请先阅读 executor/README.md。包含自动连接控制器和 CAD 执行器；尚未实机生产验证。
