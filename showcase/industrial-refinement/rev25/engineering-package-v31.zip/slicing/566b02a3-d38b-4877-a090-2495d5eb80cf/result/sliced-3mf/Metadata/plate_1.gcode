; HEADER_BLOCK_START
; BambuStudio 02.08.02.60
; model printing time: 23m 37s; total estimated time: 30m 53s
; total layer number: 23
; total filament length [mm] : 5610.04
; total filament volume [cm^3] : 13493.72
; total filament weight [g] : 17.00
; filament_density: 1.26
; filament_diameter: 1.75
; max_z_height: 4.60
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 70
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 1
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 0x0,18x0,18x28,0x28
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = auto_brim
; brim_width = 5
; chamber_temperatures = 0
; change_filament_gcode = ;=X1 20251031=\nM620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nG1 X70 F21000\nG1 Y245\nG1 Y265 F3000\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E-{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{else}\nM620.11 S0\n{endif}\nM400\nG1 X90 F3000\nG1 Y255 F4000\nG1 X100 F5000\nG1 X120 F15000\nG1 X20 Y50 F21000\nG1 Y-3\n{if toolchange_count == 2}\n; get travel path for change filament\nM620.1 X[travel_point_1_x] Y[travel_point_1_y] F21000 P0\nM620.1 X[travel_point_2_x] Y[travel_point_2_y] F21000 P1\nM620.1 X[travel_point_3_x] Y[travel_point_3_y] F21000 P2\n{endif}\nM620.1 E F{flush_volumetric_speeds[previous_extruder]/2.4053*60} T{flush_temperatures[previous_extruder]}\nT[next_extruder]\nM620.1 E F{flush_volumetric_speeds[next_extruder]/2.4053*60} T{flush_temperatures[next_extruder]}\n\n{if next_extruder < 255}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM628 S1\nG92 E0\nG1 E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM400\nM629 S1\n{else}\nM620.11 S0\n{endif}\nG92 E0\n{if flush_length_1 > 1}\nM83\n; FLUSH_START\n; always use highest temperature to flush\nM400\n{if filament_type[next_extruder] == \"PETG\"}\nM109 S260\n{elsif filament_type[next_extruder] == \"PVA\"}\nM109 S210\n{else}\nM109 S{flush_temperatures[next_extruder]}\n{endif}\n{if flush_length_1 > 23.7}\nG1 E23.7 F{flush_volumetric_speeds[previous_extruder]/2.4053*60} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\n{else}\nG1 E{flush_length_1} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_4 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n; FLUSH_START\nM400\nM109 S[new_filament_temp]\nG1 E2 F{flush_volumetric_speeds[next_extruder]/2.4053*60} ;Compensate for filament spillage during waiting temperature\n; FLUSH_END\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM106 P1 S255\nM400 S3\n\nG1 X70 F5000\nG1 X90 F3000\nG1 Y255 F4000\nG1 X105 F5000\nG1 Y265 F5000\nG1 X70 F10000\nG1 X100 F5000\nG1 X70 F10000\nG1 X100 F5000\n\nG1 X70 F10000\nG1 X80 F15000\nG1 X60\nG1 X80\nG1 X60\nG1 X80 ; shake to put down garbage\nG1 X100 F5000\nG1 X165 F15000; wipe and shake\nG1 Y256 ; move Y to aside, prevent collision\nM400\nG1 Z{max_layer_z + 3.0} F3000\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\nM621 S[next_extruder]A\n
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; compatible_printers_condition = 
; complete_print_exhaust_fan_speed = 70
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.008
; counter_coef_3 = -0.041
; counter_limit_max = 0.033
; counter_limit_min = -0.035
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 10000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL X1C"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL X1C
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70
; elefant_foot_compensation = 0.15
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 1
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0
; eng_plate_temp_initial_layer = 0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 33
; extruder_clearance_height_to_lid = 90
; extruder_clearance_height_to_rod = 34
; extruder_clearance_max_radius = 68
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x2
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard,Direct Drive High Flow"
; fan_cooling_layer_time = 100
; fan_direction = left
; fan_max_speed = 100
; fan_min_speed = 100
; farthest_point_timelapse = 1
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 100
; filament_bridge_speed = 25
; filament_change_length = 5
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 0
; filament_cost = 19.99
; filament_density = 1.26
; filament_dev_ams_drying_ams_limitations = 1
; filament_dev_ams_drying_heat_distortion_temperature = 45
; filament_dev_ams_drying_temperature = 45
; filament_dev_ams_drying_time = 12
; filament_dev_chamber_drying_bed_temperature = 70
; filament_dev_chamber_drying_time = 12
; filament_dev_drying_cooling_temperature = 45
; filament_dev_drying_softening_temperature = 50
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = "; filament end gcode \n\n"
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = GFA00
; filament_is_mixed = 0
; filament_is_support = 0
; filament_long_retractions_when_cut = 1
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 21
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 50
; filament_overhang_3_4_speed = 30
; filament_overhang_4_4_speed = 10
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 10
; filament_prime_volume = 30
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 14
; filament_retraction_distances_when_cut = 18
; filament_scarf_gap = 0%
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Bambu PLA Basic @BBL X1C"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\nM142 P1 R35 S40\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = "Bambu Lab"
; filament_volume_map = 0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 0
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 
; hole_coef_1 = 0
; hole_coef_2 = -0.008
; hole_coef_3 = 0.23415
; hole_limit_max = 0.22
; hole_limit_min = 0.088
; hot_plate_temp = 55
; hot_plate_temp_initial_layer = 55
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 13.8
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = ;===== date: 20240528 =====================\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG1 E-0.8 F1800 ; retract\nG1 Z{max_layer_z + 0.5} F900 ; lower z a little\nG1 X65 Y245 F12000 ; move to safe pos\nG1 Y265 F3000\n\nG1 X65 Y245 F12000\nG1 Y265 F3000\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\nG1 X100 F12000 ; wipe\n; pull back filament to AMS\nM620 S255\nG1 X20 Y50 F12000\nG1 Y-3\nT255\nG1 X65 F12000\nG1 Y265\nG1 X100 F12000 ; wipe\nM621 S255\nM104 S0 ; turn off hotend\n\nM622.1 S1 ; for prev firware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n    M400 ; wait all motion done\n    M991 S0 P-1 ;end smooth timelapse at safe pos\n    M400 S3 ;wait for last picture to be taken\nM623; end of \"timelapse_record_flag\"\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 250}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z250 F600\n    G1 Z248\n{endif}\nM400 P100\nM17 R ; restore z current\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n;=====printer finish  sound=========\nM17\nM400 S1\nM1006 S1\nM1006 A0 B20 L100 C37 D20 M40 E42 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C46 D10 M80 E46 F10 N80\nM1006 A44 B20 L100 C39 D20 M60 E48 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C48 D10 M60 E44 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10  N100\nM1006 A49 B20 L100 C44 D20 M100 E41 F20 N100\nM1006 A0 B20 L100 C0 D20 M60 E0 F20 N100\nM1006 A0 B20 L100 C37 D20 M30 E37 F20 N60\nM1006 W\n\nM17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power\nM960 S5 P0 ; turn off logo lamp\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 29
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 20000,20000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 9000,9000
; machine_max_acceleration_x = 20000,20000
; machine_max_acceleration_y = 20000,20000
; machine_max_acceleration_z = 500,500
; machine_max_force_Y = 0
; machine_max_jerk_e = 2.5,2.5
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_printed_mass = 0
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,500
; machine_max_speed_y = 500,500
; machine_max_speed_z = 20,20
; machine_min_extruding_rate = 0
; machine_min_travel_rate = 0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = ;===== machine: X1-0.4 ====================\n;===== date: 20251031 ==================\n;===== start printer sound ================\nM17\nM400 S1\nM1006 S1\nM1006 A0 B10 L100 C37 D10 M60 E37 F10 N60\nM1006 A0 B10 L100 C41 D10 M60 E41 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A46 B10 L100 C43 D10 M70 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A43 B10 L100 C0 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A41 B10 L100 C0 D10 M100 E41 F10 N100\nM1006 A44 B10 L100 C0 D10 M100 E44 F10 N100\nM1006 A49 B10 L100 C0 D10 M100 E49 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A48 B10 L100 C44 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A44 B10 L100 C0 D10 M90 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A46 B10 L100 C43 D10 M60 E39 F10 N100\nM1006 W\n;===== turn on the HB fan =================\nM104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle\n;===== reset machine status =================\nM290 X40 Y40 Z2.6666666\nG91\nM17 Z0.4 ; lower the z-motor current\nG380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed\nG380 S2 Z-25 F300 ;\nG1 Z5 F300;\nG90\nM17 X1.2 Y1.2 Z0.75 ; reset motor current to default\nM960 S5 P1 ; turn on logo lamp\nG90\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 5\nM221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem\nG29.1 Z{+0.0} ; clear z-trim value first\nM204 S10000 ; init ACC set to 10m/s^2\n\n;===== heatbed preheat ====================\nM1002 gcode_claim_action:54\nM140 S[bed_temperature_initial_layer_single] ;set bed temp\nM190 S[bed_temperature_initial_layer_single] ;wait for bed temp\n\n{if scan_first_layer}\n;=========register first layer scan=====\nM977 S1 P60\n{endif}\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\n;===== prepare print temperature and material ==========\nM104 S[nozzle_temperature_initial_layer] ;set extruder temp\nG91\nG0 Z10 F1200\nG90\nG28 X\nM975 S1 ; turn on\nG1 X60 F12000\nG1 Y245\nG1 Y265 F3000\nM620 M\nM620 S[initial_no_support_extruder]A   ; switch material if AMS exist\n    M109 S[nozzle_temperature_initial_layer]\n    G1 X120 F12000\n\n    G1 X20 Y50 F12000\n    G1 Y-3\n    T[initial_no_support_extruder]\n    G1 X54 F12000\n    G1 Y265\n    M400\nM621 S[initial_no_support_extruder]A\nM620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T{flush_temperatures[initial_no_support_extruder]}\n\nM412 S1 ; ===turn on filament runout detection===\n\nM109 S250 ;set nozzle to common flush temp\nM106 P1 S0\nG92 E0\nG1 E50 F200\nM400\nM104 S[nozzle_temperature_initial_layer]\nG92 E0\nG1 E50 F200\nM400\nM106 P1 S255\nG92 E0\nG1 E5 F300\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20} ; drop nozzle temp, make filament shink a bit\nG92 E0\nG1 E-0.5 F300\n\nG1 X70 F9000\nG1 X76 F15000\nG1 X65 F15000\nG1 X76 F15000\nG1 X65 F15000; shake to put down garbage\nG1 X80 F6000\nG1 X95 F15000\nG1 X80 F15000\nG1 X165 F15000; wipe and shake\nM400\nM106 P1 S0\n;===== prepare print temperature and material end =====\n\n\n;===== wipe nozzle ===============================\nM1002 gcode_claim_action : 14\nM975 S1\nM106 S255\nG1 X65 Y230 F18000\nG1 Y264 F6000\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20}\nG1 X100 F18000 ; first wipe mouth\n\nG0 X135 Y253 F20000  ; move to exposed steel surface edge\nG28 Z P0 T300; home z with low precision,permit 300deg temperature\nG29.2 S0 ; turn off ABL\nG0 Z5 F20000\n\nG1 X60 Y265\nG92 E0\nG1 E-0.5 F300 ; retrack more\nG1 X100 F5000; second wipe mouth\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X90 F5000\nG0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle\nM104 S140 ; set temp down to heatbed acceptable\nM106 S255 ; turn on fan (G28 has turn off fan)\n\nM221 S; push soft endstop status\nM221 Z0 ;turn off Z axis endstop\nG0 Z0.5 F20000\nG0 X125 Y259.5 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 X128\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\n\nM109 S140 ; wait nozzle temp down to heatbed acceptable\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\n\nM221 R; pop softend status\nG1 Z10 F1200\nM400\nG1 Z10\nG1 F30000\nG1 X128 Y128\nG29.2 S1 ; turn on ABL\n;G28 ; home again after hard wipe mouth\nM106 S0 ; turn off fan , too noisy\n;===== wipe nozzle end ================================\n\n;===== check scanner clarity ===========================\nG1 X128 Y128 F24000\nG28 Z P0\nM972 S5 P0\nG1 X230 Y15 F24000\n;===== check scanner clarity end =======================\n\n;===== bed leveling ==================================\nM1002 judge_flag g29_before_print_flag\nM622 J1\n\n    M1002 gcode_claim_action : 1\n    G29 A X{first_layer_print_min[0]} Y{first_layer_print_min[1]} I{first_layer_print_size[0]} J{first_layer_print_size[1]}\n    M400\n    M500 ; save cali data\n\nM623\n;===== bed leveling end ================================\n\n;===== home after wipe mouth============================\nM1002 judge_flag g29_before_print_flag\nM622 J0\n\n    M1002 gcode_claim_action : 13\n    G28\n\nM623\n;===== home after wipe mouth end =======================\n\nM975 S1 ; turn on vibration supression\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\nM104 S{nozzle_temperature_initial_layer[initial_no_support_extruder]} ; set extrude temp earlier, to reduce wait time\n\n;===== mech mode fast check============================\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q1 A7 B30 C80  H15 K0\nM974 Q1 S2 P0\n\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q0 A7 B30 C90 Q0 H15 K0\nM974 Q0 S2 P0\n\nM975 S1\nG1 F30000\nG1 X230 Y15\nG28 X ; re-home XY\n;===== mech mode fast check============================\n\n{if scan_first_layer}\n;start heatbed  scan====================================\nM976 S2 P1\nG90\nG1 X128 Y128 F20000\nM976 S3 P2  ;register void printing detection\n{endif}\n\n;===== nozzle load line ===============================\nM975 S1\nG90\nM83\nT1000\nG1 X18.0 Y1.0 Z0.8 F18000;Move to start position\nM109 S{nozzle_temperature[initial_no_support_extruder]}\nG1 Z0.2\nG0 E2 F300\nG0 X240 E15 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nG0 Y11 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\nG0 X239.5\nG0 E0.2\nG0 Y1.5 E0.700\nG0 X231 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM400\n\n;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==\n;curr_bed_type={curr_bed_type}\n{if curr_bed_type==\"Textured PEI Plate\"}\nG29.1 Z{-0.04} ; for Textured PEI Plate\n{endif}\n\n;===== draw extrinsic para cali paint =================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M1002 gcode_claim_action : 8\n\n    T1000\n\n    G0 F1200.0 X231 Y12   Z0.2 E0.577\n    G0 F1200.0 X226 Y12   Z0.2 E0.275\n    G0 F1200.0 X226 Y1.5  Z0.2 E0.577\n    G0 F1200.0 X220 Y1.5  Z0.2 E0.330\n    G0 F1200.0 X220 Y8    Z0.2 E0.358\n    G0 F1200.0 X210 Y8    Z0.2 E0.549\n    G0 F1200.0 X210 Y1.5  Z0.2 E0.357\n\n    G0 X48.0 E11.9 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X48.0 Y12 E0.772 F1200.0\n    G0 X45.0 E0.22 F1200.0\n    G0 X35.0 Y6.0 E0.86 F1200.0\n\n    ;=========== extruder cali extrusion ==================\n    T1000\n    M83\n    {if default_acceleration > 0}\n        {if outer_wall_acceleration > 0}\n            M204 S[outer_wall_acceleration]\n        {else}\n            M204 S[default_acceleration]\n        {endif}\n    {endif}\n    G0 X35.000 Y6.000 Z0.300 F30000 E0\n    G1 F1500.000 E0.800\n    M106 S0 ; turn off fan\n    G0 X185.000 E9.35441 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G0 X187 Z0\n    G1 F1500.000 E-0.800\n    G0 Z1\n    G0 X180 Z0.3 F18000\n\n    M900 L1000.0 M1.0\n    M900 K0.040\n    G0 X45.000 F30000\n    G0 Y8.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.020\n    G0 X45.000 F30000\n    G0 Y10.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.000\n    G0 X45.000 F30000\n    G0 Y12.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n\n    G0 X45.000 F30000 ; move to start point\n\nM623 ; end of \"draw extrinsic para cali paint\"\n\n\nM1002 judge_flag extrude_cali_flag\nM622 J0\n    G0 X231 Y1.5 F30000\n    G0 X18 E14.3 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM623\n\nM104 S140\n\n\n;=========== laser and rgb calibration ===========\nM400\nM18 E\nM500 R\n\nM973 S3 P14\n\nG1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nT1100\nG1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nM400 P100\nM960 S1 P1\nM400 P100\nM973 S6 P0; use auto exposure for horizontal laser by xcam\nM960 S0 P0\n\nG1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos\nM960 S2 P1\nM400 P100\nM973 S6 P1; use auto exposure for vertical laser by xcam\nM960 S0 P0\n\n;=========== handeye calibration ======================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M973 S3 P1 ; camera start stream\n    M400 P500\n    M973 S1\n    G0 F6000 X228.500 Y4.750 Z0.000\n    M960 S0 P1\n    M973 S1\n    M400 P800\n    M971 S6 P0\n    M973 S2 P0\n    M400 P500\n    G0 Z0.000 F12000\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P200\n    M971 S5 P1\n    M973 S2 P1\n    M400 P500\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P3\n    G0 Z0.500 F12000\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P4\n    M973 S2 P0\n    M400 P500\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P500\n    M971 S5 P2\n    M963 S1\n    M400 P1500\n    M964\n    T1100\n    G1 Z3 F3000\n\n    M400\n    M500 ; save cali data\n\n    M104 S{nozzle_temperature[initial_no_support_extruder]} ; rise nozzle temp now ,to reduce temp waiting time.\n\n    T1100\n    M400 P400\n    M960 S0 P0\n    G0 F30000.000 Y10.000 X65.000 Z0.000\n    M400 P400\n    M960 S1 P1\n    M400 P50\n\n    M969 S1 N3 A2000\n    G0 F360.000 X181.000 Z0.000\n    M980.3 A70.000 B{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60/4} C5.000 D{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60} E5.000 F175.000 H1.000 I0.000 J0.020 K0.040\n    M400 P100\n    G0 F20000\n    G0 Z1 ; rise nozzle up\n    T1000 ; change to nozzle space\n    G0 X45.000 Y4.000 F30000 ; move to test line pos\n    M969 S0 ; turn off scanning\n    M960 S0 P0\n\n\n    G1 Z2 F20000\n    T1000\n    G0 X45.000 Y4.000 F30000 E0\n    M109 S{nozzle_temperature[initial_no_support_extruder]}\n    G0 Z0.3\n    G1 F1500.000 E3.600\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n\n    ; see if extrude cali success, if not ,use default value\n    M1002 judge_last_extrude_cali_success\n    M622 J0\n        M400\n        M900 K0.02 M{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*0.02}\n    M623\n\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X185.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X190.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X195.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X200.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X205.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X210.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X215.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X220.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X225.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    M973 S4\n\nM623\n\n;========turn off light and wait extrude temperature =============\nM1002 gcode_claim_action : 0\nM973 S4 ; turn off scanner\nM400 ; wait all motion done before implement the emprical L parameters\n;M900 L500.0 ; Empirical parameters\nM109 S[nozzle_temperature_initial_layer]\nM960 S1 P0 ; turn off laser\nM960 S2 P0 ; turn off laser\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off big fan\nM106 P3 S0 ; turn off chamber fan\n\nM975 S1 ; turn on mech mode supression\nG90\nM83\nT1000\n;===== purge line to wipe the nozzle ============================\nG1 E{-retraction_length[initial_no_support_extruder]} F1800\nG1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position\nG1 E{retraction_length[initial_no_support_extruder]} F1800\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]}\nG1 Z0.2\nG0 X239 E15 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\nG0 Y12 E0.7 F{outer_wall_volumetric_speed/(0.3*0.5)/4* 60}\n
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 28
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.2
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = hardened_steel
; nozzle_volume = 107
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 50%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab X1 Carbon 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab P1S 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL X1C
; printable_area = 0x0,256x0,256x256,0x256
; printable_height = 250
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab X1 Carbon
; printer_notes = 
; printer_settings_id = Bambu Lab X1 Carbon 0.4 nozzle
; printer_structure = corexy
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 249
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 1
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 4
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 150
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 15%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45
; supertack_plate_temp_initial_layer = 45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = tree(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45
; template_custom_gcode = 
; textured_plate_temp = 55
; textured_plate_temp_initial_layer = 55
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;========Date 20250206========\n; SKIPPABLE_START\n; SKIPTYPE: timelapse\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n{if timelapse_type == 0} ; timelapse without wipe tower\nM971 S11 C10 O0\nM1004 S5 P1  ; external shutter\n{elsif timelapse_type == 1} ; timelapse with wipe tower\nG92 E0\nG1 X65 Y245 F20000 ; move to safe pos\nG17\nG2 Z{layer_z} I0.86 J0.86 P1 F20000\nG1 Y265 F3000\nM400\nM1004 S5 P1  ; external shutter\nM400 P300\nM971 S11 C10 O0\nG92 E0\nG1 X100 F5000\nG1 Y255 F20000\n{endif}\nM623\n; SKIPPABLE_END\n
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 500
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab P1S 0.4 nozzle";"Bambu Lab P1P 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle";"Bambu Lab A1 0.4 nozzle";"Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R30
M201 X20000 Y20000 Z500 E5000
M203 X500 Y500 Z20 E30
M204 P20000 R5000 T20000
M205 X9.00 Y9.00 Z3.00 E2.50
M106 S0
M106 P2 S0
; FEATURE: Custom
;===== machine: X1-0.4 ====================
;===== date: 20251031 ==================
;===== start printer sound ================
M17
M400 S1
M1006 S1
M1006 A0 B10 L100 C37 D10 M60 E37 F10 N60
M1006 A0 B10 L100 C41 D10 M60 E41 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A46 B10 L100 C43 D10 M70 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A43 B10 L100 C0 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A41 B10 L100 C0 D10 M100 E41 F10 N100
M1006 A44 B10 L100 C0 D10 M100 E44 F10 N100
M1006 A49 B10 L100 C0 D10 M100 E49 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A48 B10 L100 C44 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A44 B10 L100 C0 D10 M90 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A46 B10 L100 C43 D10 M60 E39 F10 N100
M1006 W
;===== turn on the HB fan =================
M104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle
;===== reset machine status =================
M290 X40 Y40 Z2.6666666
G91
M17 Z0.4 ; lower the z-motor current
G380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed
G380 S2 Z-25 F300 ;
G1 Z5 F300;
G90
M17 X1.2 Y1.2 Z0.75 ; reset motor current to default
M960 S5 P1 ; turn on logo lamp
G90
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 5
M221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem
G29.1 Z0 ; clear z-trim value first
M204 S10000 ; init ACC set to 10m/s^2

;===== heatbed preheat ====================
M1002 gcode_claim_action:54
M140 S35 ;set bed temp
M190 S35 ;wait for bed temp


;=========register first layer scan=====
M977 S1 P60


;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

;===== prepare print temperature and material ==========
M104 S220 ;set extruder temp
G91
G0 Z10 F1200
G90
G28 X
M975 S1 ; turn on
G1 X60 F12000
G1 Y245
G1 Y265 F3000
M620 M
M620 S0A   ; switch material if AMS exist
    M109 S220
    G1 X120 F12000

    G1 X20 Y50 F12000
    G1 Y-3
    T0
    G1 X54 F12000
    G1 Y265
    M400
M621 S0A
M620.1 E F523.843 T240

M412 S1 ; ===turn on filament runout detection===

M109 S250 ;set nozzle to common flush temp
M106 P1 S0
G92 E0
M73 P1 R30
G1 E50 F200
M400
M104 S220
G92 E0
M73 P15 R25
G1 E50 F200
M400
M106 P1 S255
G92 E0
M73 P16 R25
G1 E5 F300
M109 S200 ; drop nozzle temp, make filament shink a bit
G92 E0
G1 E-0.5 F300

M73 P17 R25
G1 X70 F9000
G1 X76 F15000
G1 X65 F15000
G1 X76 F15000
G1 X65 F15000; shake to put down garbage
G1 X80 F6000
G1 X95 F15000
G1 X80 F15000
G1 X165 F15000; wipe and shake
M400
M106 P1 S0
;===== prepare print temperature and material end =====


;===== wipe nozzle ===============================
M1002 gcode_claim_action : 14
M975 S1
M106 S255
G1 X65 Y230 F18000
G1 Y264 F6000
M109 S200
G1 X100 F18000 ; first wipe mouth

G0 X135 Y253 F20000  ; move to exposed steel surface edge
G28 Z P0 T300; home z with low precision,permit 300deg temperature
G29.2 S0 ; turn off ABL
G0 Z5 F20000

G1 X60 Y265
G92 E0
G1 E-0.5 F300 ; retrack more
G1 X100 F5000; second wipe mouth
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X90 F5000
G0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle
M104 S140 ; set temp down to heatbed acceptable
M106 S255 ; turn on fan (G28 has turn off fan)

M221 S; push soft endstop status
M221 Z0 ;turn off Z axis endstop
G0 Z0.5 F20000
G0 X125 Y259.5 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 X128
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300

M109 S140 ; wait nozzle temp down to heatbed acceptable
G2 I0.5 J0 F3000
M73 P18 R25
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000

M221 R; pop softend status
G1 Z10 F1200
M400
G1 Z10
G1 F30000
G1 X128 Y128
G29.2 S1 ; turn on ABL
;G28 ; home again after hard wipe mouth
M106 S0 ; turn off fan , too noisy
;===== wipe nozzle end ================================

;===== check scanner clarity ===========================
G1 X128 Y128 F24000
G28 Z P0
M972 S5 P0
G1 X230 Y15 F24000
;===== check scanner clarity end =======================

;===== bed leveling ==================================
M1002 judge_flag g29_before_print_flag
M622 J1

    M1002 gcode_claim_action : 1
    G29 A X73.0842 Y96 I109.832 J64
    M400
    M500 ; save cali data

M623
;===== bed leveling end ================================

;===== home after wipe mouth============================
M1002 judge_flag g29_before_print_flag
M622 J0

    M1002 gcode_claim_action : 13
    G28

M623
;===== home after wipe mouth end =======================

M975 S1 ; turn on vibration supression

;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

M104 S220 ; set extrude temp earlier, to reduce wait time

;===== mech mode fast check============================
G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q1 A7 B30 C80  H15 K0
M974 Q1 S2 P0

G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q0 A7 B30 C90 Q0 H15 K0
M974 Q0 S2 P0

M975 S1
G1 F30000
G1 X230 Y15
G28 X ; re-home XY
;===== mech mode fast check============================


;start heatbed  scan====================================
M976 S2 P1
G90
G1 X128 Y128 F20000
M976 S3 P2  ;register void printing detection


;===== nozzle load line ===============================
M975 S1
G90
M83
T1000
G1 X18.0 Y1.0 Z0.8 F18000;Move to start position
M109 S220
G1 Z0.2
G0 E2 F300
G0 X240 E15 F6033.27
G0 Y11 E0.700 F1508.32
G0 X239.5
G0 E0.2
G0 Y1.5 E0.700
G0 X231 E0.700 F6033.27
M400

;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==
;curr_bed_type=Cool Plate


;===== draw extrinsic para cali paint =================
M1002 judge_flag extrude_cali_flag
M622 J1

    M1002 gcode_claim_action : 8

    T1000

    G0 F1200.0 X231 Y12   Z0.2 E0.577
    G0 F1200.0 X226 Y12   Z0.2 E0.275
    G0 F1200.0 X226 Y1.5  Z0.2 E0.577
    G0 F1200.0 X220 Y1.5  Z0.2 E0.330
    G0 F1200.0 X220 Y8    Z0.2 E0.358
    G0 F1200.0 X210 Y8    Z0.2 E0.549
    G0 F1200.0 X210 Y1.5  Z0.2 E0.357

    G0 X48.0 E11.9 F6033.27
    G0 X48.0 Y12 E0.772 F1200.0
    G0 X45.0 E0.22 F1200.0
    G0 X35.0 Y6.0 E0.86 F1200.0

    ;=========== extruder cali extrusion ==================
    T1000
    M83
    
        
            M204 S5000
        
    
    G0 X35.000 Y6.000 Z0.300 F30000 E0
    G1 F1500.000 E0.800
    M106 S0 ; turn off fan
    G0 X185.000 E9.35441 F6033.27
    G0 X187 Z0
    G1 F1500.000 E-0.800
    G0 Z1
    G0 X180 Z0.3 F18000

    M900 L1000.0 M1.0
    M900 K0.040
    G0 X45.000 F30000
    G0 Y8.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
M73 P19 R25
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
M73 P19 R24
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.020
    G0 X45.000 F30000
    G0 Y10.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
M73 P20 R24
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.000
    G0 X45.000 F30000
    G0 Y12.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3

    G0 X45.000 F30000 ; move to start point

M623 ; end of "draw extrinsic para cali paint"


M1002 judge_flag extrude_cali_flag
M622 J0
    G0 X231 Y1.5 F30000
    G0 X18 E14.3 F6033.27
M623

M104 S140


;=========== laser and rgb calibration ===========
M400
M18 E
M500 R

M973 S3 P14

G1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
T1100
G1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
M400 P100
M960 S1 P1
M400 P100
M973 S6 P0; use auto exposure for horizontal laser by xcam
M960 S0 P0

G1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos
M960 S2 P1
M400 P100
M973 S6 P1; use auto exposure for vertical laser by xcam
M960 S0 P0

;=========== handeye calibration ======================
M1002 judge_flag extrude_cali_flag
M622 J1

    M973 S3 P1 ; camera start stream
    M400 P500
    M973 S1
    G0 F6000 X228.500 Y4.750 Z0.000
    M960 S0 P1
    M973 S1
    M400 P800
    M971 S6 P0
    M973 S2 P0
    M400 P500
    G0 Z0.000 F12000
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P200
    M971 S5 P1
    M973 S2 P1
    M400 P500
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P3
    G0 Z0.500 F12000
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P4
    M973 S2 P0
    M400 P500
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P500
    M971 S5 P2
    M963 S1
    M400 P1500
    M964
    T1100
    G1 Z3 F3000

    M400
    M500 ; save cali data

    M104 S220 ; rise nozzle temp now ,to reduce temp waiting time.

    T1100
    M400 P400
    M960 S0 P0
    G0 F30000.000 Y10.000 X65.000 Z0.000
    M400 P400
    M960 S1 P1
    M400 P50

    M969 S1 N3 A2000
    G0 F360.000 X181.000 Z0.000
    M980.3 A70.000 B94.1106 C5.000 D376.442 E5.000 F175.000 H1.000 I0.000 J0.020 K0.040
    M400 P100
    G0 F20000
    G0 Z1 ; rise nozzle up
    T1000 ; change to nozzle space
    G0 X45.000 Y4.000 F30000 ; move to test line pos
    M969 S0 ; turn off scanning
    M960 S0 P0


    G1 Z2 F20000
    T1000
    G0 X45.000 Y4.000 F30000 E0
    M109 S220
    G0 Z0.3
    G1 F1500.000 E3.600
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27

    ; see if extrude cali success, if not ,use default value
    M1002 judge_last_extrude_cali_success
    M622 J0
        M400
        M900 K0.02 M0.125481
    M623

    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
M73 P21 R24
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F1508.32
    G1 X185.000 E0.31181 F6033.27
    G1 X190.000 E0.31181 F1508.32
    G1 X195.000 E0.31181 F6033.27
    G1 X200.000 E0.31181 F1508.32
    G1 X205.000 E0.31181 F6033.27
    G1 X210.000 E0.31181 F1508.32
    G1 X215.000 E0.31181 F6033.27
    G1 X220.000 E0.31181 F1508.32
    G1 X225.000 E0.31181 F6033.27
    M973 S4

M623

;========turn off light and wait extrude temperature =============
M1002 gcode_claim_action : 0
M973 S4 ; turn off scanner
M400 ; wait all motion done before implement the emprical L parameters
;M900 L500.0 ; Empirical parameters
M109 S220
M960 S1 P0 ; turn off laser
M960 S2 P0 ; turn off laser
M106 S0 ; turn off fan
M106 P2 S0 ; turn off big fan
M106 P3 S0 ; turn off chamber fan

M975 S1 ; turn on mech mode supression
G90
M83
T1000
;===== purge line to wipe the nozzle ============================
G1 E-0.8 F1800
G1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position
G1 E0.8 F1800
M109 S220
G1 Z0.2
G0 X239 E15 F6033.27
G0 Y12 E0.7 F1508.32
; MACHINE_START_GCODE_END
; filament start gcode

M142 P1 R35 S40
;VT0 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/23
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
M106 P2 S0
; OBJECT_ID: 15
G1 X162.177 Y144.389 F30000
M204 S6000
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G3 X165.895 Y141.859 I3.816 J1.611 E.17705
G1 X166.122 Y141.86 E.00845
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X162.154 Y144.444 I-.129 J4.14 E.78157
M204 S6000
G1 X161.764 Y144.208 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X162.07 Y143.598 E.02542
G3 X165.885 Y141.402 I3.922 J2.401 E.17097
G1 X166.134 Y141.403 E.00929
G3 X161.736 Y144.258 I-.142 J4.597 E.86847
; WIPE_START
G1 X162.07 Y143.598 E-.28094
G1 X162.333 Y143.223 E-.17432
G1 X162.628 Y142.871 E-.17434
G1 X162.874 Y142.632 E-.1304
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X169.554 Y144.257 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51113
G1 F6300
M204 S500
G1 X168.478 Y143.181 E.05804
G2 X167.03 Y142.395 I-2.508 J2.895 E.06334
G1 X169.606 Y144.971 E.13898
G3 X169.745 Y145.772 I-3.909 J1.091 E.03108
G1 X166.23 Y142.257 E.18965
G1 X165.584 Y142.274 E.02465
G1 X169.721 Y146.41 E.22318
G3 X169.621 Y146.973 I-2.293 J-.115 E.02186
G1 X165.028 Y142.379 E.24786
G2 X164.534 Y142.548 I.598 J2.552 E.01993
G1 X169.454 Y147.468 E.26547
G3 X169.229 Y147.905 I-2.296 J-.904 E.01879
G1 X164.093 Y142.769 E.27715
G2 X163.701 Y143.038 I1.15 J2.092 E.0182
G1 X168.962 Y148.299 E.28386
G3 X168.653 Y148.653 I-1.92 J-1.365 E.01793
G1 X163.349 Y143.349 E.28619
G2 X163.037 Y143.699 I1.593 J1.734 E.01792
G1 X168.301 Y148.963 E.28404
G3 X167.905 Y149.229 I-1.531 J-1.85 E.01823
G1 X162.769 Y144.094 E.27711
G2 X162.549 Y144.535 I2.098 J1.323 E.01887
G1 X167.465 Y149.452 E.26528
G3 X166.974 Y149.623 I-1.83 J-4.457 E.01985
G1 X162.377 Y145.026 E.24806
G2 X162.274 Y145.585 I4.268 J1.078 E.0217
G1 X166.416 Y149.726 E.22348
M73 P22 R23
G3 X165.769 Y149.742 I-.418 J-3.818 E.02469
G1 X162.255 Y146.228 E.18963
G2 X162.394 Y147.029 I4.048 J-.29 E.03108
M73 P23 R23
G1 X164.97 Y149.605 E.13898
G3 X163.522 Y148.819 I1.06 J-3.681 E.06336
G1 X162.446 Y147.744 E.05801
; WIPE_START
G1 X163.522 Y148.819 E-.57778
G1 X163.809 Y149.048 E-.13959
G1 X163.903 Y149.109 E-.04263
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X164.75 Y141.523 Z.6 F30000
G1 X169.033 Y103.186 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G3 X165.895 Y101.859 I-3.04 J2.813 E.83853
G1 X166.122 Y101.86 E.00845
G3 X168.992 Y103.142 I-.129 J4.14 E.1201
M204 S6000
G1 X169.368 Y102.876 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G3 X165.884 Y101.402 I-3.375 J3.124 E.93112
G1 X166.134 Y101.403 E.00929
G3 X169.326 Y102.832 I-.142 J4.597 E.13365
; WIPE_START
G1 X169.667 Y103.223 E-.1969
G1 X169.925 Y103.601 E-.17423
G1 X170.144 Y104.004 E-.17431
G1 X170.322 Y104.427 E-.17415
G1 X170.354 Y104.528 E-.04042
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X169.554 Y104.257 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51113
G1 F6300
M204 S500
G1 X168.478 Y103.181 E.05804
G2 X167.03 Y102.395 I-2.508 J2.895 E.06334
G1 X169.606 Y104.971 E.13898
G3 X169.745 Y105.772 I-3.907 J1.091 E.03108
G1 X166.23 Y102.257 E.18965
G1 X165.584 Y102.274 E.02465
G1 X169.726 Y106.416 E.22348
G3 X169.623 Y106.974 I-4.373 J-.52 E.0217
G1 X165.027 Y102.379 E.24795
G2 X164.534 Y102.548 I.597 J2.549 E.01993
G1 X169.451 Y107.465 E.26531
G3 X169.231 Y107.907 I-2.319 J-.881 E.01887
G1 X164.093 Y102.769 E.27722
G2 X163.701 Y103.038 I1.151 J2.094 E.0182
G1 X168.963 Y108.301 E.28396
G3 X168.651 Y108.651 I-1.904 J-1.383 E.01792
G1 X163.349 Y103.349 E.2861
G2 X163.037 Y103.699 I1.591 J1.732 E.01792
G1 X168.299 Y108.962 E.28396
G3 X167.907 Y109.231 I-1.543 J-1.824 E.0182
G1 X162.769 Y104.094 E.27722
G2 X162.549 Y104.535 I2.097 J1.322 E.01887
G1 X167.463 Y109.45 E.26515
G3 X166.974 Y109.623 I-1.587 J-3.693 E.0198
G1 X162.377 Y105.026 E.24806
G2 X162.274 Y105.585 I4.27 J1.079 E.0217
G1 X166.416 Y109.726 E.22348
G3 X165.769 Y109.742 I-.418 J-3.817 E.02469
G1 X162.255 Y106.228 E.18963
G2 X162.394 Y107.029 I4.051 J-.29 E.03108
G1 X164.97 Y109.605 E.13898
G3 X163.522 Y108.819 I1.06 J-3.68 E.06336
G1 X162.446 Y107.744 E.05801
; WIPE_START
G1 X163.522 Y108.819 E-.57781
G1 X163.809 Y109.048 E-.13959
G1 X163.903 Y109.109 E-.0426
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X156.302 Y108.416 Z.6 F30000
G1 X88.306 Y102.22 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X88.68 Y102.071 E.01498
G3 X89.895 Y101.859 I1.313 J3.928 E.04612
G1 X90.122 Y101.86 E.00845
G3 X88.251 Y102.242 I-.129 J4.14 E.89753
M204 S6000
G1 X88.139 Y101.795 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X88.534 Y101.638 E.01583
G3 X89.884 Y101.402 I1.458 J4.362 E.05126
G1 X90.134 Y101.403 E.00929
G3 X88.083 Y101.815 I-.142 J4.597 E.99769
; WIPE_START
G1 X88.534 Y101.638 E-.18418
G1 X88.976 Y101.516 E-.17434
G1 X89.428 Y101.436 E-.17426
G1 X89.884 Y101.402 E-.17402
G1 X90.024 Y101.402 E-.0532
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X93.554 Y104.257 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51113
G1 F6300
M204 S500
G1 X92.478 Y103.181 E.05803
G2 X91.03 Y102.395 I-2.508 J2.895 E.06336
G1 X93.606 Y104.971 E.13898
G3 X93.745 Y105.772 I-3.912 J1.091 E.03107
G1 X90.23 Y102.257 E.18965
G1 X89.584 Y102.274 E.02465
G1 X93.726 Y106.416 E.22348
G3 X93.621 Y106.973 I-3.879 J-.442 E.02165
G1 X89.028 Y102.379 E.24787
G2 X88.534 Y102.548 I.598 J2.552 E.01993
G1 X93.454 Y107.468 E.26547
G3 X93.229 Y107.905 I-2.297 J-.904 E.01879
G1 X88.093 Y102.769 E.27715
G2 X87.701 Y103.038 I1.151 J2.094 E.0182
G1 X92.962 Y108.299 E.28386
G3 X92.653 Y108.653 I-1.922 J-1.367 E.01793
G1 X87.349 Y103.349 E.28619
G2 X87.037 Y103.699 I1.592 J1.733 E.01792
G1 X92.301 Y108.963 E.28404
G3 X91.905 Y109.229 I-1.529 J-1.848 E.01823
G1 X86.769 Y104.094 E.27711
G2 X86.549 Y104.535 I2.098 J1.323 E.01887
G1 X91.465 Y109.452 E.26528
G3 X90.974 Y109.623 I-1.831 J-4.461 E.01985
G1 X86.377 Y105.026 E.24806
G2 X86.274 Y105.585 I4.273 J1.079 E.0217
G1 X90.416 Y109.726 E.22348
G3 X89.769 Y109.742 I-.418 J-3.818 E.02469
G1 X86.255 Y106.228 E.18963
G2 X86.394 Y107.029 I4.048 J-.29 E.03108
G1 X88.97 Y109.605 E.13898
G3 X87.522 Y108.819 I1.061 J-3.681 E.06336
G1 X86.446 Y107.744 E.05802
; WIPE_START
G1 X87.522 Y108.819 E-.57783
G1 X87.809 Y109.048 E-.13956
G1 X87.903 Y109.109 E-.04262
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X89.154 Y116.638 Z.6 F30000
G1 X93.732 Y144.202 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X93.726 Y144.205 E.00025
G3 X89.895 Y141.859 I-3.733 J1.794 E.79244
G1 X90.122 Y141.86 E.00845
G3 X93.529 Y143.843 I-.129 J4.14 E.15305
G1 X93.702 Y144.149 E.01311
M204 S6000
G1 X94.133 Y143.983 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X94.137 Y144.008 E.00092
G3 X89.885 Y141.402 I-4.145 J1.992 E.87994
G1 X90.134 Y141.403 E.00929
G3 X93.919 Y143.605 I-.142 J4.597 E.17
G1 X94.103 Y143.931 E.01395
M204 S6000
G1 X93.554 Y144.257 F30000
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51113
G1 F6300
M204 S500
M73 P24 R23
G1 X92.478 Y143.181 E.05803
G2 X91.03 Y142.395 I-2.508 J2.895 E.06335
G1 X93.606 Y144.971 E.13898
G3 X93.745 Y145.772 I-3.909 J1.091 E.03108
G1 X90.23 Y142.257 E.18965
G1 X89.584 Y142.274 E.02465
G1 X93.726 Y146.416 E.22348
G3 X93.621 Y146.973 I-3.867 J-.44 E.02165
G1 X89.028 Y142.379 E.24786
G2 X88.534 Y142.548 I.598 J2.554 E.01993
G1 X93.454 Y147.467 E.26543
G3 X93.229 Y147.905 I-4.536 J-2.044 E.01878
G1 X88.093 Y142.769 E.27715
G2 X87.701 Y143.038 I1.151 J2.093 E.0182
G1 X92.962 Y148.299 E.28386
G3 X92.653 Y148.653 I-1.923 J-1.367 E.01793
G1 X87.349 Y143.349 E.28619
G2 X87.037 Y143.699 I1.595 J1.736 E.01792
G1 X92.301 Y148.963 E.28404
G3 X91.905 Y149.229 I-1.527 J-1.845 E.01823
G1 X86.769 Y144.094 E.27711
G2 X86.549 Y144.535 I2.098 J1.323 E.01887
G1 X91.465 Y149.452 E.26528
G3 X90.974 Y149.623 I-1.827 J-4.449 E.01985
G1 X86.377 Y145.026 E.24806
G2 X86.274 Y145.585 I4.272 J1.079 E.0217
G1 X90.416 Y149.726 E.22348
G3 X89.769 Y149.742 I-.418 J-3.822 E.02469
G1 X86.255 Y146.228 E.18963
G2 X86.394 Y147.029 I4.049 J-.29 E.03108
G1 X88.97 Y149.605 E.13898
G3 X87.522 Y148.819 I1.06 J-3.681 E.06336
G1 X86.446 Y147.744 E.05802
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F6300
G1 X87.522 Y148.819 E-.57782
G1 X87.809 Y149.048 E-.13955
G1 X87.903 Y149.109 E-.04262
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/23
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S255
M106 P2 S178
; open powerlost recovery
M1003 S1
M976 S1 P1 ; scan model before printing 2nd layer
M400 P100
G1 E.8
; OBJECT_ID: 15
G1 E-.8
M204 S10000
G1 X95.519 Y148.613 Z.6 F30000
G1 X161.94 Y144.289 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X165.671 Y141.615 I4.05 J1.711 E.16021
G3 X166.167 Y141.606 I.315 J4.151 E.01644
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X161.917 Y144.344 I-.176 J4.394 E.73782
M204 S250
G1 X161.583 Y144.148 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X161.578 Y144.136 E.0004
G3 X165.642 Y141.223 I4.412 J1.864 E.16163
G3 X166.178 Y141.214 I.343 J4.492 E.01649
G3 X161.415 Y144.585 I-.188 J4.786 E.73181
G1 X161.561 Y144.204 E.01255
M204 S10000
G1 X162.287 Y143.975 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42928
G1 F15000
G1 X163.278 Y142.984 E.04413
G3 X164.633 Y142.176 I2.792 J3.14 E.04997
G1 X162.173 Y144.636 E.10955
G2 X161.986 Y145.369 I3.568 J1.298 E.02385
G1 X165.365 Y141.99 E.15046
G3 X165.964 Y141.938 I.736 J4.962 E.01894
G1 X161.941 Y145.961 E.17914
G2 X161.969 Y146.48 I2.606 J.121 E.01638
G1 X166.483 Y141.966 E.20099
G3 X166.945 Y142.049 I-1.328 J8.658 E.0148
G1 X162.05 Y146.945 E.21798
G2 X162.174 Y147.367 I2.17 J-.409 E.01388
G1 X167.366 Y142.175 E.23116
G3 X167.751 Y142.336 I-.611 J2.008 E.01317
G1 X162.334 Y147.753 E.24119
G2 X162.526 Y148.108 I1.878 J-.787 E.01271
G1 X168.106 Y142.528 E.24844
G3 X168.432 Y142.748 I-.934 J1.739 E.01241
G1 X162.747 Y148.434 E.25316
G2 X162.994 Y148.733 I1.611 J-1.083 E.01224
G1 X168.732 Y142.995 E.25548
G3 X169.006 Y143.267 I-1.224 J1.503 E.01218
G1 X163.268 Y149.005 E.25548
G2 X163.568 Y149.252 I1.382 J-1.373 E.01224
G1 X169.253 Y143.566 E.25316
G3 X169.474 Y143.892 I-1.51 J1.26 E.01241
G1 X163.894 Y149.472 E.24845
G2 X164.249 Y149.664 I1.134 J-1.674 E.01272
G1 X169.666 Y144.246 E.2412
G3 X169.826 Y144.633 I-1.853 J.995 E.01319
G1 X164.634 Y149.825 E.23116
G2 X165.054 Y149.951 I.84 J-2.035 E.01384
G1 X169.95 Y145.055 E.21798
G3 X170.031 Y145.52 I-2.283 J.638 E.01489
G1 X165.517 Y150.034 E.20099
G2 X166.038 Y150.059 I.386 J-2.592 E.01646
G1 X170.059 Y146.039 E.17902
G3 X170.014 Y146.631 I-5.336 J-.111 E.01869
G1 X166.633 Y150.012 E.15054
G2 X167.368 Y149.822 I-.748 J-4.432 E.02394
G1 X169.827 Y147.363 E.10948
G3 X169.013 Y148.724 I-3.99 J-1.464 E.05022
G1 X168.027 Y149.71 E.04388
; WIPE_START
G1 X169.013 Y148.724 E-.52968
G1 X169.24 Y148.454 E-.13403
G1 X169.382 Y148.245 E-.09629
; WIPE_END
G1 E-.04 F1800
G1 X169.355 Y140.612 Z.8 F30000
G1 X169.218 Y103.014 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X165.672 Y101.615 I-3.228 J2.986 E.78568
G3 X166.167 Y101.606 I.315 J4.156 E.01644
G3 X169.177 Y102.97 I-.176 J4.394 E.1124
M204 S250
G1 X169.509 Y102.74 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X169.505 Y102.748 E.00026
G3 X165.642 Y101.223 I-3.515 J3.252 E.79263
G3 X166.178 Y101.214 I.343 J4.498 E.01649
G3 X169.165 Y102.414 I-.188 J4.786 E.10085
G1 X169.465 Y102.698 E.01271
; WIPE_START
M204 S10000
G1 X169.505 Y102.748 E-.02418
G1 X169.818 Y103.108 E-.18133
G1 X170.087 Y103.502 E-.18141
G1 X170.316 Y103.922 E-.18148
G1 X170.501 Y104.362 E-.18148
G1 X170.509 Y104.387 E-.01011
; WIPE_END
G1 E-.04 F1800
G1 X168.021 Y109.716 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42928
G1 F15000
G1 X169.013 Y108.724 E.04417
G2 X169.827 Y107.363 I-3.176 J-2.824 E.05022
G1 X167.366 Y109.824 E.10957
G3 X166.634 Y110.01 I-1.456 J-4.205 E.02381
G1 X170.014 Y106.631 E.15047
G2 X170.059 Y106.039 I-5.296 J-.703 E.01869
G1 X166.043 Y110.055 E.17883
G3 X165.517 Y110.034 I-.18 J-2.105 E.0166
G1 X170.031 Y105.52 E.20099
G2 X169.95 Y105.055 I-2.367 J.173 E.01489
G1 X165.054 Y109.951 E.21798
G3 X164.634 Y109.825 I.421 J-2.165 E.01384
G1 X169.826 Y104.633 E.23117
G2 X169.666 Y104.246 I-2.018 J.611 E.01318
G1 X164.249 Y109.664 E.24119
G3 X163.894 Y109.472 I.779 J-1.866 E.01271
G1 X169.474 Y103.892 E.24845
G2 X169.253 Y103.566 I-1.739 J.94 E.01241
G1 X163.568 Y109.252 E.25316
G3 X163.268 Y109.005 I1.082 J-1.62 E.01224
G1 X169.006 Y103.267 E.25548
G2 X168.732 Y102.995 I-1.497 J1.229 E.01218
G1 X162.994 Y108.733 E.25548
G3 X162.747 Y108.434 I1.364 J-1.382 E.01224
G1 X168.432 Y102.748 E.25316
G2 X168.106 Y102.528 I-1.262 J1.521 E.01241
G1 X162.526 Y108.108 E.24844
G3 X162.334 Y107.753 I1.674 J-1.135 E.01271
G1 X167.751 Y102.336 E.24119
G2 X167.366 Y102.175 I-.996 J1.844 E.01317
G1 X162.174 Y107.367 E.23116
G3 X162.05 Y106.945 I2.046 J-.831 E.01388
G1 X166.945 Y102.049 E.21798
G2 X166.483 Y101.966 I-1.797 J8.605 E.0148
G1 X161.969 Y106.48 E.20099
G3 X161.941 Y105.961 I2.579 J-.398 E.01638
G1 X165.964 Y101.938 E.17914
G2 X165.365 Y101.99 I.137 J5.017 E.01894
G1 X161.986 Y105.369 E.15045
G3 X162.173 Y104.636 I3.755 J.565 E.02385
G1 X164.633 Y102.176 E.10955
G2 X163.278 Y102.985 I1.437 J3.948 E.05
G1 X162.287 Y103.975 E.0441
; WIPE_START
G1 X163.278 Y102.985 E-.53226
G1 X163.627 Y102.7 E-.17138
G1 X163.752 Y102.62 E-.05636
; WIPE_END
G1 E-.04 F1800
G1 X156.12 Y102.554 Z.8 F30000
G1 X88.255 Y101.969 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.392 Y101.904 E.00505
G3 X89.671 Y101.615 I1.598 J4.096 E.04367
G3 X90.167 Y101.606 I.315 J4.157 E.01644
G3 X87.992 Y102.083 I-.176 J4.394 E.84183
G1 X88.2 Y101.993 E.00752
M204 S250
G1 X88.093 Y101.612 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X88.249 Y101.539 E.00528
G3 X89.642 Y101.223 I1.741 J4.461 E.04405
G3 X90.178 Y101.214 I.343 J4.498 E.01649
G3 X87.813 Y101.734 I-.188 J4.786 E.84939
G1 X88.039 Y101.636 E.00756
; WIPE_START
M204 S10000
G1 X88.249 Y101.539 E-.0881
G1 X88.703 Y101.389 E-.18155
G1 X89.168 Y101.283 E-.18146
G1 X89.642 Y101.223 E-.18146
G1 X89.977 Y101.218 E-.12743
; WIPE_END
G1 E-.04 F1800
G1 X86.287 Y103.975 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42928
G1 F15000
G1 X87.278 Y102.984 E.04413
G3 X88.633 Y102.176 I2.793 J3.141 E.04997
G1 X86.173 Y104.636 E.10955
G2 X85.986 Y105.369 I3.569 J1.298 E.02385
G1 X89.365 Y101.99 E.15046
G3 X89.964 Y101.938 I.736 J4.962 E.01894
G1 X85.941 Y105.961 E.17914
G2 X85.969 Y106.48 I2.607 J.121 E.01638
G1 X90.483 Y101.966 E.20099
G3 X90.945 Y102.049 I-1.328 J8.658 E.0148
G1 X86.05 Y106.945 E.21798
G2 X86.174 Y107.367 I2.17 J-.409 E.01388
G1 X91.366 Y102.175 E.23116
G3 X91.751 Y102.336 I-.611 J2.006 E.01317
G1 X86.334 Y107.753 E.24119
G2 X86.526 Y108.108 I1.872 J-.784 E.01271
G1 X92.106 Y102.528 E.24844
G3 X92.432 Y102.748 I-.935 J1.74 E.01241
G1 X86.747 Y108.434 E.25316
G2 X86.994 Y108.733 I1.615 J-1.086 E.01224
G1 X92.732 Y102.995 E.25548
G3 X93.006 Y103.267 I-1.227 J1.505 E.01218
G1 X87.268 Y109.005 E.25548
G2 X87.568 Y109.252 I1.382 J-1.374 E.01224
G1 X93.253 Y103.566 E.25316
G3 X93.474 Y103.892 I-1.512 J1.261 E.01241
G1 X87.894 Y109.472 E.24845
G2 X88.249 Y109.664 I1.134 J-1.675 E.01271
G1 X93.666 Y104.246 E.24119
G3 X93.826 Y104.633 I-1.852 J.995 E.01318
G1 X88.634 Y109.825 E.23116
G2 X89.054 Y109.951 I.841 J-2.037 E.01384
G1 X93.95 Y105.055 E.21798
G3 X94.031 Y105.52 I-2.285 J.638 E.01489
G1 X89.517 Y110.034 E.20099
G2 X90.038 Y110.059 I.386 J-2.589 E.01646
G1 X94.059 Y106.039 E.17902
G3 X94.014 Y106.631 I-5.324 J-.111 E.0187
G1 X90.633 Y110.012 E.15054
G2 X91.368 Y109.822 I-.748 J-4.431 E.02394
G1 X93.827 Y107.363 E.10948
G3 X93.013 Y108.724 I-3.99 J-1.464 E.05021
G1 X92.027 Y109.71 E.04389
; WIPE_START
G1 X93.013 Y108.724 E-.52975
G1 X93.24 Y108.454 E-.1339
G1 X93.383 Y108.245 E-.09635
; WIPE_END
G1 E-.04 F1800
G1 X93.51 Y115.876 Z.8 F30000
G1 X93.981 Y144.137 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X94.124 Y144.499 E.01289
G3 X89.671 Y141.615 I-4.133 J1.501 E.7276
G3 X90.167 Y141.606 I.315 J4.151 E.01644
G3 X93.95 Y144.087 I-.176 J4.394 E.1576
M204 S250
G1 X94.342 Y143.985 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X94.492 Y144.365 E.01254
G3 X89.642 Y141.223 I-4.502 J1.635 E.73404
G3 X90.178 Y141.214 I.343 J4.492 E.01649
G3 X94.307 Y143.926 I-.188 J4.786 E.15946
G1 X94.312 Y143.934 E.00028
; WIPE_START
M204 S10000
G1 X94.492 Y144.365 E-.17762
G1 X94.695 Y145.051 E-.27179
G1 X94.766 Y145.523 E-.18146
G1 X94.783 Y145.862 E-.12913
; WIPE_END
G1 E-.04 F1800
G1 X92.027 Y149.71 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42928
G1 F15000
G1 X93.013 Y148.724 E.04389
G2 X93.827 Y147.363 I-3.176 J-2.824 E.05021
G1 X91.368 Y149.822 E.10948
G3 X90.633 Y150.012 I-1.483 J-4.242 E.02394
G1 X94.014 Y146.631 E.15054
G2 X94.059 Y146.039 I-5.284 J-.703 E.0187
G1 X90.038 Y150.059 E.17902
G3 X89.517 Y150.034 I-.135 J-2.616 E.01646
G1 X94.031 Y145.52 E.20099
G2 X93.95 Y145.055 I-2.366 J.173 E.01489
G1 X89.054 Y149.951 E.21798
G3 X88.634 Y149.825 I.42 J-2.161 E.01384
G1 X93.826 Y144.633 E.23116
G2 X93.666 Y144.246 I-2.009 J.607 E.01319
G1 X88.249 Y149.664 E.2412
G3 X87.894 Y149.472 I.78 J-1.867 E.01271
G1 X93.474 Y143.892 E.24845
G2 X93.253 Y143.566 I-1.723 J.929 E.01241
G1 X87.568 Y149.252 E.25316
G3 X87.268 Y149.005 I1.082 J-1.62 E.01224
G1 X93.006 Y143.267 E.25548
G2 X92.732 Y142.995 I-1.498 J1.23 E.01218
G1 X86.994 Y148.733 E.25548
G3 X86.747 Y148.434 I1.366 J-1.383 E.01224
G1 X92.432 Y142.748 E.25316
G2 X92.106 Y142.528 I-1.262 J1.521 E.01241
G1 X86.526 Y148.108 E.24844
G3 X86.334 Y147.753 I1.677 J-1.136 E.01271
G1 X91.751 Y142.336 E.24119
G2 X91.366 Y142.175 I-.998 J1.849 E.01317
G1 X86.174 Y147.367 E.23116
G3 X86.05 Y146.945 I2.049 J-.832 E.01388
G1 X90.945 Y142.049 E.21798
G2 X90.483 Y141.966 I-1.798 J8.612 E.0148
G1 X85.969 Y146.48 E.20099
G3 X85.941 Y145.961 I2.578 J-.398 E.01638
G1 X89.964 Y141.938 E.17914
G2 X89.365 Y141.99 I.137 J5.016 E.01894
G1 X85.986 Y145.369 E.15046
G3 X86.173 Y144.636 I3.754 J.565 E.02385
G1 X88.633 Y142.176 E.10955
G2 X87.278 Y142.985 I1.437 J3.948 E.04999
G1 X86.287 Y143.975 E.0441
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X87.278 Y142.985 E-.5323
G1 X87.628 Y142.7 E-.17134
G1 X87.752 Y142.62 E-.05636
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/23
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z.8 I-.028 J1.217 P1  F30000
G1 X161.942 Y144.32 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X162.03 Y144.088 E.00822
G3 X165.672 Y141.615 I3.96 J1.912 E.15295
G3 X166.194 Y141.608 I.322 J4.752 E.01735
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X161.859 Y144.493 I-.205 J4.392 E.73156
G1 X161.916 Y144.374 E.00437
M204 S250
G1 X161.576 Y144.168 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X161.58 Y144.137 E.00097
G3 X165.404 Y141.247 I4.412 J1.863 E.15425
G3 X166.214 Y141.216 I.669 J6.887 E.0249
G3 X161.416 Y144.586 I-.222 J4.784 E.7307
G1 X161.554 Y144.224 E.01191
; WIPE_START
M204 S10000
G1 X161.58 Y144.137 E-.03454
G1 X161.793 Y143.709 E-.18157
G1 X162.042 Y143.302 E-.18142
G1 X162.331 Y142.921 E-.18155
G1 X162.655 Y142.572 E-.18092
; WIPE_END
G1 E-.04 F1800
G1 X163.979 Y149.716 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42927
M73 P25 R23
G1 F15000
G1 X162.986 Y148.723 E.04422
G3 X162.173 Y147.363 I3.174 J-2.822 E.05017
G1 X164.634 Y149.824 E.10958
G2 X165.366 Y150.01 I1.457 J-4.211 E.0238
G1 X161.986 Y146.63 E.15047
G3 X161.941 Y146.039 I5.299 J-.704 E.01869
G1 X165.961 Y150.059 E.17901
G1 X166.482 Y150.033 E.0164
G1 X161.969 Y145.52 E.20094
G3 X162.05 Y145.055 I2.365 J.173 E.01489
G1 X166.946 Y149.951 E.21798
G2 X167.366 Y149.824 I-.421 J-2.166 E.01384
G1 X162.174 Y144.633 E.23116
G3 X162.334 Y144.246 I2.005 J.605 E.01318
G1 X167.751 Y149.664 E.24119
G2 X168.106 Y149.472 I-.781 J-1.869 E.01271
G1 X162.526 Y143.892 E.24844
G3 X162.747 Y143.566 I1.736 J.938 E.01241
G1 X168.432 Y149.252 E.25315
G2 X168.732 Y149.005 I-1.086 J-1.624 E.01224
G1 X162.994 Y143.267 E.25547
G3 X163.268 Y142.995 I1.501 J1.233 E.01218
G1 X169.006 Y148.733 E.25547
G2 X169.253 Y148.434 I-1.37 J-1.387 E.01224
G1 X163.568 Y142.748 E.25315
G3 X163.894 Y142.528 I1.263 J1.522 E.01241
G1 X169.474 Y148.108 E.24844
G2 X169.666 Y147.753 I-1.667 J-1.131 E.01271
G1 X164.249 Y142.336 E.24119
G3 X164.634 Y142.175 I.996 J1.844 E.01317
G1 X169.826 Y147.367 E.23115
G2 X169.95 Y146.945 I-2.046 J-.831 E.01388
G1 X165.054 Y142.049 E.21797
G3 X165.517 Y141.966 I1.754 J8.383 E.01481
G1 X170.031 Y146.48 E.20098
G2 X170.059 Y145.961 I-2.579 J-.398 E.01638
G1 X166.037 Y141.939 E.17909
G3 X166.634 Y141.99 I-.052 J4.114 E.0189
G1 X170.014 Y145.369 E.15046
G2 X169.827 Y144.637 I-3.753 J.565 E.02385
G1 X167.366 Y142.176 E.10956
G3 X168.689 Y142.953 I-1.329 J3.777 E.04859
G3 X169.713 Y143.976 I-40.831 J41.881 E.04557
; WIPE_START
G1 X168.689 Y142.953 E-.54999
G1 X168.372 Y142.7 E-.15393
G1 X168.248 Y142.62 E-.05608
; WIPE_END
G1 E-.04 F1800
G1 X168.435 Y134.99 Z1 F30000
G1 X169.217 Y103.015 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X165.672 Y101.615 I-3.228 J2.985 E.78564
G3 X166.194 Y101.608 I.322 J4.748 E.01735
G3 X169.176 Y102.971 I-.205 J4.392 E.11145
M204 S250
G1 X169.513 Y102.745 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X169.95 Y103.307 E.02188
G3 X165.404 Y101.247 I-3.959 J2.691 E.76284
G3 X166.214 Y101.216 I.669 J6.882 E.02491
G3 X169.47 Y102.71 I-.222 J4.782 E.11283
; WIPE_START
M204 S10000
G1 X169.95 Y103.307 E-.29114
G1 X170.207 Y103.709 E-.18121
G1 X170.414 Y104.14 E-.18155
G1 X170.509 Y104.402 E-.1061
; WIPE_END
G1 E-.04 F1800
G1 X169.713 Y103.976 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42927
G1 F15000
G2 X168.689 Y102.953 I-41.246 J40.249 E.04557
G2 X167.366 Y102.176 I-2.652 J3.001 E.04859
G1 X169.827 Y104.637 E.10956
G3 X170.014 Y105.369 I-3.567 J1.298 E.02385
G1 X166.634 Y101.99 E.15046
G2 X166.037 Y101.939 I-.65 J4.067 E.0189
G1 X170.059 Y105.961 E.17909
G3 X170.031 Y106.48 I-2.606 J.121 E.01638
G1 X165.517 Y101.966 E.20098
G2 X165.054 Y102.049 I1.291 J8.468 E.01481
G1 X169.95 Y106.945 E.21797
G3 X169.826 Y107.367 I-2.174 J-.41 E.01388
G1 X164.634 Y102.175 E.23116
G2 X164.249 Y102.336 I.61 J2.005 E.01317
G1 X169.666 Y107.753 E.24119
G3 X169.474 Y108.108 I-1.865 J-.78 E.01271
G1 X163.894 Y102.528 E.24844
G2 X163.568 Y102.748 I.936 J1.742 E.01241
G1 X169.253 Y108.434 E.25315
G3 X169.006 Y108.733 I-1.613 J-1.085 E.01224
G1 X163.268 Y102.995 E.25547
G2 X162.994 Y103.267 I1.227 J1.506 E.01218
G1 X168.732 Y109.005 E.25547
G3 X168.432 Y109.252 I-1.382 J-1.374 E.01224
G1 X162.747 Y103.566 E.25315
G2 X162.526 Y103.892 I1.521 J1.267 E.01241
G1 X168.106 Y109.472 E.24844
G3 X167.745 Y109.657 I-.92 J-1.347 E.01281
G1 X162.334 Y104.246 E.24091
G2 X162.174 Y104.633 I1.854 J.996 E.01318
G1 X167.365 Y109.824 E.23112
G3 X166.943 Y109.948 I-.834 J-2.046 E.01387
G1 X162.05 Y105.055 E.21787
G2 X161.969 Y105.52 I2.286 J.639 E.01489
G1 X166.479 Y110.031 E.20083
G3 X165.964 Y110.061 I-.411 J-2.565 E.0163
G1 X161.941 Y106.039 E.1791
G2 X161.986 Y106.63 I5.349 J-.112 E.01869
G1 X165.366 Y110.01 E.15047
G3 X164.634 Y109.824 I.724 J-4.392 E.0238
G1 X162.173 Y107.363 E.10958
G2 X162.986 Y108.723 I3.987 J-1.462 E.05017
G1 X163.979 Y109.716 E.04422
; WIPE_START
G1 X162.986 Y108.723 E-.53379
G1 X162.76 Y108.454 E-.13335
G1 X162.623 Y108.252 E-.09286
; WIPE_END
G1 E-.04 F1800
G1 X155.017 Y107.609 Z1 F30000
G1 X88.269 Y101.961 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.599 Y101.829 E.01177
G3 X89.672 Y101.615 I1.39 J4.171 E.03639
G3 X90.194 Y101.608 I.322 J4.748 E.01735
G3 X88.19 Y101.988 I-.205 J4.392 E.84813
G1 X88.213 Y101.98 E.0008
M204 S250
G1 X88.126 Y101.596 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X88.474 Y101.458 E.0115
G3 X89.404 Y101.247 I1.518 J4.542 E.02936
G3 X90.214 Y101.216 I.669 J6.882 E.02491
G3 X88.029 Y101.632 I-.222 J4.784 E.8556
G1 X88.07 Y101.617 E.00134
; WIPE_START
M204 S10000
G1 X88.474 Y101.458 E-.16497
G1 X88.934 Y101.33 E-.18144
G1 X89.404 Y101.247 E-.18145
G1 X89.881 Y101.212 E-.18151
G1 X90.014 Y101.213 E-.05064
; WIPE_END
G1 E-.04 F1800
G1 X93.713 Y103.976 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42928
G1 F15000
G2 X92.689 Y102.953 I-41.532 J40.536 E.04557
G2 X91.366 Y102.176 I-2.652 J3.002 E.04859
G1 X93.827 Y104.637 E.10956
G3 X94.014 Y105.369 I-3.566 J1.298 E.02385
G1 X90.634 Y101.99 E.15046
G2 X90.037 Y101.939 I-.65 J4.067 E.0189
G1 X94.059 Y105.961 E.17909
G3 X94.031 Y106.48 I-2.605 J.121 E.01638
G1 X89.517 Y101.966 E.20099
G2 X89.054 Y102.049 I1.289 J8.457 E.01481
G1 X93.95 Y106.945 E.21798
G3 X93.826 Y107.367 I-2.171 J-.409 E.01388
G1 X88.634 Y102.175 E.23116
G2 X88.249 Y102.336 I.61 J2.005 E.01317
G1 X93.666 Y107.754 E.24119
G3 X93.474 Y108.108 I-1.873 J-.785 E.01271
G1 X87.894 Y102.528 E.24845
G2 X87.568 Y102.748 I.935 J1.74 E.01241
G1 X93.253 Y108.434 E.25316
G3 X93.006 Y108.733 I-1.62 J-1.09 E.01224
G1 X87.268 Y102.995 E.25548
G2 X86.994 Y103.267 I1.226 J1.504 E.01218
G1 X92.732 Y109.005 E.25548
G3 X92.432 Y109.252 I-1.383 J-1.375 E.01224
G1 X86.747 Y103.566 E.25316
G2 X86.526 Y103.892 I1.524 J1.27 E.01241
G1 X92.106 Y109.472 E.24845
G3 X91.745 Y109.657 I-.921 J-1.349 E.01281
G1 X86.334 Y104.247 E.24091
G2 X86.174 Y104.633 I1.849 J.993 E.01319
G1 X91.365 Y109.824 E.23112
G3 X90.943 Y109.948 I-.834 J-2.046 E.01387
G1 X86.05 Y105.055 E.21787
G2 X85.969 Y105.52 I2.284 J.638 E.01489
G1 X90.479 Y110.031 E.20083
G3 X89.963 Y110.061 I-.41 J-2.564 E.0163
G1 X85.941 Y106.039 E.1791
G2 X85.986 Y106.631 I5.344 J-.112 E.01869
G1 X89.365 Y110.01 E.15046
G3 X88.633 Y109.824 I.723 J-4.388 E.02381
G1 X86.173 Y107.364 E.10956
G2 X86.987 Y108.725 I3.99 J-1.464 E.05023
G1 X87.979 Y109.716 E.04414
; WIPE_START
G1 X86.987 Y108.725 E-.53274
G1 X86.76 Y108.454 E-.1342
G1 X86.622 Y108.252 E-.09306
; WIPE_END
G1 E-.04 F1800
G1 X88.162 Y115.727 Z1 F30000
G1 X94.038 Y144.263 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X94.043 Y144.296 E.00109
G3 X89.672 Y141.615 I-4.053 J1.704 E.73482
G3 X90.194 Y141.608 I.322 J4.752 E.01735
G3 X93.744 Y143.712 I-.205 J4.392 E.14248
G1 X94.01 Y144.21 E.01874
M204 S250
G1 X94.388 Y144.085 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X94.406 Y144.143 E.00185
G3 X89.404 Y141.247 I-4.414 J1.857 E.73394
G3 X90.214 Y141.216 I.669 J6.887 E.0249
G3 X94.199 Y143.713 I-.222 J4.784 E.15105
G1 X94.361 Y144.032 E.01098
M204 S10000
G1 X93.713 Y143.976 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42928
G1 F15000
G2 X92.689 Y142.953 I-41.377 J40.381 E.04557
G2 X91.366 Y142.176 I-2.652 J3.001 E.04859
G1 X93.827 Y144.637 E.10956
G3 X94.014 Y145.369 I-3.568 J1.298 E.02385
G1 X90.634 Y141.99 E.15046
G2 X90.037 Y141.939 I-.65 J4.064 E.0189
G1 X94.059 Y145.961 E.17909
G3 X94.025 Y146.473 I-2.058 J.119 E.0162
G1 X89.517 Y141.966 E.20069
G2 X89.054 Y142.049 I1.29 J8.463 E.01481
G1 X93.948 Y146.943 E.2179
G3 X93.823 Y147.364 I-2.168 J-.416 E.01385
G1 X88.634 Y142.176 E.23103
G2 X88.249 Y142.336 I.61 J2.004 E.01317
G1 X93.662 Y147.75 E.24104
G3 X93.471 Y148.105 I-1.867 J-.78 E.01272
G1 X87.894 Y142.528 E.2483
G2 X87.568 Y142.748 I.936 J1.741 E.01241
G1 X93.251 Y148.431 E.25304
G3 X93.004 Y148.731 I-1.62 J-1.084 E.01224
G1 X87.268 Y142.995 E.25539
G2 X86.994 Y143.267 I1.225 J1.503 E.01218
G1 X92.731 Y149.004 E.25542
G3 X92.432 Y149.251 I-1.385 J-1.372 E.01224
G1 X86.747 Y143.566 E.25312
G2 X86.526 Y143.892 I1.515 J1.263 E.01241
G1 X92.105 Y149.471 E.24842
G3 X91.751 Y149.663 I-1.135 J-1.675 E.01271
G1 X86.334 Y144.247 E.24117
G2 X86.174 Y144.633 I1.861 J.998 E.01318
G1 X91.365 Y149.824 E.23112
G3 X90.943 Y149.948 I-.834 J-2.045 E.01387
G1 X86.05 Y145.055 E.21787
G2 X85.969 Y145.52 I2.288 J.639 E.01489
G1 X90.479 Y150.031 E.20083
G3 X89.963 Y150.061 I-.41 J-2.565 E.0163
G1 X85.941 Y146.039 E.17909
G2 X85.986 Y146.631 I5.345 J-.112 E.0187
G1 X89.365 Y150.01 E.15046
G3 X88.633 Y149.824 I.724 J-4.392 E.02381
G1 X86.173 Y147.364 E.10956
G2 X86.987 Y148.725 I3.99 J-1.464 E.05023
G1 X87.979 Y149.716 E.04414
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X86.987 Y148.725 E-.53275
G1 X86.76 Y148.454 E-.13418
G1 X86.622 Y148.252 E-.09307
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 4/23
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1 I.063 J1.215 P1  F30000
G1 X161.933 Y144.341 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F6613
G1 X162.03 Y144.088 E.009
G3 X165.672 Y141.615 I3.959 J1.911 E.15294
G3 X166.234 Y141.61 I.321 J4.702 E.01867
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X161.859 Y144.493 I-.244 J4.39 E.73019
G1 X161.906 Y144.395 E.00359
M204 S250
G1 X161.568 Y144.189 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6613
M204 S5000
G1 X161.58 Y144.137 E.00163
G3 X165.404 Y141.247 I4.412 J1.863 E.15425
G3 X166.254 Y141.218 I.65 J6.58 E.02613
G3 X161.416 Y144.586 I-.262 J4.782 E.72944
G1 X161.547 Y144.245 E.01123
; WIPE_START
G1 F12000
M204 S10000
G1 X161.58 Y144.137 E-.04285
G1 X161.793 Y143.709 E-.18167
G1 X162.182 Y143.108 E-.27209
G1 X162.489 Y142.742 E-.18134
G1 X162.643 Y142.591 E-.08206
; WIPE_END
G1 E-.04 F1800
G1 X163.892 Y149.453 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6613
G2 X165.413 Y149.994 I2.053 J-3.357 E.05396
G1 X170.005 Y145.403 E.21539
G2 X169.877 Y144.849 I-5.95 J1.077 E.01885
G1 X167.15 Y142.123 E.12792
G2 X165.77 Y141.962 I-1.14 J3.781 E.04634
G1 X161.958 Y145.773 E.17881
G3 X162.141 Y144.789 I4.269 J.285 E.03327
G1 X167.212 Y149.86 E.23788
G2 X168.627 Y149.078 I-1.262 J-3.952 E.05398
; WIPE_START
G1 F15476.087
G1 X168.025 Y149.507 E-.28098
G1 X167.212 Y149.86 E-.33674
G1 X166.947 Y149.595 E-.14228
; WIPE_END
G1 E-.04 F1800
G1 X167.319 Y141.972 Z1.2 F30000
G1 X169.217 Y103.014 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6613
G3 X165.672 Y101.615 I-3.228 J2.985 E.78558
G3 X166.234 Y101.61 I.321 J4.702 E.01867
G3 X169.176 Y102.971 I-.244 J4.39 E.11014
M204 S250
G1 X169.512 Y102.743 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6613
M204 S5000
G1 X169.951 Y103.306 E.02194
G3 X165.404 Y101.247 I-3.959 J2.693 E.7632
G3 X166.254 Y101.218 I.65 J6.578 E.02613
G3 X169.47 Y102.708 I-.262 J4.782 E.11157
M204 S10000
G1 X168.627 Y102.922 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6613
G2 X167.212 Y102.14 I-2.677 J3.17 E.05398
G1 X162.138 Y107.214 E.23803
G3 X161.967 Y106.236 I8.059 J-1.911 E.03296
G1 X165.771 Y110.04 E.17845
G2 X167.15 Y109.878 I.048 J-5.533 E.04618
G1 X169.877 Y107.151 E.12792
G2 X170.005 Y106.597 I-5.816 J-1.629 E.01885
G1 X165.406 Y101.998 E.21573
G2 X163.887 Y102.551 I.618 J4.064 E.05398
; WIPE_START
G1 F15476.087
G1 X164.711 Y102.162 E-.34625
G1 X165.406 Y101.998 E-.27141
G1 X165.671 Y102.263 E-.14235
; WIPE_END
G1 E-.04 F1800
G1 X158.038 Y102.232 Z1.2 F30000
G1 X88.302 Y101.948 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6613
G1 X88.599 Y101.829 E.01061
G3 X89.672 Y101.615 I1.391 J4.171 E.03638
G3 X90.234 Y101.61 I.321 J4.702 E.01867
G3 X88.19 Y101.988 I-.244 J4.39 E.84676
G1 X88.245 Y101.968 E.00196
M204 S250
G1 X88.159 Y101.583 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6613
M204 S5000
G1 X88.474 Y101.458 E.01043
G3 X89.404 Y101.247 I1.518 J4.542 E.02935
G3 X90.254 Y101.218 I.65 J6.578 E.02613
G3 X88.029 Y101.632 I-.262 J4.782 E.85442
G1 X88.103 Y101.604 E.00241
; WIPE_START
G1 F12000
M204 S10000
G1 X88.474 Y101.458 E-.15176
G1 X88.934 Y101.33 E-.18135
G1 X89.404 Y101.247 E-.18147
G1 X89.881 Y101.212 E-.18151
G1 X90.049 Y101.215 E-.06392
; WIPE_END
G1 E-.04 F1800
G1 X92.113 Y102.551 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6613
G2 X90.594 Y101.998 I-2.136 J3.51 E.05398
G1 X85.995 Y106.597 E.21573
G2 X86.121 Y107.149 I2.257 J-.224 E.01883
G1 X88.853 Y109.881 E.12816
G2 X90.23 Y110.038 I1.155 J-4.004 E.04619
G1 X94.042 Y106.227 E.17881
M73 P25 R22
G3 X93.859 Y107.211 I-4.268 J-.285 E.03328
G1 X88.788 Y102.14 E.23788
G2 X87.373 Y102.922 I1.261 J3.952 E.05398
; WIPE_START
G1 F15476.087
G1 X87.975 Y102.493 E-.28101
G1 X88.788 Y102.14 E-.33671
G1 X89.053 Y102.405 E-.14228
; WIPE_END
G1 E-.04 F1800
G1 X89.959 Y109.983 Z1.2 F30000
G1 X94.067 Y144.331 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6613
G1 X94.192 Y144.707 E.01314
G3 X89.672 Y141.615 I-4.202 J1.293 E.72025
G3 X90.234 Y141.61 I.321 J4.702 E.01867
G3 X94.036 Y144.28 I-.244 J4.39 E.16237
M204 S250
G1 X94.435 Y144.197 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6613
M204 S5000
G1 X94.568 Y144.591 E.01277
G3 X89.404 Y141.247 I-4.577 J1.409 E.71924
G3 X90.254 Y141.218 I.65 J6.58 E.02613
G3 X94.406 Y144.143 I-.262 J4.782 E.16448
G1 X94.407 Y144.144 E.00006
; WIPE_START
G1 F12000
M204 S10000
G1 X94.568 Y144.591 E-.18046
G1 X94.695 Y145.051 E-.18118
G1 X94.766 Y145.523 E-.18153
G1 X94.79 Y146 E-.18148
G1 X94.785 Y146.093 E-.03535
; WIPE_END
G1 E-.04 F1800
G1 X87.705 Y148.944 Z1.2 F30000
G1 X87.375 Y149.077 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6613
G2 X88.789 Y149.859 I2.643 J-3.107 E.05397
G1 X93.859 Y144.789 E.23784
G3 X94.042 Y145.773 I-4.085 J1.268 E.03328
G1 X90.227 Y141.959 E.17895
G2 X88.85 Y142.123 I-.197 J4.218 E.04622
G1 X86.123 Y144.849 E.12792
G2 X85.995 Y145.403 I5.809 J1.628 E.01886
G1 X90.594 Y150.002 E.21573
G2 X92.113 Y149.449 I-.618 J-4.064 E.05398
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X91.289 Y149.838 E-.34623
G1 X90.594 Y150.002 E-.27142
G1 X90.329 Y149.737 E-.14235
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/23
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.2 I.091 J1.214 P1  F30000
G1 X161.924 Y144.362 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6717
G1 X162.032 Y144.089 E.00974
G3 X165.671 Y141.615 I3.96 J1.91 E.15288
G3 X166.274 Y141.612 I.323 J4.764 E.02
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X161.862 Y144.494 I-.281 J4.388 E.72895
G1 X161.898 Y144.416 E.00284
M204 S250
G1 X161.563 Y144.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6717
M204 S5000
G1 X161.678 Y143.919 E.00962
G3 X165.642 Y141.223 I4.313 J2.081 E.15426
G3 X166.293 Y141.22 I.351 J5.177 E.02003
G3 X161.492 Y144.359 I-.302 J4.779 E.73558
G1 X161.537 Y144.264 E.00323
; WIPE_START
G1 F12000
M204 S10000
G1 X161.678 Y143.919 E-.14173
G1 X161.913 Y143.502 E-.18172
G1 X162.182 Y143.108 E-.18135
G1 X162.489 Y142.742 E-.18145
G1 X162.628 Y142.607 E-.07376
; WIPE_END
G1 E-.04 F1800
G1 X167.817 Y148.204 Z1.4 F30000
G1 X168.627 Y149.078 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6717
G3 X167.212 Y149.86 I-2.676 J-3.169 E.05398
G1 X162.141 Y144.789 E.23788
G2 X161.958 Y145.773 I4.084 J1.268 E.03327
G1 X165.77 Y141.962 E.17881
G3 X167.15 Y142.123 I.247 J3.89 E.04635
G1 X169.877 Y144.849 E.12792
G3 X170.005 Y145.403 I-5.824 J1.631 E.01885
G1 X165.413 Y149.994 E.21539
G3 X163.892 Y149.453 I.531 J-3.899 E.05396
; WIPE_START
G1 F15476.087
G1 X164.71 Y149.838 E-.34389
G1 X165.413 Y149.994 E-.27359
G1 X165.678 Y149.729 E-.14252
; WIPE_END
G1 E-.04 F1800
G1 X166.255 Y142.119 Z1.4 F30000
G1 X169.219 Y103.013 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6717
G3 X165.671 Y101.615 I-3.227 J2.987 E.78555
G3 X166.274 Y101.612 I.323 J4.764 E.02
G3 X169.178 Y102.969 I-.281 J4.388 E.10886
M204 S250
G1 X169.506 Y102.747 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6717
M204 S5000
G3 X165.642 Y101.223 I-3.515 J3.253 E.79256
G3 X166.293 Y101.22 I.351 J5.176 E.02003
G3 X169.465 Y102.703 I-.302 J4.779 E.11014
; WIPE_START
G1 F12000
M204 S10000
G1 X169.958 Y103.302 E-.29459
G1 X170.207 Y103.71 E-.18156
G1 X170.414 Y104.14 E-.18136
G1 X170.506 Y104.393 E-.10249
; WIPE_END
G1 E-.04 F1800
G1 X163.887 Y102.551 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6717
G3 X165.406 Y101.998 I2.137 J3.511 E.05398
G1 X170.005 Y106.597 E.21574
G3 X169.877 Y107.151 I-5.955 J-1.079 E.01886
G1 X167.15 Y109.877 E.12792
G3 X165.771 Y110.04 I-1.331 J-5.369 E.04618
G1 X161.958 Y106.227 E.17887
G2 X162.141 Y107.211 I4.269 J-.285 E.03327
G1 X167.212 Y102.14 E.23788
G3 X168.627 Y102.922 I-1.261 J3.952 E.05398
; WIPE_START
G1 F15476.087
G1 X168.025 Y102.493 E-.281
G1 X167.212 Y102.14 E-.33672
G1 X166.947 Y102.405 E-.14228
; WIPE_END
G1 E-.04 F1800
G1 X159.315 Y102.359 Z1.4 F30000
G1 X88.333 Y101.936 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6717
G1 X88.599 Y101.83 E.00949
G3 X89.671 Y101.615 I1.394 J4.17 E.03639
G3 X90.274 Y101.612 I.323 J4.764 E.02
G3 X88.19 Y101.989 I-.281 J4.388 E.84546
G1 X88.277 Y101.957 E.00306
M204 S250
G1 X88.189 Y101.569 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6717
M204 S5000
G1 X88.249 Y101.539 E.00205
G3 X89.642 Y101.223 I1.742 J4.461 E.04405
G3 X90.293 Y101.22 I.351 J5.176 E.02003
G3 X87.813 Y101.735 I-.302 J4.779 E.84579
G1 X88.135 Y101.593 E.0108
; WIPE_START
G1 F12000
M204 S10000
G1 X88.249 Y101.539 E-.04813
G1 X88.703 Y101.389 E-.18153
G1 X89.168 Y101.283 E-.18143
G1 X89.642 Y101.223 E-.18147
G1 X90.083 Y101.221 E-.16745
; WIPE_END
G1 E-.04 F1800
G1 X87.373 Y102.922 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6717
G3 X88.788 Y102.14 I2.676 J3.169 E.05398
G1 X93.859 Y107.211 E.23788
G2 X94.042 Y106.227 I-4.085 J-1.268 E.03328
G1 X90.23 Y110.038 E.17881
G3 X88.853 Y109.881 I-.222 J-4.16 E.04619
G1 X86.119 Y107.147 E.12827
G3 X86 Y106.593 I2.709 J-.873 E.01883
G1 X90.594 Y101.998 E.21554
G3 X92.113 Y102.551 I-.618 J4.064 E.05398
; WIPE_START
G1 F15476.087
G1 X91.29 Y102.162 E-.34616
G1 X90.594 Y101.998 E-.27149
G1 X90.329 Y102.263 E-.14235
; WIPE_END
G1 E-.04 F1800
G1 X91.011 Y109.865 Z1.4 F30000
G1 X94.115 Y144.453 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6717
G1 X94.125 Y144.499 E.00154
G3 X89.671 Y141.615 I-4.133 J1.501 E.72745
G3 X90.274 Y141.612 I.323 J4.764 E.02
G3 X93.955 Y144.095 I-.281 J4.388 E.15441
G1 X94.09 Y144.398 E.01102
M204 S250
G1 X94.476 Y144.301 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6717
M204 S5000
G1 X94.493 Y144.365 E.00203
G3 X89.642 Y141.223 I-4.501 J1.635 E.73394
G3 X90.293 Y141.22 I.351 J5.177 E.02003
G3 X94.308 Y143.925 I-.302 J4.779 E.15593
G1 X94.451 Y144.246 E.01081
; WIPE_START
G1 F12000
M204 S10000
G1 X94.493 Y144.365 E-.04772
G1 X94.642 Y144.818 E-.18134
G1 X94.736 Y145.286 E-.18148
G1 X94.79 Y146 E-.27202
G1 X94.78 Y146.204 E-.07745
; WIPE_END
G1 E-.04 F1800
G1 X92.113 Y149.449 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6717
G3 X90.594 Y150.002 I-2.137 J-3.512 E.05398
G1 X85.995 Y145.403 E.21573
G3 X86.123 Y144.849 I5.94 J1.075 E.01886
G1 X88.85 Y142.123 E.12792
G3 X90.227 Y141.959 I1.345 J5.45 E.04614
G1 X94.042 Y145.773 E.17894
G2 X93.859 Y144.789 I-4.267 J.284 E.03328
G1 X88.788 Y149.86 E.23788
G3 X87.373 Y149.078 I1.261 J-3.951 E.05398
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X87.975 Y149.507 E-.28097
G1 X88.788 Y149.86 E-.33675
G1 X89.053 Y149.595 E-.14228
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 6/23
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.4 I.087 J1.214 P1  F30000
G1 X161.923 Y144.358 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6603
G1 X161.944 Y144.29 E.00237
G3 X165.89 Y141.604 I4.05 J1.707 E.16741
G3 X166.3 Y141.613 I.11 J4.113 E.01361
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X161.794 Y144.703 I-.307 J4.384 E.72041
G1 X161.902 Y144.415 E.01021
M204 S250
G1 X161.555 Y144.224 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6603
M204 S5000
G1 X161.582 Y144.138 E.00279
G3 X165.88 Y141.212 I4.411 J1.859 E.1689
G3 X166.329 Y141.222 I.12 J4.495 E.01378
G3 X161.419 Y144.587 I-.335 J4.775 E.72679
G1 X161.534 Y144.281 E.01005
; WIPE_START
G1 F12000
M204 S10000
G1 X161.582 Y144.138 E-.05733
G1 X161.793 Y143.709 E-.18145
G1 X162.042 Y143.302 E-.18149
M73 P26 R22
G1 X162.331 Y142.921 E-.1815
G1 X162.614 Y142.616 E-.15824
; WIPE_END
G1 E-.04 F1800
G1 X163.892 Y149.453 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6603
G2 X165.413 Y149.994 I2.053 J-3.357 E.05396
G1 X170.005 Y145.403 E.21539
G2 X169.877 Y144.849 I-5.941 J1.075 E.01885
G1 X167.15 Y142.123 E.12792
G2 X165.77 Y141.962 I-1.13 J3.693 E.04635
G1 X161.958 Y145.773 E.17881
G3 X162.141 Y144.789 I4.266 J.284 E.03327
G1 X167.212 Y149.86 E.23788
G2 X168.627 Y149.078 I-1.261 J-3.952 E.05398
; WIPE_START
G1 F15476.087
G1 X168.024 Y149.507 E-.28105
G1 X167.212 Y149.86 E-.33667
G1 X166.947 Y149.595 E-.14228
; WIPE_END
G1 E-.03999 F1800
G1 X167.319 Y141.972 Z1.6 F30000
G1 X169.219 Y103.013 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6603
G3 X165.89 Y101.604 I-3.226 J2.985 E.79241
G3 X166.3 Y101.613 I.11 J4.114 E.01361
G3 X169.178 Y102.969 I-.307 J4.384 E.10799
M204 S250
G1 X169.507 Y102.746 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6603
M204 S5000
G3 X165.881 Y101.212 I-3.514 J3.251 E.79947
G3 X166.329 Y101.222 I.119 J4.497 E.01377
G3 X169.466 Y102.702 I-.335 J4.775 E.10907
M204 S10000
G1 X168.627 Y102.922 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6603
G2 X167.212 Y102.14 I-2.676 J3.169 E.05398
G1 X162.141 Y107.211 E.23788
G3 X161.958 Y106.227 I4.084 J-1.268 E.03327
G1 X165.771 Y110.04 E.17888
G2 X167.15 Y109.877 I.048 J-5.531 E.04618
G1 X169.877 Y107.151 E.12792
G2 X170.005 Y106.597 I-5.821 J-1.63 E.01885
G1 X165.406 Y101.998 E.21573
G2 X163.887 Y102.551 I.618 J4.065 E.05398
; WIPE_START
G1 F15476.087
G1 X164.711 Y102.162 E-.34629
G1 X165.406 Y101.998 E-.27137
G1 X165.671 Y102.263 E-.14234
; WIPE_END
G1 E-.04 F1800
G1 X158.038 Y102.23 Z1.6 F30000
G1 X88.359 Y101.926 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6603
G1 X88.599 Y101.83 E.00859
G3 X89.89 Y101.604 I1.395 J4.168 E.04365
G3 X90.3 Y101.613 I.11 J4.114 E.01361
G3 X88.19 Y101.989 I-.307 J4.384 E.84418
G1 X88.303 Y101.947 E.00398
M204 S250
G1 X88.216 Y101.557 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6603
M204 S5000
G1 X88.249 Y101.539 E.00116
G3 X89.881 Y101.212 I1.744 J4.458 E.05139
G3 X90.329 Y101.222 I.119 J4.497 E.01377
G3 X87.814 Y101.735 I-.335 J4.775 E.84432
G1 X88.161 Y101.581 E.01167
; WIPE_START
G1 F12000
M204 S10000
G1 X88.249 Y101.539 E-.03719
G1 X88.934 Y101.33 E-.27209
G1 X89.404 Y101.247 E-.18144
G1 X89.881 Y101.212 E-.18151
G1 X90.112 Y101.217 E-.08777
; WIPE_END
G1 E-.04 F1800
G1 X92.113 Y102.551 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6603
G2 X90.594 Y101.998 I-2.137 J3.512 E.05398
G1 X85.995 Y106.597 E.21573
G2 X86.118 Y107.146 I7.395 J-1.363 E.01866
G1 X88.853 Y109.881 E.12831
G2 X90.23 Y110.038 I1.155 J-4.003 E.04619
G1 X94.042 Y106.227 E.17881
G3 X93.859 Y107.211 I-4.268 J-.284 E.03328
G1 X88.788 Y102.14 E.23788
G2 X87.373 Y102.922 I1.261 J3.951 E.05398
; WIPE_START
G1 F15476.087
G1 X87.975 Y102.493 E-.28101
G1 X88.788 Y102.14 E-.33671
G1 X89.053 Y102.405 E-.14228
; WIPE_END
G1 E-.04 F1800
G1 X89.967 Y109.982 Z1.6 F30000
G1 X94.134 Y144.5 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6603
G1 X94.254 Y144.917 E.0144
G3 X89.89 Y141.604 I-4.26 J1.08 E.71978
G3 X90.3 Y141.613 I.11 J4.113 E.01361
G3 X94.107 Y144.451 I-.307 J4.384 E.16638
M204 S250
G1 X94.508 Y144.384 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6603
M204 S5000
G1 X94.633 Y144.82 E.01394
G3 X89.88 Y141.212 I-4.64 J1.177 E.72619
G3 X90.329 Y141.222 I.12 J4.495 E.01378
G3 X94.481 Y144.331 I-.335 J4.775 E.16846
; WIPE_START
G1 F12000
M204 S10000
G1 X94.633 Y144.82 E-.19457
G1 X94.736 Y145.286 E-.18128
G1 X94.784 Y145.761 E-.18151
G1 X94.784 Y146.239 E-.18142
G1 X94.778 Y146.294 E-.02123
; WIPE_END
G1 E-.04 F1800
G1 X87.634 Y148.979 Z1.6 F30000
G1 X87.375 Y149.077 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6603
G2 X88.789 Y149.859 I2.643 J-3.106 E.05397
G1 X93.859 Y144.789 E.23784
G3 X94.042 Y145.773 I-4.085 J1.268 E.03328
G1 X90.228 Y141.96 E.1789
G2 X88.85 Y142.123 I-.041 J5.57 E.04616
G1 X86.123 Y144.849 E.12792
G2 X85.995 Y145.403 I5.814 J1.629 E.01886
G1 X90.594 Y150.002 E.21573
G2 X92.113 Y149.449 I-.618 J-4.063 E.05398
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X91.29 Y149.838 E-.34607
G1 X90.594 Y150.002 E-.27158
G1 X90.329 Y149.737 E-.14235
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/23
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.6 I-.471 J-1.122 P1  F30000
G1 X81.354 Y153.503 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X78.401 Y150.549 E.13855
G3 X77.472 Y148.571 I2.319 J-2.296 E.07392
G1 X73.701 Y108.032 E1.35055
G3 X74.027 Y106.293 I3.277 J-.286 E.05943
G1 X77.113 Y100.12 E.22895
G3 X78.124 Y98.937 I2.968 J1.513 E.05209
G1 X83.353 Y95.202 E.21317
G3 X85.226 Y94.602 I1.871 J2.62 E.06627
G1 X170.777 Y94.602 E2.83791
G3 X172.646 Y95.202 I-.002 J3.219 E.06616
G1 X177.876 Y98.937 E.21318
G3 X178.887 Y100.12 I-1.958 J2.697 E.05209
G1 X181.973 Y106.293 E.22893
G3 X182.299 Y108.032 I-2.95 J1.454 E.05944
G1 X178.528 Y148.571 E1.35057
G3 X177.599 Y150.549 I-3.248 J-.318 E.07392
G1 X171.692 Y156.456 E.27711
G3 X169.418 Y157.398 I-2.287 J-2.305 E.08375
G1 X86.581 Y157.398 E2.74785
G3 X84.308 Y156.456 I.013 J-3.247 E.08373
G1 X81.397 Y153.545 E.13656
M204 S250
G1 X81.077 Y153.78 F30000
G1 F600
M204 S5000
G1 X78.12 Y150.823 E.13871
G3 X77.082 Y148.612 I2.606 J-2.573 E.0826
G1 X73.31 Y108.064 E1.35088
G3 X73.674 Y106.121 I3.677 J-.316 E.06636
G1 X76.765 Y99.94 E.22925
G3 X77.892 Y98.621 I3.327 J1.701 E.0581
G1 X83.129 Y94.88 E.21348
G3 X85.221 Y94.21 I2.096 J2.942 E.07402
G1 X170.782 Y94.21 E2.83823
G3 X172.871 Y94.88 I-.006 J3.611 E.07393
G1 X178.108 Y98.621 E.21349
G3 X179.235 Y99.94 I-2.2 J3.022 E.0581
G1 X182.326 Y106.121 E.22923
G3 X182.69 Y108.064 I-3.312 J1.627 E.06638
G1 X178.918 Y148.612 E1.35088
G3 X177.88 Y150.823 I-3.644 J-.362 E.0826
G1 X171.966 Y156.737 E.27743
G3 X169.423 Y157.79 I-2.563 J-2.591 E.09363
G1 X86.577 Y157.79 E2.74817
G3 X84.034 Y156.737 I.02 J-3.644 E.09363
G1 X81.119 Y153.822 E.13672
; WIPE_START
M204 S10000
G1 X79.705 Y152.408 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.289 J1.182 P1  F30000
G1 X92.05 Y149.396 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
G1 F15476.087
G3 X90.526 Y149.933 I-2.103 J-3.533 E.05398
G1 X86.068 Y145.476 E.20912
G3 X86.243 Y144.729 I4.874 J.749 E.02546
G1 X88.735 Y142.237 E.11689
G1 X88.972 Y142.171 E.00817
G3 X90.313 Y142.045 I1.046 J3.931 E.04489
G1 X93.953 Y145.685 E.17076
G2 X93.795 Y144.853 I-4.024 J.332 E.02814
G1 X88.852 Y149.796 E.23188
G3 X87.433 Y149.022 I1.164 J-3.826 E.05401
; WIPE_START
G1 X88.103 Y149.483 E-.30928
G1 X88.852 Y149.796 E-.30842
G1 X89.117 Y149.531 E-.14231
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.649 J-1.03 P1  F30000
G1 X77.016 Y141.91 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42174
G1 F3000
G1 X88.496 Y141.91 E.35436
G2 X87.811 Y142.227 I2.252 J5.761 E.0233
G1 X87.716 Y142.289 E.00351
G1 X77.222 Y142.289 E.32393
G1 X77.257 Y142.668 E.01174
G1 X87.191 Y142.668 E.30664
G2 X86.797 Y143.039 I5.509 J6.234 E.01673
G1 X77.293 Y143.046 E.29339
G1 X77.328 Y143.425 E.01174
G1 X86.482 Y143.425 E.28259
G2 X86.273 Y143.733 I2.847 J2.156 E.0115
G1 X86.235 Y143.804 E.00249
G1 X77.363 Y143.804 E.27386
G1 X77.398 Y144.183 E.01174
G1 X86.038 Y144.183 E.2667
G2 X85.898 Y144.516 I27.451 J11.691 E.01115
G1 X85.884 Y144.562 E.00148
G1 X77.433 Y144.562 E.26087
G1 X77.469 Y144.94 E.01174
G1 X85.769 Y144.94 E.25623
G1 X85.693 Y145.319 E.01193
G1 X77.504 Y145.319 E.25278
G1 X77.539 Y145.698 E.01174
G1 X85.652 Y145.698 E.25042
G2 X85.643 Y146.077 I2.023 J.235 E.01171
G1 X77.574 Y146.077 E.24907
G1 X77.61 Y146.456 E.01174
G1 X85.667 Y146.456 E.24872
G2 X85.724 Y146.835 I2.012 J-.108 E.01184
G1 X77.645 Y146.835 E.24938
G1 X77.68 Y147.213 E.01174
G1 X85.815 Y147.213 E.25111
G2 X85.941 Y147.588 I3.706 J-1.042 E.01222
G1 X77.715 Y147.592 E.25393
G1 X77.751 Y147.971 E.01174
G1 X86.113 Y147.971 E.25815
M73 P27 R22
G2 X86.33 Y148.35 I5.074 J-2.65 E.01347
G1 X77.786 Y148.35 E.26375
G2 X77.831 Y148.729 I3.894 J-.27 E.01178
G1 X86.602 Y148.729 E.27076
G2 X86.946 Y149.108 I3.593 J-2.917 E.0158
G1 X77.914 Y149.108 E.27881
G2 X78.066 Y149.486 I1.599 J-.42 E.01263
G1 X87.386 Y149.486 E.28769
G2 X87.989 Y149.865 I3.674 J-5.183 E.02201
G1 X78.278 Y149.865 E.29976
M73 P28 R22
G2 X78.574 Y150.244 I1.668 J-.996 E.01487
G1 X177.427 Y150.244 E3.05152
G2 X177.73 Y149.866 I-1.373 J-1.408 E.01497
G1 X168.011 Y149.865 E.30001
G2 X168.554 Y149.536 I-3.145 J-5.801 E.01961
G1 X168.616 Y149.486 E.00246
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X177.938 Y149.486 E.28777
G2 X178.078 Y149.108 I-1.454 J-.751 E.0125
G1 X169.054 Y149.108 E.27857
G2 X169.398 Y148.729 I-1.792 J-1.973 E.01582
G1 X178.164 Y148.729 E.2706
G2 X178.214 Y148.35 I-2.55 J-.531 E.01181
G1 X169.671 Y148.35 E.26372
M73 P28 R21
G2 X169.888 Y147.971 I-1.898 J-1.336 E.01349
G1 X178.249 Y147.971 E.25812
G1 X178.285 Y147.592 E.01174
G1 X170.057 Y147.592 E.25398
M73 P29 R21
G1 X170.185 Y147.213 E.01235
G1 X178.32 Y147.213 E.25111
G1 X178.355 Y146.835 E.01174
G1 X170.276 Y146.835 E.24938
G2 X170.333 Y146.456 I-1.868 J-.473 E.01184
G1 X178.39 Y146.456 E.24872
G1 X178.426 Y146.077 E.01174
G1 X170.357 Y146.077 E.24907
G2 X170.356 Y145.775 I-3.359 J-.143 E.00934
G1 X170.348 Y145.698 E.00237
G1 X178.461 Y145.698 E.25042
G1 X178.496 Y145.319 E.01174
G1 X170.307 Y145.319 E.25278
G1 X170.231 Y144.941 E.01193
G1 X178.531 Y144.941 E.25623
G1 X178.567 Y144.562 E.01174
G1 X170.116 Y144.562 E.26087
G2 X169.962 Y144.183 I-2.165 J.657 E.01264
G1 X178.602 Y144.183 E.2667
G1 X178.637 Y143.804 E.01174
G1 X169.765 Y143.804 E.27386
G2 X169.518 Y143.425 I-2.416 J1.308 E.01398
G1 X178.672 Y143.425 E.28259
G1 X178.707 Y143.046 E.01174
G1 X169.209 Y143.046 E.2932
G2 X168.879 Y142.723 I-18.835 J18.918 E.01428
G1 X168.809 Y142.668 E.00274
G1 X178.743 Y142.668 E.30664
G1 X178.778 Y142.289 E.01174
G1 X168.284 Y142.289 E.32393
G2 X167.504 Y141.91 I-2.384 J3.916 E.02681
G1 X178.813 Y141.91 E.34909
G1 X178.848 Y141.531 E.01174
G1 X77.152 Y141.531 E3.13928
G1 X77.116 Y141.152 E.01174
G1 X178.884 Y141.152 E3.14146
G1 X178.919 Y140.774 E.01174
G1 X77.081 Y140.773 E3.14364
G1 X77.046 Y140.395 E.01174
G1 X178.954 Y140.395 E3.14581
G1 X178.989 Y140.016 E.01174
G1 X77.011 Y140.016 E3.14799
G1 X76.975 Y139.637 E.01174
G1 X179.025 Y139.637 E3.15016
G1 X179.06 Y139.258 E.01174
G1 X76.94 Y139.258 E3.15234
G1 X76.905 Y138.879 E.01174
G1 X179.095 Y138.879 E3.15451
G1 X179.13 Y138.501 E.01174
G1 X76.87 Y138.501 E3.15669
G1 X76.834 Y138.122 E.01174
G1 X179.166 Y138.122 E3.15886
G1 X179.201 Y137.743 E.01174
G1 X76.799 Y137.743 E3.16104
G1 X76.764 Y137.364 E.01174
G1 X179.236 Y137.364 E3.16322
G1 X179.271 Y136.985 E.01174
G1 X76.729 Y136.985 E3.16539
G1 X76.693 Y136.606 E.01174
G1 X179.307 Y136.607 E3.16757
G1 X179.342 Y136.228 E.01174
G1 X76.658 Y136.228 E3.16974
M73 P30 R21
G1 X76.623 Y135.849 E.01174
G1 X179.377 Y135.849 E3.17192
G1 X179.412 Y135.47 E.01174
G1 X76.588 Y135.47 E3.17409
G1 X76.552 Y135.091 E.01174
G1 X179.448 Y135.091 E3.17627
G1 X179.483 Y134.712 E.01174
G1 X76.517 Y134.712 E3.17844
G1 X76.482 Y134.334 E.01174
G1 X179.518 Y134.334 E3.18062
G1 X179.553 Y133.955 E.01174
G1 X76.447 Y133.955 E3.1828
G1 X76.412 Y133.576 E.01174
G1 X179.588 Y133.576 E3.18497
G1 X179.624 Y133.197 E.01174
G1 X76.376 Y133.197 E3.18715
G1 X76.341 Y132.818 E.01174
G1 X179.659 Y132.818 E3.18932
G1 X179.694 Y132.44 E.01174
G1 X76.306 Y132.439 E3.1915
G1 X76.271 Y132.061 E.01174
G1 X179.729 Y132.061 E3.19367
G1 X179.765 Y131.682 E.01174
G1 X76.235 Y131.682 E3.19585
G1 X76.2 Y131.303 E.01174
G1 X179.8 Y131.303 E3.19803
G1 X179.835 Y130.924 E.01174
G1 X76.165 Y130.924 E3.2002
G1 X76.13 Y130.545 E.01174
G1 X179.87 Y130.545 E3.20238
G1 X179.906 Y130.167 E.01174
G1 X76.094 Y130.167 E3.20455
G1 X76.059 Y129.788 E.01174
G1 X179.941 Y129.788 E3.20673
G1 X179.976 Y129.409 E.01174
G1 X76.024 Y129.409 E3.2089
G1 X75.989 Y129.03 E.01174
G1 X180.011 Y129.03 E3.21108
G1 X180.047 Y128.651 E.01174
G1 X75.953 Y128.651 E3.21325
G1 X75.918 Y128.272 E.01174
G1 X180.082 Y128.272 E3.21543
G1 X180.117 Y127.894 E.01174
G1 X75.883 Y127.894 E3.21761
G1 X75.848 Y127.515 E.01174
G1 X180.152 Y127.515 E3.21978
G1 X180.188 Y127.136 E.01174
G1 X75.812 Y127.136 E3.22196
G1 X75.777 Y126.757 E.01174
G1 X180.223 Y126.757 E3.22413
G1 X180.258 Y126.378 E.01174
G1 X75.742 Y126.378 E3.22631
G1 X75.707 Y125.999 E.01174
G1 X180.293 Y126 E3.22848
G1 X180.328 Y125.621 E.01174
G1 X75.672 Y125.621 E3.23066
G1 X75.636 Y125.242 E.01174
G1 X180.364 Y125.242 E3.23283
G1 X180.399 Y124.863 E.01174
G1 X75.601 Y124.863 E3.23501
G1 X75.566 Y124.484 E.01174
G1 X180.434 Y124.484 E3.23719
G1 X180.469 Y124.105 E.01174
G1 X75.531 Y124.105 E3.23936
G1 X75.495 Y123.727 E.01174
G1 X180.505 Y123.727 E3.24154
G1 X180.54 Y123.348 E.01174
G1 X75.46 Y123.348 E3.24371
G1 X75.425 Y122.969 E.01174
G1 X180.575 Y122.969 E3.24589
G1 X180.61 Y122.59 E.01174
G1 X75.39 Y122.59 E3.24806
G1 X75.354 Y122.211 E.01174
G1 X180.646 Y122.211 E3.25024
G1 X180.681 Y121.833 E.01174
G1 X75.319 Y121.832 E3.25241
G1 X75.284 Y121.454 E.01174
G1 X180.716 Y121.454 E3.25459
G1 X180.751 Y121.075 E.01174
M73 P31 R21
G1 X75.249 Y121.075 E3.25677
G1 X75.213 Y120.696 E.01174
G1 X180.787 Y120.696 E3.25894
G1 X180.822 Y120.317 E.01174
G1 X75.178 Y120.317 E3.26112
G1 X75.143 Y119.938 E.01174
G1 X180.857 Y119.938 E3.26329
G1 X180.892 Y119.56 E.01174
G1 X75.108 Y119.56 E3.26547
G1 X75.072 Y119.181 E.01174
G1 X180.928 Y119.181 E3.26764
G1 X180.963 Y118.802 E.01174
G1 X75.037 Y118.802 E3.26982
G1 X75.002 Y118.423 E.01174
G1 X180.998 Y118.423 E3.27199
G1 X181.033 Y118.044 E.01174
G1 X74.967 Y118.044 E3.27417
G1 X74.932 Y117.665 E.01174
M73 P32 R20
G1 X181.069 Y117.666 E3.27635
G1 X181.104 Y117.287 E.01174
G1 X74.896 Y117.287 E3.27852
G1 X74.861 Y116.908 E.01174
G1 X181.139 Y116.908 E3.2807
G1 X181.174 Y116.529 E.01174
G1 X74.826 Y116.529 E3.28287
G1 X74.791 Y116.15 E.01174
G1 X181.209 Y116.15 E3.28505
G1 X181.245 Y115.771 E.01174
G1 X74.755 Y115.771 E3.28722
G1 X74.72 Y115.393 E.01174
G1 X181.28 Y115.393 E3.2894
G1 X181.315 Y115.014 E.01174
G1 X74.685 Y115.014 E3.29158
G1 X74.65 Y114.635 E.01174
G1 X181.35 Y114.635 E3.29375
G1 X181.386 Y114.256 E.01174
M73 P33 R20
G1 X74.614 Y114.256 E3.29593
G1 X74.579 Y113.877 E.01174
G1 X181.421 Y113.877 E3.2981
G1 X181.456 Y113.499 E.01174
G1 X74.544 Y113.498 E3.30028
G1 X74.509 Y113.12 E.01174
G1 X181.491 Y113.12 E3.30245
G1 X181.527 Y112.741 E.01174
G1 X74.473 Y112.741 E3.30463
G1 X74.438 Y112.362 E.01174
G1 X181.562 Y112.362 E3.3068
G1 X181.597 Y111.983 E.01174
G1 X74.403 Y111.983 E3.30898
G1 X74.368 Y111.604 E.01174
G1 X181.632 Y111.604 E3.31116
G1 X181.668 Y111.226 E.01174
M73 P34 R20
G1 X74.332 Y111.226 E3.31333
G1 X74.297 Y110.847 E.01174
G1 X181.873 Y110.847 E3.32077
; WIPE_START
G1 X179.873 Y110.847 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I1.217 J-.023 P1  F30000
G1 X179.71 Y102.134 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F3000
G1 X168.009 Y102.134 E.36119
G3 X168.615 Y102.513 I-2.29 J4.337 E.02208
G1 X179.709 Y102.513 E.34247
G1 X179.898 Y102.892 E.01307
G1 X169.053 Y102.892 E.33479
G3 X169.357 Y103.222 I-1.57 J1.747 E.01389
G1 X169.397 Y103.27 E.00193
G1 X180.088 Y103.27 E.33
M73 P35 R20
G1 X180.277 Y103.649 E.01307
G1 X169.67 Y103.649 E.32741
G3 X169.789 Y103.849 I-1.023 J.746 E.00718
G1 X169.887 Y104.028 E.00631
G1 X180.466 Y104.028 E.32656
G1 X180.655 Y104.407 E.01307
M73 P35 R19
G1 X170.057 Y104.407 E.32716
G3 X170.185 Y104.786 I-1.83 J.831 E.01237
G1 X180.844 Y104.786 E.32904
G1 X181.033 Y105.164 E.01307
G1 X170.276 Y105.164 E.33207
G3 X170.333 Y105.543 I-1.87 J.474 E.01184
G1 X181.223 Y105.543 E.33615
G1 X181.412 Y105.922 E.01307
G1 X170.357 Y105.922 E.34125
G3 X170.356 Y106.225 I-3.372 J.143 E.00937
G1 X170.349 Y106.301 E.00234
G1 X181.601 Y106.301 E.34735
M73 P36 R19
G3 X181.778 Y106.68 I-1.959 J1.145 E.01292
G1 X170.308 Y106.68 E.35407
G1 X170.231 Y107.059 E.01193
G1 X181.9 Y107.059 E.36021
G3 X181.963 Y107.437 I-1.597 J.46 E.01188
G1 X170.116 Y107.437 E.3657
G3 X170.014 Y107.694 I-1.506 J-.45 E.00855
G1 X169.963 Y107.816 E.00408
G1 X181.976 Y107.816 E.37084
G3 X181.949 Y108.195 I-4.141 J-.098 E.01173
G1 X169.766 Y108.195 E.3761
G3 X169.518 Y108.574 I-2.147 J-1.132 E.01399
G1 X181.914 Y108.574 E.38265
G1 X181.879 Y108.953 E.01174
G1 X169.21 Y108.953 E.39108
G3 X168.88 Y109.276 I-18.684 J-18.742 E.01426
G1 X168.81 Y109.331 E.00275
G1 X181.844 Y109.331 E.40233
M73 P37 R19
G1 X181.809 Y109.71 E.01174
G1 X168.286 Y109.71 E.41743
G3 X167.507 Y110.089 I-2.381 J-3.906 E.02678
G1 X181.773 Y110.089 E.4404
G1 X181.738 Y110.468 E.01174
G1 X74.262 Y110.468 E3.31768
G1 X74.227 Y110.089 E.01174
G1 X88.49 Y110.089 E.44031
G3 X87.771 Y109.744 I1.672 J-4.41 E.02467
G1 X87.713 Y109.71 E.00208
G1 X74.192 Y109.71 E.41738
G1 X74.156 Y109.331 E.01174
G1 X87.19 Y109.331 E.40235
G3 X86.796 Y108.953 I1.696 J-2.16 E.01691
G1 X74.121 Y108.953 E.39127
G1 X74.086 Y108.574 E.01174
M73 P38 R19
G1 X86.484 Y108.574 E.38272
G3 X86.284 Y108.275 I1.398 J-1.15 E.01112
G1 X86.235 Y108.195 E.00289
G1 X74.051 Y108.195 E.37613
G3 X74.024 Y107.816 I4.125 J-.477 E.01173
G1 X86.039 Y107.816 E.37088
G3 X85.887 Y107.437 I1.911 J-.988 E.01262
G1 X74.036 Y107.437 E.36582
G3 X74.103 Y107.058 I2.071 J.169 E.01189
G1 X85.774 Y107.058 E.36027
M73 P38 R18
G3 X85.709 Y106.761 I2.942 J-.797 E.0094
G1 X85.696 Y106.68 E.00254
G1 X74.22 Y106.68 E.35428
G3 X74.395 Y106.301 I4.22 J1.727 E.0129
G1 X85.656 Y106.301 E.34761
G1 X85.647 Y105.922 E.0117
G1 X74.585 Y105.922 E.34147
G1 X74.774 Y105.543 E.01307
M73 P39 R18
G1 X85.667 Y105.543 E.33625
G3 X85.724 Y105.164 I1.924 J.095 E.01184
G1 X74.964 Y105.164 E.33216
G1 X75.153 Y104.786 E.01307
G1 X85.815 Y104.786 E.32913
G3 X85.943 Y104.407 I1.958 J.452 E.01237
G1 X75.342 Y104.407 E.32724
G1 X75.532 Y104.028 E.01307
G1 X86.113 Y104.028 E.32663
G3 X86.283 Y103.718 I3.064 J1.477 E.01093
G1 X86.33 Y103.649 E.00256
G1 X75.721 Y103.649 E.32747
G1 X75.911 Y103.27 E.01307
G1 X86.603 Y103.27 E.33006
G3 X86.947 Y102.891 I2.792 J2.191 E.01581
G1 X76.1 Y102.891 E.33484
G1 X76.289 Y102.513 E.01307
G1 X87.385 Y102.513 E.34251
G3 X87.991 Y102.134 I2.907 J3.975 E.02208
G1 X76.479 Y102.134 E.35537
G1 X76.668 Y101.755 E.01307
G1 X179.331 Y101.755 E3.1691
G1 X179.142 Y101.376 E.01307
G1 X76.858 Y101.376 E3.15741
G1 X77.047 Y100.997 E.01307
G1 X178.953 Y100.997 E3.14572
G1 X178.763 Y100.619 E.01307
G1 X77.236 Y100.619 E3.13404
G3 X77.428 Y100.24 I4.013 J1.792 E.01311
G1 X178.572 Y100.24 E3.12221
G2 X178.331 Y99.861 I-1.667 J.795 E.0139
G1 X77.663 Y99.861 E3.10753
G3 X77.989 Y99.482 I1.71 J1.145 E.01548
G1 X178.001 Y99.482 E3.08727
G2 X177.535 Y99.103 I-2.426 J2.508 E.01856
G1 X78.465 Y99.103 E3.05822
G1 X78.995 Y98.724 E.02012
G1 X177.004 Y98.725 E3.02545
G1 X176.473 Y98.346 E.02013
G1 X79.525 Y98.346 E2.99269
G1 X80.056 Y97.967 E.02012
G1 X175.942 Y97.967 E2.95993
G1 X175.411 Y97.588 E.02014
G1 X80.586 Y97.588 E2.92717
G1 X81.116 Y97.209 E.02012
G1 X174.88 Y97.209 E2.8944
G1 X174.349 Y96.83 E.02014
G1 X81.647 Y96.83 E2.86164
G1 X82.177 Y96.452 E.02012
G1 X173.818 Y96.452 E2.82888
G1 X173.287 Y96.073 E.02014
G1 X82.707 Y96.073 E2.79611
G1 X83.238 Y95.694 E.02012
G1 X172.756 Y95.694 E2.76335
G2 X172.191 Y95.315 I-1.871 J2.179 E.02105
G1 X83.797 Y95.315 E2.72866
G3 X85.214 Y94.936 I1.418 J2.466 E.04579
G1 X171.764 Y94.936 E2.67171
; WIPE_START
G1 X169.764 Y94.936 E-.76
; WIPE_END
G1 E-.04 F1800
G17
M73 P40 R18
G3 Z1.8 I-.975 J-.728 P1  F30000
G1 X164.39 Y102.134 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F3000
G1 X92.009 Y102.134 E2.23432
G3 X92.615 Y102.513 I-2.273 J4.309 E.02208
G1 X163.385 Y102.513 E2.18461
G1 X163.229 Y102.637 E.00616
G2 X162.947 Y102.892 I1.195 J1.608 E.01174
G1 X93.053 Y102.891 E2.15757
G3 X93.397 Y103.27 I-1.791 J1.973 E.01582
G1 X162.603 Y103.27 E2.13632
G1 X162.529 Y103.359 E.00356
G2 X162.33 Y103.649 I2.565 J1.972 E.01087
G1 X93.67 Y103.649 E2.11944
G1 X93.717 Y103.718 E.00256
G3 X93.887 Y104.028 I-19.608 J10.945 E.01092
G1 X162.113 Y104.028 E2.10606
G2 X161.943 Y104.407 I3.544 J1.812 E.01282
G1 X94.057 Y104.407 E2.0956
G1 X94.096 Y104.5 E.00312
G3 X94.185 Y104.786 I-20.369 J6.504 E.00923
G1 X161.815 Y104.786 E2.08768
G2 X161.724 Y105.164 I1.943 J.668 E.01205
G1 X94.276 Y105.164 E2.08205
G3 X94.333 Y105.543 I-1.869 J.474 E.01184
G1 X161.667 Y105.543 E2.07854
G2 X161.643 Y105.922 I1.975 J.315 E.01173
G1 X94.357 Y105.922 E2.07706
G3 X94.349 Y106.301 I-2.037 J.145 E.01171
G1 X161.651 Y106.301 E2.07757
G2 X161.692 Y106.68 I1.919 J-.016 E.01178
G1 X94.308 Y106.68 E2.0801
G1 X94.231 Y107.058 E.01193
G1 X161.771 Y107.068 E2.08489
G2 X161.884 Y107.437 I3.784 J-.956 E.01193
G1 X94.116 Y107.437 E2.09193
G1 X94.102 Y107.484 E.00151
G3 X93.963 Y107.816 I-30.113 J-12.415 E.01111
G1 X162.037 Y107.816 E2.1014
G1 X162.067 Y107.886 E.00233
G2 X162.234 Y108.195 I3.431 J-1.659 E.01087
G1 X93.766 Y108.195 E2.11356
G1 X93.727 Y108.266 E.0025
G3 X93.518 Y108.574 I-2.776 J-1.657 E.01148
G1 X162.482 Y108.574 E2.12883
G1 X162.518 Y108.627 E.002
G2 X162.795 Y108.953 I8.146 J-6.654 E.01319
G1 X93.204 Y108.96 E2.1482
G3 X92.81 Y109.331 I-5.861 J-5.811 E.01672
G1 X163.19 Y109.331 E2.17256
G2 X163.714 Y109.71 I5.085 J-6.478 E.01996
G1 X92.286 Y109.71 E2.20492
G3 X91.507 Y110.089 I-2.421 J-3.989 E.02678
G1 X165.098 Y110.089 E2.2717
G1 X163.95 Y102.604 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X165.474 Y102.067 I2.091 J3.5 E.05398
G1 X169.932 Y106.524 E.20912
G3 X169.757 Y107.271 I-4.422 J-.643 E.02546
G1 X167.264 Y109.763 E.11693
G3 X165.687 Y109.955 I-1.255 J-3.725 E.05307
G1 X162.047 Y106.315 E.17077
G2 X162.205 Y107.147 I4.025 J-.333 E.02814
G1 X167.148 Y102.204 E.23188
G3 X168.567 Y102.976 I-1.11 J3.732 E.054
; WIPE_START
M73 P41 R18
G1 X167.985 Y102.562 E-.27157
G1 X167.148 Y102.204 E-.34604
G1 X166.883 Y102.469 E-.1424
; WIPE_END
G1 E-.04 F1800
G1 X166.535 Y110.094 Z1.8 F30000
G1 X165.082 Y141.91 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42174
G1 F3000
G1 X91.504 Y141.91 E2.27128
G3 X92.284 Y142.289 I-1.604 J4.296 E.02681
G1 X163.716 Y142.289 E2.20501
G1 X163.62 Y142.351 E.00352
G2 X163.191 Y142.668 I1.424 J2.376 E.01649
M73 P41 R17
G1 X92.809 Y142.668 E2.17261
G3 X93.209 Y143.046 I-5.141 J5.83 E.01701
G1 X162.791 Y143.046 E2.14792
G1 X162.681 Y143.177 E.00528
G2 X162.482 Y143.425 I1.246 J1.202 E.00982
G1 X93.518 Y143.425 E2.12887
M73 P42 R17
G3 X93.765 Y143.804 I-1.885 J1.502 E.01399
G1 X162.235 Y143.804 E2.11359
G2 X162.038 Y144.183 I1.924 J1.241 E.0132
G1 X93.962 Y144.183 E2.10143
G3 X94.116 Y144.562 I-2.005 J1.034 E.01264
G1 X161.884 Y144.562 E2.09195
G2 X161.769 Y144.941 I2.591 J.994 E.01223
G1 X94.231 Y144.94 E2.08484
G1 X94.307 Y145.319 E.01193
G1 X161.693 Y145.319 E2.08012
G2 X161.652 Y145.698 I1.875 J.395 E.01178
G1 X94.348 Y145.698 E2.07758
G1 X94.356 Y145.774 E.00237
G3 X94.357 Y146.077 I-3.276 J.16 E.00934
G1 X161.643 Y146.077 E2.07706
G2 X161.667 Y146.456 I2 J.064 E.01173
G1 X94.333 Y146.456 E2.07853
G3 X94.276 Y146.835 I-1.926 J-.095 E.01184
G1 X161.724 Y146.835 E2.08204
G2 X161.815 Y147.213 I2.034 J-.289 E.01205
G1 X94.185 Y147.213 E2.08766
G3 X94.057 Y147.592 I-2.068 J-.489 E.01236
G1 X161.943 Y147.592 E2.09558
G1 X161.956 Y147.624 E.00105
G2 X162.112 Y147.971 I1.928 J-.658 E.01177
G1 X93.888 Y147.971 E2.10603
G1 X93.825 Y148.086 E.00405
G3 X93.671 Y148.35 I-1.493 J-.695 E.00944
G1 X162.329 Y148.35 E2.1194
G2 X162.602 Y148.729 I2.124 J-1.244 E.01444
G1 X93.398 Y148.729 E2.13627
M73 P43 R17
G3 X93.054 Y149.108 I-2.134 J-1.592 E.01582
G1 X162.946 Y149.108 E2.15751
G2 X163.384 Y149.486 I2.172 J-2.068 E.0179
G1 X92.616 Y149.486 E2.18453
G1 X92.554 Y149.536 E.00245
G3 X92.011 Y149.865 I-3.485 J-5.135 E.01962
G1 X164.387 Y149.865 E2.23419
G1 X168.567 Y149.024 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X168.533 Y149.051 E.00145
G3 X167.148 Y149.796 I-2.546 J-3.074 E.05253
G1 X162.205 Y144.853 E.23188
G2 X162.047 Y145.685 I3.86 J1.163 E.02813
G1 X165.744 Y142.043 E.17214
G3 X165.976 Y142.033 I.167 J1.174 E.00772
G3 X167.131 Y142.2 I.004 J4.068 E.03885
G1 X167.265 Y142.237 E.00462
G1 X169.757 Y144.729 E.11689
G3 X169.932 Y145.476 I-4.254 J1.391 E.02546
G1 X165.483 Y149.925 E.20872
G1 X165.317 Y149.9 E.00556
G3 X163.956 Y149.399 I.72 J-4.062 E.04836
; WIPE_START
G1 X164.736 Y149.763 E-.32701
G1 X165.317 Y149.9 E-.22697
G1 X165.483 Y149.925 E-.06373
G1 X165.748 Y149.66 E-.14229
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I-1.03 J.648 P1  F30000
G1 X170.405 Y157.063 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42174
G1 F3000
G1 X86.549 Y157.063 E2.58855
M73 P44 R17
G3 X85.154 Y156.684 I.084 J-3.069 E.04506
G1 X170.843 Y156.684 E2.64514
G2 X171.363 Y156.305 I-1.948 J-3.22 E.01988
G1 X84.634 Y156.305 E2.67725
G1 X84.254 Y155.926 E.01655
G1 X171.751 Y155.926 E2.70093
G1 X172.129 Y155.548 E.01653
G1 X83.875 Y155.547 E2.72431
G1 X83.496 Y155.169 E.01655
G1 X172.508 Y155.169 E2.7477
G1 X172.886 Y154.79 E.01653
G1 X83.117 Y154.79 E2.77109
G1 X82.738 Y154.411 E.01655
G1 X173.264 Y154.411 E2.79448
G1 X173.643 Y154.032 E.01653
G1 X82.358 Y154.032 E2.81786
G1 X81.979 Y153.653 E.01655
G1 X174.021 Y153.653 E2.84125
G1 X174.4 Y153.275 E.01653
G1 X81.6 Y153.275 E2.86464
G1 X81.221 Y152.896 E.01655
G1 X174.778 Y152.896 E2.88803
G1 X175.157 Y152.517 E.01653
G1 X80.842 Y152.517 E2.91141
G1 X80.463 Y152.138 E.01655
G1 X175.535 Y152.138 E2.9348
G1 X175.914 Y151.759 E.01653
G1 X80.083 Y151.759 E2.95819
G1 X79.704 Y151.38 E.01655
G1 X176.292 Y151.381 E2.98158
G1 X176.671 Y151.002 E.01653
G1 X79.325 Y151.002 E3.00496
G1 X78.946 Y150.623 E.01655
G1 X177.289 Y150.623 E3.03575
; WIPE_START
G1 X175.289 Y150.623 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.58 J-1.07 P1  F30000
G1 X87.433 Y102.976 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X87.474 Y102.944 E.00174
G3 X88.852 Y102.204 I2.543 J3.087 E.05224
G1 X93.795 Y107.147 E.23188
G2 X93.953 Y106.315 I-3.862 J-1.163 E.02814
G1 X90.316 Y109.952 E.17061
G3 X88.727 Y109.755 I-.296 J-4.111 E.05346
G1 X86.244 Y107.271 E.1165
M73 P45 R16
G3 X86.069 Y106.523 I3.927 J-1.309 E.02553
G1 X90.526 Y102.067 E.20905
G3 X92.05 Y102.604 I-.595 J4.117 E.05397
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X91.264 Y102.237 E-.32965
G1 X90.526 Y102.067 E-.28808
G1 X90.261 Y102.332 E-.14227
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/23
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.8 I-.573 J1.074 P1  F30000
G1 X178.35 Y149.36 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.07 J-1.107 E.04701
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27712
G3 X169.418 Y157.398 I-2.287 J-2.306 E.08374
G1 X86.581 Y157.398 E2.74785
G3 X84.308 Y156.456 I.013 J-3.247 E.08372
G1 X78.4 Y150.549 E.27712
G3 X77.472 Y148.571 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35056
G3 X74.027 Y106.292 I3.277 J-.286 E.05945
G1 X77.113 Y100.12 E.22893
G3 X78.124 Y98.937 I2.964 J1.51 E.05209
G1 X83.353 Y95.202 E.21316
G3 X85.225 Y94.602 I1.872 J2.62 E.06628
G1 X170.788 Y94.602 E2.83827
G3 X172.647 Y95.202 I-.011 J3.217 E.06584
G1 X177.876 Y98.937 E.21314
G3 X178.887 Y100.12 I-1.957 J2.696 E.0521
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.951 J1.454 E.05943
G1 X178.528 Y148.571 E1.35058
G3 X178.37 Y149.304 I-3.248 J-.318 E.02491
M204 S250
G1 X178.722 Y149.496 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.589 Y149.807 E.01039
G3 X177.88 Y150.823 I-3.314 J-1.557 E.03824
G1 X171.966 Y156.737 E.25699
G3 X169.423 Y157.79 I-2.563 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54564
G3 X84.034 Y156.737 I.02 J-3.644 E.08672
G1 X78.12 Y150.823 E.257
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06149
G1 X76.765 Y99.94 E.21233
G3 X77.892 Y98.621 I3.323 J1.698 E.05383
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.096 J2.942 E.06858
G1 X170.793 Y94.21 E2.62938
M73 P46 R16
G3 X172.871 Y94.88 I-.016 J3.609 E.06816
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.2 J3.022 E.05382
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.313 J1.627 E.06148
G1 X178.918 Y148.612 E1.25133
G3 X178.738 Y149.44 I-3.644 J-.362 E.02607
; WIPE_START
M204 S10000
G1 X178.589 Y149.807 E-.15061
G1 X178.419 Y150.134 E-.14
G1 X178.229 Y150.418 E-.12975
G1 X177.88 Y150.823 E-.20321
G1 X177.626 Y151.077 E-.13642
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I-.788 J-.927 P1  F30000
G1 X170.762 Y156.915 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42089
G1 F15000
G1 X177.463 Y150.208 E.29202
G2 X178.103 Y149.039 I-2.09 J-1.902 E.04141
M73 P47 R16
G1 X170.185 Y156.957 E.34486
G1 X170.122 Y156.978 E.00205
G3 X169.55 Y157.058 I-.609 J-2.265 E.01785
G1 X178.21 Y148.398 E.37721
G1 X178.265 Y147.808 E.01823
G1 X169.008 Y157.065 E.40318
G1 X168.474 Y157.065 E.01646
G1 X178.319 Y147.219 E.42885
G1 X178.374 Y146.63 E.01823
G1 X167.939 Y157.065 E.45452
G1 X167.405 Y157.065 E.01646
G1 X178.429 Y146.04 E.48019
G1 X178.484 Y145.451 E.01823
G1 X166.87 Y157.065 E.50586
G1 X166.336 Y157.065 E.01646
G1 X178.539 Y144.862 E.53153
G1 X178.593 Y144.272 E.01823
G1 X165.801 Y157.065 E.5572
G1 X165.267 Y157.065 E.01646
G1 X178.648 Y143.683 E.58287
G1 X178.703 Y143.094 E.01823
G1 X164.732 Y157.065 E.60855
G1 X164.197 Y157.065 E.01646
G1 X178.758 Y142.504 E.63422
G1 X178.813 Y141.915 E.01823
G1 X163.663 Y157.065 E.65989
G1 X163.128 Y157.065 E.01646
G1 X178.868 Y141.326 E.68556
G1 X178.922 Y140.736 E.01823
G1 X162.594 Y157.065 E.71123
G1 X162.059 Y157.065 E.01646
G1 X178.977 Y140.147 E.7369
G1 X179.032 Y139.557 E.01823
G1 X161.525 Y157.065 E.76257
G1 X160.99 Y157.065 E.01646
G1 X179.087 Y138.968 E.78824
G1 X179.142 Y138.379 E.01823
G1 X170.131 Y147.39 E.39249
G2 X170.308 Y146.678 I-3.556 J-1.263 E.02263
G1 X179.197 Y137.789 E.38716
G1 X179.251 Y137.2 E.01823
G1 X170.357 Y146.094 E.38742
G2 X170.337 Y145.58 I-2.674 J-.152 E.01588
G1 X179.306 Y136.611 E.39069
G1 X179.361 Y136.021 E.01823
G1 X170.266 Y145.116 E.39614
G2 X170.156 Y144.692 I-2.264 J.363 E.01352
G1 X179.416 Y135.432 E.40334
G1 X179.471 Y134.843 E.01823
G1 X170.012 Y144.301 E.41199
G2 X169.839 Y143.94 I-1.975 J.723 E.01236
G1 X179.525 Y134.253 E.42192
G1 X179.58 Y133.664 E.01823
G1 X169.64 Y143.604 E.43298
G2 X169.416 Y143.293 I-1.764 J1.032 E.01181
G1 X179.635 Y133.075 E.4451
G1 X179.69 Y132.485 E.01823
G1 X169.17 Y143.005 E.45823
G1 X168.899 Y142.742 E.01164
G1 X179.745 Y131.896 E.47241
G1 X179.8 Y131.307 E.01823
G1 X168.603 Y142.503 E.48769
G1 X168.553 Y142.464 E.00195
G2 X168.283 Y142.288 I-1.905 J2.637 E.00992
G1 X179.854 Y130.717 E.504
G1 X179.909 Y130.128 E.01823
G1 X167.939 Y142.098 E.52139
G2 X167.568 Y141.935 I-1.038 J1.859 E.01251
G1 X179.964 Y129.538 E.53995
G1 X180.019 Y128.949 E.01823
G1 X167.166 Y141.802 E.55984
G2 X166.729 Y141.704 I-.727 J2.226 E.01381
G1 X180.074 Y128.36 E.58126
G1 X180.129 Y127.77 E.01823
G1 X166.252 Y141.647 E.60445
G2 X165.712 Y141.652 I-.243 J2.845 E.01665
G1 X180.183 Y127.181 E.63034
G1 X180.238 Y126.592 E.01823
G1 X165.094 Y141.736 E.65963
G1 X165.038 Y141.746 E.00176
G2 X164.314 Y141.981 I1.558 J6.012 E.02346
G1 X180.293 Y126.002 E.696
G1 X180.348 Y125.413 E.01823
G1 X148.696 Y157.065 E1.37867
G1 X148.162 Y157.065 E.01646
G1 X180.403 Y124.824 E1.40434
G1 X180.457 Y124.234 E.01823
G1 X147.627 Y157.065 E1.43001
G1 X147.093 Y157.065 E.01646
G1 X180.512 Y123.645 E1.45568
G1 X180.567 Y123.056 E.01823
G1 X146.558 Y157.065 E1.48135
G1 X146.023 Y157.065 E.01646
G1 X180.622 Y122.466 E1.50702
G1 X180.677 Y121.877 E.01823
G1 X145.489 Y157.065 E1.53269
G1 X144.954 Y157.065 E.01646
G1 X180.732 Y121.288 E1.55836
G1 X180.786 Y120.698 E.01823
G1 X144.42 Y157.065 E1.58403
G1 X143.885 Y157.065 E.01646
G1 X180.841 Y120.109 E1.6097
G1 X180.896 Y119.519 E.01823
G1 X143.351 Y157.065 E1.63537
G1 X142.816 Y157.065 E.01646
G1 X180.951 Y118.93 E1.66105
G1 X181.006 Y118.341 E.01823
G1 X142.282 Y157.065 E1.68672
G1 X141.747 Y157.065 E.01646
G1 X181.061 Y117.751 E1.71239
G1 X181.115 Y117.162 E.01823
G1 X141.213 Y157.065 E1.73806
G1 X140.678 Y157.065 E.01646
G1 X181.17 Y116.573 E1.76373
G1 X181.225 Y115.983 E.01823
G1 X140.144 Y157.065 E1.7894
G1 X139.609 Y157.065 E.01646
G1 X181.28 Y115.394 E1.81507
G1 X181.335 Y114.805 E.01823
G1 X139.075 Y157.065 E1.84074
G1 X138.54 Y157.065 E.01646
G1 X181.389 Y114.215 E1.86641
G1 X181.444 Y113.626 E.01823
G1 X138.005 Y157.065 E1.89208
G1 X137.471 Y157.065 E.01646
G1 X181.499 Y113.037 E1.91775
G1 X181.554 Y112.447 E.01823
G1 X136.936 Y157.065 E1.94342
G1 X136.402 Y157.065 E.01646
G1 X181.609 Y111.858 E1.96909
G1 X181.664 Y111.268 E.01823
G1 X135.867 Y157.065 E1.99477
G1 X135.333 Y157.065 E.01646
G1 X181.718 Y110.679 E2.02044
G1 X181.773 Y110.09 E.01823
G1 X134.798 Y157.065 E2.04611
G1 X134.264 Y157.065 E.01646
G1 X181.828 Y109.5 E2.07178
G1 X181.883 Y108.911 E.01823
G1 X133.729 Y157.065 E2.09745
G1 X133.195 Y157.065 E.01646
G1 X181.938 Y108.322 E2.12312
G2 X181.979 Y107.746 I-6.25 J-.739 E.01779
G1 X132.66 Y157.065 E2.14821
G1 X132.126 Y157.065 E.01646
M73 P48 R16
G1 X181.938 Y107.252 E2.1697
G2 X181.832 Y106.824 I-1.891 J.241 E.01363
G1 X131.591 Y157.065 E2.18837
G1 X131.057 Y157.065 E.01646
G1 X181.674 Y106.447 E2.20476
G1 X181.496 Y106.091 E.01227
G1 X130.522 Y157.065 E2.22029
G1 X129.988 Y157.065 E.01646
G1 X181.318 Y105.734 E2.23582
G1 X181.14 Y105.378 E.01227
G1 X129.453 Y157.065 E2.25135
G1 X128.918 Y157.065 E.01646
G1 X180.962 Y105.021 E2.26688
G1 X180.784 Y104.665 E.01227
G1 X128.384 Y157.065 E2.28241
G1 X127.849 Y157.065 E.01646
G1 X180.606 Y104.308 E2.29794
G1 X180.428 Y103.952 E.01227
G1 X127.315 Y157.065 E2.31346
G1 X126.78 Y157.065 E.01646
G1 X180.25 Y103.595 E2.32899
G1 X180.072 Y103.239 E.01227
G1 X126.246 Y157.065 E2.34452
G1 X125.711 Y157.065 E.01646
G1 X179.894 Y102.882 E2.36005
G1 X179.716 Y102.526 E.01227
G1 X125.177 Y157.065 E2.37558
G1 X124.642 Y157.065 E.01646
G1 X179.538 Y102.169 E2.39111
G1 X179.36 Y101.813 E.01227
G1 X124.108 Y157.065 E2.40663
G1 X123.573 Y157.065 E.01646
G1 X179.182 Y101.456 E2.42216
G1 X179.004 Y101.1 E.01227
G1 X123.039 Y157.065 E2.43769
G1 X122.504 Y157.065 E.01646
G1 X178.826 Y100.743 E2.45322
G1 X178.648 Y100.387 E.01227
G1 X121.97 Y157.065 E2.46875
G1 X121.435 Y157.065 E.01646
G1 X178.46 Y100.04 E2.48385
G2 X178.235 Y99.73 I-1.373 J.76 E.01182
G1 X120.901 Y157.065 E2.49734
G1 X120.366 Y157.065 E.01646
G1 X167.259 Y110.172 E2.04253
G3 X166.573 Y110.323 I-1.118 J-3.441 E.02166
G1 X119.831 Y157.065 E2.03594
G1 X119.297 Y157.065 E.01646
G1 X166.003 Y110.358 E2.03441
G3 X165.503 Y110.324 I-.108 J-2.112 E.01549
G1 X118.762 Y157.065 E2.03589
G1 X118.228 Y157.065 E.01646
G1 X165.038 Y110.254 E2.03895
G3 X164.62 Y110.138 I.707 J-3.349 E.01338
G1 X117.693 Y157.065 E2.04401
G1 X117.159 Y157.065 E.01646
G1 X164.236 Y109.988 E2.05054
G1 X164.214 Y109.98 E.00071
M73 P48 R15
G3 X163.88 Y109.809 I1.506 J-3.368 E.01156
G1 X116.624 Y157.065 E2.05833
G1 X116.09 Y157.065 E.01646
G1 X163.55 Y109.604 E2.06725
G1 X163.461 Y109.547 E.00328
G3 X163.245 Y109.375 I1.593 J-2.232 E.0085
G1 X115.555 Y157.065 E2.07723
G1 X115.021 Y157.065 E.01646
G1 X162.962 Y109.123 E2.08821
G3 X162.703 Y108.848 I1.312 J-1.5 E.01166
G1 X114.486 Y157.065 E2.10018
G1 X113.952 Y157.065 E.01646
G1 X162.466 Y108.551 E2.11315
G3 X162.253 Y108.229 I1.674 J-1.34 E.0119
G1 X113.417 Y157.065 E2.12716
G1 X112.883 Y157.065 E.01646
G1 X162.065 Y107.882 E2.14227
G1 X161.907 Y107.506 E.01257
G1 X112.348 Y157.065 E2.15865
G1 X111.814 Y157.065 E.01646
G1 X161.779 Y107.099 E2.17639
G1 X161.775 Y107.085 E.00045
G3 X161.688 Y106.656 I46.91 J-9.785 E.01348
G1 X111.279 Y157.065 E2.19568
G1 X110.744 Y157.065 E.01646
G1 X161.643 Y106.166 E2.21702
G3 X161.66 Y105.615 I2.87 J-.188 E.01702
G1 X110.21 Y157.065 E2.24103
G1 X109.675 Y157.065 E.01646
G1 X161.761 Y104.979 E2.26874
G1 X161.771 Y104.932 E.00146
G3 X162.049 Y104.157 I6.043 J1.729 E.02539
G1 X109.141 Y157.065 E2.30454
G1 X108.606 Y157.065 E.01646
G1 X170.735 Y94.936 E2.70618
G3 X171.231 Y94.974 I-.299 J7.008 E.01532
G1 X164.157 Y102.049 E.30815
G1 X164.198 Y102.028 E.00144
G3 X164.979 Y101.761 I2.418 J5.807 E.02543
G1 X171.661 Y95.079 E.29106
G3 X172.042 Y95.233 I-.344 J1.399 E.01269
G1 X165.615 Y101.66 E.27993
G3 X166.164 Y101.645 I.35 J2.872 E.01694
G1 X172.382 Y95.427 E.27085
G1 X172.694 Y95.65 E.0118
G1 X166.653 Y101.691 E.26315
G3 X167.096 Y101.782 I-.257 J2.369 E.01396
G1 X173.006 Y95.872 E.25743
G1 X173.318 Y96.095 E.0118
G1 X167.503 Y101.91 E.25328
G3 X167.88 Y102.068 I-.651 J2.079 E.01259
G1 X173.63 Y96.317 E.25047
G1 X173.942 Y96.54 E.0118
G1 X168.229 Y102.253 E.24885
G3 X168.553 Y102.463 I-1.923 J3.317 E.01191
G1 X174.254 Y96.762 E.24832
G1 X174.566 Y96.985 E.0118
G1 X168.85 Y102.7 E.24895
G1 X168.88 Y102.724 E.00115
G3 X169.124 Y102.961 I-2.223 J2.536 E.0105
G1 X174.878 Y97.208 E.25061
G1 X175.19 Y97.43 E.0118
G1 X169.375 Y103.245 E.25326
G3 X169.603 Y103.551 I-1.493 J1.349 E.01178
G1 X175.502 Y97.653 E.25692
G1 X175.814 Y97.875 E.0118
G1 X169.807 Y103.882 E.26162
G3 X169.985 Y104.238 I-1.782 J1.113 E.01229
G1 X176.126 Y98.098 E.26745
G1 X176.438 Y98.32 E.0118
G1 X170.135 Y104.623 E.27454
G3 X170.251 Y105.041 I-2.141 J.822 E.01339
G1 X176.75 Y98.543 E.28306
G1 X177.062 Y98.765 E.0118
G1 X170.328 Y105.499 E.29328
G3 X170.357 Y106.005 I-2.606 J.4 E.01564
G1 X177.374 Y98.988 E.30563
G3 X177.685 Y99.211 I-2.117 J3.287 E.0118
G1 X170.321 Y106.575 E.32076
G1 X170.314 Y106.642 E.00206
G3 X170.171 Y107.26 I-6.441 J-1.17 E.01956
G1 X178.095 Y99.336 E.34516
G1 X168.567 Y102.976 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X167.148 Y102.204 I-2.594 J3.078 E.05398
G1 X162.205 Y107.147 E.23188
G3 X162.047 Y106.315 I3.865 J-1.164 E.02814
G1 X165.687 Y109.955 E.17077
G2 X167.265 Y109.763 I.171 J-5.151 E.05295
G1 X169.757 Y107.271 E.11689
G2 X169.932 Y106.524 I-4.247 J-1.389 E.02546
G1 X165.474 Y102.067 E.20912
M73 P49 R15
G2 X163.95 Y102.604 I.572 J4.053 E.05398
G1 X146.851 Y94.766 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42089
G1 F15000
G1 X94.08 Y147.537 E2.29856
G2 X94.283 Y146.799 I-4.843 J-1.73 E.02358
G1 X146.147 Y94.936 E2.25904
G1 X145.613 Y94.936 E.01646
G1 X94.357 Y146.191 E2.23256
G2 X94.356 Y145.774 I-4.241 J-.2 E.01286
G1 X94.345 Y145.668 E.00328
G1 X145.078 Y94.936 E2.20978
G1 X144.543 Y94.936 E.01646
G1 X94.283 Y145.196 E2.18924
G2 X94.179 Y144.766 I-2.296 J.326 E.01367
G1 X144.009 Y94.936 E2.17048
G1 X143.474 Y94.936 E.01646
G1 X94.041 Y144.369 E2.1532
G2 X93.926 Y144.1 I-2.745 J1.008 E.00902
G1 X93.873 Y144.002 E.00342
G1 X142.94 Y94.936 E2.13722
G1 X142.405 Y94.936 E.01646
G1 X93.679 Y143.662 E2.12239
G2 X93.472 Y143.359 I-3.142 J1.931 E.0113
G1 X93.46 Y143.346 E.00054
G1 X141.871 Y94.936 E2.10863
G1 X141.336 Y94.936 E.01646
G1 X93.217 Y143.055 E2.09597
G2 X92.948 Y142.789 I-1.721 J1.469 E.01165
G1 X140.802 Y94.936 E2.08439
G1 X140.267 Y94.936 E.01646
G1 X92.657 Y142.546 E2.07379
G2 X92.342 Y142.326 I-1.312 J1.542 E.01184
G1 X139.733 Y94.936 E2.06421
G1 X139.198 Y94.936 E.01646
G1 X92.003 Y142.131 E2.0557
G2 X91.637 Y141.962 I-1.065 J1.828 E.01243
G1 X138.664 Y94.936 E2.04836
G1 X138.129 Y94.936 E.01646
G1 X91.241 Y141.823 E2.04231
G2 X90.811 Y141.719 I-.76 J2.193 E.01366
G1 X137.595 Y94.936 E2.03777
G1 X137.06 Y94.936 E.01646
G1 X90.343 Y141.653 E2.03488
G2 X89.883 Y141.64 I-.66 J15.173 E.01418
G1 X89.816 Y141.645 E.00204
G1 X136.526 Y94.936 E2.03453
G1 X135.991 Y94.936 E.01646
G1 X89.212 Y141.715 E2.03759
G2 X88.473 Y141.919 I.81 J4.373 E.02362
G1 X135.457 Y94.936 E2.04647
G1 X134.922 Y94.936 E.01646
G1 X79.09 Y150.767 E2.43188
G1 X79.358 Y151.034 E.01164
G1 X85.913 Y144.479 E.28553
G2 X85.714 Y145.212 I5.132 J1.785 E.02342
G1 X79.625 Y151.301 E.26523
G1 X79.893 Y151.569 E.01164
G1 X85.643 Y145.818 E.25048
G2 X85.644 Y146.226 I4.1 J.195 E.01257
G1 X85.655 Y146.34 E.00353
G1 X80.16 Y151.836 E.23937
G1 X80.427 Y152.103 E.01164
G1 X85.719 Y146.811 E.23049
G2 X85.774 Y147.082 I3.459 J-.565 E.00851
G1 X85.821 Y147.244 E.00519
G1 X80.695 Y152.37 E.22328
G1 X80.962 Y152.637 E.01164
G1 X85.96 Y147.639 E.2177
G2 X86.129 Y148.004 I2.111 J-.758 E.01241
G1 X81.229 Y152.904 E.21343
G1 X81.497 Y153.171 E.01164
G1 X86.326 Y148.343 E.21033
G2 X86.546 Y148.656 I1.761 J-1.005 E.01183
G1 X81.764 Y153.439 E.2083
G1 X82.032 Y153.706 E.01164
G1 X86.791 Y148.947 E.20729
G2 X87.058 Y149.214 I1.541 J-1.271 E.01166
G1 X82.299 Y153.973 E.20727
G1 X82.566 Y154.24 E.01164
G1 X87.347 Y149.459 E.20825
G2 X87.641 Y149.669 I2.204 J-2.772 E.01112
G1 X87.661 Y149.68 E.0007
G1 X82.834 Y154.507 E.21024
G1 X83.101 Y154.774 E.01164
G1 X88 Y149.876 E.21336
G2 X88.367 Y150.043 I1.516 J-2.845 E.01244
G1 X83.369 Y155.041 E.21772
G1 X83.636 Y155.309 E.01164
G1 X88.764 Y150.181 E.22335
G2 X89.194 Y150.285 I.784 J-2.3 E.01366
G1 X83.903 Y155.576 E.23045
G1 X84.171 Y155.843 E.01164
G1 X89.665 Y150.349 E.2393
G2 X90.117 Y150.36 I1.568 J-53.323 E.01395
G1 X90.193 Y150.355 E.00235
G1 X84.438 Y156.11 E.25069
G2 X84.711 Y156.372 I1.471 J-1.26 E.01166
G1 X90.799 Y150.283 E.2652
G2 X91.542 Y150.075 I-.819 J-4.354 E.02377
G1 X85.017 Y156.6 E.28421
G2 X85.364 Y156.788 I.943 J-1.331 E.01218
G1 X147.216 Y94.936 E2.69412
G1 X147.751 Y94.936 E.01646
G1 X85.751 Y156.936 E2.70056
G2 X86.189 Y157.032 I.543 J-1.428 E.01387
G1 X148.285 Y94.936 E2.70475
G1 X148.82 Y94.936 E.01646
G1 X86.691 Y157.065 E2.70619
G1 X87.225 Y157.065 E.01646
G1 X149.354 Y94.936 E2.70619
G1 X149.889 Y94.936 E.01646
G1 X87.76 Y157.065 E2.70619
G1 X88.294 Y157.065 E.01646
G1 X150.423 Y94.936 E2.70619
G1 X150.958 Y94.936 E.01646
G1 X88.829 Y157.065 E2.70619
G1 X89.363 Y157.065 E.01646
G1 X151.492 Y94.936 E2.70619
G1 X152.027 Y94.936 E.01646
G1 X89.898 Y157.065 E2.70619
G1 X90.432 Y157.065 E.01646
G1 X152.561 Y94.936 E2.70619
G1 X153.096 Y94.936 E.01646
G1 X90.967 Y157.065 E2.70619
G1 X91.501 Y157.065 E.01646
G1 X153.63 Y94.936 E2.70619
G1 X154.165 Y94.936 E.01646
G1 X92.036 Y157.065 E2.70619
G1 X92.57 Y157.065 E.01646
G1 X154.7 Y94.936 E2.70619
G1 X155.234 Y94.936 E.01646
G1 X93.105 Y157.065 E2.70619
G1 X93.639 Y157.065 E.01646
G1 X155.769 Y94.936 E2.70619
G1 X156.303 Y94.936 E.01646
G1 X94.174 Y157.065 E2.70619
G1 X94.709 Y157.065 E.01646
G1 X156.838 Y94.936 E2.70619
G1 X157.372 Y94.936 E.01646
G1 X95.243 Y157.065 E2.70619
G1 X95.778 Y157.065 E.01646
G1 X157.907 Y94.936 E2.70619
G1 X158.441 Y94.936 E.01646
G1 X96.312 Y157.065 E2.70619
G1 X96.847 Y157.065 E.01646
G1 X158.976 Y94.936 E2.70619
G1 X159.51 Y94.936 E.01646
G1 X97.381 Y157.065 E2.70619
G1 X97.916 Y157.065 E.01646
G1 X160.045 Y94.936 E2.70618
G1 X160.579 Y94.936 E.01646
G1 X98.45 Y157.065 E2.70618
G1 X98.985 Y157.065 E.01646
G1 X161.114 Y94.936 E2.70618
G1 X161.648 Y94.936 E.01646
G1 X99.519 Y157.065 E2.70618
G1 X100.054 Y157.065 E.01646
G1 X162.183 Y94.936 E2.70618
G1 X162.717 Y94.936 E.01646
G1 X100.588 Y157.065 E2.70618
G1 X101.123 Y157.065 E.01646
G1 X163.252 Y94.936 E2.70618
G1 X163.787 Y94.936 E.01646
G1 X101.657 Y157.065 E2.70618
G1 X102.192 Y157.065 E.01646
G1 X164.321 Y94.936 E2.70618
G1 X164.856 Y94.936 E.01646
G1 X102.726 Y157.065 E2.70618
G1 X103.261 Y157.065 E.01646
G1 X165.39 Y94.936 E2.70618
G1 X165.925 Y94.936 E.01646
G1 X103.796 Y157.065 E2.70618
G1 X104.33 Y157.065 E.01646
G1 X166.459 Y94.936 E2.70618
G1 X166.994 Y94.936 E.01646
G1 X104.865 Y157.065 E2.70618
G1 X105.399 Y157.065 E.01646
G1 X167.528 Y94.936 E2.70618
G1 X168.063 Y94.936 E.01646
G1 X105.934 Y157.065 E2.70618
G1 X106.468 Y157.065 E.01646
G1 X168.597 Y94.936 E2.70618
G1 X169.132 Y94.936 E.01646
G1 X107.003 Y157.065 E2.70618
G1 X107.537 Y157.065 E.01646
G1 X169.666 Y94.936 E2.70618
G1 X170.201 Y94.936 E.01646
G1 X107.902 Y157.234 E2.71357
G1 X87.433 Y149.022 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X88.851 Y149.797 I2.598 J-3.073 E.05398
G1 X93.795 Y144.853 E.23192
G3 X93.953 Y145.685 I-3.863 J1.164 E.02814
G1 X90.312 Y142.044 E.17081
G2 X88.735 Y142.237 I-.163 J5.186 E.05293
G1 X86.243 Y144.729 E.11689
G2 X86.068 Y145.476 I4.25 J1.39 E.02546
G1 X90.526 Y149.933 E.20912
G2 X92.05 Y149.396 I-.571 J-4.051 E.05398
G1 X78.703 Y150.62 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42089
G1 F15000
G1 X134.387 Y94.936 E2.42547
G1 X133.853 Y94.935 E.01646
G1 X78.56 Y150.228 E2.40842
G3 X78.324 Y149.93 I1.089 J-1.106 E.01175
G1 X133.318 Y94.935 E2.39543
G1 X132.784 Y94.935 E.01646
G1 X78.118 Y149.601 E2.3811
G3 X77.96 Y149.225 I1.435 J-.825 E.0126
M73 P50 R15
G1 X132.249 Y94.935 E2.36472
G1 X131.715 Y94.935 E.01646
G1 X77.842 Y148.808 E2.34655
G3 X77.784 Y148.332 I4.841 J-.831 E.01479
G1 X131.18 Y94.935 E2.3258
G1 X130.646 Y94.935 E.01646
G1 X77.739 Y147.843 E2.3045
G1 X77.693 Y147.354 E.01513
G1 X130.111 Y94.935 E2.2832
G1 X129.577 Y94.935 E.01646
G1 X77.648 Y146.864 E2.26189
G1 X77.602 Y146.375 E.01513
G1 X129.042 Y94.935 E2.24059
G1 X128.508 Y94.935 E.01646
G1 X77.557 Y145.886 E2.21929
G1 X77.511 Y145.397 E.01513
G1 X127.973 Y94.935 E2.19799
G1 X127.439 Y94.935 E.01646
G1 X77.466 Y144.908 E2.17669
G1 X77.42 Y144.419 E.01513
G1 X126.904 Y94.935 E2.15539
G1 X126.37 Y94.935 E.01646
G1 X77.375 Y143.93 E2.13409
G1 X77.329 Y143.441 E.01513
G1 X125.835 Y94.935 E2.11279
G1 X125.3 Y94.935 E.01646
G1 X77.284 Y142.952 E2.09148
G1 X77.238 Y142.463 E.01513
G1 X124.766 Y94.935 E2.07018
G1 X124.231 Y94.935 E.01646
G1 X77.193 Y141.974 E2.04888
G1 X77.147 Y141.485 E.01513
G1 X123.697 Y94.935 E2.02758
G1 X123.162 Y94.935 E.01646
G1 X77.102 Y140.996 E2.00628
G1 X77.056 Y140.507 E.01513
G1 X122.628 Y94.935 E1.98498
G1 X122.093 Y94.935 E.01646
G1 X77.011 Y140.018 E1.96368
G1 X76.965 Y139.529 E.01513
G1 X121.559 Y94.935 E1.94238
G1 X121.024 Y94.935 E.01646
G1 X76.92 Y139.04 E1.92108
G1 X76.874 Y138.551 E.01513
G1 X120.49 Y94.935 E1.89977
G1 X119.955 Y94.935 E.01646
G1 X76.829 Y138.062 E1.87847
G1 X76.783 Y137.573 E.01513
G1 X119.421 Y94.935 E1.85717
G1 X118.886 Y94.935 E.01646
G1 X76.738 Y137.084 E1.83587
G1 X76.692 Y136.595 E.01513
G1 X118.352 Y94.935 E1.81457
G1 X117.817 Y94.935 E.01646
G1 X76.647 Y136.106 E1.79327
G1 X76.601 Y135.617 E.01513
G1 X117.283 Y94.935 E1.77197
G1 X116.748 Y94.935 E.01646
G1 X76.556 Y135.128 E1.75067
G1 X76.51 Y134.639 E.01513
G1 X116.213 Y94.935 E1.72936
G1 X115.679 Y94.935 E.01646
G1 X76.465 Y134.149 E1.70806
G1 X76.419 Y133.66 E.01513
G1 X115.144 Y94.935 E1.68676
G1 X114.61 Y94.935 E.01646
G1 X76.374 Y133.171 E1.66546
G1 X76.328 Y132.682 E.01513
G1 X114.075 Y94.935 E1.64416
G1 X113.541 Y94.935 E.01646
G1 X76.283 Y132.193 E1.62286
G1 X76.237 Y131.704 E.01513
G1 X113.006 Y94.935 E1.60156
G1 X112.472 Y94.935 E.01646
G1 X76.192 Y131.215 E1.58026
G1 X76.146 Y130.726 E.01513
G1 X111.937 Y94.935 E1.55896
G1 X111.403 Y94.935 E.01646
G1 X76.101 Y130.237 E1.53765
G1 X76.055 Y129.748 E.01513
G1 X110.868 Y94.935 E1.51635
G1 X110.334 Y94.935 E.01646
G1 X76.01 Y129.259 E1.49505
G1 X75.964 Y128.77 E.01513
G1 X109.799 Y94.935 E1.47375
G1 X109.265 Y94.935 E.01646
G1 X75.919 Y128.281 E1.45245
G1 X75.874 Y127.792 E.01513
G1 X108.73 Y94.935 E1.43115
G1 X108.196 Y94.935 E.01646
G1 X75.828 Y127.303 E1.40985
G1 X75.783 Y126.814 E.01513
G1 X107.661 Y94.935 E1.38855
G1 X107.126 Y94.935 E.01646
G1 X75.737 Y126.325 E1.36724
G1 X75.692 Y125.836 E.01513
G1 X91.394 Y110.133 E.68397
G3 X90.69 Y110.302 I-1.813 J-5.987 E.02231
G1 X75.646 Y125.347 E.6553
G1 X75.601 Y124.858 E.01513
G1 X90.098 Y110.361 E.63145
G3 X89.585 Y110.339 I-.141 J-2.733 E.01583
G1 X75.555 Y124.369 E.6111
G1 X75.51 Y123.88 E.01513
G1 X89.121 Y110.268 E.59288
G3 X88.696 Y110.158 I.365 J-2.282 E.01353
G1 X75.464 Y123.391 E.57637
M73 P51 R15
G1 X75.419 Y122.902 E.01513
G1 X88.305 Y110.015 E.5613
G3 X87.943 Y109.843 I.743 J-2.034 E.01238
G1 X75.373 Y122.413 E.54749
G1 X75.328 Y121.924 E.01513
G1 X87.606 Y109.645 E.53482
G1 X87.295 Y109.421 E.0118
G1 X75.282 Y121.434 E.52326
G1 X75.237 Y120.945 E.01513
G1 X87.01 Y109.172 E.51282
G1 X86.961 Y109.129 E.00203
G3 X86.747 Y108.9 I2.155 J-2.225 E.00963
G1 X75.191 Y120.456 E.50336
G1 X75.146 Y119.967 E.01513
G1 X86.508 Y108.605 E.4949
G3 X86.292 Y108.287 I1.558 J-1.291 E.01187
G1 X75.1 Y119.478 E.48747
G1 X75.055 Y118.989 E.01513
G1 X86.1 Y107.944 E.48112
G3 X85.936 Y107.573 I1.895 J-1.063 E.01249
G1 X75.009 Y118.5 E.47594
G1 X74.964 Y118.011 E.01513
G1 X85.801 Y107.174 E.47203
G1 X85.774 Y107.082 E.00296
G3 X85.704 Y106.737 I4.44 J-1.084 E.01086
G1 X74.918 Y117.522 E.4698
G1 X74.873 Y117.033 E.01513
G1 X85.647 Y106.259 E.46931
G1 X85.644 Y106.226 E.00101
G3 X85.649 Y105.722 I11.116 J-.138 E.01552
G1 X74.827 Y116.544 E.47138
G1 X74.782 Y116.055 E.01513
G1 X85.737 Y105.1 E.47718
G3 X85.978 Y104.324 I4.288 J.909 E.02507
G1 X74.736 Y115.566 E.48968
G1 X74.691 Y115.077 E.01513
G1 X94.832 Y94.935 E.87732
G1 X95.367 Y94.935 E.01646
G1 X88.325 Y101.977 E.30671
G3 X89.103 Y101.734 I1.834 J4.508 E.02511
G1 X95.901 Y94.935 E.29614
G1 X96.436 Y94.935 E.01646
G1 X89.719 Y101.652 E.29256
G3 X90.258 Y101.648 I.293 J2.842 E.01662
G1 X96.97 Y94.935 E.29237
G1 X97.505 Y94.935 E.01646
G1 X90.735 Y101.705 E.29489
G3 X91.171 Y101.803 I-.291 J2.318 E.0138
G1 X98.04 Y94.935 E.29916
G1 X98.574 Y94.935 E.01646
G1 X91.573 Y101.937 E.30496
G3 X91.944 Y102.1 I-.67 J2.022 E.01251
G1 X99.109 Y94.935 E.31209
G1 X99.643 Y94.935 E.01646
G1 X92.288 Y102.291 E.32039
G3 X92.607 Y102.506 I-.998 J1.824 E.01188
G1 X100.178 Y94.935 E.32976
G1 X100.712 Y94.935 E.01646
G1 X92.903 Y102.745 E.34017
G1 X93.173 Y103.009 E.01164
G1 X101.247 Y94.935 E.35166
M73 P51 R14
G1 X101.781 Y94.935 E.01646
G1 X93.42 Y103.297 E.36421
G1 X93.472 Y103.359 E.00251
G3 X93.643 Y103.608 I-2.403 J1.832 E.00931
G1 X102.316 Y94.935 E.37778
G1 X102.85 Y94.935 E.01646
G1 X93.842 Y103.944 E.3924
G3 X94.014 Y104.306 I-1.805 J1.083 E.01237
G1 X103.385 Y94.935 E.40816
G1 X103.919 Y94.935 E.01646
G1 X94.158 Y104.697 E.4252
G3 X94.267 Y105.122 I-2.151 J.783 E.01353
G1 X104.454 Y94.935 E.44369
G1 X104.988 Y94.935 E.01646
G1 X94.337 Y105.586 E.46393
G3 X94.357 Y106.101 I-2.658 J.359 E.0159
G1 X105.523 Y94.935 E.48636
G1 X106.057 Y94.935 E.01646
G1 X94.306 Y106.687 E.51185
G3 X94.128 Y107.4 I-3.733 J-.556 E.02267
G1 X106.762 Y94.766 E.5503
G1 X92.05 Y102.604 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X90.526 Y102.067 I-2.096 J3.514 E.05398
G1 X86.068 Y106.524 E.20912
G2 X86.243 Y107.271 I7.58 J-1.382 E.02543
G1 X88.727 Y109.755 E.11654
G2 X90.316 Y109.952 I1.273 J-3.757 E.05349
G1 X93.953 Y106.315 E.17061
G3 X93.795 Y107.147 I-4.022 J-.332 E.02814
G1 X88.852 Y102.204 E.23188
G2 X87.433 Y102.976 I1.174 J3.85 E.05398
G1 X78.864 Y98.609 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42089
G1 F15000
G1 X77.972 Y99.501 E.03884
G1 X77.709 Y99.795 E.01215
G2 X77.083 Y100.925 I5.112 J3.568 E.03985
G1 X80.005 Y98.003 E.12726
G1 X81.876 Y96.667 E.07081
G1 X76.549 Y101.994 E.23203
G1 X76.014 Y103.063 E.03681
G1 X83.707 Y95.37 E.33506
G3 X84.541 Y95.017 I1.763 J3.005 E.02799
G1 X84.605 Y95.007 E.00199
G1 X75.48 Y104.132 E.39747
G1 X74.945 Y105.201 E.03681
G1 X85.21 Y94.937 E.44709
G3 X85.745 Y94.935 I.28 J5.357 E.01651
G1 X74.411 Y106.27 E.4937
G2 X74.086 Y107.129 I3.181 J1.694 E.02837
G1 X86.28 Y94.935 E.53114
G1 X86.814 Y94.935 E.01646
G1 X74.02 Y107.73 E.55729
G2 X74.054 Y108.23 I5.48 J-.118 E.01547
G1 X87.349 Y94.935 E.5791
G1 X87.883 Y94.935 E.01646
G1 X74.099 Y108.719 E.6004
G1 X74.145 Y109.209 E.01513
G1 X88.418 Y94.935 E.6217
G1 X88.953 Y94.935 E.01646
G1 X74.19 Y109.698 E.643
G1 X74.236 Y110.187 E.01513
G1 X89.487 Y94.935 E.66431
G1 X90.022 Y94.935 E.01646
G1 X74.281 Y110.676 E.68561
G1 X74.327 Y111.165 E.01513
G1 X90.556 Y94.935 E.70691
G1 X91.091 Y94.935 E.01646
G1 X74.372 Y111.654 E.72821
G1 X74.418 Y112.143 E.01513
G1 X91.625 Y94.935 E.74951
G1 X92.16 Y94.935 E.01646
G1 X74.463 Y112.632 E.77081
G1 X74.509 Y113.121 E.01513
G1 X92.694 Y94.935 E.79211
G1 X93.229 Y94.935 E.01646
G1 X74.554 Y113.61 E.81341
G1 X74.6 Y114.099 E.01513
G1 X93.763 Y94.935 E.83472
G1 X94.298 Y94.935 E.01646
G1 X74.489 Y114.744 E.86281
G1 X149.061 Y157.234 F30000
G1 F15000
G1 X161.983 Y144.312 E.56287
G2 X161.739 Y145.091 I4.048 J1.699 E.02519
G1 X149.765 Y157.065 E.52154
G1 X150.3 Y157.065 E.01646
G1 X161.65 Y145.714 E.49439
G2 X161.644 Y146.226 I10.263 J.375 E.01576
G1 X161.647 Y146.252 E.00081
G1 X150.834 Y157.065 E.47096
G1 X151.369 Y157.065 E.01646
G1 X161.703 Y146.731 E.45012
G2 X161.775 Y147.085 I3.543 J-.541 E.01114
G1 X161.801 Y147.167 E.00266
G1 X151.903 Y157.065 E.4311
G1 X152.438 Y157.065 E.01646
G1 X161.933 Y147.569 E.4136
G2 X162.074 Y147.901 I3.368 J-1.234 E.0111
G1 X162.096 Y147.941 E.00141
G1 X152.972 Y157.065 E.3974
G1 X153.507 Y157.065 E.01646
G1 X162.285 Y148.286 E.38237
G1 X162.502 Y148.604 E.01185
G1 X154.041 Y157.065 E.36853
G1 X154.576 Y157.065 E.01646
G1 X162.743 Y148.897 E.35576
G2 X163.008 Y149.168 I1.572 J-1.272 E.01166
G1 X155.11 Y157.065 E.34398
G1 X155.645 Y157.065 E.01646
G1 X163.295 Y149.415 E.33319
G2 X163.605 Y149.64 I1.329 J-1.51 E.01181
G1 X156.18 Y157.065 E.32342
G1 X156.714 Y157.065 E.01646
G1 X163.939 Y149.84 E.31471
G2 X164.214 Y149.979 I1.56 J-2.725 E.0095
G1 X164.3 Y150.013 E.00285
G1 X157.249 Y157.065 E.30714
G1 X157.783 Y157.065 E.01646
G1 X164.69 Y150.158 E.30086
G2 X165.116 Y150.266 I.681 J-1.785 E.01357
G1 X158.318 Y157.065 E.29613
G1 X158.852 Y157.065 E.01646
G1 X165.581 Y150.336 E.29308
G2 X166.091 Y150.361 I.36 J-2.178 E.01576
G1 X159.387 Y157.065 E.29202
G1 X159.921 Y157.065 E.01646
G1 X166.682 Y150.304 E.29448
G2 X167.381 Y150.138 I-.503 J-3.666 E.02215
G1 X160.286 Y157.234 E.30907
G1 X163.956 Y149.399 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X165.483 Y149.925 I2.005 J-3.347 E.05397
G1 X169.932 Y145.476 E.20872
G2 X169.757 Y144.729 I-4.425 J.644 E.02546
G1 X167.264 Y142.237 E.11694
G2 X165.684 Y142.048 I-1.245 J3.706 E.05316
G1 X162.047 Y145.685 E.17061
G3 X162.205 Y144.853 I4.02 J.332 E.02814
G1 X167.148 Y149.796 E.23188
G2 X168.567 Y149.024 I-1.174 J-3.85 E.05398
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X167.985 Y149.438 E-.27173
G1 X167.148 Y149.796 E-.34588
G1 X166.883 Y149.531 E-.1424
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 9/23
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2 I.019 J1.217 P1  F30000
G1 X178.355 Y149.348 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.074 J-1.095 E.04744
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.693 Y156.456 E.2771
G3 X169.418 Y157.398 I-2.287 J-2.305 E.08376
G1 X86.582 Y157.398 E2.74783
G3 X84.307 Y156.456 I.013 J-3.248 E.08376
G1 X78.401 Y150.549 E.2771
G3 X77.472 Y148.572 I2.319 J-2.296 E.0739
G1 X73.701 Y108.032 E1.35057
G3 X74.027 Y106.293 I3.277 J-.286 E.05944
G1 X77.113 Y100.12 E.22894
G3 X78.124 Y98.937 I2.968 J1.514 E.05208
G1 X83.353 Y95.202 E.21316
G3 X85.225 Y94.602 I1.872 J2.62 E.06628
G1 X170.799 Y94.603 E2.83864
G3 X172.647 Y95.202 I-.025 J3.226 E.06546
G1 X177.876 Y98.937 E.21317
G3 X178.887 Y100.12 I-1.958 J2.696 E.05208
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.95 J1.453 E.05943
G1 X178.528 Y148.572 E1.35058
G3 X178.374 Y149.291 I-3.248 J-.319 E.02447
M204 S250
G1 X178.722 Y149.495 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
M73 P52 R14
G1 X178.589 Y149.807 E.01043
G3 X177.88 Y150.823 I-3.315 J-1.557 E.03826
G1 X171.966 Y156.737 E.25698
G3 X169.423 Y157.79 I-2.563 J-2.591 E.08674
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.02 J-3.644 E.08673
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.613 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06149
G1 X76.765 Y99.94 E.21233
G3 X77.892 Y98.621 I3.328 J1.702 E.05383
G1 X83.129 Y94.88 E.19774
G3 X85.221 Y94.21 I2.096 J2.942 E.06858
G1 X170.804 Y94.211 E2.62972
G3 X172.871 Y94.88 I-.03 J3.618 E.06782
G1 X178.108 Y98.621 E.19775
G3 X179.235 Y99.94 I-2.2 J3.021 E.05382
G1 X182.326 Y106.121 E.21235
G3 X182.69 Y108.064 I-3.313 J1.627 E.06147
G1 X178.918 Y148.612 E1.25133
G3 X178.738 Y149.437 I-3.644 J-.362 E.026
; WIPE_START
M204 S10000
G1 X178.589 Y149.807 E-.15151
G1 X178.426 Y150.122 E-.13484
G1 X178.229 Y150.418 E-.13493
G1 X177.88 Y150.823 E-.20334
G1 X177.628 Y151.075 E-.13538
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I.866 J-.855 P1  F30000
G1 X168.352 Y141.68 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42087
G1 F15000
G1 X121.608 Y94.936 E2.03594
G1 X121.074 Y94.936 E.01646
G1 X167.19 Y141.052 E2.00859
G1 X166.544 Y140.94 E.02018
G1 X120.539 Y94.936 E2.00375
G1 X120.005 Y94.936 E.01646
G1 X165.98 Y140.911 E2.00247
G1 X165.473 Y140.938 E.01564
G1 X119.47 Y94.936 E2.00366
G1 X118.936 Y94.936 E.01646
G1 X165.009 Y141.008 E2.00671
G1 X164.579 Y141.113 E.01363
G1 X118.401 Y94.936 E2.01126
G1 X117.867 Y94.936 E.01646
G1 X164.179 Y141.247 E2.01711
G1 X163.805 Y141.408 E.01252
G1 X117.332 Y94.936 E2.02414
G1 X116.798 Y94.936 E.01646
G1 X163.454 Y141.592 E2.03212
G1 X163.127 Y141.799 E.01193
G1 X116.263 Y94.936 E2.04116
G1 X115.729 Y94.936 E.01646
G1 X162.819 Y142.026 E2.05102
G1 X162.533 Y142.274 E.01167
G1 X115.194 Y94.936 E2.06185
G1 X114.66 Y94.936 E.01646
G1 X162.265 Y142.541 E2.07346
G1 X162.019 Y142.829 E.01168
G1 X114.125 Y94.936 E2.08603
G1 X113.591 Y94.936 E.01646
G1 X161.791 Y143.136 E2.09939
G1 X161.587 Y143.466 E.01195
G1 X113.056 Y94.936 E2.11375
G1 X112.522 Y94.936 E.01646
G1 X161.402 Y143.816 E2.129
G1 X161.243 Y144.191 E.01255
G1 X111.987 Y94.935 E2.14534
G1 X111.453 Y94.935 E.01646
G1 X161.109 Y144.592 E2.1628
G1 X161.005 Y145.022 E.01363
G1 X110.918 Y94.935 E2.18153
G1 X110.384 Y94.935 E.01646
G1 X160.935 Y145.487 E2.20178
G1 X160.909 Y145.996 E.01568
G1 X109.849 Y94.935 E2.22393
G1 X109.315 Y94.935 E.01646
G1 X160.942 Y146.562 E2.24861
G1 X161.057 Y147.212 E.02032
G1 X108.78 Y94.935 E2.27691
G1 X108.246 Y94.935 E.01646
G1 X161.698 Y148.388 E2.32813
G1 X163.374 Y149.894 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X164.853 Y150.555 I2.754 J-4.182 E.05397
G1 X170.556 Y144.852 E.26752
G3 X170.684 Y145.656 I-6.377 J1.433 E.02704
G1 X166.343 Y141.315 E.20365
G1 X166.41 Y141.322 E.00223
G1 X161.321 Y146.411 E.23875
G3 X161.63 Y144.278 I4.855 J-.385 E.07208
G1 X167.723 Y150.371 E.28582
G2 X169.105 Y149.526 I-1.77 J-4.449 E.05401
G1 X148.096 Y157.234 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42087
G1 F15000
G1 X94.517 Y103.656 E2.33362
G1 X94.692 Y104.026 E.01262
G1 X94.879 Y104.553 E.01721
G1 X147.391 Y157.065 E2.28717
G1 X146.857 Y157.065 E.01646
G1 X95.034 Y105.241 E2.25717
G1 X95.086 Y105.829 E.01816
G1 X146.322 Y157.065 E2.23159
G1 X145.788 Y157.065 E.01646
G1 X95.077 Y106.354 E2.20873
G1 X95.021 Y106.832 E.01484
G1 X145.253 Y157.065 E2.18789
G1 X144.719 Y157.065 E.01646
G1 X94.928 Y107.274 E2.16864
G1 X94.803 Y107.683 E.01318
G1 X144.184 Y157.065 E2.15081
G1 X143.65 Y157.065 E.01646
G1 X94.651 Y108.066 E2.13415
G1 X94.476 Y108.425 E.01231
G1 X143.115 Y157.065 E2.11851
G1 X142.581 Y157.065 E.01646
G1 X94.276 Y108.76 E2.10393
G1 X94.057 Y109.075 E.01183
G1 X142.046 Y157.065 E2.09019
G1 X141.512 Y157.065 E.01646
G1 X93.815 Y109.368 E2.07744
G1 X93.556 Y109.643 E.01164
G1 X140.977 Y157.065 E2.06546
G1 X140.443 Y157.065 E.01646
G1 X93.274 Y109.896 E2.05444
G1 X92.975 Y110.131 E.01172
G1 X139.908 Y157.065 E2.04421
G1 X139.374 Y157.065 E.01646
G1 X92.652 Y110.343 E2.03496
G1 X92.31 Y110.536 E.01209
G1 X138.839 Y157.065 E2.02657
G1 X138.305 Y157.065 E.01646
G1 X91.944 Y110.703 E2.01927
G1 X91.552 Y110.847 E.01283
G1 X137.77 Y157.065 E2.01303
G1 X137.236 Y157.065 E.01646
G1 X91.134 Y110.963 E2.00798
G1 X90.681 Y111.044 E.01418
G1 X136.701 Y157.065 E2.00444
G1 X136.167 Y157.065 E.01646
G1 X90.188 Y111.086 E2.00261
G1 X89.645 Y111.078 E.01672
G1 X135.632 Y157.065 E2.00297
G1 X135.098 Y157.065 E.01646
G1 X89.029 Y110.996 E2.00654
G1 X88.626 Y110.901 E.01275
G1 X88.293 Y110.794 E.01076
G1 X134.563 Y157.065 E2.01531
G1 X134.029 Y157.065 E.01646
G1 X77.352 Y100.388 E2.46857
G3 X77.54 Y100.041 I3.689 J1.774 E.01215
G1 X85.205 Y107.706 E.33384
G1 X85.068 Y107.261 E.01433
G1 X85.004 Y106.97 E.00917
G1 X77.765 Y99.732 E.31527
G3 X78.022 Y99.455 I1.068 J.733 E.01169
G1 X84.923 Y106.356 E.30058
G1 X84.914 Y105.812 E.01675
G1 X78.314 Y99.212 E.28745
G3 X78.625 Y98.989 I1.689 J2.02 E.0118
G1 X84.956 Y105.32 E.27576
G1 X85.039 Y104.867 E.01416
G1 X78.937 Y98.766 E.26576
G1 X79.249 Y98.543 E.0118
G1 X85.153 Y104.447 E.25716
G1 X85.296 Y104.056 E.01284
G1 X79.561 Y98.32 E.24981
G1 X79.872 Y98.098 E.0118
G1 X85.465 Y103.69 E.24359
G1 X85.656 Y103.347 E.01211
G1 X80.184 Y97.875 E.23831
G1 X80.496 Y97.652 E.0118
G1 X85.87 Y103.026 E.23407
G1 X86.103 Y102.725 E.01174
G1 X80.808 Y97.43 E.23064
G1 X81.12 Y97.207 E.0118
G1 X86.358 Y102.445 E.22817
G1 X86.631 Y102.184 E.01164
G1 X81.431 Y96.984 E.22647
G1 X81.743 Y96.761 E.0118
G1 X86.926 Y101.944 E.22574
G1 X87.239 Y101.723 E.01181
G1 X82.055 Y96.539 E.22581
G1 X82.367 Y96.316 E.0118
G1 X87.576 Y101.525 E.22689
G1 X87.934 Y101.348 E.01229
G1 X82.679 Y96.093 E.22888
G1 X82.99 Y95.871 E.0118
G1 X88.317 Y101.197 E.23199
G1 X88.727 Y101.073 E.0132
G1 X83.302 Y95.648 E.23628
G3 X83.617 Y95.428 I2.491 J3.236 E.01183
G1 X89.168 Y100.979 E.24176
G1 X89.646 Y100.922 E.01482
G1 X83.959 Y95.236 E.24767
G3 X84.34 Y95.082 I.725 J1.244 E.01269
G1 X90.171 Y100.913 E.25398
G1 X90.76 Y100.968 E.01823
G1 X84.77 Y94.978 E.26089
G3 X85.262 Y94.935 I.56 J3.588 E.01521
G1 X91.448 Y101.121 E.26941
G1 X91.864 Y101.263 E.01355
G1 X92.342 Y101.481 E.01617
G1 X85.797 Y94.935 E.28508
G1 X86.331 Y94.935 E.01646
G1 X148.46 Y157.065 E2.70605
G1 X148.995 Y157.065 E.01646
G1 X86.866 Y94.935 E2.70605
G1 X87.4 Y94.935 E.01646
G1 X149.529 Y157.065 E2.70605
G1 X150.064 Y157.065 E.01646
G1 X87.935 Y94.935 E2.70605
G1 X88.469 Y94.935 E.01646
G1 X150.598 Y157.065 E2.70605
G1 X151.133 Y157.065 E.01646
G1 X89.004 Y94.935 E2.70605
G1 X89.538 Y94.935 E.01646
G1 X151.667 Y157.065 E2.70605
M73 P53 R14
G1 X152.202 Y157.065 E.01646
G1 X90.073 Y94.935 E2.70605
G1 X90.607 Y94.935 E.01646
G1 X152.736 Y157.065 E2.70605
G1 X153.271 Y157.065 E.01646
G1 X91.142 Y94.935 E2.70605
G1 X91.676 Y94.935 E.01646
G1 X153.805 Y157.065 E2.70605
G1 X154.34 Y157.065 E.01646
G1 X92.211 Y94.935 E2.70605
G1 X92.745 Y94.935 E.01646
G1 X154.874 Y157.065 E2.70605
G1 X155.409 Y157.065 E.01646
G1 X93.28 Y94.935 E2.70605
G1 X93.814 Y94.935 E.01646
G1 X155.943 Y157.065 E2.70605
G1 X156.478 Y157.065 E.01646
G1 X94.349 Y94.935 E2.70605
G1 X94.883 Y94.935 E.01646
G1 X157.012 Y157.065 E2.70605
G1 X157.547 Y157.065 E.01646
G1 X95.418 Y94.935 E2.70605
G1 X95.952 Y94.935 E.01646
G1 X158.081 Y157.065 E2.70605
G1 X158.616 Y157.065 E.01646
G1 X96.487 Y94.935 E2.70605
G1 X97.021 Y94.935 E.01646
G1 X159.15 Y157.065 E2.70605
G1 X159.685 Y157.065 E.01646
G1 X97.556 Y94.935 E2.70605
G1 X98.09 Y94.935 E.01646
G1 X160.219 Y157.065 E2.70605
G1 X160.754 Y157.065 E.01646
G1 X98.625 Y94.935 E2.70605
G1 X99.159 Y94.935 E.01646
G1 X161.288 Y157.065 E2.70605
G1 X161.823 Y157.065 E.01646
G1 X99.694 Y94.935 E2.70605
G1 X100.228 Y94.935 E.01646
G1 X162.357 Y157.065 E2.70605
G1 X162.892 Y157.065 E.01646
G1 X100.763 Y94.935 E2.70605
G1 X101.297 Y94.935 E.01646
G1 X163.426 Y157.065 E2.70605
G1 X163.961 Y157.065 E.01646
G1 X101.832 Y94.935 E2.70605
G1 X102.366 Y94.935 E.01646
G1 X164.495 Y157.065 E2.70605
G1 X165.03 Y157.065 E.01646
G1 X102.901 Y94.935 E2.70605
G1 X103.435 Y94.935 E.01646
G1 X165.564 Y157.065 E2.70605
G1 X166.099 Y157.065 E.01646
G1 X103.97 Y94.935 E2.70605
G1 X104.504 Y94.935 E.01646
G1 X166.633 Y157.065 E2.70605
G1 X167.168 Y157.065 E.01646
G1 X105.039 Y94.935 E2.70605
G1 X105.573 Y94.935 E.01646
G1 X167.702 Y157.065 E2.70605
G1 X168.237 Y157.065 E.01646
G1 X106.108 Y94.935 E2.70605
G1 X106.642 Y94.935 E.01646
G1 X168.771 Y157.065 E2.70605
G1 X169.306 Y157.065 E.01646
G1 X107.177 Y94.935 E2.70605
G1 X107.711 Y94.935 E.01646
G1 X169.808 Y157.032 E2.70463
G2 X170.247 Y156.936 I-.105 J-1.531 E.01388
G1 X163.983 Y150.672 E.27284
G1 X164.375 Y150.824 E.01296
G1 X164.788 Y150.943 E.01322
G1 X170.634 Y156.789 E.25464
G2 X170.979 Y156.599 I-.467 J-1.257 E.01216
G1 X165.437 Y151.058 E.24135
G1 X166.003 Y151.089 E.01744
G1 X171.287 Y156.374 E.23017
G2 X171.563 Y156.114 I-2.508 J-2.939 E.01165
G1 X166.512 Y151.063 E.22
G1 X166.977 Y150.994 E.0145
G1 X171.83 Y155.847 E.21136
G1 X172.097 Y155.58 E.01164
G1 X167.409 Y150.891 E.20421
G1 X167.809 Y150.757 E.01301
G1 X172.364 Y155.312 E.1984
G1 X172.631 Y155.045 E.01164
G1 X168.183 Y150.597 E.19373
G1 X168.535 Y150.414 E.01221
G1 X172.898 Y154.778 E.19004
G1 X173.165 Y154.51 E.01164
G1 X168.863 Y150.207 E.1874
G1 X169.172 Y149.982 E.01178
G1 X173.433 Y154.243 E.18559
G1 X173.7 Y153.975 E.01164
G1 X169.458 Y149.734 E.18475
G1 X169.727 Y149.468 E.01164
G1 X173.967 Y153.708 E.18469
G1 X174.234 Y153.441 E.01164
G1 X169.973 Y149.18 E.18558
G1 X170.202 Y148.874 E.01176
G1 X174.501 Y153.173 E.18726
G1 X174.768 Y152.906 E.01164
G1 X170.407 Y148.545 E.18995
G1 X170.592 Y148.196 E.01217
G1 X175.035 Y152.638 E.19351
G1 X175.302 Y152.371 E.01164
G1 X170.752 Y147.821 E.19818
G1 X170.887 Y147.421 E.013
G1 X175.57 Y152.104 E.20396
G1 X175.837 Y151.836 E.01164
G1 X170.993 Y146.992 E.21099
G1 X171.063 Y146.528 E.01446
G1 X176.104 Y151.569 E.21957
G1 X176.371 Y151.302 E.01164
G1 X171.09 Y146.021 E.23001
G1 X171.061 Y145.457 E.01739
G1 X176.638 Y151.034 E.24292
G1 X176.905 Y150.767 E.01164
G1 X170.948 Y144.81 E.25945
G1 X170.863 Y144.495 E.01004
G1 X170.687 Y144.014 E.01577
G1 X177.172 Y150.499 E.28246
G1 X177.439 Y150.232 E.01164
G1 X122.143 Y94.936 E2.40845
G1 X122.677 Y94.936 E.01646
G1 X177.676 Y149.935 E2.39549
G2 X177.881 Y149.605 I-2.307 J-1.664 E.01196
G1 X123.212 Y94.936 E2.38114
G1 X123.746 Y94.936 E.01646
G1 X178.045 Y149.234 E2.36497
G2 X178.151 Y148.806 I-1.659 J-.639 E.01362
G1 X124.281 Y94.936 E2.34632
G1 X124.815 Y94.936 E.01646
G1 X178.215 Y148.336 E2.32585
G1 X178.261 Y147.847 E.01513
G1 X125.35 Y94.936 E2.30455
G1 X125.884 Y94.936 E.01646
G1 X178.306 Y147.358 E2.28325
G1 X178.352 Y146.869 E.01513
G1 X126.419 Y94.936 E2.26195
G1 X126.953 Y94.936 E.01646
G1 X178.397 Y146.38 E2.24065
G1 X178.443 Y145.891 E.01513
G1 X127.488 Y94.936 E2.21935
G1 X128.022 Y94.936 E.01646
G1 X178.488 Y145.402 E2.19805
G1 X178.534 Y144.913 E.01513
G1 X128.557 Y94.936 E2.17675
G1 X129.091 Y94.936 E.01646
M73 P54 R14
G1 X178.579 Y144.424 E2.15545
G1 X178.625 Y143.934 E.01513
G1 X129.626 Y94.936 E2.13415
G1 X130.161 Y94.936 E.01646
G1 X178.67 Y143.445 E2.11285
G1 X178.716 Y142.956 E.01513
G1 X130.695 Y94.936 E2.09155
G1 X131.23 Y94.936 E.01646
G1 X178.761 Y142.467 E2.07026
G1 X178.807 Y141.978 E.01513
G1 X131.764 Y94.936 E2.04896
G1 X132.299 Y94.936 E.01646
G1 X178.852 Y141.489 E2.02766
G1 X178.898 Y141 E.01513
G1 X132.833 Y94.936 E2.00636
G1 X133.368 Y94.936 E.01646
G1 X178.943 Y140.511 E1.98506
G1 X178.989 Y140.022 E.01513
G1 X133.902 Y94.936 E1.96376
G1 X134.437 Y94.936 E.01646
G1 X179.034 Y139.533 E1.94246
G1 X179.08 Y139.044 E.01513
G1 X134.971 Y94.936 E1.92116
G1 X135.506 Y94.936 E.01646
G1 X179.125 Y138.555 E1.89986
G1 X179.171 Y138.066 E.01513
G1 X136.04 Y94.936 E1.87856
G1 X136.575 Y94.936 E.01646
G1 X179.216 Y137.577 E1.85726
G1 X179.262 Y137.088 E.01513
G1 X137.109 Y94.936 E1.83596
G1 X137.644 Y94.936 E.01646
G1 X179.307 Y136.599 E1.81467
G1 X179.353 Y136.11 E.01513
G1 X138.178 Y94.936 E1.79337
G1 X138.713 Y94.936 E.01646
G1 X179.398 Y135.621 E1.77207
G1 X179.444 Y135.132 E.01513
G1 X139.247 Y94.936 E1.75077
G1 X139.782 Y94.936 E.01646
G1 X179.489 Y134.643 E1.72947
G1 X179.535 Y134.154 E.01513
G1 X140.316 Y94.936 E1.70817
G1 X140.851 Y94.936 E.01646
G1 X179.58 Y133.665 E1.68687
G1 X179.626 Y133.176 E.01513
G1 X141.385 Y94.936 E1.66557
G1 X141.92 Y94.936 E.01646
G1 X179.671 Y132.687 E1.64427
G1 X179.717 Y132.198 E.01513
G1 X142.454 Y94.936 E1.62297
G1 X142.989 Y94.936 E.01646
G1 X179.762 Y131.709 E1.60167
G1 X179.808 Y131.22 E.01513
G1 X143.523 Y94.936 E1.58037
G1 X144.058 Y94.936 E.01646
G1 X179.853 Y130.731 E1.55908
G1 X179.899 Y130.242 E.01513
G1 X144.592 Y94.936 E1.53778
G1 X145.127 Y94.936 E.01646
G1 X179.944 Y129.753 E1.51648
G1 X179.99 Y129.264 E.01513
G1 X145.661 Y94.936 E1.49518
G1 X146.196 Y94.936 E.01646
G1 X180.035 Y128.775 E1.47388
G1 X180.081 Y128.286 E.01513
G1 X146.73 Y94.936 E1.45258
G1 X147.265 Y94.936 E.01646
G1 X180.282 Y127.953 E1.43807
G1 X178.768 Y100.249 F30000
G1 F15000
G1 X177.901 Y99.381 E.03778
G1 X177.676 Y99.204 E.00882
G1 X175.976 Y97.991 E.06432
G1 X178.923 Y100.938 E.12835
G1 X179.456 Y102.005 E.03675
G1 X174.111 Y96.66 E.2328
G1 X172.279 Y95.363 E.06912
G1 X179.989 Y103.073 E.33579
G1 X180.522 Y104.141 E.03675
G1 X171.391 Y95.009 E.39771
G2 X170.783 Y94.936 I-.808 J4.135 E.01888
G1 X181.055 Y105.208 E.44741
G1 X181.588 Y106.276 E.03675
G1 X170.248 Y94.936 E.49391
G1 X169.714 Y94.936 E.01646
G1 X181.914 Y107.136 E.53136
G3 X181.98 Y107.736 I-3.357 J.673 E.01863
G1 X169.179 Y94.936 E.55751
G1 X168.645 Y94.936 E.01646
G1 X181.946 Y108.237 E.57931
G1 X181.9 Y108.726 E.01513
G1 X168.11 Y94.936 E.60061
G1 X167.576 Y94.936 E.01646
G1 X181.855 Y109.215 E.62191
G1 X181.809 Y109.704 E.01513
G1 X167.041 Y94.936 E.64321
G1 X166.507 Y94.936 E.01646
G1 X181.764 Y110.193 E.66451
G1 X181.718 Y110.682 E.01513
G1 X165.972 Y94.936 E.68581
G1 X165.438 Y94.936 E.01646
G1 X181.673 Y111.171 E.70711
G1 X181.627 Y111.66 E.01513
G1 X164.903 Y94.936 E.72841
G1 X164.369 Y94.936 E.01646
G1 X181.582 Y112.149 E.74971
G1 X181.536 Y112.638 E.01513
G1 X163.834 Y94.936 E.77101
G1 X163.3 Y94.936 E.01646
G1 X181.491 Y113.127 E.79231
G1 X181.445 Y113.616 E.01513
G1 X162.765 Y94.936 E.8136
G1 X162.231 Y94.936 E.01646
G1 X181.4 Y114.105 E.8349
G1 X181.354 Y114.594 E.01513
G1 X170.615 Y103.855 E.46775
G1 X170.785 Y104.263 E.01363
G1 X170.919 Y104.693 E.01386
G1 X181.309 Y115.083 E.45253
G1 X181.263 Y115.572 E.01513
G1 X171.048 Y105.357 E.44492
M73 P54 R13
G1 X171.089 Y105.932 E.01776
G1 X181.218 Y116.061 E.44116
G1 X181.172 Y116.55 E.01513
G1 X171.07 Y106.447 E.44002
G1 X171.006 Y106.918 E.01462
G1 X181.127 Y117.039 E.44082
G1 X181.081 Y117.528 E.01513
G1 X170.906 Y107.353 E.44318
G1 X170.777 Y107.758 E.0131
G1 X181.036 Y118.017 E.44682
G1 X180.99 Y118.506 E.01513
G1 X170.62 Y108.135 E.45169
G1 X170.439 Y108.489 E.01224
G1 X180.945 Y118.995 E.45758
G1 X180.899 Y119.484 E.01513
G1 X170.236 Y108.821 E.46443
G1 X170.012 Y109.131 E.01179
G1 X180.854 Y119.973 E.47221
G1 X180.808 Y120.462 E.01513
G1 X169.768 Y109.421 E.48087
G1 X169.503 Y109.691 E.01164
G1 X180.763 Y120.951 E.49041
G1 X180.717 Y121.44 E.01513
G1 X169.219 Y109.942 E.5008
G1 X168.915 Y110.172 E.01175
G1 X180.672 Y121.929 E.51208
G1 X180.626 Y122.418 E.01513
G1 X168.59 Y110.381 E.52425
G1 X168.242 Y110.568 E.01215
G1 X180.581 Y122.907 E.5374
G1 X180.535 Y123.396 E.01513
G1 X167.873 Y110.733 E.55152
G1 X167.475 Y110.871 E.01294
G1 X180.49 Y123.885 E.56685
G1 X180.444 Y124.374 E.01513
G1 X167.05 Y110.98 E.58339
G1 X166.591 Y111.055 E.01432
G1 X180.399 Y124.863 E.6014
G1 X180.353 Y125.352 E.01513
G1 X166.091 Y111.089 E.62123
G1 X165.535 Y111.068 E.01712
G1 X180.308 Y125.841 E.64344
G1 X180.262 Y126.33 E.01513
G1 X164.903 Y110.97 E.669
M73 P55 R13
G1 X164.618 Y110.899 E.00905
G1 X164.134 Y110.736 E.01571
G1 X180.217 Y126.819 E.70049
G1 X180.172 Y127.308 E.01513
G1 X147.799 Y94.936 E1.40998
G1 X148.334 Y94.936 E.01646
G1 X161.266 Y107.868 E.56328
G1 X161.135 Y107.497 E.01214
G1 X161.031 Y107.098 E.01269
G1 X148.868 Y94.936 E.52974
G1 X149.403 Y94.936 E.01646
G1 X160.932 Y106.465 E.50214
G1 X160.912 Y105.91 E.01708
G1 X149.937 Y94.936 E.47799
G1 X150.472 Y94.936 E.01646
G1 X160.945 Y105.409 E.45617
G1 X161.02 Y104.949 E.01435
G1 X151.006 Y94.936 E.43615
G1 X151.541 Y94.936 E.01646
G1 X161.129 Y104.524 E.41761
G1 X161.268 Y104.128 E.01291
G1 X152.075 Y94.936 E.40038
G1 X152.61 Y94.936 E.01646
G1 X161.431 Y103.757 E.38421
G1 X161.619 Y103.41 E.01214
G1 X153.144 Y94.936 E.36911
G1 X153.679 Y94.936 E.01646
G1 X161.828 Y103.085 E.35494
G1 X162.058 Y102.781 E.01175
G1 X154.213 Y94.936 E.34169
G1 X154.748 Y94.936 E.01646
G1 X162.308 Y102.496 E.3293
G1 X162.579 Y102.232 E.01164
G1 X155.282 Y94.936 E.3178
G1 X155.817 Y94.936 E.01646
G1 X162.869 Y101.988 E.30715
G1 X163.179 Y101.764 E.01179
G1 X156.351 Y94.936 E.2974
G1 X156.886 Y94.936 E.01646
G1 X163.511 Y101.561 E.28855
G1 X163.864 Y101.38 E.01223
G1 X157.42 Y94.936 E.28068
G1 X157.955 Y94.936 E.01646
G1 X164.243 Y101.224 E.27388
G1 X164.647 Y101.093 E.01307
G1 X158.489 Y94.936 E.26818
G1 X159.024 Y94.936 E.01646
G1 X165.082 Y100.994 E.26385
G1 X165.553 Y100.93 E.01464
G1 X159.558 Y94.936 E.26109
G1 X160.093 Y94.936 E.01646
G1 X166.068 Y100.911 E.26025
G1 X166.642 Y100.95 E.01771
G1 X160.627 Y94.936 E.26196
G1 X161.162 Y94.936 E.01646
G1 X167.308 Y101.081 E.26768
G1 X167.625 Y101.176 E.01021
G1 X168.145 Y101.385 E.01725
G1 X161.527 Y94.766 E.28827
G1 X169.105 Y102.474 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X167.723 Y101.629 I-3.152 J3.603 E.05401
G1 X161.63 Y107.722 E.28582
G3 X161.321 Y105.589 I4.546 J-1.748 E.07208
G1 X166.411 Y110.679 E.23879
G1 X166.342 Y110.686 E.00229
G1 X170.684 Y106.344 E.2037
G3 X170.556 Y107.148 I-6.504 J-.628 E.02704
G1 X164.853 Y101.445 E.26753
G2 X163.374 Y102.106 I1.275 J4.842 E.05397
G1 X133.664 Y157.234 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42087
G1 F15000
G1 X77.174 Y100.744 E2.46044
G1 X76.996 Y101.1 E.01227
G1 X132.96 Y157.065 E2.43753
G1 X132.425 Y157.065 E.01646
G1 X76.817 Y101.457 E2.42201
G1 X76.639 Y101.813 E.01227
G1 X131.891 Y157.065 E2.40649
G1 X131.356 Y157.065 E.01646
G1 X76.461 Y102.169 E2.39097
G1 X76.283 Y102.526 E.01227
G1 X130.822 Y157.065 E2.37545
G1 X130.287 Y157.065 E.01646
G1 X76.105 Y102.882 E2.35993
G1 X75.927 Y103.238 E.01227
G1 X129.753 Y157.065 E2.34441
G1 X129.218 Y157.065 E.01646
G1 X75.748 Y103.595 E2.32889
G1 X75.57 Y103.951 E.01227
G1 X128.684 Y157.065 E2.31337
G1 X128.149 Y157.065 E.01646
G1 X75.392 Y104.307 E2.29785
G1 X75.214 Y104.664 E.01227
G1 X127.615 Y157.065 E2.28233
G1 X127.08 Y157.065 E.01646
G1 X75.036 Y105.02 E2.26681
G1 X74.858 Y105.376 E.01227
G1 X126.546 Y157.065 E2.25129
G1 X126.011 Y157.065 E.01646
G1 X74.679 Y105.733 E2.23577
G1 X74.501 Y106.089 E.01227
G1 X125.477 Y157.065 E2.22025
G1 X124.942 Y157.065 E.01646
G1 X74.323 Y106.446 E2.20471
G2 X74.169 Y106.826 I1.955 J1.014 E.01266
G1 X124.408 Y157.065 E2.18815
G1 X123.873 Y157.065 E.01646
G1 X74.062 Y107.253 E2.16955
G2 X74.021 Y107.747 I3.583 J.545 E.01527
G1 X123.339 Y157.065 E2.14805
G1 X122.804 Y157.065 E.01646
G1 X74.062 Y108.323 E2.12296
G1 X74.117 Y108.912 E.01823
G1 X122.27 Y157.065 E2.09729
G1 X121.735 Y157.065 E.01646
G1 X74.172 Y109.501 E2.07162
G1 X74.227 Y110.091 E.01823
G1 X121.201 Y157.065 E2.04596
G1 X120.666 Y157.065 E.01646
G1 X74.282 Y110.68 E2.02029
G1 X74.337 Y111.269 E.01823
G1 X120.132 Y157.065 E1.99462
G1 X119.597 Y157.065 E.01646
G1 X74.391 Y111.859 E1.96895
G1 X74.446 Y112.448 E.01823
G1 X119.063 Y157.065 E1.94328
G1 X118.528 Y157.065 E.01646
G1 X74.501 Y113.037 E1.91761
G1 X74.556 Y113.627 E.01823
G1 X117.994 Y157.065 E1.89195
G1 X117.459 Y157.065 E.01646
G1 X74.611 Y114.216 E1.86628
G1 X74.665 Y114.805 E.01823
G1 X116.925 Y157.065 E1.84061
G1 X116.39 Y157.065 E.01646
G1 X74.72 Y115.395 E1.81494
G1 X74.775 Y115.984 E.01823
G1 X115.856 Y157.065 E1.78928
G1 X115.321 Y157.065 E.01646
G1 X74.83 Y116.573 E1.76361
G1 X74.885 Y117.163 E.01823
G1 X114.787 Y157.065 E1.73794
G1 X114.252 Y157.065 E.01646
G1 X74.94 Y117.752 E1.71227
G1 X74.994 Y118.341 E.01823
G1 X113.718 Y157.065 E1.6866
G1 X113.183 Y157.065 E.01646
G1 X75.049 Y118.931 E1.66094
G1 X75.104 Y119.52 E.01823
G1 X112.649 Y157.065 E1.63527
G1 X112.114 Y157.065 E.01646
G1 X75.159 Y120.109 E1.6096
G1 X75.214 Y120.699 E.01823
G1 X111.58 Y157.065 E1.58393
G1 X111.045 Y157.065 E.01646
G1 X75.268 Y121.288 E1.55826
G1 X75.323 Y121.877 E.01823
G1 X110.511 Y157.065 E1.53259
G1 X109.976 Y157.065 E.01646
G1 X75.378 Y122.467 E1.50693
G1 X75.433 Y123.056 E.01823
G1 X109.442 Y157.065 E1.48126
G1 X108.907 Y157.065 E.01646
G1 X75.488 Y123.645 E1.45559
G1 X75.543 Y124.235 E.01823
G1 X108.373 Y157.065 E1.42992
G1 X107.838 Y157.065 E.01646
G1 X94.604 Y143.831 E.5764
G1 X94.782 Y144.255 E.01417
G1 X94.914 Y144.675 E.01355
G1 X107.304 Y157.065 E.53965
G1 X106.769 Y157.065 E.01646
G1 X95.046 Y145.342 E.51059
G1 X95.089 Y145.919 E.01781
G1 X106.235 Y157.065 E.48547
G1 X105.7 Y157.065 E.01646
G1 X95.071 Y146.435 E.46297
G1 X95.008 Y146.907 E.01465
G1 X105.166 Y157.065 E.44244
G1 X104.631 Y157.065 E.01646
G1 X94.909 Y147.342 E.42346
G1 X94.781 Y147.749 E.01312
G1 X104.097 Y157.065 E.40576
G1 X103.562 Y157.065 E.01646
G1 X94.624 Y148.126 E.38932
G1 X94.444 Y148.481 E.01225
G1 X103.028 Y157.065 E.37387
G1 X102.493 Y157.065 E.01646
G1 X94.241 Y148.813 E.35941
G1 X94.018 Y149.124 E.0118
G1 X101.959 Y157.065 E.34586
G1 X101.424 Y157.065 E.01646
G1 X93.774 Y149.415 E.33321
G1 X93.51 Y149.685 E.01164
G1 X100.89 Y157.065 E.32141
G1 X100.355 Y157.065 E.01646
G1 X93.226 Y149.936 E.31049
G1 X92.923 Y150.167 E.01175
G1 X99.821 Y157.065 E.30045
G1 X99.286 Y157.065 E.01646
G1 X92.598 Y150.376 E.29131
G1 X92.251 Y150.564 E.01214
G1 X98.752 Y157.065 E.28313
G1 X98.217 Y157.065 E.01646
G1 X91.882 Y150.729 E.27593
G1 X91.485 Y150.867 E.01293
G1 X97.683 Y157.065 E.26992
G1 X97.148 Y157.065 E.01646
G1 X91.061 Y150.977 E.26513
G1 X90.603 Y151.054 E.0143
G1 X96.614 Y157.065 E.26179
G1 X96.079 Y157.065 E.01646
G1 X90.104 Y151.089 E.26027
G1 X89.549 Y151.069 E.01708
G1 X95.545 Y157.065 E.26113
G1 X95.01 Y157.065 E.01646
G1 X88.919 Y150.973 E.26531
G1 X88.617 Y150.899 E.00957
G1 X88.155 Y150.744 E.01501
G1 X94.476 Y157.065 E.27529
G1 X93.941 Y157.065 E.01646
G1 X77.023 Y140.146 E.73689
G1 X77.078 Y140.736 E.01823
G1 X93.407 Y157.065 E.71122
G1 X92.872 Y157.065 E.01646
G1 X77.132 Y141.325 E.68555
G1 X77.187 Y141.914 E.01823
G1 X92.338 Y157.065 E.65988
G1 X91.803 Y157.065 E.01646
G1 X77.242 Y142.504 E.63421
G1 X77.297 Y143.093 E.01823
G1 X91.269 Y157.065 E.60855
G1 X90.734 Y157.065 E.01646
M73 P56 R13
G1 X77.352 Y143.682 E.58288
G1 X77.406 Y144.271 E.01823
G1 X90.2 Y157.065 E.55721
G1 X89.665 Y157.065 E.01646
G1 X77.461 Y144.861 E.53154
G1 X77.516 Y145.45 E.01823
G1 X89.131 Y157.065 E.50587
G1 X88.596 Y157.065 E.01646
G1 X77.571 Y146.039 E.48021
G1 X77.626 Y146.629 E.01823
G1 X88.062 Y157.065 E.45454
G1 X87.527 Y157.065 E.01646
G1 X77.681 Y147.218 E.42887
G1 X77.735 Y147.807 E.01823
G1 X86.993 Y157.065 E.4032
G3 X86.451 Y157.058 I-.201 J-5.591 E.01668
G1 X77.79 Y148.397 E.37724
G2 X77.897 Y149.038 I3.938 J-.325 E.02003
G1 X85.816 Y156.957 E.34491
G3 X84.648 Y156.319 I.719 J-2.707 E.04137
G1 X77.926 Y149.601 E.29269
G1 X85.588 Y148.177 F30000
G1 F15000
G1 X76.968 Y139.557 E.37544
G1 X76.913 Y138.968 E.01823
G1 X85.027 Y147.081 E.3534
G1 X84.93 Y146.45 E.01966
G1 X76.858 Y138.378 E.35158
G1 X76.803 Y137.789 E.01823
G1 X84.912 Y145.897 E.35317
G1 X84.947 Y145.398 E.01543
G1 X76.749 Y137.2 E.35707
G1 X76.694 Y136.61 E.01823
G1 X85.022 Y144.939 E.36275
G1 X85.132 Y144.514 E.01352
G1 X76.639 Y136.021 E.3699
G1 X76.584 Y135.432 E.01823
G1 X85.271 Y144.119 E.37837
G1 X85.435 Y143.748 E.01248
G1 X76.529 Y134.842 E.38791
G1 X76.475 Y134.253 E.01823
G1 X85.624 Y143.402 E.39849
G1 X85.833 Y143.077 E.01191
G1 X76.42 Y133.664 E.41002
G1 X76.365 Y133.074 E.01823
G1 X86.064 Y142.773 E.42245
G1 X86.315 Y142.49 E.01166
G1 X76.31 Y132.485 E.43576
G1 X76.255 Y131.896 E.01823
G1 X86.585 Y142.226 E.44993
G1 X86.876 Y141.982 E.01168
G1 X76.2 Y131.306 E.46498
G1 X76.146 Y130.717 E.01823
G1 X87.187 Y141.759 E.48091
G1 X87.519 Y141.556 E.01198
G1 X76.091 Y130.128 E.49777
G1 X76.036 Y129.538 E.01823
G1 X87.873 Y141.376 E.51558
G1 X88.252 Y141.22 E.01262
G1 X75.981 Y128.949 E.53448
G1 X75.926 Y128.36 E.01823
G1 X88.657 Y141.091 E.55449
G1 X89.093 Y140.991 E.01375
G1 X75.872 Y127.77 E.57584
G1 X75.817 Y127.181 E.01823
G1 X89.565 Y140.929 E.5988
G1 X90.081 Y140.911 E.01591
G1 X75.762 Y126.592 E.62367
G1 X75.707 Y126.002 E.01823
G1 X90.657 Y140.953 E.65115
G1 X91.325 Y141.086 E.02098
G1 X75.652 Y125.413 E.68263
G1 X75.597 Y124.824 E.01823
G1 X92.593 Y141.819 E.74024
G1 X86.895 Y149.526 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X88.277 Y150.371 I3.152 J-3.603 E.05401
G1 X94.37 Y144.278 E.28582
G3 X94.679 Y146.411 I-4.546 J1.748 E.07209
G1 X89.589 Y141.321 E.23879
G1 X89.658 Y141.314 E.00229
G1 X85.316 Y145.656 E.20369
G3 X85.444 Y144.852 I6.504 J.628 E.02704
G1 X91.147 Y150.555 E.26752
G2 X92.626 Y149.894 I-1.275 J-4.842 E.05397
G1 X92.626 Y102.106 F30000
G1 F15476.087
G2 X91.147 Y101.445 I-2.754 J4.18 E.05397
G1 X85.444 Y107.148 E.26752
G3 X85.316 Y106.344 I6.374 J-1.432 E.02704
G1 X89.658 Y110.686 E.2037
G1 X89.589 Y110.679 E.00229
G1 X94.679 Y105.589 E.23879
G3 X94.37 Y107.722 I-4.856 J.385 E.07209
G1 X88.277 Y101.629 E.28582
G2 X86.895 Y102.474 I1.77 J4.448 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X87.451 Y102.053 E-.26509
G1 X88.277 Y101.629 E-.35291
G1 X88.541 Y101.893 E-.142
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/23
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.2 I-.569 J1.076 P1  F30000
G1 X178.347 Y149.379 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X178.343 Y149.38 E.00012
G3 X177.6 Y150.549 I-3.062 J-1.126 E.04632
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27713
G3 X169.418 Y157.398 I-2.287 J-2.306 E.08374
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.013 J-3.248 E.08375
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.571 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35056
G3 X74.027 Y106.293 I3.277 J-.286 E.05944
G1 X77.113 Y100.12 E.22895
G3 X78.124 Y98.937 I2.968 J1.514 E.05207
G1 X83.353 Y95.202 E.21319
G3 X85.225 Y94.602 I1.871 J2.62 E.06626
G1 X170.81 Y94.603 E2.83899
G3 X172.647 Y95.202 I-.031 J3.212 E.0651
G1 X177.876 Y98.937 E.21319
G3 X178.887 Y100.12 I-1.958 J2.696 E.05207
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.951 J1.454 E.05943
G1 X178.528 Y148.571 E1.35057
G3 X178.446 Y149.046 I-3.247 J-.318 E.01599
G1 X178.364 Y149.321 E.00954
M204 S250
G1 X178.721 Y149.494 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.712 Y149.512 E.00062
G3 X177.88 Y150.823 I-3.437 J-1.262 E.04807
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.562 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.02 J-3.644 E.08673
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.572 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21234
G3 X77.892 Y98.621 I3.328 J1.702 E.05382
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.096 J2.941 E.06858
G1 X170.814 Y94.211 E2.63005
G3 X172.871 Y94.88 I-.036 J3.605 E.0675
G1 X178.108 Y98.621 E.19775
G3 X179.235 Y99.94 I-2.2 J3.022 E.05382
G1 X182.326 Y106.121 E.21235
G3 X182.69 Y108.064 I-3.313 J1.627 E.06147
G1 X178.918 Y148.612 E1.25133
G3 X178.827 Y149.139 I-3.644 J-.362 E.01644
G1 X178.738 Y149.436 E.00952
; WIPE_START
M204 S10000
G1 X178.712 Y149.512 E-.03044
G1 X178.593 Y149.809 E-.12155
G1 X178.407 Y150.152 E-.14831
G1 X178.229 Y150.418 E-.12152
G1 X177.88 Y150.823 E-.20322
G1 X177.629 Y151.074 E-.13496
; WIPE_END
G1 E-.04 F1800
G1 X178.236 Y143.466 Z2.4 F30000
G1 X181.252 Y105.636 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.525 Y104.179 E.05401
G1 X127.654 Y157.05 E2.48026
G1 X128.346 Y157.05 E.02295
G1 X75.474 Y104.178 E2.48034
G1 X74.746 Y105.634 E.05401
G1 X76.402 Y133.314 F30000
G1 F15476.087
G1 X76.251 Y131.693 E.05401
G1 X112.994 Y94.951 E1.72365
G1 X112.302 Y94.951 E.02293
G1 X172.503 Y155.152 E2.82415
G1 X176.34 Y151.312 E.18005
G1 X119.979 Y94.951 E2.64401
G1 X120.67 Y94.951 E.02292
G1 X76.905 Y138.715 E2.0531
G1 X76.658 Y136.066 E.08827
G1 X97.642 Y157.05 E.98439
G1 X96.95 Y157.05 E.02295
G1 X159.049 Y94.951 E2.91318
G1 X158.359 Y94.951 E.0229
G1 X181.055 Y117.647 E1.06474
G1 X180.916 Y119.139 E.0497
G1 X143.006 Y157.05 E1.77845
G1 X143.698 Y157.05 E.02295
G1 X82.726 Y96.078 E2.86031
G1 X78.254 Y99.282 E.18249
G1 X136.022 Y157.05 E2.71001
G1 X135.33 Y157.05 E.02295
G1 X181.704 Y110.676 E2.17548
G1 X166.035 Y94.951 E.73638
G1 X166.725 Y94.951 E.02289
G1 X104.626 Y157.05 E2.91317
G1 X105.318 Y157.05 E.02295
G1 X75.871 Y127.603 E1.38142
G1 X75.598 Y124.67 E.0977
G1 X105.318 Y94.951 E1.39421
G1 X104.626 Y94.951 E.02293
G1 X166.726 Y157.05 E2.9132
G1 X166.034 Y157.05 E.02295
G1 X178.554 Y144.529 E.58737
G1 X178.442 Y145.738 E.04028
G1 X127.655 Y94.951 E2.38255
G1 X128.345 Y94.951 E.02292
G1 X77.558 Y145.738 E2.38254
G1 X77.446 Y144.529 E.04028
G1 X89.966 Y157.05 E.58737
G1 X89.274 Y157.05 E.02295
G1 X151.373 Y94.951 E2.91318
G1 X150.683 Y94.951 E.0229
G1 X180.402 Y124.67 E1.39419
G1 X180.129 Y127.603 E.0977
G1 X150.682 Y157.05 E1.38142
G1 X151.374 Y157.05 E.02295
G1 X89.274 Y94.95 E2.91321
G1 X89.966 Y94.95 E.02294
G1 X74.296 Y110.676 E.73641
G1 X120.67 Y157.05 E2.17548
G1 X119.978 Y157.05 E.02295
G1 X177.748 Y99.28 E2.71011
G1 X173.272 Y96.08 E.18252
G1 X112.302 Y157.05 E2.86021
G1 X112.994 Y157.05 E.02295
G1 X75.084 Y119.139 E1.77845
G1 X74.945 Y117.647 E.04971
G1 X97.642 Y94.95 E1.06476
G1 X96.95 Y94.95 E.02294
G1 X159.05 Y157.05 E2.9132
G1 X158.358 Y157.05 E.02295
G1 X179.342 Y136.066 E.98439
G1 X179.095 Y138.716 E.08827
G1 X135.331 Y94.951 E2.05309
G1 X136.021 Y94.951 E.02291
G1 X79.659 Y151.314 E2.64409
G1 X83.498 Y155.15 E.18005
G1 X143.697 Y94.951 E2.82405
G1 X143.007 Y94.951 E.02291
G1 X179.749 Y131.693 E1.72364
G1 X179.598 Y133.314 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X179.749 Y131.693 E-.61876
G1 X179.486 Y131.43 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 11/23
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.4 I-1.215 J-.077 P1  F30000
G1 X178.354 Y149.348 Z2.4
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.074 J-1.095 E.04743
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27712
G3 X169.418 Y157.398 I-2.287 J-2.305 E.08374
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.013 J-3.248 E.08375
G1 X78.401 Y150.549 E.2771
G3 X77.472 Y148.572 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35057
G3 X74.027 Y106.293 I3.277 J-.286 E.05944
G1 X77.113 Y100.12 E.22894
G3 X78.124 Y98.937 I2.952 J1.5 E.0521
G1 X83.353 Y95.202 E.21318
G3 X85.225 Y94.602 I1.871 J2.62 E.06626
G1 X170.82 Y94.603 E2.83934
G3 X172.647 Y95.202 I-.048 J3.232 E.06474
G1 X177.876 Y98.937 E.21317
G3 X178.887 Y100.12 I-1.958 J2.697 E.05209
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.937 J1.451 E.05943
G1 X178.528 Y148.572 E1.35058
G3 X178.374 Y149.292 I-3.248 J-.319 E.02448
M204 S250
G1 X178.723 Y149.492 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.589 Y149.807 E.01051
G3 X177.88 Y150.823 I-3.315 J-1.557 E.03824
G1 X171.966 Y156.737 E.25699
G3 X169.423 Y157.79 I-2.562 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.02 J-3.644 E.08673
G1 X78.12 Y150.823 E.25698
G3 X77.082 Y148.613 I2.606 J-2.573 E.07651
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21234
G3 X77.892 Y98.621 I3.311 J1.688 E.05383
G1 X83.129 Y94.88 E.19774
G3 X85.221 Y94.21 I2.096 J2.942 E.06858
G1 X170.825 Y94.211 E2.63038
G3 X172.871 Y94.88 I-.053 J3.625 E.06716
M73 P57 R13
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.2 J3.022 E.05383
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.298 J1.624 E.06148
G1 X178.918 Y148.613 E1.25133
G3 X178.739 Y149.435 I-3.644 J-.362 E.02592
; WIPE_START
M204 S10000
G1 X178.589 Y149.807 E-.15245
G1 X178.426 Y150.122 E-.13485
G1 X178.229 Y150.418 E-.13499
G1 X177.88 Y150.823 E-.20315
G1 X177.63 Y151.073 E-.13457
; WIPE_END
G1 E-.04 F1800
G1 X178.47 Y143.487 Z2.6 F30000
G1 X179.598 Y133.314 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.749 Y131.693 E.05401
G1 X143.007 Y94.951 E1.72363
G1 X143.697 Y94.951 E.0229
G1 X83.498 Y155.15 E2.82404
G1 X79.659 Y151.314 E.18005
G1 X136.021 Y94.951 E2.64409
G1 X135.331 Y94.951 E.0229
G1 X179.095 Y138.716 E2.05309
G1 X179.342 Y136.066 E.08827
G1 X158.358 Y157.05 E.98439
G1 X159.05 Y157.05 E.02295
G1 X96.95 Y94.95 E2.9132
G1 X97.642 Y94.95 E.02294
G1 X74.945 Y117.647 E1.06476
G1 X75.084 Y119.139 E.04971
G1 X112.994 Y157.05 E1.77845
G1 X112.302 Y157.05 E.02295
G1 X173.272 Y96.08 E2.86021
G1 X177.748 Y99.28 E.18252
G1 X119.978 Y157.05 E2.71011
G1 X120.67 Y157.05 E.02295
G1 X74.296 Y110.676 E2.17548
G1 X89.966 Y94.95 E.73641
G1 X89.274 Y94.95 E.02294
G1 X151.374 Y157.05 E2.91321
G1 X150.682 Y157.05 E.02295
G1 X180.129 Y127.603 E1.38142
G1 X180.402 Y124.67 E.0977
G1 X150.683 Y94.951 E1.39418
G1 X151.373 Y94.951 E.02289
G1 X89.274 Y157.05 E2.91317
G1 X89.966 Y157.05 E.02295
G1 X77.446 Y144.529 E.58736
G1 X77.558 Y145.738 E.04028
G1 X128.345 Y94.951 E2.38254
G1 X127.655 Y94.951 E.02291
G1 X178.442 Y145.738 E2.38254
G1 X178.555 Y144.529 E.04028
G1 X166.034 Y157.05 E.58737
G1 X166.726 Y157.05 E.02295
G1 X104.627 Y94.951 E2.9132
G1 X105.318 Y94.951 E.02293
G1 X75.598 Y124.67 E1.39421
G1 X75.871 Y127.603 E.0977
G1 X105.318 Y157.05 E1.38142
G1 X104.626 Y157.05 E.02295
G1 X166.725 Y94.951 E2.91316
G1 X166.035 Y94.951 E.02288
G1 X181.704 Y110.676 E.73637
G1 X135.33 Y157.05 E2.17548
G1 X136.022 Y157.05 E.02295
G1 X78.254 Y99.282 E2.71001
G1 X82.726 Y96.078 E.18249
G1 X143.698 Y157.05 E2.86031
G1 X143.006 Y157.05 E.02295
G1 X180.916 Y119.139 E1.77845
G1 X181.055 Y117.647 E.0497
G1 X158.359 Y94.951 E1.06473
G1 X159.049 Y94.951 E.02288
G1 X96.95 Y157.05 E2.91317
G1 X97.642 Y157.05 E.02295
G1 X76.658 Y136.066 E.98439
G1 X76.905 Y138.715 E.08827
G1 X120.669 Y94.951 E2.05309
G1 X119.979 Y94.951 E.02292
G1 X176.34 Y151.312 E2.64401
G1 X172.503 Y155.152 E.18005
G1 X112.303 Y94.951 E2.82415
G1 X112.994 Y94.951 E.02292
G1 X76.251 Y131.693 E1.72365
G1 X76.402 Y133.314 E.05401
G1 X74.746 Y105.634 F30000
G1 F15476.087
G1 X75.474 Y104.178 E.05401
G1 X128.346 Y157.05 E2.48034
G1 X127.654 Y157.05 E.02295
G1 X180.525 Y104.179 E2.48026
G1 X181.252 Y105.636 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X180.525 Y104.179 E-.61876
G1 X180.262 Y104.442 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/23
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.6 I-1.216 J-.052 P1  F30000
G1 X178.347 Y149.374 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X178.336 Y149.399 E.00091
G3 X177.6 Y150.549 I-3.055 J-1.146 E.04562
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27713
G3 X169.418 Y157.398 I-2.287 J-2.306 E.08374
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.013 J-3.249 E.08375
G1 X78.401 Y150.549 E.2771
G3 X77.472 Y148.571 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35058
G3 X74.027 Y106.293 I3.277 J-.286 E.05943
G1 X77.113 Y100.12 E.22895
G3 X78.124 Y98.937 I2.969 J1.514 E.05208
G1 X83.353 Y95.202 E.21318
G3 X85.225 Y94.602 I1.871 J2.62 E.06626
G1 X170.831 Y94.603 E2.8397
G3 X172.647 Y95.202 I-.051 J3.21 E.0644
G1 X177.876 Y98.937 E.21316
G3 X178.887 Y100.12 I-1.958 J2.697 E.0521
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.95 J1.453 E.05942
G1 X178.528 Y148.571 E1.35058
G3 X178.446 Y149.046 I-3.248 J-.318 E.01598
G1 X178.364 Y149.317 E.0094
M204 S250
G1 X178.721 Y149.491 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.704 Y149.532 E.00138
G3 X177.88 Y150.823 I-3.43 J-1.282 E.0474
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.562 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.02 J-3.645 E.08673
G1 X78.12 Y150.823 E.25698
G3 X77.082 Y148.612 I2.606 J-2.573 E.07651
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21234
G3 X77.892 Y98.621 I3.327 J1.702 E.05382
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.096 J2.941 E.06858
G1 X170.836 Y94.211 E2.6307
G3 X172.871 Y94.88 I-.056 J3.602 E.06684
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.2 J3.022 E.05384
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.313 J1.627 E.06147
G1 X178.918 Y148.612 E1.25133
G3 X178.827 Y149.139 I-3.644 J-.362 E.01644
G1 X178.738 Y149.433 E.00943
; WIPE_START
M204 S10000
G1 X178.704 Y149.532 E-.03979
G1 X178.593 Y149.809 E-.11331
G1 X178.426 Y150.122 E-.13496
G1 X178.229 Y150.418 E-.13493
G1 X177.88 Y150.823 E-.20316
G1 X177.631 Y151.072 E-.13386
; WIPE_END
G1 E-.04 F1800
G1 X178.237 Y143.464 Z2.8 F30000
G1 X181.252 Y105.636 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.525 Y104.179 E.05401
G1 X127.654 Y157.05 E2.48026
M73 P57 R12
G1 X128.346 Y157.05 E.02295
G1 X75.474 Y104.178 E2.48034
G1 X74.746 Y105.634 E.05401
G1 X76.402 Y133.314 F30000
G1 F15476.087
G1 X76.251 Y131.693 E.05401
G1 X112.994 Y94.951 E1.72365
M73 P58 R12
G1 X112.303 Y94.951 E.02292
G1 X172.503 Y155.152 E2.82414
G1 X176.34 Y151.312 E.18005
G1 X119.979 Y94.951 E2.644
G1 X120.669 Y94.951 E.02291
G1 X76.905 Y138.716 E2.05309
G1 X76.658 Y136.066 E.08827
G1 X97.642 Y157.05 E.98439
G1 X96.95 Y157.05 E.02295
G1 X159.049 Y94.951 E2.91316
G1 X158.359 Y94.951 E.02287
G1 X181.055 Y117.647 E1.06472
G1 X180.916 Y119.139 E.0497
G1 X143.006 Y157.05 E1.77845
G1 X143.698 Y157.05 E.02295
G1 X82.726 Y96.078 E2.86031
G1 X78.254 Y99.282 E.18249
G1 X136.022 Y157.05 E2.71001
G1 X135.33 Y157.05 E.02295
G1 X181.704 Y110.676 E2.17548
G1 X166.035 Y94.952 E.73636
G1 X166.724 Y94.952 E.02286
G1 X104.626 Y157.05 E2.91315
G1 X105.318 Y157.05 E.02295
G1 X75.871 Y127.603 E1.38142
G1 X75.598 Y124.67 E.0977
G1 X105.318 Y94.951 E1.3942
G1 X104.627 Y94.951 E.02292
G1 X166.726 Y157.05 E2.91319
G1 X166.034 Y157.05 E.02295
G1 X178.555 Y144.529 E.58737
G1 X178.442 Y145.738 E.04028
G1 X127.655 Y94.951 E2.38253
G1 X128.345 Y94.951 E.0229
G1 X77.558 Y145.738 E2.38253
G1 X77.446 Y144.529 E.04028
G1 X89.966 Y157.05 E.58736
G1 X89.274 Y157.05 E.02295
G1 X151.373 Y94.951 E2.91316
G1 X150.683 Y94.951 E.02288
G1 X180.402 Y124.67 E1.39417
G1 X180.129 Y127.603 E.0977
G1 X150.682 Y157.05 E1.38142
G1 X151.374 Y157.05 E.02295
G1 X89.274 Y94.95 E2.91321
G1 X89.966 Y94.95 E.02294
G1 X74.296 Y110.676 E.73641
G1 X120.67 Y157.05 E2.17548
G1 X119.978 Y157.05 E.02295
G1 X177.748 Y99.28 E2.71011
G1 X173.272 Y96.08 E.18252
G1 X112.302 Y157.05 E2.86021
G1 X112.994 Y157.05 E.02295
G1 X75.084 Y119.139 E1.77845
G1 X74.945 Y117.647 E.04971
G1 X97.642 Y94.951 E1.06476
G1 X96.95 Y94.951 E.02293
G1 X159.05 Y157.05 E2.9132
G1 X158.358 Y157.05 E.02295
G1 X179.342 Y136.066 E.98439
G1 X179.095 Y138.716 E.08827
G1 X135.331 Y94.951 E2.05308
G1 X136.021 Y94.951 E.02289
G1 X79.659 Y151.314 E2.64408
G1 X83.498 Y155.15 E.18005
G1 X143.697 Y94.951 E2.82404
G1 X143.007 Y94.951 E.02289
G1 X179.749 Y131.693 E1.72363
G1 X179.598 Y133.314 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X179.749 Y131.693 E-.61876
G1 X179.486 Y131.43 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/23
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.8 I-1.215 J-.077 P1  F30000
G1 X178.354 Y149.348 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.074 J-1.096 E.04743
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27711
G3 X169.418 Y157.398 I-2.287 J-2.305 E.08375
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.013 J-3.249 E.08375
G1 X78.401 Y150.549 E.2771
G3 X77.472 Y148.571 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35058
G3 X74.027 Y106.293 I3.277 J-.286 E.05944
G1 X77.113 Y100.12 E.22893
G3 X78.124 Y98.937 I2.943 J1.491 E.05209
G1 X83.353 Y95.202 E.21319
G3 X85.229 Y94.602 I1.87 J2.617 E.06638
G1 X170.842 Y94.604 E2.83994
G3 X172.647 Y95.202 I-.062 J3.208 E.06404
G1 X177.876 Y98.937 E.21317
G3 X178.887 Y100.12 I-1.956 J2.695 E.05209
G1 X181.973 Y106.292 E.22893
G3 X182.299 Y108.032 I-2.95 J1.454 E.05944
G1 X178.528 Y148.571 E1.35058
G3 X178.374 Y149.292 I-3.248 J-.319 E.02449
M204 S250
G1 X178.724 Y149.49 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.589 Y149.807 E.0106
G3 X177.88 Y150.823 I-3.315 J-1.557 E.03824
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.562 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.02 J-3.645 E.08673
G1 X78.12 Y150.823 E.25698
G3 X77.082 Y148.612 I2.606 J-2.573 E.07651
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21234
G3 X77.892 Y98.621 I3.301 J1.679 E.05383
G1 X83.129 Y94.88 E.19775
G3 X85.222 Y94.21 I2.095 J2.939 E.06861
G1 X170.846 Y94.212 E2.631
G3 X172.871 Y94.88 I-.066 J3.601 E.06651
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.199 J3.021 E.05383
G1 X182.326 Y106.121 E.21233
G3 X182.69 Y108.064 I-3.312 J1.627 E.06149
G1 X178.918 Y148.612 E1.25133
G3 X178.74 Y149.432 I-3.644 J-.362 E.02584
; WIPE_START
M204 S10000
G1 X178.589 Y149.807 E-.15351
G1 X178.426 Y150.122 E-.13484
G1 X178.229 Y150.418 E-.13492
G1 X177.88 Y150.823 E-.20318
G1 X177.632 Y151.071 E-.13356
; WIPE_END
G1 E-.04 F1800
G1 X178.472 Y143.485 Z3 F30000
G1 X179.598 Y133.314 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.749 Y131.693 E.05401
G1 X143.007 Y94.951 E1.72362
G1 X143.697 Y94.951 E.02287
G1 X83.498 Y155.15 E2.82403
G1 X79.659 Y151.314 E.18005
G1 X136.021 Y94.951 E2.64407
G1 X135.331 Y94.951 E.02288
G1 X179.095 Y138.716 E2.05307
G1 X179.342 Y136.066 E.08827
G1 X158.358 Y157.05 E.98439
G1 X159.05 Y157.05 E.02295
G1 X96.951 Y94.951 E2.9132
G1 X97.642 Y94.951 E.02293
G1 X74.945 Y117.647 E1.06476
G1 X75.084 Y119.139 E.04971
G1 X112.994 Y157.05 E1.77845
G1 X112.302 Y157.05 E.02295
G1 X173.272 Y96.08 E2.86021
G1 X177.748 Y99.28 E.18252
G1 X119.978 Y157.05 E2.71011
G1 X120.67 Y157.05 E.02295
G1 X74.296 Y110.676 E2.17548
G1 X89.966 Y94.95 E.73641
G1 X89.274 Y94.95 E.02294
G1 X151.374 Y157.05 E2.91321
G1 X150.682 Y157.05 E.02295
G1 X180.129 Y127.603 E1.38142
G1 X180.402 Y124.67 E.0977
G1 X150.683 Y94.952 E1.39416
G1 X151.373 Y94.952 E.02287
G1 X89.274 Y157.05 E2.91315
G1 X89.966 Y157.05 E.02295
G1 X77.446 Y144.529 E.58736
G1 X77.558 Y145.738 E.04028
G1 X128.345 Y94.951 E2.38253
G1 X127.655 Y94.951 E.02289
G1 X178.442 Y145.738 E2.38253
G1 X178.554 Y144.529 E.04028
G1 X166.034 Y157.05 E.58737
G1 X166.726 Y157.05 E.02295
G1 X104.627 Y94.951 E2.91319
G1 X105.318 Y94.951 E.02292
G1 X75.598 Y124.67 E1.3942
G1 X75.871 Y127.603 E.0977
G1 X105.318 Y157.05 E1.38142
G1 X104.626 Y157.05 E.02295
G1 X166.724 Y94.952 E2.91314
G1 X166.035 Y94.952 E.02285
G1 X181.704 Y110.676 E.73635
G1 X135.33 Y157.05 E2.17548
G1 X136.022 Y157.05 E.02295
G1 X78.254 Y99.282 E2.71001
G1 X82.726 Y96.078 E.18249
G1 X143.698 Y157.05 E2.86031
G1 X143.006 Y157.05 E.02295
G1 X180.916 Y119.139 E1.77845
G1 X181.055 Y117.647 E.0497
G1 X158.359 Y94.952 E1.06471
G1 X159.048 Y94.952 E.02286
G1 X96.95 Y157.05 E2.91314
G1 X97.642 Y157.05 E.02295
G1 X76.658 Y136.066 E.98439
G1 X76.905 Y138.716 E.08827
G1 X120.669 Y94.951 E2.05308
G1 X119.979 Y94.951 E.0229
G1 X176.34 Y151.312 E2.644
G1 X172.503 Y155.152 E.18005
G1 X112.303 Y94.951 E2.82414
G1 X112.993 Y94.951 E.02291
M73 P59 R12
G1 X76.251 Y131.693 E1.72364
G1 X76.402 Y133.314 E.05401
G1 X74.746 Y105.634 F30000
G1 F15476.087
G1 X75.474 Y104.178 E.05401
G1 X128.346 Y157.05 E2.48034
G1 X127.654 Y157.05 E.02295
G1 X180.525 Y104.179 E2.48026
G1 X181.252 Y105.636 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X180.525 Y104.179 E-.61876
G1 X180.262 Y104.442 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/23
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3 I-1.216 J-.052 P1  F30000
G1 X178.354 Y149.348 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.074 J-1.096 E.04743
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27711
G3 X169.418 Y157.398 I-2.287 J-2.305 E.08375
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I-.004 J-3.208 E.0838
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.571 I2.319 J-2.296 E.0739
G1 X73.701 Y108.032 E1.35058
G3 X74.027 Y106.292 I3.277 J-.286 E.05944
G1 X77.113 Y100.12 E.22892
G3 X78.124 Y98.937 I2.893 J1.449 E.05212
G1 X83.353 Y95.202 E.21319
G3 X85.225 Y94.602 I1.883 J2.656 E.06624
G1 X170.852 Y94.604 E2.8404
G3 X172.647 Y95.202 I-.092 J3.267 E.06365
G1 X177.876 Y98.937 E.21317
G3 X178.887 Y100.12 I-1.882 J2.632 E.05212
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.924 J1.449 E.05944
G1 X178.528 Y148.572 E1.35058
G3 X178.374 Y149.292 I-3.248 J-.319 E.02448
M204 S250
G1 X178.724 Y149.488 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.589 Y149.807 E.01064
G3 X177.88 Y150.823 I-3.314 J-1.557 E.03824
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.562 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.001 J-3.6 E.08679
G1 X78.12 Y150.823 E.25698
G3 X77.834 Y150.499 I2.767 J-2.732 E.0133
G3 X77.155 Y149.067 I2.949 J-2.276 E.04907
G3 X77.082 Y148.612 I3.773 J-.837 E.01415
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21234
G3 X77.892 Y98.621 I3.242 J1.629 E.05385
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.109 J2.983 E.06855
G1 X170.857 Y94.212 E2.63136
G3 X172.871 Y94.88 I-.099 J3.667 E.06615
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.114 J2.949 E.05386
G1 X182.326 Y106.121 E.21235
G3 X182.69 Y108.064 I-3.285 J1.621 E.06148
G1 X178.918 Y148.613 E1.25133
G3 X178.74 Y149.431 I-3.644 J-.362 E.0258
; WIPE_START
M204 S10000
G1 X178.589 Y149.807 E-.15403
G1 X178.426 Y150.122 E-.13479
G1 X178.229 Y150.418 E-.13494
G1 X177.88 Y150.823 E-.2032
G1 X177.633 Y151.07 E-.13304
; WIPE_END
G1 E-.04 F1800
G1 X178.239 Y143.462 Z3.2 F30000
G1 X181.252 Y105.636 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.525 Y104.179 E.05401
G1 X127.654 Y157.05 E2.48026
G1 X128.346 Y157.05 E.02295
G1 X75.474 Y104.178 E2.48034
G1 X74.746 Y105.634 E.05401
G1 X76.402 Y133.314 F30000
G1 F15476.087
G1 X76.251 Y131.693 E.05401
G1 X112.993 Y94.951 E1.72364
G1 X112.303 Y94.951 E.02291
G1 X172.503 Y155.152 E2.82414
G1 X176.34 Y151.312 E.18005
G1 X119.979 Y94.951 E2.64399
G1 X120.669 Y94.951 E.0229
G1 X76.905 Y138.715 E2.05308
G1 X76.658 Y136.066 E.08827
G1 X97.642 Y157.05 E.98439
G1 X96.95 Y157.05 E.02295
G1 X159.048 Y94.952 E2.91313
G1 X158.36 Y94.952 E.02284
G1 X181.055 Y117.647 E1.0647
G1 X180.916 Y119.139 E.0497
G1 X143.006 Y157.05 E1.77845
G1 X143.698 Y157.05 E.02295
G1 X82.726 Y96.078 E2.86031
G1 X78.254 Y99.282 E.18249
G1 X136.022 Y157.05 E2.71001
G1 X135.33 Y157.05 E.02295
G1 X181.704 Y110.676 E2.17548
G1 X166.036 Y94.952 E.73633
G1 X166.724 Y94.952 E.02283
G1 X104.626 Y157.05 E2.91313
G1 X105.318 Y157.05 E.02295
G1 X75.871 Y127.603 E1.38142
G1 X75.598 Y124.67 E.0977
G1 X105.318 Y94.951 E1.3942
G1 X104.627 Y94.951 E.02292
G1 X166.726 Y157.05 E2.91319
G1 X166.034 Y157.05 E.02295
G1 X178.554 Y144.529 E.58737
G1 X178.442 Y145.738 E.04028
G1 X127.655 Y94.951 E2.38252
G1 X128.345 Y94.951 E.02288
G1 X77.558 Y145.738 E2.38252
G1 X77.446 Y144.529 E.04028
G1 X89.966 Y157.05 E.58736
G1 X89.274 Y157.05 E.02295
G1 X151.372 Y94.952 E2.91314
G1 X150.683 Y94.952 E.02285
G1 X180.402 Y124.67 E1.39415
G1 X180.129 Y127.603 E.0977
G1 X150.682 Y157.05 E1.38142
G1 X151.374 Y157.05 E.02295
G1 X89.274 Y94.95 E2.9132
G1 X89.966 Y94.95 E.02294
G1 X74.296 Y110.676 E.73641
G1 X120.67 Y157.05 E2.17548
G1 X119.978 Y157.05 E.02295
G1 X177.748 Y99.28 E2.71011
G1 X173.272 Y96.08 E.18252
G1 X112.302 Y157.05 E2.86021
G1 X112.994 Y157.05 E.02295
G1 X75.084 Y119.139 E1.77845
G1 X74.945 Y117.647 E.04971
G1 X97.642 Y94.951 E1.06476
G1 X96.951 Y94.951 E.02293
G1 X159.05 Y157.05 E2.9132
G1 X158.358 Y157.05 E.02295
G1 X179.342 Y136.066 E.98439
G1 X179.095 Y138.716 E.08827
G1 X135.331 Y94.951 E2.05306
G1 X136.021 Y94.951 E.02287
G1 X79.659 Y151.314 E2.64407
G1 X83.498 Y155.15 E.18005
G1 X143.697 Y94.952 E2.82402
G1 X143.007 Y94.952 E.02286
G1 X179.749 Y131.693 E1.72361
G1 X179.598 Y133.314 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X179.749 Y131.693 E-.61876
G1 X179.486 Y131.43 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 15/23
; update layer progress
M73 L15
M991 S0 P14 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.2 I-1.215 J-.077 P1  F30000
G1 X178.357 Y149.349 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.032 J-1.075 E.04747
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27711
G3 X169.418 Y157.398 I-2.272 J-2.27 E.08379
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.006 J-3.232 E.08377
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.571 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35056
G3 X74.027 Y106.292 I3.277 J-.286 E.05944
G1 X77.113 Y100.119 E.22894
G3 X78.124 Y98.937 I2.893 J1.449 E.0521
G1 X83.353 Y95.202 E.21319
G3 X85.225 Y94.602 I1.871 J2.62 E.06626
G1 X170.863 Y94.604 E2.84076
G3 X172.647 Y95.202 I-.103 J3.269 E.06331
G1 X177.876 Y98.937 E.21316
G3 X178.887 Y100.12 I-1.958 J2.697 E.05209
G1 X181.973 Y106.292 E.22892
G3 X182.299 Y108.032 I-2.884 J1.441 E.05948
G1 X178.528 Y148.571 E1.35058
G3 X178.377 Y149.293 I-3.203 J-.297 E.0245
M204 S250
G1 X178.725 Y149.487 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.592 Y149.808 E.01069
G3 X177.88 Y150.823 I-3.266 J-1.534 E.03828
G1 X171.966 Y156.737 E.25699
G3 X169.423 Y157.79 I-2.546 J-2.551 E.08678
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.012 J-3.627 E.08676
M73 P60 R12
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21234
G3 X77.892 Y98.621 I3.242 J1.629 E.05384
G1 X83.129 Y94.88 E.19775
G3 X84.619 Y94.261 I2.143 J3.056 E.04995
G3 X85.221 Y94.21 I.726 J4.943 E.01858
G1 X170.868 Y94.212 E2.63169
G3 X172.871 Y94.88 I-.11 J3.668 E.06582
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.2 J3.022 E.05384
G1 X182.326 Y106.121 E.21233
G3 X182.69 Y108.064 I-3.316 J1.627 E.06148
G1 X178.918 Y148.612 E1.25133
G3 X178.744 Y149.43 I-3.593 J-.338 E.02574
; WIPE_START
M204 S10000
G1 X178.592 Y149.808 E-.15495
G1 X178.426 Y150.122 E-.13488
G1 X178.229 Y150.418 E-.13493
G1 X177.88 Y150.823 E-.20332
G1 X177.635 Y151.069 E-.13192
; WIPE_END
G1 E-.04 F1800
G1 X178.473 Y143.482 Z3.4 F30000
G1 X179.598 Y133.314 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.749 Y131.693 E.05401
G1 X143.007 Y94.952 E1.7236
G1 X143.696 Y94.952 E.02285
G1 X83.498 Y155.15 E2.82401
G1 X79.659 Y151.314 E.18005
G1 X136.021 Y94.952 E2.64406
G1 X135.331 Y94.952 E.02286
G1 X179.095 Y138.716 E2.05306
G1 X179.342 Y136.066 E.08827
G1 X158.358 Y157.05 E.98439
G1 X159.05 Y157.05 E.02295
G1 X96.951 Y94.951 E2.9132
G1 X97.642 Y94.951 E.02293
G1 X74.945 Y117.647 E1.06475
G1 X75.084 Y119.139 E.04971
G1 X112.994 Y157.05 E1.77845
G1 X112.302 Y157.05 E.02295
G1 X173.272 Y96.08 E2.86021
G1 X177.748 Y99.28 E.18252
G1 X119.978 Y157.05 E2.71011
G1 X120.67 Y157.05 E.02295
G1 X74.296 Y110.676 E2.17548
G1 X89.966 Y94.95 E.73641
G1 X89.274 Y94.95 E.02294
G1 X151.374 Y157.05 E2.9132
G1 X150.682 Y157.05 E.02295
G1 X180.129 Y127.603 E1.38142
G1 X180.402 Y124.67 E.0977
G1 X150.684 Y94.952 E1.39414
G1 X151.372 Y94.952 E.02284
G1 X89.274 Y157.05 E2.91313
G1 X89.966 Y157.05 E.02295
G1 X77.446 Y144.529 E.58737
G1 X77.558 Y145.738 E.04028
G1 X128.345 Y94.951 E2.38251
G1 X127.655 Y94.951 E.02288
G1 X178.442 Y145.738 E2.38252
G1 X178.555 Y144.529 E.04028
G1 X166.034 Y157.05 E.58737
G1 X166.726 Y157.05 E.02295
G1 X104.627 Y94.951 E2.91319
G1 X105.317 Y94.951 E.02291
G1 X75.598 Y124.67 E1.39419
G1 X75.871 Y127.603 E.0977
G1 X105.318 Y157.05 E1.38142
G1 X104.626 Y157.05 E.02295
G1 X166.724 Y94.952 E2.91312
G1 X166.036 Y94.952 E.02281
G1 X181.704 Y110.676 E.73632
G1 X135.33 Y157.05 E2.17548
G1 X136.022 Y157.05 E.02295
G1 X78.254 Y99.282 E2.71001
G1 X82.726 Y96.078 E.18249
G1 X143.698 Y157.05 E2.86031
G1 X143.006 Y157.05 E.02295
G1 X180.916 Y119.139 E1.77845
G1 X181.055 Y117.647 E.0497
G1 X158.36 Y94.952 E1.06469
G1 X159.048 Y94.952 E.02283
G1 X96.95 Y157.05 E2.91312
G1 X97.642 Y157.05 E.02295
G1 X76.658 Y136.066 E.98439
G1 X76.905 Y138.716 E.08827
G1 X120.669 Y94.951 E2.05307
G1 X119.979 Y94.951 E.02289
G1 X176.34 Y151.312 E2.64399
G1 X172.503 Y155.152 E.18005
G1 X112.303 Y94.951 E2.82413
G1 X112.993 Y94.951 E.0229
G1 X76.251 Y131.693 E1.72363
G1 X76.402 Y133.314 E.05401
G1 X74.746 Y105.634 F30000
G1 F15476.087
G1 X75.474 Y104.178 E.05401
G1 X128.346 Y157.05 E2.48034
G1 X127.654 Y157.05 E.02295
G1 X180.525 Y104.179 E2.48026
G1 X181.252 Y105.636 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X180.525 Y104.179 E-.61876
G1 X180.262 Y104.442 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 16/23
; update layer progress
M73 L16
M991 S0 P15 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.4 I-1.216 J-.052 P1  F30000
G1 X178.355 Y149.348 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.074 J-1.095 E.04745
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.2771
G3 X169.418 Y157.398 I-2.272 J-2.27 E.0838
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I-.003 J-3.21 E.0838
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.571 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35056
G3 X74.027 Y106.293 I3.277 J-.286 E.05943
G1 X77.113 Y100.12 E.22894
G3 X78.124 Y98.937 I2.893 J1.449 E.05211
G1 X83.353 Y95.202 E.21318
G3 X85.225 Y94.602 I1.889 J2.676 E.06622
G1 X170.874 Y94.604 E2.84111
G3 X172.647 Y95.202 I-.094 J3.208 E.06298
G1 X177.876 Y98.937 E.21318
G3 X178.887 Y100.12 I-1.882 J2.632 E.05211
G1 X181.973 Y106.292 E.22892
G3 X182.299 Y108.032 I-2.951 J1.454 E.05944
G1 X178.528 Y148.572 E1.35058
G3 X178.374 Y149.291 I-3.248 J-.319 E.02447
M204 S250
G1 X178.726 Y149.485 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.589 Y149.807 E.01073
G3 X177.88 Y150.823 I-3.315 J-1.557 E.03826
G1 X171.966 Y156.737 E.25699
G3 X169.423 Y157.79 I-2.555 J-2.572 E.08675
G1 X86.577 Y157.79 E2.54563
G3 X85.112 Y157.478 I.005 J-3.614 E.04636
G3 X84.034 Y156.737 I1.597 J-3.479 E.0404
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21235
G3 X77.892 Y98.621 I3.242 J1.629 E.05384
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.116 J3.005 E.06854
G1 X170.878 Y94.212 E2.63201
G3 X172.871 Y94.88 I-.098 J3.6 E.06553
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.114 J2.948 E.05386
G1 X182.326 Y106.121 E.21233
G3 X182.69 Y108.064 I-3.313 J1.627 E.06148
G1 X178.918 Y148.613 E1.25133
G3 X178.741 Y149.429 I-3.644 J-.362 E.02571
; WIPE_START
M204 S10000
G1 X178.589 Y149.807 E-.15496
G1 X178.426 Y150.122 E-.13496
G1 X178.229 Y150.418 E-.13491
G1 X177.88 Y150.823 E-.20324
G1 X177.634 Y151.069 E-.13193
; WIPE_END
G1 E-.04 F1800
G1 X178.24 Y143.46 Z3.6 F30000
G1 X181.252 Y105.636 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.525 Y104.179 E.05401
G1 X127.654 Y157.05 E2.48026
G1 X128.346 Y157.05 E.02295
M73 P61 R12
G1 X75.474 Y104.178 E2.48034
G1 X74.746 Y105.634 E.05401
G1 X76.402 Y133.314 F30000
G1 F15476.087
G1 X76.251 Y131.693 E.05401
G1 X112.993 Y94.951 E1.72363
G1 X112.303 Y94.951 E.0229
G1 X172.503 Y155.152 E2.82413
G1 X176.34 Y151.312 E.18005
G1 X119.979 Y94.951 E2.64398
G1 X120.669 Y94.951 E.02288
G1 X76.905 Y138.716 E2.05307
G1 X76.658 Y136.066 E.08827
G1 X97.642 Y157.05 E.98439
G1 X96.95 Y157.05 E.02295
G1 X159.048 Y94.952 E2.91311
G1 X158.36 Y94.952 E.02281
G1 X181.055 Y117.647 E1.06468
G1 X180.916 Y119.139 E.0497
G1 X143.006 Y157.05 E1.77845
G1 X143.698 Y157.05 E.02295
G1 X82.726 Y96.078 E2.86031
G1 X78.254 Y99.282 E.18249
G1 X136.022 Y157.05 E2.71001
M73 P61 R11
G1 X135.33 Y157.05 E.02295
G1 X181.704 Y110.676 E2.17548
G1 X166.036 Y94.953 E.73631
G1 X166.723 Y94.953 E.0228
G1 X104.626 Y157.05 E2.9131
G1 X105.318 Y157.05 E.02295
G1 X75.871 Y127.603 E1.38142
G1 X75.598 Y124.67 E.0977
G1 X105.317 Y94.951 E1.39419
G1 X104.627 Y94.951 E.02291
G1 X166.726 Y157.05 E2.91318
G1 X166.034 Y157.05 E.02295
G1 X178.554 Y144.529 E.58737
G1 X178.442 Y145.738 E.04028
G1 X127.655 Y94.951 E2.38251
G1 X128.345 Y94.952 E.02287
G1 X77.558 Y145.738 E2.38251
G1 X77.446 Y144.529 E.04028
G1 X89.966 Y157.05 E.58737
G1 X89.274 Y157.05 E.02295
G1 X151.372 Y94.952 E2.91312
G1 X150.684 Y94.952 E.02283
G1 X180.402 Y124.67 E1.39413
G1 X180.129 Y127.603 E.0977
G1 X150.682 Y157.05 E1.38142
G1 X151.374 Y157.05 E.02295
G1 X89.274 Y94.95 E2.9132
G1 X89.966 Y94.95 E.02294
G1 X74.296 Y110.676 E.73641
G1 X120.67 Y157.05 E2.17548
G1 X119.978 Y157.05 E.02295
G1 X177.748 Y99.28 E2.71011
G1 X173.272 Y96.08 E.18252
G1 X112.302 Y157.05 E2.86021
G1 X112.994 Y157.05 E.02295
G1 X75.084 Y119.139 E1.77845
G1 X74.945 Y117.647 E.04971
G1 X97.642 Y94.951 E1.06475
G1 X96.951 Y94.951 E.02292
G1 X159.05 Y157.05 E2.91319
G1 X158.358 Y157.05 E.02295
G1 X179.342 Y136.066 E.98439
G1 X179.095 Y138.716 E.08827
G1 X135.331 Y94.952 E2.05305
G1 X136.02 Y94.952 E.02285
G1 X79.659 Y151.314 E2.64405
G1 X83.498 Y155.15 E.18005
G1 X143.696 Y94.952 E2.824
G1 X143.008 Y94.952 E.02284
G1 X179.749 Y131.693 E1.72359
G1 X179.598 Y133.314 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X179.749 Y131.693 E-.61876
G1 X179.486 Y131.43 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 17/23
; update layer progress
M73 L17
M991 S0 P16 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.6 I-1.215 J-.077 P1  F30000
G1 X178.357 Y149.349 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.599 Y150.549 I-3.032 J-1.075 E.04746
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27711
G3 X169.418 Y157.398 I-2.272 J-2.27 E.0838
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I-.002 J-3.212 E.0838
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.571 I2.319 J-2.296 E.07391
G1 X73.701 Y108.032 E1.35056
G3 X74.027 Y106.293 I3.277 J-.286 E.05943
G1 X77.113 Y100.119 E.22895
G3 X78.124 Y98.937 I2.883 J1.441 E.05211
G1 X83.353 Y95.202 E.21318
G3 X85.225 Y94.602 I1.881 J2.651 E.06624
G1 X170.867 Y94.604 E2.84088
G3 X172.647 Y95.202 I-.1 J3.246 E.06319
G1 X177.876 Y98.937 E.21316
G3 X178.887 Y100.12 I-1.958 J2.697 E.0521
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.955 J1.454 E.05941
G1 X178.528 Y148.572 E1.35058
G3 X178.377 Y149.293 I-3.203 J-.297 E.02449
M204 S250
G1 X178.726 Y149.484 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.592 Y149.808 E.01078
G3 X177.88 Y150.823 I-3.267 J-1.534 E.03827
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.546 J-2.551 E.08678
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.003 J-3.604 E.08679
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21235
G3 X77.892 Y98.621 I3.231 J1.62 E.05385
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.106 J2.973 E.06856
G1 X170.883 Y94.212 E2.63216
G3 X172.871 Y94.88 I-.118 J3.646 E.06536
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.2 J3.022 E.05383
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.314 J1.627 E.06147
G1 X178.918 Y148.613 E1.25133
G3 X178.745 Y149.427 I-3.593 J-.338 E.02565
; WIPE_START
M204 S10000
G1 X178.592 Y149.808 E-.15602
G1 X178.426 Y150.122 E-.13504
G1 X178.229 Y150.418 E-.13485
G1 X177.88 Y150.823 E-.20321
G1 X177.637 Y151.066 E-.13089
; WIPE_END
G1 E-.04 F1800
G1 X178.475 Y143.48 Z3.8 F30000
G1 X179.598 Y133.314 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.749 Y131.693 E.05401
G1 X143.008 Y94.952 E1.7236
G1 X143.696 Y94.952 E.02285
G1 X83.498 Y155.15 E2.82401
G1 X79.659 Y151.314 E.18005
G1 X136.021 Y94.952 E2.64406
G1 X135.331 Y94.952 E.02286
G1 X179.095 Y138.716 E2.05306
G1 X179.342 Y136.066 E.08827
G1 X158.358 Y157.05 E.98439
G1 X159.05 Y157.05 E.02295
G1 X96.951 Y94.951 E2.91319
G1 X97.642 Y94.951 E.02293
G1 X74.945 Y117.647 E1.06475
G1 X75.084 Y119.139 E.04971
G1 X112.994 Y157.05 E1.77845
G1 X112.302 Y157.05 E.02295
G1 X173.272 Y96.08 E2.86021
G1 X177.748 Y99.28 E.18252
G1 X119.978 Y157.05 E2.71011
G1 X120.67 Y157.05 E.02295
G1 X74.296 Y110.676 E2.17548
G1 X89.966 Y94.95 E.73641
G1 X89.274 Y94.95 E.02294
G1 X151.374 Y157.05 E2.9132
G1 X150.682 Y157.05 E.02295
G1 X180.129 Y127.603 E1.38142
G1 X180.402 Y124.67 E.0977
G1 X150.684 Y94.952 E1.39414
G1 X151.372 Y94.952 E.02283
G1 X89.274 Y157.05 E2.91313
G1 X89.966 Y157.05 E.02295
G1 X77.446 Y144.529 E.58737
G1 X77.558 Y145.738 E.04028
G1 X128.345 Y94.951 E2.38251
G1 X127.655 Y94.951 E.02287
G1 X178.442 Y145.738 E2.38251
G1 X178.554 Y144.529 E.04028
G1 X166.034 Y157.05 E.58737
G1 X166.726 Y157.05 E.02295
M73 P62 R11
G1 X104.627 Y94.951 E2.91319
G1 X105.317 Y94.951 E.02291
G1 X75.598 Y124.67 E1.39419
G1 X75.871 Y127.603 E.0977
G1 X105.318 Y157.05 E1.38142
G1 X104.626 Y157.05 E.02295
G1 X166.724 Y94.952 E2.91311
G1 X166.036 Y94.952 E.02281
G1 X181.704 Y110.676 E.73632
G1 X135.33 Y157.05 E2.17548
G1 X136.022 Y157.05 E.02295
G1 X78.254 Y99.282 E2.71001
G1 X82.726 Y96.078 E.18249
G1 X143.698 Y157.05 E2.86031
G1 X143.006 Y157.05 E.02295
G1 X180.916 Y119.139 E1.77845
G1 X181.055 Y117.647 E.0497
G1 X158.36 Y94.952 E1.06468
G1 X159.048 Y94.952 E.02282
G1 X96.95 Y157.05 E2.91312
G1 X97.642 Y157.05 E.02295
G1 X76.658 Y136.066 E.98439
G1 X76.905 Y138.715 E.08827
G1 X120.669 Y94.951 E2.05307
G1 X119.979 Y94.951 E.02289
G1 X176.34 Y151.312 E2.64399
G1 X172.503 Y155.152 E.18005
G1 X112.303 Y94.951 E2.82413
G1 X112.993 Y94.951 E.0229
G1 X76.251 Y131.693 E1.72363
G1 X76.402 Y133.314 E.05401
G1 X74.746 Y105.634 F30000
G1 F15476.087
G1 X75.474 Y104.178 E.05401
G1 X128.346 Y157.05 E2.48034
G1 X127.654 Y157.05 E.02295
G1 X180.525 Y104.179 E2.48026
G1 X181.252 Y105.636 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X180.525 Y104.179 E-.61876
G1 X180.262 Y104.442 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 18/23
; update layer progress
M73 L18
M991 S0 P17 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.8 I-1.216 J-.052 P1  F30000
G1 X178.355 Y149.348 Z3.8
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X177.6 Y150.549 I-3.074 J-1.095 E.04742
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27712
G3 X169.418 Y157.398 I-2.297 J-2.331 E.08372
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.008 J-3.236 E.08376
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.571 I2.319 J-2.296 E.0739
G1 X73.701 Y108.032 E1.35058
G3 X74.027 Y106.293 I3.277 J-.286 E.05943
G1 X77.113 Y100.12 E.22895
G3 X78.127 Y98.935 I2.972 J1.517 E.0522
G1 X83.353 Y95.202 E.21306
G3 X85.225 Y94.602 I1.88 J2.647 E.06624
G1 X170.877 Y94.605 E2.84123
G3 X172.647 Y95.202 I-.118 J3.269 E.06283
G1 X177.876 Y98.937 E.21318
G3 X178.888 Y100.123 I-1.958 J2.696 E.0522
G1 X181.973 Y106.293 E.22883
G3 X182.299 Y108.032 I-2.951 J1.453 E.05942
G1 X178.528 Y148.571 E1.35058
G3 X178.374 Y149.292 I-3.248 J-.319 E.02448
M204 S250
G1 X178.727 Y149.483 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.589 Y149.807 E.01083
G3 X177.88 Y150.823 I-3.315 J-1.557 E.03824
G1 X171.966 Y156.737 E.25699
G3 X169.423 Y157.79 I-2.574 J-2.617 E.0867
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.015 J-3.633 E.08675
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21235
G3 X77.893 Y98.62 I3.329 J1.703 E.05386
G1 X83.129 Y94.88 E.19771
G3 X85.221 Y94.21 I2.104 J2.969 E.06856
G1 X170.894 Y94.213 E2.63249
G3 X172.871 Y94.88 I-.137 J3.67 E.06502
G1 X178.108 Y98.621 E.19774
G3 X179.236 Y99.942 I-2.2 J3.021 E.05387
G1 X182.326 Y106.121 E.2123
G3 X182.69 Y108.064 I-3.313 J1.627 E.06147
G1 X178.918 Y148.612 E1.25133
G3 X178.742 Y149.427 I-3.644 J-.362 E.02565
; WIPE_START
M204 S10000
G1 X178.589 Y149.807 E-.15577
G1 X178.426 Y150.122 E-.13493
G1 X178.229 Y150.418 E-.13474
G1 X177.88 Y150.823 E-.2033
G1 X177.636 Y151.067 E-.13127
; WIPE_END
G1 E-.04 F1800
G1 X178.325 Y143.466 Z4 F30000
G1 X180.206 Y122.702 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.055 Y124.324 E.05401
G1 X151.061 Y95.329 E1.36018
G1 X150.995 Y95.329 E.0022
G1 X89.652 Y156.673 E2.87773
G1 X89.589 Y156.673 E.00208
G1 X77.863 Y144.947 E.55008
G1 X77.905 Y145.392 E.01482
G1 X127.967 Y95.329 E2.34855
G1 X128.033 Y95.329 E.00216
G1 X178.095 Y145.392 E2.34856
G1 X178.137 Y144.947 E.01482
G1 X166.411 Y156.673 E.55008
G1 X166.348 Y156.673 E.00208
G1 X105.004 Y95.328 E2.87779
G1 X104.94 Y95.328 E.00211
G1 X75.945 Y124.324 E1.36024
G1 X75.794 Y122.702 E.05401
G1 X84.369 Y95.484 F30000
G1 F15476.087
G2 X82.996 Y96.348 I2.698 J5.81 E.05396
G1 X143.321 Y156.673 E2.82993
G1 X143.383 Y156.673 E.00208
G1 X180.499 Y119.557 E1.74116
G1 X180.709 Y117.301 E.07516
G1 X158.737 Y95.33 E1.03072
G1 X158.67 Y95.33 E.00222
G1 X97.327 Y156.673 E2.87772
G1 X97.265 Y156.673 E.00208
G1 X77.076 Y136.484 E.94711
G1 X77.251 Y138.369 E.06281
G1 X120.292 Y95.328 E2.01912
G1 X120.356 Y95.328 E.00214
G1 X176.073 Y151.045 E2.61378
G1 X172.237 Y154.885 E.18005
G1 X112.68 Y95.328 E2.79392
G1 X112.616 Y95.328 E.00213
G1 X76.598 Y131.346 E1.68968
G1 X76.289 Y128.02 E.1108
G1 X104.941 Y156.673 E1.34413
G1 X105.003 Y156.673 E.00208
G1 X166.346 Y95.33 E2.87771
G1 X166.413 Y95.33 E.00223
G1 X181.362 Y110.278 E.70126
G1 X181.286 Y111.094 E.02717
G1 X135.707 Y156.673 E2.13819
G1 X135.645 Y156.673 E.00208
G1 X78.522 Y99.55 E2.67975
G1 X78.339 Y99.701 E.00787
G2 X77.754 Y100.46 I2.631 J2.633 E.03186
G1 X75.755 Y104.459 E.14831
G1 X127.969 Y156.673 E2.44946
G1 X128.031 Y156.673 E.00208
G1 X180.243 Y104.46 E2.44938
G1 X178.19 Y100.36 E.15212
G2 X177.48 Y99.548 I-3.594 J2.427 E.03587
G1 X120.355 Y156.673 E2.67981
G1 X120.293 Y156.673 E.00208
G1 X74.714 Y111.094 E2.13819
G1 X74.638 Y110.278 E.02717
G1 X89.589 Y95.328 E.70136
G1 X89.652 Y95.328 E.00209
G1 X150.997 Y156.673 E2.87781
G1 X151.059 Y156.673 E.00208
G1 X179.711 Y128.02 E1.34414
G1 X179.402 Y131.346 E.11081
G1 X143.385 Y95.329 E1.68964
G1 X143.319 Y95.329 E.00219
G1 X83.765 Y154.883 E2.7938
G1 X79.925 Y151.047 E.18005
G1 X135.643 Y95.329 E2.61384
G1 X135.709 Y95.329 E.00217
G1 X178.749 Y138.369 E2.0191
G1 X178.924 Y136.484 E.06281
G1 X158.735 Y156.673 E.94711
G1 X158.672 Y156.673 E.00208
G1 X97.328 Y95.328 E2.8778
G1 X97.265 Y95.328 E.0021
G1 X75.291 Y117.301 E1.0308
G1 X75.501 Y119.557 E.07516
G1 X112.617 Y156.673 E1.74116
G1 X112.679 Y156.673 E.00208
G1 X173.001 Y96.351 E2.82983
G2 X171.629 Y95.486 I-3.126 J3.44 E.05408
G1 X177.654 Y99.224 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G3 X178.189 Y99.719 I-5.98 J7.001 E.0202
G1 X178.57 Y100.298 E.01921
G1 X181.704 Y106.573 E.19432
G3 X181.865 Y107.075 I-3.044 J1.252 E.01463
G1 X181.944 Y107.734 E.01839
G1 X181.937 Y108.007 E.00755
G1 X178.169 Y148.519 E1.12726
G1 X178.079 Y148.981 E.01306
G1 X177.824 Y149.63 E.0193
G1 X177.441 Y150.189 E.01877
G1 X171.446 Y156.189 E.23501
G3 X170.899 Y156.619 I-6.726 J-8.016 E.01928
G3 X170.095 Y156.952 I-1.428 J-2.312 E.0242
G1 X169.403 Y157.035 E.01931
G1 X86.597 Y157.035 E2.29421
G1 X86.285 Y157.008 E.00866
G1 X85.602 Y156.856 E.0194
G1 X85.034 Y156.575 E.01757
G1 X84.66 Y156.29 E.01301
G1 X78.667 Y150.303 E.2347
G3 X78.212 Y149.711 I7.047 J-5.898 E.0207
G1 X77.936 Y149.072 E.01928
M73 P63 R11
G1 X77.833 Y148.524 E.01545
G1 X74.063 Y108.01 E1.1273
G3 X74.064 Y107.452 I10.116 J-.253 E.01548
G1 X74.164 Y106.936 E.01454
G1 X74.357 Y106.444 E.01464
G1 X77.432 Y100.293 E.19054
G1 X77.593 Y100.024 E.00869
G1 X77.998 Y99.516 E.01799
G1 X78.349 Y99.222 E.01267
G1 X83.553 Y95.505 E.17719
G3 X84.145 Y95.179 I5.386 J9.087 E.01873
G1 X84.575 Y95.05 E.01243
G1 X85.238 Y94.965 E.01854
G1 X170.855 Y94.967 E2.37208
G1 X171.306 Y95.021 E.01258
G1 X171.942 Y95.216 E.01843
G1 X172.329 Y95.426 E.01219
G1 X177.605 Y99.189 E.17955
; Slow Down End
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X175.977 Y98.028 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 19/23
; update layer progress
M73 L19
M991 S0 P18 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4 I-1.216 J.056 P1  F30000
G1 X178.355 Y149.348 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X177.6 Y150.549 I-3.074 J-1.095 E.04742
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27713
G3 X169.418 Y157.398 I-2.305 J-2.351 E.08368
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.009 J-3.238 E.08375
G1 X78.401 Y150.549 E.27712
G3 X77.472 Y148.571 I2.319 J-2.296 E.0739
G1 X73.701 Y108.032 E1.35057
G3 X74.027 Y106.293 I3.277 J-.286 E.05943
G1 X77.113 Y100.119 E.22895
G3 X78.124 Y98.937 I2.972 J1.517 E.05207
G1 X83.353 Y95.202 E.21317
G3 X85.225 Y94.602 I1.879 J2.643 E.06625
G1 X170.887 Y94.605 E2.84156
G3 X172.647 Y95.202 I-.129 J3.271 E.06248
G1 X177.876 Y98.937 E.21319
G3 X178.887 Y100.12 I-1.958 J2.696 E.05208
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.954 J1.454 E.05942
G1 X178.528 Y148.572 E1.35058
G3 X178.374 Y149.292 I-3.248 J-.319 E.02448
M204 S250
G1 X178.724 Y149.479 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X177.88 Y150.823 I-3.45 J-1.229 E.04914
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.582 J-2.638 E.08667
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.016 J-3.635 E.08674
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21235
G3 X77.892 Y98.621 I3.329 J1.703 E.05382
G1 X83.129 Y94.88 E.19774
G3 X85.221 Y94.21 I2.103 J2.964 E.06857
G1 X170.904 Y94.213 E2.63281
G3 X172.871 Y94.88 I-.149 J3.672 E.0647
G1 X178.108 Y98.621 E.19775
G3 X179.235 Y99.94 I-2.2 J3.021 E.05383
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.314 J1.627 E.06147
G1 X178.918 Y148.613 E1.25133
G3 X178.743 Y149.422 I-3.644 J-.362 E.02551
; WIPE_START
M204 S10000
G1 X178.593 Y149.809 E-.15762
G1 X178.426 Y150.122 E-.1349
G1 X178.229 Y150.418 E-.13493
G1 X177.88 Y150.823 E-.20321
G1 X177.64 Y151.064 E-.12934
; WIPE_END
G1 E-.04 F1800
G1 X171.811 Y155.991 Z4.2 F30000
G1 X170.665 Y156.959 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40164
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X177.439 Y150.181 E.49467
G1 X177.527 Y150.073 E.00717
G2 X178.101 Y148.885 I-2.324 J-1.854 E.06869
G1 X170.029 Y156.957 E.58927
G3 X169.319 Y157.028 I-.694 J-3.341 E.0369
G1 X178.196 Y148.151 E.64806
G1 X178.262 Y147.447 E.03651
G1 X168.68 Y157.028 E.69947
G1 X168.041 Y157.028 E.03297
G1 X178.327 Y146.743 E.75088
G1 X178.393 Y146.038 E.03651
G1 X167.403 Y157.028 E.80229
G1 X166.764 Y157.028 E.03297
G1 X178.458 Y145.334 E.8537
G1 X178.524 Y144.63 E.03651
G1 X166.125 Y157.028 E.90511
G1 X165.487 Y157.028 E.03297
G1 X178.589 Y143.926 E.95652
G1 X178.655 Y143.221 E.03651
G1 X164.848 Y157.028 E1.00793
G1 X164.209 Y157.028 E.03297
G1 X178.72 Y142.517 E1.05934
G1 X178.786 Y141.813 E.03651
G1 X163.57 Y157.028 E1.11075
G1 X162.932 Y157.028 E.03297
G1 X178.851 Y141.109 E1.16216
G1 X178.917 Y140.405 E.03651
G1 X162.293 Y157.028 E1.21357
G1 X161.654 Y157.028 E.03297
G1 X178.982 Y139.7 E1.26498
G1 X179.048 Y138.996 E.03651
G1 X161.016 Y157.028 E1.31639
G1 X160.377 Y157.028 E.03297
G1 X179.113 Y138.292 E1.3678
G1 X179.179 Y137.588 E.03651
G1 X159.738 Y157.028 E1.41921
G1 X159.099 Y157.028 E.03297
G1 X179.244 Y136.883 E1.47062
G1 X179.31 Y136.179 E.03651
G1 X158.461 Y157.028 E1.52203
G1 X157.822 Y157.028 E.03297
G1 X179.375 Y135.475 E1.57344
G1 X179.441 Y134.771 E.03651
G1 X157.183 Y157.028 E1.62485
G1 X156.545 Y157.028 E.03297
G1 X179.506 Y134.067 E1.67626
G1 X179.572 Y133.362 E.03651
G1 X155.906 Y157.028 E1.72767
G1 X155.267 Y157.028 E.03297
G1 X179.637 Y132.658 E1.77909
G1 X179.703 Y131.954 E.03651
G1 X154.628 Y157.028 E1.8305
G1 X153.99 Y157.028 E.03297
G1 X179.768 Y131.25 E1.88191
G1 X179.834 Y130.545 E.03651
G1 X153.351 Y157.028 E1.93332
G1 X152.712 Y157.028 E.03297
G1 X179.899 Y129.841 E1.98473
G1 X179.965 Y129.137 E.03651
G1 X152.073 Y157.028 E2.03614
G1 X151.435 Y157.028 E.03297
G1 X180.03 Y128.433 E2.08755
G1 X180.096 Y127.729 E.03651
G1 X150.796 Y157.028 E2.13896
G1 X150.157 Y157.028 E.03297
G1 X180.161 Y127.024 E2.19037
G1 X180.227 Y126.32 E.03651
G1 X149.519 Y157.028 E2.24178
G1 X148.88 Y157.028 E.03297
G1 X180.292 Y125.616 E2.29319
G1 X180.358 Y124.912 E.03651
G1 X148.241 Y157.028 E2.3446
G1 X147.602 Y157.028 E.03297
G1 X180.423 Y124.207 E2.39601
G1 X180.489 Y123.503 E.03651
G1 X146.964 Y157.028 E2.44742
G1 X146.325 Y157.028 E.03297
G1 X180.554 Y122.799 E2.49883
G1 X180.62 Y122.095 E.03651
G1 X145.686 Y157.028 E2.55024
G1 X145.048 Y157.028 E.03297
M73 P64 R11
G1 X180.685 Y121.39 E2.60165
G1 X180.751 Y120.686 E.03651
G1 X144.409 Y157.028 E2.65306
G1 X143.77 Y157.028 E.03297
G1 X180.816 Y119.982 E2.70447
G1 X180.882 Y119.278 E.03651
G1 X143.131 Y157.028 E2.75588
G1 X142.493 Y157.028 E.03297
G1 X180.947 Y118.574 E2.80729
G1 X181.013 Y117.869 E.03651
G1 X141.854 Y157.028 E2.8587
G1 X141.215 Y157.028 E.03297
G1 X181.078 Y117.165 E2.91011
G1 X181.144 Y116.461 E.03651
G1 X140.577 Y157.028 E2.96152
G1 X139.938 Y157.028 E.03297
G1 X181.209 Y115.757 E3.01293
G1 X181.275 Y115.052 E.03651
G1 X139.299 Y157.028 E3.06434
G1 X138.66 Y157.028 E.03297
G1 X181.34 Y114.348 E3.11575
G1 X181.406 Y113.644 E.03651
G1 X138.022 Y157.028 E3.16716
G1 X137.383 Y157.028 E.03297
G1 X181.471 Y112.94 E3.21857
G1 X181.537 Y112.236 E.03651
G1 X136.744 Y157.028 E3.26998
G1 X136.106 Y157.028 E.03297
G1 X181.602 Y111.531 E3.32139
G1 X181.668 Y110.827 E.03651
G1 X135.467 Y157.028 E3.3728
G1 X134.828 Y157.028 E.03297
G1 X181.734 Y110.123 E3.42421
G1 X181.799 Y109.419 E.03651
G1 X134.189 Y157.028 E3.47563
G1 X133.551 Y157.028 E.03297
G1 X181.865 Y108.714 E3.52703
G1 X181.93 Y108.01 E.03651
G1 X132.912 Y157.028 E3.57845
G1 X132.273 Y157.028 E.03297
G1 X181.917 Y107.384 E3.62414
G1 X181.904 Y107.306 E.0041
G2 X181.805 Y106.858 I-1.973 J.204 E.02374
G1 X131.635 Y157.028 E3.66255
G1 X130.996 Y157.028 E.03297
G1 X181.614 Y106.41 E3.69529
G1 X181.402 Y105.984 E.02458
G1 X130.357 Y157.028 E3.72639
G1 X129.718 Y157.028 E.03297
G1 X181.189 Y105.558 E3.75749
G1 X180.976 Y105.132 E.02458
G1 X129.08 Y157.028 E3.78859
G1 X128.441 Y157.028 E.03297
G1 X180.764 Y104.706 E3.81969
M73 P64 R10
G1 X180.551 Y104.28 E.02458
G1 X127.802 Y157.028 E3.85078
G1 X127.164 Y157.028 E.03297
G1 X180.338 Y103.854 E3.88188
G1 X180.125 Y103.428 E.02458
G1 X126.525 Y157.028 E3.91298
G1 X125.886 Y157.028 E.03297
G1 X179.913 Y103.002 E3.94408
G1 X179.7 Y102.576 E.02458
G1 X125.247 Y157.028 E3.97518
G1 X124.609 Y157.028 E.03297
G1 X179.487 Y102.15 E4.00628
G1 X179.274 Y101.724 E.02458
G1 X123.97 Y157.028 E4.03737
G1 X123.331 Y157.028 E.03297
G1 X179.062 Y101.298 E4.06847
G1 X178.849 Y100.872 E.02458
G1 X122.693 Y157.028 E4.09957
G1 X122.054 Y157.028 E.03297
G1 X178.636 Y100.446 E4.13067
G2 X178.411 Y100.032 I-5.693 J2.826 E.02432
G1 X121.415 Y157.028 E4.16088
G1 X120.776 Y157.028 E.03297
G1 X178.135 Y99.669 E4.18735
G2 X177.81 Y99.356 I-1.438 J1.167 E.02338
G1 X120.138 Y157.028 E4.21023
G1 X119.499 Y157.028 E.03297
G1 X177.444 Y99.083 E4.23015
M73 P65 R10
G1 X177.071 Y98.817 E.02364
G1 X118.86 Y157.028 E4.24956
G1 X118.222 Y157.028 E.03297
G1 X176.699 Y98.551 E4.26898
G1 X176.326 Y98.285 E.02364
G1 X117.583 Y157.028 E4.28839
G1 X116.944 Y157.028 E.03297
G1 X175.953 Y98.019 E4.30781
G1 X175.58 Y97.753 E.02364
G1 X116.305 Y157.028 E4.32722
G1 X115.667 Y157.028 E.03297
G1 X175.207 Y97.487 E4.34664
G1 X174.835 Y97.222 E.02364
G1 X115.028 Y157.028 E4.36605
G1 X114.389 Y157.028 E.03297
G1 X174.462 Y96.956 E4.38547
G1 X174.089 Y96.69 E.02364
G1 X113.751 Y157.028 E4.40488
G1 X113.112 Y157.028 E.03297
G1 X173.716 Y96.424 E4.42429
G1 X173.344 Y96.158 E.02364
G1 X112.473 Y157.028 E4.44371
G1 X111.834 Y157.028 E.03297
G1 X172.971 Y95.892 E4.46312
G1 X172.598 Y95.626 E.02364
G1 X111.196 Y157.028 E4.48254
G1 X110.557 Y157.028 E.03297
G1 X172.215 Y95.37 E4.50123
G2 X171.783 Y95.164 I-1.137 J1.827 E.02478
G1 X109.918 Y157.028 E4.51628
G1 X109.28 Y157.028 E.03297
G1 X171.284 Y95.023 E4.52652
G2 X170.695 Y94.974 I-.546 J3.006 E.0306
G1 X108.641 Y157.028 E4.53009
G1 X108.002 Y157.028 E.03297
G1 X170.056 Y94.974 E4.53009
M73 P66 R10
G1 X169.417 Y94.974 E.03297
G1 X107.363 Y157.028 E4.53009
G1 X106.725 Y157.028 E.03297
G1 X168.779 Y94.974 E4.5301
G1 X168.14 Y94.974 E.03297
G1 X106.086 Y157.028 E4.5301
G1 X105.447 Y157.028 E.03297
G1 X167.501 Y94.974 E4.5301
G1 X166.862 Y94.974 E.03297
G1 X104.809 Y157.028 E4.5301
G1 X104.17 Y157.028 E.03297
G1 X166.224 Y94.974 E4.5301
G1 X165.585 Y94.974 E.03297
G1 X103.531 Y157.028 E4.5301
G1 X102.892 Y157.028 E.03297
G1 X164.946 Y94.974 E4.5301
G1 X164.308 Y94.974 E.03297
G1 X102.254 Y157.028 E4.53011
G1 X101.615 Y157.028 E.03297
G1 X163.669 Y94.974 E4.53011
G1 X163.03 Y94.974 E.03297
G1 X100.976 Y157.028 E4.53011
G1 X100.338 Y157.028 E.03297
G1 X162.392 Y94.974 E4.53011
G1 X161.753 Y94.974 E.03297
G1 X99.699 Y157.028 E4.53011
G1 X99.06 Y157.028 E.03297
G1 X161.114 Y94.974 E4.53011
G1 X160.475 Y94.974 E.03297
M73 P67 R10
G1 X98.421 Y157.028 E4.53011
G1 X97.783 Y157.028 E.03297
G1 X159.837 Y94.974 E4.53012
G1 X159.198 Y94.974 E.03297
G1 X97.144 Y157.028 E4.53012
G1 X96.505 Y157.028 E.03297
G1 X158.559 Y94.974 E4.53012
G1 X157.921 Y94.974 E.03297
G1 X95.867 Y157.028 E4.53012
G1 X95.228 Y157.028 E.03297
G1 X157.282 Y94.974 E4.53012
G1 X156.643 Y94.974 E.03297
G1 X94.589 Y157.028 E4.53012
G1 X93.95 Y157.028 E.03297
G1 X156.005 Y94.974 E4.53013
G1 X155.366 Y94.974 E.03297
M73 P67 R9
G1 X93.312 Y157.028 E4.53013
G1 X92.673 Y157.028 E.03297
G1 X154.727 Y94.974 E4.53013
G1 X154.089 Y94.974 E.03297
G1 X92.034 Y157.028 E4.53013
G1 X91.396 Y157.028 E.03297
G1 X153.45 Y94.974 E4.53013
G1 X152.811 Y94.974 E.03297
M73 P68 R9
G1 X90.757 Y157.028 E4.53013
G1 X90.118 Y157.028 E.03297
G1 X152.172 Y94.974 E4.53013
G1 X151.534 Y94.974 E.03297
G1 X89.479 Y157.028 E4.53014
G1 X88.841 Y157.028 E.03297
G1 X150.895 Y94.974 E4.53014
G1 X150.256 Y94.974 E.03297
G1 X88.202 Y157.028 E4.53014
G1 X87.563 Y157.028 E.03297
G1 X149.618 Y94.974 E4.53014
G1 X148.979 Y94.974 E.03297
G1 X86.925 Y157.028 E4.53014
G3 X86.3 Y157.014 I-.107 J-9.029 E.03225
G1 X148.34 Y94.974 E4.5291
G1 X147.702 Y94.974 E.03297
G1 X85.768 Y156.907 E4.52129
G3 X85.314 Y156.722 I.588 J-2.099 E.02536
G1 X147.063 Y94.974 E4.50783
G1 X146.424 Y94.974 E.03297
G1 X84.916 Y156.482 E4.49028
G1 X84.786 Y156.381 E.00847
M73 P69 R9
G3 X84.57 Y156.19 I1.052 J-1.409 E.01496
G1 X145.785 Y94.974 E4.46893
G1 X145.147 Y94.974 E.03297
G1 X84.25 Y155.87 E4.44563
G1 X83.931 Y155.551 E.02331
G1 X144.508 Y94.974 E4.42232
G1 X143.869 Y94.974 E.03297
G1 X83.611 Y155.232 E4.39902
G1 X83.292 Y154.913 E.02331
G1 X143.231 Y94.974 E4.37572
G1 X142.592 Y94.974 E.03297
G1 X82.972 Y154.594 E4.35242
G1 X82.652 Y154.274 E.02331
G1 X141.953 Y94.974 E4.32912
G1 X141.315 Y94.974 E.03297
G1 X82.333 Y153.955 E4.30582
G1 X82.013 Y153.636 E.02331
G1 X140.676 Y94.974 E4.28252
G1 X140.037 Y94.974 E.03297
G1 X81.694 Y153.317 E4.25921
M73 P70 R9
G1 X81.374 Y152.998 E.02331
G1 X139.399 Y94.973 E4.23591
G1 X138.76 Y94.973 E.03297
G1 X81.055 Y152.678 E4.21261
G1 X80.735 Y152.359 E.02331
G1 X138.121 Y94.973 E4.18931
G1 X137.482 Y94.973 E.03297
G1 X80.416 Y152.04 E4.16601
G1 X80.096 Y151.721 E.02331
G1 X136.844 Y94.973 E4.14271
G1 X136.205 Y94.973 E.03297
G1 X79.777 Y151.401 E4.1194
G1 X79.457 Y151.082 E.02331
G1 X135.566 Y94.973 E4.0961
G1 X134.928 Y94.973 E.03297
G1 X79.138 Y150.763 E4.0728
G1 X78.818 Y150.444 E.02331
G1 X134.289 Y94.973 E4.0495
G1 X133.65 Y94.973 E.03297
G1 X78.507 Y150.116 E4.02559
M73 P70 R8
G3 X78.239 Y149.746 I3.263 J-2.643 E.02362
G1 X133.012 Y94.973 E3.99853
M73 P71 R8
G1 X132.373 Y94.973 E.03297
G1 X78.033 Y149.314 E3.96699
G3 X77.884 Y148.823 I2.197 J-.932 E.0265
G1 X131.734 Y94.973 E3.93119
G1 X131.095 Y94.973 E.03297
G1 X77.814 Y148.255 E3.88971
G1 X77.759 Y147.671 E.0303
G1 X130.457 Y94.973 E3.84705
G1 X129.818 Y94.973 E.03297
G1 X77.705 Y147.086 E3.8044
G1 X77.651 Y146.502 E.0303
G1 X129.179 Y94.973 E3.76174
G1 X128.541 Y94.973 E.03297
G1 X77.596 Y145.918 E3.71908
G1 X77.542 Y145.333 E.0303
G1 X127.902 Y94.973 E3.67642
G1 X127.263 Y94.973 E.03297
G1 X77.488 Y144.749 E3.63376
G1 X77.433 Y144.164 E.03029
G1 X126.625 Y94.973 E3.59111
M73 P72 R8
G1 X125.986 Y94.973 E.03297
G1 X77.379 Y143.58 E3.54845
G1 X77.324 Y142.996 E.03029
G1 X125.347 Y94.973 E3.50579
G1 X124.709 Y94.973 E.03297
G1 X77.27 Y142.411 E3.46313
G1 X77.216 Y141.827 E.0303
G1 X124.07 Y94.973 E3.42047
G1 X123.431 Y94.973 E.03297
G1 X77.161 Y141.243 E3.37781
G1 X77.107 Y140.658 E.03029
G1 X122.792 Y94.973 E3.33516
G1 X122.154 Y94.973 E.03297
G1 X77.053 Y140.074 E3.2925
G1 X76.998 Y139.49 E.03029
G1 X121.515 Y94.973 E3.24984
G1 X120.876 Y94.973 E.03297
G1 X76.944 Y138.905 E3.20718
G1 X76.89 Y138.321 E.0303
G1 X120.238 Y94.973 E3.16452
G1 X119.599 Y94.973 E.03297
G1 X76.835 Y137.737 E3.12187
M73 P73 R8
G1 X76.781 Y137.152 E.03029
G1 X118.96 Y94.973 E3.07921
G1 X118.322 Y94.973 E.03297
G1 X76.727 Y136.568 E3.03655
G1 X76.672 Y135.984 E.0303
G1 X117.683 Y94.973 E2.99389
G1 X117.044 Y94.973 E.03297
G1 X76.618 Y135.399 E2.95123
G1 X76.563 Y134.815 E.0303
G1 X116.405 Y94.973 E2.90857
G1 X115.767 Y94.973 E.03297
G1 X76.509 Y134.23 E2.86592
G1 X76.455 Y133.646 E.0303
G1 X115.128 Y94.973 E2.82326
G1 X114.489 Y94.973 E.03297
G1 X76.4 Y133.062 E2.7806
G1 X76.346 Y132.477 E.0303
G1 X113.851 Y94.973 E2.73794
G1 X113.212 Y94.973 E.03297
G1 X76.292 Y131.893 E2.69529
G1 X76.237 Y131.309 E.0303
M73 P74 R8
G1 X112.573 Y94.973 E2.65263
G1 X111.935 Y94.973 E.03297
G1 X76.183 Y130.724 E2.60997
G1 X76.129 Y130.14 E.0303
M73 P74 R7
G1 X111.296 Y94.973 E2.56731
G1 X110.657 Y94.973 E.03297
G1 X76.074 Y129.556 E2.52465
G1 X76.02 Y128.971 E.03029
G1 X110.019 Y94.973 E2.48199
G1 X109.38 Y94.973 E.03297
G1 X75.965 Y128.387 E2.43934
G1 X75.911 Y127.803 E.0303
G1 X108.741 Y94.973 E2.39668
G1 X108.102 Y94.973 E.03297
G1 X75.857 Y127.218 E2.35402
G1 X75.802 Y126.634 E.03029
G1 X107.464 Y94.972 E2.31136
G1 X106.825 Y94.972 E.03297
G1 X75.748 Y126.049 E2.2687
G1 X75.694 Y125.465 E.03029
G1 X106.186 Y94.972 E2.22605
G1 X105.548 Y94.972 E.03297
M73 P75 R7
G1 X75.639 Y124.881 E2.18339
G1 X75.585 Y124.296 E.0303
G1 X104.909 Y94.972 E2.14073
G1 X104.27 Y94.972 E.03297
G1 X75.531 Y123.712 E2.09807
G1 X75.476 Y123.128 E.03029
G1 X103.632 Y94.972 E2.05541
G1 X102.993 Y94.972 E.03297
G1 X75.422 Y122.543 E2.01275
G1 X75.368 Y121.959 E.03029
G1 X102.354 Y94.972 E1.9701
G1 X101.715 Y94.972 E.03297
G1 X75.313 Y121.375 E1.92744
G1 X75.259 Y120.79 E.0303
G1 X101.077 Y94.972 E1.88478
G1 X100.438 Y94.972 E.03297
G1 X75.204 Y120.206 E1.84212
G1 X75.15 Y119.622 E.0303
G1 X99.799 Y94.972 E1.79946
G1 X99.161 Y94.972 E.03297
G1 X75.096 Y119.037 E1.75681
G1 X75.041 Y118.453 E.0303
G1 X98.522 Y94.972 E1.71415
G1 X97.883 Y94.972 E.03297
M73 P76 R7
G1 X74.987 Y117.868 E1.67149
G1 X74.933 Y117.284 E.0303
G1 X97.245 Y94.972 E1.62883
G1 X96.606 Y94.972 E.03297
G1 X74.878 Y116.7 E1.58617
G1 X74.824 Y116.115 E.0303
G1 X95.967 Y94.972 E1.54351
G1 X95.329 Y94.972 E.03297
G1 X74.77 Y115.531 E1.50086
G1 X74.715 Y114.947 E.0303
G1 X94.69 Y94.972 E1.4582
G1 X94.051 Y94.972 E.03297
G1 X74.661 Y114.362 E1.41554
G1 X74.607 Y113.778 E.03029
G1 X93.412 Y94.972 E1.37288
G1 X92.774 Y94.972 E.03297
G1 X74.552 Y113.194 E1.33022
G1 X74.498 Y112.609 E.03029
G1 X92.135 Y94.972 E1.28757
G1 X91.496 Y94.972 E.03297
G1 X74.443 Y112.025 E1.24491
G1 X74.389 Y111.441 E.03029
G1 X90.858 Y94.972 E1.20225
G1 X90.219 Y94.972 E.03297
G1 X74.335 Y110.856 E1.15959
G1 X74.28 Y110.272 E.03029
G1 X89.58 Y94.972 E1.11693
G1 X88.942 Y94.972 E.03297
M73 P77 R7
G1 X74.226 Y109.687 E1.07428
G1 X74.172 Y109.103 E.03029
G1 X88.303 Y94.972 E1.03162
G1 X87.664 Y94.972 E.03297
G1 X74.117 Y108.519 E.98896
G3 X74.066 Y107.931 I6.371 J-.851 E.03045
G1 X87.025 Y94.972 E.94607
G1 X86.387 Y94.972 E.03297
G1 X74.097 Y107.261 E.89715
G3 X74.453 Y106.267 I3.154 J.567 E.05476
G1 X85.748 Y94.972 E.82456
G2 X85.103 Y94.978 I-.257 J6.848 E.0333
M73 P77 R6
G1 X75.092 Y104.989 E.73086
G1 X75.731 Y103.712 E.07373
G1 X84.314 Y95.129 E.62661
G2 X83.561 Y95.508 I1.065 J3.052 E.04365
G1 X82.633 Y96.17 E.05884
G1 X76.369 Y102.434 E.45729
G1 X77.008 Y101.157 E.07373
G1 X80.398 Y97.767 E.24746
G1 X78.35 Y99.23 E.12992
G1 X78.035 Y99.491 E.02109
G1 X77.194 Y100.332 E.06142
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X78.035 Y99.491 E-.45214
G1 X78.35 Y99.23 E-.15528
G1 X78.676 Y98.997 E-.15259
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 20/23
; update layer progress
M73 L20
M991 S0 P19 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.2 I-.549 J1.086 P1  F30000
G1 X178.354 Y149.348 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X177.599 Y150.549 I-3.074 J-1.095 E.04743
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

M73 P78 R6
G1 X171.692 Y156.456 E.27711
G3 X169.418 Y157.398 I-2.287 J-2.305 E.08375
G1 X86.582 Y157.398 E2.74783
G3 X84.307 Y156.456 I.013 J-3.247 E.08376
G1 X78.401 Y150.549 E.2771
G3 X77.472 Y148.572 I2.319 J-2.296 E.0739
G1 X73.701 Y108.032 E1.35058
G3 X74.027 Y106.293 I3.277 J-.286 E.05943
G1 X77.113 Y100.12 E.22894
G3 X78.124 Y98.937 I2.971 J1.516 E.05208
G1 X83.353 Y95.202 E.21318
G3 X85.225 Y94.602 I1.871 J2.618 E.06627
G1 X170.897 Y94.605 E2.8419
G3 X172.647 Y95.202 I-.14 J3.273 E.06217
G1 X177.876 Y98.937 E.21317
G3 X178.887 Y100.12 I-1.958 J2.696 E.05209
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.954 J1.454 E.05942
G1 X178.528 Y148.572 E1.35058
G3 X178.374 Y149.292 I-3.248 J-.319 E.02448
M204 S250
G1 X178.724 Y149.479 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X177.88 Y150.823 I-3.45 J-1.229 E.04915
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.562 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.019 J-3.644 E.08674
G1 X78.12 Y150.823 E.25698
G3 X77.082 Y148.613 I2.606 J-2.573 E.07651
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21235
G3 X77.892 Y98.621 I3.328 J1.703 E.05381
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.095 J2.94 E.06858
G1 X170.914 Y94.213 E2.63313
G3 X172.871 Y94.88 I-.16 J3.673 E.06439
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.2 J3.021 E.05383
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.314 J1.627 E.06147
G1 X178.918 Y148.613 E1.25133
G3 X178.743 Y149.422 I-3.644 J-.362 E.02551
; WIPE_START
M204 S10000
G1 X178.593 Y149.809 E-.15769
G1 X178.426 Y150.122 E-.13489
G1 X178.229 Y150.418 E-.1349
G1 X177.88 Y150.823 E-.20321
G1 X177.64 Y151.063 E-.12931
; WIPE_END
M73 P79 R6
G1 E-.04 F1800
G1 X171.826 Y156.009 Z4.4 F30000
G1 X170.762 Y156.915 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42089
G1 F15000
G1 X177.464 Y150.207 E.29206
G2 X178.103 Y149.039 I-2.104 J-1.909 E.04139
G1 X170.185 Y156.957 E.34488
G1 X170.122 Y156.978 E.00206
G3 X169.55 Y157.058 I-.609 J-2.266 E.01783
G1 X178.21 Y148.398 E.37721
G1 X178.265 Y147.808 E.01823
G1 X169.008 Y157.065 E.40318
G1 X168.474 Y157.065 E.01646
G1 X178.319 Y147.219 E.42885
G1 X178.374 Y146.63 E.01823
G1 X167.939 Y157.065 E.45452
G1 X167.405 Y157.065 E.01646
G1 X178.429 Y146.04 E.48019
G1 X178.484 Y145.451 E.01823
G1 X166.87 Y157.065 E.50586
G1 X166.336 Y157.065 E.01646
G1 X178.539 Y144.862 E.53153
G1 X178.593 Y144.272 E.01823
G1 X165.801 Y157.065 E.5572
G1 X165.267 Y157.065 E.01646
G1 X178.648 Y143.683 E.58287
G1 X178.703 Y143.094 E.01823
G1 X164.732 Y157.065 E.60854
G1 X164.197 Y157.065 E.01646
G1 X178.758 Y142.504 E.63422
G1 X178.813 Y141.915 E.01823
G1 X163.663 Y157.065 E.65989
G1 X163.128 Y157.065 E.01646
G1 X178.868 Y141.326 E.68556
G1 X178.922 Y140.736 E.01823
G1 X162.594 Y157.065 E.71123
G1 X162.059 Y157.065 E.01646
G1 X178.977 Y140.147 E.7369
G1 X179.032 Y139.557 E.01823
G1 X161.525 Y157.065 E.76257
G1 X160.99 Y157.065 E.01646
G1 X179.087 Y138.968 E.78824
G1 X179.142 Y138.379 E.01823
G1 X160.456 Y157.065 E.81391
G1 X159.921 Y157.065 E.01646
G1 X179.197 Y137.789 E.83958
G1 X179.251 Y137.2 E.01823
G1 X159.387 Y157.065 E.86525
G1 X158.852 Y157.065 E.01646
G1 X179.306 Y136.611 E.89092
G1 X179.361 Y136.021 E.01823
G1 X158.318 Y157.065 E.91659
G1 X157.783 Y157.065 E.01646
G1 X179.416 Y135.432 E.94226
G1 X179.471 Y134.843 E.01823
G1 X157.249 Y157.065 E.96794
G1 X156.714 Y157.065 E.01646
G1 X179.525 Y134.253 E.99361
G1 X179.58 Y133.664 E.01823
G1 X156.18 Y157.065 E1.01928
G1 X155.645 Y157.065 E.01646
G1 X179.635 Y133.075 E1.04495
G1 X179.69 Y132.485 E.01823
G1 X155.11 Y157.065 E1.07062
G1 X154.576 Y157.065 E.01646
G1 X179.745 Y131.896 E1.09629
G1 X179.8 Y131.307 E.01823
G1 X154.041 Y157.065 E1.12196
G1 X153.507 Y157.065 E.01646
G1 X179.854 Y130.717 E1.14763
G1 X179.909 Y130.128 E.01823
G1 X152.972 Y157.065 E1.1733
G1 X152.438 Y157.065 E.01646
G1 X179.964 Y129.538 E1.19897
G1 X180.019 Y128.949 E.01823
G1 X151.903 Y157.065 E1.22464
G1 X151.369 Y157.065 E.01646
G1 X180.074 Y128.36 E1.25031
G1 X180.129 Y127.77 E.01823
G1 X150.834 Y157.065 E1.27598
G1 X150.3 Y157.065 E.01646
G1 X180.183 Y127.181 E1.30165
G1 X180.238 Y126.592 E.01823
G1 X149.765 Y157.065 E1.32733
G1 X149.231 Y157.065 E.01646
G1 X180.293 Y126.002 E1.353
G1 X180.348 Y125.413 E.01823
G1 X148.696 Y157.065 E1.37867
G1 X148.162 Y157.065 E.01646
G1 X180.403 Y124.824 E1.40434
G1 X180.457 Y124.234 E.01823
G1 X147.627 Y157.065 E1.43001
G1 X147.093 Y157.065 E.01646
G1 X180.512 Y123.645 E1.45568
G1 X180.567 Y123.056 E.01823
G1 X146.558 Y157.065 E1.48135
G1 X146.023 Y157.065 E.01646
G1 X180.622 Y122.466 E1.50702
G1 X180.677 Y121.877 E.01823
G1 X145.489 Y157.065 E1.53269
G1 X144.954 Y157.065 E.01646
G1 X180.732 Y121.288 E1.55836
G1 X180.786 Y120.698 E.01823
G1 X144.42 Y157.065 E1.58403
G1 X143.885 Y157.065 E.01646
G1 X180.841 Y120.109 E1.6097
G1 X180.896 Y119.519 E.01823
G1 X143.351 Y157.065 E1.63537
G1 X142.816 Y157.065 E.01646
G1 X180.951 Y118.93 E1.66105
G1 X181.006 Y118.341 E.01823
G1 X142.282 Y157.065 E1.68672
G1 X141.747 Y157.065 E.01646
G1 X181.061 Y117.751 E1.71239
G1 X181.115 Y117.162 E.01823
G1 X141.213 Y157.065 E1.73806
G1 X140.678 Y157.065 E.01646
G1 X181.17 Y116.573 E1.76373
G1 X181.225 Y115.983 E.01823
G1 X140.144 Y157.065 E1.7894
G1 X139.609 Y157.065 E.01646
G1 X181.28 Y115.394 E1.81507
G1 X181.335 Y114.805 E.01823
G1 X139.075 Y157.065 E1.84074
G1 X138.54 Y157.065 E.01646
G1 X181.389 Y114.215 E1.86641
G1 X181.444 Y113.626 E.01823
G1 X138.006 Y157.065 E1.89208
G1 X137.471 Y157.065 E.01646
G1 X181.499 Y113.037 E1.91775
G1 X181.554 Y112.447 E.01823
G1 X136.936 Y157.065 E1.94342
G1 X136.402 Y157.065 E.01646
G1 X181.609 Y111.858 E1.96909
G1 X181.664 Y111.269 E.01823
G1 X135.867 Y157.065 E1.99476
G1 X135.333 Y157.065 E.01646
G1 X181.718 Y110.679 E2.02044
G1 X181.773 Y110.09 E.01823
G1 X134.798 Y157.065 E2.04611
G1 X134.264 Y157.065 E.01646
G1 X181.828 Y109.5 E2.07178
G1 X181.883 Y108.911 E.01823
G1 X133.729 Y157.065 E2.09745
G1 X133.195 Y157.065 E.01646
G1 X181.938 Y108.322 E2.12312
G2 X181.979 Y107.746 I-6.253 J-.74 E.01779
G1 X132.66 Y157.065 E2.14821
G1 X132.126 Y157.065 E.01646
G1 X181.937 Y107.254 E2.16964
G2 X181.832 Y106.824 I-1.956 J.246 E.01366
G1 X131.591 Y157.065 E2.18838
G1 X131.057 Y157.065 E.01646
G1 X181.674 Y106.447 E2.20476
G1 X181.496 Y106.091 E.01227
G1 X130.522 Y157.065 E2.22029
G1 X129.988 Y157.065 E.01646
G1 X181.318 Y105.734 E2.23582
G1 X181.14 Y105.378 E.01227
G1 X129.453 Y157.065 E2.25135
G1 X128.918 Y157.065 E.01646
G1 X180.962 Y105.021 E2.26688
G1 X180.784 Y104.665 E.01227
G1 X128.384 Y157.065 E2.28241
G1 X127.849 Y157.065 E.01646
G1 X180.606 Y104.308 E2.29793
G1 X180.428 Y103.952 E.01227
G1 X127.315 Y157.065 E2.31346
G1 X126.78 Y157.065 E.01646
G1 X180.25 Y103.595 E2.32899
G1 X180.072 Y103.239 E.01227
G1 X126.246 Y157.065 E2.34452
G1 X125.711 Y157.065 E.01646
G1 X179.894 Y102.882 E2.36005
G1 X179.716 Y102.526 E.01227
G1 X125.177 Y157.065 E2.37558
G1 X124.642 Y157.065 E.01646
G1 X179.538 Y102.169 E2.39111
G1 X179.36 Y101.813 E.01227
G1 X124.108 Y157.065 E2.40663
G1 X123.573 Y157.065 E.01646
G1 X179.182 Y101.456 E2.42216
G1 X179.004 Y101.1 E.01227
G1 X123.039 Y157.065 E2.43769
G1 X122.504 Y157.065 E.01646
G1 X178.826 Y100.743 E2.45322
G1 X178.648 Y100.387 E.01227
G1 X121.97 Y157.065 E2.46875
G1 X121.435 Y157.065 E.01646
G1 X178.46 Y100.04 E2.48385
G2 X178.235 Y99.73 I-1.373 J.76 E.01182
G1 X120.901 Y157.065 E2.49734
G1 X120.366 Y157.065 E.01646
G1 X177.975 Y99.456 E2.5093
G2 X177.685 Y99.211 I-1.142 J1.059 E.01171
G1 X119.831 Y157.065 E2.51996
G1 X119.297 Y157.065 E.01646
G1 X177.374 Y98.988 E2.52967
G1 X177.062 Y98.765 E.0118
G1 X118.762 Y157.065 E2.53937
G1 X118.228 Y157.065 E.01646
M73 P80 R6
G1 X176.75 Y98.543 E2.54906
G1 X176.438 Y98.32 E.0118
G1 X117.693 Y157.065 E2.55876
G1 X117.159 Y157.065 E.01646
G1 X176.126 Y98.098 E2.56845
G1 X175.814 Y97.875 E.0118
G1 X116.624 Y157.065 E2.57814
G1 X116.09 Y157.065 E.01646
G1 X175.502 Y97.653 E2.58784
G1 X175.19 Y97.43 E.0118
G1 X115.555 Y157.065 E2.59753
G1 X115.021 Y157.065 E.01646
G1 X174.878 Y97.208 E2.60723
G1 X174.566 Y96.985 E.0118
G1 X114.486 Y157.065 E2.61692
G1 X113.952 Y157.065 E.01646
G1 X174.254 Y96.762 E2.62661
G1 X173.942 Y96.54 E.0118
G1 X113.417 Y157.065 E2.63631
G1 X112.883 Y157.065 E.01646
G1 X173.63 Y96.317 E2.646
G1 X173.318 Y96.095 E.0118
G1 X112.348 Y157.065 E2.6557
G1 X111.814 Y157.065 E.01646
G1 X173.006 Y95.872 E2.66539
G1 X172.694 Y95.65 E.0118
G1 X111.279 Y157.065 E2.67509
G1 X110.744 Y157.065 E.01646
G1 X172.382 Y95.427 E2.68478
G2 X172.042 Y95.233 I-.984 J1.332 E.0121
G1 X110.21 Y157.065 E2.69323
G1 X109.675 Y157.065 E.01646
G1 X171.661 Y95.079 E2.69993
G2 X171.231 Y94.974 I-.578 J1.438 E.01367
G1 X109.141 Y157.065 E2.70449
G1 X108.606 Y157.065 E.01646
G1 X170.733 Y94.938 E2.70607
G1 X170.198 Y94.938 E.01646
G1 X108.072 Y157.065 E2.70607
G1 X107.537 Y157.065 E.01646
G1 X169.664 Y94.938 E2.70607
G1 X169.129 Y94.938 E.01646
G1 X107.003 Y157.065 E2.70607
G1 X106.468 Y157.065 E.01646
G1 X168.595 Y94.938 E2.70607
G1 X168.06 Y94.938 E.01646
G1 X105.934 Y157.065 E2.70607
G1 X105.399 Y157.065 E.01646
G1 X167.526 Y94.938 E2.70607
G1 X166.991 Y94.938 E.01646
G1 X104.865 Y157.065 E2.70608
G1 X104.33 Y157.065 E.01646
G1 X166.457 Y94.938 E2.70608
G1 X165.922 Y94.938 E.01646
G1 X103.796 Y157.065 E2.70608
G1 X103.261 Y157.065 E.01646
G1 X165.388 Y94.938 E2.70608
G1 X164.853 Y94.938 E.01646
G1 X102.726 Y157.065 E2.70608
G1 X102.192 Y157.065 E.01646
G1 X164.319 Y94.938 E2.70608
G1 X163.784 Y94.938 E.01646
G1 X101.657 Y157.065 E2.70608
G1 X101.123 Y157.065 E.01646
G1 X163.25 Y94.938 E2.70608
G1 X162.715 Y94.938 E.01646
G1 X100.588 Y157.065 E2.70608
G1 X100.054 Y157.065 E.01646
G1 X162.181 Y94.938 E2.70608
G1 X161.646 Y94.938 E.01646
G1 X99.519 Y157.065 E2.70608
G1 X98.985 Y157.065 E.01646
G1 X161.112 Y94.938 E2.70608
G1 X160.577 Y94.938 E.01646
M73 P80 R5
G1 X98.45 Y157.065 E2.70608
G1 X97.916 Y157.065 E.01646
G1 X160.043 Y94.938 E2.70609
G1 X159.508 Y94.938 E.01646
G1 X97.381 Y157.065 E2.70609
G1 X96.847 Y157.065 E.01646
G1 X158.974 Y94.938 E2.70609
G1 X158.439 Y94.938 E.01646
G1 X96.312 Y157.065 E2.70609
G1 X95.778 Y157.065 E.01646
G1 X157.904 Y94.938 E2.70609
G1 X157.37 Y94.938 E.01646
G1 X95.243 Y157.065 E2.70609
G1 X94.709 Y157.065 E.01646
G1 X156.835 Y94.938 E2.70609
G1 X156.301 Y94.938 E.01646
G1 X94.174 Y157.065 E2.70609
G1 X93.639 Y157.065 E.01646
G1 X155.766 Y94.938 E2.70609
G1 X155.232 Y94.938 E.01646
G1 X93.105 Y157.065 E2.70609
G1 X92.57 Y157.065 E.01646
G1 X154.697 Y94.938 E2.70609
G1 X154.163 Y94.938 E.01646
G1 X92.036 Y157.065 E2.70609
G1 X91.501 Y157.065 E.01646
G1 X153.628 Y94.938 E2.7061
G1 X153.094 Y94.938 E.01646
G1 X90.967 Y157.065 E2.7061
G1 X90.432 Y157.065 E.01646
G1 X152.559 Y94.938 E2.7061
G1 X152.025 Y94.938 E.01646
G1 X89.898 Y157.065 E2.7061
G1 X89.363 Y157.065 E.01646
G1 X151.49 Y94.938 E2.7061
G1 X150.956 Y94.938 E.01646
G1 X88.829 Y157.065 E2.7061
G1 X88.294 Y157.065 E.01646
G1 X150.421 Y94.938 E2.7061
G1 X149.887 Y94.938 E.01646
G1 X87.76 Y157.065 E2.7061
G1 X87.225 Y157.065 E.01646
M73 P81 R5
G1 X149.352 Y94.938 E2.7061
G1 X148.818 Y94.938 E.01646
G1 X86.691 Y157.065 E2.7061
G3 X86.189 Y157.032 I-.024 J-3.458 E.01549
G1 X148.283 Y94.937 E2.70466
G1 X147.749 Y94.937 E.01646
G1 X85.751 Y156.936 E2.70048
G3 X85.364 Y156.788 I.305 J-1.38 E.0128
G1 X147.214 Y94.937 E2.69405
G1 X146.68 Y94.937 E.01646
G1 X85.017 Y156.6 E2.68587
G3 X84.711 Y156.372 I1.007 J-1.669 E.01178
G1 X146.145 Y94.937 E2.67592
G1 X145.611 Y94.937 E.01646
G1 X84.438 Y156.11 E2.66452
G1 X84.171 Y155.843 E.01164
G1 X145.076 Y94.937 E2.65288
G1 X144.542 Y94.937 E.01646
G1 X83.903 Y155.576 E2.64125
G1 X83.636 Y155.309 E.01164
G1 X144.007 Y94.937 E2.62961
G1 X143.473 Y94.937 E.01646
G1 X83.369 Y155.041 E2.61798
G1 X83.101 Y154.774 E.01164
G1 X142.938 Y94.937 E2.60634
G1 X142.404 Y94.937 E.01646
G1 X82.834 Y154.507 E2.59471
G1 X82.566 Y154.24 E.01164
G1 X141.869 Y94.937 E2.58307
G1 X141.335 Y94.937 E.01646
G1 X82.299 Y153.973 E2.57144
G1 X82.032 Y153.706 E.01164
G1 X140.8 Y94.937 E2.5598
G1 X140.266 Y94.937 E.01646
G1 X81.764 Y153.439 E2.54817
G1 X81.497 Y153.171 E.01164
G1 X139.731 Y94.937 E2.53653
G1 X139.197 Y94.937 E.01646
G1 X81.229 Y152.904 E2.5249
G1 X80.962 Y152.637 E.01164
G1 X138.662 Y94.937 E2.51326
G1 X138.128 Y94.937 E.01646
G1 X80.695 Y152.37 E2.50163
G1 X80.427 Y152.103 E.01164
G1 X137.593 Y94.937 E2.48999
G1 X137.059 Y94.937 E.01646
G1 X80.16 Y151.836 E2.47836
G1 X79.893 Y151.569 E.01164
G1 X136.524 Y94.937 E2.46672
G1 X135.989 Y94.937 E.01646
G1 X79.625 Y151.301 E2.45509
G1 X79.358 Y151.034 E.01164
G1 X135.455 Y94.937 E2.44345
G1 X134.92 Y94.937 E.01646
G1 X79.09 Y150.767 E2.43182
G1 X78.823 Y150.5 E.01164
G1 X134.386 Y94.937 E2.42018
G1 X133.851 Y94.937 E.01646
G1 X78.56 Y150.229 E2.40836
G3 X78.324 Y149.93 I1.077 J-1.093 E.01175
G1 X133.317 Y94.937 E2.39535
G1 X132.782 Y94.937 E.01646
G1 X78.118 Y149.601 E2.38104
G3 X77.96 Y149.225 I1.435 J-.825 E.0126
G1 X132.248 Y94.937 E2.36465
G1 X131.713 Y94.937 E.01646
G1 X77.844 Y148.806 E2.3464
G3 X77.784 Y148.332 I4.131 J-.764 E.01474
G1 X131.179 Y94.937 E2.32574
G1 X130.644 Y94.937 E.01646
G1 X77.739 Y147.843 E2.30444
G1 X77.693 Y147.354 E.01513
G1 X130.11 Y94.937 E2.28314
G1 X129.575 Y94.937 E.01646
G1 X77.648 Y146.864 E2.26184
G1 X77.602 Y146.375 E.01513
G1 X129.041 Y94.937 E2.24054
G1 X128.506 Y94.937 E.01646
G1 X77.557 Y145.886 E2.21923
G1 X77.511 Y145.397 E.01513
G1 X127.972 Y94.937 E2.19793
G1 X127.437 Y94.937 E.01646
G1 X77.466 Y144.908 E2.17663
G1 X77.42 Y144.419 E.01513
G1 X126.903 Y94.937 E2.15533
G1 X126.368 Y94.937 E.01646
G1 X77.375 Y143.93 E2.13403
G1 X77.329 Y143.441 E.01513
G1 X125.834 Y94.937 E2.11273
G1 X125.299 Y94.937 E.01646
G1 X77.284 Y142.952 E2.09143
G1 X77.238 Y142.463 E.01513
G1 X124.765 Y94.937 E2.07013
G1 X124.23 Y94.937 E.01646
G1 X77.193 Y141.974 E2.04883
G1 X77.147 Y141.485 E.01513
M73 P82 R5
G1 X123.696 Y94.937 E2.02753
G1 X123.161 Y94.937 E.01646
G1 X77.102 Y140.996 E2.00623
G1 X77.056 Y140.507 E.01513
G1 X122.627 Y94.937 E1.98493
G1 X122.092 Y94.937 E.01646
G1 X77.011 Y140.018 E1.96363
G1 X76.965 Y139.529 E.01513
G1 X121.558 Y94.937 E1.94233
G1 X121.023 Y94.937 E.01646
G1 X76.92 Y139.04 E1.92103
G1 X76.874 Y138.551 E.01513
G1 X120.489 Y94.937 E1.89973
G1 X119.954 Y94.937 E.01646
G1 X76.829 Y138.062 E1.87843
G1 X76.783 Y137.573 E.01513
G1 X119.42 Y94.936 E1.85713
G1 X118.885 Y94.936 E.01646
G1 X76.738 Y137.084 E1.83583
G1 X76.692 Y136.595 E.01513
G1 X118.351 Y94.936 E1.81453
G1 X117.816 Y94.936 E.01646
G1 X76.647 Y136.106 E1.79323
G1 X76.601 Y135.617 E.01513
G1 X117.282 Y94.936 E1.77193
G1 X116.747 Y94.936 E.01646
G1 X76.556 Y135.128 E1.75062
G1 X76.51 Y134.639 E.01513
G1 X116.213 Y94.936 E1.72932
G1 X115.678 Y94.936 E.01646
G1 X76.465 Y134.149 E1.70802
G1 X76.419 Y133.66 E.01513
G1 X115.144 Y94.936 E1.68672
G1 X114.609 Y94.936 E.01646
G1 X76.374 Y133.171 E1.66542
G1 X76.328 Y132.682 E.01513
G1 X114.075 Y94.936 E1.64412
G1 X113.54 Y94.936 E.01646
G1 X76.283 Y132.193 E1.62282
G1 X76.237 Y131.704 E.01513
G1 X113.005 Y94.936 E1.60152
G1 X112.471 Y94.936 E.01646
G1 X76.192 Y131.215 E1.58022
G1 X76.146 Y130.726 E.01513
G1 X111.936 Y94.936 E1.55892
G1 X111.402 Y94.936 E.01646
G1 X76.101 Y130.237 E1.53762
G1 X76.055 Y129.748 E.01513
G1 X110.867 Y94.936 E1.51632
G1 X110.333 Y94.936 E.01646
G1 X76.01 Y129.259 E1.49502
G1 X75.964 Y128.77 E.01513
G1 X109.798 Y94.936 E1.47372
G1 X109.264 Y94.936 E.01646
G1 X75.919 Y128.281 E1.45242
G1 X75.874 Y127.792 E.01513
G1 X108.729 Y94.936 E1.43112
G1 X108.195 Y94.936 E.01646
G1 X75.828 Y127.303 E1.40982
G1 X75.783 Y126.814 E.01513
G1 X107.66 Y94.936 E1.38852
G1 X107.126 Y94.936 E.01646
G1 X75.737 Y126.325 E1.36722
G1 X75.692 Y125.836 E.01513
G1 X106.591 Y94.936 E1.34592
G1 X106.057 Y94.936 E.01646
G1 X75.646 Y125.347 E1.32462
G1 X75.601 Y124.858 E.01513
G1 X105.522 Y94.936 E1.30331
G1 X104.988 Y94.936 E.01646
G1 X75.555 Y124.369 E1.28201
G1 X75.51 Y123.88 E.01513
G1 X104.453 Y94.936 E1.26071
G1 X103.919 Y94.936 E.01646
G1 X75.464 Y123.391 E1.23941
G1 X75.419 Y122.902 E.01513
G1 X103.384 Y94.936 E1.21811
G1 X102.85 Y94.936 E.01646
G1 X75.373 Y122.413 E1.19681
G1 X75.328 Y121.924 E.01513
G1 X102.315 Y94.936 E1.17551
G1 X101.781 Y94.936 E.01646
G1 X75.282 Y121.434 E1.15421
G1 X75.237 Y120.945 E.01513
G1 X101.246 Y94.936 E1.13291
G1 X100.712 Y94.936 E.01646
G1 X75.191 Y120.456 E1.11161
G1 X75.146 Y119.967 E.01513
G1 X100.177 Y94.936 E1.09031
G1 X99.643 Y94.936 E.01646
G1 X75.1 Y119.478 E1.06901
G1 X75.055 Y118.989 E.01513
G1 X99.108 Y94.936 E1.04771
G1 X98.574 Y94.936 E.01646
G1 X75.009 Y118.5 E1.02641
G1 X74.964 Y118.011 E.01513
G1 X98.039 Y94.936 E1.00511
G1 X97.505 Y94.936 E.01646
G1 X74.918 Y117.522 E.98381
G1 X74.873 Y117.033 E.01513
G1 X96.97 Y94.936 E.96251
G1 X96.436 Y94.936 E.01646
G1 X74.827 Y116.544 E.94121
G1 X74.782 Y116.055 E.01513
G1 X95.901 Y94.936 E.91991
G1 X95.367 Y94.936 E.01646
M73 P83 R5
G1 X74.736 Y115.566 E.89861
G1 X74.691 Y115.077 E.01513
G1 X94.832 Y94.936 E.87731
G1 X94.298 Y94.936 E.01646
G1 X74.645 Y114.588 E.85601
G1 X74.6 Y114.099 E.01513
G1 X93.763 Y94.936 E.8347
G1 X93.229 Y94.936 E.01646
G1 X74.554 Y113.61 E.8134
G1 X74.509 Y113.121 E.01513
G1 X92.694 Y94.936 E.7921
G1 X92.16 Y94.936 E.01646
G1 X74.463 Y112.632 E.7708
G1 X74.418 Y112.143 E.01513
G1 X91.625 Y94.936 E.7495
G1 X91.09 Y94.936 E.01646
G1 X74.372 Y111.654 E.7282
G1 X74.327 Y111.165 E.01513
G1 X90.556 Y94.936 E.7069
G1 X90.021 Y94.935 E.01646
G1 X74.281 Y110.676 E.6856
G1 X74.236 Y110.187 E.01513
G1 X89.487 Y94.935 E.6643
G1 X88.952 Y94.935 E.01646
G1 X74.19 Y109.698 E.643
G1 X74.145 Y109.209 E.01513
G1 X88.418 Y94.935 E.6217
G1 X87.883 Y94.935 E.01646
G1 X74.099 Y108.72 E.6004
G1 X74.054 Y108.23 E.01513
G1 X87.349 Y94.935 E.5791
G1 X86.814 Y94.935 E.01646
G1 X74.02 Y107.729 E.55726
G3 X74.086 Y107.129 I3.181 J.047 E.0186
G1 X86.28 Y94.935 E.53113
G1 X85.745 Y94.935 E.01646
G1 X74.411 Y106.27 E.49371
G1 X74.945 Y105.201 E.03681
G1 X85.21 Y94.936 E.44709
G2 X84.605 Y95.007 I-.011 J2.545 E.0188
G1 X75.48 Y104.132 E.39747
G1 X76.014 Y103.063 E.03681
G1 X83.707 Y95.37 E.33506
G1 X81.876 Y96.667 E.06909
G1 X76.549 Y101.994 E.23204
G1 X77.083 Y100.925 E.03681
G1 X80.005 Y98.003 E.12726
G1 X78.327 Y99.201 E.0635
G1 X78.004 Y99.47 E.01296
G1 X77.239 Y100.235 E.03332
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X78.004 Y99.47 E-.41114
G1 X78.327 Y99.201 E-.1599
G1 X78.732 Y98.912 E-.18896
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 21/23
; update layer progress
M73 L21
M991 S0 P20 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.4 I-.55 J1.086 P1  F30000
G1 X178.354 Y149.348 Z4.4
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X177.599 Y150.549 I-3.074 J-1.096 E.04743
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27711
G3 X169.418 Y157.398 I-2.292 J-2.318 E.08373
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.011 J-3.243 E.08376
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.572 I2.319 J-2.296 E.0739
G1 X73.701 Y108.032 E1.35058
G3 X74.027 Y106.292 I3.277 J-.286 E.05944
G1 X77.113 Y100.12 E.22893
G3 X78.124 Y98.937 I2.97 J1.515 E.05207
G1 X83.353 Y95.202 E.21318
G3 X85.225 Y94.602 I1.871 J2.62 E.06627
G1 X170.907 Y94.605 E2.84223
G3 X172.647 Y95.202 I-.152 J3.275 E.06182
G1 X177.876 Y98.937 E.21317
G3 X178.887 Y100.119 I-1.958 J2.696 E.05208
G1 X181.973 Y106.293 E.22896
G3 X182.299 Y108.032 I-2.975 J1.458 E.05941
G1 X178.528 Y148.571 E1.35057
G3 X178.374 Y149.292 I-3.248 J-.318 E.0245
M204 S250
G1 X178.728 Y149.479 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.724 Y149.479 E.00013
G3 X177.88 Y150.823 I-3.449 J-1.229 E.04914
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.568 J-2.604 E.08671
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.017 J-3.639 E.08674
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06149
G1 X76.765 Y99.94 E.21233
G3 X77.892 Y98.621 I3.328 J1.703 E.05381
G1 X83.129 Y94.88 E.19776
G3 X85.221 Y94.21 I2.096 J2.942 E.06858
G1 X170.925 Y94.213 E2.63345
G3 X172.871 Y94.88 I-.172 J3.676 E.06406
G1 X178.108 Y98.621 E.19774
G3 X179.235 Y99.94 I-2.2 J3.022 E.05382
G1 X182.326 Y106.121 E.21235
G3 X182.69 Y108.064 I-3.338 J1.631 E.06146
G1 X178.918 Y148.612 E1.25133
G3 X178.826 Y149.14 I-3.644 J-.362 E.01646
G1 X178.745 Y149.421 E.00901
; WIPE_START
M204 S10000
G1 X178.724 Y149.479 E-.02342
G1 X178.593 Y149.809 E-.13479
G1 X178.426 Y150.122 E-.13496
G1 X178.229 Y150.418 E-.13488
G1 X177.88 Y150.823 E-.20323
G1 X177.641 Y151.062 E-.12872
; WIPE_END
G1 E-.04 F1800
G1 X177.81 Y143.432 Z4.6 F30000
G1 X178.768 Y100.249 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42087
G1 F15000
G1 X177.901 Y99.381 E.03779
G1 X177.676 Y99.204 E.00882
G1 X175.976 Y97.991 E.06432
G1 X178.923 Y100.938 E.12835
G1 X179.456 Y102.005 E.03675
G1 X174.111 Y96.66 E.23281
G1 X172.28 Y95.364 E.0691
G1 X179.989 Y103.073 E.33578
G1 X180.522 Y104.141 E.03675
G1 X171.391 Y95.009 E.39772
G2 X170.786 Y94.938 I-.622 J2.692 E.01881
G1 X181.055 Y105.208 E.4473
G1 X181.588 Y106.276 E.03675
G1 X170.251 Y94.938 E.4938
G1 X169.716 Y94.938 E.01646
G1 X181.915 Y107.137 E.53133
G3 X181.98 Y107.736 I-4.72 J.809 E.01856
G1 X169.182 Y94.938 E.5574
G1 X168.647 Y94.938 E.01646
G1 X181.946 Y108.237 E.5792
G1 X181.9 Y108.726 E.01513
G1 X168.113 Y94.938 E.6005
G1 X167.578 Y94.938 E.01646
G1 X181.855 Y109.215 E.6218
G1 X181.809 Y109.704 E.01513
G1 X167.044 Y94.938 E.6431
G1 X166.509 Y94.938 E.01646
G1 X181.764 Y110.193 E.6644
G1 X181.718 Y110.682 E.01513
G1 X165.975 Y94.938 E.6857
G1 X165.44 Y94.938 E.01646
G1 X181.673 Y111.171 E.707
G1 X181.627 Y111.66 E.01513
G1 X164.906 Y94.938 E.7283
G1 X164.371 Y94.938 E.01646
G1 X181.582 Y112.149 E.7496
G1 X181.536 Y112.638 E.01513
G1 X163.837 Y94.938 E.7709
G1 X163.302 Y94.938 E.01646
G1 X181.491 Y113.127 E.7922
G1 X181.445 Y113.616 E.01513
G1 X162.768 Y94.938 E.8135
G1 X162.233 Y94.938 E.01646
G1 X181.4 Y114.105 E.8348
G1 X181.354 Y114.594 E.01513
G1 X161.699 Y94.938 E.8561
G1 X161.164 Y94.938 E.01646
G1 X181.309 Y115.083 E.8774
G1 X181.263 Y115.572 E.01513
G1 X160.63 Y94.938 E.8987
G1 X160.095 Y94.938 E.01646
G1 X181.218 Y116.061 E.92
G1 X181.172 Y116.55 E.01513
G1 X159.561 Y94.938 E.9413
G1 X159.026 Y94.938 E.01646
G1 X181.127 Y117.039 E.9626
G1 X181.081 Y117.528 E.01513
G1 X158.492 Y94.938 E.9839
G1 X157.957 Y94.938 E.01646
G1 X181.036 Y118.017 E1.0052
G1 X180.99 Y118.506 E.01513
G1 X157.422 Y94.938 E1.0265
G1 X156.888 Y94.938 E.01646
G1 X180.945 Y118.995 E1.0478
G1 X180.899 Y119.484 E.01513
G1 X156.353 Y94.938 E1.0691
G1 X155.819 Y94.938 E.01646
M73 P83 R4
G1 X180.854 Y119.973 E1.0904
G1 X180.808 Y120.462 E.01513
G1 X155.284 Y94.938 E1.1117
G1 X154.75 Y94.938 E.01646
G1 X180.763 Y120.951 E1.133
G1 X180.717 Y121.44 E.01513
G1 X154.215 Y94.938 E1.1543
G1 X153.681 Y94.938 E.01646
G1 X180.672 Y121.929 E1.1756
G1 X180.626 Y122.418 E.01513
G1 X153.146 Y94.938 E1.1969
G1 X152.612 Y94.938 E.01646
G1 X180.581 Y122.907 E1.2182
G1 X180.535 Y123.396 E.01513
G1 X152.077 Y94.938 E1.2395
G1 X151.543 Y94.938 E.01646
G1 X180.49 Y123.885 E1.2608
G1 X180.444 Y124.374 E.01513
G1 X151.008 Y94.938 E1.2821
G1 X150.474 Y94.938 E.01646
G1 X180.399 Y124.863 E1.3034
G1 X180.353 Y125.352 E.01513
G1 X149.939 Y94.938 E1.3247
G1 X149.405 Y94.938 E.01646
G1 X180.308 Y125.841 E1.346
G1 X180.262 Y126.33 E.01513
G1 X148.87 Y94.938 E1.3673
G1 X148.336 Y94.938 E.01646
G1 X180.217 Y126.819 E1.3886
G1 X180.172 Y127.308 E.01513
G1 X147.801 Y94.938 E1.4099
G1 X147.267 Y94.938 E.01646
G1 X180.126 Y127.797 E1.4312
G1 X180.081 Y128.286 E.01513
G1 X146.732 Y94.938 E1.4525
G1 X146.198 Y94.938 E.01646
G1 X180.035 Y128.775 E1.4738
G1 X179.99 Y129.264 E.01513
G1 X145.663 Y94.938 E1.4951
G1 X145.128 Y94.938 E.01646
G1 X179.944 Y129.753 E1.5164
G1 X179.899 Y130.242 E.01513
G1 X144.594 Y94.938 E1.5377
G1 X144.059 Y94.937 E.01646
G1 X179.853 Y130.731 E1.559
G1 X179.808 Y131.22 E.01513
G1 X143.525 Y94.937 E1.5803
G1 X142.99 Y94.937 E.01646
G1 X179.762 Y131.709 E1.6016
G1 X179.717 Y132.198 E.01513
G1 X142.456 Y94.937 E1.6229
G1 X141.921 Y94.937 E.01646
G1 X179.671 Y132.687 E1.6442
G1 X179.626 Y133.176 E.01513
G1 X141.387 Y94.937 E1.6655
G1 X140.852 Y94.937 E.01646
G1 X179.58 Y133.665 E1.6868
G1 X179.535 Y134.154 E.01513
G1 X140.318 Y94.937 E1.7081
G1 X139.783 Y94.937 E.01646
M73 P84 R4
G1 X179.489 Y134.643 E1.7294
G1 X179.444 Y135.132 E.01513
G1 X139.249 Y94.937 E1.7507
G1 X138.714 Y94.937 E.01646
G1 X179.398 Y135.621 E1.772
G1 X179.353 Y136.11 E.01513
G1 X138.18 Y94.937 E1.7933
G1 X137.645 Y94.937 E.01646
G1 X179.307 Y136.599 E1.8146
G1 X179.262 Y137.088 E.01513
G1 X137.111 Y94.937 E1.8359
G1 X136.576 Y94.937 E.01646
G1 X179.216 Y137.577 E1.8572
G1 X179.171 Y138.066 E.01513
G1 X136.042 Y94.937 E1.8785
G1 X135.507 Y94.937 E.01646
G1 X179.125 Y138.555 E1.8998
G1 X179.08 Y139.044 E.01513
G1 X134.973 Y94.937 E1.9211
G1 X134.438 Y94.937 E.01646
G1 X179.034 Y139.533 E1.9424
G1 X178.989 Y140.022 E.01513
G1 X133.904 Y94.937 E1.9637
G1 X133.369 Y94.937 E.01646
G1 X178.943 Y140.511 E1.985
G1 X178.898 Y141 E.01513
G1 X132.834 Y94.937 E2.0063
G1 X132.3 Y94.937 E.01646
G1 X178.852 Y141.489 E2.0276
G1 X178.807 Y141.978 E.01513
G1 X131.765 Y94.937 E2.0489
G1 X131.231 Y94.937 E.01646
G1 X178.761 Y142.467 E2.0702
G1 X178.716 Y142.956 E.01513
G1 X130.696 Y94.937 E2.0915
G1 X130.162 Y94.937 E.01646
G1 X178.67 Y143.445 E2.11279
G1 X178.625 Y143.935 E.01513
G1 X129.627 Y94.937 E2.1341
G1 X129.093 Y94.937 E.01646
G1 X178.579 Y144.424 E2.15539
G1 X178.534 Y144.913 E.01513
G1 X128.558 Y94.937 E2.17669
G1 X128.024 Y94.937 E.01646
G1 X178.488 Y145.402 E2.19799
G1 X178.443 Y145.891 E.01513
G1 X127.489 Y94.937 E2.21929
G1 X126.955 Y94.937 E.01646
G1 X178.397 Y146.38 E2.24059
G1 X178.352 Y146.869 E.01513
G1 X126.42 Y94.937 E2.26189
G1 X125.886 Y94.937 E.01646
G1 X178.306 Y147.358 E2.28319
G1 X178.261 Y147.847 E.01513
G1 X125.351 Y94.937 E2.30449
G1 X124.817 Y94.937 E.01646
G1 X178.215 Y148.336 E2.32579
G3 X178.151 Y148.806 I-3.228 J-.203 E.01462
G1 X124.282 Y94.937 E2.34627
G1 X123.748 Y94.937 E.01646
G1 X178.039 Y149.228 E2.36466
G3 X177.882 Y149.606 I-1.598 J-.44 E.01263
G1 X123.213 Y94.937 E2.38112
G1 X122.679 Y94.937 E.01646
G1 X177.676 Y149.935 E2.39544
G3 X177.439 Y150.232 I-1.321 J-.809 E.01174
G1 X122.144 Y94.937 E2.4084
G1 X121.61 Y94.937 E.01646
G1 X177.172 Y150.499 E2.42005
G1 X176.905 Y150.767 E.01164
G1 X121.075 Y94.937 E2.43169
G1 X120.54 Y94.937 E.01646
G1 X176.638 Y151.034 E2.44334
G1 X176.371 Y151.302 E.01164
G1 X120.006 Y94.937 E2.45498
G1 X119.471 Y94.937 E.01646
G1 X176.104 Y151.569 E2.46663
G1 X175.837 Y151.836 E.01164
G1 X118.937 Y94.937 E2.47828
G1 X118.402 Y94.937 E.01646
G1 X175.57 Y152.104 E2.48992
G1 X175.302 Y152.371 E.01164
G1 X117.868 Y94.937 E2.50157
G1 X117.333 Y94.937 E.01646
G1 X175.035 Y152.638 E2.51322
G1 X174.768 Y152.906 E.01164
G1 X116.799 Y94.936 E2.52486
G1 X116.264 Y94.936 E.01646
G1 X174.501 Y153.173 E2.53651
G1 X174.234 Y153.441 E.01164
G1 X115.73 Y94.936 E2.54816
G1 X115.195 Y94.936 E.01646
G1 X173.967 Y153.708 E2.5598
G1 X173.7 Y153.975 E.01164
G1 X114.661 Y94.936 E2.57145
G1 X114.126 Y94.936 E.01646
G1 X173.433 Y154.243 E2.5831
G1 X173.165 Y154.51 E.01164
G1 X113.592 Y94.936 E2.59474
G1 X113.057 Y94.936 E.01646
G1 X172.898 Y154.778 E2.60639
G1 X172.631 Y155.045 E.01164
G1 X112.523 Y94.936 E2.61804
G1 X111.988 Y94.936 E.01646
G1 X172.364 Y155.312 E2.62968
G1 X172.097 Y155.58 E.01164
G1 X111.454 Y94.936 E2.64133
G1 X110.919 Y94.936 E.01646
G1 X171.83 Y155.847 E2.65298
G1 X171.563 Y156.114 E.01164
G1 X110.385 Y94.936 E2.66462
G1 X109.85 Y94.936 E.01646
G1 X171.287 Y156.374 E2.67591
G3 X170.979 Y156.599 I-1.066 J-1.133 E.01181
G1 X109.316 Y94.936 E2.68575
G1 X108.781 Y94.936 E.01646
G1 X170.634 Y156.789 E2.69401
G3 X170.247 Y156.936 I-.691 J-1.233 E.0128
G1 X108.246 Y94.936 E2.70043
G1 X107.712 Y94.936 E.01646
G1 X169.808 Y157.032 E2.7046
G3 X169.306 Y157.065 I-.476 J-3.466 E.01551
G1 X107.177 Y94.936 E2.70602
G1 X106.643 Y94.936 E.01646
G1 X168.771 Y157.065 E2.70602
G1 X168.237 Y157.065 E.01646
G1 X106.108 Y94.936 E2.70602
G1 X105.574 Y94.936 E.01646
G1 X167.702 Y157.065 E2.70602
G1 X167.168 Y157.065 E.01646
G1 X105.039 Y94.936 E2.70602
G1 X104.505 Y94.936 E.01646
G1 X166.633 Y157.065 E2.70602
G1 X166.099 Y157.065 E.01646
G1 X103.97 Y94.936 E2.70602
G1 X103.436 Y94.936 E.01646
G1 X165.564 Y157.065 E2.70602
G1 X165.03 Y157.065 E.01646
G1 X102.901 Y94.936 E2.70602
G1 X102.367 Y94.936 E.01646
G1 X164.495 Y157.065 E2.70603
G1 X163.961 Y157.065 E.01646
G1 X101.832 Y94.936 E2.70603
G1 X101.298 Y94.936 E.01646
G1 X163.426 Y157.065 E2.70603
G1 X162.892 Y157.065 E.01646
G1 X100.763 Y94.936 E2.70603
G1 X100.229 Y94.936 E.01646
G1 X162.357 Y157.065 E2.70603
G1 X161.823 Y157.065 E.01646
G1 X99.694 Y94.936 E2.70603
G1 X99.16 Y94.936 E.01646
G1 X161.288 Y157.065 E2.70603
G1 X160.754 Y157.065 E.01646
G1 X98.625 Y94.936 E2.70603
G1 X98.091 Y94.936 E.01646
G1 X160.219 Y157.065 E2.70603
G1 X159.685 Y157.065 E.01646
M73 P85 R4
G1 X97.556 Y94.936 E2.70603
G1 X97.022 Y94.936 E.01646
G1 X159.15 Y157.065 E2.70603
G1 X158.616 Y157.065 E.01646
G1 X96.487 Y94.936 E2.70603
G1 X95.952 Y94.936 E.01646
G1 X158.081 Y157.065 E2.70604
G1 X157.547 Y157.065 E.01646
G1 X95.418 Y94.936 E2.70604
G1 X94.883 Y94.936 E.01646
G1 X157.012 Y157.065 E2.70604
G1 X156.478 Y157.065 E.01646
G1 X94.349 Y94.936 E2.70604
G1 X93.814 Y94.936 E.01646
G1 X155.943 Y157.065 E2.70604
G1 X155.409 Y157.065 E.01646
G1 X93.28 Y94.936 E2.70604
G1 X92.745 Y94.936 E.01646
G1 X154.874 Y157.065 E2.70604
G1 X154.34 Y157.065 E.01646
G1 X92.211 Y94.936 E2.70604
G1 X91.676 Y94.936 E.01646
G1 X153.805 Y157.065 E2.70604
G1 X153.271 Y157.065 E.01646
G1 X91.142 Y94.936 E2.70604
G1 X90.607 Y94.936 E.01646
G1 X152.736 Y157.065 E2.70604
G1 X152.202 Y157.065 E.01646
G1 X90.073 Y94.935 E2.70605
G1 X89.538 Y94.935 E.01646
G1 X151.667 Y157.065 E2.70605
G1 X151.133 Y157.065 E.01646
G1 X89.004 Y94.935 E2.70605
G1 X88.469 Y94.935 E.01646
G1 X150.598 Y157.065 E2.70605
G1 X150.064 Y157.065 E.01646
G1 X87.935 Y94.935 E2.70605
G1 X87.4 Y94.935 E.01646
G1 X149.529 Y157.065 E2.70605
G1 X148.995 Y157.065 E.01646
G1 X86.866 Y94.935 E2.70605
G1 X86.331 Y94.935 E.01646
G1 X148.46 Y157.065 E2.70605
G1 X147.926 Y157.065 E.01646
G1 X85.797 Y94.935 E2.70605
G1 X85.262 Y94.935 E.01646
G1 X147.391 Y157.065 E2.70605
G1 X146.857 Y157.065 E.01646
G1 X84.771 Y94.979 E2.70416
G2 X84.34 Y95.082 I.141 J1.544 E.01371
G1 X146.322 Y157.065 E2.69967
G1 X145.788 Y157.065 E.01646
G1 X83.959 Y95.236 E2.69296
G2 X83.617 Y95.428 I.629 J1.52 E.01212
G1 X145.253 Y157.065 E2.68458
G1 X144.719 Y157.065 E.01646
G1 X83.302 Y95.648 E2.67502
G1 X82.99 Y95.871 E.0118
G1 X144.184 Y157.065 E2.66532
G1 X143.65 Y157.065 E.01646
G1 X82.679 Y96.093 E2.65562
G1 X82.367 Y96.316 E.0118
G1 X143.115 Y157.065 E2.64592
G1 X142.581 Y157.065 E.01646
G1 X82.055 Y96.539 E2.63622
G1 X81.743 Y96.761 E.0118
G1 X142.046 Y157.065 E2.62652
G1 X141.512 Y157.065 E.01646
G1 X81.431 Y96.984 E2.61682
G1 X81.12 Y97.207 E.0118
G1 X140.977 Y157.065 E2.60712
G1 X140.443 Y157.065 E.01646
G1 X80.808 Y97.43 E2.59742
G1 X80.496 Y97.652 E.0118
G1 X139.908 Y157.065 E2.58772
G1 X139.374 Y157.065 E.01646
G1 X80.184 Y97.875 E2.57801
G1 X79.872 Y98.098 E.0118
G1 X138.839 Y157.065 E2.56831
G1 X138.305 Y157.065 E.01646
G1 X79.561 Y98.32 E2.55861
G1 X79.249 Y98.543 E.0118
G1 X137.77 Y157.065 E2.54891
G1 X137.236 Y157.065 E.01646
G1 X78.937 Y98.766 E2.53921
G1 X78.625 Y98.989 E.0118
G1 X136.701 Y157.065 E2.52951
G1 X136.167 Y157.065 E.01646
G1 X78.314 Y99.212 E2.51978
G1 X78.022 Y99.455 E.01169
G1 X135.632 Y157.065 E2.50922
G1 X135.098 Y157.065 E.01646
G1 X77.765 Y99.732 E2.49713
G2 X77.54 Y100.041 I2.383 J1.977 E.01179
G1 X134.563 Y157.065 E2.48367
G1 X134.029 Y157.065 E.01646
G1 X77.352 Y100.388 E2.46857
G1 X77.174 Y100.744 E.01227
G1 X133.494 Y157.065 E2.45305
G1 X132.96 Y157.065 E.01646
M73 P86 R4
G1 X76.996 Y101.1 E2.43753
G1 X76.817 Y101.457 E.01227
G1 X132.425 Y157.065 E2.42201
G1 X131.891 Y157.065 E.01646
G1 X76.639 Y101.813 E2.40649
G1 X76.461 Y102.169 E.01227
G1 X131.356 Y157.065 E2.39097
G1 X130.822 Y157.065 E.01646
G1 X76.283 Y102.526 E2.37545
G1 X76.105 Y102.882 E.01227
G1 X130.287 Y157.065 E2.35993
G1 X129.753 Y157.065 E.01646
G1 X75.927 Y103.238 E2.34441
G1 X75.748 Y103.595 E.01227
G1 X129.218 Y157.065 E2.32889
G1 X128.684 Y157.065 E.01646
G1 X75.57 Y103.951 E2.31337
G1 X75.392 Y104.307 E.01227
G1 X128.149 Y157.065 E2.29785
G1 X127.615 Y157.065 E.01646
G1 X75.214 Y104.664 E2.28233
G1 X75.036 Y105.02 E.01227
G1 X127.08 Y157.065 E2.26681
G1 X126.546 Y157.065 E.01646
G1 X74.858 Y105.376 E2.25129
G1 X74.679 Y105.733 E.01227
G1 X126.011 Y157.065 E2.23577
G1 X125.477 Y157.065 E.01646
G1 X74.501 Y106.089 E2.22025
G2 X74.323 Y106.446 I3.827 J2.13 E.01228
G1 X124.942 Y157.065 E2.20471
G1 X124.408 Y157.065 E.01646
G1 X74.169 Y106.826 E2.18815
G2 X74.062 Y107.253 I2.954 J.97 E.01357
G1 X123.873 Y157.065 E2.16955
G1 X123.339 Y157.065 E.01646
G1 X74.021 Y107.747 E2.14805
G2 X74.062 Y108.323 I6.286 J-.163 E.01779
G1 X122.804 Y157.065 E2.12296
G1 X122.27 Y157.065 E.01646
G1 X74.117 Y108.912 E2.09729
G1 X74.172 Y109.501 E.01823
G1 X121.735 Y157.065 E2.07162
G1 X121.201 Y157.065 E.01646
G1 X74.227 Y110.091 E2.04596
G1 X74.282 Y110.68 E.01823
G1 X120.666 Y157.065 E2.02029
G1 X120.132 Y157.065 E.01646
G1 X74.337 Y111.269 E1.99462
G1 X74.391 Y111.859 E.01823
G1 X119.597 Y157.065 E1.96895
G1 X119.063 Y157.065 E.01646
G1 X74.446 Y112.448 E1.94328
G1 X74.501 Y113.037 E.01823
G1 X118.528 Y157.065 E1.91762
G1 X117.994 Y157.065 E.01646
G1 X74.556 Y113.627 E1.89195
G1 X74.611 Y114.216 E.01823
G1 X117.459 Y157.065 E1.86628
G1 X116.925 Y157.065 E.01646
G1 X74.665 Y114.805 E1.84061
G1 X74.72 Y115.395 E.01823
G1 X116.39 Y157.065 E1.81494
G1 X115.856 Y157.065 E.01646
G1 X74.775 Y115.984 E1.78928
G1 X74.83 Y116.573 E.01823
G1 X115.321 Y157.065 E1.76361
G1 X114.787 Y157.065 E.01646
G1 X74.885 Y117.163 E1.73794
G1 X74.94 Y117.752 E.01823
G1 X114.252 Y157.065 E1.71227
G1 X113.718 Y157.065 E.01646
G1 X74.994 Y118.341 E1.6866
G1 X75.049 Y118.931 E.01823
G1 X113.183 Y157.065 E1.66094
G1 X112.649 Y157.065 E.01646
G1 X75.104 Y119.52 E1.63527
G1 X75.159 Y120.109 E.01823
G1 X112.114 Y157.065 E1.6096
G1 X111.58 Y157.065 E.01646
G1 X75.214 Y120.699 E1.58393
G1 X75.268 Y121.288 E.01823
G1 X111.045 Y157.065 E1.55826
G1 X110.511 Y157.065 E.01646
G1 X75.323 Y121.877 E1.53259
G1 X75.378 Y122.467 E.01823
G1 X109.976 Y157.065 E1.50693
G1 X109.442 Y157.065 E.01646
G1 X75.433 Y123.056 E1.48126
G1 X75.488 Y123.645 E.01823
G1 X108.907 Y157.065 E1.45559
G1 X108.373 Y157.065 E.01646
G1 X75.543 Y124.235 E1.42992
G1 X75.597 Y124.824 E.01823
G1 X107.838 Y157.065 E1.40425
G1 X107.304 Y157.065 E.01646
G1 X75.652 Y125.413 E1.37859
G1 X75.707 Y126.002 E.01823
M73 P87 R4
G1 X106.769 Y157.065 E1.35292
G1 X106.235 Y157.065 E.01646
G1 X75.762 Y126.592 E1.32725
G1 X75.817 Y127.181 E.01823
G1 X105.7 Y157.065 E1.30158
G1 X105.166 Y157.065 E.01646
G1 X75.872 Y127.77 E1.27591
G1 X75.926 Y128.36 E.01823
M73 P87 R3
G1 X104.631 Y157.065 E1.25025
G1 X104.097 Y157.065 E.01646
G1 X75.981 Y128.949 E1.22458
G1 X76.036 Y129.538 E.01823
G1 X103.562 Y157.065 E1.19891
G1 X103.028 Y157.065 E.01646
G1 X76.091 Y130.128 E1.17324
G1 X76.146 Y130.717 E.01823
G1 X102.493 Y157.065 E1.14757
G1 X101.959 Y157.065 E.01646
G1 X76.2 Y131.306 E1.12191
G1 X76.255 Y131.896 E.01823
G1 X101.424 Y157.065 E1.09624
G1 X100.89 Y157.065 E.01646
G1 X76.31 Y132.485 E1.07057
G1 X76.365 Y133.074 E.01823
G1 X100.355 Y157.065 E1.0449
G1 X99.821 Y157.065 E.01646
G1 X76.42 Y133.664 E1.01923
G1 X76.475 Y134.253 E.01823
G1 X99.286 Y157.065 E.99357
G1 X98.752 Y157.065 E.01646
G1 X76.529 Y134.842 E.9679
G1 X76.584 Y135.432 E.01823
G1 X98.217 Y157.065 E.94223
G1 X97.683 Y157.065 E.01646
G1 X76.639 Y136.021 E.91656
G1 X76.694 Y136.61 E.01823
G1 X97.148 Y157.065 E.89089
G1 X96.614 Y157.065 E.01646
G1 X76.749 Y137.2 E.86523
G1 X76.803 Y137.789 E.01823
G1 X96.079 Y157.065 E.83956
G1 X95.545 Y157.065 E.01646
G1 X76.858 Y138.378 E.81389
G1 X76.913 Y138.968 E.01823
G1 X95.01 Y157.065 E.78822
G1 X94.476 Y157.065 E.01646
G1 X76.968 Y139.557 E.76255
G1 X77.023 Y140.146 E.01823
G1 X93.941 Y157.065 E.73689
G1 X93.407 Y157.065 E.01646
G1 X77.078 Y140.736 E.71122
G1 X77.132 Y141.325 E.01823
G1 X92.872 Y157.065 E.68555
G1 X92.338 Y157.065 E.01646
G1 X77.187 Y141.914 E.65988
G1 X77.242 Y142.504 E.01823
G1 X91.803 Y157.065 E.63421
G1 X91.269 Y157.065 E.01646
G1 X77.297 Y143.093 E.60855
G1 X77.352 Y143.682 E.01823
G1 X90.734 Y157.065 E.58288
G1 X90.2 Y157.065 E.01646
G1 X77.406 Y144.272 E.55721
G1 X77.461 Y144.861 E.01823
G1 X89.665 Y157.065 E.53154
G1 X89.131 Y157.065 E.01646
G1 X77.516 Y145.45 E.50587
G1 X77.571 Y146.039 E.01823
G1 X88.596 Y157.065 E.48021
G1 X88.062 Y157.065 E.01646
G1 X77.626 Y146.629 E.45454
G1 X77.681 Y147.218 E.01823
G1 X87.527 Y157.065 E.42887
G1 X86.993 Y157.065 E.01646
G1 X77.735 Y147.807 E.4032
G1 X77.79 Y148.397 E.01823
G1 X86.451 Y157.058 E.37724
G3 X85.819 Y156.961 I.312 J-4.123 E.01971
G1 X77.905 Y149.046 E.34472
G2 X78.625 Y150.301 I2.716 J-.725 E.04507
G1 X85.248 Y156.923 E.28843
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X83.833 Y155.509 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 22/23
; update layer progress
M73 L22
M991 S0 P21 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.6 I.079 J1.214 P1  F30000
G1 X178.355 Y149.348 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X177.599 Y150.549 I-3.075 J-1.095 E.04744
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.692 Y156.456 E.27712
G3 X169.418 Y157.398 I-2.287 J-2.306 E.08374
G1 X86.582 Y157.398 E2.74783
G3 X84.308 Y156.456 I.011 J-3.244 E.08376
G1 X78.401 Y150.549 E.27711
G3 X77.472 Y148.571 I2.319 J-2.296 E.0739
G1 X73.701 Y108.032 E1.35057
G3 X74.027 Y106.292 I3.277 J-.286 E.05944
G1 X77.113 Y100.12 E.22894
G3 X78.125 Y98.936 I2.968 J1.513 E.05212
G1 X83.353 Y95.202 E.21313
G3 X85.225 Y94.602 I1.874 J2.629 E.06626
G1 X170.918 Y94.605 E2.84257
G3 X172.647 Y95.202 I-.163 J3.277 E.06149
G1 X177.876 Y98.937 E.21317
G3 X178.887 Y100.12 I-1.958 J2.696 E.05209
G1 X181.973 Y106.293 E.22894
G3 X182.299 Y108.032 I-2.951 J1.453 E.05942
G1 X178.528 Y148.572 E1.35058
G3 X178.374 Y149.291 I-3.248 J-.319 E.02447
M204 S250
G1 X178.728 Y149.478 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.724 Y149.479 E.00014
G3 X177.88 Y150.823 I-3.45 J-1.229 E.04915
G1 X171.966 Y156.737 E.257
G3 X169.423 Y157.79 I-2.562 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.018 J-3.641 E.08674
G1 X78.12 Y150.823 E.25699
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.674 Y106.121 I3.677 J-.316 E.06148
G1 X76.765 Y99.94 E.21234
G3 X77.893 Y98.621 I3.327 J1.702 E.05383
G1 X83.129 Y94.88 E.19774
G3 X85.221 Y94.21 I2.098 J2.95 E.06857
G1 X170.935 Y94.214 E2.63377
G3 X172.871 Y94.88 I-.184 J3.678 E.06374
G1 X178.108 Y98.621 E.19775
G3 X179.235 Y99.94 I-2.2 J3.022 E.05383
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.313 J1.627 E.06147
G1 X178.918 Y148.613 E1.25133
G3 X178.827 Y149.139 I-3.644 J-.362 E.01644
G1 X178.745 Y149.42 E.00898
; WIPE_START
M204 S10000
G1 X178.724 Y149.479 E-.02377
G1 X178.593 Y149.809 E-.13492
G1 X178.426 Y150.122 E-.135
G1 X178.24 Y150.402 E-.12771
G1 X177.88 Y150.823 E-.21031
G1 X177.641 Y151.062 E-.12829
; WIPE_END
G1 E-.04 F1800
G1 X171.828 Y156.007 Z4.8 F30000
G1 X170.762 Y156.915 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42089
G1 F15000
G1 X177.466 Y150.206 E.29213
M73 P88 R3
G2 X178.103 Y149.039 I-2.123 J-1.917 E.04131
G1 X170.185 Y156.957 E.34488
G1 X170.122 Y156.978 E.00206
G3 X169.55 Y157.058 I-.609 J-2.266 E.01784
G1 X178.21 Y148.398 E.37721
G1 X178.265 Y147.808 E.01823
G1 X169.008 Y157.065 E.40318
G1 X168.474 Y157.065 E.01646
G1 X178.319 Y147.219 E.42885
G1 X178.374 Y146.63 E.01823
G1 X167.939 Y157.065 E.45452
G1 X167.405 Y157.065 E.01646
G1 X178.429 Y146.04 E.48019
G1 X178.484 Y145.451 E.01823
G1 X166.87 Y157.065 E.50586
G1 X166.336 Y157.065 E.01646
G1 X178.539 Y144.862 E.53153
G1 X178.593 Y144.272 E.01823
G1 X165.801 Y157.065 E.5572
G1 X165.267 Y157.065 E.01646
G1 X178.648 Y143.683 E.58287
G1 X178.703 Y143.094 E.01823
G1 X164.732 Y157.065 E.60855
G1 X164.197 Y157.065 E.01646
G1 X178.758 Y142.504 E.63422
G1 X178.813 Y141.915 E.01823
G1 X163.663 Y157.065 E.65989
G1 X163.128 Y157.065 E.01646
G1 X178.868 Y141.326 E.68556
G1 X178.922 Y140.736 E.01823
G1 X162.594 Y157.065 E.71123
G1 X162.059 Y157.065 E.01646
G1 X178.977 Y140.147 E.7369
G1 X179.032 Y139.557 E.01823
G1 X161.525 Y157.065 E.76257
G1 X160.99 Y157.065 E.01646
G1 X179.087 Y138.968 E.78824
G1 X179.142 Y138.379 E.01823
G1 X160.456 Y157.065 E.81391
G1 X159.921 Y157.065 E.01646
G1 X179.197 Y137.789 E.83958
G1 X179.251 Y137.2 E.01823
G1 X159.387 Y157.065 E.86525
G1 X158.852 Y157.065 E.01646
G1 X179.306 Y136.611 E.89092
G1 X179.361 Y136.021 E.01823
G1 X158.318 Y157.065 E.91659
G1 X157.783 Y157.065 E.01646
G1 X179.416 Y135.432 E.94226
G1 X179.471 Y134.843 E.01823
G1 X157.249 Y157.065 E.96794
G1 X156.714 Y157.065 E.01646
G1 X179.525 Y134.253 E.99361
G1 X179.58 Y133.664 E.01823
G1 X156.18 Y157.065 E1.01928
G1 X155.645 Y157.065 E.01646
G1 X179.635 Y133.075 E1.04495
G1 X179.69 Y132.485 E.01823
G1 X155.11 Y157.065 E1.07062
G1 X154.576 Y157.065 E.01646
G1 X179.745 Y131.896 E1.09629
G1 X179.8 Y131.307 E.01823
G1 X154.041 Y157.065 E1.12196
G1 X153.507 Y157.065 E.01646
G1 X179.854 Y130.717 E1.14763
G1 X179.909 Y130.128 E.01823
G1 X152.972 Y157.065 E1.1733
G1 X152.438 Y157.065 E.01646
G1 X179.964 Y129.538 E1.19897
G1 X180.019 Y128.949 E.01823
G1 X151.903 Y157.065 E1.22464
G1 X151.369 Y157.065 E.01646
G1 X180.074 Y128.36 E1.25031
G1 X180.129 Y127.77 E.01823
G1 X150.834 Y157.065 E1.27598
G1 X150.3 Y157.065 E.01646
G1 X180.183 Y127.181 E1.30166
G1 X180.238 Y126.592 E.01823
G1 X149.765 Y157.065 E1.32733
G1 X149.231 Y157.065 E.01646
G1 X180.293 Y126.002 E1.353
G1 X180.348 Y125.413 E.01823
G1 X148.696 Y157.065 E1.37867
G1 X148.162 Y157.065 E.01646
G1 X180.403 Y124.824 E1.40434
G1 X180.457 Y124.234 E.01823
G1 X147.627 Y157.065 E1.43001
G1 X147.093 Y157.065 E.01646
G1 X180.512 Y123.645 E1.45568
G1 X180.567 Y123.056 E.01823
G1 X146.558 Y157.065 E1.48135
G1 X146.023 Y157.065 E.01646
G1 X180.622 Y122.466 E1.50702
G1 X180.677 Y121.877 E.01823
G1 X145.489 Y157.065 E1.53269
G1 X144.954 Y157.065 E.01646
G1 X180.732 Y121.288 E1.55836
G1 X180.786 Y120.698 E.01823
G1 X144.42 Y157.065 E1.58403
G1 X143.885 Y157.065 E.01646
G1 X180.841 Y120.109 E1.6097
G1 X180.896 Y119.519 E.01823
G1 X143.351 Y157.065 E1.63537
G1 X142.816 Y157.065 E.01646
G1 X180.951 Y118.93 E1.66105
G1 X181.006 Y118.341 E.01823
G1 X142.282 Y157.065 E1.68672
G1 X141.747 Y157.065 E.01646
G1 X181.061 Y117.751 E1.71239
G1 X181.115 Y117.162 E.01823
G1 X141.213 Y157.065 E1.73806
G1 X140.678 Y157.065 E.01646
G1 X181.17 Y116.573 E1.76373
G1 X181.225 Y115.983 E.01823
G1 X140.144 Y157.065 E1.7894
G1 X139.609 Y157.065 E.01646
G1 X181.28 Y115.394 E1.81507
G1 X181.335 Y114.805 E.01823
G1 X139.075 Y157.065 E1.84074
G1 X138.54 Y157.065 E.01646
G1 X181.389 Y114.215 E1.86641
G1 X181.444 Y113.626 E.01823
G1 X138.005 Y157.065 E1.89208
G1 X137.471 Y157.065 E.01646
G1 X181.499 Y113.037 E1.91775
G1 X181.554 Y112.447 E.01823
G1 X136.936 Y157.065 E1.94342
G1 X136.402 Y157.065 E.01646
G1 X181.609 Y111.858 E1.96909
G1 X181.664 Y111.268 E.01823
G1 X135.867 Y157.065 E1.99477
G1 X135.333 Y157.065 E.01646
G1 X181.718 Y110.679 E2.02044
G1 X181.773 Y110.09 E.01823
G1 X134.798 Y157.065 E2.04611
G1 X134.264 Y157.065 E.01646
G1 X181.828 Y109.5 E2.07178
G1 X181.883 Y108.911 E.01823
G1 X133.729 Y157.065 E2.09745
G1 X133.195 Y157.065 E.01646
G1 X181.938 Y108.322 E2.12312
G2 X181.979 Y107.746 I-6.255 J-.74 E.01779
G1 X132.66 Y157.065 E2.14821
G1 X132.126 Y157.065 E.01646
G1 X181.933 Y107.257 E2.1695
G2 X181.833 Y106.823 I-1.913 J.216 E.01375
G1 X131.591 Y157.065 E2.18839
G1 X131.057 Y157.065 E.01646
G1 X181.674 Y106.447 E2.20477
G1 X181.496 Y106.091 E.01227
G1 X130.522 Y157.065 E2.22029
G1 X129.988 Y157.065 E.01646
G1 X181.318 Y105.734 E2.23582
G1 X181.14 Y105.378 E.01227
G1 X129.453 Y157.065 E2.25135
G1 X128.918 Y157.065 E.01646
G1 X180.962 Y105.021 E2.26688
G1 X180.784 Y104.665 E.01227
G1 X128.384 Y157.065 E2.28241
G1 X127.849 Y157.065 E.01646
G1 X180.606 Y104.308 E2.29794
G1 X180.428 Y103.952 E.01227
G1 X127.315 Y157.065 E2.31346
G1 X126.78 Y157.065 E.01646
G1 X180.25 Y103.595 E2.32899
G1 X180.072 Y103.239 E.01227
G1 X126.246 Y157.065 E2.34452
G1 X125.711 Y157.065 E.01646
G1 X179.894 Y102.882 E2.36005
G1 X179.716 Y102.526 E.01227
G1 X125.177 Y157.065 E2.37558
G1 X124.642 Y157.065 E.01646
G1 X179.538 Y102.169 E2.39111
G1 X179.36 Y101.813 E.01227
G1 X124.108 Y157.065 E2.40663
G1 X123.573 Y157.065 E.01646
G1 X179.182 Y101.456 E2.42216
G1 X179.004 Y101.1 E.01227
G1 X123.039 Y157.065 E2.43769
G1 X122.504 Y157.065 E.01646
G1 X178.826 Y100.743 E2.45322
G1 X178.648 Y100.387 E.01227
G1 X121.97 Y157.065 E2.46875
G1 X121.435 Y157.065 E.01646
G1 X178.459 Y100.041 E2.48381
G2 X178.235 Y99.73 I-1.397 J.772 E.01182
G1 X120.901 Y157.065 E2.49734
G1 X120.366 Y157.065 E.01646
G1 X177.977 Y99.454 E2.50938
G1 X177.685 Y99.211 E.01169
G1 X119.831 Y157.065 E2.51994
G1 X119.297 Y157.065 E.01646
G1 X177.374 Y98.988 E2.52967
G1 X177.062 Y98.765 E.0118
G1 X118.762 Y157.065 E2.53937
G1 X118.228 Y157.065 E.01646
G1 X176.75 Y98.543 E2.54906
G1 X176.438 Y98.32 E.0118
G1 X117.693 Y157.065 E2.55876
G1 X117.159 Y157.065 E.01646
G1 X176.126 Y98.098 E2.56845
G1 X175.814 Y97.875 E.0118
G1 X116.624 Y157.065 E2.57814
G1 X116.09 Y157.065 E.01646
G1 X175.502 Y97.653 E2.58784
G1 X175.19 Y97.43 E.0118
G1 X115.555 Y157.065 E2.59753
G1 X115.021 Y157.065 E.01646
G1 X174.878 Y97.207 E2.60723
G1 X174.566 Y96.985 E.0118
G1 X114.486 Y157.065 E2.61692
G1 X113.952 Y157.065 E.01646
G1 X174.254 Y96.762 E2.62662
G1 X173.942 Y96.54 E.0118
G1 X113.417 Y157.065 E2.63631
G1 X112.883 Y157.065 E.01646
G1 X173.63 Y96.317 E2.646
G1 X173.318 Y96.095 E.0118
G1 X112.348 Y157.065 E2.6557
G1 X111.814 Y157.065 E.01646
G1 X173.006 Y95.872 E2.66539
G1 X172.694 Y95.65 E.0118
G1 X111.279 Y157.065 E2.67509
G1 X110.744 Y157.065 E.01646
G1 X172.382 Y95.427 E2.68478
G2 X172.042 Y95.233 I-.985 J1.334 E.0121
G1 X110.21 Y157.065 E2.69323
G1 X109.675 Y157.065 E.01646
G1 X171.661 Y95.079 E2.69993
G2 X171.231 Y94.974 I-.579 J1.442 E.01367
G1 X109.141 Y157.065 E2.70449
G1 X108.606 Y157.065 E.01646
G1 X170.732 Y94.939 E2.70605
G1 X170.198 Y94.939 E.01646
G1 X108.072 Y157.065 E2.70605
G1 X107.537 Y157.065 E.01646
G1 X169.663 Y94.939 E2.70605
G1 X169.129 Y94.939 E.01646
M73 P89 R3
G1 X107.003 Y157.065 E2.70605
G1 X106.468 Y157.065 E.01646
G1 X168.594 Y94.939 E2.70605
G1 X168.06 Y94.939 E.01646
G1 X105.934 Y157.065 E2.70605
G1 X105.399 Y157.065 E.01646
G1 X167.525 Y94.939 E2.70605
G1 X166.991 Y94.939 E.01646
G1 X104.865 Y157.065 E2.70605
G1 X104.33 Y157.065 E.01646
G1 X166.456 Y94.939 E2.70606
G1 X165.922 Y94.939 E.01646
G1 X103.796 Y157.065 E2.70606
G1 X103.261 Y157.065 E.01646
G1 X165.387 Y94.939 E2.70606
G1 X164.853 Y94.939 E.01646
G1 X102.726 Y157.065 E2.70606
G1 X102.192 Y157.065 E.01646
G1 X164.318 Y94.938 E2.70606
G1 X163.784 Y94.938 E.01646
G1 X101.657 Y157.065 E2.70606
G1 X101.123 Y157.065 E.01646
G1 X163.249 Y94.938 E2.70606
G1 X162.715 Y94.938 E.01646
G1 X100.588 Y157.065 E2.70606
G1 X100.054 Y157.065 E.01646
G1 X162.18 Y94.938 E2.70606
G1 X161.646 Y94.938 E.01646
G1 X99.519 Y157.065 E2.70606
G1 X98.985 Y157.065 E.01646
G1 X161.111 Y94.938 E2.70607
G1 X160.577 Y94.938 E.01646
G1 X98.45 Y157.065 E2.70607
G1 X97.916 Y157.065 E.01646
G1 X160.042 Y94.938 E2.70607
G1 X159.508 Y94.938 E.01646
G1 X97.381 Y157.065 E2.70607
G1 X96.847 Y157.065 E.01646
G1 X158.973 Y94.938 E2.70607
G1 X158.439 Y94.938 E.01646
G1 X96.312 Y157.065 E2.70607
G1 X95.778 Y157.065 E.01646
G1 X157.904 Y94.938 E2.70607
G1 X157.37 Y94.938 E.01646
G1 X95.243 Y157.065 E2.70607
G1 X94.709 Y157.065 E.01646
G1 X156.835 Y94.938 E2.70607
G1 X156.301 Y94.938 E.01646
G1 X94.174 Y157.065 E2.70607
G1 X93.639 Y157.065 E.01646
G1 X155.766 Y94.938 E2.70607
G1 X155.232 Y94.938 E.01646
G1 X93.105 Y157.065 E2.70608
G1 X92.57 Y157.065 E.01646
G1 X154.697 Y94.938 E2.70608
G1 X154.162 Y94.938 E.01646
G1 X92.036 Y157.065 E2.70608
G1 X91.501 Y157.065 E.01646
G1 X153.628 Y94.938 E2.70608
G1 X153.093 Y94.938 E.01646
G1 X90.967 Y157.065 E2.70608
G1 X90.432 Y157.065 E.01646
G1 X152.559 Y94.938 E2.70608
G1 X152.024 Y94.938 E.01646
G1 X89.898 Y157.065 E2.70608
G1 X89.363 Y157.065 E.01646
G1 X151.49 Y94.938 E2.70608
G1 X150.955 Y94.938 E.01646
G1 X88.829 Y157.065 E2.70608
G1 X88.294 Y157.065 E.01646
G1 X150.421 Y94.938 E2.70608
G1 X149.886 Y94.938 E.01646
G1 X87.76 Y157.065 E2.70608
G1 X87.225 Y157.065 E.01646
G1 X149.352 Y94.938 E2.70609
G1 X148.817 Y94.938 E.01646
G1 X86.691 Y157.065 E2.70609
G3 X86.189 Y157.032 I-.024 J-3.467 E.01549
G1 X148.283 Y94.938 E2.70465
G1 X147.748 Y94.938 E.01646
G1 X85.748 Y156.939 E2.7006
G3 X85.359 Y156.792 I1.022 J-3.299 E.01278
G1 X147.214 Y94.938 E2.69422
G1 X146.679 Y94.938 E.01646
G1 X85.017 Y156.6 E2.68585
G3 X84.713 Y156.37 I.605 J-1.117 E.0118
G1 X146.145 Y94.938 E2.67583
G1 X145.61 Y94.938 E.01646
G1 X84.438 Y156.11 E2.6645
G1 X84.171 Y155.843 E.01164
G1 X145.076 Y94.938 E2.65287
G1 X144.541 Y94.938 E.01646
G1 X83.903 Y155.576 E2.64123
G1 X83.636 Y155.308 E.01164
G1 X144.007 Y94.938 E2.6296
G1 X143.472 Y94.938 E.01646
G1 X83.369 Y155.041 E2.61796
G1 X83.101 Y154.774 E.01164
G1 X142.938 Y94.938 E2.60633
G1 X142.403 Y94.938 E.01646
G1 X82.834 Y154.507 E2.59469
G1 X82.566 Y154.24 E.01164
M73 P90 R3
G1 X141.869 Y94.938 E2.58306
G1 X141.334 Y94.938 E.01646
G1 X82.299 Y153.973 E2.57142
G1 X82.032 Y153.706 E.01164
G1 X140.8 Y94.938 E2.55979
G1 X140.265 Y94.938 E.01646
G1 X81.764 Y153.439 E2.54815
G1 X81.497 Y153.171 E.01164
G1 X139.731 Y94.938 E2.53652
G1 X139.196 Y94.937 E.01646
G1 X81.229 Y152.904 E2.52489
G1 X80.962 Y152.637 E.01164
G1 X138.662 Y94.937 E2.51325
G1 X138.127 Y94.937 E.01646
G1 X80.695 Y152.37 E2.50162
G1 X80.427 Y152.103 E.01164
G1 X137.593 Y94.937 E2.48998
G1 X137.058 Y94.937 E.01646
G1 X80.16 Y151.836 E2.47835
G1 X79.893 Y151.569 E.01164
G1 X136.524 Y94.937 E2.46671
G1 X135.989 Y94.937 E.01646
G1 X79.625 Y151.301 E2.45508
G1 X79.358 Y151.034 E.01164
G1 X135.455 Y94.937 E2.44344
G1 X134.92 Y94.937 E.01646
G1 X79.09 Y150.767 E2.43181
G1 X78.823 Y150.5 E.01164
G1 X134.386 Y94.937 E2.42017
G1 X133.851 Y94.937 E.01646
G1 X78.56 Y150.229 E2.40835
G3 X78.324 Y149.93 I1.078 J-1.094 E.01175
M73 P90 R2
G1 X133.317 Y94.937 E2.39534
G1 X132.782 Y94.937 E.01646
G1 X78.121 Y149.598 E2.38088
G3 X77.957 Y149.228 I1.406 J-.848 E.0125
G1 X132.248 Y94.937 E2.36477
G1 X131.713 Y94.937 E.01646
G1 X77.843 Y148.807 E2.34644
G3 X77.784 Y148.332 I4.472 J-.796 E.01477
G1 X131.179 Y94.937 E2.32572
G1 X130.644 Y94.937 E.01646
G1 X77.739 Y147.843 E2.30442
G1 X77.693 Y147.353 E.01513
G1 X130.11 Y94.937 E2.28312
G1 X129.575 Y94.937 E.01646
G1 X77.648 Y146.864 E2.26182
G1 X77.602 Y146.375 E.01513
G1 X129.041 Y94.937 E2.24052
G1 X128.506 Y94.937 E.01646
G1 X77.557 Y145.886 E2.21922
G1 X77.511 Y145.397 E.01513
G1 X127.972 Y94.937 E2.19792
G1 X127.437 Y94.937 E.01646
G1 X77.466 Y144.908 E2.17662
G1 X77.42 Y144.419 E.01513
G1 X126.903 Y94.937 E2.15532
G1 X126.368 Y94.937 E.01646
G1 X77.375 Y143.93 E2.13402
G1 X77.329 Y143.441 E.01513
G1 X125.834 Y94.937 E2.11272
G1 X125.299 Y94.937 E.01646
G1 X77.284 Y142.952 E2.09142
G1 X77.238 Y142.463 E.01513
G1 X124.764 Y94.937 E2.07012
G1 X124.23 Y94.937 E.01646
G1 X77.193 Y141.974 E2.04882
G1 X77.147 Y141.485 E.01513
G1 X123.695 Y94.937 E2.02752
G1 X123.161 Y94.937 E.01646
G1 X77.102 Y140.996 E2.00622
G1 X77.056 Y140.507 E.01513
G1 X122.626 Y94.937 E1.98492
G1 X122.092 Y94.937 E.01646
G1 X77.011 Y140.018 E1.96362
G1 X76.965 Y139.529 E.01513
G1 X121.557 Y94.937 E1.94232
G1 X121.023 Y94.937 E.01646
G1 X76.92 Y139.04 E1.92102
G1 X76.874 Y138.551 E.01513
G1 X120.488 Y94.937 E1.89972
G1 X119.954 Y94.937 E.01646
G1 X76.829 Y138.062 E1.87842
G1 X76.783 Y137.573 E.01513
G1 X119.419 Y94.937 E1.85712
G1 X118.885 Y94.937 E.01646
G1 X76.738 Y137.084 E1.83582
G1 X76.692 Y136.595 E.01513
G1 X118.35 Y94.937 E1.81452
G1 X117.816 Y94.937 E.01646
G1 X76.647 Y136.106 E1.79322
G1 X76.601 Y135.617 E.01513
G1 X117.281 Y94.937 E1.77192
G1 X116.747 Y94.937 E.01646
G1 X76.556 Y135.128 E1.75062
G1 X76.51 Y134.639 E.01513
G1 X116.212 Y94.937 E1.72932
G1 X115.678 Y94.937 E.01646
M73 P91 R2
G1 X76.465 Y134.149 E1.70802
G1 X76.419 Y133.66 E.01513
G1 X115.143 Y94.937 E1.68672
G1 X114.609 Y94.937 E.01646
G1 X76.374 Y133.171 E1.66541
G1 X76.328 Y132.682 E.01513
G1 X114.074 Y94.936 E1.64411
G1 X113.54 Y94.936 E.01646
G1 X76.283 Y132.193 E1.62281
G1 X76.237 Y131.704 E.01513
G1 X113.005 Y94.936 E1.60151
G1 X112.471 Y94.936 E.01646
G1 X76.192 Y131.215 E1.58021
G1 X76.146 Y130.726 E.01513
G1 X111.936 Y94.936 E1.55891
G1 X111.402 Y94.936 E.01646
G1 X76.101 Y130.237 E1.53761
G1 X76.055 Y129.748 E.01513
G1 X110.867 Y94.936 E1.51631
G1 X110.333 Y94.936 E.01646
G1 X76.01 Y129.259 E1.49501
G1 X75.964 Y128.77 E.01513
G1 X109.798 Y94.936 E1.47371
G1 X109.264 Y94.936 E.01646
G1 X75.919 Y128.281 E1.45241
G1 X75.874 Y127.792 E.01513
G1 X108.729 Y94.936 E1.43111
G1 X108.195 Y94.936 E.01646
G1 X75.828 Y127.303 E1.40981
G1 X75.783 Y126.814 E.01513
G1 X107.66 Y94.936 E1.38851
G1 X107.126 Y94.936 E.01646
G1 X75.737 Y126.325 E1.36721
G1 X75.692 Y125.836 E.01513
G1 X106.591 Y94.936 E1.34591
G1 X106.057 Y94.936 E.01646
G1 X75.646 Y125.347 E1.32461
G1 X75.601 Y124.858 E.01513
G1 X105.522 Y94.936 E1.30331
G1 X104.988 Y94.936 E.01646
G1 X75.555 Y124.369 E1.28201
G1 X75.51 Y123.88 E.01513
G1 X104.453 Y94.936 E1.26071
G1 X103.919 Y94.936 E.01646
G1 X75.464 Y123.391 E1.23941
G1 X75.419 Y122.902 E.01513
G1 X103.384 Y94.936 E1.21811
G1 X102.85 Y94.936 E.01646
G1 X75.373 Y122.413 E1.19681
G1 X75.328 Y121.924 E.01513
G1 X102.315 Y94.936 E1.17551
G1 X101.781 Y94.936 E.01646
G1 X75.282 Y121.434 E1.15421
G1 X75.237 Y120.945 E.01513
G1 X101.246 Y94.936 E1.13291
G1 X100.712 Y94.936 E.01646
G1 X75.191 Y120.456 E1.11161
G1 X75.146 Y119.967 E.01513
G1 X100.177 Y94.936 E1.09031
G1 X99.643 Y94.936 E.01646
G1 X75.1 Y119.478 E1.06901
G1 X75.055 Y118.989 E.01513
G1 X99.108 Y94.936 E1.04771
G1 X98.574 Y94.936 E.01646
G1 X75.009 Y118.5 E1.0264
G1 X74.964 Y118.011 E.01513
G1 X98.039 Y94.936 E1.0051
G1 X97.505 Y94.936 E.01646
G1 X74.918 Y117.522 E.9838
G1 X74.873 Y117.033 E.01513
G1 X96.97 Y94.936 E.9625
G1 X96.436 Y94.936 E.01646
G1 X74.827 Y116.544 E.9412
G1 X74.782 Y116.055 E.01513
G1 X95.901 Y94.936 E.9199
G1 X95.366 Y94.936 E.01646
G1 X74.736 Y115.566 E.8986
G1 X74.691 Y115.077 E.01513
G1 X94.832 Y94.936 E.8773
G1 X94.297 Y94.936 E.01646
G1 X74.645 Y114.588 E.856
G1 X74.6 Y114.099 E.01513
G1 X93.763 Y94.936 E.8347
G1 X93.228 Y94.936 E.01646
G1 X74.554 Y113.61 E.8134
G1 X74.509 Y113.121 E.01513
G1 X92.694 Y94.936 E.7921
G1 X92.159 Y94.936 E.01646
G1 X74.463 Y112.632 E.7708
G1 X74.418 Y112.143 E.01513
G1 X91.625 Y94.936 E.7495
G1 X91.09 Y94.936 E.01646
G1 X74.372 Y111.654 E.7282
G1 X74.327 Y111.165 E.01513
G1 X90.556 Y94.936 E.7069
G1 X90.021 Y94.936 E.01646
G1 X74.281 Y110.676 E.6856
G1 X74.236 Y110.187 E.01513
G1 X89.487 Y94.935 E.6643
G1 X88.952 Y94.935 E.01646
G1 X74.19 Y109.698 E.643
G1 X74.145 Y109.209 E.01513
G1 X88.418 Y94.935 E.6217
G1 X87.883 Y94.935 E.01646
G1 X74.099 Y108.719 E.6004
G1 X74.054 Y108.23 E.01513
G1 X87.349 Y94.935 E.5791
G1 X86.814 Y94.935 E.01646
G1 X74.02 Y107.728 E.55726
G3 X74.086 Y107.129 I3.183 J.047 E.0186
G1 X86.28 Y94.935 E.53113
G1 X85.745 Y94.935 E.01646
G1 X74.411 Y106.27 E.4937
G1 X74.945 Y105.201 E.03681
G1 X85.21 Y94.936 E.44709
G2 X84.605 Y95.007 I-.011 J2.546 E.0188
G1 X75.48 Y104.132 E.39747
G1 X76.014 Y103.063 E.03681
G1 X83.707 Y95.37 E.33506
G1 X81.876 Y96.667 E.06909
M73 P92 R2
G1 X76.549 Y101.994 E.23204
G1 X77.083 Y100.925 E.03681
G1 X80.005 Y98.003 E.12726
G1 X78.329 Y99.2 E.06345
G1 X78.003 Y99.47 E.01302
G1 X77.239 Y100.235 E.03331
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X78.003 Y99.47 E-.41094
G1 X78.329 Y99.2 E-.16067
G1 X78.732 Y98.912 E-.18839
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 23/23
; update layer progress
M73 L23
M991 S0 P22 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.8 I-.549 J1.086 P1  F30000
G1 X178.729 Y149.477 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X178.724 Y149.479 E.00017
G3 X177.88 Y150.823 I-3.45 J-1.229 E.04914
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.966 Y156.737 E.25699
G3 X169.423 Y157.79 I-2.563 J-2.591 E.08673
G1 X86.577 Y157.79 E2.54563
G3 X84.034 Y156.737 I.019 J-3.643 E.08673
G1 X78.12 Y150.823 E.257
G3 X77.082 Y148.612 I2.606 J-2.573 E.0765
G1 X73.31 Y108.064 E1.25133
G3 X73.671 Y106.128 I3.675 J-.316 E.06124
G1 X76.765 Y99.94 E.21258
G3 X77.892 Y98.621 I3.328 J1.702 E.05382
G1 X83.129 Y94.88 E.19775
G3 X85.221 Y94.21 I2.096 J2.942 E.06858
G1 X170.946 Y94.214 E2.63409
G3 X172.871 Y94.88 I-.195 J3.679 E.06343
G1 X178.108 Y98.621 E.19775
G3 X179.235 Y99.94 I-2.208 J3.028 E.05381
G1 X182.326 Y106.121 E.21234
G3 X182.69 Y108.064 I-3.313 J1.627 E.06148
G1 X178.918 Y148.612 E1.25133
G3 X178.827 Y149.139 I-3.644 J-.362 E.01645
G1 X178.745 Y149.419 E.00894
; WIPE_START
M204 S10000
G1 X178.724 Y149.479 E-.02428
G1 X178.593 Y149.809 E-.13484
G1 X178.426 Y150.122 E-.13494
G1 X178.229 Y150.418 E-.13495
G1 X177.88 Y150.823 E-.20314
G1 X177.642 Y151.061 E-.12785
; WIPE_END
G1 E-.04 F1800
G1 X177.358 Y143.434 Z5 F30000
G1 X175.631 Y97.109 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X179.543 Y101.021 E.16998
G1 X180.075 Y102.086
G1 X173.771 Y95.782 E.27392
; WIPE_START
M204 S10000
G1 X175.185 Y97.196 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X172.175 Y94.719 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X180.607 Y103.151 E.36638
G1 X181.138 Y104.216
G1 X171.406 Y94.483 E.42292
G1 X170.811 Y94.421
G1 X181.67 Y105.281 E.4719
G1 X182.202 Y106.346
G1 X170.277 Y94.421 E.51818
G1 X169.744 Y94.421
G1 X182.442 Y107.119 E.55177
G1 X182.497 Y107.708
G1 X169.211 Y94.421 E.57736
G1 X168.678 Y94.421
G1 X182.468 Y108.212 E.59927
G1 X182.423 Y108.7
G1 X168.144 Y94.421 E.62047
G1 X167.611 Y94.421
G1 X182.377 Y109.188 E.64167
G1 X182.332 Y109.675
G1 X167.078 Y94.421 E.66287
G1 X166.544 Y94.421
G1 X182.287 Y110.163 E.68407
G1 X182.241 Y110.651
G1 X166.011 Y94.421 E.70527
G1 X165.478 Y94.421
G1 X182.196 Y111.139 E.72647
G1 X182.15 Y111.627
G1 X164.945 Y94.421 E.74768
G1 X164.411 Y94.421
G1 X182.105 Y112.115 E.76888
G1 X182.06 Y112.603
G1 X163.878 Y94.421 E.79008
G1 X163.345 Y94.421
G1 X182.014 Y113.091 E.81128
G1 X181.969 Y113.578
G1 X162.811 Y94.421 E.83248
G1 X162.278 Y94.421
G1 X181.923 Y114.066 E.85368
G1 X181.878 Y114.554
G1 X161.745 Y94.421 E.87489
G1 X161.212 Y94.421
G1 X181.833 Y115.042 E.89609
G1 X181.787 Y115.53
G1 X160.678 Y94.421 E.91729
G1 X160.145 Y94.421
G1 X181.742 Y116.018 E.93849
G1 X181.697 Y116.506
G1 X159.612 Y94.421 E.95969
G1 X159.078 Y94.421
G1 X181.651 Y116.994 E.98089
G1 X181.606 Y117.481
G1 X158.545 Y94.421 E1.0021
G1 X158.012 Y94.421
G1 X181.56 Y117.969 E1.0233
G1 X181.515 Y118.457
G1 X157.479 Y94.421 E1.0445
G1 X156.945 Y94.421
G1 X181.47 Y118.945 E1.0657
G1 X181.424 Y119.433
G1 X156.412 Y94.421 E1.0869
G1 X155.879 Y94.421
G1 X181.379 Y119.921 E1.1081
G1 X181.334 Y120.409
G1 X155.346 Y94.421 E1.1293
G1 X154.812 Y94.421
G1 X181.288 Y120.897 E1.15051
G1 X181.243 Y121.384
G1 X154.279 Y94.421 E1.17171
G1 X153.746 Y94.421
G1 X181.197 Y121.872 E1.19291
G1 X181.152 Y122.36
G1 X153.212 Y94.421 E1.21411
G1 X152.679 Y94.421
G1 X181.107 Y122.848 E1.23531
G1 X181.061 Y123.336
G1 X152.146 Y94.42 E1.25651
G1 X151.613 Y94.42
G1 X181.016 Y123.824 E1.27772
G1 X180.97 Y124.312
G1 X151.079 Y94.42 E1.29892
G1 X150.546 Y94.42
G1 X180.925 Y124.799 E1.32012
G1 X180.88 Y125.287
G1 X150.013 Y94.42 E1.34132
G1 X149.479 Y94.42
G1 X180.834 Y125.775 E1.36252
G1 X180.789 Y126.263
G1 X148.946 Y94.42 E1.38372
G1 X148.413 Y94.42
G1 X180.744 Y126.751 E1.40492
G1 X180.698 Y127.239
G1 X147.88 Y94.42 E1.42613
G1 X147.346 Y94.42
G1 X180.653 Y127.727 E1.44733
G1 X180.607 Y128.215
G1 X146.813 Y94.42 E1.46853
G1 X146.28 Y94.42
G1 X180.562 Y128.702 E1.48973
G1 X180.517 Y129.19
G1 X145.746 Y94.42 E1.51093
G1 X145.213 Y94.42
G1 X180.471 Y129.678 E1.53213
G1 X180.426 Y130.166
G1 X144.68 Y94.42 E1.55334
G1 X144.147 Y94.42
G1 X180.38 Y130.654 E1.57454
G1 X180.335 Y131.142
G1 X143.613 Y94.42 E1.59574
G1 X143.08 Y94.42
G1 X180.29 Y131.63 E1.61694
G1 X180.244 Y132.118
G1 X142.547 Y94.42 E1.63814
G1 X142.013 Y94.42
G1 X180.199 Y132.605 E1.65934
G1 X180.154 Y133.093
G1 X141.48 Y94.42 E1.68055
G1 X140.947 Y94.42
G1 X180.108 Y133.581 E1.70175
G1 X180.063 Y134.069
G1 X140.414 Y94.42 E1.72295
G1 X139.88 Y94.42
G1 X180.017 Y134.557 E1.74415
G1 X179.972 Y135.045
G1 X139.347 Y94.42 E1.76535
G1 X138.814 Y94.42
G1 X179.927 Y135.533 E1.78655
G1 X179.881 Y136.021
G1 X138.28 Y94.42 E1.80775
G1 X137.747 Y94.42
G1 X179.836 Y136.508 E1.82896
G1 X179.79 Y136.996
G1 X137.214 Y94.42 E1.85016
G1 X136.681 Y94.42
G1 X179.745 Y137.484 E1.87136
G1 X179.7 Y137.972
G1 X136.147 Y94.42 E1.89256
G1 X135.614 Y94.42
G1 X179.654 Y138.46 E1.91376
G1 X179.609 Y138.948
G1 X135.081 Y94.42 E1.93496
G1 X134.547 Y94.42
G1 X179.564 Y139.436 E1.95617
G1 X179.518 Y139.924
G1 X134.014 Y94.42 E1.97737
G1 X133.481 Y94.42
G1 X179.473 Y140.411 E1.99857
G1 X179.427 Y140.899
G1 X132.948 Y94.42 E2.01977
G1 X132.414 Y94.42
G1 X179.382 Y141.387 E2.04097
G1 X179.337 Y141.875
G1 X131.881 Y94.42 E2.06217
G1 X131.348 Y94.42
G1 X179.291 Y142.363 E2.08337
G1 X179.246 Y142.851
G1 X130.815 Y94.419 E2.10458
G1 X130.281 Y94.419
G1 X179.2 Y143.339 E2.12578
G1 X179.155 Y143.827
G1 X129.748 Y94.419 E2.14698
G1 X129.215 Y94.419
G1 X179.11 Y144.314 E2.16818
G1 X179.064 Y144.802
M73 P93 R2
G1 X128.681 Y94.419 E2.18938
G1 X128.148 Y94.419
G1 X179.019 Y145.29 E2.21058
G1 X178.974 Y145.778
G1 X127.615 Y94.419 E2.23179
G1 X127.082 Y94.419
G1 X178.928 Y146.266 E2.25299
G1 X178.883 Y146.754
G1 X126.548 Y94.419 E2.27419
G1 X126.015 Y94.419
G1 X178.837 Y147.242 E2.29539
G1 X178.792 Y147.73
G1 X125.482 Y94.419 E2.31659
G1 X124.948 Y94.419
G1 X178.747 Y148.217 E2.33779
G1 X178.694 Y148.698
G1 X124.415 Y94.419 E2.35866
G1 X123.882 Y94.419
G1 X178.609 Y149.146 E2.37817
G1 X178.478 Y149.549
G1 X123.349 Y94.419 E2.39564
G1 X122.815 Y94.419
G1 X178.305 Y149.909 E2.4113
G1 X178.099 Y150.236
G1 X122.282 Y94.419 E2.42551
G1 X121.749 Y94.419
G1 X177.865 Y150.535 E2.43852
G1 X177.6 Y150.804
G1 X121.215 Y94.419 E2.45018
G1 X120.682 Y94.419
G1 X177.334 Y151.07 E2.46178
G1 X177.067 Y151.337
G1 X120.149 Y94.419 E2.47337
G1 X119.616 Y94.419
G1 X176.801 Y151.604 E2.48496
G1 X176.534 Y151.871
G1 X119.082 Y94.419 E2.49656
G1 X118.549 Y94.419
G1 X176.268 Y152.138 E2.50815
G1 X176.001 Y152.404
G1 X118.016 Y94.419 E2.51974
G1 X117.482 Y94.419
G1 X175.735 Y152.671 E2.53134
G1 X175.468 Y152.938
G1 X116.949 Y94.419 E2.54293
G1 X116.416 Y94.419
G1 X175.202 Y153.205 E2.55452
G1 X174.935 Y153.471
G1 X115.883 Y94.419 E2.56612
G1 X115.349 Y94.419
G1 X174.669 Y153.738 E2.57771
G1 X174.402 Y154.005
G1 X114.816 Y94.419 E2.58931
G1 X114.283 Y94.419
G1 X174.136 Y154.272 E2.6009
G1 X173.869 Y154.538
G1 X113.749 Y94.419 E2.61249
G1 X113.216 Y94.419
M73 P93 R1
G1 X173.603 Y154.805 E2.62409
G1 X173.336 Y155.072
G1 X112.683 Y94.419 E2.63568
G1 X112.15 Y94.419
G1 X173.07 Y155.339 E2.64727
G1 X172.803 Y155.605
G1 X111.616 Y94.419 E2.65887
G1 X111.083 Y94.419
G1 X172.537 Y155.872 E2.67046
G1 X172.27 Y156.139
G1 X110.55 Y94.419 E2.68205
G1 X110.017 Y94.419
G1 X172.004 Y156.406 E2.69365
G1 X171.733 Y156.668
G1 X109.483 Y94.419 E2.70505
G1 X108.95 Y94.418
G1 X171.439 Y156.908 E2.71545
G1 X171.121 Y157.123
G1 X108.417 Y94.418 E2.72481
G1 X107.883 Y94.418
G1 X170.766 Y157.301 E2.73257
G1 X170.372 Y157.44
G1 X107.35 Y94.418 E2.73859
G1 X106.817 Y94.418
G1 X169.94 Y157.542 E2.74303
G1 X169.446 Y157.58
G1 X106.284 Y94.418 E2.7447
G1 X105.75 Y94.418
G1 X168.915 Y157.583 E2.74479
G1 X168.381 Y157.583
G1 X105.217 Y94.418 E2.7448
G1 X104.684 Y94.418
G1 X167.848 Y157.583 E2.7448
G1 X167.315 Y157.583
G1 X104.15 Y94.418 E2.7448
G1 X103.617 Y94.418
G1 X166.782 Y157.583 E2.7448
G1 X166.248 Y157.583
G1 X103.084 Y94.418 E2.7448
M73 P94 R1
G1 X102.551 Y94.418
G1 X165.715 Y157.583 E2.7448
G1 X165.182 Y157.583
G1 X102.017 Y94.418 E2.7448
G1 X101.484 Y94.418
G1 X164.649 Y157.583 E2.7448
G1 X164.115 Y157.583
G1 X100.951 Y94.418 E2.7448
G1 X100.417 Y94.418
G1 X163.582 Y157.583 E2.74481
G1 X163.049 Y157.583
G1 X99.884 Y94.418 E2.74481
G1 X99.351 Y94.418
G1 X162.515 Y157.583 E2.74481
G1 X161.982 Y157.583
G1 X98.818 Y94.418 E2.74481
G1 X98.284 Y94.418
G1 X161.449 Y157.583 E2.74481
G1 X160.916 Y157.583
G1 X97.751 Y94.418 E2.74481
G1 X97.218 Y94.418
G1 X160.382 Y157.583 E2.74481
G1 X159.849 Y157.583
G1 X96.684 Y94.418 E2.74481
G1 X96.151 Y94.418
G1 X159.316 Y157.583 E2.74481
G1 X158.783 Y157.583
G1 X95.618 Y94.418 E2.74482
G1 X95.085 Y94.418
G1 X158.249 Y157.583 E2.74482
G1 X157.716 Y157.583
G1 X94.551 Y94.418 E2.74482
G1 X94.018 Y94.418
G1 X157.183 Y157.583 E2.74482
G1 X156.65 Y157.583
G1 X93.485 Y94.418 E2.74482
G1 X92.951 Y94.418
G1 X156.116 Y157.583 E2.74482
G1 X155.583 Y157.583
G1 X92.418 Y94.418 E2.74482
G1 X91.885 Y94.418
G1 X155.05 Y157.583 E2.74482
G1 X154.517 Y157.583
G1 X91.352 Y94.418 E2.74482
G1 X90.818 Y94.418
G1 X153.983 Y157.583 E2.74482
G1 X153.45 Y157.583
G1 X90.285 Y94.418 E2.74483
G1 X89.752 Y94.418
G1 X152.917 Y157.583 E2.74483
G1 X152.384 Y157.583
G1 X89.219 Y94.418 E2.74483
G1 X88.685 Y94.418
G1 X151.85 Y157.583 E2.74483
G1 X151.317 Y157.583
G1 X88.152 Y94.418 E2.74483
G1 X87.619 Y94.417
G1 X150.784 Y157.583 E2.74483
G1 X150.251 Y157.583
G1 X87.085 Y94.417 E2.74483
G1 X86.552 Y94.417
G1 X149.717 Y157.583 E2.74483
G1 X149.184 Y157.583
G1 X86.019 Y94.417 E2.74483
G1 X85.486 Y94.417
G1 X148.651 Y157.583 E2.74484
G1 X148.118 Y157.583
G1 X84.965 Y94.43 E2.7443
G1 X84.501 Y94.5
G1 X147.584 Y157.583 E2.74125
G1 X147.051 Y157.583
M73 P95 R1
G1 X84.088 Y94.62 E2.73604
G1 X83.715 Y94.78
G1 X146.518 Y157.583 E2.72909
G1 X145.984 Y157.583
G1 X83.372 Y94.97 E2.72081
G1 X83.056 Y95.187
G1 X145.451 Y157.583 E2.71138
G1 X144.918 Y157.583
G1 X82.745 Y95.409 E2.70172
G1 X82.434 Y95.632
G1 X144.385 Y157.583 E2.69207
G1 X143.851 Y157.583
G1 X82.123 Y95.854 E2.68241
G1 X81.812 Y96.076
G1 X143.318 Y157.583 E2.67276
G1 X142.785 Y157.583
G1 X81.501 Y96.298 E2.6631
G1 X81.189 Y96.52
G1 X142.252 Y157.583 E2.65345
G1 X141.718 Y157.583
G1 X80.878 Y96.743 E2.64379
G1 X80.567 Y96.965
G1 X141.185 Y157.583 E2.63414
G1 X140.652 Y157.583
G1 X80.256 Y97.187 E2.62448
G1 X79.945 Y97.409
G1 X140.119 Y157.583 E2.61483
G1 X139.585 Y157.583
G1 X79.634 Y97.631 E2.60517
G1 X79.323 Y97.854
G1 X139.052 Y157.583 E2.59552
G1 X138.519 Y157.583
G1 X79.012 Y98.076 E2.58586
G1 X78.701 Y98.298
G1 X137.986 Y157.583 E2.57621
G1 X137.452 Y157.583
G1 X78.39 Y98.52 E2.56655
G1 X78.079 Y98.742
G1 X136.919 Y157.583 E2.5569
G1 X136.386 Y157.583
G1 X77.784 Y98.98 E2.54655
G1 X77.511 Y99.241
G1 X135.853 Y157.583 E2.53522
G1 X135.319 Y157.583
G1 X77.264 Y99.527 E2.52278
G1 X77.053 Y99.85
G1 X134.786 Y157.583 E2.50877
G1 X134.253 Y157.583
G1 X76.868 Y100.198 E2.49366
G1 X76.69 Y100.553
G1 X133.72 Y157.583 E2.47821
G1 X133.186 Y157.583
G1 X76.512 Y100.909 E2.46276
G1 X76.335 Y101.264
G1 X132.653 Y157.583 E2.44731
G1 X132.12 Y157.583
G1 X76.157 Y101.62 E2.43186
G1 X75.979 Y101.975
G1 X131.587 Y157.583 E2.41641
G1 X131.053 Y157.583
G1 X75.801 Y102.331 E2.40096
G1 X75.624 Y102.686
G1 X130.52 Y157.583 E2.38551
G1 X129.987 Y157.583
G1 X75.446 Y103.042 E2.37007
G1 X75.268 Y103.397
G1 X129.454 Y157.583 E2.35462
G1 X128.92 Y157.583
M73 P96 R1
G1 X75.09 Y103.753 E2.33917
G1 X74.913 Y104.108
G1 X128.387 Y157.583 E2.32372
G1 X127.854 Y157.583
G1 X74.735 Y104.464 E2.30827
G1 X74.557 Y104.819
G1 X127.32 Y157.583 E2.29282
G1 X126.787 Y157.583
G1 X74.379 Y105.175 E2.27737
G1 X74.202 Y105.53
G1 X126.254 Y157.583 E2.26192
G1 X125.721 Y157.583
G1 X74.024 Y105.886 E2.24648
G1 X73.847 Y106.242
G1 X125.187 Y157.583 E2.23098
G1 X124.654 Y157.583
G1 X73.692 Y106.621 E2.21455
G1 X73.576 Y107.037
G1 X124.121 Y157.583 E2.19643
G1 X123.588 Y157.583
G1 X73.512 Y107.507 E2.17602
G1 X73.517 Y108.045
G1 X123.054 Y157.583 E2.15266
G1 X122.521 Y157.583
G1 X73.571 Y108.633 E2.12712
G1 X73.626 Y109.22
G1 X121.988 Y157.583 E2.10157
G1 X121.455 Y157.583
G1 X73.68 Y109.808 E2.07602
G1 X73.735 Y110.396
G1 X120.921 Y157.583 E2.05047
G1 X120.388 Y157.583
G1 X73.79 Y110.984 E2.02492
G1 X73.845 Y111.572
G1 X119.855 Y157.583 E1.99937
G1 X119.322 Y157.583
G1 X73.899 Y112.16 E1.97382
G1 X73.954 Y112.748
G1 X118.788 Y157.583 E1.94827
G1 X118.255 Y157.583
G1 X74.009 Y113.336 E1.92272
G1 X74.063 Y113.924
G1 X117.722 Y157.583 E1.89718
G1 X117.189 Y157.583
G1 X74.118 Y114.512 E1.87163
G1 X74.173 Y115.1
G1 X116.655 Y157.583 E1.84608
G1 X116.122 Y157.583
G1 X74.227 Y115.688 E1.82053
G1 X74.282 Y116.276
G1 X115.589 Y157.583 E1.79498
G1 X115.056 Y157.583
M73 P96 R0
G1 X74.337 Y116.864 E1.76943
G1 X74.391 Y117.452
G1 X114.522 Y157.583 E1.74388
G1 X113.989 Y157.583
G1 X74.446 Y118.04 E1.71833
G1 X74.501 Y118.628
G1 X113.456 Y157.583 E1.69278
G1 X112.923 Y157.583
G1 X74.556 Y119.216 E1.66723
G1 X74.61 Y119.804
G1 X112.389 Y157.583 E1.64168
G1 X111.856 Y157.583
G1 X74.665 Y120.392 E1.61613
G1 X74.72 Y120.979
M73 P97 R0
G1 X111.323 Y157.583 E1.59058
G1 X110.79 Y157.583
G1 X74.774 Y121.567 E1.56503
G1 X74.829 Y122.155
G1 X110.256 Y157.583 E1.53949
G1 X109.723 Y157.583
G1 X74.884 Y122.743 E1.51394
G1 X74.938 Y123.331
G1 X109.19 Y157.583 E1.48839
G1 X108.656 Y157.583
G1 X74.993 Y123.919 E1.46284
G1 X75.048 Y124.507
G1 X108.123 Y157.583 E1.43729
G1 X107.59 Y157.583
G1 X75.102 Y125.095 E1.41174
G1 X75.157 Y125.683
G1 X107.057 Y157.583 E1.38619
G1 X106.523 Y157.583
G1 X75.212 Y126.271 E1.36064
G1 X75.267 Y126.859
G1 X105.99 Y157.583 E1.33509
G1 X105.457 Y157.583
G1 X75.321 Y127.447 E1.30954
G1 X75.376 Y128.035
G1 X104.924 Y157.583 E1.28399
G1 X104.39 Y157.583
G1 X75.431 Y128.623 E1.25844
G1 X75.485 Y129.211
G1 X103.857 Y157.583 E1.23289
G1 X103.324 Y157.583
G1 X75.54 Y129.799 E1.20734
G1 X75.595 Y130.387
G1 X102.791 Y157.583 E1.18179
G1 X102.257 Y157.583
G1 X75.649 Y130.975 E1.15625
G1 X75.704 Y131.563
G1 X101.724 Y157.583 E1.1307
G1 X101.191 Y157.583
G1 X75.759 Y132.151 E1.10515
G1 X75.813 Y132.739
G1 X100.658 Y157.583 E1.0796
G1 X100.124 Y157.583
G1 X75.868 Y133.326 E1.05405
G1 X75.923 Y133.914
G1 X99.591 Y157.583 E1.0285
G1 X99.058 Y157.583
G1 X75.978 Y134.502 E1.00295
G1 X76.032 Y135.09
G1 X98.525 Y157.583 E.9774
G1 X97.991 Y157.583
G1 X76.087 Y135.678 E.95185
G1 X76.142 Y136.266
G1 X97.458 Y157.583 E.9263
G1 X96.925 Y157.583
G1 X76.196 Y136.854 E.90075
G1 X76.251 Y137.442
G1 X96.392 Y157.583 E.8752
G1 X95.858 Y157.583
G1 X76.306 Y138.03 E.84965
G1 X76.36 Y138.618
G1 X95.325 Y157.583 E.8241
G1 X94.792 Y157.583
G1 X76.415 Y139.206 E.79856
G1 X76.47 Y139.794
G1 X94.259 Y157.583 E.77301
G1 X93.725 Y157.583
G1 X76.524 Y140.382 E.74746
G1 X76.579 Y140.97
G1 X93.192 Y157.583 E.72191
G1 X92.659 Y157.583
G1 X76.634 Y141.558 E.69636
G1 X76.689 Y142.146
G1 X92.125 Y157.583 E.67081
G1 X91.592 Y157.583
G1 X76.743 Y142.734 E.64526
G1 X76.798 Y143.322
G1 X91.059 Y157.583 E.61971
G1 X90.526 Y157.583
M73 P98 R0
G1 X76.853 Y143.91 E.59416
G1 X76.907 Y144.498
G1 X89.992 Y157.583 E.56861
G1 X89.459 Y157.583
G1 X76.962 Y145.085 E.54306
G1 X77.017 Y145.673
G1 X88.926 Y157.583 E.51751
G1 X88.393 Y157.583
G1 X77.071 Y146.261 E.49196
G1 X77.126 Y146.849
G1 X87.859 Y157.583 E.46641
G1 X87.326 Y157.583
G1 X77.181 Y147.437 E.44086
G1 X77.236 Y148.025
G1 X86.793 Y157.583 E.41532
G1 X86.243 Y157.566
G1 X77.292 Y148.615 E.38897
G1 X77.429 Y149.285
G1 X85.569 Y157.425 E.35374
; WIPE_START
M204 S10000
G1 X84.155 Y156.011 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X84.195 Y148.379 Z5 F30000
G1 X84.478 Y94.501 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.100482
G1 F15000
G1 X84.318 Y94.583 E.00085
; WIPE_START
G1 X84.478 Y94.501 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X92.11 Y94.615 Z5 F30000
G1 X173.711 Y95.842 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.209042
G1 F15000
G1 X173.458 Y95.628 E.00449
; LINE_WIDTH: 0.160693
G1 X173.205 Y95.414 E.00318
; LINE_WIDTH: 0.112345
G1 X172.952 Y95.2 E.00187
; WIPE_START
G1 X173.205 Y95.414 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X175.571 Y97.169 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.209041
G1 F15000
G1 X175.318 Y96.955 E.00449
; LINE_WIDTH: 0.160693
G1 X175.065 Y96.741 E.00318
; LINE_WIDTH: 0.112345
G1 X174.812 Y96.527 E.00187
; WIPE_START
G1 X175.065 Y96.741 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X179.25 Y100.434 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.110843
G1 F15000
G1 X179.163 Y100.313 E.00082
; LINE_WIDTH: 0.156208
G1 X179.076 Y100.192 E.00137
; LINE_WIDTH: 0.201572
G1 X178.989 Y100.071 E.00192
; LINE_WIDTH: 0.246998
G1 X178.887 Y99.938 E.0028
; LINE_WIDTH: 0.29252
G1 X178.785 Y99.804 E.00342
; LINE_WIDTH: 0.33301
G1 X178.632 Y99.625 E.00557
; LINE_WIDTH: 0.377666
G2 X177.902 Y98.895 I-5.482 J4.75 E.02817
; LINE_WIDTH: 0.329363
G1 X177.701 Y98.725 E.00616
; LINE_WIDTH: 0.28568
G1 X177.5 Y98.554 E.00522
; LINE_WIDTH: 0.241997
G1 X177.298 Y98.384 E.00428
; LINE_WIDTH: 0.198314
G1 X177.097 Y98.213 E.00334
; LINE_WIDTH: 0.15463
G1 X176.896 Y98.043 E.0024
; LINE_WIDTH: 0.108784
G1 X176.673 Y97.854 E.00157
; WIPE_START
G1 X176.896 Y98.043 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X180.313 Y102.564 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.109706
G1 F15000
G1 X180.213 Y102.425 E.00093
; LINE_WIDTH: 0.152769
G1 X180.113 Y102.286 E.00153
; LINE_WIDTH: 0.195832
G1 X180.013 Y102.147 E.00213
; WIPE_START
G1 X180.113 Y102.286 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.377 Y104.694 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.109693
G1 F15000
G1 X181.277 Y104.555 E.00093
; LINE_WIDTH: 0.152756
G1 X181.177 Y104.416 E.00153
; LINE_WIDTH: 0.195819
G1 X181.077 Y104.277 E.00213
; WIPE_START
G1 X181.177 Y104.416 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X174.488 Y108.092 Z5 F30000
G1 X85.075 Y157.226 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.106798
G1 F15000
G1 X84.959 Y157.138 E.00076
; LINE_WIDTH: 0.144055
G1 X84.844 Y157.05 E.0012
; LINE_WIDTH: 0.181312
G1 X84.728 Y156.962 E.00164
; LINE_WIDTH: 0.214985
G1 X84.544 Y156.8 E.00344
; LINE_WIDTH: 0.261634
G1 X84.36 Y156.637 E.00437
G1 X78.108 Y150.376 E.1577
; LINE_WIDTH: 0.226482
G1 X77.947 Y150.184 E.00374
; LINE_WIDTH: 0.1832
G1 X77.786 Y149.993 E.00286
; LINE_WIDTH: 0.143219
G1 X77.705 Y149.884 E.00111
; LINE_WIDTH: 0.106514
G1 X77.625 Y149.775 E.0007
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F15000
G1 X77.705 Y149.884 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z5 I1.217 J0 P1  F30000
M106 S0
M106 P2 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20240528 =====================
M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G1 E-0.8 F1800 ; retract
G1 Z5.1 F900 ; lower z a little
G1 X65 Y245 F12000 ; move to safe pos
G1 Y265 F3000

G1 X65 Y245 F12000
G1 Y265 F3000
M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

G1 X100 F12000 ; wipe
; pull back filament to AMS
M620 S255
G1 X20 Y50 F12000
G1 Y-3
T255
G1 X65 F12000
G1 Y265
G1 X100 F12000 ; wipe
M621 S255
M104 S0 ; turn off hotend

M622.1 S1 ; for prev firware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
    M400 ; wait all motion done
    M991 S0 P-1 ;end smooth timelapse at safe pos
    M400 S3 ;wait for last picture to be taken
M623; end of "timelapse_record_flag"

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z104.6 F600
    G1 Z102.6

M400 P100
M17 R ; restore z current

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0
;=====printer finish  sound=========
M17
M400 S1
M1006 S1
M1006 A0 B20 L100 C37 D20 M40 E42 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C46 D10 M80 E46 F10 N80
M1006 A44 B20 L100 C39 D20 M60 E48 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C48 D10 M60 E44 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10  N100
M1006 A49 B20 L100 C44 D20 M100 E41 F20 N100
M1006 A0 B20 L100 C0 D20 M60 E0 F20 N100
M1006 A0 B20 L100 C37 D20 M30 E37 F20 N60
M1006 W

M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power
M960 S5 P0 ; turn off logo lamp
M73 P100 R0
; EXECUTABLE_BLOCK_END

