; HEADER_BLOCK_START
; BambuStudio 02.08.02.60
; model printing time: 25m 22s; total estimated time: 32m 38s
; total layer number: 23
; total filament length [mm] : 6090.03
; total filament volume [cm^3] : 14648.24
; total filament weight [g] : 18.46
; filament_density: 1.26
; filament_diameter: 1.75
; max_z_height: 4.60
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 70
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 1
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 0x0,18x0,18x28,0x28
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = auto_brim
; brim_width = 5
; chamber_temperatures = 0
; change_filament_gcode = ;=X1 20251031=\nM620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nG1 X70 F21000\nG1 Y245\nG1 Y265 F3000\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E-{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{else}\nM620.11 S0\n{endif}\nM400\nG1 X90 F3000\nG1 Y255 F4000\nG1 X100 F5000\nG1 X120 F15000\nG1 X20 Y50 F21000\nG1 Y-3\n{if toolchange_count == 2}\n; get travel path for change filament\nM620.1 X[travel_point_1_x] Y[travel_point_1_y] F21000 P0\nM620.1 X[travel_point_2_x] Y[travel_point_2_y] F21000 P1\nM620.1 X[travel_point_3_x] Y[travel_point_3_y] F21000 P2\n{endif}\nM620.1 E F{flush_volumetric_speeds[previous_extruder]/2.4053*60} T{flush_temperatures[previous_extruder]}\nT[next_extruder]\nM620.1 E F{flush_volumetric_speeds[next_extruder]/2.4053*60} T{flush_temperatures[next_extruder]}\n\n{if next_extruder < 255}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM628 S1\nG92 E0\nG1 E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM400\nM629 S1\n{else}\nM620.11 S0\n{endif}\nG92 E0\n{if flush_length_1 > 1}\nM83\n; FLUSH_START\n; always use highest temperature to flush\nM400\n{if filament_type[next_extruder] == \"PETG\"}\nM109 S260\n{elsif filament_type[next_extruder] == \"PVA\"}\nM109 S210\n{else}\nM109 S{flush_temperatures[next_extruder]}\n{endif}\n{if flush_length_1 > 23.7}\nG1 E23.7 F{flush_volumetric_speeds[previous_extruder]/2.4053*60} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\n{else}\nG1 E{flush_length_1} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_4 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n; FLUSH_START\nM400\nM109 S[new_filament_temp]\nG1 E2 F{flush_volumetric_speeds[next_extruder]/2.4053*60} ;Compensate for filament spillage during waiting temperature\n; FLUSH_END\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM106 P1 S255\nM400 S3\n\nG1 X70 F5000\nG1 X90 F3000\nG1 Y255 F4000\nG1 X105 F5000\nG1 Y265 F5000\nG1 X70 F10000\nG1 X100 F5000\nG1 X70 F10000\nG1 X100 F5000\n\nG1 X70 F10000\nG1 X80 F15000\nG1 X60\nG1 X80\nG1 X60\nG1 X80 ; shake to put down garbage\nG1 X100 F5000\nG1 X165 F15000; wipe and shake\nG1 Y256 ; move Y to aside, prevent collision\nM400\nG1 Z{max_layer_z + 3.0} F3000\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\nM621 S[next_extruder]A\n
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; compatible_printers_condition = 
; complete_print_exhaust_fan_speed = 70
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.008
; counter_coef_3 = -0.041
; counter_limit_max = 0.033
; counter_limit_min = -0.035
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 10000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL X1C"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL X1C
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70
; elefant_foot_compensation = 0.15
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 1
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0
; eng_plate_temp_initial_layer = 0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 33
; extruder_clearance_height_to_lid = 90
; extruder_clearance_height_to_rod = 34
; extruder_clearance_max_radius = 68
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x2
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard,Direct Drive High Flow"
; fan_cooling_layer_time = 100
; fan_direction = left
; fan_max_speed = 100
; fan_min_speed = 100
; farthest_point_timelapse = 1
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 100
; filament_bridge_speed = 25
; filament_change_length = 5
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 0
; filament_cost = 19.99
; filament_density = 1.26
; filament_dev_ams_drying_ams_limitations = 1
; filament_dev_ams_drying_heat_distortion_temperature = 45
; filament_dev_ams_drying_temperature = 45
; filament_dev_ams_drying_time = 12
; filament_dev_chamber_drying_bed_temperature = 70
; filament_dev_chamber_drying_time = 12
; filament_dev_drying_cooling_temperature = 45
; filament_dev_drying_softening_temperature = 50
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = "; filament end gcode \n\n"
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = GFA00
; filament_is_mixed = 0
; filament_is_support = 0
; filament_long_retractions_when_cut = 1
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 21
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 50
; filament_overhang_3_4_speed = 30
; filament_overhang_4_4_speed = 10
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 10
; filament_prime_volume = 30
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 14
; filament_retraction_distances_when_cut = 18
; filament_scarf_gap = 0%
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Bambu PLA Basic @BBL X1C"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\nM142 P1 R35 S40\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = "Bambu Lab"
; filament_volume_map = 0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 0
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 
; hole_coef_1 = 0
; hole_coef_2 = -0.008
; hole_coef_3 = 0.23415
; hole_limit_max = 0.22
; hole_limit_min = 0.088
; hot_plate_temp = 55
; hot_plate_temp_initial_layer = 55
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 13.8
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = ;===== date: 20240528 =====================\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG1 E-0.8 F1800 ; retract\nG1 Z{max_layer_z + 0.5} F900 ; lower z a little\nG1 X65 Y245 F12000 ; move to safe pos\nG1 Y265 F3000\n\nG1 X65 Y245 F12000\nG1 Y265 F3000\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\nG1 X100 F12000 ; wipe\n; pull back filament to AMS\nM620 S255\nG1 X20 Y50 F12000\nG1 Y-3\nT255\nG1 X65 F12000\nG1 Y265\nG1 X100 F12000 ; wipe\nM621 S255\nM104 S0 ; turn off hotend\n\nM622.1 S1 ; for prev firware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n    M400 ; wait all motion done\n    M991 S0 P-1 ;end smooth timelapse at safe pos\n    M400 S3 ;wait for last picture to be taken\nM623; end of \"timelapse_record_flag\"\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 250}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z250 F600\n    G1 Z248\n{endif}\nM400 P100\nM17 R ; restore z current\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n;=====printer finish  sound=========\nM17\nM400 S1\nM1006 S1\nM1006 A0 B20 L100 C37 D20 M40 E42 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C46 D10 M80 E46 F10 N80\nM1006 A44 B20 L100 C39 D20 M60 E48 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C48 D10 M60 E44 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10  N100\nM1006 A49 B20 L100 C44 D20 M100 E41 F20 N100\nM1006 A0 B20 L100 C0 D20 M60 E0 F20 N100\nM1006 A0 B20 L100 C37 D20 M30 E37 F20 N60\nM1006 W\n\nM17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power\nM960 S5 P0 ; turn off logo lamp\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 29
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 20000,20000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 9000,9000
; machine_max_acceleration_x = 20000,20000
; machine_max_acceleration_y = 20000,20000
; machine_max_acceleration_z = 500,500
; machine_max_force_Y = 0
; machine_max_jerk_e = 2.5,2.5
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_printed_mass = 0
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,500
; machine_max_speed_y = 500,500
; machine_max_speed_z = 20,20
; machine_min_extruding_rate = 0
; machine_min_travel_rate = 0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = ;===== machine: X1-0.4 ====================\n;===== date: 20251031 ==================\n;===== start printer sound ================\nM17\nM400 S1\nM1006 S1\nM1006 A0 B10 L100 C37 D10 M60 E37 F10 N60\nM1006 A0 B10 L100 C41 D10 M60 E41 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A46 B10 L100 C43 D10 M70 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A43 B10 L100 C0 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A41 B10 L100 C0 D10 M100 E41 F10 N100\nM1006 A44 B10 L100 C0 D10 M100 E44 F10 N100\nM1006 A49 B10 L100 C0 D10 M100 E49 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A48 B10 L100 C44 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A44 B10 L100 C0 D10 M90 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A46 B10 L100 C43 D10 M60 E39 F10 N100\nM1006 W\n;===== turn on the HB fan =================\nM104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle\n;===== reset machine status =================\nM290 X40 Y40 Z2.6666666\nG91\nM17 Z0.4 ; lower the z-motor current\nG380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed\nG380 S2 Z-25 F300 ;\nG1 Z5 F300;\nG90\nM17 X1.2 Y1.2 Z0.75 ; reset motor current to default\nM960 S5 P1 ; turn on logo lamp\nG90\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 5\nM221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem\nG29.1 Z{+0.0} ; clear z-trim value first\nM204 S10000 ; init ACC set to 10m/s^2\n\n;===== heatbed preheat ====================\nM1002 gcode_claim_action:54\nM140 S[bed_temperature_initial_layer_single] ;set bed temp\nM190 S[bed_temperature_initial_layer_single] ;wait for bed temp\n\n{if scan_first_layer}\n;=========register first layer scan=====\nM977 S1 P60\n{endif}\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\n;===== prepare print temperature and material ==========\nM104 S[nozzle_temperature_initial_layer] ;set extruder temp\nG91\nG0 Z10 F1200\nG90\nG28 X\nM975 S1 ; turn on\nG1 X60 F12000\nG1 Y245\nG1 Y265 F3000\nM620 M\nM620 S[initial_no_support_extruder]A   ; switch material if AMS exist\n    M109 S[nozzle_temperature_initial_layer]\n    G1 X120 F12000\n\n    G1 X20 Y50 F12000\n    G1 Y-3\n    T[initial_no_support_extruder]\n    G1 X54 F12000\n    G1 Y265\n    M400\nM621 S[initial_no_support_extruder]A\nM620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T{flush_temperatures[initial_no_support_extruder]}\n\nM412 S1 ; ===turn on filament runout detection===\n\nM109 S250 ;set nozzle to common flush temp\nM106 P1 S0\nG92 E0\nG1 E50 F200\nM400\nM104 S[nozzle_temperature_initial_layer]\nG92 E0\nG1 E50 F200\nM400\nM106 P1 S255\nG92 E0\nG1 E5 F300\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20} ; drop nozzle temp, make filament shink a bit\nG92 E0\nG1 E-0.5 F300\n\nG1 X70 F9000\nG1 X76 F15000\nG1 X65 F15000\nG1 X76 F15000\nG1 X65 F15000; shake to put down garbage\nG1 X80 F6000\nG1 X95 F15000\nG1 X80 F15000\nG1 X165 F15000; wipe and shake\nM400\nM106 P1 S0\n;===== prepare print temperature and material end =====\n\n\n;===== wipe nozzle ===============================\nM1002 gcode_claim_action : 14\nM975 S1\nM106 S255\nG1 X65 Y230 F18000\nG1 Y264 F6000\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20}\nG1 X100 F18000 ; first wipe mouth\n\nG0 X135 Y253 F20000  ; move to exposed steel surface edge\nG28 Z P0 T300; home z with low precision,permit 300deg temperature\nG29.2 S0 ; turn off ABL\nG0 Z5 F20000\n\nG1 X60 Y265\nG92 E0\nG1 E-0.5 F300 ; retrack more\nG1 X100 F5000; second wipe mouth\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X90 F5000\nG0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle\nM104 S140 ; set temp down to heatbed acceptable\nM106 S255 ; turn on fan (G28 has turn off fan)\n\nM221 S; push soft endstop status\nM221 Z0 ;turn off Z axis endstop\nG0 Z0.5 F20000\nG0 X125 Y259.5 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 X128\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\n\nM109 S140 ; wait nozzle temp down to heatbed acceptable\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\n\nM221 R; pop softend status\nG1 Z10 F1200\nM400\nG1 Z10\nG1 F30000\nG1 X128 Y128\nG29.2 S1 ; turn on ABL\n;G28 ; home again after hard wipe mouth\nM106 S0 ; turn off fan , too noisy\n;===== wipe nozzle end ================================\n\n;===== check scanner clarity ===========================\nG1 X128 Y128 F24000\nG28 Z P0\nM972 S5 P0\nG1 X230 Y15 F24000\n;===== check scanner clarity end =======================\n\n;===== bed leveling ==================================\nM1002 judge_flag g29_before_print_flag\nM622 J1\n\n    M1002 gcode_claim_action : 1\n    G29 A X{first_layer_print_min[0]} Y{first_layer_print_min[1]} I{first_layer_print_size[0]} J{first_layer_print_size[1]}\n    M400\n    M500 ; save cali data\n\nM623\n;===== bed leveling end ================================\n\n;===== home after wipe mouth============================\nM1002 judge_flag g29_before_print_flag\nM622 J0\n\n    M1002 gcode_claim_action : 13\n    G28\n\nM623\n;===== home after wipe mouth end =======================\n\nM975 S1 ; turn on vibration supression\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\nM104 S{nozzle_temperature_initial_layer[initial_no_support_extruder]} ; set extrude temp earlier, to reduce wait time\n\n;===== mech mode fast check============================\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q1 A7 B30 C80  H15 K0\nM974 Q1 S2 P0\n\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q0 A7 B30 C90 Q0 H15 K0\nM974 Q0 S2 P0\n\nM975 S1\nG1 F30000\nG1 X230 Y15\nG28 X ; re-home XY\n;===== mech mode fast check============================\n\n{if scan_first_layer}\n;start heatbed  scan====================================\nM976 S2 P1\nG90\nG1 X128 Y128 F20000\nM976 S3 P2  ;register void printing detection\n{endif}\n\n;===== nozzle load line ===============================\nM975 S1\nG90\nM83\nT1000\nG1 X18.0 Y1.0 Z0.8 F18000;Move to start position\nM109 S{nozzle_temperature[initial_no_support_extruder]}\nG1 Z0.2\nG0 E2 F300\nG0 X240 E15 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nG0 Y11 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\nG0 X239.5\nG0 E0.2\nG0 Y1.5 E0.700\nG0 X231 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM400\n\n;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==\n;curr_bed_type={curr_bed_type}\n{if curr_bed_type==\"Textured PEI Plate\"}\nG29.1 Z{-0.04} ; for Textured PEI Plate\n{endif}\n\n;===== draw extrinsic para cali paint =================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M1002 gcode_claim_action : 8\n\n    T1000\n\n    G0 F1200.0 X231 Y12   Z0.2 E0.577\n    G0 F1200.0 X226 Y12   Z0.2 E0.275\n    G0 F1200.0 X226 Y1.5  Z0.2 E0.577\n    G0 F1200.0 X220 Y1.5  Z0.2 E0.330\n    G0 F1200.0 X220 Y8    Z0.2 E0.358\n    G0 F1200.0 X210 Y8    Z0.2 E0.549\n    G0 F1200.0 X210 Y1.5  Z0.2 E0.357\n\n    G0 X48.0 E11.9 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X48.0 Y12 E0.772 F1200.0\n    G0 X45.0 E0.22 F1200.0\n    G0 X35.0 Y6.0 E0.86 F1200.0\n\n    ;=========== extruder cali extrusion ==================\n    T1000\n    M83\n    {if default_acceleration > 0}\n        {if outer_wall_acceleration > 0}\n            M204 S[outer_wall_acceleration]\n        {else}\n            M204 S[default_acceleration]\n        {endif}\n    {endif}\n    G0 X35.000 Y6.000 Z0.300 F30000 E0\n    G1 F1500.000 E0.800\n    M106 S0 ; turn off fan\n    G0 X185.000 E9.35441 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G0 X187 Z0\n    G1 F1500.000 E-0.800\n    G0 Z1\n    G0 X180 Z0.3 F18000\n\n    M900 L1000.0 M1.0\n    M900 K0.040\n    G0 X45.000 F30000\n    G0 Y8.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.020\n    G0 X45.000 F30000\n    G0 Y10.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.000\n    G0 X45.000 F30000\n    G0 Y12.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n\n    G0 X45.000 F30000 ; move to start point\n\nM623 ; end of \"draw extrinsic para cali paint\"\n\n\nM1002 judge_flag extrude_cali_flag\nM622 J0\n    G0 X231 Y1.5 F30000\n    G0 X18 E14.3 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM623\n\nM104 S140\n\n\n;=========== laser and rgb calibration ===========\nM400\nM18 E\nM500 R\n\nM973 S3 P14\n\nG1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nT1100\nG1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nM400 P100\nM960 S1 P1\nM400 P100\nM973 S6 P0; use auto exposure for horizontal laser by xcam\nM960 S0 P0\n\nG1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos\nM960 S2 P1\nM400 P100\nM973 S6 P1; use auto exposure for vertical laser by xcam\nM960 S0 P0\n\n;=========== handeye calibration ======================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M973 S3 P1 ; camera start stream\n    M400 P500\n    M973 S1\n    G0 F6000 X228.500 Y4.750 Z0.000\n    M960 S0 P1\n    M973 S1\n    M400 P800\n    M971 S6 P0\n    M973 S2 P0\n    M400 P500\n    G0 Z0.000 F12000\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P200\n    M971 S5 P1\n    M973 S2 P1\n    M400 P500\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P3\n    G0 Z0.500 F12000\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P4\n    M973 S2 P0\n    M400 P500\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P500\n    M971 S5 P2\n    M963 S1\n    M400 P1500\n    M964\n    T1100\n    G1 Z3 F3000\n\n    M400\n    M500 ; save cali data\n\n    M104 S{nozzle_temperature[initial_no_support_extruder]} ; rise nozzle temp now ,to reduce temp waiting time.\n\n    T1100\n    M400 P400\n    M960 S0 P0\n    G0 F30000.000 Y10.000 X65.000 Z0.000\n    M400 P400\n    M960 S1 P1\n    M400 P50\n\n    M969 S1 N3 A2000\n    G0 F360.000 X181.000 Z0.000\n    M980.3 A70.000 B{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60/4} C5.000 D{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60} E5.000 F175.000 H1.000 I0.000 J0.020 K0.040\n    M400 P100\n    G0 F20000\n    G0 Z1 ; rise nozzle up\n    T1000 ; change to nozzle space\n    G0 X45.000 Y4.000 F30000 ; move to test line pos\n    M969 S0 ; turn off scanning\n    M960 S0 P0\n\n\n    G1 Z2 F20000\n    T1000\n    G0 X45.000 Y4.000 F30000 E0\n    M109 S{nozzle_temperature[initial_no_support_extruder]}\n    G0 Z0.3\n    G1 F1500.000 E3.600\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n\n    ; see if extrude cali success, if not ,use default value\n    M1002 judge_last_extrude_cali_success\n    M622 J0\n        M400\n        M900 K0.02 M{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*0.02}\n    M623\n\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X185.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X190.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X195.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X200.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X205.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X210.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X215.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X220.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X225.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    M973 S4\n\nM623\n\n;========turn off light and wait extrude temperature =============\nM1002 gcode_claim_action : 0\nM973 S4 ; turn off scanner\nM400 ; wait all motion done before implement the emprical L parameters\n;M900 L500.0 ; Empirical parameters\nM109 S[nozzle_temperature_initial_layer]\nM960 S1 P0 ; turn off laser\nM960 S2 P0 ; turn off laser\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off big fan\nM106 P3 S0 ; turn off chamber fan\n\nM975 S1 ; turn on mech mode supression\nG90\nM83\nT1000\n;===== purge line to wipe the nozzle ============================\nG1 E{-retraction_length[initial_no_support_extruder]} F1800\nG1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position\nG1 E{retraction_length[initial_no_support_extruder]} F1800\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]}\nG1 Z0.2\nG0 X239 E15 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\nG0 Y12 E0.7 F{outer_wall_volumetric_speed/(0.3*0.5)/4* 60}\n
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 28
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.2
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = hardened_steel
; nozzle_volume = 107
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 50%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab X1 Carbon 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab P1S 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL X1C
; printable_area = 0x0,256x0,256x256,0x256
; printable_height = 250
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab X1 Carbon
; printer_notes = 
; printer_settings_id = Bambu Lab X1 Carbon 0.4 nozzle
; printer_structure = corexy
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 249
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 1
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 4
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 150
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 15%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45
; supertack_plate_temp_initial_layer = 45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = tree(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45
; template_custom_gcode = 
; textured_plate_temp = 55
; textured_plate_temp_initial_layer = 55
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;========Date 20250206========\n; SKIPPABLE_START\n; SKIPTYPE: timelapse\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n{if timelapse_type == 0} ; timelapse without wipe tower\nM971 S11 C10 O0\nM1004 S5 P1  ; external shutter\n{elsif timelapse_type == 1} ; timelapse with wipe tower\nG92 E0\nG1 X65 Y245 F20000 ; move to safe pos\nG17\nG2 Z{layer_z} I0.86 J0.86 P1 F20000\nG1 Y265 F3000\nM400\nM1004 S5 P1  ; external shutter\nM400 P300\nM971 S11 C10 O0\nG92 E0\nG1 X100 F5000\nG1 Y255 F20000\n{endif}\nM623\n; SKIPPABLE_END\n
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 500
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab P1S 0.4 nozzle";"Bambu Lab P1P 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle";"Bambu Lab A1 0.4 nozzle";"Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R32
M201 X20000 Y20000 Z500 E5000
M203 X500 Y500 Z20 E30
M204 P20000 R5000 T20000
M205 X9.00 Y9.00 Z3.00 E2.50
M106 S0
M106 P2 S0
; FEATURE: Custom
;===== machine: X1-0.4 ====================
;===== date: 20251031 ==================
;===== start printer sound ================
M17
M400 S1
M1006 S1
M1006 A0 B10 L100 C37 D10 M60 E37 F10 N60
M1006 A0 B10 L100 C41 D10 M60 E41 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A46 B10 L100 C43 D10 M70 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A43 B10 L100 C0 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A41 B10 L100 C0 D10 M100 E41 F10 N100
M1006 A44 B10 L100 C0 D10 M100 E44 F10 N100
M1006 A49 B10 L100 C0 D10 M100 E49 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A48 B10 L100 C44 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A44 B10 L100 C0 D10 M90 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A46 B10 L100 C43 D10 M60 E39 F10 N100
M1006 W
;===== turn on the HB fan =================
M104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle
;===== reset machine status =================
M290 X40 Y40 Z2.6666666
G91
M17 Z0.4 ; lower the z-motor current
G380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed
G380 S2 Z-25 F300 ;
G1 Z5 F300;
G90
M17 X1.2 Y1.2 Z0.75 ; reset motor current to default
M960 S5 P1 ; turn on logo lamp
G90
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 5
M221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem
G29.1 Z0 ; clear z-trim value first
M204 S10000 ; init ACC set to 10m/s^2

;===== heatbed preheat ====================
M1002 gcode_claim_action:54
M140 S35 ;set bed temp
M190 S35 ;wait for bed temp


;=========register first layer scan=====
M977 S1 P60


;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

;===== prepare print temperature and material ==========
M104 S220 ;set extruder temp
G91
G0 Z10 F1200
G90
G28 X
M975 S1 ; turn on
G1 X60 F12000
G1 Y245
G1 Y265 F3000
M620 M
M620 S0A   ; switch material if AMS exist
    M109 S220
    G1 X120 F12000

    G1 X20 Y50 F12000
    G1 Y-3
    T0
    G1 X54 F12000
    G1 Y265
    M400
M621 S0A
M620.1 E F523.843 T240

M412 S1 ; ===turn on filament runout detection===

M109 S250 ;set nozzle to common flush temp
M106 P1 S0
G92 E0
M73 P1 R32
G1 E50 F200
M400
M104 S220
G92 E0
M73 P15 R27
G1 E50 F200
M400
M106 P1 S255
G92 E0
G1 E5 F300
M109 S200 ; drop nozzle temp, make filament shink a bit
G92 E0
G1 E-0.5 F300

M73 P16 R27
G1 X70 F9000
G1 X76 F15000
G1 X65 F15000
G1 X76 F15000
G1 X65 F15000; shake to put down garbage
G1 X80 F6000
G1 X95 F15000
G1 X80 F15000
G1 X165 F15000; wipe and shake
M400
M106 P1 S0
;===== prepare print temperature and material end =====


;===== wipe nozzle ===============================
M1002 gcode_claim_action : 14
M975 S1
M106 S255
G1 X65 Y230 F18000
G1 Y264 F6000
M109 S200
G1 X100 F18000 ; first wipe mouth

G0 X135 Y253 F20000  ; move to exposed steel surface edge
G28 Z P0 T300; home z with low precision,permit 300deg temperature
G29.2 S0 ; turn off ABL
G0 Z5 F20000

G1 X60 Y265
G92 E0
G1 E-0.5 F300 ; retrack more
G1 X100 F5000; second wipe mouth
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X90 F5000
G0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle
M104 S140 ; set temp down to heatbed acceptable
M106 S255 ; turn on fan (G28 has turn off fan)

M221 S; push soft endstop status
M221 Z0 ;turn off Z axis endstop
G0 Z0.5 F20000
G0 X125 Y259.5 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 X128
G2 I0.5 J0 F300
G2 I0.5 J0 F300
M73 P17 R27
G2 I0.5 J0 F300
G2 I0.5 J0 F300

M109 S140 ; wait nozzle temp down to heatbed acceptable
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000

M221 R; pop softend status
G1 Z10 F1200
M400
G1 Z10
G1 F30000
G1 X128 Y128
G29.2 S1 ; turn on ABL
;G28 ; home again after hard wipe mouth
M106 S0 ; turn off fan , too noisy
;===== wipe nozzle end ================================

;===== check scanner clarity ===========================
G1 X128 Y128 F24000
G28 Z P0
M972 S5 P0
G1 X230 Y15 F24000
;===== check scanner clarity end =======================

;===== bed leveling ==================================
M1002 judge_flag g29_before_print_flag
M622 J1

    M1002 gcode_claim_action : 1
    G29 A X73.0812 Y94 I109.838 J68
    M400
    M500 ; save cali data

M623
;===== bed leveling end ================================

;===== home after wipe mouth============================
M1002 judge_flag g29_before_print_flag
M622 J0

    M1002 gcode_claim_action : 13
    G28

M623
;===== home after wipe mouth end =======================

M975 S1 ; turn on vibration supression

;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

M104 S220 ; set extrude temp earlier, to reduce wait time

;===== mech mode fast check============================
M73 P17 R26
G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q1 A7 B30 C80  H15 K0
M974 Q1 S2 P0

G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q0 A7 B30 C90 Q0 H15 K0
M974 Q0 S2 P0

M975 S1
G1 F30000
G1 X230 Y15
G28 X ; re-home XY
;===== mech mode fast check============================


;start heatbed  scan====================================
M976 S2 P1
G90
G1 X128 Y128 F20000
M976 S3 P2  ;register void printing detection


;===== nozzle load line ===============================
M975 S1
G90
M83
T1000
G1 X18.0 Y1.0 Z0.8 F18000;Move to start position
M109 S220
G1 Z0.2
G0 E2 F300
G0 X240 E15 F6033.27
G0 Y11 E0.700 F1508.32
G0 X239.5
G0 E0.2
G0 Y1.5 E0.700
G0 X231 E0.700 F6033.27
M400

;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==
;curr_bed_type=Cool Plate


;===== draw extrinsic para cali paint =================
M1002 judge_flag extrude_cali_flag
M622 J1

    M1002 gcode_claim_action : 8

    T1000

    G0 F1200.0 X231 Y12   Z0.2 E0.577
    G0 F1200.0 X226 Y12   Z0.2 E0.275
    G0 F1200.0 X226 Y1.5  Z0.2 E0.577
    G0 F1200.0 X220 Y1.5  Z0.2 E0.330
    G0 F1200.0 X220 Y8    Z0.2 E0.358
    G0 F1200.0 X210 Y8    Z0.2 E0.549
    G0 F1200.0 X210 Y1.5  Z0.2 E0.357

    G0 X48.0 E11.9 F6033.27
    G0 X48.0 Y12 E0.772 F1200.0
    G0 X45.0 E0.22 F1200.0
    G0 X35.0 Y6.0 E0.86 F1200.0

    ;=========== extruder cali extrusion ==================
    T1000
    M83
    
        
            M204 S5000
        
    
    G0 X35.000 Y6.000 Z0.300 F30000 E0
    G1 F1500.000 E0.800
    M106 S0 ; turn off fan
    G0 X185.000 E9.35441 F6033.27
    G0 X187 Z0
    G1 F1500.000 E-0.800
    G0 Z1
    G0 X180 Z0.3 F18000

    M900 L1000.0 M1.0
    M900 K0.040
    G0 X45.000 F30000
    G0 Y8.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
M73 P18 R26
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.020
    G0 X45.000 F30000
    G0 Y10.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
M73 P19 R26
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.000
    G0 X45.000 F30000
    G0 Y12.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3

    G0 X45.000 F30000 ; move to start point

M623 ; end of "draw extrinsic para cali paint"


M1002 judge_flag extrude_cali_flag
M622 J0
    G0 X231 Y1.5 F30000
    G0 X18 E14.3 F6033.27
M623

M104 S140


;=========== laser and rgb calibration ===========
M400
M18 E
M500 R

M973 S3 P14

G1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
T1100
G1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
M400 P100
M960 S1 P1
M400 P100
M973 S6 P0; use auto exposure for horizontal laser by xcam
M960 S0 P0

G1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos
M960 S2 P1
M400 P100
M973 S6 P1; use auto exposure for vertical laser by xcam
M960 S0 P0

;=========== handeye calibration ======================
M1002 judge_flag extrude_cali_flag
M622 J1

    M973 S3 P1 ; camera start stream
    M400 P500
    M973 S1
    G0 F6000 X228.500 Y4.750 Z0.000
    M960 S0 P1
    M973 S1
    M400 P800
    M971 S6 P0
    M973 S2 P0
    M400 P500
    G0 Z0.000 F12000
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P200
    M971 S5 P1
    M973 S2 P1
    M400 P500
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P3
    G0 Z0.500 F12000
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P4
    M973 S2 P0
    M400 P500
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P500
    M971 S5 P2
    M963 S1
    M400 P1500
    M964
    T1100
    G1 Z3 F3000

    M400
    M500 ; save cali data

    M104 S220 ; rise nozzle temp now ,to reduce temp waiting time.

    T1100
    M400 P400
    M960 S0 P0
    G0 F30000.000 Y10.000 X65.000 Z0.000
    M400 P400
    M960 S1 P1
    M400 P50

    M969 S1 N3 A2000
    G0 F360.000 X181.000 Z0.000
    M980.3 A70.000 B94.1106 C5.000 D376.442 E5.000 F175.000 H1.000 I0.000 J0.020 K0.040
    M400 P100
    G0 F20000
    G0 Z1 ; rise nozzle up
    T1000 ; change to nozzle space
    G0 X45.000 Y4.000 F30000 ; move to test line pos
    M969 S0 ; turn off scanning
    M960 S0 P0


    G1 Z2 F20000
    T1000
    G0 X45.000 Y4.000 F30000 E0
    M109 S220
    G0 Z0.3
    G1 F1500.000 E3.600
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27

    ; see if extrude cali success, if not ,use default value
    M1002 judge_last_extrude_cali_success
    M622 J0
        M400
        M900 K0.02 M0.125481
    M623

    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F1508.32
    G1 X185.000 E0.31181 F6033.27
    G1 X190.000 E0.31181 F1508.32
    G1 X195.000 E0.31181 F6033.27
    G1 X200.000 E0.31181 F1508.32
    G1 X205.000 E0.31181 F6033.27
    G1 X210.000 E0.31181 F1508.32
    G1 X215.000 E0.31181 F6033.27
    G1 X220.000 E0.31181 F1508.32
    G1 X225.000 E0.31181 F6033.27
    M973 S4

M623

;========turn off light and wait extrude temperature =============
M1002 gcode_claim_action : 0
M973 S4 ; turn off scanner
M400 ; wait all motion done before implement the emprical L parameters
;M900 L500.0 ; Empirical parameters
M109 S220
M960 S1 P0 ; turn off laser
M960 S2 P0 ; turn off laser
M106 S0 ; turn off fan
M106 P2 S0 ; turn off big fan
M106 P3 S0 ; turn off chamber fan

M975 S1 ; turn on mech mode supression
G90
M83
T1000
;===== purge line to wipe the nozzle ============================
G1 E-0.8 F1800
G1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position
G1 E0.8 F1800
M109 S220
G1 Z0.2
G0 X239 E15 F6033.27
G0 Y12 E0.7 F1508.32
; MACHINE_START_GCODE_END
; filament start gcode

M142 P1 R35 S40
;VT0 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/23
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
M106 P2 S0
; OBJECT_ID: 15
G1 X164.229 Y144.497 F30000
M204 S6000
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
M73 P20 R26
G3 X167.874 Y142.859 I3.765 J3.502 E.15287
G1 X168.161 Y142.86 E.01067
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X164.189 Y144.541 I-.167 J5.139 E1.03752
M204 S6000
G1 X163.897 Y144.189 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G3 X167.586 Y142.416 I4.101 J3.808 E.15607
G3 X168.173 Y142.403 I.408 J5.383 E.02188
G3 X163.857 Y144.233 I-.175 J5.594 E1.12948
; WIPE_START
G1 X164.299 Y143.801 E-.2349
G1 X164.736 Y143.453 E-.21217
G1 X165.205 Y143.15 E-.21217
G1 X165.441 Y143.029 E-.10076
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X172.371 Y145.66 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51712
G1 F6300
M204 S500
G1 X171.132 Y144.421 E.06769
G2 X169.544 Y143.504 I-3.086 J3.508 E.07134
G1 X172.497 Y146.457 E.1614
G3 X172.71 Y147.341 I-5.469 J1.786 E.03516
G1 X168.665 Y143.295 E.22107
G2 X167.946 Y143.248 I-.776 J6.278 E.02783
G1 X172.752 Y148.054 E.26262
G3 X172.708 Y148.68 I-3.152 J.092 E.0243
G1 X167.326 Y143.298 E.29408
G2 X166.772 Y143.415 I.302 J2.823 E.02193
G1 X172.592 Y149.235 E.31806
G3 X172.424 Y149.738 I-2.598 J-.587 E.02052
G1 X166.268 Y143.581 E.33644
G2 X165.807 Y143.791 I.817 J2.403 E.0196
G1 X172.214 Y150.198 E.3501
G3 X171.965 Y150.619 I-2.231 J-1.033 E.01895
G1 X165.385 Y144.04 E.35956
G2 X164.999 Y144.324 I1.226 J2.069 E.01856
M73 P20 R25
G1 X171.684 Y151.009 E.36531
G3 X171.364 Y151.36 I-2.499 J-1.957 E.01836
G1 X164.647 Y144.643 E.36707
G2 X164.328 Y144.995 I1.6 J1.768 E.01838
G1 X171.012 Y151.678 E.36524
G3 X170.626 Y151.963 I-1.615 J-1.787 E.01856
G1 X164.044 Y145.381 E.35969
G2 X163.795 Y145.802 I1.983 J1.455 E.01895
G1 X170.205 Y152.212 E.35027
G3 X169.745 Y152.423 I-1.285 J-2.189 E.01957
M73 P21 R25
G1 X163.584 Y146.263 E.33667
G2 X163.417 Y146.765 I2.432 J1.09 E.02052
G1 X169.239 Y152.588 E.31819
G3 X168.681 Y152.7 I-.84 J-2.736 E.02205
G1 X163.301 Y147.32 E.294
G2 X163.257 Y147.947 I3.108 J.535 E.0243
G1 X168.058 Y152.748 E.26239
G3 X167.344 Y152.705 I-.023 J-5.518 E.02766
G1 X163.299 Y148.659 E.22106
G2 X163.512 Y149.543 I5.683 J-.902 E.03515
G1 X166.465 Y152.496 E.16139
G3 X164.876 Y151.578 I1.499 J-4.428 E.07137
G1 X163.638 Y150.34 E.06764
; WIPE_START
G1 X164.876 Y151.578 E-.6652
G1 X165.071 Y151.734 E-.0948
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X164.92 Y144.103 Z.6 F30000
G1 X164.059 Y100.689 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G3 X167.874 Y98.859 I3.935 J3.31 E.16243
G1 X168.161 Y98.86 E.01067
G3 X164.021 Y100.736 I-.167 J5.139 E1.02796
M204 S6000
G1 X163.712 Y100.398 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G3 X167.586 Y98.416 I4.286 J3.598 E.16648
G3 X168.173 Y98.403 I.408 J5.383 E.02188
G3 X163.674 Y100.445 I-.175 J5.594 E1.11907
; WIPE_START
G1 X164.094 Y99.991 E-.23486
G1 X164.513 Y99.622 E-.21221
G1 X164.966 Y99.296 E-.21211
G1 X165.196 Y99.163 E-.10082
; WIPE_END
M73 P22 R25
G1 E-.04 F1800
M204 S6000
G1 X172.371 Y101.66 Z.6 F30000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51712
G1 F6300
M204 S500
G1 X171.132 Y100.421 E.06769
G2 X169.544 Y99.504 I-3.086 J3.508 E.07134
G1 X172.497 Y102.457 E.1614
G3 X172.71 Y103.341 I-5.466 J1.785 E.03516
G1 X168.665 Y99.295 E.22107
G2 X167.946 Y99.248 I-.776 J6.27 E.02783
G1 X172.752 Y104.054 E.26262
G3 X172.708 Y104.68 I-3.152 J.092 E.0243
G1 X167.326 Y99.298 E.29408
G2 X166.772 Y99.415 I.302 J2.824 E.02193
G1 X172.592 Y105.235 E.31806
G3 X172.424 Y105.738 I-2.594 J-.586 E.02052
G1 X166.268 Y99.581 E.33644
G2 X165.807 Y99.791 I.819 J2.408 E.0196
G1 X172.214 Y106.198 E.3501
G3 X171.965 Y106.619 I-2.231 J-1.032 E.01895
G1 X165.385 Y100.04 E.35956
G2 X164.999 Y100.324 I1.227 J2.07 E.01856
G1 X171.68 Y107.005 E.36512
G3 X171.362 Y107.358 I-1.944 J-1.437 E.01838
G1 X164.647 Y100.643 E.36697
G2 X164.328 Y100.995 I1.6 J1.768 E.01838
G1 X171.013 Y107.679 E.36529
G3 X170.626 Y107.963 I-1.975 J-2.289 E.01856
G1 X164.044 Y101.381 E.35969
G2 X163.795 Y101.802 I1.982 J1.454 E.01895
G1 X170.205 Y108.212 E.35027
G3 X169.745 Y108.423 I-1.284 J-2.188 E.01957
G1 X163.584 Y102.262 E.33667
G2 X163.417 Y102.765 I2.43 J1.09 E.02052
G1 X169.239 Y108.588 E.31819
G3 X168.681 Y108.7 I-.839 J-2.732 E.02205
G1 X163.301 Y103.32 E.294
G2 X163.257 Y103.947 I3.109 J.535 E.0243
G1 X168.058 Y108.748 E.26239
G3 X167.344 Y108.705 I-.023 J-5.522 E.02766
G1 X163.299 Y104.659 E.22106
G2 X163.512 Y105.543 I5.68 J-.901 E.03516
G1 X166.465 Y108.496 E.16139
G3 X164.876 Y107.578 I1.5 J-4.428 E.07137
G1 X163.638 Y106.34 E.06765
; WIPE_START
G1 X164.876 Y107.578 E-.66526
G1 X165.071 Y107.734 E-.09474
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X157.44 Y107.863 Z.6 F30000
G1 X87.113 Y109.058 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X86.86 Y109.014 E.00957
G3 X87.874 Y98.859 I1.134 J-5.015 E.55459
G1 X88.161 Y98.86 E.01067
G3 X87.365 Y109.102 I-.167 J5.139 E.61893
G1 X87.172 Y109.069 E.00729
M204 S6000
G1 X87.033 Y109.509 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G3 X87.586 Y98.416 I.965 J-5.512 E.60335
G3 X88.173 Y98.403 I.408 J5.383 E.02188
G3 X87.092 Y109.519 I-.175 J5.594 E.6822
; WIPE_START
G1 X86.758 Y109.459 E-.12905
G1 X86.221 Y109.308 E-.21204
G1 X85.701 Y109.104 E-.21213
G1 X85.217 Y108.856 E-.20678
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X90.598 Y103.443 Z.6 F30000
G1 X92.371 Y101.66 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51712
G1 F6300
M204 S500
G1 X91.132 Y100.421 E.06768
G2 X89.544 Y99.504 I-3.087 J3.509 E.07135
G1 X92.497 Y102.457 E.1614
G3 X92.71 Y103.341 I-5.469 J1.785 E.03515
G1 X88.665 Y99.295 E.22107
G2 X87.946 Y99.248 I-.776 J6.282 E.02783
G1 X92.752 Y104.054 E.26262
G3 X92.708 Y104.68 I-3.156 J.092 E.0243
G1 X87.326 Y99.298 E.29408
G2 X86.772 Y99.415 I.302 J2.825 E.02193
G1 X92.592 Y105.235 E.31805
G3 X92.424 Y105.738 I-2.595 J-.586 E.02052
G1 X86.268 Y99.581 E.33643
G2 X85.807 Y99.791 I.819 J2.408 E.0196
G1 X92.214 Y106.198 E.3501
G3 X91.965 Y106.619 I-2.23 J-1.032 E.01895
G1 X85.385 Y100.04 E.35956
G2 X84.999 Y100.324 I1.228 J2.072 E.01856
G1 X91.68 Y107.005 E.36512
G3 X91.362 Y107.358 I-1.917 J-1.414 E.01838
G1 X84.647 Y100.643 E.36696
G2 X84.328 Y100.995 I1.601 J1.769 E.01838
G1 X91.01 Y107.676 E.36512
G3 X90.624 Y107.96 I-1.614 J-1.788 E.01856
G1 X84.044 Y101.381 E.35956
G2 X83.795 Y101.802 I1.982 J1.454 E.01895
G1 X90.202 Y108.209 E.3501
G3 X89.741 Y108.419 I-1.278 J-2.195 E.0196
G1 X83.584 Y102.263 E.33643
G2 X83.417 Y102.765 I2.431 J1.09 E.02052
G1 X89.237 Y108.585 E.31805
G3 X88.681 Y108.7 I-.917 J-3.038 E.02196
G1 X83.301 Y103.32 E.294
G2 X83.257 Y103.947 I3.109 J.535 E.0243
G1 X88.058 Y108.748 E.26239
G3 X87.344 Y108.705 I-.023 J-5.523 E.02766
G1 X83.299 Y104.659 E.22106
G2 X83.512 Y105.543 I5.681 J-.902 E.03516
G1 X86.465 Y108.496 E.16139
G3 X84.876 Y107.578 I1.499 J-4.428 E.07137
G1 X83.638 Y106.34 E.06765
; WIPE_START
G1 X84.876 Y107.578 E-.66525
G1 X85.071 Y107.734 E-.09476
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X85.25 Y115.364 Z.6 F30000
G1 X86.128 Y152.781 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X85.888 Y152.69 E.00954
G3 X87.874 Y142.859 I2.106 J-4.691 E.51638
G1 X88.161 Y142.86 E.01067
G3 X86.366 Y152.877 I-.167 J5.139 E.65712
G1 X86.183 Y152.803 E.00733
M204 S6000
G1 X85.96 Y153.209 F30000
; FEATURE: Outer wall
G1 F3000
M204 S500
G3 X87.586 Y142.416 I2.038 J-5.212 E.56176
G3 X88.173 Y142.403 I.408 J5.383 E.02188
G3 X86.016 Y153.23 I-.175 J5.594 E.72379
; WIPE_START
G1 X85.449 Y152.983 E-.23485
G1 X84.966 Y152.704 E-.21202
G1 X84.513 Y152.378 E-.21213
G1 X84.314 Y152.202 E-.10101
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X90.239 Y147.391 Z.6 F30000
G1 X92.371 Y145.66 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51712
G1 F6300
M204 S500
G1 X91.132 Y144.422 E.06768
G2 X89.544 Y143.504 I-3.086 J3.508 E.07135
G1 X92.497 Y146.457 E.1614
G3 X92.71 Y147.341 I-5.458 J1.783 E.03515
G1 X88.665 Y143.295 E.22107
G2 X87.946 Y143.248 I-.776 J6.278 E.02783
G1 X92.752 Y148.054 E.26262
G3 X92.708 Y148.68 I-3.156 J.092 E.0243
G1 X87.326 Y143.298 E.29408
G2 X86.772 Y143.415 I.303 J2.827 E.02193
G1 X92.59 Y149.233 E.31795
G3 X92.424 Y149.738 I-2.643 J-.588 E.02057
G1 X86.268 Y143.581 E.33644
G2 X85.807 Y143.791 I.817 J2.405 E.0196
M73 P23 R25
G1 X92.215 Y150.199 E.35018
G3 X91.967 Y150.621 I-2.237 J-1.031 E.01896
G1 X85.385 Y144.04 E.35967
G2 X84.999 Y144.324 I1.227 J2.07 E.01856
G1 X91.682 Y151.008 E.36523
G3 X91.364 Y151.36 I-1.919 J-1.415 E.01838
G1 X84.647 Y144.643 E.36707
G2 X84.328 Y144.995 I1.6 J1.767 E.01838
G1 X91.012 Y151.678 E.36524
G3 X90.626 Y151.963 I-1.614 J-1.785 E.01856
G1 X84.044 Y145.381 E.35969
G2 X83.795 Y145.802 I1.981 J1.454 E.01895
G1 X90.205 Y152.212 E.35027
G3 X89.745 Y152.423 I-1.283 J-2.186 E.01957
G1 X83.584 Y146.263 E.33667
G2 X83.417 Y146.765 I2.428 J1.089 E.02052
G1 X89.239 Y152.588 E.31819
G3 X88.681 Y152.7 I-.839 J-2.731 E.02205
G1 X83.301 Y147.32 E.294
G2 X83.257 Y147.947 I3.108 J.535 E.0243
G1 X88.058 Y152.748 E.26239
G3 X87.344 Y152.705 I-.023 J-5.516 E.02766
G1 X83.299 Y148.659 E.22106
G2 X83.512 Y149.543 I5.684 J-.903 E.03516
G1 X86.465 Y152.496 E.16139
G3 X84.876 Y151.578 I1.499 J-4.427 E.07137
G1 X83.638 Y150.34 E.06764
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F6300
G1 X84.876 Y151.578 E-.66515
G1 X85.071 Y151.734 E-.09485
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/23
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S255
M106 P2 S178
; open powerlost recovery
M1003 S1
M976 S1 P1 ; scan model before printing 2nd layer
M400 P100
G1 E.8
; OBJECT_ID: 15
G1 E-.8
M204 S10000
G1 X92.658 Y150.901 Z.6 F30000
G1 X168.214 Y142.608 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X167.333 Y142.644 I-.217 J5.392 E1.09552
G3 X168.154 Y142.607 I.78 J8.181 E.02725
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

M204 S250
G1 X168.233 Y142.216 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X167.284 Y142.255 I-.238 J5.784 E1.08838
G3 X168.173 Y142.215 I.833 J8.705 E.02735
; WIPE_START
M204 S10000
G1 X168.724 Y142.255 E-.21003
G1 X169.293 Y142.355 E-.2193
G1 X169.848 Y142.512 E-.21936
G1 X170.121 Y142.619 E-.11131
; WIPE_END
G1 E-.04 F1800
G1 X165.39 Y143.466 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43187
G1 F15000
G1 X164.248 Y144.608 E.05118
G2 X163.324 Y146.082 I3.496 J3.219 E.05547
G1 X166.087 Y143.319 E.12384
G3 X166.877 Y143.063 I1.676 J3.822 E.02638
G1 X166.897 Y143.059 E.00062
G1 X163.069 Y146.887 E.17156
G2 X162.967 Y147.539 I3.206 J.835 E.02095
G1 X167.544 Y142.962 E.20512
G3 X168.116 Y142.94 I.419 J3.324 E.01819
G1 X162.947 Y148.11 E.23173
G2 X162.984 Y148.623 I2.582 J.071 E.01633
G1 X168.631 Y142.975 E.25315
G3 X169.099 Y143.057 I-.19 J2.452 E.01508
G1 X163.065 Y149.091 E.27048
G2 X163.182 Y149.525 I2.223 J-.367 E.01424
G1 X169.531 Y143.175 E.2846
G3 X169.933 Y143.323 I-.54 J2.084 E.0136
G1 X163.328 Y149.928 E.29604
G2 X163.501 Y150.306 I1.971 J-.672 E.01318
G1 X170.309 Y143.498 E.30516
G3 X170.662 Y143.695 I-.809 J1.86 E.01283
G1 X163.696 Y150.66 E.31219
G1 X163.919 Y150.987 E.01255
G1 X170.993 Y143.914 E.31705
G1 X171.299 Y144.158 E.01241
G1 X164.164 Y151.292 E.31978
G2 X164.429 Y151.578 I1.559 J-1.178 E.01236
G1 X171.582 Y144.424 E.32064
G3 X171.847 Y144.71 I-1.295 J1.462 E.01236
G1 X164.713 Y151.844 E.31976
G1 X165.019 Y152.088 E.01241
G1 X172.091 Y145.016 E.31701
G1 X172.314 Y145.343 E.01255
G1 X165.35 Y152.307 E.31215
G2 X165.703 Y152.504 I1.161 J-1.663 E.01283
G1 X172.51 Y145.697 E.30509
G3 X172.682 Y146.075 I-1.802 J1.049 E.01318
M73 P23 R24
G1 X166.079 Y152.678 E.29595
G2 X166.481 Y152.826 I.94 J-1.936 E.0136
G1 X172.828 Y146.479 E.28448
G3 X172.945 Y146.912 I-2.109 J.799 E.01425
G1 X166.914 Y152.944 E.27033
G2 X167.382 Y153.025 I.645 J-2.31 E.01509
G1 X173.026 Y147.382 E.25297
G3 X173.062 Y147.895 I-2.548 J.44 E.01634
G1 X167.895 Y153.062 E.23161
G2 X168.468 Y153.039 I.172 J-2.877 E.0182
G1 X173.041 Y148.466 E.20497
G3 X172.938 Y149.119 I-3.311 J-.186 E.02097
G1 X169.125 Y152.932 E.17092
G2 X169.925 Y152.682 I-1.291 J-5.539 E.02659
G1 X172.691 Y149.916 E.12398
G3 X171.884 Y151.255 I-4.666 J-1.901 E.04975
G3 X170.647 Y152.511 I-17.389 J-15.895 E.05588
; WIPE_START
G1 X171.884 Y151.255 E-.66979
G1 X172.027 Y151.066 E-.09021
; WIPE_END
G1 E-.04 F1800
G1 X170.81 Y143.531 Z.8 F30000
G1 X163.865 Y100.527 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X167.333 Y98.644 I4.131 J3.473 E.134
G3 X168.214 Y98.608 I.78 J8.182 E.02925
G3 X163.827 Y100.573 I-.217 J5.393 E.9596
M204 S250
G1 X163.565 Y100.274 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X167.284 Y98.255 I4.431 J3.726 E.13314
G3 X168.233 Y98.216 I.832 J8.705 E.02919
G3 X163.526 Y100.321 I-.238 J5.784 E.95346
; WIPE_START
M204 S10000
G1 X163.76 Y100.062 E-.13248
G1 X164.173 Y99.659 E-.21938
G1 X164.625 Y99.299 E-.21937
G1 X165.042 Y99.029 E-.18876
; WIPE_END
G1 E-.04 F1800
G1 X165.39 Y99.466 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43175
G1 F15000
G1 X164.249 Y100.607 E.05114
G2 X163.324 Y102.082 I3.499 J3.221 E.05546
G1 X166.087 Y99.319 E.12378
G3 X166.878 Y99.063 I1.679 J3.829 E.02639
G1 X166.896 Y99.059 E.0006
G1 X163.069 Y102.886 E.17148
G2 X162.967 Y103.538 I3.205 J.835 E.02094
G1 X167.543 Y98.963 E.20503
G3 X168.116 Y98.94 I.419 J3.323 E.01818
G1 X162.947 Y104.109 E.23162
G2 X162.983 Y104.622 I2.581 J.072 E.01632
G1 X168.631 Y98.975 E.25304
G3 X169.098 Y99.057 I-.198 J2.499 E.01507
G1 X163.065 Y105.091 E.27036
G2 X163.181 Y105.524 I2.222 J-.366 E.01424
G1 X169.53 Y99.175 E.28448
G3 X169.932 Y99.323 I-.54 J2.084 E.01359
G1 X163.328 Y105.927 E.29592
G2 X163.5 Y106.305 I1.972 J-.672 E.01317
G1 X170.308 Y99.497 E.30504
G3 X170.66 Y99.694 I-.81 J1.862 E.01282
G1 X163.696 Y106.659 E.31208
G1 X163.919 Y106.986 E.01254
G1 X170.992 Y99.913 E.31693
G1 X171.298 Y100.157 E.0124
G1 X164.163 Y107.291 E.31967
G2 X164.428 Y107.577 I1.558 J-1.177 E.01235
G1 X171.581 Y100.423 E.32054
G3 X171.845 Y100.709 I-1.294 J1.463 E.01235
G1 X164.711 Y107.843 E.31968
G1 X165.017 Y108.087 E.0124
G1 X172.09 Y101.014 E.31694
G1 X172.313 Y101.341 E.01254
G1 X165.348 Y108.306 E.31208
G2 X165.701 Y108.503 I1.162 J-1.663 E.01282
G1 X172.509 Y101.695 E.30504
G3 X172.681 Y102.073 I-1.8 J1.05 E.01317
G1 X166.077 Y108.677 E.29592
G2 X166.479 Y108.825 I.94 J-1.932 E.01359
G1 X172.827 Y102.476 E.28448
G3 X172.944 Y102.91 I-2.108 J.8 E.01424
G1 X166.911 Y108.943 E.27036
G2 X167.378 Y109.025 I.646 J-2.306 E.01507
G1 X173.025 Y103.378 E.25303
G3 X173.062 Y103.891 I-2.545 J.441 E.01632
G1 X167.891 Y109.062 E.23171
G2 X168.463 Y109.04 I.174 J-2.869 E.01818
G1 X173.041 Y104.462 E.20513
G3 X172.939 Y105.114 I-3.308 J-.183 E.02094
G1 X169.12 Y108.933 E.17115
G2 X169.917 Y108.686 I-1.312 J-5.636 E.02648
G1 X172.685 Y105.919 E.124
G3 X171.76 Y107.393 I-4.423 J-1.746 E.05548
G1 X170.636 Y108.517 E.05034
; WIPE_START
G1 X171.76 Y107.393 E-.60371
G1 X172.024 Y107.078 E-.15629
; WIPE_END
G1 E-.04 F1800
G1 X164.394 Y107.283 Z.8 F30000
G1 X87.334 Y109.349 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X87.067 Y109.317 E.00892
G3 X87.333 Y98.644 I.929 J-5.316 E.5094
G3 X88.214 Y98.608 I.78 J8.182 E.02925
G3 X87.601 Y109.383 I-.217 J5.393 E.56833
G1 X87.394 Y109.357 E.00694
M204 S250
G1 X87.284 Y109.745 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X87.284 Y98.255 I.711 J-5.745 E.51503
G3 X88.233 Y98.216 I.832 J8.705 E.02919
G3 X87.344 Y109.752 I-.238 J5.784 E.57158
; WIPE_START
M204 S10000
G1 X86.716 Y109.645 E-.2421
G1 X86.16 Y109.488 E-.21936
G1 X85.623 Y109.278 E-.21928
G1 X85.437 Y109.182 E-.07925
; WIPE_END
G1 E-.04 F1800
G1 X90.647 Y108.511 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43187
G1 F15000
G2 X91.884 Y107.255 I-16.153 J-17.151 E.05588
G2 X92.688 Y105.919 I-3.824 J-3.213 E.04963
G1 X89.925 Y108.682 E.12385
G3 X89.125 Y108.932 I-2.092 J-5.29 E.02659
G1 X92.939 Y105.119 E.17094
G2 X93.047 Y104.46 I-7.812 J-1.622 E.02115
G1 X88.468 Y109.039 E.20524
G3 X87.895 Y109.062 I-.401 J-2.85 E.0182
G1 X93.062 Y103.895 E.23161
G2 X93.026 Y103.382 I-2.583 J-.074 E.01634
G1 X87.382 Y109.025 E.25297
G3 X86.914 Y108.944 I.178 J-2.4 E.01509
G1 X92.945 Y102.912 E.27033
G2 X92.828 Y102.479 I-2.224 J.365 E.01425
G1 X86.481 Y108.826 E.28448
G3 X86.079 Y108.678 I.537 J-2.082 E.0136
G1 X92.682 Y102.075 E.29595
G2 X92.51 Y101.697 I-1.974 J.672 E.01318
G1 X85.703 Y108.504 E.30509
G3 X85.35 Y108.307 I.807 J-1.859 E.01283
G1 X92.314 Y101.343 E.31215
G1 X92.091 Y101.016 E.01255
G1 X85.019 Y108.088 E.31701
G1 X84.713 Y107.844 E.01241
G1 X91.847 Y100.71 E.31976
G2 X91.582 Y100.424 I-1.561 J1.178 E.01236
G1 X84.429 Y107.578 E.32064
G3 X84.164 Y107.292 I1.296 J-1.465 E.01236
G1 X91.299 Y100.158 E.31978
G1 X90.993 Y99.914 E.01241
G1 X83.919 Y106.987 E.31705
G1 X83.696 Y106.66 E.01255
G1 X90.662 Y99.695 E.31219
G2 X90.309 Y99.498 I-1.162 J1.662 E.01283
G1 X83.501 Y106.306 E.30516
G3 X83.328 Y105.928 I1.8 J-1.051 E.01318
G1 X89.933 Y99.323 E.29604
G2 X89.531 Y99.175 I-.941 J1.934 E.0136
G1 X83.182 Y105.525 E.2846
G3 X83.065 Y105.091 I2.106 J-.8 E.01425
G1 X89.099 Y99.057 E.27048
G2 X88.631 Y98.975 I-.655 J2.353 E.01508
G1 X82.984 Y104.623 E.25315
G3 X82.947 Y104.11 I2.545 J-.442 E.01633
G1 X88.116 Y98.94 E.23173
G2 X87.544 Y98.962 I-.154 J3.347 E.01819
G1 X82.967 Y103.539 E.20512
G3 X83.069 Y102.887 I3.311 J.183 E.02095
G1 X86.897 Y99.059 E.17156
G1 X86.877 Y99.063 E.00062
G2 X86.087 Y99.319 I.887 J4.083 E.02638
G1 X83.324 Y102.082 E.12384
G3 X84.248 Y100.608 I4.422 J1.745 E.05546
G1 X85.39 Y99.466 E.0512
; WIPE_START
G1 X84.248 Y100.608 E-.61384
G1 X84.001 Y100.903 E-.14616
; WIPE_END
G1 E-.04 F1800
G1 X84.227 Y108.532 Z.8 F30000
G1 X85.54 Y152.806 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X87.333 Y142.644 I2.456 J-4.806 E.45579
G3 X88.214 Y142.608 I.78 J8.181 E.02924
G3 X85.594 Y152.833 I-.217 J5.393 E.63781
M204 S250
G1 X85.361 Y153.155 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X87.284 Y142.255 I2.634 J-5.155 E.45289
G3 X88.233 Y142.216 I.833 J8.705 E.02919
G3 X85.415 Y153.182 I-.238 J5.784 E.63371
; WIPE_START
M204 S10000
G1 X85.109 Y153.014 E-.1324
G1 X84.625 Y152.701 E-.21935
G1 X84.173 Y152.341 E-.21933
G1 X83.962 Y152.145 E-.10975
G1 X83.82 Y151.992 E-.07917
; WIPE_END
G1 E-.04 F1800
G1 X90.647 Y152.511 Z.8 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43187
G1 F15000
G2 X91.884 Y151.255 I-16.147 J-17.146 E.05587
G2 X92.689 Y149.919 I-3.83 J-3.218 E.04966
G1 X89.925 Y152.682 E.12387
G3 X89.125 Y152.932 I-2.09 J-5.285 E.02659
G1 X92.938 Y149.119 E.17091
G2 X93.041 Y148.466 I-3.209 J-.838 E.02097
G1 X88.468 Y153.039 E.20497
G3 X87.895 Y153.062 I-.401 J-2.856 E.0182
G1 X93.062 Y147.895 E.23161
G2 X93.026 Y147.382 I-2.584 J-.074 E.01634
G1 X87.382 Y153.025 E.25297
G3 X86.914 Y152.944 I.178 J-2.401 E.01509
G1 X92.945 Y146.912 E.27033
G2 X92.828 Y146.479 I-2.223 J.365 E.01425
G1 X86.481 Y152.826 E.28448
G3 X86.079 Y152.678 I.538 J-2.084 E.0136
G1 X92.682 Y146.075 E.29595
G2 X92.51 Y145.697 I-1.975 J.672 E.01318
G1 X85.703 Y152.504 E.30509
G3 X85.35 Y152.307 I.808 J-1.86 E.01283
G1 X92.314 Y145.343 E.31215
G1 X92.091 Y145.016 E.01255
G1 X85.019 Y152.088 E.31701
G1 X84.713 Y151.844 E.01241
G1 X91.847 Y144.71 E.31976
G2 X91.582 Y144.424 I-1.558 J1.176 E.01236
G1 X84.429 Y151.578 E.32064
G3 X84.164 Y151.292 I1.296 J-1.465 E.01236
M73 P24 R24
G1 X91.299 Y144.158 E.31978
G1 X90.993 Y143.914 E.01241
G1 X83.919 Y150.987 E.31705
G1 X83.696 Y150.66 E.01255
G1 X90.662 Y143.695 E.31219
G2 X90.309 Y143.498 I-1.163 J1.664 E.01283
G1 X83.501 Y150.306 E.30516
G3 X83.328 Y149.928 I1.8 J-1.051 E.01318
G1 X89.933 Y143.323 E.29604
G2 X89.531 Y143.175 I-.941 J1.934 E.0136
G1 X83.182 Y149.525 E.2846
G3 X83.065 Y149.091 I2.106 J-.8 E.01425
G1 X89.099 Y143.057 E.27048
G2 X88.631 Y142.975 I-.661 J2.386 E.01508
G1 X82.984 Y148.623 E.25315
G3 X82.947 Y148.11 I2.544 J-.442 E.01633
G1 X88.116 Y142.94 E.23173
G2 X87.544 Y142.962 I-.154 J3.347 E.01819
G1 X82.967 Y147.539 E.20512
G3 X83.069 Y146.887 I3.309 J.183 E.02095
G1 X86.897 Y143.059 E.17156
G1 X86.877 Y143.063 E.00062
G2 X86.087 Y143.319 I.887 J4.082 E.02638
G1 X83.324 Y146.082 E.12385
G3 X84.248 Y144.608 I4.421 J1.745 E.05546
G1 X85.39 Y143.466 E.0512
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X84.248 Y144.608 E-.61384
G1 X84.001 Y144.903 E-.14616
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/23
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z.8 I.009 J1.217 P1  F30000
G1 X164.043 Y144.325 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X167.333 Y142.644 I3.952 J3.675 E.12507
G3 X168.273 Y142.611 I.739 J7.516 E.03123
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X164.003 Y144.369 I-.278 J5.389 E.96647
M204 S250
G1 X163.756 Y144.058 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X167.284 Y142.255 I4.239 J3.942 E.12427
G3 X168.293 Y142.219 I.792 J8.063 E.03103
G3 X163.715 Y144.102 I-.299 J5.781 E.96043
; WIPE_START
M204 S10000
G1 X164.173 Y143.659 E-.24214
G1 X164.625 Y143.299 E-.21938
G1 X165.109 Y142.986 E-.21938
G1 X165.295 Y142.891 E-.07911
; WIPE_END
G1 E-.04 F1800
G1 X163.553 Y150.322 Z1 F30000
G1 X163.482 Y150.626 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43175
G1 F15000
G1 X164.628 Y151.772 E.05133
G2 X166.087 Y152.681 I3.471 J-3.946 E.0547
G1 X163.324 Y149.918 E.12378
G3 X163.069 Y149.114 I4.914 J-1.999 E.02677
G1 X166.896 Y152.941 E.17148
G2 X167.543 Y153.037 I.808 J-3.183 E.02076
G1 X162.967 Y148.462 E.20502
G3 X162.947 Y147.891 I2.843 J-.39 E.01813
G1 X168.112 Y153.057 E.23147
G2 X168.625 Y153.02 I.071 J-2.584 E.01632
G1 X162.983 Y147.378 E.25279
G3 X163.065 Y146.909 I2.381 J.171 E.0151
G1 X169.094 Y152.939 E.27019
G2 X169.529 Y152.824 I-.36 J-2.227 E.01426
G1 X163.181 Y146.476 E.28442
G3 X163.328 Y146.073 I2.09 J.53 E.01362
G1 X169.933 Y152.679 E.29599
G1 X170.312 Y152.508 E.01317
G1 X163.5 Y145.695 E.30525
G3 X163.696 Y145.341 I1.863 J.796 E.01285
G1 X170.661 Y152.306 E.31212
G2 X170.989 Y152.084 I-.95 J-1.75 E.01256
G1 X163.919 Y145.014 E.3168
G3 X164.163 Y144.709 I1.649 J1.071 E.01241
G1 X171.296 Y151.841 E.31959
G2 X171.583 Y151.579 I-1.166 J-1.568 E.01235
G1 X164.428 Y144.423 E.32064
G3 X164.711 Y144.157 I1.474 J1.285 E.01235
G1 X171.848 Y151.294 E.31979
G2 X172.089 Y150.985 I-1.426 J-1.359 E.01244
G1 X165.017 Y143.913 E.31687
G3 X165.348 Y143.694 I1.256 J1.543 E.0126
G1 X172.309 Y150.655 E.31191
G2 X172.508 Y150.304 I-1.656 J-1.172 E.0128
G1 X165.701 Y143.497 E.30503
G3 X166.077 Y143.323 I1.058 J1.791 E.01315
G1 X172.684 Y149.93 E.29607
G1 X172.831 Y149.527 E.01359
G1 X166.479 Y143.175 E.28464
G3 X166.911 Y143.057 I.805 J2.095 E.01421
G1 X172.946 Y149.092 E.27042
G2 X173.025 Y148.622 I-3.193 J-.783 E.01512
G1 X167.378 Y142.975 E.25303
G3 X167.891 Y142.938 I.46 J2.778 E.0163
G1 X173.062 Y148.109 E.23172
G2 X173.041 Y147.538 I-2.864 J-.181 E.01813
G1 X168.464 Y142.961 E.2051
G3 X169.113 Y143.059 I-.214 J3.59 E.02081
G1 X172.939 Y146.886 E.17147
G2 X172.685 Y146.081 I-5.169 J1.194 E.02678
G1 X169.922 Y143.319 E.12377
G3 X171.355 Y144.203 I-1.827 J4.567 E.0536
G3 X172.527 Y145.374 I-45.692 J46.89 E.05248
; WIPE_START
G1 X171.355 Y144.203 E-.62933
G1 X171.086 Y143.988 E-.13067
; WIPE_END
G1 E-.04 F1800
G1 X169.801 Y136.465 Z1 F30000
G1 X163.697 Y100.737 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X167.333 Y98.644 I4.298 J3.263 E.14295
G3 X168.273 Y98.611 I.739 J7.516 E.03123
G3 X163.661 Y100.785 I-.278 J5.389 E.94859
M204 S250
G1 X163.383 Y100.5 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X167.284 Y98.255 I4.611 J3.5 E.14204
G3 X168.293 Y98.219 I.792 J8.063 E.03103
G3 X163.347 Y100.548 I-.299 J5.781 E.94266
; WIPE_START
M204 S10000
G1 X163.76 Y100.062 E-.2423
G1 X164.173 Y99.659 E-.21928
G1 X164.625 Y99.299 E-.21942
G1 X164.799 Y99.186 E-.079
; WIPE_END
G1 E-.04 F1800
G1 X163.482 Y106.626 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43175
G1 F15000
G1 X164.628 Y107.772 E.05135
G2 X166.087 Y108.681 I3.471 J-3.947 E.05468
G1 X163.324 Y105.918 E.12378
G3 X163.069 Y105.114 I4.91 J-1.998 E.02677
G1 X166.896 Y108.941 E.17148
G2 X167.543 Y109.037 I.808 J-3.184 E.02076
G1 X162.967 Y104.462 E.20503
G3 X162.947 Y103.891 I2.842 J-.39 E.01813
G1 X168.118 Y109.063 E.23174
G2 X168.63 Y109.025 I.004 J-3.434 E.01629
G1 X162.983 Y103.378 E.25303
G3 X163.065 Y102.909 I2.382 J.171 E.0151
G1 X169.098 Y108.943 E.27036
G2 X169.53 Y108.825 I-.374 J-2.217 E.01421
G1 X163.181 Y102.476 E.28448
G3 X163.328 Y102.073 I2.089 J.53 E.01362
G1 X169.932 Y108.677 E.29592
G2 X170.308 Y108.503 I-.681 J-1.965 E.01315
G1 X163.5 Y101.695 E.30504
G3 X163.696 Y101.341 I1.863 J.797 E.01285
G1 X170.66 Y108.306 E.31208
G2 X170.992 Y108.087 I-.926 J-1.763 E.0126
G1 X163.919 Y101.014 E.31694
G3 X164.163 Y100.709 I1.649 J1.072 E.01241
G1 X171.298 Y107.843 E.31968
G2 X171.581 Y107.577 I-1.19 J-1.551 E.01235
G1 X164.428 Y100.423 E.32054
G3 X164.711 Y100.157 I1.473 J1.285 E.01235
G1 X171.845 Y107.291 E.31967
G2 X172.09 Y106.986 I-1.4 J-1.374 E.01241
G1 X165.017 Y99.913 E.31694
G3 X165.348 Y99.694 I1.258 J1.546 E.0126
G1 X172.313 Y106.659 E.31208
G2 X172.509 Y106.305 I-1.676 J-1.155 E.01285
G1 X165.701 Y99.497 E.30504
G3 X166.077 Y99.323 I1.057 J1.79 E.01315
G1 X172.681 Y105.927 E.29592
G2 X172.827 Y105.524 I-1.943 J-.934 E.01362
G1 X166.479 Y99.175 E.28448
G3 X166.911 Y99.057 I.804 J2.093 E.01421
G1 X172.944 Y105.09 E.27036
G2 X173.025 Y104.622 I-2.299 J-.64 E.0151
G1 X167.378 Y98.975 E.25303
G3 X167.891 Y98.938 I.46 J2.775 E.01631
G1 X173.062 Y104.109 E.23172
G2 X173.041 Y103.538 I-2.863 J-.181 E.01813
G1 X168.464 Y98.961 E.2051
G3 X169.113 Y99.059 I-.214 J3.589 E.02081
G1 X172.939 Y102.886 E.17147
G2 X172.685 Y102.081 I-5.168 J1.194 E.02677
G1 X169.922 Y99.319 E.12377
G3 X171.355 Y100.203 I-1.828 J4.567 E.0536
G3 X172.527 Y101.374 I-46.369 J47.567 E.05247
; WIPE_START
G1 X171.355 Y100.203 E-.62931
G1 X171.086 Y99.988 E-.13069
; WIPE_END
G1 E-.04 F1800
G1 X163.502 Y100.842 Z1 F30000
G1 X87.601 Y109.383 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X87.333 Y98.644 I.394 J-5.383 E.52736
G3 X88.273 Y98.611 I.739 J7.516 E.03123
G3 X87.661 Y109.387 I-.278 J5.39 E.56428
M204 S250
G1 X87.572 Y109.774 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X87.284 Y98.255 I.422 J-5.774 E.52399
G3 X88.293 Y98.219 I.792 J8.063 E.03103
G3 X87.632 Y109.778 I-.299 J5.781 E.56081
; WIPE_START
M204 S10000
G1 X86.999 Y109.702 E-.24212
G1 X86.436 Y109.574 E-.21933
G1 X85.889 Y109.39 E-.21934
G1 X85.699 Y109.304 E-.07921
; WIPE_END
G1 E-.04 F1800
G1 X83.482 Y106.626 Z1 F30000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43175
G1 F15000
G1 X84.628 Y107.772 E.05135
G2 X86.086 Y108.681 I3.472 J-3.948 E.05469
G1 X83.324 Y105.918 E.12377
G3 X83.069 Y105.114 I4.915 J-1.999 E.02678
G1 X86.896 Y108.941 E.17148
G2 X87.543 Y109.037 I.808 J-3.183 E.02076
G1 X82.968 Y104.462 E.20502
G3 X82.947 Y103.891 I2.841 J-.39 E.01813
G1 X88.112 Y109.057 E.23147
G2 X88.625 Y109.02 I.071 J-2.582 E.01632
G1 X82.983 Y103.378 E.25279
G3 X83.065 Y102.909 I2.383 J.171 E.0151
G1 X89.094 Y108.939 E.27018
G2 X89.529 Y108.824 I-.36 J-2.226 E.01426
G1 X83.181 Y102.476 E.28442
G3 X83.328 Y102.073 I2.089 J.53 E.01362
G1 X89.933 Y108.679 E.29599
G1 X90.312 Y108.508 E.01317
G1 X83.5 Y101.695 E.30525
G3 X83.696 Y101.341 I1.879 J.805 E.01285
G1 X90.661 Y108.306 E.31212
G2 X90.989 Y108.084 I-.948 J-1.747 E.01256
G1 X83.919 Y101.014 E.3168
G3 X84.163 Y100.709 I1.649 J1.072 E.01241
G1 X91.297 Y107.842 E.31964
G2 X91.582 Y107.578 I-1.845 J-2.278 E.01234
G1 X84.428 Y100.423 E.32059
G3 X84.711 Y100.157 I1.474 J1.285 E.01235
G1 X91.845 Y107.291 E.31967
G2 X92.09 Y106.986 I-1.404 J-1.377 E.01241
G1 X85.017 Y99.913 E.31693
G3 X85.348 Y99.694 I1.258 J1.545 E.0126
G1 X92.313 Y106.659 E.31208
G2 X92.509 Y106.305 I-1.685 J-1.161 E.01284
G1 X85.701 Y99.497 E.30504
G3 X86.077 Y99.323 I1.057 J1.79 E.01315
G1 X92.681 Y105.927 E.29592
G2 X92.827 Y105.524 I-1.943 J-.934 E.01362
G1 X86.479 Y99.175 E.28448
G3 X86.911 Y99.057 I.805 J2.094 E.01421
G1 X92.944 Y105.091 E.27036
G2 X93.025 Y104.622 I-2.302 J-.64 E.0151
G1 X87.378 Y98.975 E.25303
G3 X87.891 Y98.937 I.462 J2.797 E.0163
G1 X93.062 Y104.109 E.23172
G2 X93.041 Y103.538 I-2.862 J-.181 E.01813
G1 X88.464 Y98.961 E.2051
G3 X89.113 Y99.059 I-.214 J3.59 E.02081
G1 X92.939 Y102.886 E.17147
G2 X92.685 Y102.081 I-5.169 J1.194 E.02678
G1 X89.922 Y99.319 E.12377
G3 X91.355 Y100.203 I-1.828 J4.568 E.0536
G3 X92.527 Y101.374 I-46.155 J47.354 E.05247
; WIPE_START
G1 X91.355 Y100.203 E-.62931
G1 X91.086 Y99.989 E-.13069
; WIPE_END
G1 E-.04 F1800
G1 X91.242 Y107.619 Z1 F30000
G1 X92.133 Y151.465 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X87.333 Y142.644 I-4.139 J-3.464 E.69689
G3 X88.273 Y142.611 I.739 J7.516 E.03123
G3 X92.172 Y151.418 I-.278 J5.39 E.39476
M204 S250
G1 X92.434 Y151.716 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X87.284 Y142.255 I-4.439 J-3.716 E.69243
G3 X88.293 Y142.219 I.792 J8.063 E.03103
G3 X92.472 Y151.67 I-.299 J5.781 E.39236
; WIPE_START
M204 S10000
G1 X92.249 Y151.938 E-.13255
G1 X91.836 Y152.341 E-.21929
G1 X91.384 Y152.701 E-.21937
G1 X90.967 Y152.971 E-.18878
; WIPE_END
G1 E-.04 F1800
G1 X92.502 Y145.494 Z1 F30000
G1 X92.527 Y145.374 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43175
G1 F15000
G2 X91.355 Y144.203 I-47.328 J46.184 E.05247
G2 X89.922 Y143.319 I-3.261 J3.684 E.0536
G1 X92.685 Y146.081 E.12377
G3 X92.939 Y146.886 I-4.916 J2 E.02678
G1 X89.113 Y143.06 E.17147
G2 X88.464 Y142.961 I-.863 J3.49 E.02081
G1 X93.041 Y147.538 E.2051
G3 X93.062 Y148.109 I-2.842 J.39 E.01813
G1 X87.891 Y142.938 E.23172
G2 X87.378 Y142.975 I-.052 J2.817 E.01631
G1 X93.025 Y148.622 E.25303
G3 X92.944 Y149.091 I-2.384 J-.172 E.0151
G1 X86.911 Y143.057 E.27036
G2 X86.479 Y143.175 I.373 J2.214 E.01421
G1 X92.827 Y149.524 E.28448
G3 X92.681 Y149.927 I-2.09 J-.531 E.01362
G1 X86.077 Y143.323 E.29592
G2 X85.701 Y143.497 I.681 J1.965 E.01315
G1 X92.509 Y150.305 E.30504
G3 X92.313 Y150.659 I-1.866 J-.798 E.01285
G1 X85.348 Y143.694 E.31208
G2 X85.017 Y143.913 I.925 J1.762 E.0126
G1 X92.09 Y150.986 E.31693
G3 X91.845 Y151.291 I-1.646 J-1.069 E.01241
G1 X84.711 Y144.157 E.31967
G2 X84.428 Y144.423 I1.19 J1.551 E.01235
G1 X91.582 Y151.578 E.32059
G3 X91.297 Y151.842 I-2.128 J-2.011 E.01234
G1 X84.163 Y144.709 E.31964
G2 X83.919 Y145.014 I1.403 J1.376 E.01241
G1 X90.989 Y152.084 E.3168
G3 X90.661 Y152.306 I-1.276 J-1.525 E.01256
G1 X83.696 Y145.341 E.31212
G2 X83.5 Y145.695 I1.675 J1.155 E.01285
G1 X90.312 Y152.508 E.30525
G1 X89.933 Y152.679 E.01317
G1 X83.328 Y146.073 E.29599
G2 X83.181 Y146.476 I1.942 J.934 E.01362
G1 X89.529 Y152.824 E.28442
G3 X89.094 Y152.939 I-.794 J-2.112 E.01426
G1 X83.065 Y146.909 E.27018
G2 X82.983 Y147.378 I2.302 J.64 E.0151
G1 X88.625 Y153.02 E.25279
G3 X88.112 Y153.057 I-.442 J-2.546 E.01632
G1 X82.947 Y147.891 E.23147
G2 X82.968 Y148.462 I2.863 J.181 E.01813
G1 X87.543 Y153.037 E.20502
G3 X86.896 Y152.941 I.161 J-3.283 E.02076
G1 X83.069 Y149.114 E.17148
G2 X83.324 Y149.918 I5.171 J-1.195 E.02678
G1 X86.086 Y152.681 E.12377
G3 X84.627 Y151.771 I2.011 J-4.853 E.05472
G1 X83.482 Y150.626 E.05131
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X84.627 Y151.771 E-.61535
G1 X84.923 Y152.011 E-.14465
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 4/23
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1 I.125 J1.211 P1  F30000
G1 X164.636 Y143.776 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F8697
G3 X167.601 Y142.617 I3.359 J4.224 E.1072
G3 X168.333 Y142.614 I.396 J5.832 E.0243
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X164.589 Y143.813 I-.338 J5.386 E.99129
M204 S250
G1 X164.391 Y143.468 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8697
M204 S5000
G3 X167.572 Y142.226 I3.603 J4.532 E.10652
G3 X168.353 Y142.222 I.424 J6.247 E.02401
G3 X164.344 Y143.506 I-.359 J5.778 E.98531
; WIPE_START
G1 F12000
M204 S10000
G1 X164.863 Y143.136 E-.24222
G1 X165.363 Y142.848 E-.21921
G1 X165.889 Y142.61 E-.2194
G1 X166.087 Y142.544 E-.07917
; WIPE_END
G1 E-.04 F1800
G1 X167.743 Y149.995 Z1.2 F30000
G1 X168.417 Y153.026 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8697
G2 X169.99 Y152.638 I-.943 J-7.205 E.05386
G1 X163.368 Y146.016 E.31065
G2 X164.149 Y151.259 I4.623 J1.991 E.18517
G1 X171.261 Y144.147 E.33364
G2 X167.982 Y142.955 I-3.383 J4.2 E.11784
G1 X173.047 Y148.019 E.2376
G3 X172.783 Y149.618 I-7.205 J-.372 E.05386
; WIPE_START
G1 F15476.087
G1 X172.997 Y148.753 E-.33882
G1 X173.047 Y148.019 E-.27923
G1 X172.783 Y147.755 E-.14196
; WIPE_END
G1 E-.04 F1800
G1 X171.367 Y140.255 Z1.2 F30000
G1 X163.864 Y100.526 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F8697
G3 X167.601 Y98.617 I4.13 J3.473 E.14297
G3 X168.333 Y98.614 I.396 J5.827 E.02429
G3 X163.826 Y100.572 I-.338 J5.386 E.95552
M204 S250
G1 X163.563 Y100.274 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8697
M204 S5000
G3 X167.572 Y98.226 I4.43 J3.726 E.14205
G3 X168.353 Y98.222 I.424 J6.241 E.02401
G3 X163.525 Y100.32 I-.359 J5.778 E.94977
; WIPE_START
G1 F12000
M204 S10000
G1 X163.962 Y99.855 E-.24223
G1 X164.395 Y99.473 E-.21942
G1 X164.863 Y99.136 E-.21929
G1 X165.043 Y99.032 E-.07907
; WIPE_END
G1 E-.04 F1800
G1 X172.048 Y102.064 Z1.2 F30000
G1 X172.783 Y102.382 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8697
G3 X173.047 Y103.981 I-6.941 J1.97 E.05386
G1 X167.984 Y109.044 E.23753
G2 X171.261 Y107.853 I-.099 J-5.377 E.11778
G1 X164.153 Y100.745 E.33346
G2 X163.364 Y105.988 I3.869 J3.262 E.18509
G1 X169.99 Y99.362 E.31082
G2 X168.417 Y98.971 I-2.607 J7.125 E.05387
; WIPE_START
G1 F15476.087
G1 X169.128 Y99.077 E-.27317
G1 X169.99 Y99.362 E-.34496
G1 X169.726 Y99.626 E-.14187
; WIPE_END
G1 E-.04 F1800
G1 X162.147 Y100.53 Z1.2 F30000
G1 X87.87 Y109.395 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F8697
G3 X87.601 Y98.617 I.125 J-5.395 E.54519
G3 X88.333 Y98.614 I.396 J5.827 E.02429
G3 X87.93 Y109.396 I-.338 J5.386 E.5533
M204 S250
G1 X87.86 Y109.788 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8697
M204 S5000
G3 X87.572 Y98.226 I.134 J-5.788 E.54177
G3 X88.353 Y98.222 I.424 J6.241 E.02401
G3 X87.92 Y109.789 I-.359 J5.778 E.55005
; WIPE_START
G1 F12000
M204 S10000
G1 X87.284 Y109.745 E-.24205
G1 X86.716 Y109.645 E-.21937
G1 X86.16 Y109.488 E-.21934
G1 X85.966 Y109.412 E-.07925
; WIPE_END
G1 E-.04 F1800
G1 X87.136 Y101.87 Z1.2 F30000
G1 X87.585 Y98.974 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8697
G2 X86.012 Y99.364 I.957 J7.226 E.05386
G1 X92.638 Y105.99 E.31082
G2 X91.852 Y100.74 I-4.761 J-1.971 E.18498
G1 X84.744 Y107.848 E.33346
G2 X88.017 Y109.045 I3.383 J-4.179 E.11772
G1 X82.962 Y103.989 E.23716
G3 X83.224 Y102.39 I7.184 J.356 E.05386
; WIPE_START
G1 F15476.087
G1 X83.012 Y103.248 E-.3355
G1 X82.962 Y103.989 E-.28255
G1 X83.226 Y104.254 E-.14196
; WIPE_END
G1 E-.04 F1800
G1 X84.641 Y111.754 Z1.2 F30000
G1 X92.132 Y151.464 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F8697
G3 X87.601 Y142.617 I-4.138 J-3.464 E.70574
G3 X88.333 Y142.614 I.396 J5.832 E.0243
G3 X92.171 Y151.418 I-.338 J5.386 E.39274
M204 S250
G1 X92.433 Y151.716 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8697
M204 S5000
G3 X87.572 Y142.226 I-4.439 J-3.716 E.70132
G3 X88.353 Y142.222 I.424 J6.247 E.02401
G3 X92.471 Y151.67 I-.359 J5.778 E.3905
; WIPE_START
G1 F12000
M204 S10000
G1 X92.047 Y152.145 E-.24196
G1 X91.614 Y152.527 E-.21936
G1 X91.146 Y152.864 E-.21943
G1 X90.965 Y152.968 E-.07926
; WIPE_END
G1 E-.04 F1800
G1 X83.963 Y149.93 Z1.2 F30000
G1 X83.224 Y149.609 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8697
G3 X82.962 Y148.011 I4.857 J-1.617 E.05396
G1 X88.017 Y142.955 E.23716
G2 X84.743 Y144.151 I.112 J5.387 E.11773
G1 X91.852 Y151.26 E.3335
G2 X92.638 Y146.01 I-3.976 J-3.279 E.18498
G1 X86.014 Y152.634 E.31076
G2 X87.586 Y153.03 I2.615 J-7.071 E.05387
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X86.637 Y152.86 E-.36628
G1 X86.014 Y152.634 E-.2518
G1 X86.278 Y152.37 E-.14193
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/23
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.2 I.122 J1.211 P1  F30000
G1 X163.867 Y144.528 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F8666
G3 X167.87 Y142.604 I4.131 J3.469 E.15184
G3 X168.379 Y142.616 I.135 J5.113 E.01692
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G3 X163.828 Y144.574 I-.381 J5.381 E.95354
M204 S250
G1 X163.566 Y144.276 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8666
M204 S5000
G3 X167.86 Y142.212 I4.431 J3.721 E.15087
G3 X168.408 Y142.225 I.144 J5.497 E.01684
G3 X163.528 Y144.322 I-.41 J5.772 E.94755
; WIPE_START
G1 F12000
M204 S10000
G1 X163.76 Y144.062 E-.13244
G1 X164.173 Y143.659 E-.21935
G1 X164.625 Y143.299 E-.21938
G1 X165.042 Y143.029 E-.18883
; WIPE_END
G1 E-.04 F1800
G1 X170.854 Y147.976 Z1.4 F30000
G1 X172.783 Y149.618 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8666
G2 X173.047 Y148.019 I-6.94 J-1.97 E.05386
G1 X167.983 Y142.955 E.23759
G3 X171.261 Y144.147 I-.104 J5.389 E.11783
G1 X164.153 Y151.255 E.33346
G3 X163.368 Y146.016 I3.98 J-3.274 E.18455
G1 X169.99 Y152.638 E.31065
G3 X168.417 Y153.026 I-2.516 J-6.817 E.05386
; WIPE_START
G1 F15476.087
G1 X169.128 Y152.923 E-.2731
G1 X169.99 Y152.638 E-.34495
G1 X169.726 Y152.374 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X168.869 Y144.79 Z1.4 F30000
G1 X163.867 Y100.528 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F8666
G3 X167.87 Y98.604 I4.131 J3.469 E.15185
G3 X168.379 Y98.616 I.135 J5.111 E.01691
G3 X163.828 Y100.574 I-.381 J5.381 E.95354
M204 S250
G1 X163.566 Y100.276 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8666
M204 S5000
G3 X167.86 Y98.212 I4.431 J3.721 E.15088
G3 X168.408 Y98.225 I.144 J5.495 E.01684
G3 X163.528 Y100.322 I-.41 J5.772 E.94755
; WIPE_START
G1 F12000
M204 S10000
G1 X163.76 Y100.062 E-.13245
G1 X164.173 Y99.659 E-.21935
G1 X164.625 Y99.299 E-.21938
G1 X165.042 Y99.029 E-.18882
; WIPE_END
G1 E-.04 F1800
G1 X168.417 Y98.969 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8666
G3 X169.99 Y99.362 I-1.074 J7.65 E.05387
G1 X163.364 Y105.988 E.31082
G3 X164.153 Y100.745 I4.657 J-1.98 E.18509
G1 X171.261 Y107.853 E.33346
G3 X167.984 Y109.044 I-3.376 J-4.187 E.11778
G1 X173.047 Y103.981 E.23753
G2 X172.783 Y102.382 I-7.205 J.372 E.05386
; WIPE_START
G1 F15476.087
G1 X172.997 Y103.248 E-.33882
G1 X173.047 Y103.981 E-.27923
G1 X172.783 Y104.245 E-.14196
; WIPE_END
G1 E-.04 F1800
G1 X165.164 Y104.7 Z1.4 F30000
G1 X87.334 Y109.35 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F8666
G3 X87.87 Y98.604 I.664 J-5.353 E.53582
G3 X88.379 Y98.616 I.135 J5.111 E.01691
G3 X87.393 Y109.357 I-.381 J5.381 E.56957
M204 S250
G1 X87.285 Y109.739 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8666
M204 S5000
G3 X87.86 Y98.212 I.712 J-5.742 E.53238
M73 P25 R24
G3 X88.408 Y98.225 I.144 J5.495 E.01684
G3 X87.345 Y109.746 I-.41 J5.772 E.56604
; WIPE_START
G1 F12000
M204 S10000
G1 X86.716 Y109.645 E-.24202
G1 X86.16 Y109.488 E-.2193
G1 X85.623 Y109.278 E-.2193
G1 X85.437 Y109.182 E-.07938
; WIPE_END
G1 E-.04 F1800
G1 X83.224 Y102.39 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8666
G2 X82.962 Y103.989 I6.92 J1.955 E.05386
G1 X88.017 Y109.045 E.23716
G3 X84.744 Y107.848 I.11 J-5.376 E.11772
G1 X91.852 Y100.74 E.33346
G3 X92.638 Y105.99 I-3.975 J3.279 E.18498
G1 X86.012 Y99.364 E.31082
G3 X87.585 Y98.974 I2.531 J6.84 E.05386
; WIPE_START
G1 F15476.087
G1 X86.881 Y99.077 E-.27051
G1 X86.012 Y99.364 E-.34755
G1 X86.277 Y99.629 E-.14195
; WIPE_END
G1 E-.04 F1800
G1 X87.133 Y107.213 Z1.4 F30000
G1 X92.131 Y151.463 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F8666
G3 X87.87 Y142.604 I-4.133 J-3.466 E.7141
G3 X88.379 Y142.616 I.135 J5.113 E.01692
G3 X92.169 Y151.417 I-.381 J5.381 E.39129
M204 S250
G1 X92.431 Y151.715 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F8666
M204 S5000
G3 X87.86 Y142.212 I-4.433 J-3.718 E.70952
G3 X88.408 Y142.225 I.144 J5.497 E.01684
G3 X92.469 Y151.668 I-.41 J5.772 E.3889
; WIPE_START
G1 F12000
M204 S10000
G1 X92.047 Y152.145 E-.24193
G1 X91.614 Y152.527 E-.21931
G1 X91.146 Y152.864 E-.21938
G1 X90.965 Y152.968 E-.07938
; WIPE_END
G1 E-.04 F1800
G1 X87.585 Y153.03 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F8666
G3 X86.014 Y152.634 I1.05 J-7.496 E.05387
G1 X92.638 Y146.01 E.31077
G3 X91.852 Y151.26 I-4.761 J1.971 E.18498
G1 X84.743 Y144.151 E.3335
G3 X88.016 Y142.956 I3.384 J4.188 E.11771
G1 X82.962 Y148.011 E.23714
G2 X83.224 Y149.61 I7.182 J-.356 E.05386
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X83.012 Y148.753 E-.33541
G1 X82.962 Y148.011 E-.28263
G1 X83.226 Y147.746 E-.14196
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 6/23
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.4 I-1.184 J-.281 P1  F30000
G1 X81.379 Y155.523 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X78.212 Y152.356 E.14858
G3 X77.513 Y150.848 I1.703 J-1.706 E.0563
G1 X73.692 Y105 E1.52612
G3 X74.09 Y103.458 I2.441 J-.194 E.05384
G1 X80.611 Y93.676 E.38996
G3 X82.618 Y92.602 I2.011 J1.347 E.07862
G1 X173.559 Y92.602 E3.01668
G3 X175.44 Y93.508 I-.01 J2.426 E.07158
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.907 J1.515 E.06045
G1 X178.493 Y150.844 E1.58734
G3 X177.793 Y152.36 I-2.403 J-.19 E.05658
G1 X171.462 Y158.691 E.29697
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06292
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.435 E.06293
G1 X81.422 Y155.566 E.14659
M204 S250
G1 X81.102 Y155.8 F30000
G1 F600
M204 S5000
G1 X77.931 Y152.63 E.14873
G3 X77.122 Y150.885 I1.983 J-1.98 E.06512
G1 X73.301 Y105.028 E1.52644
G3 X73.761 Y103.244 I2.838 J-.219 E.06223
G1 X80.287 Y93.454 E.39028
G3 X82.613 Y92.21 I2.336 J1.571 E.09106
G1 X173.564 Y92.21 E3.01702
G3 X175.743 Y93.259 I-.017 J2.822 E.08291
G1 X182.096 Y101.201 E.33736
G3 X182.7 Y103.171 I-2.22 J1.758 E.06995
G1 X178.883 Y150.88 E1.58766
G3 X178.073 Y152.634 I-2.794 J-.226 E.06545
G1 X171.736 Y158.971 E.29727
G3 X169.759 Y159.79 I-1.992 J-2.013 E.0728
G1 X86.25 Y159.79 E2.77015
G3 X84.272 Y158.971 I.015 J-2.832 E.07281
G1 X81.144 Y155.843 E.14675
; WIPE_START
M204 S10000
G1 X79.73 Y154.429 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.6 I-.771 J.942 P1  F30000
G1 X85.391 Y159.063 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42079
G1 F3000
G1 X169.778 Y159.063 E2.59842
G2 X170.943 Y158.685 I-.042 J-2.115 E.03826
G1 X85.073 Y158.685 E2.64408
G3 X84.639 Y158.307 I1.059 J-1.656 E.01779
G1 X171.374 Y158.307 E2.67073
G1 X171.752 Y157.93 E.01645
G1 X84.26 Y157.929 E2.694
G1 X83.882 Y157.552 E.01646
G1 X172.129 Y157.552 E2.71727
G1 X172.507 Y157.174 E.01645
G1 X83.504 Y157.174 E2.74054
G1 X83.126 Y156.796 E.01646
G1 X172.885 Y156.796 E2.76381
G1 X173.262 Y156.418 E.01645
G1 X82.748 Y156.418 E2.78708
G1 X82.37 Y156.04 E.01646
G1 X173.64 Y156.04 E2.81036
G1 X174.018 Y155.662 E.01645
G1 X81.992 Y155.662 E2.83363
G1 X81.614 Y155.284 E.01646
G1 X174.395 Y155.284 E2.8569
G1 X174.773 Y154.907 E.01645
G1 X81.235 Y154.906 E2.88017
G1 X80.857 Y154.529 E.01646
G1 X175.151 Y154.529 E2.90344
G1 X175.528 Y154.151 E.01645
G1 X80.479 Y154.151 E2.92671
G1 X80.101 Y153.773 E.01646
G1 X175.906 Y153.773 E2.94998
G1 X176.283 Y153.395 E.01645
G1 X79.723 Y153.395 E2.97325
G1 X79.345 Y153.017 E.01646
G1 X86.121 Y153.017 E.20865
G3 X85.328 Y152.639 I2.206 J-5.647 E.02706
G1 X78.967 Y152.639 E.19589
G1 X78.589 Y152.261 E.01646
G1 X84.758 Y152.261 E.18997
G3 X84.364 Y151.93 I3.133 J-4.13 E.01587
G1 X84.316 Y151.883 E.00206
G1 X78.25 Y151.883 E.18678
G3 X78.026 Y151.506 I1.377 J-1.071 E.01356
G1 X83.955 Y151.506 E.18255
G3 X83.655 Y151.128 I3.642 J-3.196 E.01486
G1 X77.899 Y151.128 E.17724
G3 X77.839 Y150.75 I2.315 J-.561 E.01179
G1 X83.408 Y150.75 E.1715
G3 X83.239 Y150.448 I2.944 J-1.848 E.01068
G1 X83.202 Y150.372 E.00258
G1 X77.807 Y150.372 E.16612
G1 X77.776 Y149.994 E.01168
G1 X83.033 Y149.994 E.16188
G3 X82.898 Y149.616 I5.965 J-2.338 E.01235
G1 X77.744 Y149.616 E.1587
G1 X77.713 Y149.238 E.01168
G1 X82.791 Y149.238 E.15636
G1 X82.714 Y148.861 E.01187
G1 X77.681 Y148.861 E.15498
G1 X77.65 Y148.483 E.01168
G1 X82.67 Y148.483 E.15459
G3 X82.649 Y148.105 I1.969 J-.302 E.01167
G1 X77.618 Y148.105 E.15489
M73 P26 R24
G1 X77.587 Y147.727 E.01168
G1 X82.649 Y147.727 E.15588
G1 X82.687 Y147.349 E.01169
G1 X77.555 Y147.349 E.15802
G1 X77.524 Y146.971 E.01168
G1 X82.748 Y146.971 E.16087
G3 X82.81 Y146.67 I3.301 J.519 E.00948
G1 X82.834 Y146.593 E.00246
M73 P26 R23
G1 X77.492 Y146.593 E.16447
G1 X77.461 Y146.215 E.01168
G1 X82.95 Y146.215 E.16903
G3 X83.104 Y145.838 I1.965 J.579 E.01258
G1 X77.429 Y145.838 E.17473
G1 X77.398 Y145.46 E.01168
G1 X83.289 Y145.46 E.18141
M73 P27 R23
G3 X83.512 Y145.082 I2.087 J.974 E.01352
G1 X77.366 Y145.082 E.18923
G1 X77.335 Y144.704 E.01168
G1 X83.779 Y144.704 E.19842
G3 X84.079 Y144.347 I4.384 J3.386 E.01436
G1 X84.101 Y144.326 E.00094
G1 X77.303 Y144.326 E.2093
G1 X77.272 Y143.948 E.01168
M73 P28 R23
G1 X84.495 Y143.948 E.22242
G3 X84.991 Y143.57 I2.217 J2.396 E.01923
G1 X77.24 Y143.57 E.23867
G1 X77.209 Y143.192 E.01168
G1 X85.642 Y143.192 E.25968
G3 X86.66 Y142.815 I2.43 J4.986 E.03348
G1 X77.178 Y142.815 E.29199
G1 X77.146 Y142.437 E.01168
G1 X178.831 Y142.437 E3.13103
G1 X178.861 Y142.059 E.01167
G1 X77.115 Y142.059 E3.13293
G1 X77.083 Y141.681 E.01168
G1 X178.891 Y141.681 E3.13483
G1 X178.921 Y141.303 E.01167
G1 X77.052 Y141.303 E3.13673
G1 X77.02 Y140.925 E.01168
G1 X178.951 Y140.925 E3.13863
G1 X178.982 Y140.548 E.01167
G1 X76.989 Y140.547 E3.14053
G1 X76.957 Y140.17 E.01168
M73 P29 R23
G1 X179.012 Y140.17 E3.14243
G1 X179.042 Y139.792 E.01167
G1 X76.926 Y139.792 E3.14433
G1 X76.894 Y139.414 E.01168
G1 X179.072 Y139.414 E3.14623
G1 X179.103 Y139.036 E.01167
G1 X76.863 Y139.036 E3.14813
G1 X76.831 Y138.658 E.01168
G1 X179.133 Y138.658 E3.15003
G1 X179.163 Y138.28 E.01167
G1 X76.8 Y138.28 E3.15193
G1 X76.768 Y137.902 E.01168
G1 X179.193 Y137.902 E3.15383
G1 X179.223 Y137.525 E.01167
M73 P29 R22
G1 X76.737 Y137.524 E3.15573
G1 X76.705 Y137.147 E.01168
G1 X179.254 Y137.147 E3.15763
G1 X179.284 Y136.769 E.01167
G1 X76.674 Y136.769 E3.15953
G1 X76.642 Y136.391 E.01168
G1 X179.314 Y136.391 E3.16143
G1 X179.344 Y136.013 E.01167
M73 P30 R22
G1 X76.611 Y136.013 E3.16333
G1 X76.579 Y135.635 E.01168
G1 X179.374 Y135.635 E3.16523
G1 X179.405 Y135.257 E.01167
G1 X76.548 Y135.257 E3.16713
G1 X76.516 Y134.879 E.01168
G1 X179.435 Y134.879 E3.16903
G1 X179.465 Y134.502 E.01167
G1 X76.485 Y134.501 E3.17093
G1 X76.453 Y134.124 E.01168
G1 X179.495 Y134.124 E3.17283
G1 X179.525 Y133.746 E.01167
G1 X76.422 Y133.746 E3.17473
G1 X76.39 Y133.368 E.01168
G1 X179.556 Y133.368 E3.17663
G1 X179.586 Y132.99 E.01167
G1 X76.359 Y132.99 E3.17853
G1 X76.327 Y132.612 E.01168
G1 X179.616 Y132.612 E3.18043
G1 X179.646 Y132.234 E.01167
G1 X76.296 Y132.234 E3.18233
G1 X76.264 Y131.856 E.01168
G1 X179.676 Y131.856 E3.18423
G1 X179.707 Y131.479 E.01167
G1 X76.233 Y131.479 E3.18613
G1 X76.201 Y131.101 E.01168
G1 X179.737 Y131.101 E3.18803
G1 X179.767 Y130.723 E.01167
G1 X76.17 Y130.723 E3.18993
G1 X76.138 Y130.345 E.01168
G1 X179.797 Y130.345 E3.19183
G1 X179.827 Y129.967 E.01167
G1 X76.107 Y129.967 E3.19373
G1 X76.075 Y129.589 E.01168
G1 X179.858 Y129.589 E3.19563
G1 X179.888 Y129.211 E.01167
G1 X76.044 Y129.211 E3.19752
G1 X76.012 Y128.833 E.01168
G1 X179.918 Y128.834 E3.19942
G1 X179.948 Y128.456 E.01167
G1 X75.981 Y128.456 E3.20132
G1 X75.949 Y128.078 E.01168
G1 X179.979 Y128.078 E3.20322
G1 X180.009 Y127.7 E.01167
G1 X75.918 Y127.7 E3.20512
G1 X75.886 Y127.322 E.01168
G1 X180.039 Y127.322 E3.20702
G1 X180.069 Y126.944 E.01167
G1 X75.855 Y126.944 E3.20892
G1 X75.823 Y126.566 E.01168
G1 X180.099 Y126.566 E3.21082
G1 X180.13 Y126.188 E.01167
G1 X75.792 Y126.188 E3.21272
G1 X75.76 Y125.81 E.01168
G1 X180.16 Y125.811 E3.21462
G1 X180.19 Y125.433 E.01167
G1 X75.729 Y125.433 E3.21652
G1 X75.698 Y125.055 E.01168
G1 X180.22 Y125.055 E3.21842
G1 X180.25 Y124.677 E.01167
G1 X75.666 Y124.677 E3.22032
G1 X75.635 Y124.299 E.01168
G1 X180.281 Y124.299 E3.22222
G1 X180.311 Y123.921 E.01167
G1 X75.603 Y123.921 E3.22412
G1 X75.572 Y123.543 E.01168
G1 X180.341 Y123.543 E3.22602
G1 X180.371 Y123.165 E.01167
G1 X75.54 Y123.165 E3.22792
G1 X75.509 Y122.787 E.01168
G1 X180.401 Y122.788 E3.22982
G1 X180.432 Y122.41 E.01167
G1 X75.477 Y122.41 E3.23172
G1 X75.446 Y122.032 E.01168
G1 X180.462 Y122.032 E3.23362
G1 X180.492 Y121.654 E.01167
M73 P31 R22
G1 X75.414 Y121.654 E3.23552
G1 X75.383 Y121.276 E.01168
G1 X180.522 Y121.276 E3.23742
G1 X180.552 Y120.898 E.01167
G1 X75.351 Y120.898 E3.23932
G1 X75.32 Y120.52 E.01168
G1 X180.583 Y120.52 E3.24122
G1 X180.613 Y120.143 E.01167
G1 X75.288 Y120.142 E3.24312
G1 X75.257 Y119.765 E.01168
G1 X180.643 Y119.765 E3.24502
G1 X180.673 Y119.387 E.01167
G1 X75.225 Y119.387 E3.24692
G1 X75.194 Y119.009 E.01168
G1 X180.703 Y119.009 E3.24882
G1 X180.734 Y118.631 E.01167
G1 X75.162 Y118.631 E3.25072
G1 X75.131 Y118.253 E.01168
M73 P32 R22
G1 X180.764 Y118.253 E3.25262
G1 X180.794 Y117.875 E.01167
G1 X75.099 Y117.875 E3.25452
G1 X75.068 Y117.497 E.01168
G1 X180.824 Y117.497 E3.25642
G1 X180.855 Y117.12 E.01167
G1 X75.036 Y117.119 E3.25832
G1 X75.005 Y116.742 E.01168
G1 X180.885 Y116.742 E3.26022
G1 X180.915 Y116.364 E.01167
G1 X74.973 Y116.364 E3.26212
G1 X74.942 Y115.986 E.01168
M73 P32 R21
G1 X180.945 Y115.986 E3.26402
G1 X180.975 Y115.608 E.01167
G1 X74.91 Y115.608 E3.26592
G1 X74.879 Y115.23 E.01168
G1 X181.006 Y115.23 E3.26782
G1 X181.036 Y114.852 E.01167
G1 X74.847 Y114.852 E3.26971
G1 X74.816 Y114.474 E.01168
M73 P33 R21
G1 X181.066 Y114.474 E3.27161
G1 X181.096 Y114.097 E.01167
G1 X74.784 Y114.096 E3.27351
G1 X74.753 Y113.719 E.01168
G1 X181.126 Y113.719 E3.27541
G1 X181.157 Y113.341 E.01167
G1 X74.721 Y113.341 E3.27731
G1 X74.69 Y112.963 E.01168
G1 X181.187 Y112.963 E3.27921
G1 X181.217 Y112.585 E.01167
G1 X74.658 Y112.585 E3.28111
G1 X74.627 Y112.207 E.01168
G1 X181.247 Y112.207 E3.28301
G1 X181.277 Y111.829 E.01167
G1 X74.595 Y111.829 E3.28491
G1 X74.564 Y111.451 E.01168
G1 X181.308 Y111.452 E3.28681
G1 X181.338 Y111.074 E.01167
M73 P34 R21
G1 X74.532 Y111.074 E3.28871
G1 X74.501 Y110.696 E.01168
G1 X181.368 Y110.696 E3.29061
G1 X181.398 Y110.318 E.01167
G1 X74.469 Y110.318 E3.29251
G1 X74.438 Y109.94 E.01168
G1 X181.599 Y109.94 E3.29965
; WIPE_START
G1 X179.599 Y109.94 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.6 I.896 J-.823 P1  F30000
G1 X172.723 Y102.459 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X172.968 Y104.06 I-6.681 J1.84 E.05386
G1 X168.061 Y108.966 E.23017
G2 X171.204 Y107.797 I-.054 J-4.951 E.11349
G1 X164.209 Y100.801 E.32816
G1 X164.163 Y100.857 E.0024
G2 X163.424 Y105.928 I3.865 J3.152 E.17853
M73 P35 R21
G1 X169.904 Y99.414 E.3048
G2 X168.353 Y99.045 I-1.904 J4.559 E.05313
G1 X166.693 Y98.982 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42079
G1 F3000
G1 X89.877 Y98.982 E2.36527
G3 X90.691 Y99.36 I-2.843 J7.184 E.02763
G1 X165.316 Y99.361 E2.29782
G2 X164.76 Y99.738 I1.683 J3.085 E.02071
G1 X91.249 Y99.737 E2.26351
G3 X91.692 Y100.115 I-1.73 J2.475 E.01795
G1 X164.317 Y100.115 E2.23624
G2 X163.956 Y100.493 I1.781 J2.064 E.01612
M73 P35 R20
G1 X92.053 Y100.493 E2.21399
G3 X92.353 Y100.871 I-1.828 J1.759 E.01488
G1 X163.656 Y100.871 E2.19552
G2 X163.404 Y101.249 I1.94 J1.564 E.01399
G1 X92.604 Y101.249 E2.18004
G1 X92.81 Y101.627 E.01325
M73 P36 R20
G1 X163.198 Y101.627 E2.16737
G2 X163.033 Y102.005 I7.836 J3.647 E.0127
G1 X92.975 Y102.005 E2.1572
G3 X93.11 Y102.383 I-1.908 J.894 E.01237
G1 X162.899 Y102.383 E2.1489
G2 X162.791 Y102.76 I1.96 J.763 E.01212
G1 X93.218 Y102.76 E2.14227
G1 X93.294 Y103.138 E.01187
G1 X162.715 Y103.138 E2.13757
G2 X162.67 Y103.516 I1.868 J.41 E.01173
G1 X93.338 Y103.516 E2.13485
G3 X93.36 Y103.894 I-1.969 J.302 E.01167
G1 X162.645 Y103.894 E2.13339
G2 X162.656 Y104.272 I2.526 J.116 E.01165
G1 X93.359 Y104.272 E2.13374
G1 X93.322 Y104.65 E.01169
G1 X162.686 Y104.65 E2.13584
G1 X162.743 Y105.028 E.01177
M73 P37 R20
G1 X93.261 Y105.028 E2.13948
G3 X93.176 Y105.405 I-2.068 J-.268 E.01194
G1 X162.836 Y105.406 E2.14495
G2 X162.954 Y105.783 I2.036 J-.43 E.01221
G1 X93.059 Y105.783 E2.15219
G1 X93.046 Y105.826 E.00138
G3 X92.905 Y106.161 I-23.82 J-9.781 E.01118
G1 X163.101 Y106.161 E2.16143
G1 X163.283 Y106.539 E.01291
G1 X92.72 Y106.539 E2.17275
G3 X92.498 Y106.917 I-2.091 J-.976 E.01352
G1 X163.51 Y106.917 E2.1866
G2 X163.782 Y107.295 I2.123 J-1.237 E.01434
G1 X92.231 Y107.295 E2.20316
G1 X92.104 Y107.447 E.0061
G3 X91.909 Y107.673 I-1.424 J-1.028 E.00919
G1 X164.106 Y107.673 E2.22306
G2 X164.5 Y108.051 I3.246 J-2.991 E.01682
M73 P38 R20
G1 X91.515 Y108.051 E2.24734
G1 X91.257 Y108.256 E.01014
G3 X91.019 Y108.428 I-1.033 J-1.176 E.00907
G1 X164.989 Y108.429 E2.27766
G2 X165.635 Y108.806 I3.662 J-5.515 E.02304
G1 X90.369 Y108.806 E2.31756
G3 X89.353 Y109.184 I-2.308 J-4.651 E.03343
G1 X167.872 Y109.184 E2.41772
; WIPE_START
G1 X165.872 Y109.184 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X169.422 Y102.428 Z1.6 F30000
G1 X174.41 Y92.936 Z1.6
G1 Z1.2
G1 E.8 F1800
M73 P38 R19
G1 F3000
G1 X82.617 Y92.936 E2.82645
G2 X81.423 Y93.314 I.031 J2.174 E.03912
G1 X174.742 Y93.314 E2.87345
M73 P39 R19
G3 X175.157 Y93.692 I-1.089 J1.613 E.01734
G1 X81.028 Y93.692 E2.89838
G2 X80.749 Y94.069 I1.797 J1.621 E.0145
G1 X175.462 Y94.069 E2.91637
G1 X175.764 Y94.447 E.0149
G1 X80.497 Y94.447 E2.93343
G1 X80.245 Y94.825 E.01398
G1 X176.066 Y94.825 E2.95049
G1 X176.368 Y95.203 E.0149
G1 X79.993 Y95.203 E2.96755
G1 X79.741 Y95.581 E.01398
G1 X176.671 Y95.581 E2.98461
G1 X176.973 Y95.959 E.0149
G1 X79.489 Y95.959 E3.00167
G1 X79.237 Y96.337 E.01398
G1 X177.275 Y96.337 E3.01873
G1 X177.577 Y96.715 E.0149
G1 X78.986 Y96.714 E3.03579
G1 X78.734 Y97.092 E.01398
G1 X177.879 Y97.092 E3.05285
G1 X178.181 Y97.47 E.0149
G1 X78.482 Y97.47 E3.06991
G1 X78.23 Y97.848 E.01398
G1 X178.483 Y97.848 E3.08697
G1 X178.785 Y98.226 E.0149
G1 X77.978 Y98.226 E3.10403
G1 X77.726 Y98.604 E.01398
G1 X179.088 Y98.604 E3.12109
G1 X179.39 Y98.982 E.0149
G1 X169.878 Y98.982 E.29289
G1 X170.048 Y99.049 E.00562
G3 X170.691 Y99.36 I-2.161 J5.291 E.02203
G1 X179.692 Y99.36 E.27715
G1 X179.994 Y99.738 E.0149
G1 X171.249 Y99.738 E.26926
G1 X171.31 Y99.786 E.00239
M73 P40 R19
G3 X171.692 Y100.115 I-1.519 J2.147 E.01556
G1 X180.296 Y100.115 E.26493
G1 X180.598 Y100.493 E.0149
G1 X172.053 Y100.493 E.26311
G3 X172.353 Y100.871 I-1.831 J1.761 E.01488
G1 X180.9 Y100.871 E.26318
G1 X181.202 Y101.249 E.0149
G1 X172.605 Y101.249 E.26474
G1 X172.81 Y101.627 E.01325
G1 X181.505 Y101.627 E.26771
G3 X181.749 Y102.005 I-1.208 J1.048 E.0139
G1 X172.975 Y102.005 E.27015
G3 X173.11 Y102.383 I-1.912 J.895 E.01237
G1 X181.902 Y102.383 E.27071
G3 X181.965 Y102.761 I-1.103 J.38 E.01185
G1 X173.218 Y102.76 E.26935
G1 X173.294 Y103.138 E.01187
G1 X181.972 Y103.138 E.26721
G1 X181.942 Y103.516 E.01167
G1 X173.338 Y103.516 E.26492
G3 X173.36 Y103.894 I-1.969 J.302 E.01167
G1 X181.912 Y103.894 E.26332
G1 X181.882 Y104.272 E.01167
G1 X173.359 Y104.272 E.26241
G1 X173.322 Y104.65 E.01169
G1 X181.851 Y104.65 E.26264
G1 X181.821 Y105.028 E.01167
G1 X173.261 Y105.028 E.26359
M73 P41 R19
G1 X173.254 Y105.062 E.00109
G3 X173.175 Y105.406 I-1.89 J-.25 E.01085
G1 X181.791 Y105.406 E.26528
G1 X181.761 Y105.783 E.01167
G1 X173.059 Y105.783 E.26794
G1 X173.046 Y105.827 E.0014
G3 X172.905 Y106.161 I-33.78 J-13.96 E.01117
G1 X181.731 Y106.161 E.27174
G1 X181.7 Y106.539 E.01167
G1 X172.72 Y106.539 E.27652
G3 X172.498 Y106.917 I-2.092 J-.976 E.01352
G1 X181.67 Y106.917 E.28244
G1 X181.64 Y107.295 E.01167
G1 X172.231 Y107.295 E.28972
G3 X171.909 Y107.673 I-2.049 J-1.419 E.01531
G1 X181.61 Y107.673 E.2987
G1 X181.579 Y108.051 E.01167
G1 X171.515 Y108.051 E.30991
G3 X171.019 Y108.429 I-2.137 J-2.29 E.01923
G1 X181.549 Y108.429 E.32425
G1 X181.519 Y108.806 E.01167
G1 X170.369 Y108.806 E.34334
G1 X170.217 Y108.884 E.00524
G3 X169.353 Y109.184 I-2.138 J-4.762 E.02821
G1 X181.489 Y109.184 E.37369
G1 X181.459 Y109.562 E.01167
G1 X74.406 Y109.562 E3.29631
G1 X74.375 Y109.184 E.01168
G1 X86.65 Y109.184 E.37796
G3 X85.635 Y108.806 I1.482 J-5.534 E.0334
G1 X74.343 Y108.806 E.34767
M73 P41 R18
G1 X74.312 Y108.428 E.01168
G1 X84.989 Y108.428 E.32877
G3 X84.5 Y108.051 I1.705 J-2.712 E.01906
G1 X74.28 Y108.051 E.31468
M73 P42 R18
G1 X74.249 Y107.673 E.01168
G1 X84.106 Y107.673 E.30352
G3 X83.781 Y107.295 I2.345 J-2.344 E.01536
G1 X74.218 Y107.295 E.29449
G1 X74.186 Y106.917 E.01168
G1 X83.51 Y106.917 E.28711
G3 X83.283 Y106.539 I2.145 J-1.549 E.0136
G1 X74.155 Y106.539 E.28107
G1 X74.123 Y106.161 E.01168
G1 X83.101 Y106.161 E.27644
G1 X83.067 Y106.09 E.00242
G3 X82.954 Y105.783 I3.097 J-1.31 E.01008
G1 X74.092 Y105.783 E.27289
G1 X74.06 Y105.405 E.01168
G1 X82.831 Y105.405 E.27009
G3 X82.748 Y105.028 I2.333 J-.712 E.01193
G1 X74.029 Y105.028 E.26849
G3 X74.024 Y104.65 I6.238 J-.272 E.01164
G1 X82.687 Y104.65 E.26676
G1 X82.649 Y104.272 E.01169
M73 P43 R18
G1 X74.089 Y104.272 E.26358
G3 X74.228 Y103.894 I1.378 J.292 E.01244
G1 X82.649 Y103.894 E.25928
G3 X82.67 Y103.516 I2.775 J-.03 E.01166
G1 X74.451 Y103.516 E.25309
G1 X74.703 Y103.138 E.01398
G1 X82.715 Y103.138 E.24669
G1 X82.791 Y102.76 E.01187
G1 X74.955 Y102.76 E.24129
G1 X75.207 Y102.383 E.01398
G1 X82.899 Y102.383 E.23684
G3 X83.033 Y102.005 I2.042 J.516 E.01237
G1 X75.459 Y102.005 E.23324
G1 X75.711 Y101.627 E.01398
G1 X83.198 Y101.627 E.23056
G1 X83.404 Y101.249 E.01325
G1 X75.963 Y101.249 E.22914
G1 X76.214 Y100.871 E.01398
G1 X83.656 Y100.871 E.22913
G3 X83.956 Y100.493 I2.132 J1.385 E.01488
G1 X76.466 Y100.493 E.23061
G1 X76.718 Y100.115 E.01398
G1 X84.317 Y100.115 E.23397
G3 X84.76 Y99.737 I2.18 J2.106 E.01795
G1 X76.97 Y99.737 E.23985
G1 X77.222 Y99.36 E.01398
G1 X85.323 Y99.356 E.24945
G3 X86.132 Y98.982 I2.313 J3.934 E.02747
G1 X77.27 Y98.982 E.27286
; WIPE_START
G1 X79.27 Y98.982 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.6 I-.01 J1.217 P1  F30000
G1 X87.649 Y99.049 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X86.074 Y99.426 I.272 J4.626 E.05402
G1 X92.578 Y105.929 E.30511
G1 X92.602 Y105.87 E.00213
G2 X91.796 Y100.797 I-4.6 J-1.87 E.17912
G1 X84.8 Y107.792 E.32818
G1 X84.869 Y107.853 E.00304
G2 X87.935 Y108.963 I3.126 J-3.842 E.11025
G1 X83.041 Y104.069 E.22961
G3 X83.283 Y102.467 I4.982 J-.066 E.05398
; WIPE_START
G1 X83.09 Y103.259 E-.30977
G1 X83.041 Y104.069 E-.30826
G1 X83.305 Y104.333 E-.14198
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.6 I-1.217 J-.001 P1  F30000
G1 X83.283 Y149.533 Z1.6
G1 Z1.2
G1 E.8 F1800
G1 F15476.087
G3 X83.041 Y147.931 I6.683 J-1.829 E.05386
G1 X87.939 Y143.033 E.22978
G1 X87.877 Y143.032 E.00206
G2 X84.8 Y144.207 I.158 J5.031 E.11131
G1 X91.796 Y151.203 E.32821
G1 X91.835 Y151.157 E.002
G2 X92.578 Y146.071 I-3.961 J-3.176 E.1788
G1 X86.074 Y152.574 E.3051
G2 X87.649 Y152.956 I2.009 J-4.849 E.05398
; WIPE_START
G1 X86.658 Y152.784 E-.38214
G1 X86.074 Y152.574 E-.2359
G1 X86.338 Y152.31 E-.14197
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.6 I-.011 J1.217 P1  F30000
G1 X166.681 Y153.017 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42079
G1 F3000
G1 X89.88 Y153.017 E2.3648
G2 X90.693 Y152.639 I-2.84 J-7.17 E.02761
G1 X165.329 Y152.639 E2.29816
G3 X164.758 Y152.261 I2.464 J-4.339 E.02108
G1 X91.251 Y152.261 E2.26342
G2 X91.693 Y151.884 I-1.729 J-2.473 E.01795
G1 X164.316 Y151.884 E2.23617
G3 X163.955 Y151.506 I4.124 J-4.302 E.0161
G1 X92.054 Y151.506 E2.21393
G2 X92.354 Y151.128 I-3.506 J-3.089 E.01486
G1 X163.655 Y151.128 E2.19548
G3 X163.408 Y150.75 I6.359 J-4.419 E.0139
G1 X92.605 Y150.75 E2.18015
G1 X92.811 Y150.372 E.01325
G1 X163.202 Y150.372 E2.16747
G3 X163.033 Y149.994 I3.681 J-1.877 E.01276
G1 X92.976 Y149.994 E2.15717
G2 X93.11 Y149.616 I-1.908 J-.893 E.01237
G1 X162.898 Y149.616 E2.14888
G3 X162.793 Y149.238 I3.745 J-1.246 E.01208
G1 X93.218 Y149.238 E2.14233
G1 X93.294 Y148.861 E.01187
G1 X162.714 Y148.861 E2.13755
G3 X162.67 Y148.483 I2.039 J-.43 E.01173
G1 X93.338 Y148.483 E2.13484
G2 X93.36 Y148.105 I-1.966 J-.302 E.01167
G1 X162.649 Y148.105 E2.13351
G3 X162.649 Y147.727 I4.091 J-.181 E.01164
G1 X93.359 Y147.727 E2.13355
G1 X93.322 Y147.349 E.01169
G1 X162.687 Y147.349 E2.13588
G3 X162.748 Y146.971 I1.922 J.118 E.01181
G1 X93.26 Y146.971 E2.13965
G2 X93.198 Y146.669 I-3.002 J.458 E.00952
G1 X93.175 Y146.593 E.00243
G1 X162.834 Y146.593 E2.1449
G1 X162.95 Y146.216 E.01218
G1 X93.059 Y146.215 E2.15208
G2 X92.905 Y145.838 I-2.175 J.665 E.01258
G1 X163.104 Y145.838 E2.16154
G3 X163.289 Y145.46 I1.983 J.739 E.01298
G1 X92.719 Y145.46 E2.17297
G2 X92.497 Y145.082 I-2.088 J.975 E.01352
G1 X163.512 Y145.082 E2.18667
G3 X163.736 Y144.755 I3.268 J1.999 E.01219
G1 X163.779 Y144.704 E.00207
M73 P44 R18
G1 X92.23 Y144.704 E2.2031
G2 X91.93 Y144.348 I-4.548 J3.523 E.01435
G1 X91.908 Y144.326 E.00095
G1 X164.101 Y144.326 E2.22293
G3 X164.463 Y143.974 I3.871 J3.619 E.01555
G1 X164.495 Y143.948 E.00128
G1 X91.513 Y143.948 E2.24723
G2 X91.017 Y143.57 I-2.211 J2.388 E.01923
G1 X164.991 Y143.57 E2.27778
G3 X165.642 Y143.193 I2.213 J3.062 E.02321
G1 X90.366 Y143.192 E2.31786
G2 X89.349 Y142.815 I-2.471 J5.096 E.03348
G1 X167.801 Y142.815 E2.41568
G1 X168.353 Y152.951 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X169.929 Y152.577 I-.811 J-6.918 E.05386
G1 X163.429 Y146.077 E.30493
G1 X163.404 Y146.135 E.00208
G2 X164.209 Y151.199 I4.602 J1.865 E.17874
G1 X171.204 Y144.203 E.32817
G1 X171.025 Y144.06 E.0076
G2 X168.064 Y143.036 I-3.018 J3.933 E.10574
G1 X172.968 Y147.94 E.23005
G3 X172.723 Y149.541 I-5.009 J.054 E.05397
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
G1 X172.919 Y148.741 E-.3131
G1 X172.968 Y147.94 E-.30492
G1 X172.704 Y147.676 E-.14198
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.6 I-.957 J.752 P1  F30000
G1 X176.901 Y153.017 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42079
G1 F3000
G1 X169.88 Y153.017 E.21619
G2 X170.693 Y152.639 I-2.803 J-7.091 E.02761
G1 X177.039 Y152.639 E.19541
G1 X177.416 Y152.261 E.01645
G1 X171.25 Y152.261 E.18986
G2 X171.693 Y151.884 I-2.475 J-3.347 E.01793
G1 X177.759 Y151.884 E.18677
G2 X177.983 Y151.506 I-2.085 J-1.492 E.01354
G1 X172.054 Y151.506 E.18255
G2 X172.354 Y151.128 I-1.826 J-1.757 E.01488
G1 X178.111 Y151.128 E.17727
G2 X178.166 Y150.75 I-5.907 J-1.058 E.01176
G1 X172.605 Y150.75 E.17123
G1 X172.811 Y150.372 E.01325
G1 X178.196 Y150.372 E.16582
G1 X178.226 Y149.994 E.01167
G1 X172.976 Y149.994 E.16168
G2 X173.11 Y149.616 I-1.909 J-.893 E.01237
G1 X178.257 Y149.616 E.15846
G1 X178.287 Y149.239 E.01167
G1 X173.218 Y149.239 E.15608
G1 X173.294 Y148.861 E.01187
G1 X178.317 Y148.861 E.15466
G1 X178.347 Y148.483 E.01167
G1 X173.338 Y148.483 E.15423
G2 X173.36 Y148.105 I-1.967 J-.302 E.01167
G1 X178.378 Y148.105 E.1545
G1 X178.408 Y147.727 E.01167
G1 X173.359 Y147.727 E.15545
G1 X173.322 Y147.349 E.01169
G1 X178.438 Y147.349 E.15754
G1 X178.468 Y146.971 E.01167
G1 X173.26 Y146.971 E.16036
G2 X173.198 Y146.669 I-3.201 J.498 E.00951
G1 X173.175 Y146.593 E.00243
G1 X178.498 Y146.593 E.16391
G1 X178.529 Y146.216 E.01167
G1 X173.059 Y146.216 E.16843
G2 X172.905 Y145.838 I-2.176 J.665 E.01258
M73 P44 R17
G1 X178.559 Y145.838 E.17409
G1 X178.589 Y145.46 E.01167
M73 P45 R17
G1 X172.719 Y145.46 E.18074
G2 X172.497 Y145.082 I-2.087 J.975 E.01352
G1 X178.619 Y145.082 E.18852
G1 X178.649 Y144.704 E.01167
G1 X172.23 Y144.704 E.19766
G2 X171.929 Y144.346 I-3.527 J2.665 E.01441
G1 X171.908 Y144.326 E.00089
G1 X178.68 Y144.326 E.20851
G1 X178.71 Y143.948 E.01167
G1 X171.514 Y143.948 E.22158
G2 X171.017 Y143.57 I-3.311 J3.833 E.01922
G1 X178.74 Y143.57 E.23779
G1 X178.77 Y143.193 E.01167
G1 X170.367 Y143.193 E.25876
G2 X169.349 Y142.815 I-2.43 J4.985 E.03348
G1 X178.971 Y142.815 E.29627
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X176.971 Y142.815 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/23
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.6 I1.215 J-.074 P1  F30000
G1 X173.909 Y92.639 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X174.153 Y92.677 E.00819
G3 X175.44 Y93.508 I-.595 J2.332 E.05171
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.907 J1.515 E.06044
G1 X178.493 Y150.844 E1.58733
G3 X177.793 Y152.36 I-2.403 J-.189 E.05657
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.462 Y158.691 E.29698
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06292
M73 P46 R17
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.691 I.008 J-2.435 E.06292
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.703 J-1.706 E.05631
G1 X73.692 Y105.001 E1.52609
G3 X74.09 Y103.458 I2.447 J-.193 E.05386
G1 X80.611 Y93.676 E.38996
G3 X82.618 Y92.602 I2.012 J1.347 E.07862
G1 X173.682 Y92.605 E3.02076
G1 X173.85 Y92.631 E.00564
M204 S250
G1 X173.969 Y92.24 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X173.978 Y92.241 E.00026
G3 X175.743 Y93.259 I-.42 J2.768 E.06408
G1 X182.096 Y101.201 E.3125
G3 X182.7 Y103.17 I-2.22 J1.758 E.06479
G1 X178.883 Y150.88 E1.47065
G3 X178.074 Y152.634 I-2.794 J-.225 E.06062
G1 X171.736 Y158.971 E.27539
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.273 Y158.971 I.015 J-2.832 E.06744
G1 X77.932 Y152.63 E.27554
G3 X77.122 Y150.885 I1.983 J-1.98 E.06034
G1 X73.301 Y105.028 E1.41394
G3 X73.761 Y103.244 I2.845 J-.218 E.05765
G1 X80.287 Y93.455 E.36152
G3 X82.613 Y92.21 I2.337 J1.571 E.08435
G1 X173.701 Y92.214 E2.79889
G1 X173.909 Y92.234 E.00643
; WIPE_START
M204 S10000
G1 X173.978 Y92.241 E-.02603
G1 X174.25 Y92.296 E-.10558
G1 X174.644 Y92.428 E-.15805
G1 X174.895 Y92.549 E-.10555
G1 X175.132 Y92.693 E-.10558
G1 X175.353 Y92.861 E-.10541
G1 X175.557 Y93.049 E-.10551
G1 X175.641 Y93.144 E-.04829
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I-1.148 J.404 P1  F30000
G1 X176.194 Y94.713 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42122
G1 F15000
G1 X175.029 Y93.549 E.05077
G2 X173.924 Y92.979 I-1.417 J1.391 E.03898
G1 X177.244 Y96.299 E.14473
G1 X179.378 Y98.967 E.10534
G1 X173.349 Y92.938 E.26284
G1 X172.814 Y92.938 E.01649
G1 X181.512 Y101.636 E.37919
G3 X181.946 Y102.605 I-1.44 J1.226 E.03317
G1 X172.279 Y92.938 E.42143
G1 X171.744 Y92.938 E.01649
G1 X181.97 Y103.164 E.4458
G1 X181.931 Y103.66 E.01532
G1 X171.209 Y92.938 E.4674
G1 X170.674 Y92.938 E.01649
G1 X181.891 Y104.155 E.489
G1 X181.851 Y104.651 E.01532
G1 X170.139 Y92.938 E.5106
G1 X169.604 Y92.938 E.01649
G1 X181.812 Y105.146 E.5322
G1 X181.772 Y105.641 E.01532
G1 X169.069 Y92.938 E.55379
G1 X168.534 Y92.938 E.01649
G1 X181.732 Y106.137 E.57539
G1 X181.693 Y106.632 E.01532
G1 X167.999 Y92.938 E.59699
G1 X167.464 Y92.938 E.01649
G1 X181.653 Y107.128 E.61859
G1 X181.614 Y107.623 E.01532
G1 X166.929 Y92.938 E.64019
G1 X166.394 Y92.938 E.01649
G1 X181.574 Y108.118 E.66178
G1 X181.534 Y108.614 E.01532
G1 X165.859 Y92.938 E.68338
G1 X165.324 Y92.938 E.01649
G1 X181.495 Y109.109 E.70498
G1 X181.455 Y109.604 E.01532
G1 X164.789 Y92.938 E.72658
G1 X164.254 Y92.938 E.01649
G1 X170.657 Y99.342 E.27917
G2 X169.692 Y98.911 I-3.451 J6.441 E.03262
G1 X163.719 Y92.938 E.2604
G1 X163.184 Y92.938 E.01649
G1 X168.979 Y98.734 E.25266
G2 X168.362 Y98.651 I-.992 J5.056 E.01922
G1 X162.649 Y92.938 E.24905
G1 X162.114 Y92.938 E.01649
G1 X167.819 Y98.643 E.24872
G2 X167.323 Y98.682 I.029 J3.578 E.01536
G1 X161.579 Y92.938 E.25041
G1 X161.044 Y92.938 E.01649
G1 X166.868 Y98.762 E.2539
G1 X166.82 Y98.771 E.00151
G2 X166.446 Y98.875 I.819 J3.659 E.01197
G1 X160.509 Y92.938 E.25882
G1 X159.974 Y92.938 E.01649
G1 X166.05 Y99.014 E.26488
G2 X165.676 Y99.175 I.66 J2.041 E.01256
G1 X159.439 Y92.938 E.27192
G1 X158.904 Y92.938 E.01649
G1 X165.323 Y99.357 E.27984
G2 X164.997 Y99.567 I1.952 J3.385 E.01194
G1 X158.369 Y92.938 E.28898
G1 X157.834 Y92.938 E.01649
G1 X164.689 Y99.794 E.29887
G2 X164.398 Y100.037 I1.155 J1.683 E.01173
G1 X157.299 Y92.938 E.30947
G1 X156.764 Y92.938 E.01649
G1 X164.127 Y100.301 E.32099
G1 X164.08 Y100.347 E.00202
G2 X163.877 Y100.587 I2.254 J2.108 E.00968
G1 X156.229 Y92.938 E.33345
G1 X155.694 Y92.938 E.01649
G1 X163.644 Y100.888 E.3466
G2 X163.428 Y101.207 I3.043 J2.3 E.01188
G1 X155.159 Y92.938 E.36049
G1 X154.624 Y92.938 E.01649
G1 X163.239 Y101.553 E.37558
G2 X163.07 Y101.919 I1.837 J1.071 E.01244
G1 X154.089 Y92.938 E.39153
G1 X153.554 Y92.938 E.01649
G1 X162.922 Y102.306 E.40843
G2 X162.799 Y102.719 I2.263 J.898 E.01328
G1 X153.019 Y92.938 E.4264
G1 X152.484 Y92.938 E.01649
G1 X162.709 Y103.164 E.4458
G1 X162.704 Y103.193 E.00091
G2 X162.657 Y103.647 I4.584 J.697 E.01407
G1 X151.949 Y92.938 E.46685
G1 X151.414 Y92.938 E.01649
G1 X162.651 Y104.175 E.48989
G2 X162.703 Y104.762 I3.056 J.024 E.01821
G1 X150.879 Y92.938 E.5155
G1 X150.344 Y92.938 E.01649
G1 X162.844 Y105.438 E.54497
G2 X163.165 Y106.294 I5.369 J-1.524 E.0282
G1 X149.809 Y92.938 E.58227
G1 X149.274 Y92.938 E.01649
G1 X180.307 Y123.971 E1.35291
G1 X180.346 Y123.476 E.01532
G1 X165.712 Y108.841 E.63799
G2 X166.572 Y109.167 I2.934 J-6.461 E.02837
G1 X180.386 Y122.98 E.60221
G1 X180.426 Y122.485 E.01532
G1 X167.243 Y109.302 E.5747
G2 X167.829 Y109.353 I.555 J-2.998 E.01815
G1 X180.465 Y121.989 E.55089
G1 X180.505 Y121.494 E.01532
G1 X168.355 Y109.344 E.52967
G2 X168.837 Y109.291 I-.035 J-2.534 E.01497
G1 X180.544 Y120.999 E.51038
G1 X180.584 Y120.503 E.01532
G1 X169.284 Y109.203 E.49262
G1 X169.702 Y109.086 E.01337
G1 X180.624 Y120.008 E.47614
G1 X180.663 Y119.512 E.01532
G1 X170.087 Y108.936 E.46108
G2 X170.45 Y108.765 I-.72 J-1.997 E.01241
G1 X180.703 Y119.017 E.44696
G1 X180.742 Y118.522 E.01532
G1 X170.794 Y108.574 E.43369
G1 X171.119 Y108.364 E.01193
G1 X180.782 Y118.026 E.42124
G1 X180.822 Y117.531 E.01532
G1 X171.418 Y108.128 E.40994
G2 X171.701 Y107.875 I-1.179 J-1.608 E.0117
G1 X180.861 Y117.035 E.39933
G1 X180.901 Y116.54 E.01532
G1 X171.969 Y107.608 E.38941
G1 X172.213 Y107.317 E.01171
G1 X180.94 Y116.045 E.38049
G1 X180.98 Y115.549 E.01532
G1 X172.437 Y107.006 E.37244
G2 X172.644 Y106.678 I-1.621 J-1.254 E.01197
G1 X181.02 Y115.054 E.36513
G1 X181.059 Y114.558 E.01532
G1 X172.833 Y106.332 E.35864
G2 X172.992 Y105.956 I-3.691 J-1.785 E.01259
G1 X181.099 Y114.063 E.35343
G1 X181.138 Y113.568 E.01532
G1 X173.129 Y105.558 E.3492
G2 X173.239 Y105.133 I-2.155 J-.789 E.01354
G1 X181.178 Y113.072 E.3461
G1 X181.218 Y112.577 E.01532
G1 X173.319 Y104.678 E.34435
G2 X173.36 Y104.184 I-2.613 J-.466 E.0153
G1 X181.257 Y112.081 E.34428
G1 X181.297 Y111.586 E.01532
G1 X173.351 Y103.64 E.34641
G2 X173.271 Y103.026 I-3.22 J.104 E.01913
G1 X181.336 Y111.091 E.3516
G1 X181.376 Y110.595 E.01532
G1 X173.086 Y102.306 E.36139
G2 X172.652 Y101.336 I-5.351 J1.815 E.03279
G1 X181.573 Y110.258 E.38892
G1 X180.425 Y124.624 F30000
G1 F15000
G1 X148.738 Y92.938 E1.38138
G1 X148.203 Y92.938 E.01649
G1 X180.228 Y124.962 E1.39611
G1 X180.188 Y125.457 E.01532
G1 X147.668 Y92.938 E1.41771
G1 X147.133 Y92.938 E.01649
G1 X180.148 Y125.953 E1.4393
G1 X180.109 Y126.448 E.01532
G1 X146.598 Y92.938 E1.4609
G1 X146.063 Y92.938 E.01649
G1 X180.069 Y126.943 E1.4825
G1 X180.03 Y127.439 E.01532
G1 X145.528 Y92.938 E1.5041
G1 X144.993 Y92.937 E.01649
G1 X179.99 Y127.934 E1.52569
G1 X179.95 Y128.429 E.01532
G1 X144.458 Y92.937 E1.54729
G1 X143.923 Y92.937 E.01649
G1 X179.911 Y128.925 E1.56889
G1 X179.871 Y129.42 E.01532
G1 X143.388 Y92.937 E1.59049
G1 X142.853 Y92.937 E.01649
G1 X179.832 Y129.916 E1.61209
G1 X179.792 Y130.411 E.01532
G1 X142.318 Y92.937 E1.63368
G1 X141.783 Y92.937 E.01649
G1 X179.752 Y130.906 E1.65528
G1 X179.713 Y131.402 E.01532
G1 X141.248 Y92.937 E1.67688
G1 X140.713 Y92.937 E.01649
G1 X179.673 Y131.897 E1.69848
G1 X179.634 Y132.393 E.01532
G1 X140.178 Y92.937 E1.72007
G1 X139.643 Y92.937 E.01649
G1 X179.594 Y132.888 E1.74167
G1 X179.554 Y133.383 E.01532
G1 X139.108 Y92.937 E1.76327
G1 X138.573 Y92.937 E.01649
G1 X179.515 Y133.879 E1.78487
G1 X179.475 Y134.374 E.01532
G1 X138.038 Y92.937 E1.80647
G1 X137.503 Y92.937 E.01649
G1 X179.436 Y134.87 E1.82806
G1 X179.396 Y135.365 E.01532
G1 X136.968 Y92.937 E1.84966
G1 X136.433 Y92.937 E.01649
G1 X179.356 Y135.86 E1.87126
G1 X179.317 Y136.356 E.01532
G1 X135.898 Y92.937 E1.89286
G1 X135.363 Y92.937 E.01649
G1 X179.277 Y136.851 E1.91445
G1 X179.238 Y137.347 E.01532
G1 X134.828 Y92.937 E1.93605
G1 X134.293 Y92.937 E.01649
G1 X179.198 Y137.842 E1.95765
G1 X179.158 Y138.337 E.01532
G1 X133.758 Y92.937 E1.97925
G1 X133.223 Y92.937 E.01649
G1 X179.119 Y138.833 E2.00085
G1 X179.079 Y139.328 E.01532
G1 X132.688 Y92.937 E2.02244
G1 X132.153 Y92.937 E.01649
G1 X179.04 Y139.824 E2.04404
G1 X179 Y140.319 E.01532
G1 X131.618 Y92.937 E2.06564
G1 X131.083 Y92.937 E.01649
G1 X178.96 Y140.814 E2.08724
G1 X178.921 Y141.31 E.01532
G1 X130.548 Y92.937 E2.10883
G1 X130.013 Y92.937 E.01649
G1 X178.881 Y141.805 E2.13043
G1 X178.842 Y142.301 E.01532
G1 X129.478 Y92.937 E2.15203
G1 X128.943 Y92.937 E.01649
G1 X178.802 Y142.796 E2.17363
G1 X178.762 Y143.291 E.01532
G1 X128.408 Y92.937 E2.19523
G1 X127.873 Y92.937 E.01649
G1 X178.723 Y143.787 E2.21682
G1 X178.683 Y144.282 E.01532
G1 X127.338 Y92.937 E2.23842
G1 X126.803 Y92.937 E.01649
G1 X178.644 Y144.778 E2.26002
G1 X178.604 Y145.273 E.01532
G1 X126.268 Y92.937 E2.28162
G1 X125.733 Y92.937 E.01649
G1 X178.564 Y145.768 E2.30321
G1 X178.525 Y146.264 E.01532
G1 X125.198 Y92.937 E2.32481
G1 X124.663 Y92.937 E.01649
G1 X178.485 Y146.759 E2.34641
G1 X178.446 Y147.255 E.01532
G1 X124.128 Y92.937 E2.36801
G1 X123.593 Y92.937 E.01649
G1 X178.406 Y147.75 E2.38961
G1 X178.366 Y148.245 E.01532
G1 X123.058 Y92.937 E2.4112
G1 X122.523 Y92.937 E.01649
G1 X178.327 Y148.741 E2.4328
G1 X178.287 Y149.236 E.01532
G1 X121.988 Y92.937 E2.4544
G1 X121.453 Y92.937 E.01649
G1 X178.248 Y149.731 E2.476
G1 X178.208 Y150.227 E.01532
G1 X120.918 Y92.937 E2.49759
G1 X120.383 Y92.937 E.01649
G1 X178.168 Y150.722 E2.51919
G3 X178.094 Y151.183 I-3.319 J-.297 E.0144
M73 P47 R17
G1 X173.019 Y146.108 E.22127
G1 X173.04 Y146.158 E.00168
G3 X173.238 Y146.862 I-8.157 J2.678 E.02257
G1 X177.948 Y151.572 E.20532
G3 X177.747 Y151.906 I-2.658 J-1.379 E.01202
G1 X173.336 Y147.495 E.19227
G3 X173.36 Y148.054 I-2.872 J.402 E.01727
G1 X177.492 Y152.186 E.18013
G1 X177.224 Y152.453 E.01166
G1 X173.331 Y148.56 E.16975
G3 X173.261 Y149.025 I-2.451 J-.129 E.01453
G1 X176.957 Y152.721 E.16113
G1 X176.69 Y152.989 E.01166
G1 X173.159 Y149.458 E.15391
G3 X173.031 Y149.864 I-2.447 J-.552 E.01315
G1 X176.422 Y153.256 E.14786
G1 X176.155 Y153.524 E.01166
G1 X172.872 Y150.241 E.14312
G1 X172.839 Y150.319 E.00261
G3 X172.69 Y150.594 I-2.864 J-1.372 E.00965
G1 X175.887 Y153.791 E.13939
G1 X175.62 Y154.059 E.01166
G1 X172.49 Y150.929 E.13647
G3 X172.272 Y151.246 I-2.835 J-1.711 E.01187
G1 X175.353 Y154.327 E.1343
G1 X175.085 Y154.594 E.01166
G1 X172.028 Y151.537 E.13328
G3 X171.767 Y151.811 I-1.572 J-1.232 E.01168
G1 X174.818 Y154.862 E.13299
G1 X174.55 Y155.129 E.01166
G1 X171.491 Y152.07 E.13338
G1 X171.193 Y152.307 E.01174
G1 X174.283 Y155.397 E.1347
G1 X174.016 Y155.664 E.01166
G1 X170.874 Y152.522 E.13697
G3 X170.536 Y152.72 I-1.204 J-1.666 E.01207
G1 X173.748 Y155.932 E.14001
G1 X173.481 Y156.2 E.01166
G1 X170.18 Y152.899 E.14388
G1 X169.796 Y153.05 E.01272
G1 X173.213 Y156.467 E.14897
G1 X172.946 Y156.735 E.01166
G1 X169.386 Y153.175 E.15519
G3 X168.948 Y153.272 I-.724 J-2.23 E.01385
G1 X172.678 Y157.002 E.16263
G1 X172.411 Y157.27 E.01166
G1 X168.476 Y153.335 E.17153
G3 X167.962 Y153.356 I-.366 J-2.657 E.01588
G1 X172.144 Y157.537 E.18228
G1 X171.876 Y157.805 E.01166
G1 X167.392 Y153.321 E.1955
G3 X166.741 Y153.205 I.268 J-3.397 E.02041
G1 X171.609 Y158.073 E.2122
G1 X171.341 Y158.34 E.01166
G1 X165.603 Y152.602 E.25017
G1 X172.723 Y149.541 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X172.968 Y147.94 I-6.68 J-1.84 E.05386
G1 X168.064 Y143.036 E.23005
G3 X171.204 Y144.203 I-.185 J5.305 E.11306
G1 X164.209 Y151.199 E.32817
G3 X163.429 Y146.077 I3.923 J-3.218 E.18037
G1 X169.929 Y152.577 E.30493
G3 X168.353 Y152.951 I-2.387 J-6.543 E.05386
G1 X170.218 Y143.307 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42122
G1 F15000
G1 X119.848 Y92.937 E2.19593
G1 X119.313 Y92.937 E.01649
G1 X169.138 Y142.762 E2.17214
G2 X168.504 Y142.663 I-.952 J4.051 E.01977
G1 X118.778 Y92.937 E2.16787
G1 X118.243 Y92.937 E.01649
G1 X167.947 Y142.641 E2.1669
G1 X167.879 Y142.64 E.0021
G2 X167.442 Y142.671 I.107 J4.469 E.0135
G1 X117.708 Y92.937 E2.16822
G1 X117.173 Y92.937 E.01649
G1 X166.979 Y142.743 E2.17132
G2 X166.547 Y142.846 I.325 J2.298 E.01369
G1 X116.638 Y92.937 E2.17584
G1 X116.103 Y92.936 E.01649
G1 X166.143 Y142.977 E2.18155
G2 X165.762 Y143.131 I.678 J2.226 E.01269
G1 X115.568 Y92.936 E2.18826
G1 X115.033 Y92.936 E.01649
G1 X165.408 Y143.312 E2.19616
G1 X165.331 Y143.352 E.00268
G2 X165.077 Y143.515 I1.482 J2.59 E.00933
G1 X114.498 Y92.936 E2.20502
G1 X113.962 Y92.936 E.01649
G1 X164.762 Y143.736 E2.21462
G1 X164.464 Y143.973 E.01174
G1 X113.427 Y92.936 E2.22497
G1 X112.892 Y92.936 E.01649
G1 X164.193 Y144.237 E2.23646
G2 X163.937 Y144.516 I1.335 J1.48 E.01169
G1 X112.357 Y92.936 E2.24863
G1 X111.822 Y92.936 E.01649
G1 X163.697 Y144.811 E2.26149
G1 X163.48 Y145.129 E.01187
G1 X111.287 Y92.936 E2.27536
G1 X110.752 Y92.936 E.01649
G1 X163.285 Y145.469 E2.29017
G2 X163.108 Y145.827 I1.787 J1.102 E.01234
G1 X110.217 Y92.936 E2.3058
G1 X109.682 Y92.936 E.01649
G1 X162.953 Y146.207 E2.32235
G1 X162.827 Y146.616 E.01319
G1 X109.147 Y92.936 E2.34018
G1 X108.612 Y92.936 E.01649
G1 X162.731 Y147.055 E2.35935
G2 X162.669 Y147.528 I2.437 J.561 E.01472
G1 X108.077 Y92.936 E2.37996
G1 X107.542 Y92.936 E.01649
G1 X162.649 Y148.043 E2.40239
G2 X162.683 Y148.612 I2.958 J.107 E.01761
G1 X107.007 Y92.936 E2.42722
G1 X106.472 Y92.936 E.01649
G1 X162.795 Y149.259 E2.45541
G1 X162.806 Y149.315 E.00176
G2 X163.06 Y150.059 I7.715 J-2.218 E.02426
G1 X105.937 Y92.936 E2.49031
G1 X105.402 Y92.936 E.01649
G1 X171.065 Y158.599 E2.86261
G3 X170.742 Y158.811 I-.875 J-.985 E.01196
G1 X104.867 Y92.936 E2.87183
G1 X104.332 Y92.936 E.01649
G1 X170.364 Y158.968 E2.87871
G3 X169.918 Y159.056 I-.732 J-2.536 E.01406
G1 X103.797 Y92.936 E2.88255
G1 X103.262 Y92.936 E.01649
G1 X169.391 Y159.065 E2.88291
G1 X168.856 Y159.065 E.01649
G1 X102.727 Y92.936 E2.8829
G1 X102.192 Y92.936 E.01649
G1 X168.321 Y159.064 E2.8829
G1 X167.786 Y159.064 E.01649
G1 X101.657 Y92.936 E2.8829
G1 X101.122 Y92.936 E.01649
G1 X167.25 Y159.064 E2.8829
G1 X166.715 Y159.064 E.01649
G1 X100.587 Y92.936 E2.88289
G1 X100.052 Y92.936 E.01649
G1 X166.18 Y159.064 E2.88289
G1 X165.645 Y159.064 E.01649
G1 X99.517 Y92.936 E2.88289
G1 X98.982 Y92.936 E.01649
G1 X165.11 Y159.064 E2.88289
G1 X164.575 Y159.064 E.01649
G1 X98.447 Y92.936 E2.88289
G1 X97.912 Y92.936 E.01649
G1 X164.04 Y159.064 E2.88288
G1 X163.505 Y159.064 E.01649
G1 X97.377 Y92.936 E2.88288
G1 X96.842 Y92.936 E.01649
G1 X162.97 Y159.064 E2.88288
G1 X162.435 Y159.064 E.01649
G1 X96.307 Y92.936 E2.88288
G1 X95.772 Y92.936 E.01649
G1 X161.9 Y159.064 E2.88287
G1 X161.365 Y159.064 E.01649
G1 X95.237 Y92.936 E2.88287
G1 X94.702 Y92.936 E.01649
G1 X160.83 Y159.063 E2.88287
G1 X160.295 Y159.063 E.01649
G1 X94.167 Y92.936 E2.88287
G1 X93.632 Y92.936 E.01649
G1 X159.759 Y159.063 E2.88286
G1 X159.224 Y159.063 E.01649
G1 X93.097 Y92.936 E2.88286
G1 X92.562 Y92.936 E.01649
G1 X158.689 Y159.063 E2.88286
G1 X158.154 Y159.063 E.01649
G1 X92.027 Y92.936 E2.88286
G1 X91.492 Y92.936 E.01649
G1 X157.619 Y159.063 E2.88285
G1 X157.084 Y159.063 E.01649
G1 X90.957 Y92.936 E2.88285
G1 X90.422 Y92.936 E.01649
M73 P47 R16
G1 X156.549 Y159.063 E2.88285
G1 X156.014 Y159.063 E.01649
G1 X89.887 Y92.936 E2.88285
G1 X89.352 Y92.936 E.01649
G1 X155.479 Y159.063 E2.88284
G1 X154.944 Y159.063 E.01649
G1 X88.817 Y92.936 E2.88284
M73 P48 R16
G1 X88.282 Y92.936 E.01649
G1 X154.409 Y159.063 E2.88284
G1 X153.874 Y159.062 E.01649
G1 X87.747 Y92.935 E2.88284
G1 X87.212 Y92.935 E.01649
G1 X153.339 Y159.062 E2.88283
G1 X152.804 Y159.062 E.01649
G1 X86.677 Y92.935 E2.88283
G1 X86.142 Y92.935 E.01649
G1 X152.268 Y159.062 E2.88283
G1 X151.733 Y159.062 E.01649
G1 X85.607 Y92.935 E2.88283
G1 X85.072 Y92.935 E.01649
G1 X151.198 Y159.062 E2.88282
G1 X150.663 Y159.062 E.01649
G1 X84.537 Y92.935 E2.88282
G1 X84.002 Y92.935 E.01649
G1 X90.158 Y99.092 E.2684
G2 X89.345 Y98.814 I-1.827 J4.01 E.02655
G1 X83.467 Y92.935 E.25626
G1 X82.932 Y92.935 E.01649
G1 X88.677 Y98.68 E.25046
G2 X88.106 Y98.645 I-.654 J5.923 E.01762
G1 X82.412 Y92.951 E.24822
G2 X81.97 Y93.044 I.117 J1.662 E.01398
G1 X87.587 Y98.661 E.24487
G2 X87.111 Y98.719 I.066 J2.498 E.01482
G1 X81.597 Y93.206 E.24036
G2 X81.28 Y93.423 I1.813 J2.987 E.01187
G1 X86.669 Y98.812 E.23493
G2 X86.255 Y98.933 I.472 J2.38 E.01331
G1 X81.021 Y93.7 E.22815
G2 X80.792 Y94.005 I1.452 J1.332 E.0118
G1 X85.87 Y99.084 E.22141
G1 X85.807 Y99.109 E.0021
G2 X85.511 Y99.26 I1.386 J3.087 E.01025
G1 X80.578 Y94.326 E.21508
G1 X80.364 Y94.647 E.01189
G1 X85.171 Y99.455 E.20957
G2 X84.848 Y99.667 I1.082 J1.995 E.01192
G1 X80.15 Y94.968 E.20483
G1 X79.936 Y95.289 E.01189
G1 X84.551 Y99.904 E.20119
G1 X84.463 Y99.974 E.00346
G2 X84.271 Y100.16 I1.769 J2.017 E.00823
G1 X79.722 Y95.61 E.19834
G1 X79.508 Y95.931 E.01189
G1 X84.008 Y100.431 E.19618
G1 X83.764 Y100.722 E.01171
G1 X79.294 Y96.252 E.19487
G1 X79.08 Y96.573 E.01189
G1 X83.543 Y101.037 E.19458
G2 X83.339 Y101.368 I1.631 J1.23 E.01201
G1 X78.866 Y96.894 E.19504
G1 X78.652 Y97.215 E.01189
G1 X83.154 Y101.718 E.1963
G1 X82.996 Y102.094 E.01259
G1 X78.438 Y97.536 E.19871
G1 X78.224 Y97.857 E.01189
G1 X82.863 Y102.497 E.20227
G2 X82.757 Y102.926 I2.183 J.766 E.01365
G1 X78.01 Y98.178 E.20699
G1 X77.796 Y98.499 E.01189
G1 X82.683 Y103.387 E.21308
G2 X82.649 Y103.887 I2.589 J.43 E.01549
G1 X77.582 Y98.82 E.2209
G1 X77.368 Y99.141 E.01189
G1 X82.666 Y104.44 E.23098
G2 X82.756 Y105.064 I3.26 J-.149 E.01948
G1 X77.154 Y99.462 E.24422
G1 X76.94 Y99.783 E.01189
G1 X83.263 Y106.106 E.27566
G1 X83.283 Y102.467 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X83.041 Y104.069 I6.681 J1.829 E.05386
G1 X87.935 Y108.963 E.22961
G3 X84.8 Y107.792 I.191 J-5.294 E.11296
G1 X91.796 Y100.797 E.32818
G3 X92.578 Y105.929 I-3.918 J3.223 E.1808
G1 X86.074 Y99.426 E.30511
G3 X87.649 Y99.049 I2.398 J6.553 E.05386
G1 X85.893 Y108.737 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42122
G1 F15000
G1 X136.216 Y159.06 E2.19386
G1 X136.751 Y159.06 E.01649
G1 X86.942 Y109.251 E2.17145
G2 X87.569 Y109.343 I.793 J-3.221 E.01957
G1 X137.286 Y159.06 E2.16744
G1 X137.822 Y159.06 E.01649
G1 X88.122 Y109.36 E2.16669
G2 X88.621 Y109.324 I.002 J-3.47 E.01544
G1 X138.357 Y159.06 E2.16825
G1 X138.892 Y159.06 E.01649
G1 X89.08 Y109.249 E2.17157
G2 X89.507 Y109.141 I-.354 J-2.302 E.0136
G1 X139.427 Y159.06 E2.17627
G1 X139.962 Y159.06 E.01649
G1 X89.908 Y109.006 E2.18213
G2 X90.218 Y108.884 I-1.051 J-3.109 E.01028
G1 X90.285 Y108.849 E.00235
G1 X140.497 Y159.061 E2.18899
G1 X141.032 Y159.061 E.01649
G1 X90.639 Y108.668 E2.1969
M73 P49 R16
G2 X90.968 Y108.462 I-.977 J-1.923 E.01198
G1 X141.567 Y159.061 E2.20589
G1 X142.102 Y159.061 E.01649
G1 X91.28 Y108.238 E2.21563
G2 X91.559 Y108.014 I-2.101 J-2.907 E.01104
G1 X91.575 Y107.999 E.0007
G1 X142.637 Y159.061 E2.22608
G1 X143.172 Y159.061 E.01649
G1 X91.846 Y107.735 E2.2376
G2 X92.099 Y107.452 I-1.358 J-1.473 E.0117
G1 X143.707 Y159.061 E2.2499
G1 X144.242 Y159.061 E.01649
G1 X92.336 Y107.154 E2.2629
G1 X92.553 Y106.836 E.01187
G1 X144.777 Y159.061 E2.27677
G1 X145.313 Y159.061 E.01649
G1 X92.745 Y106.494 E2.29172
G2 X92.918 Y106.132 I-1.801 J-1.084 E.01239
G1 X145.848 Y159.061 E2.3075
G1 X146.383 Y159.061 E.01649
G1 X93.07 Y105.748 E2.3242
G1 X93.196 Y105.34 E.01319
G1 X146.918 Y159.061 E2.34203
G1 X147.453 Y159.062 E.01649
G1 X93.287 Y104.896 E2.36137
G2 X93.345 Y104.419 I-2.494 J-.543 E.01484
G1 X147.988 Y159.062 E2.38219
G1 X148.523 Y159.062 E.01649
G1 X93.36 Y103.899 E2.40485
G2 X93.319 Y103.323 I-3.008 J-.075 E.01783
G1 X149.058 Y159.062 E2.42997
G1 X149.593 Y159.062 E.01649
G1 X93.198 Y102.666 E2.45859
G2 X92.906 Y101.839 I-4.365 J1.076 E.02708
G1 X150.298 Y159.232 E2.50204
G1 X135.851 Y159.23 F30000
G1 F15000
G1 X76.726 Y100.104 E2.5776
G1 X76.512 Y100.425 E.01189
G1 X135.146 Y159.06 E2.5562
G1 X134.611 Y159.06 E.01649
G1 X76.298 Y100.746 E2.5422
G1 X76.084 Y101.067 E.01189
G1 X134.076 Y159.06 E2.5282
G1 X133.541 Y159.06 E.01649
G1 X75.87 Y101.388 E2.51421
G1 X75.656 Y101.709 E.01189
G1 X133.006 Y159.06 E2.50021
G1 X132.471 Y159.059 E.01649
G1 X75.442 Y102.03 E2.48621
G1 X75.228 Y102.351 E.01189
G1 X131.936 Y159.059 E2.47222
G1 X131.401 Y159.059 E.01649
G1 X75.014 Y102.672 E2.45822
G1 X74.8 Y102.993 E.01189
G1 X130.866 Y159.059 E2.44422
G1 X130.33 Y159.059 E.01649
G1 X74.586 Y103.314 E2.43022
G1 X74.372 Y103.635 E.01189
G1 X129.795 Y159.059 E2.41623
G1 X129.26 Y159.059 E.01649
G1 X74.187 Y103.986 E2.40094
G2 X74.058 Y104.392 I2.565 J1.041 E.01314
G1 X128.725 Y159.059 E2.38325
G1 X128.19 Y159.059 E.01649
G1 X74.024 Y104.893 E2.36141
G2 X74.065 Y105.469 I4.094 J-.005 E.01783
G1 X127.655 Y159.059 E2.33627
G1 X127.12 Y159.059 E.01649
G1 X74.114 Y106.053 E2.31082
G1 X74.163 Y106.636 E.01805
G1 X126.585 Y159.059 E2.28538
G1 X126.05 Y159.059 E.01649
G1 X74.211 Y107.22 E2.25993
G1 X74.26 Y107.804 E.01805
G1 X125.515 Y159.058 E2.23448
G1 X124.98 Y159.058 E.01649
G1 X74.309 Y108.387 E2.20904
G1 X74.357 Y108.971 E.01805
G1 X124.445 Y159.058 E2.18359
G1 X123.91 Y159.058 E.01649
G1 X74.406 Y109.554 E2.15814
G1 X74.454 Y110.138 E.01805
G1 X123.375 Y159.058 E2.1327
G1 X122.839 Y159.058 E.01649
G1 X74.503 Y110.722 E2.10725
G1 X74.552 Y111.305 E.01805
G1 X122.304 Y159.058 E2.0818
G1 X121.769 Y159.058 E.01649
G1 X74.6 Y111.889 E2.05635
G1 X74.649 Y112.473 E.01805
G1 X121.234 Y159.058 E2.03091
G1 X120.699 Y159.058 E.01649
G1 X74.698 Y113.056 E2.00546
G1 X74.746 Y113.64 E.01805
G1 X120.164 Y159.058 E1.98001
G1 X119.629 Y159.058 E.01649
G1 X74.795 Y114.224 E1.95457
G1 X74.844 Y114.807 E.01805
G1 X119.094 Y159.058 E1.92912
G1 X118.559 Y159.057 E.01649
G1 X74.892 Y115.391 E1.90367
G1 X74.941 Y115.974 E.01805
G1 X118.024 Y159.057 E1.87822
G1 X117.489 Y159.057 E.01649
G1 X74.989 Y116.558 E1.85278
G1 X75.038 Y117.142 E.01805
G1 X116.954 Y159.057 E1.82733
G1 X116.419 Y159.057 E.01649
G1 X75.087 Y117.725 E1.80188
G1 X75.135 Y118.309 E.01805
G1 X115.884 Y159.057 E1.77644
G1 X115.348 Y159.057 E.01649
G1 X75.184 Y118.893 E1.75099
G1 X75.233 Y119.476 E.01805
G1 X114.813 Y159.057 E1.72554
G1 X114.278 Y159.057 E.01649
G1 X75.281 Y120.06 E1.7001
G1 X75.33 Y120.643 E.01805
G1 X113.743 Y159.057 E1.67465
G1 X113.208 Y159.057 E.01649
G1 X75.379 Y121.227 E1.6492
G1 X75.427 Y121.811 E.01805
G1 X112.673 Y159.057 E1.62375
G1 X112.138 Y159.057 E.01649
G1 X75.476 Y122.394 E1.59831
G1 X75.524 Y122.978 E.01805
G1 X111.603 Y159.057 E1.57286
G1 X111.068 Y159.056 E.01649
G1 X75.573 Y123.562 E1.54741
G1 X75.622 Y124.145 E.01805
G1 X110.533 Y159.056 E1.52197
G1 X109.998 Y159.056 E.01649
G1 X75.67 Y124.729 E1.49652
G1 X75.719 Y125.313 E.01805
G1 X109.463 Y159.056 E1.47107
G1 X108.928 Y159.056 E.01649
G1 X75.768 Y125.896 E1.44563
G1 X75.816 Y126.48 E.01805
G1 X108.393 Y159.056 E1.42018
G1 X107.857 Y159.056 E.01649
G1 X75.865 Y127.063 E1.39473
G1 X75.914 Y127.647 E.01805
G1 X107.322 Y159.056 E1.36928
G1 X106.787 Y159.056 E.01649
G1 X75.962 Y128.231 E1.34384
G1 X76.011 Y128.814 E.01805
G1 X90.413 Y143.216 E.62786
G2 X89.526 Y142.865 I-2.441 J4.86 E.02944
G1 X76.059 Y129.398 E.58708
G1 X76.108 Y129.982 E.01805
G1 X88.835 Y142.708 E.55482
G1 X88.679 Y142.681 E.00488
G2 X88.24 Y142.648 I-.664 J5.976 E.01358
G1 X76.157 Y130.565 E.52676
G1 X76.205 Y131.149 E.01805
G1 X87.708 Y142.652 E.50146
G2 X87.221 Y142.7 I.01 J2.581 E.0151
G1 X76.254 Y131.732 E.47813
G1 X76.303 Y132.316 E.01805
G1 X86.77 Y142.784 E.45634
G1 X86.353 Y142.901 E.01337
G1 X76.351 Y132.9 E.43601
G1 X76.4 Y133.483 E.01805
G1 X85.964 Y143.047 E.41695
G2 X85.597 Y143.216 I.695 J2 E.01246
G1 X76.449 Y134.067 E.39884
G1 X76.497 Y134.651 E.01805
G1 X85.25 Y143.403 E.38158
M73 P50 R16
G1 X84.925 Y143.613 E.01193
G1 X76.546 Y135.234 E.36529
G1 X76.594 Y135.818 E.01805
G1 X84.623 Y143.846 E.35001
G2 X84.337 Y144.096 I1.163 J1.623 E.01171
G1 X76.643 Y136.402 E.33543
G1 X76.692 Y136.985 E.01805
G1 X84.067 Y144.36 E.32153
G1 X83.823 Y144.651 E.01171
G1 X76.74 Y137.569 E.30877
G1 X76.789 Y138.152 E.01805
G1 X83.596 Y144.959 E.29674
G2 X83.385 Y145.284 I1.624 J1.283 E.01194
G1 X76.838 Y138.736 E.28545
G1 X76.886 Y139.32 E.01805
G1 X83.197 Y145.63 E.27511
G1 X83.177 Y145.666 E.00125
G2 X83.034 Y146.003 I3.296 J1.597 E.01129
G1 X76.935 Y139.903 E.26591
G1 X76.984 Y140.487 E.01805
G1 X82.894 Y146.398 E.25767
G2 X82.779 Y146.818 I2.141 J.81 E.01345
G1 X77.032 Y141.071 E.25055
G1 X77.081 Y141.654 E.01805
G1 X82.695 Y147.269 E.24476
G2 X82.649 Y147.757 I2.982 J.53 E.01515
G1 X77.129 Y142.238 E.24062
G1 X77.178 Y142.822 E.01805
G1 X82.652 Y148.295 E.23862
G2 X82.723 Y148.901 I3.226 J-.071 E.01884
G1 X77.227 Y143.405 E.23959
G1 X77.275 Y143.989 E.01805
G1 X82.896 Y149.61 E.24505
G2 X83.287 Y150.535 I5.123 J-1.616 E.03101
G1 X77.324 Y144.572 E.25994
G1 X77.373 Y145.156 E.01805
G1 X91.27 Y159.054 E.60587
G1 X91.805 Y159.054 E.01649
G1 X85.48 Y152.728 E.27577
G1 X85.578 Y152.781 E.00344
G2 X86.396 Y153.109 I3.212 J-6.818 E.02719
G1 X92.34 Y159.054 E.25915
G1 X92.875 Y159.054 E.01649
G1 X87.107 Y153.285 E.2515
G2 X87.706 Y153.35 I.642 J-3.127 E.01863
G1 X93.411 Y159.054 E.24867
G1 X93.946 Y159.054 E.01649
G1 X88.244 Y153.353 E.24855
G2 X88.736 Y153.309 I.011 J-2.676 E.01523
G1 X94.481 Y159.054 E.25045
G1 X95.016 Y159.054 E.01649
G1 X89.191 Y153.229 E.25395
G2 X89.609 Y153.112 I-.969 J-4.277 E.01339
G1 X95.551 Y159.054 E.25905
G1 X96.086 Y159.054 E.01649
G1 X90.001 Y152.97 E.26526
G2 X90.371 Y152.805 I-.676 J-2.017 E.01251
G1 X96.621 Y159.054 E.27245
G1 X97.156 Y159.054 E.01649
G1 X90.722 Y152.62 E.2805
G1 X91.047 Y152.41 E.01193
G1 X97.691 Y159.055 E.28965
G1 X98.226 Y159.055 E.01649
G1 X91.352 Y152.18 E.29968
G2 X91.641 Y151.934 I-1.154 J-1.647 E.01172
G1 X98.761 Y159.055 E.31041
G1 X99.296 Y159.055 E.01649
G1 X91.912 Y151.67 E.32193
G1 X91.929 Y151.653 E.00075
G2 X92.158 Y151.382 I-2.616 J-2.438 E.01096
G1 X99.831 Y159.055 E.33452
G1 X100.366 Y159.055 E.01649
G1 X92.389 Y151.077 E.3478
G2 X92.602 Y150.756 I-1.689 J-1.354 E.01191
G1 X100.902 Y159.055 E.36182
G1 X101.437 Y159.055 E.01649
G1 X92.791 Y150.409 E.37692
G1 X92.831 Y150.334 E.00263
G2 X92.957 Y150.04 I-2.854 J-1.386 E.00986
G1 X101.972 Y159.055 E.39302
G1 X102.507 Y159.055 E.01649
G1 X93.1 Y149.649 E.41007
G2 X93.219 Y149.233 I-2.154 J-.84 E.01336
G1 X103.042 Y159.055 E.42822
G1 X103.577 Y159.055 E.01649
G1 X93.308 Y148.787 E.44767
G1 X93.357 Y148.3 E.01507
G1 X104.112 Y159.055 E.46888
G1 X104.647 Y159.056 E.01649
G1 X93.36 Y147.769 E.49206
G1 X93.36 Y147.741 E.00083
G2 X93.302 Y147.175 I-30.841 J2.894 E.01755
G1 X105.182 Y159.056 E.51793
G1 X105.717 Y159.056 E.01649
G1 X93.14 Y146.478 E.54833
G2 X92.795 Y145.598 I-5.725 J1.737 E.02916
G1 X106.422 Y159.225 E.59409
G1 X90.905 Y159.223 F30000
G1 F15000
G1 X77.421 Y145.74 E.58782
G1 X77.47 Y146.323 E.01805
G1 X90.2 Y159.054 E.55498
G1 X89.665 Y159.053 E.01649
G1 X77.519 Y146.907 E.52953
G1 X77.567 Y147.491 E.01805
G1 X89.13 Y159.053 E.50408
G1 X88.595 Y159.053 E.01649
G1 X77.616 Y148.074 E.47864
G1 X77.664 Y148.658 E.01805
G1 X88.06 Y159.053 E.45319
G1 X87.525 Y159.053 E.01649
G1 X77.713 Y149.241 E.42774
G1 X77.762 Y149.825 E.01805
G1 X86.99 Y159.053 E.4023
G1 X86.455 Y159.053 E.01649
G1 X77.81 Y150.409 E.37685
G2 X77.869 Y151.002 I6.444 J-.334 E.01838
G1 X85.894 Y159.028 E.34988
G1 X85.75 Y159.003 E.00452
G3 X84.858 Y158.527 I.593 J-2.184 E.03141
G1 X77.839 Y151.508 E.306
G1 X87.649 Y152.956 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X86.074 Y152.574 I.435 J-5.237 E.05398
G1 X92.578 Y146.071 E.30511
G3 X91.796 Y151.203 I-4.7 J1.91 E.1808
G1 X84.8 Y144.207 E.32821
G3 X87.939 Y143.033 I3.347 J4.164 E.11309
G1 X83.041 Y147.931 E.22978
G2 X83.283 Y149.533 I6.925 J-.228 E.05386
G1 X168.353 Y99.043 F30000
G1 F15476.087
G1 X168.354 Y99.043 E.00002
G3 X169.929 Y99.423 I-.955 J7.409 E.05385
G1 X163.424 Y105.928 E.30515
G3 X164.209 Y100.801 I4.729 J-1.899 E.18049
G1 X171.204 Y107.797 E.32816
G3 X168.061 Y108.966 I-3.338 J-4.162 E.11316
G1 X172.968 Y104.06 E.23017
G2 X172.723 Y102.459 I-6.925 J.239 E.05386
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X172.919 Y103.259 E-.31324
G1 X172.968 Y104.06 E-.30479
G1 X172.704 Y104.324 E-.14198
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/23
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.8 I1.21 J.126 P1  F30000
G1 X173.919 Y92.631 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.369 J2.397 E.05959
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.915 J1.518 E.06044
G1 X178.493 Y150.844 E1.58733
G3 X177.793 Y152.36 I-2.403 J-.19 E.05657
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29697
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06293
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.436 E.06292
G1 X78.212 Y152.356 E.29714
G3 X77.513 Y150.848 I1.703 J-1.706 E.05631
G1 X73.692 Y105.002 E1.52606
G3 X74.09 Y103.457 I2.452 J-.192 E.05389
G1 X80.611 Y93.676 E.38996
G3 X82.618 Y92.602 I2.011 J1.345 E.07862
G1 X173.576 Y92.603 E3.01724
G3 X173.86 Y92.622 I-.026 J2.425 E.00945
M204 S250
G1 X173.971 Y92.241 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X173.977 Y92.243 E.00022
G3 X175.743 Y93.259 I-.429 J2.788 E.06404
G1 X182.096 Y101.201 E.31249
G3 X182.7 Y103.171 I-2.229 J1.761 E.06479
G1 X178.883 Y150.88 E1.47065
G3 X178.074 Y152.634 I-2.794 J-.226 E.06062
G1 X171.736 Y158.971 E.27538
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06745
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.832 E.06744
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I1.983 J-1.98 E.06034
G1 X73.301 Y105.029 E1.41393
G3 X73.761 Y103.244 I2.85 J-.217 E.05767
G1 X80.287 Y93.455 E.36151
G3 X82.613 Y92.21 I2.336 J1.569 E.08436
G1 X173.58 Y92.211 E2.79518
G1 X173.911 Y92.236 E.01018
; WIPE_START
M204 S10000
G1 X173.977 Y92.243 E-.02542
G1 X174.25 Y92.296 E-.10553
G1 X174.515 Y92.378 E-.10547
G1 X174.771 Y92.485 E-.10551
G1 X175.015 Y92.618 E-.1055
G1 X175.353 Y92.861 E-.15817
G1 X175.557 Y93.049 E-.10558
G1 X175.642 Y93.146 E-.04881
; WIPE_END
G1 E-.04 F1800
G1 X169.32 Y97.421 Z2 F30000
G1 X168.015 Y98.303 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X169.621 Y98.537 I-.012 J5.716 E.054
G1 X173.467 Y102.384 E.18045
G3 X173.666 Y103.362 I-7.476 J2.024 E.03314
G1 X167.367 Y109.661 E.2955
G2 X171.723 Y108.316 I.636 J-5.666 E.15561
G1 X163.689 Y100.281 E.37692
G2 X162.873 Y106.478 I4.321 J3.721 E.21945
G1 X170.482 Y98.87 E.35691
G3 X171.828 Y99.776 I-2.489 J5.15 E.054
G1 X173.266 Y106.712 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42083
G1 F15000
G1 X180.103 Y99.874 E.29778
G1 X179.866 Y99.577 E.01171
G1 X173.894 Y105.55 E.26009
G1 X174.031 Y104.878 E.02111
G1 X179.628 Y99.28 E.24378
G1 X179.391 Y98.983 E.01171
G1 X174.088 Y104.286 E.23095
G1 X174.089 Y103.751 E.01649
G1 X179.153 Y98.686 E.22057
G1 X178.916 Y98.389 E.01171
G1 X174.048 Y103.258 E.21202
G1 X173.975 Y102.796 E.01439
G1 X178.679 Y98.092 E.20485
G1 X178.441 Y97.795 E.01171
G1 X173.87 Y102.367 E.19907
G1 X173.742 Y101.96 E.01313
G1 X178.204 Y97.498 E.1943
G1 X177.966 Y97.201 E.01171
G1 X173.591 Y101.577 E.19055
G1 X173.419 Y101.215 E.01235
G1 X177.729 Y96.904 E.18771
G1 X177.491 Y96.607 E.01171
G1 X173.228 Y100.87 E.18566
G1 X173.019 Y100.545 E.01191
G1 X177.254 Y96.31 E.18441
G1 X177.016 Y96.013 E.01171
G1 X172.792 Y100.238 E.18397
G1 X172.548 Y99.947 E.01168
G1 X176.779 Y95.716 E.18424
G1 X176.541 Y95.419 E.01171
G1 X172.289 Y99.672 E.18521
G1 X172.012 Y99.414 E.01164
G1 X176.304 Y95.122 E.18692
G1 X176.066 Y94.826 E.01171
G1 X171.718 Y99.174 E.1894
G1 X171.407 Y98.951 E.01179
G1 X175.829 Y94.529 E.19258
G1 X175.592 Y94.232 E.01171
G1 X171.08 Y98.744 E.1965
G1 X170.733 Y98.556 E.01214
G1 X175.354 Y93.935 E.20126
G2 X175.113 Y93.641 I-3.103 J2.307 E.0117
G1 X170.366 Y98.388 E.20672
G1 X169.98 Y98.24 E.01274
G1 X174.838 Y93.382 E.21155
G2 X174.514 Y93.171 I-1.005 J1.185 E.01192
G1 X169.57 Y98.116 E.21534
G1 X169.134 Y98.017 E.01375
G1 X174.129 Y93.022 E.21752
G2 X173.672 Y92.944 I-.493 J1.516 E.01432
G1 X168.669 Y97.948 E.21791
G1 X168.17 Y97.912 E.0154
G1 X173.146 Y92.936 E.21671
G1 X172.612 Y92.936 E.01646
G1 X167.625 Y97.923 E.21718
G1 X167.023 Y97.99 E.01866
G1 X172.077 Y92.936 E.22013
G1 X171.543 Y92.936 E.01646
G1 X166.336 Y98.143 E.22677
G1 X165.783 Y98.329 E.01796
G1 X165.493 Y98.452 E.00971
G1 X171.008 Y92.936 E.24022
G1 X170.474 Y92.936 E.01646
G1 X104.354 Y159.056 E2.87955
G1 X103.82 Y159.056 E.01646
G1 X169.94 Y92.936 E2.87955
G1 X169.405 Y92.936 E.01646
G1 X103.285 Y159.055 E2.87955
G1 X102.751 Y159.055 E.01646
M73 P51 R16
G1 X168.871 Y92.936 E2.87954
G1 X168.336 Y92.936 E.01646
M73 P51 R15
G1 X102.217 Y159.055 E2.87954
G1 X101.682 Y159.055 E.01646
G1 X167.802 Y92.936 E2.87954
G1 X167.267 Y92.936 E.01646
G1 X101.148 Y159.055 E2.87953
G1 X100.614 Y159.055 E.01646
G1 X166.733 Y92.936 E2.87953
G1 X166.198 Y92.936 E.01646
G1 X100.079 Y159.055 E2.87953
G1 X99.545 Y159.055 E.01646
G1 X165.664 Y92.936 E2.87952
G1 X165.13 Y92.936 E.01646
G1 X99.01 Y159.055 E2.87952
G1 X98.476 Y159.055 E.01646
G1 X164.595 Y92.936 E2.87952
G1 X164.061 Y92.936 E.01646
G1 X97.942 Y159.055 E2.87952
G1 X97.407 Y159.055 E.01646
G1 X163.526 Y92.936 E2.87951
G1 X162.992 Y92.936 E.01646
G1 X96.873 Y159.055 E2.87951
G1 X96.339 Y159.055 E.01646
G1 X162.457 Y92.936 E2.87951
G1 X161.923 Y92.936 E.01646
G1 X95.804 Y159.054 E2.8795
G1 X95.27 Y159.054 E.01646
G1 X161.388 Y92.936 E2.8795
G1 X160.854 Y92.936 E.01646
G1 X94.735 Y159.054 E2.8795
G1 X94.201 Y159.054 E.01646
G1 X160.32 Y92.936 E2.87949
G1 X159.785 Y92.936 E.01646
G1 X93.667 Y159.054 E2.87949
G1 X93.132 Y159.054 E.01646
G1 X159.251 Y92.936 E2.87949
G1 X158.716 Y92.936 E.01646
G1 X92.598 Y159.054 E2.87948
G1 X92.064 Y159.054 E.01646
G1 X158.182 Y92.936 E2.87948
G1 X157.647 Y92.936 E.01646
G1 X91.529 Y159.054 E2.87948
G1 X90.995 Y159.054 E.01646
G1 X157.113 Y92.936 E2.87948
G1 X156.578 Y92.936 E.01646
G1 X90.46 Y159.054 E2.87947
G1 X89.926 Y159.054 E.01646
G1 X156.044 Y92.936 E2.87947
G1 X155.51 Y92.936 E.01646
G1 X89.392 Y159.054 E2.87947
G1 X88.857 Y159.053 E.01646
G1 X154.975 Y92.936 E2.87946
G1 X154.441 Y92.936 E.01646
G1 X88.323 Y159.053 E2.87946
G1 X87.789 Y159.053 E.01646
G1 X153.906 Y92.936 E2.87946
G1 X153.372 Y92.936 E.01646
G1 X87.254 Y159.053 E2.87945
G1 X86.72 Y159.053 E.01646
G1 X152.837 Y92.936 E2.87945
G1 X152.303 Y92.936 E.01646
G1 X86.185 Y159.053 E2.87945
G3 X85.713 Y158.991 I.04 J-2.126 E.0147
G1 X151.768 Y92.936 E2.87673
G1 X151.234 Y92.936 E.01646
G1 X93.455 Y150.715 E2.51632
G1 X93.618 Y150.362 E.01197
G1 X93.817 Y149.819 E.01781
G1 X150.7 Y92.936 E2.47729
G1 X150.165 Y92.936 E.01646
G1 X93.991 Y149.109 E2.44639
G1 X94.073 Y148.493 E.01914
G1 X149.631 Y92.936 E2.41956
G1 X149.096 Y92.936 E.01646
G1 X94.093 Y147.938 E2.3954
G1 X94.067 Y147.43 E.01568
G1 X148.562 Y92.936 E2.37326
G1 X148.027 Y92.936 E.01646
G1 X94.004 Y146.959 E2.35276
G1 X93.911 Y146.517 E.01391
G1 X147.493 Y92.936 E2.33351
G1 X146.958 Y92.936 E.01646
G1 X93.79 Y146.104 E2.31549
G1 X93.647 Y145.712 E.01283
G1 X146.424 Y92.936 E2.29845
G1 X145.89 Y92.936 E.01646
G1 X93.484 Y145.342 E2.2823
G1 X93.299 Y144.992 E.01217
G1 X145.355 Y92.936 E2.26709
G1 X144.821 Y92.936 E.01646
G1 X93.096 Y144.661 E2.25265
G1 X92.876 Y144.346 E.01182
G1 X144.286 Y92.936 E2.23894
G1 X143.752 Y92.936 E.01646
G1 X92.638 Y144.049 E2.22602
G1 X92.383 Y143.77 E.01165
G1 X143.217 Y92.936 E2.21384
G1 X142.683 Y92.936 E.01646
G1 X92.113 Y143.506 E2.20236
G1 X91.826 Y143.258 E.01167
G1 X142.148 Y92.936 E2.19158
G1 X141.614 Y92.936 E.01646
G1 X91.521 Y143.029 E2.18157
G1 X91.199 Y142.816 E.01188
G1 X141.08 Y92.936 E2.17234
G1 X140.545 Y92.936 E.01646
G1 X90.859 Y142.622 E2.16385
G1 X90.501 Y142.445 E.01229
G1 X140.011 Y92.936 E2.15616
G1 X139.476 Y92.936 E.01646
G1 X90.121 Y142.291 E2.14945
G1 X89.72 Y142.157 E.01301
G1 X138.942 Y92.936 E2.14363
G1 X138.407 Y92.936 E.01646
G1 X89.294 Y142.049 E2.13891
G1 X88.84 Y141.968 E.0142
G1 X137.873 Y92.936 E2.13541
G1 X137.339 Y92.936 E.01646
G1 X88.353 Y141.921 E2.13334
G1 X87.827 Y141.913 E.0162
G1 X136.804 Y92.936 E2.13297
G1 X136.27 Y92.936 E.01646
G1 X87.249 Y141.957 E2.13489
G1 X86.595 Y142.076 E.02047
G1 X135.735 Y92.936 E2.14008
G1 X135.201 Y92.936 E.01646
G1 X85.5 Y142.636 E2.1645
G1 X82.641 Y145.496 F30000
G1 F15000
G1 X77.804 Y150.332 E.21064
G2 X77.846 Y150.825 I5.39 J-.207 E.01524
G1 X82.081 Y146.59 E.18445
G1 X81.963 Y147.242 E.02042
G1 X77.935 Y151.27 E.17543
G2 X78.094 Y151.646 I2.834 J-.981 E.01256
G1 X81.918 Y147.821 E.16655
G1 X81.925 Y148.349 E.01626
G1 X78.309 Y151.965 E.15748
G2 X78.568 Y152.241 I3.494 J-3.031 E.01165
G1 X81.973 Y148.836 E.14828
G1 X82.053 Y149.29 E.01419
G1 X78.835 Y152.508 E.14015
G1 X79.103 Y152.775 E.01164
G1 X82.162 Y149.716 E.13324
G1 X82.295 Y150.117 E.01303
G1 X79.37 Y153.042 E.12737
G1 X79.637 Y153.309 E.01164
G1 X82.451 Y150.496 E.12253
G1 X82.626 Y150.855 E.01231
G1 X79.904 Y153.576 E.11852
G1 X80.172 Y153.843 E.01164
G1 X82.82 Y151.195 E.11533
G1 X83.033 Y151.516 E.01187
G1 X80.439 Y154.111 E.11298
G1 X80.706 Y154.378 E.01164
G1 X83.263 Y151.821 E.11136
G1 X83.51 Y152.109 E.01167
G1 X80.974 Y154.645 E.11045
G1 X81.241 Y154.912 E.01164
G1 X83.773 Y152.38 E.11027
G1 X84.054 Y152.633 E.01165
G1 X81.508 Y155.179 E.11086
G1 X81.776 Y155.446 E.01164
G1 X84.351 Y152.871 E.11216
G1 X84.664 Y153.092 E.01181
G1 X82.043 Y155.713 E.11416
G1 X82.31 Y155.981 E.01164
G1 X84.996 Y153.295 E.11697
G1 X85.347 Y153.478 E.01219
G1 X82.578 Y156.248 E.12061
G1 X82.845 Y156.515 E.01164
G1 X85.717 Y153.643 E.12506
G1 X86.107 Y153.787 E.01282
G1 X83.112 Y156.782 E.13045
M73 P52 R15
G1 X83.38 Y157.049 E.01164
G1 X86.523 Y153.906 E.13689
G1 X86.963 Y154.001 E.01385
G1 X83.647 Y157.316 E.1444
G1 X83.914 Y157.583 E.01164
G1 X87.435 Y154.062 E.15335
G1 X87.943 Y154.089 E.01566
G1 X84.181 Y157.85 E.16382
G1 X84.449 Y158.118 E.01164
G1 X88.496 Y154.07 E.17628
G1 X89.113 Y153.988 E.01915
G1 X84.716 Y158.385 E.19149
G2 X84.999 Y158.636 I1.159 J-1.018 E.01169
G1 X89.825 Y153.81 E.21018
G1 X90.233 Y153.668 E.01332
G1 X90.719 Y153.451 E.01638
G1 X85.205 Y158.964 E.24012
G1 X87.98 Y153.697 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X86.375 Y153.459 I.026 J-5.712 E.054
G1 X82.545 Y149.628 E.1797
G3 X82.342 Y148.63 I7.418 J-2.025 E.03382
G1 X88.634 Y142.338 E.29515
G2 X84.281 Y143.688 I-.629 J5.665 E.15553
G1 X92.316 Y151.724 E.37695
G2 X93.132 Y145.516 I-4.317 J-3.725 E.21987
G1 X85.521 Y153.127 E.35705
G3 X84.176 Y152.219 I2.493 J-5.143 E.054
G1 X77.606 Y149.996 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42083
G1 F15000
G1 X134.666 Y92.936 E2.48502
G1 X134.132 Y92.936 E.01646
G1 X77.722 Y149.346 E2.45669
G1 X77.681 Y148.852 E.01524
G1 X133.597 Y92.936 E2.4352
G1 X133.063 Y92.936 E.01646
G1 X77.64 Y148.359 E2.41372
G1 X77.598 Y147.866 E.01524
G1 X132.529 Y92.936 E2.39223
G1 X131.994 Y92.936 E.01646
G1 X77.557 Y147.372 E2.37075
G1 X77.516 Y146.879 E.01524
G1 X131.46 Y92.936 E2.34926
G1 X130.925 Y92.936 E.01646
G1 X77.475 Y146.386 E2.32778
G1 X77.434 Y145.892 E.01524
G1 X130.391 Y92.936 E2.3063
G1 X129.856 Y92.936 E.01646
G1 X77.393 Y145.399 E2.28481
G1 X77.352 Y144.906 E.01524
G1 X129.322 Y92.936 E2.26333
G1 X128.787 Y92.936 E.01646
G1 X77.311 Y144.412 E2.24184
G1 X77.27 Y143.919 E.01524
G1 X128.253 Y92.936 E2.22036
G1 X127.719 Y92.936 E.01646
G1 X77.228 Y143.426 E2.19887
G1 X77.187 Y142.932 E.01524
G1 X127.184 Y92.936 E2.17739
G1 X126.65 Y92.936 E.01646
G1 X77.146 Y142.439 E2.1559
G1 X77.105 Y141.946 E.01524
G1 X126.115 Y92.936 E2.13442
G1 X125.581 Y92.936 E.01646
G1 X77.064 Y141.452 E2.11293
G1 X77.023 Y140.959 E.01524
G1 X125.046 Y92.936 E2.09145
G1 X124.512 Y92.936 E.01646
G1 X76.982 Y140.466 E2.06996
G1 X76.941 Y139.972 E.01524
G1 X123.977 Y92.936 E2.04848
G1 X123.443 Y92.936 E.01646
G1 X76.9 Y139.479 E2.02699
G1 X76.858 Y138.986 E.01524
G1 X122.909 Y92.936 E2.00551
G1 X122.374 Y92.936 E.01646
G1 X76.817 Y138.492 E1.98402
G1 X76.776 Y137.999 E.01525
G1 X121.84 Y92.936 E1.96254
G1 X121.305 Y92.936 E.01646
G1 X76.735 Y137.506 E1.94105
G1 X76.694 Y137.012 E.01524
G1 X120.771 Y92.936 E1.91957
G1 X120.236 Y92.936 E.01646
G1 X76.653 Y136.519 E1.89808
G1 X76.612 Y136.026 E.01524
G1 X119.702 Y92.936 E1.8766
G1 X119.167 Y92.936 E.01646
G1 X76.571 Y135.532 E1.85511
G1 X76.53 Y135.039 E.01524
G1 X118.633 Y92.936 E1.83363
G1 X118.099 Y92.936 E.01646
G1 X76.488 Y134.546 E1.81214
G1 X76.447 Y134.052 E.01524
G1 X117.564 Y92.936 E1.79066
G1 X117.03 Y92.936 E.01646
G1 X76.406 Y133.559 E1.76917
G1 X76.365 Y133.066 E.01524
G1 X116.495 Y92.936 E1.74769
G1 X115.961 Y92.936 E.01646
G1 X76.324 Y132.572 E1.7262
G1 X76.283 Y132.079 E.01524
G1 X115.426 Y92.936 E1.70472
G1 X114.892 Y92.935 E.01646
G1 X76.242 Y131.586 E1.68323
G1 X76.201 Y131.092 E.01524
G1 X114.357 Y92.935 E1.66175
G1 X113.823 Y92.935 E.01646
G1 X76.16 Y130.599 E1.64027
G1 X76.118 Y130.106 E.01524
G1 X113.289 Y92.935 E1.61878
G1 X112.754 Y92.935 E.01646
G1 X76.077 Y129.612 E1.5973
G1 X76.036 Y129.119 E.01524
G1 X112.22 Y92.935 E1.57581
G1 X111.685 Y92.935 E.01646
G1 X75.995 Y128.626 E1.55433
G1 X75.954 Y128.132 E.01524
G1 X111.151 Y92.935 E1.53284
G1 X110.616 Y92.935 E.01646
G1 X75.913 Y127.639 E1.51136
G1 X75.872 Y127.146 E.01524
G1 X110.082 Y92.935 E1.48987
G1 X109.547 Y92.935 E.01646
G1 X75.831 Y126.652 E1.46839
G1 X75.79 Y126.159 E.01524
G1 X109.013 Y92.935 E1.4469
G1 X108.479 Y92.935 E.01646
G1 X75.748 Y125.666 E1.42542
G1 X75.707 Y125.172 E.01524
G1 X107.944 Y92.935 E1.40393
G1 X107.41 Y92.935 E.01646
G1 X93.245 Y107.1 E.61686
G1 X93.494 Y106.639 E.01613
G1 X93.728 Y106.083 E.01856
G1 X106.875 Y92.935 E.57259
G1 X106.341 Y92.935 E.01646
G1 X93.946 Y105.33 E.5398
G1 X94.055 Y104.687 E.02008
G1 X105.806 Y92.935 E.5118
G1 X105.272 Y92.935 E.01646
G1 X94.092 Y104.115 E.48689
G1 X94.08 Y103.593 E.01608
G1 X104.738 Y92.935 E.46415
G1 X104.203 Y92.935 E.01646
G1 X94.029 Y103.109 E.44308
G1 X93.944 Y102.66 E.01408
G1 X103.669 Y92.935 E.42352
G1 X103.134 Y92.935 E.01646
G1 X93.833 Y102.236 E.40506
G1 X93.697 Y101.838 E.01296
G1 X102.6 Y92.935 E.38772
G1 X102.065 Y92.935 E.01646
G1 X93.539 Y101.462 E.37133
G1 X93.362 Y101.104 E.01228
G1 X101.531 Y92.935 E.35575
G1 X100.996 Y92.935 E.01646
G1 X93.165 Y100.767 E.34108
G1 X92.95 Y100.448 E.01186
G1 X100.462 Y92.935 E.32717
G1 X99.928 Y92.935 E.01646
G1 X92.718 Y100.145 E.31398
G1 X92.47 Y99.858 E.01167
G1 X99.393 Y92.935 E.3015
G1 X98.859 Y92.935 E.01646
G1 X92.204 Y99.59 E.28983
G1 X91.921 Y99.338 E.01166
G1 X98.324 Y92.935 E.27885
G1 X97.79 Y92.935 E.01646
G1 X91.623 Y99.102 E.26858
G1 X91.308 Y98.883 E.01182
G1 X97.255 Y92.935 E.25903
G1 X96.721 Y92.935 E.01646
G1 X90.973 Y98.683 E.25033
G1 X90.62 Y98.502 E.01222
G1 X96.186 Y92.935 E.24242
G1 X95.652 Y92.935 E.01646
G1 X90.249 Y98.339 E.23531
G1 X89.854 Y98.199 E.01289
G1 X95.118 Y92.935 E.22922
G1 X94.583 Y92.935 E.01646
G1 X89.437 Y98.082 E.22413
G1 X88.993 Y97.991 E.01396
G1 X94.049 Y92.935 E.22019
M73 P53 R15
G1 X93.514 Y92.935 E.01646
G1 X88.516 Y97.933 E.21766
G1 X88.004 Y97.911 E.0158
G1 X92.98 Y92.935 E.2167
G1 X92.445 Y92.935 E.01646
G1 X87.444 Y97.937 E.21782
G1 X86.818 Y98.028 E.01946
G1 X91.911 Y92.935 E.22178
G1 X91.376 Y92.935 E.01646
G1 X86.094 Y98.217 E.23003
G1 X85.504 Y98.447 E.01952
G1 X85.163 Y98.614 E.01169
G1 X90.842 Y92.935 E.24732
G1 X90.308 Y92.935 E.01646
G1 X74.351 Y108.892 E.69493
G1 X74.392 Y109.386 E.01524
G1 X82.619 Y101.158 E.3583
G1 X82.394 Y101.63 E.01609
G1 X82.223 Y102.088 E.01506
G1 X74.433 Y109.879 E.33929
G1 X74.474 Y110.372 E.01524
G1 X82.031 Y102.816 E.32909
G1 X81.941 Y103.44 E.01943
G1 X74.515 Y110.866 E.32338
G1 X74.556 Y111.359 E.01524
G1 X81.914 Y104.001 E.32043
G1 X81.937 Y104.513 E.01576
G1 X74.597 Y111.852 E.31965
G1 X74.638 Y112.346 E.01524
G1 X81.996 Y104.988 E.32043
G1 X82.086 Y105.432 E.01396
G1 X74.68 Y112.839 E.32256
G1 X74.721 Y113.332 E.01524
G1 X82.203 Y105.85 E.32585
G1 X82.344 Y106.243 E.01287
G1 X74.762 Y113.826 E.33021
G1 X74.803 Y114.319 E.01524
G1 X82.505 Y106.617 E.33544
G1 X82.688 Y106.969 E.01221
G1 X74.844 Y114.812 E.3416
G1 X74.885 Y115.306 E.01524
G1 X82.889 Y107.302 E.34856
G1 X83.107 Y107.618 E.01183
G1 X74.926 Y115.799 E.35627
G1 X74.967 Y116.292 E.01524
G1 X83.341 Y107.918 E.3647
G1 X83.595 Y108.199 E.01165
G1 X75.008 Y116.786 E.37394
G1 X75.05 Y117.279 E.01524
G1 X83.864 Y108.464 E.38388
G1 X84.149 Y108.714 E.01166
G1 X75.091 Y117.772 E.39451
G1 X75.132 Y118.266 E.01524
G1 X84.451 Y108.946 E.40586
G1 X84.772 Y109.16 E.01187
G1 X75.173 Y118.759 E.41803
G1 X75.214 Y119.252 E.01524
G1 X85.11 Y109.357 E.43096
G1 X85.465 Y109.535 E.01226
G1 X75.255 Y119.746 E.44467
G1 X75.296 Y120.239 E.01524
G1 X85.843 Y109.693 E.4593
G1 X86.242 Y109.828 E.01298
G1 X75.337 Y120.732 E.47489
G1 X75.378 Y121.226 E.01524
G1 X86.663 Y109.941 E.49146
G1 X87.115 Y110.023 E.01414
G1 X75.42 Y121.719 E.50935
G1 X75.461 Y122.212 E.01524
G1 X87.597 Y110.076 E.52854
G1 X88.119 Y110.089 E.01607
G1 X75.502 Y122.706 E.54947
G1 X75.543 Y123.199 E.01524
G1 X88.691 Y110.05 E.57263
G1 X89.333 Y109.943 E.02003
G1 X75.584 Y123.692 E.59878
G1 X75.625 Y124.186 E.01524
G1 X90.091 Y109.72 E.62998
G1 X90.513 Y109.55 E.01403
G1 X91.103 Y109.242 E.02051
G1 X75.509 Y124.836 E.67914
G1 X74.152 Y108.556 F30000
G1 F15000
G1 X89.773 Y92.935 E.68029
G1 X89.239 Y92.935 E.01646
G1 X74.268 Y107.906 E.65196
G1 X74.227 Y107.412 E.01524
G1 X88.704 Y92.935 E.63048
G1 X88.17 Y92.935 E.01646
G1 X74.186 Y106.919 E.60899
G1 X74.145 Y106.426 E.01524
G1 X87.635 Y92.935 E.58751
G1 X87.101 Y92.935 E.01646
G1 X74.104 Y105.932 E.56602
G1 X74.063 Y105.439 E.01524
G1 X86.566 Y92.935 E.54454
G1 X86.032 Y92.935 E.01646
G1 X74.025 Y104.943 E.52293
G3 X74.061 Y104.372 I2.954 J-.098 E.01764
G1 X85.498 Y92.935 E.49807
G1 X84.963 Y92.935 E.01646
G1 X74.589 Y103.31 E.45182
G1 X75.658 Y101.707 E.05934
G1 X84.429 Y92.935 E.38199
G1 X83.894 Y92.935 E.01646
G1 X76.726 Y100.103 E.31216
G1 X77.795 Y98.5 E.05934
G1 X83.36 Y92.935 E.24234
G1 X82.825 Y92.935 E.01646
G1 X78.864 Y96.897 E.17251
G1 X79.933 Y95.293 E.05934
G1 X82.258 Y92.968 E.10125
G2 X81.159 Y93.533 I.4 J2.13 E.03859
G1 X80.39 Y94.302 E.03347
G1 X84.176 Y99.781 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X85.521 Y98.873 I3.837 J4.235 E.054
G1 X93.132 Y106.484 E.35705
G2 X92.316 Y100.276 I-5.133 J-2.483 E.21987
G1 X84.281 Y108.312 E.37695
G2 X88.634 Y109.662 I3.725 J-4.317 E.15555
G1 X82.342 Y103.37 E.29517
G3 X82.545 Y102.372 I7.63 J1.028 E.03382
G1 X86.375 Y98.541 E.1797
G3 X87.98 Y98.303 I1.631 J5.473 E.054
G1 X162.844 Y101.101 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42083
G1 F15000
G1 X104.888 Y159.056 E2.52398
G1 X105.423 Y159.056 E.01646
G1 X162.149 Y102.329 E2.47047
G1 X161.995 Y103.018 E.02174
G1 X105.957 Y159.056 E2.44047
G1 X106.492 Y159.056 E.01646
G1 X161.927 Y103.621 E2.41424
G1 X161.918 Y104.164 E.01674
G1 X107.026 Y159.056 E2.39057
G1 X107.56 Y159.056 E.01646
G1 X161.951 Y104.665 E2.36876
G1 X162.021 Y105.13 E.01447
G1 X108.095 Y159.056 E2.34852
G1 X108.629 Y159.056 E.01646
G1 X162.12 Y105.566 E2.32955
G1 X162.245 Y105.975 E.01318
G1 X109.163 Y159.056 E2.31172
G1 X109.698 Y159.056 E.01646
G1 X162.391 Y106.363 E2.29482
G1 X162.561 Y106.728 E.01239
G1 X110.232 Y159.056 E2.27893
G1 X110.767 Y159.057 E.01646
G1 X162.749 Y107.074 E2.26385
G1 X162.954 Y107.403 E.01194
G1 X111.301 Y159.057 E2.24953
G1 X111.835 Y159.057 E.01646
G1 X163.178 Y107.714 E2.23601
G1 X163.42 Y108.007 E.01169
G1 X112.37 Y159.057 E2.22325
G1 X112.904 Y159.057 E.01646
G1 X163.677 Y108.284 E2.2112
G1 X163.951 Y108.545 E.01164
G1 X113.438 Y159.057 E2.19983
G1 X113.973 Y159.057 E.01646
G1 X164.242 Y108.788 E2.18923
G1 X164.55 Y109.014 E.01178
G1 X114.507 Y159.057 E2.1794
G1 X115.042 Y159.057 E.01646
G1 X164.875 Y109.223 E2.17028
G1 X165.218 Y109.415 E.01209
G1 X115.576 Y159.057 E2.16192
G1 X116.11 Y159.057 E.01646
G1 X165.581 Y109.586 E2.15449
G1 X165.965 Y109.737 E.01269
G1 X116.645 Y159.057 E2.14792
G1 X117.179 Y159.057 E.01646
G1 X166.37 Y109.867 E2.14228
G1 X166.802 Y109.969 E.01368
G1 X117.713 Y159.057 E2.13784
G1 X118.248 Y159.058 E.01646
G1 X167.261 Y110.045 E2.13453
G1 X167.756 Y110.084 E.0153
G1 X118.782 Y159.058 E2.13283
G1 X119.317 Y159.058 E.01646
G1 X168.292 Y110.082 E2.13292
G1 X168.884 Y110.025 E.0183
G1 X119.851 Y159.058 E2.1354
G1 X120.385 Y159.058 E.01646
G1 X169.555 Y109.888 E2.14136
G1 X169.948 Y109.772 E.01262
G1 X170.365 Y109.612 E.01375
G1 X120.92 Y159.058 E2.15338
G1 X121.454 Y159.058 E.01646
G1 X180.341 Y100.171 E2.56455
G1 X180.578 Y100.468 E.01171
G1 X121.988 Y159.058 E2.55162
G1 X122.523 Y159.058 E.01646
G1 X180.816 Y100.765 E2.53869
G1 X181.053 Y101.062 E.01171
G1 X123.057 Y159.058 E2.52575
G1 X123.591 Y159.058 E.01646
G1 X181.291 Y101.359 E2.51282
G1 X181.528 Y101.656 E.01171
G1 X124.126 Y159.058 E2.49989
G1 X124.66 Y159.058 E.01646
G1 X181.736 Y101.983 E2.48567
G3 X181.895 Y102.358 I-2.01 J1.076 E.01257
G1 X125.195 Y159.059 E2.46934
G1 X125.729 Y159.059 E.01646
G1 X181.974 Y102.813 E2.44951
G3 X181.954 Y103.368 I-2.353 J.192 E.01713
G1 X126.263 Y159.059 E2.42535
G1 X126.798 Y159.059 E.01646
G1 X181.907 Y103.949 E2.40005
G1 X181.861 Y104.53 E.01795
G1 X127.332 Y159.059 E2.37476
G1 X127.866 Y159.059 E.01646
G1 X181.815 Y105.111 E2.34947
G1 X181.768 Y105.692 E.01795
G1 X128.401 Y159.059 E2.32417
G1 X128.935 Y159.059 E.01646
G1 X181.722 Y106.273 E2.29888
G1 X181.675 Y106.853 E.01795
G1 X129.47 Y159.059 E2.27358
G1 X130.004 Y159.059 E.01646
G1 X181.629 Y107.434 E2.24829
G1 X181.582 Y108.015 E.01795
G1 X130.538 Y159.059 E2.22299
G1 X131.073 Y159.059 E.01646
G1 X181.536 Y108.596 E2.1977
G1 X181.489 Y109.177 E.01795
G1 X131.607 Y159.059 E2.1724
G1 X132.141 Y159.059 E.01646
G1 X181.443 Y109.758 E2.14711
G1 X181.397 Y110.339 E.01795
G1 X132.676 Y159.06 E2.12182
G1 X133.21 Y159.06 E.01646
G1 X181.35 Y110.92 E2.09652
G1 X181.304 Y111.501 E.01795
G1 X133.745 Y159.06 E2.07123
G1 X134.279 Y159.06 E.01646
G1 X181.257 Y112.081 E2.04593
G1 X181.211 Y112.662 E.01795
G1 X134.813 Y159.06 E2.02064
G1 X135.348 Y159.06 E.01646
G1 X181.164 Y113.243 E1.99534
G1 X181.118 Y113.824 E.01795
G1 X135.882 Y159.06 E1.97005
G1 X136.416 Y159.06 E.01646
G1 X181.072 Y114.405 E1.94475
G1 X181.025 Y114.986 E.01795
G1 X136.951 Y159.06 E1.91946
G1 X137.485 Y159.06 E.01646
G1 X180.979 Y115.567 E1.89417
G1 X180.932 Y116.148 E.01795
G1 X138.02 Y159.06 E1.86887
G1 X138.554 Y159.06 E.01646
G1 X180.886 Y116.728 E1.84358
G1 X180.839 Y117.309 E.01795
G1 X139.088 Y159.06 E1.81828
G1 X139.623 Y159.061 E.01646
G1 X180.793 Y117.89 E1.79299
G1 X180.746 Y118.471 E.01795
G1 X140.157 Y159.061 E1.76769
G1 X140.691 Y159.061 E.01646
G1 X180.7 Y119.052 E1.7424
M73 P54 R15
G1 X180.654 Y119.633 E.01795
G1 X141.226 Y159.061 E1.7171
G1 X141.76 Y159.061 E.01646
G1 X180.607 Y120.214 E1.69181
G1 X180.561 Y120.795 E.01795
G1 X142.294 Y159.061 E1.66651
G1 X142.829 Y159.061 E.01646
G1 X180.514 Y121.376 E1.64122
G1 X180.468 Y121.956 E.01795
G1 X143.363 Y159.061 E1.61593
M73 P54 R14
G1 X143.898 Y159.061 E.01646
G1 X180.421 Y122.537 E1.59063
G1 X180.375 Y123.118 E.01795
G1 X144.432 Y159.061 E1.56534
G1 X144.966 Y159.061 E.01646
G1 X180.329 Y123.699 E1.54004
G1 X180.282 Y124.28 E.01795
G1 X145.501 Y159.061 E1.51475
G1 X146.035 Y159.061 E.01646
G1 X180.236 Y124.861 E1.48945
G1 X180.189 Y125.442 E.01795
G1 X146.569 Y159.061 E1.46416
G1 X147.104 Y159.062 E.01646
G1 X180.143 Y126.023 E1.43886
G1 X180.096 Y126.603 E.01795
G1 X147.469 Y159.231 E1.42096
G1 X171.828 Y152.224 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X170.482 Y153.13 I-3.836 J-4.245 E.054
G1 X162.87 Y145.528 E.35685
G2 X163.689 Y151.719 I5.173 J2.466 E.21909
G1 X171.723 Y143.684 E.37692
G2 X167.367 Y142.339 I-3.721 J4.321 E.15561
G1 X173.666 Y148.638 E.2955
G3 X173.467 Y149.616 I-7.674 J-1.045 E.03314
G1 X169.621 Y153.463 E.18046
G3 X168.015 Y153.697 I-1.618 J-5.483 E.054
G1 X170.618 Y159.063 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42083
G1 F15000
G1 X177.626 Y152.052 E.30526
G2 X178.13 Y151.017 I-1.591 J-1.415 E.03591
G1 X170.12 Y159.026 E.34883
G3 X169.547 Y159.065 I-.465 J-2.669 E.01771
G1 X178.193 Y150.42 E.3765
G1 X178.239 Y149.839 E.01795
G1 X169.013 Y159.065 E.40179
G1 X168.479 Y159.065 E.01646
G1 X178.285 Y149.258 E.42709
G1 X178.332 Y148.677 E.01795
G1 X167.944 Y159.064 E.45238
G1 X167.41 Y159.064 E.01646
G1 X178.378 Y148.096 E.47767
G1 X178.425 Y147.515 E.01795
G1 X166.876 Y159.064 E.50297
G1 X166.341 Y159.064 E.01646
G1 X178.471 Y146.934 E.52826
G1 X178.518 Y146.353 E.01795
G1 X165.807 Y159.064 E.55356
G1 X165.272 Y159.064 E.01646
G1 X171.081 Y153.255 E.25297
G1 X170.513 Y153.55 E.01971
G1 X170.077 Y153.725 E.01447
G1 X164.738 Y159.064 E.23251
G1 X164.204 Y159.064 E.01646
G1 X169.322 Y153.946 E.22291
G1 X168.682 Y154.051 E.01999
G1 X163.669 Y159.064 E.2183
G1 X163.135 Y159.064 E.01646
G1 X168.11 Y154.089 E.21666
G1 X167.589 Y154.076 E.01606
G1 X162.601 Y159.064 E.21724
G1 X162.066 Y159.064 E.01646
G1 X167.108 Y154.022 E.21955
G1 X166.656 Y153.939 E.01414
G1 X161.532 Y159.064 E.22316
G1 X160.998 Y159.063 E.01646
G1 X166.235 Y153.826 E.22809
G1 X165.836 Y153.69 E.01297
G1 X160.463 Y159.063 E.234
G1 X159.929 Y159.063 E.01646
G1 X165.46 Y153.532 E.24087
G1 X165.105 Y153.353 E.01225
G1 X159.394 Y159.063 E.24868
G1 X158.86 Y159.063 E.01646
G1 X164.766 Y153.157 E.25722
G1 X164.446 Y152.943 E.01187
G1 X158.326 Y159.063 E.26654
G1 X157.791 Y159.063 E.01646
G1 X164.145 Y152.71 E.27669
G1 X163.86 Y152.46 E.01166
G1 X157.257 Y159.063 E.28755
G1 X156.723 Y159.063 E.01646
G1 X163.591 Y152.195 E.29911
G1 X163.338 Y151.913 E.01165
G1 X156.188 Y159.063 E.31136
G1 X155.654 Y159.063 E.01646
G1 X163.103 Y151.613 E.32443
G1 X162.885 Y151.297 E.01183
G1 X155.119 Y159.063 E.33821
G1 X154.585 Y159.063 E.01646
G1 X162.685 Y150.963 E.35274
G1 X162.503 Y150.611 E.01222
G1 X154.051 Y159.063 E.36808
G1 X153.516 Y159.062 E.01646
G1 X162.342 Y150.237 E.38434
G1 X162.201 Y149.844 E.01287
G1 X152.982 Y159.062 E.40148
G1 X152.448 Y159.062 E.01646
G1 X162.084 Y149.425 E.41969
G1 X161.995 Y148.981 E.01397
G1 X151.913 Y159.062 E.43905
G1 X151.379 Y159.062 E.01646
G1 X161.936 Y148.505 E.45979
G1 X161.914 Y147.993 E.01578
G1 X150.844 Y159.062 E.48208
G1 X150.31 Y159.062 E.01646
G1 X161.941 Y147.431 E.50654
G1 X162.032 Y146.805 E.01947
G1 X149.776 Y159.062 E.53379
G1 X149.241 Y159.062 E.01646
G1 X162.228 Y146.075 E.56557
G1 X162.394 Y145.63 E.01464
G1 X162.628 Y145.141 E.0167
G1 X148.707 Y159.062 E.60627
G1 X148.173 Y159.062 E.01646
G1 X180.05 Y127.184 E1.38828
G1 X180.004 Y127.765 E.01795
G1 X165.144 Y142.625 E.64713
G1 X165.504 Y142.446 E.01236
G1 X166.082 Y142.221 E.01911
G1 X179.957 Y128.346 E.60427
G1 X179.911 Y128.927 E.01795
G1 X166.808 Y142.03 E.57065
G1 X167.434 Y141.938 E.0195
G1 X179.864 Y129.508 E.54134
G1 X179.818 Y130.089 E.01795
G1 X167.995 Y141.911 E.51488
G1 X168.508 Y141.932 E.01582
G1 X179.771 Y130.67 E.4905
G1 X179.725 Y131.251 E.01795
G1 X168.985 Y141.99 E.46772
G1 X169.43 Y142.08 E.01397
G1 X179.678 Y131.831 E.44633
G1 X179.632 Y132.412 E.01795
G1 X169.848 Y142.197 E.42612
G1 X170.243 Y142.336 E.0129
G1 X179.586 Y132.993 E.40688
M73 P55 R14
G1 X179.539 Y133.574 E.01795
G1 X170.614 Y142.499 E.38868
G1 X170.967 Y142.68 E.01222
G1 X179.493 Y134.155 E.37129
G1 X179.446 Y134.736 E.01795
G1 X171.302 Y142.88 E.35467
G1 X171.618 Y143.099 E.01183
G1 X179.4 Y135.317 E.33891
G1 X179.353 Y135.898 E.01795
G1 X171.917 Y143.334 E.32388
G1 X172.199 Y143.586 E.01166
G1 X179.307 Y136.478 E.30955
G1 X179.261 Y137.059 E.01795
G1 X172.466 Y143.854 E.29591
G1 X172.714 Y144.14 E.01167
G1 X179.214 Y137.64 E.28308
G1 X179.168 Y138.221 E.01795
G1 X172.946 Y144.443 E.27096
G1 X173.161 Y144.762 E.01186
G1 X179.121 Y138.802 E.25956
G1 X179.075 Y139.383 E.01795
G1 X173.359 Y145.099 E.24892
G1 X173.536 Y145.456 E.01228
G1 X179.028 Y139.964 E.23918
G1 X178.982 Y140.545 E.01795
G1 X173.694 Y145.832 E.23027
G1 X173.831 Y146.23 E.01295
G1 X178.935 Y141.125 E.22228
G1 X178.889 Y141.706 E.01795
G1 X173.942 Y146.653 E.21543
G1 X174.028 Y147.102 E.01406
G1 X178.843 Y142.287 E.20967
G1 X178.796 Y142.868 E.01795
G1 X174.079 Y147.585 E.20543
G1 X174.092 Y148.106 E.01606
G1 X178.75 Y143.449 E.20283
G1 X178.703 Y144.03 E.01795
G1 X174.056 Y148.677 E.2024
G1 X173.949 Y149.319 E.02003
G1 X178.657 Y144.611 E.20505
G1 X178.61 Y145.192 E.01795
G1 X173.732 Y150.07 E.21245
G1 X173.494 Y150.639 E.01899
G1 X173.257 Y151.079 E.01541
G1 X178.749 Y145.588 E.23917
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X177.335 Y147.002 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 9/23
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2 I1.215 J-.076 P1  F30000
G1 X173.919 Y92.631 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X175.44 Y93.508 I-.369 J2.396 E.05959
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.907 J1.515 E.06045
G1 X178.493 Y150.844 E1.58735
G3 X177.793 Y152.36 I-2.403 J-.19 E.05656
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29697
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06293
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.435 E.06293
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.703 J-1.706 E.05632
G1 X73.692 Y105.003 E1.52604
G3 X74.09 Y103.458 I2.455 J-.192 E.05389
G1 X80.611 Y93.676 E.38997
G3 X82.618 Y92.602 I2.01 J1.344 E.07862
G1 X173.584 Y92.603 E3.01751
G3 X173.859 Y92.622 I-.034 J2.424 E.00917
M204 S250
G1 X173.972 Y92.241 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X173.977 Y92.243 E.00017
G3 X175.743 Y93.259 I-.429 J2.787 E.06404
G1 X182.096 Y101.201 E.3125
G3 X182.7 Y103.171 I-2.22 J1.758 E.0648
G1 X178.883 Y150.88 E1.47066
G3 X178.074 Y152.634 I-2.794 J-.226 E.06061
G1 X171.736 Y158.971 E.27539
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.832 E.06744
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I1.983 J-1.98 E.06034
G1 X73.301 Y105.029 E1.41392
G3 X73.761 Y103.244 I2.855 J-.216 E.05766
G1 X80.287 Y93.455 E.36152
G3 X82.613 Y92.21 I2.335 J1.568 E.08436
G1 X173.589 Y92.211 E2.79544
G1 X173.912 Y92.236 E.00998
; WIPE_START
M204 S10000
G1 X173.977 Y92.243 E-.02474
G1 X174.25 Y92.296 E-.10557
G1 X174.515 Y92.378 E-.10549
G1 X174.771 Y92.485 E-.10547
G1 X175.015 Y92.618 E-.10552
G1 X175.353 Y92.861 E-.1581
G1 X175.557 Y93.049 E-.10553
G1 X175.643 Y93.147 E-.04958
; WIPE_END
G1 E-.04 F1800
G1 X170.035 Y98.324 Z2.2 F30000
G1 X104.264 Y159.04 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.636 Y159.04 E.05401
G1 X168.725 Y92.951 E3.10038
G1 X171.711 Y92.951 E.09904
G1 X181.953 Y103.193 E.48048
G2 X181.957 Y102.747 I-1.883 J-.239 E.01483
G1 X125.66 Y159.044 E2.64097
G1 X122.663 Y159.043 E.09942
G1 X74.534 Y110.914 E2.25784
G1 X74.493 Y110.423 E.01634
G1 X91.966 Y92.95 E.81968
G1 X94.95 Y92.95 E.099
G1 X161.048 Y159.048 E3.1008
G1 X164.035 Y159.049 E.09906
G1 X178.657 Y144.427 E.68594
G1 X178.544 Y145.84 E.04701
G1 X125.654 Y92.951 E2.48114
G1 X122.67 Y92.951 E.09901
G1 X76.855 Y138.765 E2.14925
G1 X76.628 Y136.035 E.09087
G1 X99.632 Y159.04 E1.07919
G1 X94.961 Y159.039 E.15496
G1 X161.049 Y92.951 E3.10034
G1 X164.035 Y92.951 E.09903
G1 X181.385 Y110.301 E.81392
G1 X181.324 Y111.056 E.02511
G1 X133.335 Y159.045 E2.25126
G1 X130.34 Y159.044 E.09935
G1 X74.606 Y103.31 E2.61459
G1 X75.959 Y101.282 E.08087
G1 X84.29 Y92.95 E.39084
G1 X87.274 Y92.95 E.09899
G1 X153.371 Y159.047 E3.10075
G1 X156.36 Y159.048 E.09913
G1 X179.323 Y136.084 E1.07727
G1 X179.112 Y138.732 E.08811
G1 X133.33 Y92.951 E2.14769
G1 X130.345 Y92.951 E.09902
G1 X77.446 Y145.851 E2.48164
G1 X77.325 Y144.409 E.04799
G1 X91.955 Y159.039 E.68631
G1 X87.286 Y159.038 E.15489
G1 X153.373 Y92.951 E3.10029
G1 X156.359 Y92.951 E.09903
G1 X180.816 Y117.409 E1.14737
G1 X180.657 Y119.398 E.06621
G1 X141.01 Y159.046 E1.85993
G1 X138.017 Y159.045 E.09927
G1 X77.677 Y98.705 E2.8307
G1 X80.747 Y94.099 E.18361
G1 X145.694 Y159.046 E3.04681
G1 X148.685 Y159.047 E.0992
G1 X179.99 Y127.741 E1.4686
G1 X180.248 Y124.516 E.10732
G1 X148.683 Y92.951 E1.48081
G1 X145.697 Y92.951 E.09903
G1 X82.5 Y156.148 E2.96473
G1 X78.66 Y152.312 E.18005
G1 X138.021 Y92.951 E2.78475
G1 X141.007 Y92.951 E.09902
G1 X179.68 Y131.624 E1.81425
G1 X179.55 Y133.247 E.05401
G1 X76.4 Y133.302 F30000
G1 F15476.087
G1 X76.265 Y131.68 E.05401
G1 X114.994 Y92.951 E1.81686
G1 X117.978 Y92.951 E.09901
G1 X177.342 Y152.314 E2.78488
G1 X173.505 Y156.154 E.18005
G1 X110.302 Y92.951 E2.96498
G1 X107.318 Y92.951 E.09901
G1 X75.674 Y124.594 E1.48447
G1 X75.93 Y127.661 E.1021
G1 X107.309 Y159.041 E1.47207
G1 X110.311 Y159.041 E.09956
G1 X175.372 Y93.98 E3.05214
G1 X178.782 Y98.246 E.18116
G1 X117.985 Y159.042 E2.85209
G1 X114.986 Y159.042 E.09949
G1 X75.232 Y119.288 E1.86495
G1 X75.084 Y117.509 E.05922
G1 X99.642 Y92.95 E1.15207
G1 X102.626 Y92.95 E.099
G1 X168.725 Y159.05 E3.10084
G2 X170.345 Y158.959 I.505 J-5.495 E.05399
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X169.959 Y159.039 E-.14981
G1 X168.725 Y159.05 E-.46859
G1 X168.462 Y158.786 E-.1416
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/23
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.2 I1.213 J.1 P1  F30000
G1 X173.914 Y92.64 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X174.153 Y92.677 E.00801
G3 X175.44 Y93.508 I-.594 J2.331 E.05172
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.922 J1.52 E.06042
G1 X178.493 Y150.844 E1.58733
G3 X177.793 Y152.36 I-2.403 J-.19 E.05658
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29697
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06292
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.435 E.06293
G1 X78.212 Y152.356 E.29716
G3 X77.513 Y150.848 I1.702 J-1.706 E.0563
G1 X73.692 Y105 E1.52613
G3 X74.09 Y103.458 I2.461 J-.188 E.0538
G1 X80.611 Y93.676 E.38997
G3 X82.618 Y92.602 I2.01 J1.344 E.07862
G1 X173.682 Y92.605 E3.02076
G1 X173.855 Y92.631 E.0058
M204 S250
G1 X173.974 Y92.241 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X173.977 Y92.241 E.0001
G3 X175.743 Y93.259 I-.419 J2.767 E.06409
G1 X182.096 Y101.201 E.3125
G3 X182.7 Y103.171 I-2.237 J1.763 E.06477
G1 X178.883 Y150.88 E1.47066
G3 X178.073 Y152.634 I-2.794 J-.226 E.06062
G1 X171.736 Y158.971 E.27537
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.832 E.06744
G1 X77.931 Y152.63 E.27555
G3 X77.122 Y150.885 I1.983 J-1.98 E.06032
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.86 J-.214 E.05762
G1 X80.287 Y93.454 E.36153
G3 X82.613 Y92.21 I2.335 J1.568 E.08436
G1 X173.701 Y92.214 E2.7989
G1 X173.914 Y92.235 E.00658
; WIPE_START
M204 S10000
G1 X173.977 Y92.241 E-.02407
G1 X174.25 Y92.296 E-.10553
G1 X174.515 Y92.378 E-.1055
G1 X174.862 Y92.532 E-.14436
G1 X175.132 Y92.693 E-.11933
G1 X175.353 Y92.861 E-.10549
G1 X175.557 Y93.049 E-.10559
G1 X175.645 Y93.148 E-.05013
; WIPE_END
G1 E-.04 F1800
G1 X176.384 Y100.745 Z2.4 F30000
G1 X179.55 Y133.247 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.68 Y131.624 E.05401
G1 X141.008 Y92.952 E1.81418
G1 X138.02 Y92.952 E.09912
G1 X78.66 Y152.312 E2.78468
G1 X82.5 Y156.148 E.18005
G1 X145.696 Y92.953 E2.96465
G1 X148.684 Y92.953 E.09914
G1 X180.248 Y124.516 E1.48073
G1 X179.99 Y127.741 E.10732
G1 X148.685 Y159.047 E1.4686
G1 X145.694 Y159.046 E.0992
G1 X80.747 Y94.099 E3.04681
G1 X77.677 Y98.705 E.18361
G1 X138.017 Y159.045 E2.8307
G1 X141.01 Y159.046 E.09927
G1 X180.657 Y119.398 E1.85994
G1 X180.816 Y117.409 E.06621
G1 X156.361 Y92.953 E1.14727
G1 X153.371 Y92.953 E.09916
G1 X87.286 Y159.038 E3.10021
G1 X91.955 Y159.039 E.1549
G1 X77.325 Y144.409 E.68632
M73 P56 R14
G1 X77.446 Y145.851 E.04799
G1 X130.344 Y92.952 E2.48158
G1 X133.332 Y92.952 E.09911
G1 X179.112 Y138.732 E2.14763
G1 X179.323 Y136.084 E.08811
G1 X156.36 Y159.048 E1.07727
G1 X153.371 Y159.047 E.09913
G1 X87.275 Y92.95 E3.10074
G1 X84.29 Y92.95 E.099
G1 X75.959 Y101.282 E.39084
G1 X74.606 Y103.31 E.08087
G1 X130.34 Y159.044 E2.6146
G1 X133.335 Y159.045 E.09934
G1 X181.324 Y111.056 E2.25127
G1 X181.385 Y110.301 E.02511
G1 X164.037 Y92.953 E.81382
G1 X161.047 Y92.953 E.09918
G1 X94.961 Y159.039 E3.10025
G1 X99.632 Y159.04 E.15497
G1 X76.628 Y136.035 E1.0792
G1 X76.855 Y138.765 E.09087
G1 X122.669 Y92.952 E2.1492
G1 X125.656 Y92.952 E.09909
G1 X178.544 Y145.84 E2.48108
G1 X178.656 Y144.427 E.04701
G1 X164.035 Y159.049 E.68594
G1 X161.048 Y159.048 E.09906
G1 X94.951 Y92.951 E3.10078
G1 X91.966 Y92.951 E.09902
G1 X74.493 Y110.423 E.81967
G1 X74.534 Y110.914 E.01634
G1 X122.663 Y159.043 E2.25784
G1 X125.66 Y159.044 E.09941
G1 X181.957 Y102.747 E2.64098
G3 X181.953 Y103.193 I-1.886 J.207 E.01483
G1 X171.713 Y92.953 E.48037
G1 X168.723 Y92.953 E.09919
G1 X102.636 Y159.04 E3.10028
G1 X104.264 Y159.041 E.05401
G1 X170.345 Y158.959 F30000
G1 F15476.087
G3 X168.725 Y159.05 I-1.116 J-5.441 E.05398
G1 X102.627 Y92.951 E3.10082
G1 X99.641 Y92.951 E.09904
G1 X75.084 Y117.509 E1.15205
G1 X75.232 Y119.288 E.05922
G1 X114.986 Y159.042 E1.86496
G1 X117.985 Y159.043 E.09948
G1 X178.782 Y98.246 E2.8521
G1 X175.372 Y93.98 E.18116
G1 X110.31 Y159.041 E3.05215
G1 X107.309 Y159.041 E.09955
G1 X75.93 Y127.661 E1.47208
G1 X75.674 Y124.594 E.1021
G1 X107.317 Y92.951 E1.48444
G1 X110.303 Y92.951 E.09905
G1 X173.505 Y156.154 E2.96495
G1 X177.342 Y152.314 E.18005
G1 X117.979 Y92.952 E2.78483
G1 X114.993 Y92.951 E.09907
G1 X76.265 Y131.68 E1.81682
G1 X76.4 Y133.302 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X76.265 Y131.68 E-.61876
G1 X76.527 Y131.417 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 11/23
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.4 I.45 J1.131 P1  F30000
G1 X173.919 Y92.631 Z2.4
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.368 J2.396 E.05959
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.925 J1.521 E.06042
G1 X178.493 Y150.841 E1.58723
G3 X177.793 Y152.36 I-2.403 J-.186 E.05668
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.462 Y158.691 E.29697
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06292
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.437 E.06293
G1 X78.214 Y152.358 E.29705
G3 X77.513 Y150.848 I1.715 J-1.715 E.05639
G1 X73.692 Y105 E1.52614
G3 X74.09 Y103.457 I2.44 J-.193 E.05382
G1 X80.611 Y93.676 E.38996
G3 X82.618 Y92.602 I2.012 J1.347 E.07861
G1 X173.6 Y92.603 E3.01806
G3 X173.86 Y92.622 I-.05 J2.423 E.00862
M204 S250
G1 X173.977 Y92.243 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X175.743 Y93.259 I-.428 J2.787 E.06404
G1 X182.096 Y101.201 E.31251
G3 X182.7 Y103.171 I-2.24 J1.764 E.06476
G1 X178.883 Y150.879 E1.47062
G3 X178.073 Y152.634 I-2.794 J-.225 E.06066
G1 X171.736 Y158.971 E.27537
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.833 E.06744
G1 X77.932 Y152.631 E.27551
G3 X77.122 Y150.885 I1.997 J-1.987 E.06035
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.838 J-.219 E.05765
G1 X80.287 Y93.454 E.36151
G3 X82.613 Y92.21 I2.337 J1.571 E.08435
G1 X173.605 Y92.211 E2.79595
G3 X173.918 Y92.235 I-.056 J2.819 E.00964
; WIPE_START
M204 S10000
G1 X174.25 Y92.296 E-.1284
G1 X174.515 Y92.378 E-.10539
G1 X174.771 Y92.485 E-.10547
G1 X175.015 Y92.618 E-.10552
G1 X175.353 Y92.861 E-.15814
G1 X175.557 Y93.049 E-.1056
G1 X175.647 Y93.151 E-.05149
; WIPE_END
G1 E-.04 F1800
G1 X170.038 Y98.328 Z2.6 F30000
G1 X104.264 Y159.041 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.635 Y159.04 E.05401
G1 X168.725 Y92.951 E3.10037
G1 X171.711 Y92.951 E.09907
G1 X181.953 Y103.193 E.48046
G2 X181.957 Y102.747 I-1.883 J-.239 E.01483
G1 X125.66 Y159.044 E2.64098
G1 X122.663 Y159.043 E.09941
G1 X74.534 Y110.914 E2.25784
G1 X74.493 Y110.423 E.01634
G1 X91.966 Y92.95 E.81968
G1 X94.95 Y92.95 E.099
G1 X161.048 Y159.048 E3.10079
G1 X164.035 Y159.049 E.09906
G1 X178.656 Y144.427 E.68594
G1 X178.544 Y145.84 E.04701
G1 X125.655 Y92.951 E2.48113
G1 X122.669 Y92.951 E.09903
G1 X76.855 Y138.765 E2.14924
G1 X76.628 Y136.035 E.09087
G1 X99.632 Y159.04 E1.0792
G1 X94.961 Y159.039 E.15497
G1 X161.049 Y92.951 E3.10033
G1 X164.035 Y92.951 E.09906
G1 X181.385 Y110.301 E.81391
G1 X181.324 Y111.056 E.02511
G1 X133.335 Y159.045 E2.25127
G1 X130.34 Y159.044 E.09934
G1 X74.606 Y103.31 E2.6146
G1 X75.959 Y101.282 E.08087
G1 X84.29 Y92.95 E.39084
G1 X87.274 Y92.95 E.099
G1 X153.371 Y159.047 E3.10075
G1 X156.36 Y159.048 E.09913
G1 X179.323 Y136.084 E1.07727
G1 X179.112 Y138.732 E.08811
G1 X133.331 Y92.951 E2.14768
G1 X130.345 Y92.951 E.09903
G1 X77.446 Y145.851 E2.48163
G1 X77.325 Y144.409 E.04798
G1 X91.955 Y159.039 E.68632
G1 X87.286 Y159.038 E.1549
G1 X153.373 Y92.951 E3.10028
G1 X156.359 Y92.951 E.09905
G1 X180.816 Y117.409 E1.14735
G1 X180.657 Y119.398 E.06621
G1 X141.01 Y159.046 E1.85994
G1 X138.017 Y159.045 E.09927
G1 X77.677 Y98.705 E2.83071
G1 X80.747 Y94.099 E.18361
G1 X145.694 Y159.046 E3.04681
G1 X148.685 Y159.047 E.0992
G1 X179.99 Y127.741 E1.4686
G1 X180.248 Y124.516 E.10732
G1 X148.683 Y92.951 E1.48079
G1 X145.697 Y92.951 E.09905
G1 X82.5 Y156.148 E2.96472
G1 X78.66 Y152.312 E.18005
G1 X138.021 Y92.951 E2.78474
G1 X141.007 Y92.951 E.09904
G1 X179.68 Y131.624 E1.81424
G1 X179.55 Y133.247 E.05401
G1 X76.4 Y133.302 F30000
G1 F15476.087
G1 X76.265 Y131.68 E.05401
G1 X114.994 Y92.951 E1.81685
G1 X117.979 Y92.951 E.09902
G1 X177.342 Y152.314 E2.78487
G1 X173.505 Y156.154 E.18005
G1 X110.303 Y92.951 E2.96498
G1 X107.318 Y92.951 E.09901
G1 X75.674 Y124.594 E1.48446
M73 P57 R14
G1 X75.93 Y127.661 E.1021
G1 X107.309 Y159.041 E1.47208
G1 X110.31 Y159.042 E.09955
G1 X175.372 Y93.98 E3.05215
G1 X178.782 Y98.246 E.18116
G1 X117.985 Y159.043 E2.8521
G1 X114.986 Y159.042 E.09948
G1 X75.232 Y119.288 E1.86496
G1 X75.084 Y117.509 E.05922
G1 X99.642 Y92.951 E1.15207
G1 X102.627 Y92.951 E.09901
G1 X168.725 Y159.05 E3.10084
G2 X170.345 Y158.959 I.505 J-5.493 E.05399
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X169.959 Y159.039 E-.14983
G1 X168.725 Y159.05 E-.46857
G1 X168.462 Y158.786 E-.1416
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/23
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.6 I1.213 J.1 P1  F30000
G1 X173.919 Y92.631 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.368 J2.396 E.05959
G1 X181.787 Y101.442 E.33707
G3 X182.309 Y103.144 I-1.928 J1.522 E.06041
G1 X178.493 Y150.844 E1.58733
G3 X177.793 Y152.36 I-2.402 J-.189 E.05659
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29695
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06293
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.435 E.06292
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.719 J-1.714 E.0563
M73 P57 R13
G1 X73.692 Y105 E1.52614
G3 X74.09 Y103.457 I2.469 J-.186 E.0538
G1 X80.611 Y93.676 E.38996
G3 X82.618 Y92.602 I2.009 J1.342 E.07863
G1 X173.609 Y92.603 E3.01833
G3 X173.859 Y92.622 I-.058 J2.423 E.00835
M204 S250
G1 X173.977 Y92.243 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G3 X175.743 Y93.259 I-.428 J2.787 E.06404
G1 X182.096 Y101.201 E.31251
G3 X182.7 Y103.171 I-2.244 J1.765 E.06476
G1 X178.883 Y150.88 E1.47066
G3 X178.073 Y152.634 I-2.792 J-.225 E.06063
G1 X171.736 Y158.971 E.27536
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.014 J-2.832 E.06744
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I1.999 J-1.988 E.06032
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.869 J-.211 E.05762
G1 X80.287 Y93.454 E.36151
G3 X82.613 Y92.21 I2.334 J1.566 E.08436
G1 X173.614 Y92.211 E2.7962
G3 X173.918 Y92.235 I-.065 J2.819 E.00938
; WIPE_START
M204 S10000
G1 X174.25 Y92.296 E-.12838
G1 X174.515 Y92.378 E-.10544
G1 X174.771 Y92.485 E-.10546
G1 X175.015 Y92.618 E-.10547
G1 X175.353 Y92.861 E-.15822
G1 X175.557 Y93.049 E-.10556
G1 X175.647 Y93.151 E-.05147
; WIPE_END
G1 E-.04 F1800
G1 X176.386 Y100.747 Z2.8 F30000
G1 X179.55 Y133.247 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.68 Y131.624 E.05401
G1 X141.007 Y92.951 E1.81423
G1 X138.021 Y92.951 E.09905
G1 X78.66 Y152.312 E2.78473
G1 X82.5 Y156.148 E.18005
G1 X145.697 Y92.951 E2.96471
G1 X148.683 Y92.951 E.09906
G1 X180.248 Y124.516 E1.48079
G1 X179.99 Y127.741 E.10732
G1 X148.685 Y159.047 E1.4686
G1 X145.694 Y159.046 E.0992
G1 X80.747 Y94.099 E3.04681
G1 X77.677 Y98.705 E.18361
G1 X138.017 Y159.045 E2.83071
G1 X141.01 Y159.046 E.09927
G1 X180.657 Y119.398 E1.85994
G1 X180.816 Y117.409 E.06621
G1 X156.359 Y92.951 E1.14734
G1 X153.373 Y92.951 E.09906
G1 X87.286 Y159.038 E3.10028
G1 X91.955 Y159.039 E.15491
G1 X77.325 Y144.409 E.68632
G1 X77.446 Y145.851 E.04798
G1 X130.345 Y92.951 E2.48163
G1 X133.331 Y92.951 E.09904
G1 X179.112 Y138.732 E2.14768
G1 X179.323 Y136.084 E.08811
G1 X156.36 Y159.048 E1.07727
G1 X153.371 Y159.047 E.09913
G1 X87.274 Y92.95 E3.10075
G1 X84.29 Y92.95 E.099
G1 X75.959 Y101.282 E.39084
G1 X74.606 Y103.31 E.08087
G1 X130.34 Y159.044 E2.6146
G1 X133.335 Y159.045 E.09934
G1 X181.324 Y111.056 E2.25127
G1 X181.385 Y110.301 E.02511
G1 X164.035 Y92.952 E.8139
G1 X161.049 Y92.951 E.09907
G1 X94.961 Y159.039 E3.10032
G1 X99.632 Y159.04 E.15497
G1 X76.628 Y136.035 E1.0792
G1 X76.855 Y138.765 E.09087
G1 X122.669 Y92.951 E2.14924
G1 X125.655 Y92.951 E.09903
G1 X178.544 Y145.84 E2.48112
G1 X178.657 Y144.427 E.04701
G1 X164.035 Y159.049 E.68594
G1 X161.048 Y159.048 E.09906
G1 X94.95 Y92.951 E3.10079
G1 X91.966 Y92.95 E.099
G1 X74.493 Y110.423 E.81968
G1 X74.534 Y110.914 E.01634
G1 X122.663 Y159.043 E2.25784
G1 X125.66 Y159.044 E.09941
G1 X181.957 Y102.747 E2.64098
G3 X181.953 Y103.193 I-1.886 J.207 E.01483
G1 X171.711 Y92.952 E.48045
G1 X168.724 Y92.952 E.09908
G1 X102.635 Y159.04 E3.10037
G1 X104.264 Y159.041 E.05401
G1 X170.345 Y158.959 F30000
G1 F15476.087
G3 X168.725 Y159.05 I-1.114 J-5.406 E.05399
G1 X102.627 Y92.951 E3.10084
G1 X99.642 Y92.951 E.09901
G1 X75.084 Y117.509 E1.15207
G1 X75.232 Y119.288 E.05922
G1 X114.986 Y159.042 E1.86496
G1 X117.985 Y159.043 E.09948
G1 X178.782 Y98.246 E2.8521
G1 X175.372 Y93.98 E.18116
G1 X110.31 Y159.042 E3.05215
G1 X107.309 Y159.041 E.09955
G1 X75.93 Y127.661 E1.47208
G1 X75.674 Y124.594 E.1021
G1 X107.318 Y92.951 E1.48446
G1 X110.303 Y92.951 E.09902
G1 X173.505 Y156.154 E2.96497
G1 X177.342 Y152.314 E.18005
G1 X117.979 Y92.951 E2.78487
G1 X114.993 Y92.951 E.09903
G1 X76.265 Y131.68 E1.81685
G1 X76.4 Y133.302 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X76.265 Y131.68 E-.61876
G1 X76.527 Y131.417 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/23
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.8 I.45 J1.131 P1  F30000
G1 X173.919 Y92.629 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.361 J2.379 E.05964
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.88 J1.507 E.06046
G1 X178.493 Y150.839 E1.58721
G3 X177.793 Y152.36 I-2.433 J-.199 E.05669
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29697
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06293
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.691 I.008 J-2.435 E.06292
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.732 J-1.72 E.05628
G1 X73.692 Y105 E1.52614
G3 X74.09 Y103.457 I2.473 J-.185 E.05379
G1 X80.611 Y93.676 E.38996
G3 X82.618 Y92.602 I2.008 J1.341 E.07863
G1 X173.682 Y92.605 E3.02076
G3 X173.86 Y92.621 I-.123 J2.403 E.00592
M204 S250
G1 X173.98 Y92.242 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
M73 P58 R13
G1 F12000
M204 S5000
G1 X174.325 Y92.317 E.01085
G3 X175.743 Y93.259 I-.767 J2.692 E.05315
G1 X182.096 Y101.201 E.3125
G3 X182.7 Y103.171 I-2.188 J1.748 E.06483
G1 X178.883 Y150.878 E1.4706
G3 X178.073 Y152.634 I-2.828 J-.24 E.06064
G1 X171.736 Y158.971 E.27538
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.273 Y158.971 I.015 J-2.832 E.06744
G1 X77.932 Y152.63 E.27554
G3 X77.122 Y150.885 I2.018 J-1.996 E.06031
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.873 J-.21 E.05762
G1 X80.287 Y93.454 E.36151
G3 X82.613 Y92.21 I2.333 J1.565 E.08437
G1 X173.701 Y92.214 E2.7989
G3 X173.921 Y92.233 I-.143 J2.796 E.00677
; WIPE_START
M204 S10000
G1 X174.325 Y92.317 E-.15688
G1 X174.644 Y92.428 E-.1285
G1 X174.895 Y92.549 E-.10549
G1 X175.132 Y92.693 E-.10554
G1 X175.353 Y92.861 E-.10554
G1 X175.557 Y93.049 E-.10555
G1 X175.649 Y93.153 E-.0525
; WIPE_END
G1 E-.04 F1800
G1 X170.04 Y98.33 Z3 F30000
G1 X104.264 Y159.041 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.635 Y159.041 E.05401
G1 X168.723 Y92.953 E3.10029
G1 X171.713 Y92.953 E.09919
G1 X181.953 Y103.193 E.48037
G2 X181.95 Y102.754 I-1.556 J-.211 E.01463
G1 X125.66 Y159.044 E2.64069
G1 X122.663 Y159.043 E.09941
G1 X74.534 Y110.914 E2.25784
G1 X74.493 Y110.423 E.01634
G1 X91.966 Y92.951 E.81967
G1 X94.951 Y92.951 E.09902
G1 X161.048 Y159.048 E3.10078
G1 X164.035 Y159.049 E.09906
G1 X178.656 Y144.427 E.68594
G1 X178.544 Y145.84 E.04701
G1 X125.656 Y92.952 E2.48108
G1 X122.669 Y92.952 E.09909
G1 X76.855 Y138.765 E2.1492
G1 X76.628 Y136.035 E.09087
G1 X99.632 Y159.04 E1.07921
G1 X94.961 Y159.039 E.15498
G1 X161.047 Y92.953 E3.10025
G1 X164.037 Y92.953 E.09918
G1 X181.385 Y110.301 E.81382
G1 X181.324 Y111.056 E.02511
G1 X133.335 Y159.045 E2.25127
G1 X130.34 Y159.044 E.09934
G1 X74.606 Y103.31 E2.6146
G1 X75.959 Y101.282 E.08087
G1 X84.29 Y92.95 E.39084
G1 X87.275 Y92.95 E.099
G1 X153.371 Y159.047 E3.10074
G1 X156.36 Y159.048 E.09913
G1 X179.323 Y136.084 E1.07727
G1 X179.112 Y138.732 E.08811
G1 X133.332 Y92.952 E2.14763
G1 X130.344 Y92.952 E.09911
G1 X77.446 Y145.851 E2.48158
G1 X77.325 Y144.409 E.04799
G1 X91.955 Y159.039 E.68633
G1 X87.286 Y159.038 E.15491
G1 X153.371 Y92.953 E3.10021
G1 X156.361 Y92.953 E.09916
G1 X180.816 Y117.409 E1.14727
G1 X180.657 Y119.398 E.06621
G1 X141.01 Y159.046 E1.85994
G1 X138.017 Y159.045 E.09927
G1 X77.677 Y98.705 E2.83071
G1 X80.747 Y94.099 E.18361
G1 X145.694 Y159.046 E3.04681
G1 X148.685 Y159.047 E.0992
G1 X179.99 Y127.741 E1.4686
G1 X180.248 Y124.516 E.10731
G1 X148.684 Y92.953 E1.48073
G1 X145.696 Y92.953 E.09914
G1 X82.5 Y156.148 E2.96465
G1 X78.66 Y152.312 E.18005
G1 X138.02 Y92.952 E2.78468
G1 X141.008 Y92.952 E.09912
G1 X179.68 Y131.624 E1.81418
G1 X179.55 Y133.247 E.05401
G1 X76.4 Y133.302 F30000
G1 F15476.087
G1 X76.265 Y131.68 E.05401
G1 X114.993 Y92.951 E1.81682
G1 X117.979 Y92.952 E.09907
G1 X177.342 Y152.314 E2.78483
G1 X173.505 Y156.154 E.18005
G1 X110.303 Y92.951 E2.96495
G1 X107.317 Y92.951 E.09905
G1 X75.674 Y124.594 E1.48444
G1 X75.93 Y127.661 E.1021
G1 X107.309 Y159.041 E1.47209
G1 X110.31 Y159.042 E.09954
G1 X175.372 Y93.98 E3.05216
G1 X178.782 Y98.246 E.18116
G1 X117.985 Y159.043 E2.8521
G1 X114.986 Y159.042 E.09947
G1 X75.232 Y119.288 E1.86496
G1 X75.084 Y117.509 E.05922
G1 X99.641 Y92.951 E1.15205
G1 X102.627 Y92.951 E.09904
G1 X168.725 Y159.05 E3.10082
G2 X170.345 Y158.959 I.503 J-5.548 E.05398
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X169.958 Y159.039 E-.14989
G1 X168.725 Y159.05 E-.46852
G1 X168.462 Y158.786 E-.14159
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/23
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3 I1.213 J.1 P1  F30000
G1 X173.919 Y92.631 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.368 J2.396 E.0596
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.907 J1.515 E.06044
G1 X178.493 Y150.844 E1.58733
G3 X177.793 Y152.36 I-2.491 J-.23 E.0565
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29696
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06293
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.691 I-.003 J-2.409 E.06296
G1 X78.212 Y152.356 E.29717
G3 X77.513 Y150.848 I1.733 J-1.72 E.05626
G1 X73.692 Y105 E1.52614
G3 X74.09 Y103.457 I2.404 J-.202 E.05386
G1 X80.611 Y93.676 E.38995
G3 X82.618 Y92.602 I2.01 J1.343 E.07863
G1 X173.625 Y92.604 E3.01888
G3 X173.859 Y92.622 I-.075 J2.423 E.0078
M204 S250
G1 X173.982 Y92.242 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.249 Y92.299 E.00838
G3 X175.743 Y93.259 I-.7 J2.731 E.05551
G1 X182.096 Y101.201 E.3125
G3 X182.7 Y103.171 I-2.22 J1.758 E.06479
G1 X178.883 Y150.88 E1.47065
G3 X178.073 Y152.634 I-2.891 J-.27 E.06055
G1 X171.736 Y158.971 E.27537
G3 X169.759 Y159.79 I-1.992 J-2.014 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.273 Y158.971 I.002 J-2.801 E.06748
G1 X77.931 Y152.63 E.27556
G3 X77.122 Y150.885 I2.019 J-1.996 E.06028
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.795 J-.23 E.05768
G1 X80.287 Y93.455 E.36151
G3 X82.613 Y92.21 I2.333 J1.565 E.08437
G1 X173.63 Y92.212 E2.79671
G3 X173.923 Y92.236 I-.081 J2.818 E.00904
; WIPE_START
M204 S10000
G1 X174.249 Y92.299 E-.12626
G1 X174.515 Y92.378 E-.10535
G1 X174.771 Y92.485 E-.10549
G1 X175.015 Y92.618 E-.10555
G1 X175.352 Y92.86 E-.15755
G1 X175.557 Y93.049 E-.10612
G1 X175.651 Y93.155 E-.05368
; WIPE_END
G1 E-.04 F1800
M73 P59 R13
G1 X176.39 Y100.752 Z3.2 F30000
G1 X179.55 Y133.247 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.68 Y131.624 E.05401
G1 X141.007 Y92.951 E1.81422
G1 X138.021 Y92.951 E.09906
G1 X78.66 Y152.312 E2.78472
G1 X82.5 Y156.148 E.18005
G1 X145.697 Y92.952 E2.9647
G1 X148.683 Y92.952 E.09907
G1 X180.248 Y124.516 E1.48077
G1 X179.99 Y127.741 E.10732
G1 X148.685 Y159.047 E1.46861
G1 X145.694 Y159.046 E.0992
G1 X80.747 Y94.099 E3.04681
G1 X77.677 Y98.705 E.18361
G1 X138.017 Y159.045 E2.83071
G1 X141.01 Y159.046 E.09927
G1 X180.657 Y119.398 E1.85994
G1 X180.816 Y117.409 E.06621
G1 X156.359 Y92.952 E1.14733
G1 X153.372 Y92.952 E.09908
G1 X87.286 Y159.038 E3.10027
G1 X91.956 Y159.039 E.15491
G1 X77.325 Y144.409 E.68633
G1 X77.446 Y145.851 E.04798
G1 X130.345 Y92.951 E2.48162
G1 X133.331 Y92.951 E.09906
G1 X179.112 Y138.732 E2.14767
G1 X179.323 Y136.084 E.08811
G1 X156.36 Y159.048 E1.07727
G1 X153.371 Y159.047 E.09913
G1 X87.274 Y92.95 E3.10075
G1 X84.29 Y92.95 E.099
G1 X75.959 Y101.282 E.39084
G1 X74.606 Y103.31 E.08087
G1 X130.34 Y159.044 E2.6146
G1 X133.335 Y159.045 E.09933
G1 X181.324 Y111.056 E2.25127
G1 X181.385 Y110.301 E.02511
G1 X164.035 Y92.952 E.81388
G1 X161.048 Y92.952 E.09909
G1 X94.96 Y159.04 E3.10031
G1 X99.632 Y159.04 E.15498
G1 X76.628 Y136.035 E1.07921
G1 X76.855 Y138.765 E.09087
G1 X122.669 Y92.951 E2.14923
G1 X125.655 Y92.951 E.09905
G1 X178.544 Y145.84 E2.48111
G1 X178.656 Y144.427 E.04701
G1 X164.035 Y159.049 E.68594
G1 X161.048 Y159.049 E.09906
G1 X94.951 Y92.951 E3.10079
G1 X91.966 Y92.951 E.09901
G1 X74.493 Y110.423 E.81968
G1 X74.534 Y110.914 E.01634
G1 X122.663 Y159.043 E2.25785
G1 X125.66 Y159.044 E.0994
G1 X181.957 Y102.747 E2.64098
G3 X181.953 Y103.193 I-1.886 J.207 E.01483
G1 X171.712 Y92.952 E.48043
G1 X168.724 Y92.952 E.0991
G1 X102.635 Y159.041 E3.10035
G1 X104.264 Y159.041 E.05401
G1 X170.344 Y158.959 F30000
G1 F15476.087
G3 X168.725 Y159.05 I-1.114 J-5.386 E.05399
G1 X102.627 Y92.951 E3.10083
G1 X99.642 Y92.951 E.09902
G1 X75.084 Y117.509 E1.15206
G1 X75.232 Y119.288 E.05922
G1 X114.987 Y159.042 E1.86497
G1 X117.985 Y159.043 E.09947
G1 X178.782 Y98.246 E2.8521
G1 X175.372 Y93.98 E.18116
G1 X110.31 Y159.042 E3.05216
G1 X107.309 Y159.041 E.09954
G1 X75.93 Y127.661 E1.47209
G1 X75.674 Y124.594 E.1021
G1 X107.318 Y92.951 E1.48445
G1 X110.303 Y92.951 E.09903
G1 X173.505 Y156.154 E2.96497
G1 X177.342 Y152.314 E.18005
G1 X117.979 Y92.951 E2.78486
G1 X114.993 Y92.951 E.09904
G1 X76.265 Y131.68 E1.81684
G1 X76.4 Y133.302 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X76.265 Y131.68 E-.61876
G1 X76.527 Y131.417 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 15/23
; update layer progress
M73 L15
M991 S0 P14 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.2 I.45 J1.131 P1  F30000
G1 X173.919 Y92.63 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.357 J2.374 E.05963
G1 X181.787 Y101.442 E.33707
G3 X182.309 Y103.144 I-1.907 J1.515 E.06043
G1 X178.493 Y150.839 E1.58719
G3 X177.793 Y152.36 I-2.426 J-.195 E.05673
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29694
G3 X169.754 Y159.398 I-1.706 J-1.701 E.06297
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.435 E.06293
G1 X78.212 Y152.356 E.29714
G3 X77.513 Y150.848 I1.764 J-1.735 E.05624
G1 X73.692 Y105 E1.52614
G3 X74.09 Y103.457 I2.404 J-.202 E.05385
G1 X80.611 Y93.676 E.38996
G3 X82.618 Y92.602 I2.028 J1.379 E.07852
G1 X173.624 Y92.604 E3.01883
G3 X173.86 Y92.622 I-.062 J2.4 E.00785
M204 S250
G1 X173.985 Y92.243 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.25 Y92.297 E.00831
G3 X175.743 Y93.259 I-.688 J2.708 E.05554
G1 X182.096 Y101.201 E.31251
G3 X182.7 Y103.171 I-2.221 J1.758 E.06479
G1 X178.883 Y150.878 E1.4706
G3 X178.073 Y152.634 I-2.816 J-.234 E.06067
G1 X171.736 Y158.971 E.27536
G3 X169.759 Y159.79 I-1.979 J-1.982 E.06748
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.832 E.06744
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I2.053 J-2.013 E.06027
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.795 J-.23 E.05768
G1 X80.287 Y93.455 E.36151
G3 X82.613 Y92.21 I2.355 J1.605 E.08427
G1 X173.635 Y92.212 E2.79686
G3 X173.925 Y92.235 I-.074 J2.793 E.00894
; WIPE_START
M204 S10000
G1 X174.25 Y92.297 E-.12554
G1 X174.515 Y92.378 E-.10549
G1 X174.771 Y92.485 E-.10544
G1 X175.015 Y92.618 E-.10559
G1 X175.3 Y92.818 E-.13206
G1 X175.557 Y93.049 E-.13161
G1 X175.652 Y93.156 E-.05426
; WIPE_END
G1 E-.04 F1800
G1 X170.043 Y98.333 Z3.4 F30000
G1 X104.264 Y159.041 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.635 Y159.041 E.05401
G1 X168.724 Y92.952 E3.10034
G1 X171.712 Y92.952 E.09912
G1 X181.953 Y103.193 E.48043
G2 X181.957 Y102.747 I-1.883 J-.239 E.01483
G1 X125.66 Y159.044 E2.64098
G1 X122.664 Y159.043 E.0994
G1 X74.534 Y110.914 E2.25785
G1 X74.493 Y110.423 E.01634
G1 X91.966 Y92.951 E.81968
G1 X94.951 Y92.951 E.09901
G1 X161.048 Y159.049 E3.10079
G1 X164.035 Y159.049 E.09906
G1 X178.656 Y144.427 E.68594
G1 X178.544 Y145.84 E.04701
G1 X125.655 Y92.951 E2.48111
G1 X122.669 Y92.951 E.09905
G1 X76.855 Y138.765 E2.14923
G1 X76.628 Y136.035 E.09087
G1 X99.633 Y159.04 E1.07921
G1 X94.96 Y159.04 E.15498
G1 X161.048 Y92.952 E3.1003
G1 X164.036 Y92.952 E.09911
G1 X181.385 Y110.301 E.81387
M73 P60 R13
G1 X181.324 Y111.056 E.02511
G1 X133.335 Y159.045 E2.25127
G1 X130.341 Y159.044 E.09933
G1 X74.606 Y103.31 E2.6146
G1 X75.959 Y101.282 E.08087
G1 X84.29 Y92.95 E.39084
G1 X87.274 Y92.95 E.099
G1 X153.371 Y159.047 E3.10075
G1 X156.36 Y159.048 E.09913
G1 X179.323 Y136.084 E1.07727
G1 X179.112 Y138.732 E.08811
G1 X133.331 Y92.951 E2.14766
G1 X130.345 Y92.951 E.09906
G1 X77.446 Y145.851 E2.48161
G1 X77.325 Y144.409 E.04798
G1 X91.956 Y159.039 E.68633
G1 X87.286 Y159.038 E.15491
G1 X153.372 Y92.952 E3.10026
G1 X156.36 Y92.952 E.0991
G1 X180.816 Y117.409 E1.14732
G1 X180.657 Y119.398 E.06621
G1 X141.01 Y159.046 E1.85994
G1 X138.017 Y159.045 E.09927
G1 X77.677 Y98.705 E2.83071
G1 X80.747 Y94.099 E.18361
G1 X145.695 Y159.046 E3.04681
G1 X148.685 Y159.047 E.0992
G1 X179.99 Y127.741 E1.46861
G1 X180.248 Y124.516 E.10732
G1 X148.683 Y92.952 E1.48077
G1 X145.696 Y92.952 E.09908
G1 X82.5 Y156.148 E2.96469
G1 X78.66 Y152.312 E.18005
G1 X138.021 Y92.952 E2.78471
G1 X141.007 Y92.952 E.09907
G1 X179.68 Y131.624 E1.81421
G1 X179.55 Y133.247 E.05401
G1 X76.4 Y133.302 F30000
G1 F15476.087
M73 P60 R12
G1 X76.265 Y131.68 E.05401
G1 X114.993 Y92.951 E1.81684
G1 X117.979 Y92.951 E.09904
G1 X177.342 Y152.314 E2.78485
G1 X173.505 Y156.154 E.18005
G1 X110.303 Y92.951 E2.96497
G1 X107.317 Y92.951 E.09903
G1 X75.674 Y124.594 E1.48445
G1 X75.93 Y127.661 E.1021
G1 X107.31 Y159.041 E1.47209
G1 X110.31 Y159.042 E.09954
G1 X175.372 Y93.98 E3.05216
G1 X178.782 Y98.246 E.18116
G1 X117.985 Y159.043 E2.8521
G1 X114.987 Y159.042 E.09947
G1 X75.232 Y119.288 E1.86497
G1 X75.084 Y117.509 E.05922
G1 X99.642 Y92.951 E1.15206
G1 X102.627 Y92.951 E.09902
G1 X168.725 Y159.05 E3.10083
G2 X170.345 Y158.959 I.502 J-5.562 E.05398
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X169.954 Y159.04 E-.15155
G1 X168.725 Y159.05 E-.46686
G1 X168.462 Y158.786 E-.1416
; WIPE_END
G1 E-.03999 F1800
; layer num/total_layer_count: 16/23
; update layer progress
M73 L16
M991 S0 P15 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.4 I1.213 J.1 P1  F30000
G1 X173.927 Y92.642 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X174.153 Y92.677 E.00761
G3 X175.44 Y93.508 I-.595 J2.332 E.05171
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.88 J1.507 E.06046
G1 X178.493 Y150.844 E1.58734
G3 X177.793 Y152.36 I-2.403 J-.19 E.0566
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29695
G3 X169.754 Y159.398 I-1.726 J-1.752 E.06289
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.003 J-2.425 E.06294
G1 X78.212 Y152.356 E.29716
G3 X77.513 Y150.848 I1.703 J-1.706 E.05629
G1 X73.692 Y105 E1.52614
G3 X74.09 Y103.458 I2.44 J-.193 E.05381
G1 X80.611 Y93.676 E.38998
G3 X82.618 Y92.602 I2.012 J1.348 E.07861
G1 X173.682 Y92.605 E3.02076
G1 X173.867 Y92.633 E.00622
M204 S250
G1 X173.987 Y92.243 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.25 Y92.297 E.00825
G3 X175.743 Y93.259 I-.692 J2.712 E.05555
G1 X182.096 Y101.201 E.31251
G3 X182.7 Y103.171 I-2.189 J1.748 E.06482
G1 X178.883 Y150.88 E1.47065
G3 X178.073 Y152.634 I-2.794 J-.225 E.06064
G1 X171.736 Y158.971 E.27537
G3 X169.759 Y159.79 I-2.002 J-2.039 E.0674
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.01 J-2.821 E.06746
G1 X77.931 Y152.63 E.27554
G3 X77.122 Y150.885 I1.984 J-1.98 E.06033
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.838 J-.219 E.05764
G1 X80.287 Y93.455 E.36152
G3 X82.613 Y92.21 I2.337 J1.572 E.08435
G1 X173.701 Y92.214 E2.7989
G3 X173.927 Y92.234 I-.143 J2.796 E.00697
; WIPE_START
M204 S10000
G1 X174.25 Y92.297 E-.12485
G1 X174.572 Y92.4 E-.12836
G1 X174.895 Y92.549 E-.1352
G1 X175.132 Y92.693 E-.10553
G1 X175.353 Y92.861 E-.10555
G1 X175.557 Y93.049 E-.10551
G1 X175.653 Y93.158 E-.055
; WIPE_END
G1 E-.04 F1800
G1 X176.392 Y100.754 Z3.6 F30000
G1 X179.55 Y133.247 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.68 Y131.624 E.05401
G1 X141.008 Y92.952 E1.81418
G1 X138.02 Y92.952 E.09912
G1 X78.66 Y152.312 E2.78468
G1 X82.5 Y156.148 E.18005
G1 X145.696 Y92.953 E2.96465
G1 X148.684 Y92.953 E.09914
G1 X180.248 Y124.516 E1.48073
G1 X179.99 Y127.741 E.10731
G1 X148.685 Y159.047 E1.4686
G1 X145.694 Y159.046 E.0992
G1 X80.747 Y94.099 E3.04681
G1 X77.677 Y98.705 E.18361
G1 X138.017 Y159.045 E2.8307
G1 X141.01 Y159.046 E.09927
G1 X180.657 Y119.398 E1.85993
G1 X180.816 Y117.409 E.06621
G1 X156.361 Y92.953 E1.14727
G1 X153.371 Y92.953 E.09916
G1 X87.286 Y159.038 E3.1002
G1 X91.955 Y159.039 E.15489
G1 X77.325 Y144.409 E.68631
G1 X77.446 Y145.851 E.04798
G1 X130.344 Y92.952 E2.48158
G1 X133.332 Y92.952 E.09911
G1 X179.112 Y138.732 E2.14763
G1 X179.323 Y136.084 E.08811
G1 X156.36 Y159.048 E1.07727
G1 X153.371 Y159.047 E.09913
G1 X87.275 Y92.95 E3.10074
G1 X84.29 Y92.95 E.099
G1 X75.959 Y101.282 E.39084
G1 X74.606 Y103.31 E.08087
G1 X130.34 Y159.044 E2.61459
G1 X133.335 Y159.045 E.09935
G1 X181.324 Y111.056 E2.25126
G1 X181.385 Y110.301 E.02511
G1 X164.037 Y92.953 E.81382
G1 X161.047 Y92.953 E.09918
G1 X94.961 Y159.039 E3.10024
G1 X99.632 Y159.04 E.15496
G1 X76.628 Y136.035 E1.07919
G1 X76.855 Y138.765 E.09087
G1 X122.669 Y92.952 E2.1492
G1 X125.656 Y92.952 E.09909
G1 X178.544 Y145.84 E2.48108
G1 X178.657 Y144.427 E.04701
G1 X164.035 Y159.049 E.68594
G1 X161.048 Y159.048 E.09906
G1 X94.951 Y92.951 E3.10078
G1 X91.966 Y92.951 E.09902
G1 X74.493 Y110.423 E.81967
G1 X74.534 Y110.914 E.01634
G1 X122.663 Y159.043 E2.25784
G1 X125.66 Y159.043 E.09942
G1 X181.953 Y102.751 E2.64082
G3 X181.953 Y103.193 I-1.696 J.22 E.01472
G1 X171.713 Y92.953 E.48037
G1 X168.723 Y92.953 E.09919
G1 X102.636 Y159.04 E3.10027
G1 X104.264 Y159.04 E.05401
G1 X170.345 Y158.959 F30000
G1 F15476.087
M73 P61 R12
G3 X168.725 Y159.05 I-1.114 J-5.393 E.05399
G1 X102.627 Y92.951 E3.10082
G1 X99.641 Y92.951 E.09904
G1 X75.084 Y117.509 E1.15205
G1 X75.232 Y119.288 E.05922
G1 X114.986 Y159.042 E1.86496
G1 X117.985 Y159.042 E.09949
G1 X178.782 Y98.246 E2.85209
G1 X175.372 Y93.98 E.18116
G1 X110.311 Y159.041 E3.05214
G1 X107.309 Y159.041 E.09956
G1 X75.93 Y127.661 E1.47207
G1 X75.674 Y124.594 E.1021
G1 X107.317 Y92.951 E1.48444
G1 X110.303 Y92.951 E.09905
G1 X173.505 Y156.154 E2.96495
G1 X177.342 Y152.314 E.18005
G1 X117.979 Y92.952 E2.78483
G1 X114.993 Y92.951 E.09907
G1 X76.265 Y131.68 E1.81682
G1 X76.4 Y133.302 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X76.265 Y131.68 E-.61876
G1 X76.527 Y131.417 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 17/23
; update layer progress
M73 L17
M991 S0 P16 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.6 I.45 J1.131 P1  F30000
G1 X173.919 Y92.63 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.357 J2.374 E.05963
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.907 J1.515 E.06043
G1 X178.493 Y150.844 E1.58736
G3 X177.793 Y152.36 I-2.402 J-.189 E.05658
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.462 Y158.69 E.29696
G3 X169.754 Y159.398 I-1.725 J-1.749 E.06289
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.435 E.06293
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.703 J-1.706 E.05631
G1 X73.692 Y105 E1.52614
G3 X74.092 Y103.454 I2.44 J-.193 E.05395
G1 X80.611 Y93.676 E.38983
G3 X82.618 Y92.602 I2.012 J1.347 E.07861
G1 X173.639 Y92.604 E3.01935
G3 X173.86 Y92.622 I-.077 J2.4 E.00734
M204 S250
G1 X173.989 Y92.243 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.25 Y92.297 E.00818
G3 X175.743 Y93.259 I-.688 J2.708 E.05555
G1 X182.096 Y101.201 E.31251
G3 X182.7 Y103.171 I-2.22 J1.758 E.06478
G1 X178.883 Y150.88 E1.47066
G3 X178.073 Y152.634 I-2.792 J-.225 E.06063
G1 X171.736 Y158.971 E.27536
G3 X169.759 Y159.79 I-2.001 J-2.036 E.06742
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.832 E.06744
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I1.983 J-1.98 E.06034
G1 X73.301 Y105.028 E1.41396
G3 X73.762 Y103.243 I2.838 J-.219 E.05768
G1 X80.287 Y93.454 E.36148
G3 X82.613 Y92.21 I2.337 J1.571 E.08435
G1 X173.651 Y92.212 E2.79736
G3 X173.93 Y92.235 I-.09 J2.793 E.00858
; WIPE_START
M204 S10000
G1 X174.25 Y92.297 E-.12388
G1 X174.515 Y92.378 E-.10552
G1 X174.771 Y92.485 E-.10544
G1 X175.015 Y92.618 E-.10556
G1 X175.312 Y92.828 E-.13818
G1 X175.557 Y93.049 E-.1255
G1 X175.655 Y93.16 E-.05591
; WIPE_END
G1 E-.04 F1800
G1 X170.046 Y98.336 Z3.8 F30000
G1 X104.264 Y159.04 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.636 Y159.04 E.05401
G1 X168.723 Y92.953 E3.10031
G1 X171.712 Y92.953 E.09914
G1 X181.953 Y103.193 E.48041
G2 X181.953 Y102.75 I-1.702 J-.224 E.01473
G1 X125.66 Y159.044 E2.64082
G1 X122.663 Y159.043 E.09942
G1 X74.534 Y110.914 E2.25784
G1 X74.493 Y110.423 E.01634
G1 X91.966 Y92.951 E.81967
G1 X94.951 Y92.951 E.09901
G1 X161.048 Y159.048 E3.10078
G1 X164.035 Y159.049 E.09906
G1 X178.656 Y144.427 E.68594
G1 X178.544 Y145.84 E.04701
G1 X125.655 Y92.951 E2.4811
G1 X122.669 Y92.951 E.09906
G1 X76.855 Y138.765 E2.14922
G1 X76.628 Y136.035 E.09087
G1 X99.632 Y159.04 E1.07919
G1 X94.961 Y159.039 E.15496
G1 X161.048 Y92.952 E3.10027
G1 X164.036 Y92.952 E.09913
G1 X181.385 Y110.301 E.81386
G1 X181.324 Y111.056 E.02511
G1 X133.335 Y159.045 E2.25126
G1 X130.34 Y159.044 E.09935
G1 X74.606 Y103.31 E2.61459
G1 X75.959 Y101.282 E.08087
G1 X84.29 Y92.95 E.39084
G1 X87.274 Y92.95 E.099
G1 X153.371 Y159.047 E3.10074
G1 X156.36 Y159.048 E.09913
G1 X179.323 Y136.084 E1.07727
G1 X179.112 Y138.732 E.08811
G1 X133.331 Y92.952 E2.14765
G1 X130.345 Y92.952 E.09908
G1 X77.446 Y145.851 E2.4816
G1 X77.325 Y144.409 E.04798
G1 X91.955 Y159.039 E.68631
G1 X87.286 Y159.038 E.15489
G1 X153.372 Y92.952 E3.10023
G1 X156.36 Y92.952 E.09912
G1 X180.816 Y117.409 E1.1473
G1 X180.657 Y119.398 E.06621
G1 X141.01 Y159.046 E1.85993
G1 X138.017 Y159.045 E.09927
G1 X77.677 Y98.705 E2.8307
G1 X80.747 Y94.099 E.18361
G1 X145.694 Y159.046 E3.04681
G1 X148.685 Y159.047 E.0992
G1 X179.99 Y127.741 E1.4686
G1 X180.248 Y124.516 E.10731
G1 X148.684 Y92.952 E1.48075
G1 X145.696 Y92.952 E.0991
G1 X82.5 Y156.148 E2.96468
G1 X78.66 Y152.312 E.18005
G1 X138.02 Y92.952 E2.7847
G1 X141.008 Y92.952 E.09909
G1 X179.68 Y131.624 E1.8142
G1 X179.55 Y133.247 E.05401
G1 X76.4 Y133.302 F30000
G1 F15476.087
G1 X76.265 Y131.68 E.05401
G1 X114.993 Y92.951 E1.81683
G1 X117.979 Y92.951 E.09905
G1 X177.342 Y152.314 E2.78485
G1 X173.505 Y156.154 E.18005
G1 X110.303 Y92.951 E2.96496
G1 X107.317 Y92.951 E.09904
G1 X75.674 Y124.594 E1.48445
G1 X75.93 Y127.661 E.1021
G1 X107.309 Y159.041 E1.47207
G1 X110.311 Y159.041 E.09956
G1 X175.372 Y93.98 E3.05214
G1 X178.782 Y98.246 E.18116
G1 X117.985 Y159.042 E2.85209
G1 X114.986 Y159.042 E.09949
G1 X75.232 Y119.288 E1.86495
G1 X75.084 Y117.509 E.05922
G1 X99.642 Y92.951 E1.15206
G1 X102.627 Y92.951 E.09902
G1 X168.725 Y159.05 E3.10083
G2 X170.345 Y158.959 I.505 J-5.484 E.05399
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X169.955 Y159.04 E-.15115
G1 X168.725 Y159.05 E-.46724
G1 X168.462 Y158.786 E-.14162
; WIPE_END
G1 E-.03999 F1800
; layer num/total_layer_count: 18/23
; update layer progress
M73 L18
M991 S0 P17 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.8 I1.213 J.1 P1  F30000
G1 X173.919 Y92.63 Z3.8
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.358 J2.376 E.05963
G1 X181.787 Y101.443 E.33707
G3 X182.309 Y103.144 I-1.907 J1.515 E.06043
G1 X178.493 Y150.844 E1.58735
G3 X177.793 Y152.36 I-2.403 J-.19 E.05657
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29696
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06293
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.005 J-2.428 E.06293
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.703 J-1.706 E.05632
G1 X73.692 Y105 E1.52613
G3 X74.09 Y103.458 I2.44 J-.193 E.05381
G1 X80.611 Y93.676 E.38997
G3 X82.618 Y92.602 I2.012 J1.347 E.07861
M73 P62 R12
G1 X173.64 Y92.604 E3.01936
G3 X173.86 Y92.622 I-.079 J2.401 E.00732
M204 S250
G1 X173.991 Y92.244 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.25 Y92.297 E.00812
G3 X175.743 Y93.259 I-.689 J2.709 E.05554
G1 X182.096 Y101.201 E.31251
G3 X182.7 Y103.171 I-2.221 J1.758 E.06478
G1 X178.883 Y150.88 E1.47066
G3 X178.073 Y152.634 I-2.794 J-.226 E.06062
G1 X171.736 Y158.971 E.27537
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.011 J-2.824 E.06745
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I1.983 J-1.98 E.06033
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.838 J-.219 E.05764
G1 X80.287 Y93.454 E.36153
G3 X82.613 Y92.21 I2.337 J1.571 E.08435
G1 X173.657 Y92.212 E2.79753
G3 X173.932 Y92.235 I-.096 J2.793 E.00848
; WIPE_START
M204 S10000
G1 X174.25 Y92.297 E-.12312
G1 X174.515 Y92.378 E-.10541
G1 X174.771 Y92.485 E-.10547
G1 X175.053 Y92.642 E-.12244
G1 X175.353 Y92.861 E-.14122
G1 X175.557 Y93.049 E-.10555
G1 X175.656 Y93.161 E-.05679
; WIPE_END
G1 E-.04 F1800
G1 X174.997 Y100.765 Z4 F30000
G1 X169.975 Y158.653 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X168.348 Y158.672 I-.912 J-8.448 E.05406
G1 X103.004 Y93.328 E3.06544
G1 X99.264 Y93.328 E.12404
G1 X75.433 Y117.159 E1.11798
G1 X75.645 Y119.701 E.08459
G1 X114.609 Y158.665 E1.82789
G1 X118.363 Y158.665 E.12451
G1 X178.514 Y98.514 E2.82181
G1 X177.497 Y97.242 E.05401
G1 X170.237 Y158.975 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X169.739 Y159.035 E.01388
G1 X86.057 Y159.023 E2.31847
G1 X85.732 Y158.955 E.00921
G1 X85.228 Y158.758 E.01497
G1 X84.874 Y158.501 E.01211
G1 X78.479 Y152.11 E.25051
G1 X78.18 Y151.733 E.01331
G1 X78 Y151.359 E.01152
G1 X77.873 Y150.804 E.01577
G1 X74.055 Y104.989 E1.27375
G1 X74.064 Y104.647 E.00946
G1 X74.173 Y104.113 E.01509
G1 X74.399 Y103.648 E.01433
G1 X80.905 Y93.888 E.32498
G1 X81.179 Y93.558 E.01189
G1 X81.583 Y93.246 E.01415
G1 X82.087 Y93.042 E.01506
G1 X82.637 Y92.965 E.01537
G1 X173.617 Y92.967 E2.52066
G1 X173.876 Y92.997 E.00724
G1 X174.371 Y93.138 E.01427
G1 X174.852 Y93.43 E.01558
G1 X175.164 Y93.744 E.01227
G1 X181.554 Y101.735 E.28347
G1 X181.771 Y102.108 E.01195
G1 X181.938 Y102.73 E.01783
G1 X181.952 Y103.026 E.00822
G1 X178.133 Y150.797 E1.32775
G3 X177.914 Y151.566 I-2.674 J-.344 E.02223
G1 X177.597 Y152.039 E.01577
G1 X171.217 Y158.423 E.25008
G3 X170.786 Y158.754 I-3.843 J-4.567 E.01505
G1 X170.292 Y158.953 E.01474
; Slow Down End
G1 X75.888 Y122.622 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X76.024 Y124.245 E.05401
G1 X106.94 Y93.328 E1.45037
G1 X110.68 Y93.328 E.12406
G1 X173.239 Y155.887 E2.93476
G1 X177.076 Y152.048 E.18005
G1 X118.356 Y93.328 E2.75465
G1 X114.616 Y93.328 E.12407
G1 X76.614 Y131.33 E1.78275
G1 X76.343 Y128.074 E.10838
G1 X106.932 Y158.664 E1.43501
G1 X110.688 Y158.664 E.12458
G1 X175.103 Y94.249 E3.02186
G2 X173.608 Y93.33 I-1.576 J.888 E.0608
G1 X172.089 Y93.33 E.05037
G1 X181.582 Y102.822 E.44533
G3 X181.58 Y103.124 I-1.275 J.142 E.01002
G1 X126.037 Y158.666 E2.60561
G1 X122.286 Y158.666 E.12444
G1 X74.947 Y111.327 E2.22077
G1 X74.843 Y110.074 E.04171
G1 X91.589 Y93.328 E.78559
G1 X95.328 Y93.328 E.12403
G1 X160.671 Y158.671 E3.0654
G1 X164.412 Y158.672 E.12408
G1 X178.245 Y144.838 E.64895
G1 X178.193 Y145.489 E.02167
G1 X126.032 Y93.328 E2.44698
G1 X122.292 Y93.328 E.12408
G1 X77.204 Y138.416 E2.11514
G1 X77.04 Y136.448 E.0655
G1 X99.255 Y158.663 E1.04213
G1 X103.013 Y158.663 E.12465
G1 X168.346 Y93.329 E3.06494
G1 X166.718 Y93.329 E.05401
G1 X89.28 Y93.328 F30000
G1 F15476.087
G1 X87.652 Y93.328 E.05401
G1 X152.994 Y158.67 E3.06535
G1 X156.737 Y158.671 E.12415
G1 X178.912 Y136.495 E1.04029
G1 X178.761 Y138.382 E.06277
G1 X133.708 Y93.329 E2.11353
G1 X129.968 Y93.329 E.12409
G1 X77.795 Y145.501 E2.44753
G1 X77.738 Y144.822 E.02261
G1 X91.578 Y158.662 E.64924
G1 X95.338 Y158.662 E.12473
G1 X160.671 Y93.329 E3.06489
G1 X164.413 Y93.329 E.12414
G1 X181.034 Y109.951 E.77974
G1 X180.913 Y111.467 E.05046
G1 X133.712 Y158.667 E2.21428
G1 X129.963 Y158.667 E.12437
G1 X74.878 Y103.582 E2.58414
G1 X77.319 Y99.922 E.14593
G1 X83.913 Y93.328 E.30935
G2 X81.971 Y93.457 I-.635 J5.111 E.06497
G2 X81.019 Y94.371 I.795 J1.78 E.04465
G1 X145.317 Y158.669 E3.01635
G1 X149.062 Y158.67 E.12423
G1 X179.579 Y128.153 E1.43162
G1 X179.33 Y131.274 E.10387
G1 X141.385 Y93.329 E1.78008
G1 X137.643 Y93.329 E.1241
G1 X78.927 Y152.045 E2.7545
G1 X82.766 Y155.882 E.18005
G1 X145.319 Y93.329 E2.93448
G1 X149.061 Y93.329 E.12411
G1 X179.898 Y124.166 E1.44663
G1 X180.028 Y122.543 E.05401
G1 X77.949 Y98.977 F30000
G1 F15476.087
G1 X137.64 Y158.668 E2.80024
G1 X141.387 Y158.669 E.1243
G1 X180.246 Y119.81 E1.82295
G1 X180.466 Y117.058 E.09156
G1 X156.737 Y93.329 E1.11318
G1 X152.995 Y93.329 E.12413
G1 X87.663 Y158.661 E3.06485
G1 X86.035 Y158.654 E.05399
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
M73 P63 R12
G1 X87.663 Y158.661 E-.61854
G1 X87.926 Y158.398 E-.14147
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 19/23
; update layer progress
M73 L19
M991 S0 P18 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4 I.739 J.967 P1  F30000
G1 X173.919 Y92.629 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G3 X175.44 Y93.508 I-.361 J2.38 E.05964
G1 X181.787 Y101.442 E.33706
G3 X182.309 Y103.144 I-1.907 J1.515 E.06043
G1 X178.493 Y150.843 E1.58734
G3 X177.793 Y152.36 I-2.403 J-.189 E.05658
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29697
G3 X169.754 Y159.398 I-1.722 J-1.742 E.0629
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.014 J-2.45 E.0629
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.703 J-1.706 E.05631
G1 X73.692 Y105 E1.52614
G3 X74.09 Y103.458 I2.44 J-.193 E.05381
G1 X80.611 Y93.676 E.38998
G3 X82.618 Y92.602 I2.012 J1.348 E.0786
G1 X173.682 Y92.605 E3.02076
G3 X173.86 Y92.621 I-.124 J2.404 E.00592
M204 S250
G1 X173.993 Y92.245 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.382 Y92.334 E.01227
G3 X175.743 Y93.259 I-.824 J2.675 E.05133
G1 X182.096 Y101.201 E.3125
G3 X182.7 Y103.17 I-2.221 J1.758 E.06478
G1 X178.883 Y150.879 E1.47065
G3 X178.073 Y152.634 I-2.794 J-.225 E.06063
G1 X171.736 Y158.971 E.27537
M73 P63 R11
G3 X169.759 Y159.79 I-1.999 J-2.029 E.06742
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.021 J-2.848 E.06742
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I1.983 J-1.98 E.06033
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.838 J-.219 E.05764
G1 X80.287 Y93.454 E.36153
G3 X82.613 Y92.21 I2.337 J1.572 E.08435
G1 X173.701 Y92.214 E2.7989
G3 X173.934 Y92.235 I-.143 J2.796 E.00717
M204 S10000
G1 X174.338 Y92.912 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40117
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X175.157 Y93.746 E.06021
G1 X177.641 Y96.853 E.20485
G1 X173.774 Y92.986 E.28163
G2 X173.125 Y92.975 I-.38 J3.242 E.03349
G1 X180.186 Y100.036 E.51426
G1 X181.558 Y101.752 E.11314
G3 X181.852 Y102.34 I-1.617 J1.175 E.03401
G1 X172.487 Y92.975 E.68206
G1 X171.849 Y92.975 E.03286
G1 X181.941 Y103.068 E.73507
G1 X181.894 Y103.658 E.03052
G1 X171.211 Y92.975 E.7781
G1 X170.572 Y92.975 E.03286
G1 X181.847 Y104.249 E.82113
G1 X181.8 Y104.84 E.03052
G1 X169.934 Y92.975 E.86416
G1 X169.296 Y92.975 E.03286
G1 X181.752 Y105.431 E.9072
G1 X181.705 Y106.022 E.03052
G1 X168.658 Y92.975 E.95023
G1 X168.02 Y92.975 E.03286
G1 X181.658 Y106.612 E.99326
G1 X181.611 Y107.203 E.03052
G1 X167.382 Y92.975 E1.03629
G1 X166.744 Y92.975 E.03286
G1 X181.563 Y107.794 E1.07932
G1 X181.516 Y108.385 E.03052
G1 X166.106 Y92.975 E1.12236
G1 X165.468 Y92.975 E.03286
G1 X181.469 Y108.976 E1.16539
G1 X181.422 Y109.567 E.03052
G1 X164.83 Y92.975 E1.20842
G1 X164.192 Y92.975 E.03286
G1 X181.375 Y110.157 E1.25145
G1 X181.327 Y110.748 E.03052
G1 X163.554 Y92.975 E1.29449
G1 X162.916 Y92.975 E.03286
G1 X181.28 Y111.339 E1.33752
G1 X181.233 Y111.93 E.03052
G1 X162.278 Y92.975 E1.38055
G1 X161.639 Y92.975 E.03286
G1 X181.186 Y112.521 E1.42358
G1 X181.138 Y113.111 E.03052
G1 X161.001 Y92.975 E1.46661
G1 X160.363 Y92.974 E.03286
G1 X181.091 Y113.702 E1.50965
G1 X181.044 Y114.293 E.03052
G1 X159.725 Y92.974 E1.55268
G1 X159.087 Y92.974 E.03286
G1 X180.997 Y114.884 E1.59571
G1 X180.949 Y115.475 E.03052
G1 X158.449 Y92.974 E1.63874
G1 X157.811 Y92.974 E.03286
G1 X180.902 Y116.066 E1.68177
G1 X180.855 Y116.656 E.03052
G1 X157.173 Y92.974 E1.72481
G1 X156.535 Y92.974 E.03286
G1 X180.808 Y117.247 E1.76784
G1 X180.761 Y117.838 E.03052
G1 X155.897 Y92.974 E1.81087
G1 X155.259 Y92.974 E.03286
G1 X180.713 Y118.429 E1.8539
G1 X180.666 Y119.02 E.03052
G1 X154.621 Y92.974 E1.89694
G1 X153.983 Y92.974 E.03286
G1 X180.619 Y119.611 E1.93997
G1 X180.572 Y120.201 E.03052
G1 X153.345 Y92.974 E1.983
G1 X152.706 Y92.974 E.03286
G1 X180.524 Y120.792 E2.02603
G1 X180.477 Y121.383 E.03052
G1 X152.068 Y92.974 E2.06906
G1 X151.43 Y92.974 E.03286
G1 X180.43 Y121.974 E2.1121
G1 X180.383 Y122.565 E.03052
G1 X150.792 Y92.974 E2.15513
G1 X150.154 Y92.974 E.03286
G1 X180.335 Y123.155 E2.19816
G1 X180.288 Y123.746 E.03052
G1 X149.516 Y92.974 E2.24119
G1 X148.878 Y92.974 E.03286
G1 X180.241 Y124.337 E2.28423
G1 X180.194 Y124.928 E.03052
G1 X148.24 Y92.974 E2.32726
G1 X147.602 Y92.974 E.03286
G1 X180.147 Y125.519 E2.37029
G1 X180.099 Y126.11 E.03052
G1 X146.964 Y92.974 E2.41332
G1 X146.326 Y92.974 E.03286
G1 X180.052 Y126.7 E2.45635
G1 X180.005 Y127.291 E.03052
G1 X145.688 Y92.974 E2.49939
G1 X145.05 Y92.974 E.03286
G1 X179.958 Y127.882 E2.54242
G1 X179.91 Y128.473 E.03052
G1 X144.412 Y92.974 E2.58545
G1 X143.773 Y92.974 E.03286
G1 X179.863 Y129.064 E2.62848
G1 X179.816 Y129.654 E.03052
G1 X143.135 Y92.974 E2.67152
G1 X142.497 Y92.974 E.03286
G1 X179.769 Y130.245 E2.71455
G1 X179.721 Y130.836 E.03052
G1 X141.859 Y92.974 E2.75758
G1 X141.221 Y92.974 E.03286
G1 X179.674 Y131.427 E2.80061
G1 X179.627 Y132.018 E.03052
G1 X140.583 Y92.974 E2.84364
G1 X139.945 Y92.974 E.03286
G1 X179.58 Y132.609 E2.88668
G1 X179.533 Y133.199 E.03052
G1 X139.307 Y92.974 E2.92971
G1 X138.669 Y92.974 E.03286
G1 X179.485 Y133.79 E2.97274
G1 X179.438 Y134.381 E.03052
M73 P64 R11
G1 X138.031 Y92.974 E3.01577
G1 X137.393 Y92.974 E.03286
G1 X179.391 Y134.972 E3.0588
G1 X179.344 Y135.563 E.03052
G1 X136.755 Y92.974 E3.10184
G1 X136.117 Y92.974 E.03286
G1 X179.296 Y136.153 E3.14487
G1 X179.249 Y136.744 E.03052
G1 X135.478 Y92.974 E3.1879
G1 X134.84 Y92.974 E.03286
G1 X179.202 Y137.335 E3.23093
G1 X179.155 Y137.926 E.03052
G1 X134.202 Y92.974 E3.27397
G1 X133.564 Y92.974 E.03286
G1 X179.107 Y138.517 E3.317
G1 X179.06 Y139.108 E.03052
G1 X132.926 Y92.974 E3.36003
G1 X132.288 Y92.974 E.03286
G1 X179.013 Y139.698 E3.40306
G1 X178.966 Y140.289 E.03052
G1 X131.65 Y92.973 E3.44609
G1 X131.012 Y92.973 E.03286
G1 X178.919 Y140.88 E3.48913
G1 X178.871 Y141.471 E.03052
G1 X130.374 Y92.973 E3.53216
G1 X129.736 Y92.973 E.03286
G1 X178.824 Y142.062 E3.57519
G1 X178.777 Y142.652 E.03052
G1 X129.098 Y92.973 E3.61822
G1 X128.46 Y92.973 E.03286
G1 X178.73 Y143.243 E3.66126
G1 X178.682 Y143.834 E.03052
G1 X127.822 Y92.973 E3.70429
G1 X127.184 Y92.973 E.03286
G1 X178.635 Y144.425 E3.74732
G1 X178.588 Y145.016 E.03052
G1 X126.545 Y92.973 E3.79035
G1 X125.907 Y92.973 E.03286
G1 X178.541 Y145.607 E3.83338
G1 X178.493 Y146.197 E.03052
G1 X125.269 Y92.973 E3.87642
G1 X124.631 Y92.973 E.03286
G1 X178.446 Y146.788 E3.91945
G1 X178.399 Y147.379 E.03052
G1 X123.993 Y92.973 E3.96248
G1 X123.355 Y92.973 E.03286
G1 X178.352 Y147.97 E4.00551
G1 X178.305 Y148.561 E.03052
G1 X122.717 Y92.973 E4.04854
G1 X122.079 Y92.973 E.03286
G1 X178.257 Y149.152 E4.09158
G1 X178.21 Y149.742 E.03052
G1 X121.441 Y92.973 E4.13461
G1 X120.803 Y92.973 E.03286
G1 X178.163 Y150.333 E4.17764
G3 X178.108 Y150.916 I-4.209 J-.101 E.0302
G1 X120.165 Y92.973 E4.22012
G1 X119.527 Y92.973 E.03286
G1 X177.977 Y151.423 E4.25703
G3 X177.75 Y151.835 I-1.732 J-.684 E.02426
G1 X118.889 Y92.973 E4.28702
G1 X118.251 Y92.973 E.03286
M73 P65 R11
G1 X177.452 Y152.174 E4.31175
G1 X177.133 Y152.493 E.02324
G1 X117.612 Y92.973 E4.33499
G1 X116.974 Y92.973 E.03286
G1 X176.814 Y152.813 E4.35823
G1 X176.495 Y153.132 E.02324
G1 X116.336 Y92.973 E4.38148
G1 X115.698 Y92.973 E.03286
G1 X176.176 Y153.451 E4.40472
G1 X175.857 Y153.77 E.02323
G1 X115.06 Y92.973 E4.42797
G1 X114.422 Y92.973 E.03286
G1 X175.538 Y154.089 E4.45121
G1 X175.219 Y154.408 E.02324
G1 X113.784 Y92.973 E4.47445
G1 X113.146 Y92.973 E.03286
G1 X174.9 Y154.727 E4.4977
G1 X174.581 Y155.046 E.02324
G1 X112.508 Y92.973 E4.52094
G1 X111.87 Y92.973 E.03286
G1 X174.263 Y155.366 E4.54419
G1 X173.944 Y155.685 E.02324
G1 X111.232 Y92.973 E4.56743
G1 X110.594 Y92.973 E.03286
G1 X173.625 Y156.004 E4.59067
G1 X173.306 Y156.323 E.02324
G1 X109.956 Y92.973 E4.61392
G1 X109.318 Y92.973 E.03286
G1 X172.987 Y156.642 E4.63716
G1 X172.668 Y156.961 E.02324
G1 X108.679 Y92.973 E4.66041
G1 X108.041 Y92.973 E.03286
G1 X172.349 Y157.28 E4.68365
G1 X172.03 Y157.599 E.02324
G1 X107.403 Y92.973 E4.70689
G1 X106.765 Y92.973 E.03286
G1 X171.711 Y157.919 E4.73014
G1 X171.392 Y158.238 E.02323
M73 P66 R11
G1 X106.127 Y92.973 E4.75338
G1 X105.489 Y92.973 E.03286
G1 X171.067 Y158.55 E4.77615
G3 X170.746 Y158.768 I-2.007 J-2.616 E.01998
G1 X170.68 Y158.801 E.00381
G1 X104.851 Y92.973 E4.79443
G1 X104.213 Y92.973 E.03286
G1 X170.214 Y158.973 E4.80696
G3 X169.63 Y159.028 I-.518 J-2.373 E.03024
G1 X103.575 Y92.973 E4.81096
M73 P66 R10
G1 X102.937 Y92.972 E.03286
G1 X168.992 Y159.028 E4.81096
G1 X168.354 Y159.028 E.03286
G1 X102.299 Y92.972 E4.81095
G1 X101.661 Y92.972 E.03286
G1 X167.716 Y159.028 E4.81095
G1 X167.078 Y159.028 E.03286
G1 X101.023 Y92.972 E4.81094
G1 X100.384 Y92.972 E.03286
G1 X166.44 Y159.028 E4.81094
G1 X165.802 Y159.028 E.03286
G1 X99.746 Y92.972 E4.81093
G1 X99.108 Y92.972 E.03286
G1 X165.164 Y159.028 E4.81093
G1 X164.525 Y159.027 E.03286
G1 X98.47 Y92.972 E4.81092
G1 X97.832 Y92.972 E.03286
G1 X163.887 Y159.027 E4.81092
G1 X163.249 Y159.027 E.03286
G1 X97.194 Y92.972 E4.81091
M73 P67 R10
G1 X96.556 Y92.972 E.03286
G1 X162.611 Y159.027 E4.81091
G1 X161.973 Y159.027 E.03286
G1 X95.918 Y92.972 E4.8109
G1 X95.28 Y92.972 E.03286
G1 X161.335 Y159.027 E4.8109
G1 X160.697 Y159.027 E.03286
G1 X94.642 Y92.972 E4.81089
G1 X94.004 Y92.972 E.03286
G1 X160.058 Y159.027 E4.81089
G1 X159.42 Y159.027 E.03286
G1 X93.366 Y92.972 E4.81088
G1 X92.728 Y92.972 E.03286
G1 X158.782 Y159.027 E4.81088
G1 X158.144 Y159.027 E.03286
G1 X92.09 Y92.972 E4.81087
G1 X91.451 Y92.972 E.03286
G1 X157.506 Y159.026 E4.81087
G1 X156.868 Y159.026 E.03286
G1 X90.813 Y92.972 E4.81086
G1 X90.175 Y92.972 E.03286
G1 X156.23 Y159.026 E4.81086
G1 X155.591 Y159.026 E.03286
G1 X89.537 Y92.972 E4.81085
M73 P68 R10
G1 X88.899 Y92.972 E.03286
G1 X154.953 Y159.026 E4.81085
G1 X154.315 Y159.026 E.03286
G1 X88.261 Y92.972 E4.81084
G1 X87.623 Y92.972 E.03286
G1 X153.677 Y159.026 E4.81084
G1 X153.039 Y159.026 E.03286
G1 X86.985 Y92.972 E4.81083
G1 X86.347 Y92.972 E.03286
G1 X152.401 Y159.026 E4.81083
G1 X151.763 Y159.026 E.03286
G1 X85.709 Y92.972 E4.81082
G1 X85.071 Y92.972 E.03286
G1 X151.124 Y159.026 E4.81082
G1 X150.486 Y159.026 E.03286
G1 X84.433 Y92.972 E4.81081
G1 X83.795 Y92.972 E.03286
G1 X149.848 Y159.025 E4.81081
G1 X149.21 Y159.025 E.03286
G1 X83.157 Y92.972 E4.8108
G2 X82.523 Y92.977 I-.265 J6.536 E.03262
G1 X148.572 Y159.025 E4.81044
G1 X147.934 Y159.025 E.03286
G1 X81.986 Y93.077 E4.80311
M73 P69 R10
G2 X81.546 Y93.275 I.766 J2.289 E.02489
G1 X147.296 Y159.025 E4.78868
G1 X146.657 Y159.025 E.03286
G1 X81.188 Y93.556 E4.76824
G2 X80.901 Y93.907 I2.022 J1.949 E.02338
G1 X146.019 Y159.025 E4.74268
G1 X145.381 Y159.025 E.03286
G1 X80.646 Y94.29 E4.71479
M73 P69 R9
G1 X80.391 Y94.672 E.0237
G1 X144.743 Y159.025 E4.6869
G1 X144.105 Y159.025 E.03286
G1 X80.136 Y95.055 E4.65901
G1 X79.88 Y95.438 E.02369
G1 X143.467 Y159.025 E4.63112
G1 X142.829 Y159.024 E.03286
G1 X79.625 Y95.821 E4.60324
G1 X79.37 Y96.204 E.0237
G1 X142.19 Y159.024 E4.57535
G1 X141.552 Y159.024 E.03286
G1 X79.115 Y96.587 E4.54746
M73 P70 R9
G1 X78.859 Y96.969 E.0237
G1 X140.914 Y159.024 E4.51957
G1 X140.276 Y159.024 E.03286
G1 X78.604 Y97.352 E4.49168
G1 X78.349 Y97.735 E.0237
G1 X139.638 Y159.024 E4.46379
G1 X139 Y159.024 E.03286
G1 X78.094 Y98.118 E4.4359
G1 X77.839 Y98.501 E.0237
G1 X138.362 Y159.024 E4.40801
G1 X137.723 Y159.024 E.03286
G1 X77.583 Y98.884 E4.38013
G1 X77.328 Y99.266 E.0237
G1 X137.085 Y159.024 E4.35224
G1 X136.447 Y159.024 E.03286
G1 X77.073 Y99.649 E4.32435
G1 X76.818 Y100.032 E.0237
G1 X135.809 Y159.023 E4.29646
G1 X135.171 Y159.023 E.03286
G1 X76.562 Y100.415 E4.26857
G1 X76.307 Y100.798 E.0237
G1 X134.533 Y159.023 E4.24068
G1 X133.895 Y159.023 E.03286
M73 P71 R9
G1 X76.052 Y101.181 E4.21279
G1 X75.797 Y101.563 E.0237
G1 X133.257 Y159.023 E4.1849
G1 X132.618 Y159.023 E.03286
G1 X75.542 Y101.946 E4.15702
G1 X75.286 Y102.329 E.0237
G1 X131.98 Y159.023 E4.12913
G1 X131.342 Y159.023 E.03286
G1 X75.031 Y102.712 E4.10124
G1 X74.776 Y103.095 E.0237
G1 X130.704 Y159.023 E4.07335
G1 X130.066 Y159.023 E.03286
G1 X74.521 Y103.477 E4.04546
G2 X74.279 Y103.873 I2.657 J1.897 E.02392
G1 X129.428 Y159.023 E4.01662
G1 X128.79 Y159.022 E.03286
G1 X74.107 Y104.34 E3.9826
G2 X74.061 Y104.932 I2.34 J.482 E.03063
G1 X128.151 Y159.022 E3.93952
G1 X127.513 Y159.022 E.03286
M73 P72 R9
G1 X74.115 Y105.624 E3.88911
G1 X74.173 Y106.32 E.03597
G1 X126.875 Y159.022 E3.83841
G1 X126.237 Y159.022 E.03286
G1 X74.231 Y107.016 E3.78771
G1 X74.289 Y107.712 E.03597
G1 X125.599 Y159.022 E3.737
G1 X124.961 Y159.022 E.03286
G1 X74.347 Y108.408 E3.6863
G1 X74.405 Y109.104 E.03597
M73 P72 R8
G1 X124.323 Y159.022 E3.6356
G1 X123.684 Y159.022 E.03286
G1 X74.463 Y109.8 E3.5849
G1 X74.521 Y110.496 E.03597
G1 X123.046 Y159.022 E3.5342
G1 X122.408 Y159.022 E.03286
G1 X74.579 Y111.192 E3.4835
G1 X74.637 Y111.888 E.03597
G1 X121.77 Y159.021 E3.43279
G1 X121.132 Y159.021 E.03286
G1 X74.695 Y112.584 E3.38209
G1 X74.753 Y113.28 E.03597
M73 P73 R8
G1 X120.494 Y159.021 E3.33139
G1 X119.856 Y159.021 E.03286
G1 X74.811 Y113.977 E3.28069
G1 X74.869 Y114.673 E.03597
G1 X119.217 Y159.021 E3.22999
G1 X118.579 Y159.021 E.03286
G1 X74.927 Y115.369 E3.17929
G1 X74.985 Y116.065 E.03597
G1 X117.941 Y159.021 E3.12858
G1 X117.303 Y159.021 E.03286
G1 X75.043 Y116.761 E3.07788
G1 X75.101 Y117.457 E.03597
G1 X116.665 Y159.021 E3.02718
G1 X116.027 Y159.021 E.03286
G1 X75.159 Y118.153 E2.97648
G1 X75.217 Y118.849 E.03597
G1 X115.389 Y159.021 E2.92578
G1 X114.75 Y159.02 E.03286
G1 X75.275 Y119.545 E2.87508
G1 X75.333 Y120.241 E.03597
M73 P74 R8
G1 X114.112 Y159.02 E2.82438
G1 X113.474 Y159.02 E.03286
G1 X75.391 Y120.937 E2.77367
G1 X75.449 Y121.633 E.03597
G1 X112.836 Y159.02 E2.72297
G1 X112.198 Y159.02 E.03286
G1 X75.507 Y122.329 E2.67227
G1 X75.565 Y123.025 E.03597
G1 X111.56 Y159.02 E2.62157
G1 X110.922 Y159.02 E.03286
G1 X75.623 Y123.721 E2.57087
G1 X75.681 Y124.417 E.03597
G1 X110.283 Y159.02 E2.52017
G1 X109.645 Y159.02 E.03286
G1 X75.739 Y125.113 E2.46946
G1 X75.797 Y125.809 E.03597
G1 X109.007 Y159.02 E2.41876
G1 X108.369 Y159.02 E.03286
G1 X75.855 Y126.506 E2.36806
G1 X75.913 Y127.202 E.03597
G1 X107.731 Y159.02 E2.31736
G1 X107.093 Y159.019 E.03286
M73 P75 R8
G1 X75.971 Y127.898 E2.26666
G1 X76.029 Y128.594 E.03597
G1 X106.455 Y159.019 E2.21596
G1 X105.816 Y159.019 E.03286
G1 X76.087 Y129.29 E2.16525
G1 X76.145 Y129.986 E.03597
G1 X105.178 Y159.019 E2.11455
G1 X104.54 Y159.019 E.03286
G1 X76.203 Y130.682 E2.06385
G1 X76.261 Y131.378 E.03597
G1 X103.902 Y159.019 E2.01315
G1 X103.264 Y159.019 E.03286
M73 P75 R7
G1 X76.319 Y132.074 E1.96245
G1 X76.377 Y132.77 E.03597
G1 X102.626 Y159.019 E1.91175
G1 X101.988 Y159.019 E.03286
G1 X76.435 Y133.466 E1.86104
G1 X76.493 Y134.162 E.03597
G1 X101.35 Y159.019 E1.81034
G1 X100.711 Y159.019 E.03286
G1 X76.551 Y134.858 E1.75964
G1 X76.609 Y135.554 E.03597
G1 X100.073 Y159.018 E1.70894
G1 X99.435 Y159.018 E.03286
M73 P76 R7
G1 X76.667 Y136.25 E1.65824
G1 X76.725 Y136.946 E.03597
G1 X98.797 Y159.018 E1.60754
G1 X98.159 Y159.018 E.03286
G1 X76.783 Y137.642 E1.55683
G1 X76.841 Y138.338 E.03597
G1 X97.521 Y159.018 E1.50613
G1 X96.883 Y159.018 E.03286
G1 X76.899 Y139.035 E1.45543
G1 X76.957 Y139.731 E.03597
G1 X96.244 Y159.018 E1.40473
G1 X95.606 Y159.018 E.03286
G1 X77.015 Y140.427 E1.35403
G1 X77.073 Y141.123 E.03597
G1 X94.968 Y159.018 E1.30333
G1 X94.33 Y159.018 E.03286
G1 X77.131 Y141.819 E1.25263
G1 X77.189 Y142.515 E.03597
G1 X93.692 Y159.018 E1.20192
G1 X93.054 Y159.017 E.03286
G1 X77.247 Y143.211 E1.15122
G1 X77.305 Y143.907 E.03597
G1 X92.416 Y159.017 E1.10052
G1 X91.777 Y159.017 E.03286
G1 X77.363 Y144.603 E1.04982
G1 X77.421 Y145.299 E.03597
M73 P77 R7
G1 X91.139 Y159.017 E.99912
G1 X90.501 Y159.017 E.03286
G1 X77.479 Y145.995 E.94842
G1 X77.537 Y146.691 E.03597
G1 X89.863 Y159.017 E.89771
G1 X89.225 Y159.017 E.03286
G1 X77.595 Y147.387 E.84701
G1 X77.653 Y148.083 E.03597
G1 X88.587 Y159.017 E.79631
G1 X87.949 Y159.017 E.03286
G1 X77.711 Y148.779 E.74561
G1 X77.769 Y149.475 E.03597
G1 X87.31 Y159.017 E.69491
G1 X86.672 Y159.017 E.03286
G1 X77.827 Y150.171 E.64421
G2 X77.888 Y150.871 I7.6 J-.312 E.03616
G1 X86.032 Y159.014 E.59313
G3 X85.007 Y158.597 I.225 J-2.019 E.05773
G1 X84.882 Y158.499 E.00816
G1 X77.816 Y151.436 E.51451
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X79.231 Y152.85 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 20/23
; update layer progress
M73 L20
M991 S0 P19 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.2 I.653 J1.027 P1  F30000
G1 X173.919 Y92.63 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X175.44 Y93.508 I-.359 J2.377 E.05962
G1 X181.787 Y101.442 E.33707
G3 X182.309 Y103.144 I-1.907 J1.515 E.06042
G1 X178.493 Y150.843 E1.58734
M73 P78 R7
G3 X177.793 Y152.36 I-2.403 J-.189 E.0566
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.462 Y158.69 E.29696
G3 X169.754 Y159.398 I-1.716 J-1.728 E.06292
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.006 J-2.431 E.06294
G1 X78.212 Y152.356 E.29715
G3 X77.513 Y150.848 I1.712 J-1.71 E.0563
G1 X73.692 Y105 E1.52613
G3 X74.091 Y103.456 I2.441 J-.193 E.0539
G1 X80.611 Y93.676 E.38989
G3 X82.618 Y92.602 I2.012 J1.347 E.07861
G1 X173.655 Y92.605 E3.01988
G3 X173.86 Y92.621 I-.095 J2.402 E.00681
M204 S250
G1 X173.995 Y92.245 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.249 Y92.297 E.00798
G3 X175.743 Y93.259 I-.689 J2.71 E.05555
G1 X182.096 Y101.201 E.31252
G3 X182.7 Y103.17 I-2.22 J1.758 E.06478
G1 X178.883 Y150.88 E1.47065
G3 X178.073 Y152.634 I-2.793 J-.225 E.06064
G1 X171.736 Y158.971 E.27536
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
M73 P78 R6
G3 X84.272 Y158.971 I.013 J-2.827 E.06745
G1 X77.931 Y152.63 E.27554
G3 X77.122 Y150.885 I1.993 J-1.984 E.06032
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.243 I2.838 J-.219 E.05767
G1 X80.287 Y93.454 E.3615
G3 X82.613 Y92.21 I2.337 J1.571 E.08435
G1 X173.673 Y92.213 E2.79803
G3 X173.936 Y92.236 I-.113 J2.794 E.0081
; WIPE_START
M204 S10000
G1 X174.249 Y92.297 E-.12146
G1 X174.515 Y92.378 E-.10554
G1 X174.771 Y92.485 E-.10556
G1 X175.015 Y92.618 E-.10545
G1 X175.353 Y92.861 E-.15823
G1 X175.537 Y93.03 E-.09477
G1 X175.658 Y93.165 E-.06898
; WIPE_END
G1 E-.04 F1800
G1 X175.076 Y100.775 Z4.4 F30000
G1 X170.618 Y159.063 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42082
G1 F15000
M73 P79 R6
G1 X177.626 Y152.052 E.30526
G2 X178.13 Y151.017 I-1.593 J-1.416 E.03589
G1 X170.12 Y159.026 E.34881
G3 X169.547 Y159.065 I-.465 J-2.665 E.0177
G1 X178.192 Y150.42 E.37649
G1 X178.239 Y149.839 E.01794
G1 X169.013 Y159.065 E.40178
G1 X168.479 Y159.065 E.01646
G1 X178.285 Y149.258 E.42707
G1 X178.332 Y148.677 E.01794
G1 X167.944 Y159.064 E.45236
G1 X167.41 Y159.064 E.01646
G1 X178.378 Y148.096 E.47766
G1 X178.425 Y147.515 E.01794
G1 X166.876 Y159.064 E.50295
G1 X166.341 Y159.064 E.01646
G1 X178.471 Y146.934 E.52824
G1 X178.518 Y146.354 E.01794
G1 X165.807 Y159.064 E.55354
G1 X165.273 Y159.064 E.01645
G1 X178.564 Y145.773 E.57883
G1 X178.61 Y145.192 E.01794
G1 X164.738 Y159.064 E.60412
G1 X164.204 Y159.064 E.01646
G1 X178.657 Y144.611 E.62942
G1 X178.703 Y144.03 E.01794
G1 X163.67 Y159.064 E.65471
G1 X163.135 Y159.064 E.01646
G1 X178.75 Y143.449 E.68
G1 X178.796 Y142.868 E.01794
G1 X162.601 Y159.064 E.7053
G1 X162.066 Y159.064 E.01646
G1 X178.843 Y142.288 E.73059
G1 X178.889 Y141.707 E.01794
G1 X161.532 Y159.064 E.75588
G1 X160.998 Y159.063 E.01646
G1 X178.935 Y141.126 E.78118
G1 X178.982 Y140.545 E.01794
G1 X160.463 Y159.063 E.80647
G1 X159.929 Y159.063 E.01646
G1 X179.028 Y139.964 E.83176
G1 X179.075 Y139.383 E.01794
G1 X159.395 Y159.063 E.85705
G1 X158.86 Y159.063 E.01645
G1 X179.121 Y138.802 E.88235
G1 X179.168 Y138.221 E.01794
G1 X158.326 Y159.063 E.90764
G1 X157.792 Y159.063 E.01645
G1 X179.214 Y137.641 E.93293
G1 X179.26 Y137.06 E.01794
G1 X157.257 Y159.063 E.95823
G1 X156.723 Y159.063 E.01646
G1 X179.307 Y136.479 E.98352
G1 X179.353 Y135.898 E.01794
G1 X156.189 Y159.063 E1.00881
G1 X155.654 Y159.063 E.01646
G1 X179.4 Y135.317 E1.03411
G1 X179.446 Y134.736 E.01794
G1 X155.12 Y159.063 E1.0594
G1 X154.585 Y159.063 E.01645
G1 X179.493 Y134.155 E1.08469
G1 X179.539 Y133.575 E.01794
G1 X154.051 Y159.062 E1.10999
G1 X153.517 Y159.062 E.01645
G1 X179.586 Y132.994 E1.13528
G1 X179.632 Y132.413 E.01794
G1 X152.982 Y159.062 E1.16057
G1 X152.448 Y159.062 E.01646
G1 X179.678 Y131.832 E1.18586
G1 X179.725 Y131.251 E.01794
G1 X151.914 Y159.062 E1.21116
G1 X151.379 Y159.062 E.01646
G1 X179.771 Y130.67 E1.23645
G1 X179.818 Y130.089 E.01794
G1 X150.845 Y159.062 E1.26174
G1 X150.311 Y159.062 E.01646
G1 X179.864 Y129.508 E1.28704
G1 X179.911 Y128.928 E.01794
G1 X149.776 Y159.062 E1.31233
G1 X149.242 Y159.062 E.01645
G1 X179.957 Y128.347 E1.33762
G1 X180.003 Y127.766 E.01794
G1 X148.708 Y159.062 E1.36292
G1 X148.173 Y159.062 E.01646
G1 X180.05 Y127.185 E1.38821
G1 X180.096 Y126.604 E.01794
G1 X147.639 Y159.062 E1.4135
G1 X147.104 Y159.061 E.01645
G1 X180.143 Y126.023 E1.4388
G1 X180.189 Y125.442 E.01794
G1 X146.57 Y159.061 E1.46409
G1 X146.036 Y159.061 E.01646
G1 X180.236 Y124.862 E1.48938
G1 X180.282 Y124.281 E.01794
G1 X145.501 Y159.061 E1.51468
G1 X144.967 Y159.061 E.01646
G1 X180.328 Y123.7 E1.53997
G1 X180.375 Y123.119 E.01794
G1 X144.433 Y159.061 E1.56526
G1 X143.898 Y159.061 E.01646
G1 X180.421 Y122.538 E1.59055
G1 X180.468 Y121.957 E.01794
G1 X143.364 Y159.061 E1.61585
G1 X142.83 Y159.061 E.01645
G1 X180.514 Y121.376 E1.64114
G1 X180.561 Y120.795 E.01794
G1 X142.295 Y159.061 E1.66643
G1 X141.761 Y159.061 E.01645
G1 X180.607 Y120.215 E1.69173
G1 X180.654 Y119.634 E.01794
G1 X141.227 Y159.061 E1.71702
G1 X140.692 Y159.061 E.01646
G1 X180.7 Y119.053 E1.74231
G1 X180.746 Y118.472 E.01794
G1 X140.158 Y159.061 E1.76761
G1 X139.624 Y159.06 E.01646
G1 X180.793 Y117.891 E1.7929
G1 X180.839 Y117.31 E.01794
G1 X139.089 Y159.06 E1.81819
G1 X138.555 Y159.06 E.01645
G1 X180.886 Y116.729 E1.84349
G1 X180.932 Y116.149 E.01794
G1 X138.02 Y159.06 E1.86878
G1 X137.486 Y159.06 E.01645
G1 X180.979 Y115.568 E1.89407
G1 X181.025 Y114.987 E.01794
G1 X136.952 Y159.06 E1.91936
G1 X136.417 Y159.06 E.01646
G1 X181.071 Y114.406 E1.94466
G1 X181.118 Y113.825 E.01794
G1 X135.883 Y159.06 E1.96995
G1 X135.349 Y159.06 E.01646
G1 X181.164 Y113.244 E1.99524
G1 X181.211 Y112.663 E.01794
G1 X134.814 Y159.06 E2.02054
G1 X134.28 Y159.06 E.01646
G1 X181.257 Y112.082 E2.04583
G1 X181.304 Y111.502 E.01794
G1 X133.746 Y159.06 E2.07112
G1 X133.211 Y159.06 E.01645
G1 X181.35 Y110.921 E2.09642
G1 X181.397 Y110.34 E.01794
G1 X132.677 Y159.059 E2.12171
G1 X132.143 Y159.059 E.01646
G1 X181.443 Y109.759 E2.147
G1 X181.489 Y109.178 E.01794
G1 X131.608 Y159.059 E2.1723
G1 X131.074 Y159.059 E.01645
G1 X181.536 Y108.597 E2.19759
G1 X181.582 Y108.016 E.01794
G1 X130.539 Y159.059 E2.22288
G1 X130.005 Y159.059 E.01646
G1 X181.629 Y107.436 E2.24818
G1 X181.675 Y106.855 E.01794
G1 X129.471 Y159.059 E2.27347
G1 X128.936 Y159.059 E.01646
G1 X181.722 Y106.274 E2.29876
G1 X181.768 Y105.693 E.01794
G1 X128.402 Y159.059 E2.32405
G1 X127.868 Y159.059 E.01646
G1 X181.814 Y105.112 E2.34935
G1 X181.861 Y104.531 E.01794
G1 X127.333 Y159.059 E2.37464
G1 X126.799 Y159.059 E.01645
G1 X181.907 Y103.95 E2.39993
G1 X181.954 Y103.369 E.01794
G1 X126.265 Y159.059 E2.42523
G1 X125.73 Y159.058 E.01645
G1 X181.974 Y102.815 E2.44939
G1 X181.895 Y102.359 E.01424
G1 X125.196 Y159.058 E2.46922
G1 X124.662 Y159.058 E.01645
G1 X181.742 Y101.978 E2.4858
G2 X181.529 Y101.657 I-1.465 J.74 E.0119
G1 X124.127 Y159.058 E2.49979
G1 X123.593 Y159.058 E.01646
G1 X181.291 Y101.36 E2.51272
G1 X181.054 Y101.063 E.01171
G1 X123.058 Y159.058 E2.52565
G1 X122.524 Y159.058 E.01646
G1 X180.816 Y100.766 E2.53858
G1 X180.579 Y100.469 E.01171
G1 X121.99 Y159.058 E2.55151
G1 X121.455 Y159.058 E.01645
G1 X180.341 Y100.172 E2.56444
G1 X180.104 Y99.875 E.01171
G1 X120.921 Y159.058 E2.57737
G1 X120.387 Y159.058 E.01646
G1 X179.866 Y99.578 E2.5903
G1 X179.629 Y99.281 E.01171
G1 X119.852 Y159.058 E2.60323
G1 X119.318 Y159.058 E.01645
G1 X179.391 Y98.984 E2.61616
G1 X179.154 Y98.687 E.01171
G1 X118.784 Y159.058 E2.62909
G1 X118.249 Y159.057 E.01646
G1 X178.917 Y98.39 E2.64202
G1 X178.679 Y98.093 E.01171
M73 P80 R6
G1 X117.715 Y159.057 E2.65495
G1 X117.181 Y159.057 E.01646
G1 X178.442 Y97.796 E2.66788
G1 X178.204 Y97.499 E.01171
G1 X116.646 Y159.057 E2.68081
G1 X116.112 Y159.057 E.01646
G1 X177.967 Y97.202 E2.69374
G1 X177.729 Y96.905 E.01171
G1 X115.577 Y159.057 E2.70668
G1 X115.043 Y159.057 E.01645
G1 X177.492 Y96.608 E2.7196
G1 X177.254 Y96.311 E.01171
G1 X114.509 Y159.057 E2.73254
G1 X113.974 Y159.057 E.01646
G1 X177.017 Y96.014 E2.74547
G1 X176.78 Y95.717 E.01171
G1 X113.44 Y159.057 E2.7584
G1 X112.906 Y159.057 E.01646
G1 X176.542 Y95.42 E2.77133
G1 X176.305 Y95.123 E.01171
G1 X112.371 Y159.057 E2.78425
G1 X111.837 Y159.057 E.01646
G1 X176.067 Y94.826 E2.79719
G1 X175.83 Y94.529 E.01171
G1 X111.303 Y159.056 E2.81012
G1 X110.768 Y159.056 E.01645
G1 X175.592 Y94.232 E2.82305
G1 X175.355 Y93.935 E.01171
G1 X110.234 Y159.056 E2.83598
G1 X109.7 Y159.056 E.01646
G1 X175.109 Y93.646 E2.84855
G1 X174.839 Y93.383 E.01164
G1 X109.165 Y159.056 E2.86003
G1 X108.631 Y159.056 E.01645
G1 X174.515 Y93.172 E2.86923
G2 X174.13 Y93.022 I-.688 J1.206 E.01277
G1 X108.096 Y159.056 E2.87572
G1 X107.562 Y159.056 E.01646
G1 X173.677 Y92.941 E2.87925
G2 X173.146 Y92.938 I-.284 J2.875 E.01638
G1 X107.028 Y159.056 E2.8794
G1 X106.493 Y159.056 E.01646
G1 X172.611 Y92.938 E2.8794
G1 X172.077 Y92.938 E.01646
G1 X105.959 Y159.056 E2.8794
G1 X105.425 Y159.056 E.01645
G1 X171.543 Y92.938 E2.87939
G1 X171.008 Y92.938 E.01646
G1 X104.89 Y159.056 E2.87939
G1 X104.356 Y159.055 E.01645
G1 X170.474 Y92.938 E2.87939
G1 X169.939 Y92.938 E.01646
G1 X103.822 Y159.055 E2.87939
G1 X103.287 Y159.055 E.01645
G1 X169.405 Y92.938 E2.87938
G1 X168.871 Y92.938 E.01646
G1 X102.753 Y159.055 E2.87938
G1 X102.219 Y159.055 E.01646
G1 X168.336 Y92.938 E2.87938
G1 X167.802 Y92.938 E.01646
G1 X101.684 Y159.055 E2.87937
G1 X101.15 Y159.055 E.01646
G1 X167.267 Y92.938 E2.87937
G1 X166.733 Y92.938 E.01646
G1 X100.615 Y159.055 E2.87937
G1 X100.081 Y159.055 E.01646
G1 X166.198 Y92.938 E2.87937
G1 X165.664 Y92.938 E.01646
G1 X99.547 Y159.055 E2.87936
G1 X99.012 Y159.055 E.01645
G1 X165.13 Y92.938 E2.87936
G1 X164.595 Y92.938 E.01646
G1 X98.478 Y159.055 E2.87936
G1 X97.944 Y159.055 E.01646
G1 X164.061 Y92.938 E2.87936
G1 X163.526 Y92.938 E.01646
G1 X97.409 Y159.055 E2.87935
G1 X96.875 Y159.054 E.01646
G1 X162.992 Y92.938 E2.87935
G1 X162.458 Y92.938 E.01646
G1 X96.341 Y159.054 E2.87935
G1 X95.806 Y159.054 E.01646
G1 X161.923 Y92.938 E2.87935
G1 X161.389 Y92.937 E.01646
G1 X95.272 Y159.054 E2.87934
G1 X94.738 Y159.054 E.01645
G1 X160.854 Y92.937 E2.87934
G1 X160.32 Y92.937 E.01646
G1 X94.203 Y159.054 E2.87934
G1 X93.669 Y159.054 E.01646
G1 X159.785 Y92.937 E2.87934
G1 X159.251 Y92.937 E.01646
G1 X93.134 Y159.054 E2.87933
G1 X92.6 Y159.054 E.01645
G1 X158.717 Y92.937 E2.87933
G1 X158.182 Y92.937 E.01646
G1 X92.066 Y159.054 E2.87933
G1 X91.531 Y159.054 E.01646
G1 X157.648 Y92.937 E2.87933
G1 X157.113 Y92.937 E.01646
G1 X90.997 Y159.054 E2.87932
G1 X90.463 Y159.054 E.01646
G1 X156.579 Y92.937 E2.87932
G1 X156.045 Y92.937 E.01646
G1 X89.928 Y159.053 E2.87932
G1 X89.394 Y159.053 E.01646
G1 X155.51 Y92.937 E2.87931
G1 X154.976 Y92.937 E.01646
G1 X88.86 Y159.053 E2.87931
G1 X88.325 Y159.053 E.01645
G1 X154.441 Y92.937 E2.87931
G1 X153.907 Y92.937 E.01646
G1 X87.791 Y159.053 E2.87931
G1 X87.257 Y159.053 E.01645
G1 X153.372 Y92.937 E2.8793
G1 X152.838 Y92.937 E.01646
G1 X86.722 Y159.053 E2.8793
G1 X86.188 Y159.053 E.01646
M73 P81 R6
G1 X152.304 Y92.937 E2.8793
G1 X151.769 Y92.937 E.01646
G1 X85.716 Y158.991 E2.87659
G1 X85.329 Y158.843 E.01275
G1 X151.235 Y92.937 E2.87016
G1 X150.7 Y92.937 E.01646
G1 X85 Y158.637 E2.8612
G3 X84.717 Y158.386 I.881 J-1.276 E.01169
G1 X150.166 Y92.937 E2.85025
G1 X149.632 Y92.937 E.01646
G1 X84.45 Y158.119 E2.83862
G1 X84.183 Y157.852 E.01164
G1 X149.097 Y92.937 E2.82698
G1 X148.563 Y92.937 E.01646
G1 X83.915 Y157.584 E2.81535
G1 X83.648 Y157.317 E.01164
G1 X148.028 Y92.937 E2.80372
G1 X147.494 Y92.937 E.01646
G1 X83.381 Y157.05 E2.79209
G1 X83.113 Y156.783 E.01164
G1 X146.959 Y92.937 E2.78045
G1 X146.425 Y92.937 E.01646
G1 X82.846 Y156.516 E2.76882
G1 X82.579 Y156.249 E.01164
G1 X145.891 Y92.937 E2.75719
G1 X145.356 Y92.937 E.01646
G1 X82.311 Y155.982 E2.74556
G1 X82.044 Y155.715 E.01164
G1 X144.822 Y92.937 E2.73392
G1 X144.287 Y92.937 E.01646
G1 X81.777 Y155.447 E2.72229
G1 X81.51 Y155.18 E.01164
G1 X143.753 Y92.937 E2.71066
G1 X143.219 Y92.937 E.01646
G1 X81.242 Y154.913 E2.69903
G1 X80.975 Y154.646 E.01164
G1 X142.684 Y92.937 E2.68739
G1 X142.15 Y92.937 E.01646
G1 X80.708 Y154.379 E2.67576
G1 X80.44 Y154.112 E.01164
G1 X141.615 Y92.937 E2.66413
G1 X141.081 Y92.937 E.01646
G1 X80.173 Y153.845 E2.6525
G1 X79.906 Y153.578 E.01164
G1 X140.546 Y92.937 E2.64086
G1 X140.012 Y92.937 E.01646
G1 X79.638 Y153.31 E2.62923
G1 X79.371 Y153.043 E.01164
G1 X139.478 Y92.937 E2.6176
G1 X138.943 Y92.937 E.01646
G1 X79.104 Y152.776 E2.60597
G1 X78.837 Y152.509 E.01164
G1 X138.409 Y92.937 E2.59433
G1 X137.874 Y92.937 E.01646
G1 X78.569 Y152.242 E2.5827
G3 X78.31 Y151.967 I3.376 J-3.445 E.01164
G1 X137.34 Y92.937 E2.57073
G1 X136.806 Y92.937 E.01646
G1 X78.097 Y151.645 E2.55671
G3 X77.935 Y151.273 I1.621 J-.925 E.01253
G1 X136.271 Y92.937 E2.54049
G1 X135.737 Y92.937 E.01646
M73 P81 R5
G1 X77.846 Y150.827 E2.52111
G3 X77.804 Y150.335 I5.321 J-.699 E.01523
G1 X135.202 Y92.937 E2.49965
G1 X134.668 Y92.937 E.01646
G1 X77.763 Y149.841 E2.47817
G1 X77.722 Y149.348 E.01524
G1 X134.133 Y92.937 E2.45668
G1 X133.599 Y92.937 E.01646
G1 X77.681 Y148.855 E2.4352
G1 X77.64 Y148.362 E.01524
G1 X133.065 Y92.937 E2.41372
G1 X132.53 Y92.937 E.01646
G1 X77.599 Y147.868 E2.39223
G1 X77.558 Y147.375 E.01524
G1 X131.996 Y92.937 E2.37075
G1 X131.461 Y92.937 E.01646
G1 X77.516 Y146.882 E2.34927
G1 X77.475 Y146.388 E.01524
G1 X130.927 Y92.937 E2.32778
G1 X130.393 Y92.937 E.01646
G1 X77.434 Y145.895 E2.3063
G1 X77.393 Y145.402 E.01524
G1 X129.858 Y92.937 E2.28482
G1 X129.324 Y92.937 E.01646
G1 X77.352 Y144.908 E2.26333
G1 X77.311 Y144.415 E.01524
G1 X128.789 Y92.937 E2.24185
G1 X128.255 Y92.937 E.01646
G1 X77.27 Y143.922 E2.22037
G1 X77.229 Y143.428 E.01524
G1 X127.72 Y92.937 E2.19889
G1 X127.186 Y92.937 E.01646
G1 X77.188 Y142.935 E2.1774
G1 X77.146 Y142.442 E.01524
M73 P82 R5
G1 X126.652 Y92.937 E2.15592
G1 X126.117 Y92.937 E.01646
G1 X77.105 Y141.948 E2.13444
G1 X77.064 Y141.455 E.01524
G1 X125.583 Y92.937 E2.11295
G1 X125.048 Y92.936 E.01646
G1 X77.023 Y140.962 E2.09147
G1 X76.982 Y140.468 E.01524
G1 X124.514 Y92.936 E2.06999
G1 X123.98 Y92.936 E.01646
G1 X76.941 Y139.975 E2.0485
G1 X76.9 Y139.482 E.01524
G1 X123.445 Y92.936 E2.02702
G1 X122.911 Y92.936 E.01646
G1 X76.859 Y138.988 E2.00554
G1 X76.818 Y138.495 E.01524
G1 X122.376 Y92.936 E1.98405
G1 X121.842 Y92.936 E.01646
G1 X76.776 Y138.002 E1.96257
G1 X76.735 Y137.508 E.01524
G1 X121.307 Y92.936 E1.94109
G1 X120.773 Y92.936 E.01646
G1 X76.694 Y137.015 E1.9196
G1 X76.653 Y136.522 E.01524
G1 X120.239 Y92.936 E1.89812
G1 X119.704 Y92.936 E.01646
G1 X76.612 Y136.029 E1.87664
G1 X76.571 Y135.535 E.01524
G1 X119.17 Y92.936 E1.85515
G1 X118.635 Y92.936 E.01646
G1 X76.53 Y135.042 E1.83367
G1 X76.489 Y134.549 E.01524
G1 X118.101 Y92.936 E1.81219
G1 X117.567 Y92.936 E.01646
G1 X76.448 Y134.055 E1.7907
G1 X76.406 Y133.562 E.01524
G1 X117.032 Y92.936 E1.76922
G1 X116.498 Y92.936 E.01646
G1 X76.365 Y133.069 E1.74774
G1 X76.324 Y132.575 E.01524
G1 X115.963 Y92.936 E1.72626
G1 X115.429 Y92.936 E.01646
G1 X76.283 Y132.082 E1.70477
G1 X76.242 Y131.589 E.01524
G1 X114.894 Y92.936 E1.68329
G1 X114.36 Y92.936 E.01646
G1 X76.201 Y131.095 E1.66181
G1 X76.16 Y130.602 E.01524
G1 X113.826 Y92.936 E1.64032
G1 X113.291 Y92.936 E.01646
G1 X76.119 Y130.109 E1.61884
G1 X76.078 Y129.615 E.01524
G1 X112.757 Y92.936 E1.59736
G1 X112.222 Y92.936 E.01646
G1 X76.036 Y129.122 E1.57587
G1 X75.995 Y128.629 E.01524
G1 X111.688 Y92.936 E1.55439
G1 X111.154 Y92.936 E.01646
G1 X75.954 Y128.135 E1.53291
G1 X75.913 Y127.642 E.01524
G1 X110.619 Y92.936 E1.51142
G1 X110.085 Y92.936 E.01646
G1 X75.872 Y127.149 E1.48994
G1 X75.831 Y126.655 E.01524
G1 X109.55 Y92.936 E1.46846
G1 X109.016 Y92.936 E.01646
G1 X75.79 Y126.162 E1.44697
G1 X75.749 Y125.669 E.01524
G1 X108.481 Y92.936 E1.42549
G1 X107.947 Y92.936 E.01646
G1 X75.708 Y125.175 E1.40401
G1 X75.666 Y124.682 E.01524
G1 X107.413 Y92.936 E1.38252
G1 X106.878 Y92.936 E.01646
G1 X75.625 Y124.189 E1.36104
G1 X75.584 Y123.695 E.01524
G1 X106.344 Y92.936 E1.33956
G1 X105.809 Y92.936 E.01646
G1 X75.543 Y123.202 E1.31807
G1 X75.502 Y122.709 E.01524
G1 X105.275 Y92.936 E1.29659
G1 X104.741 Y92.936 E.01646
G1 X75.461 Y122.216 E1.27511
G1 X75.42 Y121.722 E.01524
G1 X104.206 Y92.936 E1.25362
G1 X103.672 Y92.936 E.01646
G1 X75.379 Y121.229 E1.23214
G1 X75.338 Y120.736 E.01524
G1 X103.137 Y92.936 E1.21066
G1 X102.603 Y92.936 E.01646
G1 X75.296 Y120.242 E1.18918
G1 X75.255 Y119.749 E.01524
G1 X102.068 Y92.936 E1.16769
G1 X101.534 Y92.936 E.01646
G1 X75.214 Y119.256 E1.14621
G1 X75.173 Y118.762 E.01524
G1 X101 Y92.936 E1.12473
G1 X100.465 Y92.936 E.01646
G1 X75.132 Y118.269 E1.10324
G1 X75.091 Y117.776 E.01524
G1 X99.931 Y92.936 E1.08176
G1 X99.396 Y92.936 E.01646
G1 X75.05 Y117.282 E1.06028
G1 X75.009 Y116.789 E.01524
G1 X98.862 Y92.936 E1.03879
G1 X98.328 Y92.936 E.01646
G1 X74.968 Y116.296 E1.01731
G1 X74.926 Y115.802 E.01524
M73 P83 R5
G1 X97.793 Y92.936 E.99583
G1 X97.259 Y92.936 E.01646
G1 X74.885 Y115.309 E.97434
G1 X74.844 Y114.816 E.01524
G1 X96.724 Y92.936 E.95286
G1 X96.19 Y92.936 E.01646
G1 X74.803 Y114.322 E.93138
G1 X74.762 Y113.829 E.01524
G1 X95.655 Y92.936 E.90989
G1 X95.121 Y92.936 E.01646
G1 X74.721 Y113.336 E.88841
G1 X74.68 Y112.842 E.01524
G1 X94.587 Y92.936 E.86693
G1 X94.052 Y92.936 E.01646
G1 X74.639 Y112.349 E.84544
G1 X74.598 Y111.856 E.01524
G1 X93.518 Y92.936 E.82396
G1 X92.983 Y92.936 E.01646
G1 X74.556 Y111.362 E.80248
G1 X74.515 Y110.869 E.01524
G1 X92.449 Y92.936 E.78099
G1 X91.915 Y92.936 E.01646
G1 X74.474 Y110.376 E.75951
G1 X74.433 Y109.882 E.01524
G1 X91.38 Y92.936 E.73803
G1 X90.846 Y92.936 E.01646
G1 X74.392 Y109.389 E.71654
G1 X74.351 Y108.896 E.01524
G1 X90.311 Y92.936 E.69506
G1 X89.777 Y92.936 E.01646
G1 X74.31 Y108.403 E.67358
G1 X74.269 Y107.909 E.01524
G1 X89.242 Y92.935 E.6521
G1 X88.708 Y92.935 E.01646
G1 X74.228 Y107.416 E.63061
G1 X74.186 Y106.923 E.01524
G1 X88.174 Y92.935 E.60913
G1 X87.639 Y92.935 E.01646
G1 X74.145 Y106.429 E.58765
G1 X74.104 Y105.936 E.01524
G1 X87.105 Y92.935 E.56616
G1 X86.57 Y92.935 E.01646
G1 X74.063 Y105.443 E.54468
G3 X74.025 Y104.947 I3.438 J-.517 E.01533
G1 X86.036 Y92.935 E.52309
G1 X85.502 Y92.935 E.01646
G1 X74.06 Y104.377 E.49827
G3 X74.375 Y103.63 I2.045 J.423 E.02511
G1 X74.581 Y103.322 E.01142
G1 X84.967 Y92.935 E.45233
G1 X84.433 Y92.935 E.01646
G1 X75.649 Y101.719 E.38251
G1 X76.718 Y100.115 E.05934
G1 X83.898 Y92.935 E.31268
G1 X83.364 Y92.935 E.01646
G1 X77.787 Y98.512 E.24286
G1 X78.856 Y96.909 E.05934
G1 X82.829 Y92.935 E.17304
G2 X82.261 Y92.969 I-.054 J3.882 E.01754
G1 X79.925 Y95.305 E.10175
G1 X80.883 Y93.868 E.05321
G3 X81.12 Y93.576 I1.486 J.963 E.0116
G1 X81.753 Y92.943 E.02756
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X81.12 Y93.576 E-.34013
G1 X80.883 Y93.868 E-.14282
G1 X80.479 Y94.474 E-.27706
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 21/23
; update layer progress
M73 L21
M991 S0 P20 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.4 I.024 J1.217 P1  F30000
G1 X173.919 Y92.63 Z4.4
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X175.439 Y93.508 I-.359 J2.377 E.05962
G1 X181.787 Y101.443 E.33708
G3 X182.309 Y103.144 I-1.907 J1.515 E.06042
G1 X178.493 Y150.843 E1.58734
G3 X177.793 Y152.36 I-2.403 J-.189 E.0566
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.463 Y158.69 E.29694
G3 X169.754 Y159.398 I-1.72 J-1.736 E.06292
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.691 I.011 J-2.444 E.0629
G1 X78.212 Y152.356 E.29717
G3 X77.513 Y150.848 I1.703 J-1.706 E.0563
G1 X73.692 Y105 E1.52613
G3 X74.09 Y103.457 I2.436 J-.194 E.05383
G1 X80.611 Y93.676 E.38995
G3 X82.618 Y92.602 I2.012 J1.348 E.07861
G1 X173.663 Y92.605 E3.02013
G3 X173.86 Y92.621 I-.103 J2.402 E.00655
M204 S250
G1 X173.997 Y92.245 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.25 Y92.297 E.00794
G3 X175.743 Y93.259 I-.69 J2.71 E.05554
G1 X182.096 Y101.201 E.31252
G3 X182.7 Y103.17 I-2.22 J1.758 E.06478
G1 X178.883 Y150.88 E1.47065
G3 X178.073 Y152.634 I-2.794 J-.225 E.06064
G1 X171.736 Y158.971 E.27536
G3 X169.759 Y159.79 I-1.996 J-2.022 E.06743
G1 X86.25 Y159.79 E2.566
G3 X84.273 Y158.971 I.018 J-2.841 E.06742
G1 X77.931 Y152.63 E.27555
G3 X77.122 Y150.885 I1.983 J-1.98 E.06032
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.244 I2.833 J-.22 E.05766
G1 X80.287 Y93.454 E.36151
G3 X82.613 Y92.21 I2.337 J1.572 E.08435
G1 X173.681 Y92.213 E2.79828
G3 X173.937 Y92.236 I-.122 J2.794 E.0079
; WIPE_START
M204 S10000
G1 X174.25 Y92.297 E-.12098
G1 X174.515 Y92.378 E-.10543
G1 X174.771 Y92.486 E-.10556
G1 X175.132 Y92.693 E-.15816
G1 X175.354 Y92.861 E-.10559
G1 X175.557 Y93.049 E-.10537
G1 X175.66 Y93.165 E-.05892
; WIPE_END
G1 E-.04 F1800
G1 X176.194 Y94.713 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42122
G1 F15000
G1 X175.03 Y93.549 E.05076
G2 X173.914 Y92.968 I-1.52 J1.557 E.03935
G1 X177.244 Y96.298 E.14519
G1 X179.378 Y98.967 E.10534
G1 X173.349 Y92.938 E.26285
G1 X172.814 Y92.938 E.01649
G1 X181.512 Y101.636 E.3792
G3 X181.947 Y102.606 I-1.447 J1.231 E.03322
G1 X172.279 Y92.938 E.4215
G1 X171.744 Y92.938 E.01649
G1 X181.97 Y103.164 E.44582
G1 X181.931 Y103.66 E.01532
G1 X171.209 Y92.938 E.46742
G1 X170.674 Y92.938 E.01649
G1 X181.891 Y104.155 E.48902
G1 X181.851 Y104.651 E.01532
G1 X170.139 Y92.938 E.51062
G1 X169.604 Y92.938 E.01649
G1 X181.812 Y105.146 E.53221
G1 X181.772 Y105.641 E.01532
G1 X169.069 Y92.938 E.55381
G1 X168.534 Y92.938 E.01649
G1 X181.733 Y106.137 E.57541
G1 X181.693 Y106.632 E.01532
G1 X167.999 Y92.938 E.59701
G1 X167.464 Y92.938 E.01649
G1 X181.653 Y107.127 E.61861
G1 X181.614 Y107.623 E.01532
G1 X166.929 Y92.938 E.6402
G1 X166.394 Y92.938 E.01649
G1 X181.574 Y108.118 E.6618
G1 X181.535 Y108.614 E.01532
G1 X165.859 Y92.938 E.6834
G1 X165.324 Y92.938 E.01649
G1 X181.495 Y109.109 E.705
G1 X181.455 Y109.604 E.01532
G1 X164.789 Y92.938 E.72659
G1 X164.254 Y92.938 E.01649
G1 X181.416 Y110.1 E.74819
G1 X181.376 Y110.595 E.01532
G1 X163.719 Y92.938 E.76979
G1 X163.184 Y92.938 E.01649
G1 X181.336 Y111.091 E.79139
G1 X181.297 Y111.586 E.01532
G1 X162.649 Y92.938 E.81298
G1 X162.114 Y92.938 E.01649
G1 X181.257 Y112.081 E.83458
G1 X181.218 Y112.577 E.01532
G1 X161.579 Y92.938 E.85618
G1 X161.043 Y92.938 E.01649
G1 X181.178 Y113.072 E.87778
G1 X181.138 Y113.568 E.01532
G1 X160.508 Y92.938 E.89938
G1 X159.973 Y92.938 E.01649
G1 X181.099 Y114.063 E.92097
G1 X181.059 Y114.558 E.01532
G1 X159.438 Y92.938 E.94257
G1 X158.903 Y92.938 E.01649
G1 X181.02 Y115.054 E.96417
G1 X180.98 Y115.549 E.01532
G1 X158.368 Y92.938 E.98577
G1 X157.833 Y92.938 E.01649
G1 X180.94 Y116.045 E1.00736
G1 X180.901 Y116.54 E.01532
G1 X157.298 Y92.938 E1.02896
G1 X156.763 Y92.938 E.01649
G1 X180.861 Y117.035 E1.05056
G1 X180.822 Y117.531 E.01532
G1 X156.228 Y92.938 E1.07216
G1 X155.693 Y92.937 E.01649
G1 X180.782 Y118.026 E1.09375
G1 X180.742 Y118.522 E.01532
G1 X155.158 Y92.937 E1.11535
G1 X154.623 Y92.937 E.01649
G1 X180.703 Y119.017 E1.13695
G1 X180.663 Y119.512 E.01532
G1 X154.088 Y92.937 E1.15855
G1 X153.553 Y92.937 E.01649
G1 X180.624 Y120.008 E1.18014
G1 X180.584 Y120.503 E.01532
G1 X153.018 Y92.937 E1.20174
G1 X152.483 Y92.937 E.01649
G1 X180.544 Y120.999 E1.22334
G1 X180.505 Y121.494 E.01532
G1 X151.948 Y92.937 E1.24494
G1 X151.413 Y92.937 E.01649
G1 X180.465 Y121.989 E1.26653
G1 X180.426 Y122.485 E.01532
G1 X150.878 Y92.937 E1.28813
G1 X150.343 Y92.937 E.01649
G1 X180.386 Y122.98 E1.30973
G1 X180.346 Y123.476 E.01532
G1 X149.808 Y92.937 E1.33133
G1 X149.273 Y92.937 E.01649
G1 X180.307 Y123.971 E1.35293
G1 X180.267 Y124.466 E.01532
G1 X148.738 Y92.937 E1.37452
G1 X148.203 Y92.937 E.01649
G1 X180.228 Y124.962 E1.39612
G1 X180.188 Y125.457 E.01532
G1 X147.668 Y92.937 E1.41772
G1 X147.133 Y92.937 E.01649
G1 X180.148 Y125.952 E1.43932
G1 X180.109 Y126.448 E.01532
G1 X146.598 Y92.937 E1.46091
G1 X146.063 Y92.937 E.01649
G1 X180.069 Y126.943 E1.48251
G1 X180.03 Y127.439 E.01532
G1 X145.528 Y92.937 E1.50411
G1 X144.993 Y92.937 E.01649
G1 X179.99 Y127.934 E1.52571
G1 X179.95 Y128.429 E.01532
G1 X144.458 Y92.937 E1.5473
G1 X143.923 Y92.937 E.01649
G1 X179.911 Y128.925 E1.5689
G1 X179.871 Y129.42 E.01532
G1 X143.388 Y92.937 E1.5905
G1 X142.853 Y92.937 E.01649
G1 X179.832 Y129.916 E1.6121
G1 X179.792 Y130.411 E.01532
M73 P84 R5
G1 X142.318 Y92.937 E1.6337
G1 X141.783 Y92.937 E.01649
G1 X179.752 Y130.906 E1.65529
G1 X179.713 Y131.402 E.01532
G1 X141.248 Y92.937 E1.67689
G1 X140.713 Y92.937 E.01649
G1 X179.673 Y131.897 E1.69849
G1 X179.634 Y132.393 E.01532
G1 X140.178 Y92.937 E1.72009
G1 X139.643 Y92.937 E.01649
G1 X179.594 Y132.888 E1.74168
G1 X179.554 Y133.383 E.01532
G1 X139.108 Y92.937 E1.76328
G1 X138.573 Y92.937 E.01649
G1 X179.515 Y133.879 E1.78488
G1 X179.475 Y134.374 E.01532
G1 X138.038 Y92.937 E1.80648
G1 X137.503 Y92.937 E.01649
G1 X179.436 Y134.87 E1.82807
G1 X179.396 Y135.365 E.01532
G1 X136.968 Y92.937 E1.84967
G1 X136.433 Y92.937 E.01649
G1 X179.356 Y135.86 E1.87127
G1 X179.317 Y136.356 E.01532
G1 X135.898 Y92.937 E1.89287
G1 X135.363 Y92.937 E.01649
G1 X179.277 Y136.851 E1.91446
G1 X179.238 Y137.347 E.01532
G1 X134.828 Y92.937 E1.93606
G1 X134.293 Y92.937 E.01649
G1 X179.198 Y137.842 E1.95766
G1 X179.158 Y138.337 E.01532
G1 X133.758 Y92.937 E1.97926
G1 X133.223 Y92.937 E.01649
G1 X179.119 Y138.833 E2.00086
G1 X179.079 Y139.328 E.01532
G1 X132.688 Y92.937 E2.02245
G1 X132.153 Y92.937 E.01649
G1 X179.04 Y139.824 E2.04405
G1 X179 Y140.319 E.01532
G1 X131.618 Y92.937 E2.06565
G1 X131.083 Y92.937 E.01649
G1 X178.96 Y140.814 E2.08725
G1 X178.921 Y141.31 E.01532
G1 X130.548 Y92.937 E2.10884
G1 X130.013 Y92.937 E.01649
G1 X178.881 Y141.805 E2.13044
G1 X178.842 Y142.301 E.01532
G1 X129.478 Y92.937 E2.15204
G1 X128.943 Y92.937 E.01649
G1 X178.802 Y142.796 E2.17364
G1 X178.762 Y143.291 E.01532
G1 X128.408 Y92.937 E2.19523
G1 X127.873 Y92.937 E.01649
G1 X178.723 Y143.787 E2.21683
G1 X178.683 Y144.282 E.01532
G1 X127.338 Y92.937 E2.23843
G1 X126.803 Y92.937 E.01649
G1 X178.644 Y144.777 E2.26003
G1 X178.604 Y145.273 E.01532
G1 X126.268 Y92.937 E2.28163
G1 X125.733 Y92.937 E.01649
G1 X178.564 Y145.768 E2.30322
G1 X178.525 Y146.264 E.01532
G1 X125.198 Y92.937 E2.32482
G1 X124.663 Y92.937 E.01649
G1 X178.485 Y146.759 E2.34642
G1 X178.446 Y147.254 E.01532
G1 X124.128 Y92.937 E2.36802
G1 X123.593 Y92.937 E.01649
G1 X178.406 Y147.75 E2.38961
G1 X178.366 Y148.245 E.01532
G1 X123.058 Y92.937 E2.41121
G1 X122.523 Y92.937 E.01649
G1 X178.327 Y148.741 E2.43281
G1 X178.287 Y149.236 E.01532
G1 X121.988 Y92.936 E2.45441
G1 X121.453 Y92.936 E.01649
G1 X178.248 Y149.731 E2.476
G1 X178.208 Y150.227 E.01532
G1 X120.918 Y92.936 E2.4976
G1 X120.383 Y92.936 E.01649
G1 X178.168 Y150.722 E2.5192
G3 X178.094 Y151.183 I-3.315 J-.297 E.0144
G1 X119.848 Y92.936 E2.53929
G1 X119.312 Y92.936 E.01649
G1 X177.948 Y151.572 E2.55625
G3 X177.744 Y151.903 I-1.442 J-.664 E.01201
G1 X118.777 Y92.936 E2.57066
G1 X118.242 Y92.936 E.01649
G1 X177.492 Y152.186 E2.58301
G1 X177.225 Y152.453 E.01166
G1 X117.707 Y92.936 E2.59467
G1 X117.172 Y92.936 E.01649
G1 X176.957 Y152.721 E2.60634
G1 X176.69 Y152.989 E.01166
G1 X116.637 Y92.936 E2.61801
G1 X116.102 Y92.936 E.01649
G1 X176.422 Y153.256 E2.62967
G1 X176.155 Y153.524 E.01166
G1 X115.567 Y92.936 E2.64134
G1 X115.032 Y92.936 E.01649
G1 X175.887 Y153.791 E2.653
G1 X175.62 Y154.059 E.01166
G1 X114.497 Y92.936 E2.66467
G1 X113.962 Y92.936 E.01649
G1 X175.353 Y154.326 E2.67634
G1 X175.085 Y154.594 E.01166
G1 X113.427 Y92.936 E2.688
G1 X112.892 Y92.936 E.01649
G1 X174.818 Y154.862 E2.69967
G1 X174.55 Y155.129 E.01166
G1 X112.357 Y92.936 E2.71133
G1 X111.822 Y92.936 E.01649
G1 X174.283 Y155.397 E2.723
G1 X174.016 Y155.664 E.01166
G1 X111.287 Y92.936 E2.73467
G1 X110.752 Y92.936 E.01649
G1 X173.748 Y155.932 E2.74633
G1 X173.481 Y156.2 E.01166
G1 X110.217 Y92.936 E2.758
G1 X109.682 Y92.936 E.01649
G1 X173.213 Y156.467 E2.76966
G1 X172.946 Y156.735 E.01166
G1 X109.147 Y92.936 E2.78133
G1 X108.612 Y92.936 E.01649
G1 X172.678 Y157.002 E2.793
G1 X172.411 Y157.27 E.01166
G1 X108.077 Y92.936 E2.80466
G1 X107.542 Y92.936 E.01649
G1 X172.144 Y157.537 E2.81633
G1 X171.876 Y157.805 E.01166
G1 X107.007 Y92.936 E2.828
G1 X106.472 Y92.936 E.01649
G1 X171.609 Y158.073 E2.83966
G1 X171.341 Y158.34 E.01166
M73 P84 R4
G1 X105.937 Y92.936 E2.85133
G1 X105.402 Y92.936 E.01649
G1 X171.065 Y158.599 E2.86261
G3 X170.742 Y158.811 I-.876 J-.986 E.01196
G1 X104.867 Y92.936 E2.87184
G1 X104.332 Y92.936 E.01649
G1 X170.364 Y158.968 E2.87871
G3 X169.918 Y159.056 I-.734 J-2.543 E.01406
G1 X103.797 Y92.936 E2.88255
G1 X103.262 Y92.936 E.01649
G1 X169.391 Y159.065 E2.88291
G1 X168.856 Y159.065 E.01649
G1 X102.727 Y92.936 E2.88291
G1 X102.192 Y92.936 E.01649
G1 X168.321 Y159.064 E2.88291
G1 X167.786 Y159.064 E.01649
G1 X101.657 Y92.936 E2.8829
G1 X101.122 Y92.936 E.01649
G1 X167.251 Y159.064 E2.8829
G1 X166.715 Y159.064 E.01649
G1 X100.587 Y92.936 E2.8829
G1 X100.052 Y92.936 E.01649
G1 X166.18 Y159.064 E2.8829
G1 X165.645 Y159.064 E.01649
G1 X99.517 Y92.936 E2.88289
G1 X98.982 Y92.936 E.01649
G1 X165.11 Y159.064 E2.88289
G1 X164.575 Y159.064 E.01649
G1 X98.447 Y92.936 E2.88289
G1 X97.912 Y92.936 E.01649
G1 X164.04 Y159.064 E2.88289
G1 X163.505 Y159.064 E.01649
G1 X97.377 Y92.936 E2.88288
G1 X96.842 Y92.936 E.01649
M73 P85 R4
G1 X162.97 Y159.064 E2.88288
G1 X162.435 Y159.064 E.01649
G1 X96.307 Y92.936 E2.88288
G1 X95.772 Y92.936 E.01649
G1 X161.9 Y159.064 E2.88288
G1 X161.365 Y159.064 E.01649
G1 X95.237 Y92.936 E2.88287
G1 X94.702 Y92.936 E.01649
G1 X160.83 Y159.063 E2.88287
G1 X160.295 Y159.063 E.01649
G1 X94.167 Y92.936 E2.88287
G1 X93.632 Y92.936 E.01649
G1 X159.76 Y159.063 E2.88287
G1 X159.224 Y159.063 E.01649
G1 X93.097 Y92.936 E2.88286
G1 X92.562 Y92.936 E.01649
G1 X158.689 Y159.063 E2.88286
G1 X158.154 Y159.063 E.01649
G1 X92.027 Y92.936 E2.88286
G1 X91.492 Y92.936 E.01649
G1 X157.619 Y159.063 E2.88285
G1 X157.084 Y159.063 E.01649
G1 X90.957 Y92.936 E2.88285
G1 X90.422 Y92.936 E.01649
G1 X156.549 Y159.063 E2.88285
G1 X156.014 Y159.063 E.01649
G1 X89.887 Y92.936 E2.88285
G1 X89.352 Y92.936 E.01649
G1 X155.479 Y159.063 E2.88284
G1 X154.944 Y159.063 E.01649
G1 X88.817 Y92.936 E2.88284
G1 X88.282 Y92.935 E.01649
G1 X154.409 Y159.063 E2.88284
G1 X153.874 Y159.062 E.01649
G1 X87.747 Y92.935 E2.88284
G1 X87.212 Y92.935 E.01649
G1 X153.339 Y159.062 E2.88283
G1 X152.804 Y159.062 E.01649
G1 X86.677 Y92.935 E2.88283
G1 X86.142 Y92.935 E.01649
G1 X152.268 Y159.062 E2.88283
G1 X151.733 Y159.062 E.01649
G1 X85.607 Y92.935 E2.88283
G1 X85.072 Y92.935 E.01649
G1 X151.198 Y159.062 E2.88282
G1 X150.663 Y159.062 E.01649
G1 X84.537 Y92.935 E2.88282
G1 X84.002 Y92.935 E.01649
G1 X150.128 Y159.062 E2.88282
G1 X149.593 Y159.062 E.01649
G1 X83.467 Y92.935 E2.88282
G1 X82.932 Y92.935 E.01649
G1 X149.058 Y159.062 E2.88281
G1 X148.523 Y159.062 E.01649
G1 X82.412 Y92.951 E2.88212
G2 X81.968 Y93.042 I.261 J2.416 E.014
G1 X147.988 Y159.062 E2.87817
G1 X147.453 Y159.062 E.01649
G1 X81.596 Y93.205 E2.87107
G2 X81.283 Y93.426 I.907 J1.613 E.01185
G1 X146.918 Y159.061 E2.86139
G1 X146.383 Y159.061 E.01649
G1 X81.013 Y93.693 E2.84981
G2 X80.792 Y94.005 I3.109 J2.433 E.01181
G1 X145.848 Y159.061 E2.83615
G1 X145.313 Y159.061 E.01649
G1 X80.578 Y94.326 E2.82215
G1 X80.364 Y94.647 E.01189
G1 X144.777 Y159.061 E2.80815
G1 X144.242 Y159.061 E.01649
G1 X80.15 Y94.968 E2.79416
G1 X79.936 Y95.289 E.01189
G1 X143.707 Y159.061 E2.78016
G1 X143.172 Y159.061 E.01649
G1 X79.722 Y95.61 E2.76616
G1 X79.508 Y95.931 E.01189
G1 X142.637 Y159.061 E2.75216
G1 X142.102 Y159.061 E.01649
G1 X79.294 Y96.252 E2.73817
G1 X79.08 Y96.573 E.01189
G1 X141.567 Y159.061 E2.72417
G1 X141.032 Y159.061 E.01649
G1 X78.866 Y96.894 E2.71017
G1 X78.652 Y97.215 E.01189
G1 X140.497 Y159.061 E2.69617
G1 X139.962 Y159.06 E.01649
G1 X78.438 Y97.536 E2.68218
G1 X78.224 Y97.857 E.01189
G1 X139.427 Y159.06 E2.66818
G1 X138.892 Y159.06 E.01649
G1 X78.01 Y98.178 E2.65418
G1 X77.796 Y98.499 E.01189
G1 X138.357 Y159.06 E2.64018
G1 X137.822 Y159.06 E.01649
G1 X77.582 Y98.82 E2.62619
G1 X77.368 Y99.141 E.01189
G1 X137.286 Y159.06 E2.61219
G1 X136.751 Y159.06 E.01649
G1 X77.154 Y99.462 E2.59819
G1 X76.94 Y99.783 E.01189
M73 P86 R4
G1 X136.216 Y159.06 E2.5842
G1 X135.681 Y159.06 E.01649
G1 X76.726 Y100.104 E2.5702
G1 X76.512 Y100.425 E.01189
G1 X135.146 Y159.06 E2.5562
G1 X134.611 Y159.06 E.01649
G1 X76.298 Y100.746 E2.5422
G1 X76.084 Y101.067 E.01189
G1 X134.076 Y159.06 E2.52821
G1 X133.541 Y159.06 E.01649
G1 X75.87 Y101.388 E2.51421
G1 X75.656 Y101.709 E.01189
G1 X133.006 Y159.06 E2.50021
G1 X132.471 Y159.059 E.01649
G1 X75.442 Y102.03 E2.48621
G1 X75.228 Y102.351 E.01189
G1 X131.936 Y159.059 E2.47222
G1 X131.401 Y159.059 E.01649
G1 X75.014 Y102.672 E2.45822
G1 X74.8 Y102.993 E.01189
G1 X130.866 Y159.059 E2.44422
G1 X130.331 Y159.059 E.01649
G1 X74.586 Y103.314 E2.43022
G1 X74.372 Y103.635 E.01189
G1 X129.795 Y159.059 E2.41623
G1 X129.26 Y159.059 E.01649
G1 X74.187 Y103.986 E2.40094
G2 X74.058 Y104.392 I2.588 J1.048 E.01314
G1 X128.725 Y159.059 E2.38325
G1 X128.19 Y159.059 E.01649
G1 X74.024 Y104.892 E2.36141
G2 X74.065 Y105.469 I4.055 J-.002 E.01783
G1 X127.655 Y159.059 E2.33627
G1 X127.12 Y159.059 E.01649
G1 X74.114 Y106.053 E2.31083
G1 X74.163 Y106.636 E.01805
G1 X126.585 Y159.059 E2.28538
G1 X126.05 Y159.059 E.01649
G1 X74.211 Y107.22 E2.25993
G1 X74.26 Y107.803 E.01805
G1 X125.515 Y159.058 E2.23449
G1 X124.98 Y159.058 E.01649
G1 X74.309 Y108.387 E2.20904
G1 X74.357 Y108.971 E.01805
G1 X124.445 Y159.058 E2.18359
G1 X123.91 Y159.058 E.01649
G1 X74.406 Y109.554 E2.15814
G1 X74.454 Y110.138 E.01805
G1 X123.375 Y159.058 E2.1327
G1 X122.84 Y159.058 E.01649
G1 X74.503 Y110.722 E2.10725
G1 X74.552 Y111.305 E.01805
G1 X122.304 Y159.058 E2.0818
G1 X121.769 Y159.058 E.01649
G1 X74.6 Y111.889 E2.05636
G1 X74.649 Y112.473 E.01805
G1 X121.234 Y159.058 E2.03091
G1 X120.699 Y159.058 E.01649
G1 X74.698 Y113.056 E2.00546
G1 X74.746 Y113.64 E.01805
G1 X120.164 Y159.058 E1.98001
G1 X119.629 Y159.058 E.01649
G1 X74.795 Y114.223 E1.95457
G1 X74.844 Y114.807 E.01805
G1 X119.094 Y159.058 E1.92912
G1 X118.559 Y159.057 E.01649
G1 X74.892 Y115.391 E1.90367
G1 X74.941 Y115.974 E.01805
G1 X118.024 Y159.057 E1.87823
G1 X117.489 Y159.057 E.01649
G1 X74.989 Y116.558 E1.85278
G1 X75.038 Y117.142 E.01805
G1 X116.954 Y159.057 E1.82733
G1 X116.419 Y159.057 E.01649
G1 X75.087 Y117.725 E1.80189
G1 X75.135 Y118.309 E.01805
G1 X115.884 Y159.057 E1.77644
G1 X115.349 Y159.057 E.01649
G1 X75.184 Y118.893 E1.75099
G1 X75.233 Y119.476 E.01805
G1 X114.813 Y159.057 E1.72554
G1 X114.278 Y159.057 E.01649
G1 X75.281 Y120.06 E1.7001
G1 X75.33 Y120.643 E.01805
G1 X113.743 Y159.057 E1.67465
G1 X113.208 Y159.057 E.01649
G1 X75.379 Y121.227 E1.6492
G1 X75.427 Y121.811 E.01805
G1 X112.673 Y159.057 E1.62376
G1 X112.138 Y159.057 E.01649
G1 X75.476 Y122.394 E1.59831
G1 X75.524 Y122.978 E.01805
G1 X111.603 Y159.057 E1.57286
G1 X111.068 Y159.056 E.01649
G1 X75.573 Y123.562 E1.54742
G1 X75.622 Y124.145 E.01805
G1 X110.533 Y159.056 E1.52197
G1 X109.998 Y159.056 E.01649
M73 P87 R4
G1 X75.67 Y124.729 E1.49652
G1 X75.719 Y125.312 E.01805
G1 X109.463 Y159.056 E1.47107
G1 X108.928 Y159.056 E.01649
G1 X75.768 Y125.896 E1.44563
G1 X75.816 Y126.48 E.01805
G1 X108.393 Y159.056 E1.42018
G1 X107.858 Y159.056 E.01649
G1 X75.865 Y127.063 E1.39473
G1 X75.914 Y127.647 E.01805
G1 X107.322 Y159.056 E1.36929
G1 X106.787 Y159.056 E.01649
G1 X75.962 Y128.231 E1.34384
G1 X76.011 Y128.814 E.01805
G1 X106.252 Y159.056 E1.31839
G1 X105.717 Y159.056 E.01649
G1 X76.059 Y129.398 E1.29294
G1 X76.108 Y129.982 E.01805
G1 X105.182 Y159.056 E1.2675
G1 X104.647 Y159.056 E.01649
G1 X76.157 Y130.565 E1.24205
G1 X76.205 Y131.149 E.01805
G1 X104.112 Y159.055 E1.2166
G1 X103.577 Y159.055 E.01649
G1 X76.254 Y131.732 E1.19116
G1 X76.303 Y132.316 E.01805
G1 X103.042 Y159.055 E1.16571
G1 X102.507 Y159.055 E.01649
G1 X76.351 Y132.9 E1.14026
G1 X76.4 Y133.483 E.01805
G1 X101.972 Y159.055 E1.11482
G1 X101.437 Y159.055 E.01649
G1 X76.449 Y134.067 E1.08937
G1 X76.497 Y134.651 E.01805
G1 X100.902 Y159.055 E1.06392
G1 X100.367 Y159.055 E.01649
G1 X76.546 Y135.234 E1.03847
G1 X76.594 Y135.818 E.01805
G1 X99.831 Y159.055 E1.01303
G1 X99.296 Y159.055 E.01649
G1 X76.643 Y136.402 E.98758
G1 X76.692 Y136.985 E.01805
G1 X98.761 Y159.055 E.96213
G1 X98.226 Y159.055 E.01649
G1 X76.74 Y137.569 E.93669
G1 X76.789 Y138.152 E.01805
G1 X97.691 Y159.055 E.91124
G1 X97.156 Y159.054 E.01649
G1 X76.838 Y138.736 E.88579
G1 X76.886 Y139.32 E.01805
G1 X96.621 Y159.054 E.86035
G1 X96.086 Y159.054 E.01649
G1 X76.935 Y139.903 E.8349
G1 X76.984 Y140.487 E.01805
G1 X95.551 Y159.054 E.80945
G1 X95.016 Y159.054 E.01649
G1 X77.032 Y141.071 E.784
G1 X77.081 Y141.654 E.01805
G1 X94.481 Y159.054 E.75856
G1 X93.946 Y159.054 E.01649
G1 X77.129 Y142.238 E.73311
G1 X77.178 Y142.821 E.01805
G1 X93.411 Y159.054 E.70766
G1 X92.875 Y159.054 E.01649
G1 X77.227 Y143.405 E.68222
G1 X77.275 Y143.989 E.01805
G1 X92.34 Y159.054 E.65677
G1 X91.805 Y159.054 E.01649
G1 X77.324 Y144.572 E.63132
G1 X77.373 Y145.156 E.01805
G1 X91.27 Y159.054 E.60587
G1 X90.735 Y159.054 E.01649
G1 X77.421 Y145.74 E.58043
G1 X77.47 Y146.323 E.01805
G1 X90.2 Y159.054 E.55498
G1 X89.665 Y159.053 E.01649
G1 X77.519 Y146.907 E.52953
G1 X77.567 Y147.491 E.01805
G1 X89.13 Y159.053 E.50409
G1 X88.595 Y159.053 E.01649
G1 X77.616 Y148.074 E.47864
G1 X77.664 Y148.658 E.01805
G1 X88.06 Y159.053 E.45319
G1 X87.525 Y159.053 E.01649
G1 X77.713 Y149.241 E.42775
G1 X77.762 Y149.825 E.01805
G1 X86.99 Y159.053 E.4023
G1 X86.455 Y159.053 E.01649
G1 X77.81 Y150.409 E.37685
G2 X77.869 Y151.002 I6.453 J-.334 E.01838
G1 X85.894 Y159.027 E.34987
G3 X84.859 Y158.527 I.329 J-2.003 E.03594
G1 X77.839 Y151.508 E.30602
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X79.254 Y152.922 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 22/23
; update layer progress
M73 L22
M991 S0 P21 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.6 I.654 J1.027 P1  F30000
G1 X173.951 Y92.638 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
M73 P87 R3
G1 F15476.087
G1 X174.026 Y92.648 E.00251
G3 X175.44 Y93.508 I-.467 J2.361 E.05603
G1 X181.787 Y101.442 E.33707
G3 X182.309 Y103.144 I-1.907 J1.515 E.06042
G1 X178.493 Y150.844 E1.58735
G3 X177.793 Y152.36 I-2.403 J-.19 E.05657
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.462 Y158.69 E.29698
G3 X169.754 Y159.398 I-1.718 J-1.733 E.06292
G1 X86.255 Y159.398 E2.76981
G3 X84.546 Y158.69 I.008 J-2.435 E.06293
G1 X78.212 Y152.356 E.29714
G3 X77.513 Y150.848 I1.703 J-1.706 E.05631
G1 X73.692 Y105 E1.52614
G3 X74.091 Y103.456 I2.44 J-.193 E.05387
G1 X80.611 Y93.676 E.3899
G3 X82.618 Y92.602 I2.012 J1.347 E.07862
G1 X173.682 Y92.605 E3.02076
G1 X173.891 Y92.631 E.007
M204 S250
G1 X173.999 Y92.25 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.103 Y92.263 E.00322
G3 X175.743 Y93.259 I-.545 J2.746 E.06018
G1 X182.096 Y101.201 E.31252
G3 X182.7 Y103.171 I-2.221 J1.758 E.06478
G1 X178.883 Y150.88 E1.47065
G3 X178.073 Y152.634 I-2.794 J-.226 E.06062
G1 X171.736 Y158.971 E.27537
G3 X169.759 Y159.79 I-1.994 J-2.018 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.832 E.06745
G1 X77.932 Y152.63 E.27553
G3 X77.122 Y150.885 I1.983 J-1.98 E.06033
G1 X73.301 Y105.028 E1.41396
G3 X73.761 Y103.243 I2.838 J-.219 E.05767
G1 X80.287 Y93.455 E.36149
G3 X82.613 Y92.21 I2.337 J1.571 E.08436
G1 X173.701 Y92.214 E2.7989
G1 X173.939 Y92.243 E.00736
; WIPE_START
M204 S10000
G1 X174.103 Y92.263 E-.06257
G1 X174.384 Y92.334 E-.11012
G1 X174.645 Y92.428 E-.10547
G1 X174.895 Y92.549 E-.1054
G1 X175.132 Y92.693 E-.10557
G1 X175.353 Y92.861 E-.10553
G1 X175.557 Y93.049 E-.10549
M73 P88 R3
G1 X175.661 Y93.167 E-.05985
; WIPE_END
G1 E-.04 F1800
G1 X175.079 Y100.777 Z4.8 F30000
G1 X170.618 Y159.063 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42083
G1 F15000
G1 X177.626 Y152.052 E.30527
G2 X178.13 Y151.017 I-1.586 J-1.413 E.03591
G1 X170.12 Y159.027 E.34885
G3 X169.547 Y159.065 I-.469 J-2.756 E.01769
G1 X178.192 Y150.42 E.3765
G1 X178.239 Y149.839 E.01795
G1 X169.013 Y159.065 E.40179
G1 X168.479 Y159.065 E.01646
G1 X178.285 Y149.258 E.42709
G1 X178.332 Y148.677 E.01795
G1 X167.944 Y159.064 E.45238
G1 X167.41 Y159.064 E.01646
G1 X178.378 Y148.096 E.47767
G1 X178.425 Y147.515 E.01795
G1 X166.876 Y159.064 E.50297
G1 X166.341 Y159.064 E.01646
G1 X178.471 Y146.934 E.52826
G1 X178.518 Y146.353 E.01795
G1 X165.807 Y159.064 E.55356
G1 X165.272 Y159.064 E.01646
G1 X178.564 Y145.773 E.57885
G1 X178.61 Y145.192 E.01795
G1 X164.738 Y159.064 E.60415
G1 X164.204 Y159.064 E.01646
G1 X178.657 Y144.611 E.62944
G1 X178.703 Y144.03 E.01795
G1 X163.669 Y159.064 E.65474
G1 X163.135 Y159.064 E.01646
G1 X178.75 Y143.449 E.68003
G1 X178.796 Y142.868 E.01795
G1 X162.601 Y159.064 E.70532
G1 X162.066 Y159.064 E.01646
G1 X178.843 Y142.287 E.73062
G1 X178.889 Y141.706 E.01795
G1 X161.532 Y159.064 E.75591
G1 X160.998 Y159.063 E.01646
G1 X178.935 Y141.126 E.78121
G1 X178.982 Y140.545 E.01795
G1 X160.463 Y159.063 E.8065
G1 X159.929 Y159.063 E.01646
G1 X179.028 Y139.964 E.8318
G1 X179.075 Y139.383 E.01795
G1 X159.394 Y159.063 E.85709
G1 X158.86 Y159.063 E.01646
G1 X179.121 Y138.802 E.88238
G1 X179.168 Y138.221 E.01795
G1 X158.326 Y159.063 E.90768
G1 X157.791 Y159.063 E.01646
G1 X179.214 Y137.64 E.93297
G1 X179.261 Y137.059 E.01795
G1 X157.257 Y159.063 E.95827
G1 X156.723 Y159.063 E.01646
G1 X179.307 Y136.478 E.98356
G1 X179.353 Y135.898 E.01795
G1 X156.188 Y159.063 E1.00886
G1 X155.654 Y159.063 E.01646
G1 X179.4 Y135.317 E1.03415
G1 X179.446 Y134.736 E.01795
G1 X155.119 Y159.063 E1.05945
G1 X154.585 Y159.063 E.01646
G1 X179.493 Y134.155 E1.08474
G1 X179.539 Y133.574 E.01795
G1 X154.051 Y159.062 E1.11004
G1 X153.516 Y159.062 E.01646
G1 X179.586 Y132.993 E1.13533
G1 X179.632 Y132.412 E.01795
G1 X152.982 Y159.062 E1.16062
G1 X152.448 Y159.062 E.01646
G1 X179.678 Y131.831 E1.18592
G1 X179.725 Y131.251 E.01795
G1 X151.913 Y159.062 E1.21121
G1 X151.379 Y159.062 E.01646
G1 X179.771 Y130.67 E1.23651
G1 X179.818 Y130.089 E.01795
G1 X150.844 Y159.062 E1.2618
G1 X150.31 Y159.062 E.01646
G1 X179.864 Y129.508 E1.2871
G1 X179.911 Y128.927 E.01795
G1 X149.776 Y159.062 E1.31239
G1 X149.241 Y159.062 E.01646
G1 X179.957 Y128.346 E1.33768
G1 X180.004 Y127.765 E.01795
G1 X148.707 Y159.062 E1.36298
G1 X148.173 Y159.062 E.01646
G1 X180.05 Y127.184 E1.38827
G1 X180.096 Y126.603 E.01795
G1 X147.638 Y159.062 E1.41357
G1 X147.104 Y159.061 E.01646
G1 X180.143 Y126.023 E1.43886
G1 X180.189 Y125.442 E.01795
G1 X146.57 Y159.061 E1.46416
G1 X146.035 Y159.061 E.01646
G1 X180.236 Y124.861 E1.48945
G1 X180.282 Y124.28 E.01795
G1 X145.501 Y159.061 E1.51475
G1 X144.966 Y159.061 E.01646
G1 X180.329 Y123.699 E1.54004
G1 X180.375 Y123.118 E.01795
G1 X144.432 Y159.061 E1.56533
G1 X143.898 Y159.061 E.01646
G1 X180.421 Y122.537 E1.59063
G1 X180.468 Y121.956 E.01795
G1 X143.363 Y159.061 E1.61592
G1 X142.829 Y159.061 E.01646
G1 X180.514 Y121.376 E1.64122
G1 X180.561 Y120.795 E.01795
G1 X142.295 Y159.061 E1.66651
G1 X141.76 Y159.061 E.01646
G1 X180.607 Y120.214 E1.69181
G1 X180.654 Y119.633 E.01795
G1 X141.226 Y159.061 E1.7171
G1 X140.691 Y159.061 E.01646
G1 X180.7 Y119.052 E1.7424
G1 X180.746 Y118.471 E.01795
G1 X140.157 Y159.061 E1.76769
G1 X139.623 Y159.06 E.01646
G1 X180.793 Y117.89 E1.79299
G1 X180.839 Y117.309 E.01795
G1 X139.088 Y159.06 E1.81828
G1 X138.554 Y159.06 E.01646
G1 X180.886 Y116.728 E1.84357
G1 X180.932 Y116.148 E.01795
G1 X138.02 Y159.06 E1.86887
G1 X137.485 Y159.06 E.01646
G1 X180.979 Y115.567 E1.89416
G1 X181.025 Y114.986 E.01795
G1 X136.951 Y159.06 E1.91946
G1 X136.416 Y159.06 E.01646
G1 X181.072 Y114.405 E1.94475
G1 X181.118 Y113.824 E.01795
G1 X135.882 Y159.06 E1.97005
G1 X135.348 Y159.06 E.01646
G1 X181.164 Y113.243 E1.99534
G1 X181.211 Y112.662 E.01795
G1 X134.813 Y159.06 E2.02063
G1 X134.279 Y159.06 E.01646
G1 X181.257 Y112.081 E2.04593
G1 X181.304 Y111.501 E.01795
G1 X133.745 Y159.06 E2.07122
G1 X133.21 Y159.06 E.01646
G1 X181.35 Y110.92 E2.09652
G1 X181.397 Y110.339 E.01795
G1 X132.676 Y159.059 E2.12181
G1 X132.142 Y159.059 E.01646
G1 X181.443 Y109.758 E2.14711
G1 X181.489 Y109.177 E.01795
G1 X131.607 Y159.059 E2.1724
G1 X131.073 Y159.059 E.01646
G1 X181.536 Y108.596 E2.1977
G1 X181.582 Y108.015 E.01795
G1 X130.538 Y159.059 E2.22299
G1 X130.004 Y159.059 E.01646
G1 X181.629 Y107.434 E2.24828
G1 X181.675 Y106.853 E.01795
G1 X129.47 Y159.059 E2.27358
G1 X128.935 Y159.059 E.01646
G1 X181.722 Y106.273 E2.29887
G1 X181.768 Y105.692 E.01795
G1 X128.401 Y159.059 E2.32417
G1 X127.867 Y159.059 E.01646
G1 X181.815 Y105.111 E2.34946
G1 X181.861 Y104.53 E.01795
G1 X127.332 Y159.059 E2.37476
G1 X126.798 Y159.059 E.01646
G1 X181.907 Y103.949 E2.40005
G1 X181.954 Y103.368 E.01795
G1 X126.263 Y159.059 E2.42535
G1 X125.729 Y159.058 E.01646
G1 X181.974 Y102.813 E2.4495
G1 X181.895 Y102.358 E.01423
G1 X125.195 Y159.058 E2.46933
G1 X124.66 Y159.058 E.01646
G1 X181.736 Y101.983 E2.48567
G2 X181.528 Y101.656 I-1.253 J.567 E.01196
G1 X124.126 Y159.058 E2.49989
G1 X123.592 Y159.058 E.01646
G1 X181.291 Y101.359 E2.51282
G1 X181.053 Y101.062 E.01171
G1 X123.057 Y159.058 E2.52575
G1 X122.523 Y159.058 E.01646
G1 X180.816 Y100.765 E2.53868
G1 X180.578 Y100.468 E.01171
G1 X121.988 Y159.058 E2.55161
G1 X121.454 Y159.058 E.01646
G1 X180.341 Y100.171 E2.56454
G1 X180.103 Y99.874 E.01171
G1 X120.92 Y159.058 E2.57747
G1 X120.385 Y159.058 E.01646
G1 X179.866 Y99.577 E2.5904
G1 X179.628 Y99.28 E.01171
G1 X119.851 Y159.058 E2.60334
G1 X119.317 Y159.058 E.01646
G1 X179.391 Y98.983 E2.61627
G1 X179.153 Y98.686 E.01171
G1 X118.782 Y159.058 E2.6292
G1 X118.248 Y159.057 E.01646
G1 X178.916 Y98.389 E2.64213
G1 X178.679 Y98.092 E.01171
G1 X117.714 Y159.057 E2.65506
G1 X117.179 Y159.057 E.01646
G1 X178.441 Y97.795 E2.66799
G1 X178.204 Y97.498 E.01171
G1 X116.645 Y159.057 E2.68092
G1 X116.11 Y159.057 E.01646
G1 X177.966 Y97.201 E2.69385
G1 X177.729 Y96.904 E.01171
G1 X115.576 Y159.057 E2.70678
G1 X115.042 Y159.057 E.01646
G1 X177.491 Y96.607 E2.71971
G1 X177.254 Y96.31 E.01171
G1 X114.507 Y159.057 E2.73264
G1 X113.973 Y159.057 E.01646
G1 X177.016 Y96.013 E2.74557
G1 X176.779 Y95.716 E.01171
G1 X113.439 Y159.057 E2.7585
G1 X112.904 Y159.057 E.01646
G1 X176.541 Y95.419 E2.77143
G1 X176.304 Y95.122 E.01171
G1 X112.37 Y159.057 E2.78437
G1 X111.835 Y159.057 E.01646
G1 X176.066 Y94.826 E2.7973
G1 X175.829 Y94.529 E.01171
G1 X111.301 Y159.056 E2.81023
G1 X110.767 Y159.056 E.01646
G1 X175.592 Y94.232 E2.82316
G1 X175.354 Y93.935 E.01171
G1 X110.232 Y159.056 E2.83609
G1 X109.698 Y159.056 E.01646
G1 X175.113 Y93.641 E2.84885
G2 X174.836 Y93.384 I-1.25 J1.067 E.01167
G1 X109.164 Y159.056 E2.86007
G1 X108.629 Y159.056 E.01646
G1 X174.513 Y93.173 E2.86925
G1 X174.133 Y93.018 E.01263
G1 X108.095 Y159.056 E2.87599
G1 X107.56 Y159.056 E.01646
G1 X173.676 Y92.94 E2.87937
M73 P89 R3
G1 X173.144 Y92.938 E.0164
G1 X107.026 Y159.056 E2.87945
G1 X106.492 Y159.056 E.01646
G1 X172.609 Y92.938 E2.87945
G1 X172.075 Y92.938 E.01646
G1 X105.957 Y159.056 E2.87944
G1 X105.423 Y159.056 E.01646
G1 X171.54 Y92.938 E2.87944
G1 X171.006 Y92.938 E.01646
G1 X104.889 Y159.056 E2.87944
G1 X104.354 Y159.055 E.01646
G1 X170.471 Y92.938 E2.87944
G1 X169.937 Y92.938 E.01646
G1 X103.82 Y159.055 E2.87943
G1 X103.286 Y159.055 E.01646
G1 X169.403 Y92.938 E2.87943
G1 X168.868 Y92.938 E.01646
G1 X102.751 Y159.055 E2.87943
G1 X102.217 Y159.055 E.01646
G1 X168.334 Y92.938 E2.87943
G1 X167.799 Y92.938 E.01646
G1 X101.682 Y159.055 E2.87942
G1 X101.148 Y159.055 E.01646
G1 X167.265 Y92.938 E2.87942
G1 X166.73 Y92.938 E.01646
G1 X100.614 Y159.055 E2.87942
G1 X100.079 Y159.055 E.01646
G1 X166.196 Y92.938 E2.87942
G1 X165.662 Y92.938 E.01646
G1 X99.545 Y159.055 E2.87941
G1 X99.011 Y159.055 E.01646
G1 X165.127 Y92.938 E2.87941
G1 X164.593 Y92.938 E.01646
G1 X98.476 Y159.055 E2.87941
G1 X97.942 Y159.055 E.01646
G1 X164.058 Y92.938 E2.87941
G1 X163.524 Y92.938 E.01646
G1 X97.407 Y159.055 E2.8794
G1 X96.873 Y159.054 E.01646
G1 X162.989 Y92.938 E2.8794
G1 X162.455 Y92.938 E.01646
G1 X96.339 Y159.054 E2.8794
G1 X95.804 Y159.054 E.01646
G1 X161.921 Y92.938 E2.8794
G1 X161.386 Y92.938 E.01646
G1 X95.27 Y159.054 E2.87939
G1 X94.736 Y159.054 E.01646
G1 X160.852 Y92.938 E2.87939
G1 X160.317 Y92.938 E.01646
G1 X94.201 Y159.054 E2.87939
G1 X93.667 Y159.054 E.01646
G1 X159.783 Y92.938 E2.87939
G1 X159.248 Y92.938 E.01646
G1 X93.132 Y159.054 E2.87938
G1 X92.598 Y159.054 E.01646
G1 X158.714 Y92.938 E2.87938
G1 X158.18 Y92.938 E.01646
G1 X92.064 Y159.054 E2.87938
G1 X91.529 Y159.054 E.01646
G1 X157.645 Y92.938 E2.87938
G1 X157.111 Y92.938 E.01646
G1 X90.995 Y159.054 E2.87937
G1 X90.461 Y159.054 E.01646
G1 X156.576 Y92.938 E2.87937
G1 X156.042 Y92.938 E.01646
G1 X89.926 Y159.053 E2.87937
G1 X89.392 Y159.053 E.01646
G1 X155.507 Y92.938 E2.87937
G1 X154.973 Y92.938 E.01646
G1 X88.857 Y159.053 E2.87936
G1 X88.323 Y159.053 E.01646
G1 X154.439 Y92.938 E2.87936
G1 X153.904 Y92.938 E.01646
G1 X87.789 Y159.053 E2.87936
G1 X87.254 Y159.053 E.01646
G1 X153.37 Y92.938 E2.87936
G1 X152.835 Y92.938 E.01646
G1 X86.72 Y159.053 E2.87935
G1 X86.186 Y159.053 E.01646
G1 X152.301 Y92.938 E2.87935
G1 X151.766 Y92.938 E.01646
G1 X85.714 Y158.99 E2.8766
G1 X85.326 Y158.844 E.01277
G1 X151.232 Y92.938 E2.87024
G1 X150.698 Y92.938 E.01646
G1 X84.999 Y158.636 E2.86121
G3 X84.716 Y158.385 I.884 J-1.279 E.01169
G1 X150.163 Y92.938 E2.85025
G1 X149.629 Y92.938 E.01646
G1 X84.449 Y158.118 E2.83862
G1 X84.181 Y157.85 E.01164
G1 X149.094 Y92.938 E2.82699
G1 X148.56 Y92.938 E.01646
G1 X83.914 Y157.583 E2.81536
G1 X83.647 Y157.316 E.01164
G1 X148.025 Y92.938 E2.80372
G1 X147.491 Y92.938 E.01646
G1 X83.38 Y157.049 E2.79209
G1 X83.112 Y156.782 E.01164
G1 X146.957 Y92.938 E2.78046
G1 X146.422 Y92.938 E.01646
G1 X82.845 Y156.515 E2.76882
G1 X82.578 Y156.248 E.01164
G1 X145.888 Y92.938 E2.75719
G1 X145.353 Y92.938 E.01646
M73 P90 R3
G1 X82.31 Y155.981 E2.74556
G1 X82.043 Y155.713 E.01164
G1 X144.819 Y92.937 E2.73392
G1 X144.284 Y92.937 E.01646
G1 X81.776 Y155.446 E2.72229
G1 X81.508 Y155.179 E.01164
G1 X143.75 Y92.937 E2.71066
G1 X143.216 Y92.937 E.01646
G1 X81.241 Y154.912 E2.69903
G1 X80.974 Y154.645 E.01164
G1 X142.681 Y92.937 E2.68739
G1 X142.147 Y92.937 E.01646
G1 X80.706 Y154.378 E2.67576
G1 X80.439 Y154.111 E.01164
G1 X141.612 Y92.937 E2.66413
G1 X141.078 Y92.937 E.01646
G1 X80.172 Y153.843 E2.65249
G1 X79.904 Y153.576 E.01164
G1 X140.543 Y92.937 E2.64086
G1 X140.009 Y92.937 E.01646
G1 X79.637 Y153.309 E2.62923
G1 X79.37 Y153.042 E.01164
G1 X139.475 Y92.937 E2.61759
G1 X138.94 Y92.937 E.01646
G1 X79.103 Y152.775 E2.60596
G1 X78.835 Y152.508 E.01164
G1 X138.406 Y92.937 E2.59433
G1 X137.871 Y92.937 E.01646
G1 X78.568 Y152.241 E2.5827
G3 X78.309 Y151.965 I3.215 J-3.287 E.01165
G1 X137.337 Y92.937 E2.57071
G1 X136.802 Y92.937 E.01646
G1 X78.096 Y151.643 E2.55669
G3 X77.935 Y151.271 I1.629 J-.927 E.01254
G1 X136.268 Y92.937 E2.54045
G1 X135.734 Y92.937 E.01646
G1 X77.846 Y150.825 E2.52105
G3 X77.804 Y150.332 I5.29 J-.695 E.01524
G1 X135.199 Y92.937 E2.49959
G1 X134.665 Y92.937 E.01646
G1 X77.763 Y149.839 E2.47811
G1 X77.722 Y149.346 E.01524
G1 X134.13 Y92.937 E2.45662
G1 X133.596 Y92.937 E.01646
G1 X77.681 Y148.852 E2.43514
G1 X77.64 Y148.359 E.01524
G1 X133.061 Y92.937 E2.41365
G1 X132.527 Y92.937 E.01646
G1 X77.598 Y147.866 E2.39217
G1 X77.557 Y147.372 E.01524
G1 X131.993 Y92.937 E2.37069
G1 X131.458 Y92.937 E.01646
G1 X77.516 Y146.879 E2.3492
G1 X77.475 Y146.386 E.01524
G1 X130.924 Y92.937 E2.32772
G1 X130.389 Y92.937 E.01646
G1 X77.434 Y145.892 E2.30623
G1 X77.393 Y145.399 E.01524
G1 X129.855 Y92.937 E2.28475
G1 X129.321 Y92.937 E.01646
G1 X77.352 Y144.906 E2.26327
G1 X77.311 Y144.412 E.01524
G1 X128.786 Y92.937 E2.24178
G1 X128.252 Y92.937 E.01646
G1 X77.27 Y143.919 E2.2203
G1 X77.228 Y143.426 E.01524
G1 X127.717 Y92.937 E2.19881
G1 X127.183 Y92.937 E.01646
G1 X77.187 Y142.932 E2.17733
G1 X77.146 Y142.439 E.01525
G1 X126.648 Y92.937 E2.15585
G1 X126.114 Y92.937 E.01646
G1 X77.105 Y141.946 E2.13436
G1 X77.064 Y141.452 E.01524
G1 X125.58 Y92.937 E2.11288
G1 X125.045 Y92.937 E.01646
G1 X77.023 Y140.959 E2.09139
G1 X76.982 Y140.466 E.01524
G1 X124.511 Y92.937 E2.06991
G1 X123.976 Y92.937 E.01646
M73 P90 R2
G1 X76.941 Y139.972 E2.04842
G1 X76.9 Y139.479 E.01524
G1 X123.442 Y92.937 E2.02694
G1 X122.907 Y92.937 E.01646
G1 X76.858 Y138.986 E2.00546
G1 X76.817 Y138.492 E.01524
G1 X122.373 Y92.937 E1.98397
G1 X121.839 Y92.937 E.01646
G1 X76.776 Y137.999 E1.96249
G1 X76.735 Y137.506 E.01524
G1 X121.304 Y92.937 E1.941
G1 X120.77 Y92.937 E.01646
G1 X76.694 Y137.012 E1.91952
G1 X76.653 Y136.519 E.01524
G1 X120.235 Y92.937 E1.89804
G1 X119.701 Y92.937 E.01646
M73 P91 R2
G1 X76.612 Y136.026 E1.87655
G1 X76.571 Y135.532 E.01524
G1 X119.166 Y92.937 E1.85507
G1 X118.632 Y92.937 E.01646
G1 X76.53 Y135.039 E1.83358
G1 X76.488 Y134.546 E.01524
G1 X118.098 Y92.937 E1.8121
G1 X117.563 Y92.937 E.01646
G1 X76.447 Y134.052 E1.79061
G1 X76.406 Y133.559 E.01525
G1 X117.029 Y92.937 E1.76913
G1 X116.494 Y92.937 E.01646
G1 X76.365 Y133.066 E1.74765
G1 X76.324 Y132.572 E.01524
G1 X115.96 Y92.936 E1.72616
G1 X115.425 Y92.936 E.01646
G1 X76.283 Y132.079 E1.70468
G1 X76.242 Y131.586 E.01524
G1 X114.891 Y92.936 E1.68319
G1 X114.357 Y92.936 E.01646
G1 X76.201 Y131.092 E1.66171
G1 X76.16 Y130.599 E.01524
G1 X113.822 Y92.936 E1.64023
G1 X113.288 Y92.936 E.01646
G1 X76.118 Y130.106 E1.61874
G1 X76.077 Y129.612 E.01524
G1 X112.753 Y92.936 E1.59726
G1 X112.219 Y92.936 E.01646
G1 X76.036 Y129.119 E1.57577
G1 X75.995 Y128.626 E.01524
G1 X111.684 Y92.936 E1.55429
G1 X111.15 Y92.936 E.01646
G1 X75.954 Y128.132 E1.5328
G1 X75.913 Y127.639 E.01524
G1 X110.616 Y92.936 E1.51132
G1 X110.081 Y92.936 E.01646
G1 X75.872 Y127.146 E1.48984
G1 X75.831 Y126.652 E.01524
G1 X109.547 Y92.936 E1.46835
G1 X109.012 Y92.936 E.01646
G1 X75.79 Y126.159 E1.44687
G1 X75.748 Y125.666 E.01524
G1 X108.478 Y92.936 E1.42538
G1 X107.943 Y92.936 E.01646
G1 X75.707 Y125.172 E1.4039
G1 X75.666 Y124.679 E.01524
G1 X107.409 Y92.936 E1.38242
G1 X106.875 Y92.936 E.01646
G1 X75.625 Y124.186 E1.36093
G1 X75.584 Y123.692 E.01524
G1 X106.34 Y92.936 E1.33945
G1 X105.806 Y92.936 E.01646
G1 X75.543 Y123.199 E1.31796
G1 X75.502 Y122.706 E.01524
G1 X105.271 Y92.936 E1.29648
G1 X104.737 Y92.936 E.01646
G1 X75.461 Y122.212 E1.27499
G1 X75.42 Y121.719 E.01525
G1 X104.202 Y92.936 E1.25351
G1 X103.668 Y92.936 E.01646
G1 X75.378 Y121.226 E1.23203
G1 X75.337 Y120.732 E.01524
G1 X103.134 Y92.936 E1.21054
G1 X102.599 Y92.936 E.01646
G1 X75.296 Y120.239 E1.18906
G1 X75.255 Y119.746 E.01524
G1 X102.065 Y92.936 E1.16757
G1 X101.53 Y92.936 E.01646
G1 X75.214 Y119.252 E1.14609
G1 X75.173 Y118.759 E.01524
G1 X100.996 Y92.936 E1.1246
G1 X100.461 Y92.936 E.01646
G1 X75.132 Y118.266 E1.10312
G1 X75.091 Y117.772 E.01524
G1 X99.927 Y92.936 E1.08164
G1 X99.393 Y92.936 E.01646
G1 X75.05 Y117.279 E1.06015
G1 X75.008 Y116.786 E.01524
G1 X98.858 Y92.936 E1.03867
G1 X98.324 Y92.936 E.01646
G1 X74.967 Y116.292 E1.01718
G1 X74.926 Y115.799 E.01524
G1 X97.789 Y92.936 E.9957
G1 X97.255 Y92.936 E.01646
G1 X74.885 Y115.306 E.97422
G1 X74.844 Y114.812 E.01524
G1 X96.72 Y92.936 E.95273
G1 X96.186 Y92.936 E.01646
G1 X74.803 Y114.319 E.93125
G1 X74.762 Y113.826 E.01524
G1 X95.652 Y92.936 E.90976
G1 X95.117 Y92.936 E.01646
G1 X74.721 Y113.332 E.88828
G1 X74.68 Y112.839 E.01524
G1 X94.583 Y92.936 E.8668
G1 X94.048 Y92.936 E.01646
G1 X74.638 Y112.346 E.84531
G1 X74.597 Y111.852 E.01524
G1 X93.514 Y92.936 E.82383
G1 X92.979 Y92.936 E.01646
G1 X74.556 Y111.359 E.80234
G1 X74.515 Y110.866 E.01524
G1 X92.445 Y92.936 E.78086
G1 X91.911 Y92.936 E.01646
G1 X74.474 Y110.372 E.75937
G1 X74.433 Y109.879 E.01524
G1 X91.376 Y92.936 E.73789
G1 X90.842 Y92.936 E.01646
G1 X74.392 Y109.386 E.71641
G1 X74.351 Y108.892 E.01524
G1 X90.307 Y92.936 E.69492
G1 X89.773 Y92.936 E.01646
G1 X74.31 Y108.399 E.67344
G1 X74.268 Y107.906 E.01524
G1 X89.238 Y92.936 E.65195
G1 X88.704 Y92.936 E.01646
G1 X74.227 Y107.412 E.63047
G1 X74.186 Y106.919 E.01524
G1 X88.17 Y92.936 E.60899
G1 X87.635 Y92.935 E.01646
M73 P92 R2
G1 X74.145 Y106.426 E.5875
G1 X74.104 Y105.932 E.01524
G1 X87.101 Y92.935 E.56602
G1 X86.566 Y92.935 E.01646
G1 X74.063 Y105.439 E.54453
G3 X74.024 Y104.943 I3.446 J-.516 E.01533
G1 X86.032 Y92.935 E.52293
G1 X85.497 Y92.935 E.01646
G1 X74.061 Y104.372 E.49807
G3 X74.374 Y103.631 I2.165 J.479 E.02492
G1 X74.589 Y103.31 E.01188
G1 X84.963 Y92.935 E.45182
G1 X84.429 Y92.935 E.01646
G1 X75.657 Y101.707 E.38199
G1 X76.726 Y100.103 E.05934
G1 X83.894 Y92.935 E.31217
G1 X83.36 Y92.935 E.01646
G1 X77.795 Y98.5 E.24234
G1 X78.864 Y96.897 E.05934
G1 X82.825 Y92.935 E.17251
G2 X82.256 Y92.97 I-.055 J3.763 E.01758
G1 X79.933 Y95.293 E.10117
G1 X80.883 Y93.868 E.05275
G3 X81.151 Y93.541 I1.727 J1.14 E.01304
G1 X81.746 Y92.945 E.02593
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X81.151 Y93.541 E-.32002
G1 X80.883 Y93.868 E-.1606
G1 X80.475 Y94.48 E-.27939
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 23/23
; update layer progress
M73 L23
M991 S0 P22 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.8 I.029 J1.217 P1  F30000
G1 X174 Y92.246 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X174.25 Y92.297 E.00784
G3 X175.743 Y93.259 I-.692 J2.712 E.05555
G1 X182.096 Y101.201 E.3125
G3 X182.7 Y103.17 I-2.221 J1.758 E.06479
G1 X178.883 Y150.88 E1.47066
G3 X178.073 Y152.634 I-2.794 J-.226 E.06062
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X171.736 Y158.971 E.27536
G3 X169.759 Y159.79 I-1.992 J-2.013 E.06744
G1 X86.25 Y159.79 E2.566
G3 X84.272 Y158.971 I.015 J-2.832 E.06744
G1 X77.932 Y152.63 E.27554
G3 X77.122 Y150.885 I1.983 J-1.98 E.06034
G1 X73.301 Y105.028 E1.41395
G3 X73.761 Y103.244 I2.838 J-.219 E.05765
G1 X80.287 Y93.455 E.36151
G3 X82.613 Y92.21 I2.337 J1.571 E.08435
G1 X173.697 Y92.213 E2.79877
G3 X173.941 Y92.236 I-.139 J2.795 E.00751
; WIPE_START
M204 S10000
G1 X174.25 Y92.297 E-.11973
G1 X174.515 Y92.378 E-.1055
G1 X174.775 Y92.487 E-.10696
G1 X175.132 Y92.693 E-.15677
G1 X175.353 Y92.861 E-.10534
G1 X175.557 Y93.049 E-.10556
G1 X175.662 Y93.168 E-.06015
; WIPE_END
G1 E-.04 F1800
G1 X177.456 Y95.734 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X174.228 Y92.506 E.14026
G1 X173.609 Y92.421
G1 X179.582 Y98.394 E.25955
; WIPE_START
M204 S10000
G1 X178.168 Y96.979 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.709 Y101.053 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X173.076 Y92.421 E.37512
G1 X172.543 Y92.421
G1 X182.411 Y102.289 E.42881
G1 X182.498 Y102.909
G1 X172.01 Y92.421 E.45579
G1 X171.476 Y92.421
G1 X182.469 Y103.414 E.4777
G1 X182.43 Y103.908
G1 X170.943 Y92.421 E.49916
G1 X170.41 Y92.421
G1 X182.391 Y104.401 E.52062
G1 X182.351 Y104.895
G1 X169.877 Y92.421 E.54208
G1 X169.343 Y92.421
G1 X182.312 Y105.389 E.56354
G1 X182.272 Y105.883
G1 X168.81 Y92.421 E.585
G1 X168.277 Y92.421
G1 X182.233 Y106.377 E.60645
G1 X182.193 Y106.87
G1 X167.743 Y92.421 E.62791
G1 X167.21 Y92.421
G1 X182.154 Y107.364 E.64937
G1 X182.114 Y107.858
G1 X166.677 Y92.421 E.67083
G1 X166.144 Y92.421
G1 X182.075 Y108.352 E.69229
G1 X182.035 Y108.845
G1 X165.61 Y92.42 E.71374
G1 X165.077 Y92.42
G1 X181.996 Y109.339 E.7352
G1 X181.956 Y109.833
G1 X164.544 Y92.42 E.75666
G1 X164.01 Y92.42
G1 X181.917 Y110.327 E.77812
G1 X181.877 Y110.821
G1 X163.477 Y92.42 E.79958
G1 X162.944 Y92.42
G1 X181.838 Y111.314 E.82104
G1 X181.798 Y111.808
G1 X162.411 Y92.42 E.8425
G1 X161.877 Y92.42
G1 X181.759 Y112.302 E.86395
G1 X181.72 Y112.796
G1 X161.344 Y92.42 E.88541
G1 X160.811 Y92.42
G1 X181.68 Y113.29 E.90687
G1 X181.641 Y113.783
G1 X160.278 Y92.42 E.92833
G1 X159.744 Y92.42
G1 X181.601 Y114.277 E.94979
G1 X181.562 Y114.771
G1 X159.211 Y92.42 E.97124
G1 X158.678 Y92.42
G1 X181.522 Y115.265 E.9927
G1 X181.483 Y115.758
G1 X158.144 Y92.42 E1.01416
G1 X157.611 Y92.42
G1 X181.443 Y116.252 E1.03562
G1 X181.404 Y116.746
G1 X157.078 Y92.42 E1.05708
G1 X156.545 Y92.42
G1 X181.364 Y117.24 E1.07854
G1 X181.325 Y117.734
G1 X156.011 Y92.42 E1.09999
G1 X155.478 Y92.42
G1 X181.285 Y118.227 E1.12145
G1 X181.246 Y118.721
G1 X154.945 Y92.42 E1.14291
G1 X154.411 Y92.42
G1 X181.206 Y119.215 E1.16437
G1 X181.167 Y119.709
G1 X153.878 Y92.42 E1.18583
G1 X153.345 Y92.42
G1 X181.127 Y120.203 E1.20729
G1 X181.088 Y120.696
G1 X152.812 Y92.42 E1.22874
G1 X152.278 Y92.42
G1 X181.049 Y121.19 E1.2502
G1 X181.009 Y121.684
G1 X151.745 Y92.42 E1.27166
G1 X151.212 Y92.42
G1 X180.97 Y122.178 E1.29312
G1 X180.93 Y122.672
G1 X150.679 Y92.42 E1.31458
G1 X150.145 Y92.42
G1 X180.891 Y123.165 E1.33604
G1 X180.851 Y123.659
G1 X149.612 Y92.42 E1.35749
G1 X149.079 Y92.42
G1 X180.812 Y124.153 E1.37895
G1 X180.772 Y124.647
G1 X148.545 Y92.42 E1.40041
G1 X148.012 Y92.42
G1 X180.733 Y125.14 E1.42187
G1 X180.693 Y125.634
G1 X147.479 Y92.42 E1.44333
G1 X146.946 Y92.42
G1 X180.654 Y126.128 E1.46479
G1 X180.614 Y126.622
G1 X146.412 Y92.42 E1.48624
G1 X145.879 Y92.42
G1 X180.575 Y127.116 E1.5077
G1 X180.535 Y127.609
G1 X145.346 Y92.42 E1.52916
G1 X144.812 Y92.42
G1 X180.496 Y128.103 E1.55062
G1 X180.456 Y128.597
G1 X144.279 Y92.42 E1.57208
G1 X143.746 Y92.42
G1 X180.417 Y129.091 E1.59354
G1 X180.378 Y129.585
G1 X143.213 Y92.42 E1.61499
G1 X142.679 Y92.42
G1 X180.338 Y130.078 E1.63645
G1 X180.299 Y130.572
G1 X142.146 Y92.42 E1.65791
G1 X141.613 Y92.42
G1 X180.259 Y131.066 E1.67937
G1 X180.22 Y131.56
G1 X141.08 Y92.42 E1.70083
G1 X140.546 Y92.42
G1 X180.18 Y132.053 E1.72229
G1 X180.141 Y132.547
G1 X140.013 Y92.42 E1.74374
G1 X139.48 Y92.42
G1 X180.101 Y133.041 E1.7652
G1 X180.062 Y133.535
G1 X138.946 Y92.419 E1.78666
G1 X138.413 Y92.419
G1 X180.022 Y134.029 E1.80812
G1 X179.983 Y134.522
G1 X137.88 Y92.419 E1.82958
G1 X137.347 Y92.419
G1 X179.943 Y135.016 E1.85104
G1 X179.904 Y135.51
G1 X136.813 Y92.419 E1.87249
G1 X136.28 Y92.419
G1 X179.864 Y136.004 E1.89395
G1 X179.825 Y136.498
G1 X135.747 Y92.419 E1.91541
G1 X135.213 Y92.419
G1 X179.785 Y136.991 E1.93687
G1 X179.746 Y137.485
G1 X134.68 Y92.419 E1.95833
G1 X134.147 Y92.419
G1 X179.707 Y137.979 E1.97979
G1 X179.667 Y138.473
G1 X133.614 Y92.419 E2.00124
G1 X133.08 Y92.419
G1 X179.628 Y138.966 E2.0227
G1 X179.588 Y139.46
G1 X132.547 Y92.419 E2.04416
G1 X132.014 Y92.419
G1 X179.549 Y139.954 E2.06562
G1 X179.509 Y140.448
G1 X131.481 Y92.419 E2.08708
G1 X130.947 Y92.419
G1 X179.47 Y140.942 E2.10854
G1 X179.43 Y141.435
M73 P93 R2
G1 X130.414 Y92.419 E2.12999
G1 X129.881 Y92.419
G1 X179.391 Y141.929 E2.15145
G1 X179.351 Y142.423
G1 X129.347 Y92.419 E2.17291
G1 X128.814 Y92.419
G1 X179.312 Y142.917 E2.19437
G1 X179.272 Y143.411
G1 X128.281 Y92.419 E2.21583
G1 X127.748 Y92.419
G1 X179.233 Y143.904 E2.23728
G1 X179.193 Y144.398
G1 X127.214 Y92.419 E2.25874
G1 X126.681 Y92.419
G1 X179.154 Y144.892 E2.2802
G1 X179.114 Y145.386
G1 X126.148 Y92.419 E2.30166
G1 X125.614 Y92.419
G1 X179.075 Y145.88 E2.32312
G1 X179.036 Y146.373
G1 X125.081 Y92.419 E2.34458
G1 X124.548 Y92.419
G1 X178.996 Y146.867 E2.36603
G1 X178.957 Y147.361
G1 X124.015 Y92.419 E2.38749
G1 X123.481 Y92.419
G1 X178.917 Y147.855 E2.40895
G1 X178.878 Y148.348
G1 X122.948 Y92.419 E2.43041
G1 X122.415 Y92.419
G1 X178.838 Y148.842 E2.45187
G1 X178.799 Y149.336
G1 X121.882 Y92.419 E2.47333
G1 X121.348 Y92.419
G1 X178.759 Y149.83 E2.49478
G1 X178.72 Y150.324
G1 X120.815 Y92.419 E2.51624
G1 X120.282 Y92.419
G1 X178.68 Y150.817 E2.5377
G1 X178.606 Y151.276
G1 X119.748 Y92.419 E2.55765
G1 X119.215 Y92.419
G1 X178.471 Y151.674 E2.57493
G1 X178.29 Y152.027
G1 X118.682 Y92.419 E2.59025
G1 X118.149 Y92.419
G1 X178.063 Y152.333 E2.60356
G1 X177.803 Y152.607
G1 X117.615 Y92.419 E2.61546
G1 X117.082 Y92.419
G1 X177.537 Y152.873 E2.62705
G1 X177.27 Y153.14
G1 X116.549 Y92.419 E2.63864
G1 X116.015 Y92.419
G1 X177.004 Y153.407 E2.65023
G1 X176.737 Y153.673
G1 X115.482 Y92.419 E2.66182
G1 X114.949 Y92.419
G1 X176.471 Y153.94 E2.67341
G1 X176.204 Y154.207
G1 X114.416 Y92.419 E2.685
G1 X113.882 Y92.419
G1 X175.937 Y154.474 E2.69659
G1 X175.671 Y154.74
G1 X113.349 Y92.419 E2.70819
G1 X112.816 Y92.419
G1 X175.404 Y155.007 E2.71978
G1 X175.138 Y155.274
G1 X112.283 Y92.418 E2.73137
G1 X111.749 Y92.418
G1 X174.871 Y155.541 E2.74296
G1 X174.605 Y155.807
G1 X111.216 Y92.418 E2.75455
G1 X110.683 Y92.418
G1 X174.338 Y156.074 E2.76614
G1 X174.072 Y156.341
G1 X110.149 Y92.418 E2.77773
G1 X109.616 Y92.418
G1 X173.805 Y156.607 E2.78932
G1 X173.539 Y156.874
G1 X109.083 Y92.418 E2.80091
G1 X108.55 Y92.418
G1 X173.272 Y157.141 E2.81251
G1 X173.006 Y157.408
G1 X108.016 Y92.418 E2.8241
G1 X107.483 Y92.418
G1 X172.739 Y157.674 E2.83569
G1 X172.473 Y157.941
G1 X106.95 Y92.418 E2.84728
G1 X106.416 Y92.418
G1 X172.206 Y158.208 E2.85887
G1 X171.939 Y158.474
G1 X105.883 Y92.418 E2.87046
G1 X105.35 Y92.418
M73 P93 R1
G1 X171.673 Y158.741 E2.88205
G1 X171.397 Y158.998
G1 X104.817 Y92.418 E2.89322
G1 X104.283 Y92.418
G1 X171.083 Y159.218 E2.90277
G1 X170.725 Y159.394
G1 X103.75 Y92.418 E2.9104
G1 X103.217 Y92.418
G1 X170.316 Y159.517 E2.91578
G1 X169.844 Y159.578
M73 P94 R1
G1 X102.684 Y92.418 E2.91843
G1 X102.15 Y92.418
G1 X169.315 Y159.583 E2.91862
G1 X168.782 Y159.583
G1 X101.617 Y92.418 E2.91862
G1 X101.084 Y92.418
G1 X168.248 Y159.583 E2.91863
G1 X167.715 Y159.583
G1 X100.55 Y92.418 E2.91863
G1 X100.017 Y92.418
G1 X167.182 Y159.583 E2.91863
G1 X166.649 Y159.583
G1 X99.484 Y92.418 E2.91863
G1 X98.951 Y92.418
G1 X166.115 Y159.583 E2.91863
G1 X165.582 Y159.583
G1 X98.417 Y92.418 E2.91863
G1 X97.884 Y92.418
G1 X165.049 Y159.583 E2.91863
G1 X164.515 Y159.583
G1 X97.351 Y92.418 E2.91863
G1 X96.817 Y92.418
G1 X163.982 Y159.583 E2.91863
G1 X163.449 Y159.583
G1 X96.284 Y92.418 E2.91863
G1 X95.751 Y92.418
G1 X162.916 Y159.583 E2.91863
G1 X162.382 Y159.583
G1 X95.218 Y92.418 E2.91863
G1 X94.684 Y92.418
G1 X161.849 Y159.583 E2.91864
G1 X161.316 Y159.583
G1 X94.151 Y92.418 E2.91864
G1 X93.618 Y92.418
G1 X160.783 Y159.583 E2.91864
G1 X160.249 Y159.583
G1 X93.085 Y92.418 E2.91864
G1 X92.551 Y92.418
G1 X159.716 Y159.583 E2.91864
G1 X159.183 Y159.583
G1 X92.018 Y92.418 E2.91864
G1 X91.485 Y92.418
G1 X158.65 Y159.583 E2.91864
G1 X158.116 Y159.583
G1 X90.951 Y92.418 E2.91864
G1 X90.418 Y92.418
G1 X157.583 Y159.583 E2.91864
G1 X157.05 Y159.583
G1 X89.885 Y92.418 E2.91864
G1 X89.352 Y92.418
G1 X156.517 Y159.583 E2.91864
G1 X155.983 Y159.583
G1 X88.818 Y92.418 E2.91865
G1 X88.285 Y92.418
G1 X155.45 Y159.583 E2.91865
G1 X154.917 Y159.583
G1 X87.752 Y92.418 E2.91865
G1 X87.218 Y92.418
G1 X154.384 Y159.583 E2.91865
G1 X153.85 Y159.583
G1 X86.685 Y92.418 E2.91865
G1 X86.152 Y92.417
G1 X153.317 Y159.583 E2.91865
G1 X152.784 Y159.583
G1 X85.619 Y92.417 E2.91865
G1 X85.085 Y92.417
G1 X152.251 Y159.583 E2.91865
G1 X151.717 Y159.583
G1 X84.552 Y92.417 E2.91865
G1 X84.019 Y92.417
G1 X151.184 Y159.583 E2.91865
G1 X150.651 Y159.583
G1 X83.486 Y92.417 E2.91865
G1 X82.952 Y92.417
M73 P95 R1
G1 X150.118 Y159.583 E2.91866
G1 X149.584 Y159.583
G1 X82.428 Y92.427 E2.91825
G1 X81.968 Y92.5
G1 X149.051 Y159.583 E2.91506
G1 X148.518 Y159.583
G1 X81.574 Y92.639 E2.90904
G1 X81.225 Y92.823
G1 X147.984 Y159.583 E2.90102
G1 X147.451 Y159.583
G1 X80.923 Y93.054 E2.89097
G1 X80.654 Y93.318
G1 X146.918 Y159.583 E2.87951
G1 X146.385 Y159.583
G1 X80.424 Y93.622 E2.86629
G1 X80.211 Y93.942
G1 X145.851 Y159.583 E2.85239
G1 X145.318 Y159.583
G1 X79.998 Y94.262 E2.83849
G1 X79.785 Y94.582
G1 X144.785 Y159.583 E2.82458
G1 X144.252 Y159.583
G1 X79.571 Y94.902 E2.81068
G1 X79.358 Y95.222
G1 X143.718 Y159.583 E2.79678
G1 X143.185 Y159.583
G1 X79.145 Y95.542 E2.78287
G1 X78.931 Y95.862
G1 X142.652 Y159.583 E2.76897
G1 X142.119 Y159.583
G1 X78.718 Y96.182 E2.75506
G1 X78.505 Y96.502
G1 X141.585 Y159.583 E2.74116
G1 X141.052 Y159.583
G1 X78.291 Y96.822 E2.72726
G1 X78.078 Y97.142
G1 X140.519 Y159.583 E2.71335
G1 X139.986 Y159.583
G1 X77.865 Y97.462 E2.69945
G1 X77.652 Y97.782
G1 X139.452 Y159.583 E2.68555
G1 X138.919 Y159.583
G1 X77.438 Y98.102 E2.67164
G1 X77.225 Y98.422
G1 X138.386 Y159.583 E2.65774
G1 X137.853 Y159.583
G1 X77.012 Y98.742 E2.64384
G1 X76.798 Y99.062
G1 X137.319 Y159.583 E2.62993
G1 X136.786 Y159.583
G1 X76.585 Y99.382 E2.61603
G1 X76.372 Y99.701
G1 X136.253 Y159.583 E2.60213
G1 X135.72 Y159.583
G1 X76.158 Y100.021 E2.58822
G1 X75.945 Y100.341
G1 X135.186 Y159.583 E2.57432
G1 X134.653 Y159.583
G1 X75.732 Y100.661 E2.56041
G1 X75.518 Y100.981
G1 X134.12 Y159.583 E2.54651
G1 X133.587 Y159.583
G1 X75.305 Y101.301 E2.53261
G1 X75.092 Y101.621
G1 X133.053 Y159.583 E2.5187
G1 X132.52 Y159.583
M73 P96 R1
G1 X74.879 Y101.941 E2.5048
G1 X74.665 Y102.261
G1 X131.987 Y159.583 E2.4909
G1 X131.454 Y159.583
G1 X74.452 Y102.581 E2.47699
G1 X74.239 Y102.901
G1 X130.92 Y159.583 E2.46309
G1 X130.387 Y159.583
G1 X74.025 Y103.221 E2.44919
G1 X73.824 Y103.553
G1 X129.854 Y159.583 E2.43477
G1 X129.32 Y159.583
G1 X73.653 Y103.915 E2.41902
G1 X73.543 Y104.339
G1 X128.787 Y159.583 E2.40061
G1 X128.254 Y159.583
G1 X73.506 Y104.835 E2.37907
G1 X73.54 Y105.402
G1 X127.721 Y159.583 E2.35441
G1 X127.187 Y159.583
G1 X73.589 Y105.984 E2.32913
G1 X73.637 Y106.565
G1 X126.654 Y159.583 E2.30385
G1 X126.121 Y159.583
G1 X73.685 Y107.147 E2.27857
G1 X73.734 Y107.729
G1 X125.588 Y159.583 E2.2533
G1 X125.054 Y159.583
G1 X73.782 Y108.311 E2.22802
G1 X73.831 Y108.892
G1 X124.521 Y159.583 E2.20274
G1 X123.988 Y159.583
G1 X73.879 Y109.474 E2.17746
G1 X73.928 Y110.056
G1 X123.455 Y159.583 E2.15218
G1 X122.921 Y159.583
G1 X73.976 Y110.638 E2.1269
G1 X74.025 Y111.219
G1 X122.388 Y159.583 E2.10162
G1 X121.855 Y159.583
G1 X74.073 Y111.801 E2.07634
G1 X74.122 Y112.383
G1 X121.322 Y159.583 E2.05106
G1 X120.788 Y159.583
G1 X74.17 Y112.965 E2.02578
G1 X74.219 Y113.546
G1 X120.255 Y159.583 E2.0005
G1 X119.722 Y159.583
G1 X74.267 Y114.128 E1.97522
G1 X74.316 Y114.71
G1 X119.189 Y159.583 E1.94994
G1 X118.655 Y159.583
G1 X74.364 Y115.291 E1.92467
G1 X74.413 Y115.873
G1 X118.122 Y159.583 E1.89939
G1 X117.589 Y159.583
G1 X74.461 Y116.455 E1.87411
G1 X74.51 Y117.037
G1 X117.056 Y159.583 E1.84883
G1 X116.522 Y159.583
G1 X74.558 Y117.618 E1.82355
G1 X74.607 Y118.2
G1 X115.989 Y159.583 E1.79827
G1 X115.456 Y159.583
G1 X74.655 Y118.782 E1.77299
G1 X74.704 Y119.364
M73 P96 R0
G1 X114.923 Y159.583 E1.74771
G1 X114.389 Y159.583
M73 P97 R0
G1 X74.752 Y119.945 E1.72243
G1 X74.8 Y120.527
G1 X113.856 Y159.583 E1.69715
G1 X113.323 Y159.583
G1 X74.849 Y121.109 E1.67187
G1 X74.897 Y121.691
G1 X112.789 Y159.583 E1.64659
G1 X112.256 Y159.583
G1 X74.946 Y122.272 E1.62131
G1 X74.994 Y122.854
G1 X111.723 Y159.583 E1.59604
G1 X111.19 Y159.583
G1 X75.043 Y123.436 E1.57076
G1 X75.091 Y124.018
G1 X110.656 Y159.583 E1.54548
G1 X110.123 Y159.583
G1 X75.14 Y124.599 E1.5202
G1 X75.188 Y125.181
G1 X109.59 Y159.583 E1.49492
G1 X109.057 Y159.583
G1 X75.237 Y125.763 E1.46964
G1 X75.285 Y126.344
G1 X108.523 Y159.583 E1.44436
G1 X107.99 Y159.583
G1 X75.334 Y126.926 E1.41908
G1 X75.382 Y127.508
G1 X107.457 Y159.583 E1.3938
G1 X106.924 Y159.583
G1 X75.431 Y128.09 E1.36852
G1 X75.479 Y128.671
G1 X106.39 Y159.583 E1.34324
G1 X105.857 Y159.583
G1 X75.528 Y129.253 E1.31796
G1 X75.576 Y129.835
G1 X105.324 Y159.583 E1.29268
G1 X104.791 Y159.583
G1 X75.625 Y130.417 E1.26741
G1 X75.673 Y130.998
G1 X104.257 Y159.583 E1.24213
G1 X103.724 Y159.583
G1 X75.722 Y131.58 E1.21685
G1 X75.77 Y132.162
G1 X103.191 Y159.583 E1.19157
G1 X102.658 Y159.583
G1 X75.819 Y132.744 E1.16629
G1 X75.867 Y133.325
G1 X102.124 Y159.583 E1.14101
G1 X101.591 Y159.583
G1 X75.915 Y133.907 E1.11573
G1 X75.964 Y134.489
G1 X101.058 Y159.583 E1.09045
G1 X100.525 Y159.583
G1 X76.012 Y135.07 E1.06517
G1 X76.061 Y135.652
G1 X99.991 Y159.583 E1.03989
G1 X99.458 Y159.583
G1 X76.109 Y136.234 E1.01461
G1 X76.158 Y136.816
G1 X98.925 Y159.583 E.98933
G1 X98.392 Y159.583
G1 X76.206 Y137.397 E.96405
G1 X76.255 Y137.979
G1 X97.858 Y159.583 E.93878
G1 X97.325 Y159.583
G1 X76.303 Y138.561 E.9135
G1 X76.352 Y139.143
G1 X96.792 Y159.583 E.88822
G1 X96.259 Y159.583
G1 X76.4 Y139.724 E.86294
G1 X76.449 Y140.306
G1 X95.725 Y159.583 E.83766
G1 X95.192 Y159.583
G1 X76.497 Y140.888 E.81238
G1 X76.546 Y141.47
G1 X94.659 Y159.583 E.7871
G1 X94.125 Y159.583
G1 X76.594 Y142.051 E.76182
G1 X76.643 Y142.633
M73 P98 R0
G1 X93.592 Y159.583 E.73654
G1 X93.059 Y159.583
G1 X76.691 Y143.215 E.71126
G1 X76.74 Y143.797
G1 X92.526 Y159.583 E.68598
G1 X91.992 Y159.583
G1 X76.788 Y144.378 E.6607
G1 X76.837 Y144.96
G1 X91.459 Y159.583 E.63542
G1 X90.926 Y159.583
G1 X76.885 Y145.542 E.61015
G1 X76.934 Y146.123
G1 X90.393 Y159.583 E.58487
G1 X89.859 Y159.583
G1 X76.982 Y146.705 E.55959
G1 X77.03 Y147.287
G1 X89.326 Y159.583 E.53431
G1 X88.793 Y159.583
G1 X77.079 Y147.869 E.50903
G1 X77.127 Y148.45
G1 X88.26 Y159.583 E.48375
G1 X87.726 Y159.583
G1 X77.176 Y149.032 E.45847
G1 X77.224 Y149.614
G1 X87.193 Y159.583 E.43319
G1 X86.66 Y159.583
G1 X77.273 Y150.196 E.40791
G1 X77.321 Y150.777
G1 X86.12 Y159.576 E.38235
G1 X85.47 Y159.46
G1 X77.442 Y151.431 E.34887
; WIPE_START
M204 S10000
G1 X78.856 Y152.845 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X85.396 Y148.91 Z5 F30000
G1 X176.256 Y94.237 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.107679
G1 F15000
G1 X176.016 Y93.969 E.0019
; LINE_WIDTH: 0.146716
G1 X175.776 Y93.701 E.00304
; LINE_WIDTH: 0.185753
G1 X175.536 Y93.433 E.00418
; LINE_WIDTH: 0.208039
G2 X174.991 Y92.907 I-4.209 J3.822 E.01021
; LINE_WIDTH: 0.154899
G1 X174.847 Y92.796 E.00166
; LINE_WIDTH: 0.110411
G1 X174.702 Y92.686 E.001
; WIPE_START
G1 X174.847 Y92.796 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X178.382 Y96.896 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.106988
G1 F15000
G1 X178.135 Y96.621 E.00193
; LINE_WIDTH: 0.144642
G1 X177.889 Y96.345 E.00306
; LINE_WIDTH: 0.182296
G1 X177.642 Y96.07 E.0042
; LINE_WIDTH: 0.21995
G1 X177.396 Y95.794 E.00533
; WIPE_START
G1 X177.642 Y96.07 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X180.508 Y99.556 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.106992
G1 F15000
G1 X180.262 Y99.28 E.00193
; LINE_WIDTH: 0.144652
G1 X180.015 Y99.005 E.00306
; LINE_WIDTH: 0.182313
G1 X179.769 Y98.729 E.0042
; LINE_WIDTH: 0.219973
G1 X179.522 Y98.454 E.00533
; WIPE_START
G1 X179.769 Y98.729 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.247 Y101.831 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.1032
G1 F15000
G1 X182.18 Y101.741 E.00055
; LINE_WIDTH: 0.133277
G1 X182.114 Y101.65 E.00083
; LINE_WIDTH: 0.172918
G1 X181.962 Y101.464 E.00255
; LINE_WIDTH: 0.218145
G1 X181.648 Y101.113 E.00672
; WIPE_START
G1 X181.962 Y101.464 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X180.481 Y108.951 Z5 F30000
G1 X170.499 Y159.434 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.0972568
G1 F15000
G1 X170.339 Y159.516 E.0008
; WIPE_START
G1 X170.499 Y159.434 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X162.866 Y159.414 Z5 F30000
G1 X84.927 Y159.211 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.102791
G1 F15000
G1 X84.823 Y159.131 E.00064
; LINE_WIDTH: 0.164552
G1 X84.539 Y158.88 E.00376
G1 X77.945 Y152.281 E.09247
; LINE_WIDTH: 0.141119
G1 X77.827 Y152.142 E.00145
; LINE_WIDTH: 0.10727
G3 X77.68 Y151.964 I1.195 J-1.132 E.00122
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F15000
G1 X77.827 Y152.142 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z5 I1.217 J0 P1  F30000
M106 S0
M106 P2 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20240528 =====================
M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G1 E-0.8 F1800 ; retract
G1 Z5.1 F900 ; lower z a little
G1 X65 Y245 F12000 ; move to safe pos
G1 Y265 F3000

G1 X65 Y245 F12000
G1 Y265 F3000
M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

G1 X100 F12000 ; wipe
; pull back filament to AMS
M620 S255
G1 X20 Y50 F12000
G1 Y-3
T255
G1 X65 F12000
G1 Y265
G1 X100 F12000 ; wipe
M621 S255
M104 S0 ; turn off hotend

M622.1 S1 ; for prev firware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
    M400 ; wait all motion done
    M991 S0 P-1 ;end smooth timelapse at safe pos
    M400 S3 ;wait for last picture to be taken
M623; end of "timelapse_record_flag"

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z104.6 F600
    G1 Z102.6

M400 P100
M17 R ; restore z current

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0
;=====printer finish  sound=========
M17
M400 S1
M1006 S1
M1006 A0 B20 L100 C37 D20 M40 E42 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C46 D10 M80 E46 F10 N80
M1006 A44 B20 L100 C39 D20 M60 E48 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C48 D10 M60 E44 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10  N100
M1006 A49 B20 L100 C44 D20 M100 E41 F20 N100
M1006 A0 B20 L100 C0 D20 M60 E0 F20 N100
M1006 A0 B20 L100 C37 D20 M30 E37 F20 N60
M1006 W

M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power
M960 S5 P0 ; turn off logo lamp
M73 P100 R0
; EXECUTABLE_BLOCK_END

