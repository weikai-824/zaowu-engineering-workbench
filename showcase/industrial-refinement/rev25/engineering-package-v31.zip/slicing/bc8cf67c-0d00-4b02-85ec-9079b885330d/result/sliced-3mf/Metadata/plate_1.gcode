; HEADER_BLOCK_START
; BambuStudio 02.08.02.60
; model printing time: 21m 5s; total estimated time: 28m 21s
; total layer number: 32
; total filament length [mm] : 1986.98
; total filament volume [cm^3] : 4779.24
; total filament weight [g] : 6.02
; filament_density: 1.26
; filament_diameter: 1.75
; max_z_height: 6.40
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 70
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 1
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 0x0,18x0,18x28,0x28
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = auto_brim
; brim_width = 5
; chamber_temperatures = 0
; change_filament_gcode = ;=X1 20251031=\nM620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nG1 X70 F21000\nG1 Y245\nG1 Y265 F3000\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E-{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{else}\nM620.11 S0\n{endif}\nM400\nG1 X90 F3000\nG1 Y255 F4000\nG1 X100 F5000\nG1 X120 F15000\nG1 X20 Y50 F21000\nG1 Y-3\n{if toolchange_count == 2}\n; get travel path for change filament\nM620.1 X[travel_point_1_x] Y[travel_point_1_y] F21000 P0\nM620.1 X[travel_point_2_x] Y[travel_point_2_y] F21000 P1\nM620.1 X[travel_point_3_x] Y[travel_point_3_y] F21000 P2\n{endif}\nM620.1 E F{flush_volumetric_speeds[previous_extruder]/2.4053*60} T{flush_temperatures[previous_extruder]}\nT[next_extruder]\nM620.1 E F{flush_volumetric_speeds[next_extruder]/2.4053*60} T{flush_temperatures[next_extruder]}\n\n{if next_extruder < 255}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM628 S1\nG92 E0\nG1 E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM400\nM629 S1\n{else}\nM620.11 S0\n{endif}\nG92 E0\n{if flush_length_1 > 1}\nM83\n; FLUSH_START\n; always use highest temperature to flush\nM400\n{if filament_type[next_extruder] == \"PETG\"}\nM109 S260\n{elsif filament_type[next_extruder] == \"PVA\"}\nM109 S210\n{else}\nM109 S{flush_temperatures[next_extruder]}\n{endif}\n{if flush_length_1 > 23.7}\nG1 E23.7 F{flush_volumetric_speeds[previous_extruder]/2.4053*60} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\n{else}\nG1 E{flush_length_1} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_4 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n; FLUSH_START\nM400\nM109 S[new_filament_temp]\nG1 E2 F{flush_volumetric_speeds[next_extruder]/2.4053*60} ;Compensate for filament spillage during waiting temperature\n; FLUSH_END\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM106 P1 S255\nM400 S3\n\nG1 X70 F5000\nG1 X90 F3000\nG1 Y255 F4000\nG1 X105 F5000\nG1 Y265 F5000\nG1 X70 F10000\nG1 X100 F5000\nG1 X70 F10000\nG1 X100 F5000\n\nG1 X70 F10000\nG1 X80 F15000\nG1 X60\nG1 X80\nG1 X60\nG1 X80 ; shake to put down garbage\nG1 X100 F5000\nG1 X165 F15000; wipe and shake\nG1 Y256 ; move Y to aside, prevent collision\nM400\nG1 Z{max_layer_z + 3.0} F3000\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\nM621 S[next_extruder]A\n
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; compatible_printers_condition = 
; complete_print_exhaust_fan_speed = 70
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.008
; counter_coef_3 = -0.041
; counter_limit_max = 0.033
; counter_limit_min = -0.035
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 10000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL X1C"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL X1C
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70
; elefant_foot_compensation = 0.15
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 1
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0
; eng_plate_temp_initial_layer = 0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 33
; extruder_clearance_height_to_lid = 90
; extruder_clearance_height_to_rod = 34
; extruder_clearance_max_radius = 68
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x2
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard,Direct Drive High Flow"
; fan_cooling_layer_time = 100
; fan_direction = left
; fan_max_speed = 100
; fan_min_speed = 100
; farthest_point_timelapse = 1
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 100
; filament_bridge_speed = 25
; filament_change_length = 5
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 0
; filament_cost = 19.99
; filament_density = 1.26
; filament_dev_ams_drying_ams_limitations = 1
; filament_dev_ams_drying_heat_distortion_temperature = 45
; filament_dev_ams_drying_temperature = 45
; filament_dev_ams_drying_time = 12
; filament_dev_chamber_drying_bed_temperature = 70
; filament_dev_chamber_drying_time = 12
; filament_dev_drying_cooling_temperature = 45
; filament_dev_drying_softening_temperature = 50
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = "; filament end gcode \n\n"
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = GFA00
; filament_is_mixed = 0
; filament_is_support = 0
; filament_long_retractions_when_cut = 1
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 21
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 50
; filament_overhang_3_4_speed = 30
; filament_overhang_4_4_speed = 10
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 10
; filament_prime_volume = 30
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 14
; filament_retraction_distances_when_cut = 18
; filament_scarf_gap = 0%
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Bambu PLA Basic @BBL X1C"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\nM142 P1 R35 S40\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = "Bambu Lab"
; filament_volume_map = 0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 0
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 
; hole_coef_1 = 0
; hole_coef_2 = -0.008
; hole_coef_3 = 0.23415
; hole_limit_max = 0.22
; hole_limit_min = 0.088
; hot_plate_temp = 55
; hot_plate_temp_initial_layer = 55
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 13.8
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = ;===== date: 20240528 =====================\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG1 E-0.8 F1800 ; retract\nG1 Z{max_layer_z + 0.5} F900 ; lower z a little\nG1 X65 Y245 F12000 ; move to safe pos\nG1 Y265 F3000\n\nG1 X65 Y245 F12000\nG1 Y265 F3000\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\nG1 X100 F12000 ; wipe\n; pull back filament to AMS\nM620 S255\nG1 X20 Y50 F12000\nG1 Y-3\nT255\nG1 X65 F12000\nG1 Y265\nG1 X100 F12000 ; wipe\nM621 S255\nM104 S0 ; turn off hotend\n\nM622.1 S1 ; for prev firware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n    M400 ; wait all motion done\n    M991 S0 P-1 ;end smooth timelapse at safe pos\n    M400 S3 ;wait for last picture to be taken\nM623; end of \"timelapse_record_flag\"\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 250}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z250 F600\n    G1 Z248\n{endif}\nM400 P100\nM17 R ; restore z current\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n;=====printer finish  sound=========\nM17\nM400 S1\nM1006 S1\nM1006 A0 B20 L100 C37 D20 M40 E42 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C46 D10 M80 E46 F10 N80\nM1006 A44 B20 L100 C39 D20 M60 E48 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C48 D10 M60 E44 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10  N100\nM1006 A49 B20 L100 C44 D20 M100 E41 F20 N100\nM1006 A0 B20 L100 C0 D20 M60 E0 F20 N100\nM1006 A0 B20 L100 C37 D20 M30 E37 F20 N60\nM1006 W\n\nM17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power\nM960 S5 P0 ; turn off logo lamp\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 29
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 20000,20000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 9000,9000
; machine_max_acceleration_x = 20000,20000
; machine_max_acceleration_y = 20000,20000
; machine_max_acceleration_z = 500,500
; machine_max_force_Y = 0
; machine_max_jerk_e = 2.5,2.5
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_printed_mass = 0
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,500
; machine_max_speed_y = 500,500
; machine_max_speed_z = 20,20
; machine_min_extruding_rate = 0
; machine_min_travel_rate = 0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = ;===== machine: X1-0.4 ====================\n;===== date: 20251031 ==================\n;===== start printer sound ================\nM17\nM400 S1\nM1006 S1\nM1006 A0 B10 L100 C37 D10 M60 E37 F10 N60\nM1006 A0 B10 L100 C41 D10 M60 E41 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A46 B10 L100 C43 D10 M70 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A43 B10 L100 C0 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A41 B10 L100 C0 D10 M100 E41 F10 N100\nM1006 A44 B10 L100 C0 D10 M100 E44 F10 N100\nM1006 A49 B10 L100 C0 D10 M100 E49 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A48 B10 L100 C44 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A44 B10 L100 C0 D10 M90 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A46 B10 L100 C43 D10 M60 E39 F10 N100\nM1006 W\n;===== turn on the HB fan =================\nM104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle\n;===== reset machine status =================\nM290 X40 Y40 Z2.6666666\nG91\nM17 Z0.4 ; lower the z-motor current\nG380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed\nG380 S2 Z-25 F300 ;\nG1 Z5 F300;\nG90\nM17 X1.2 Y1.2 Z0.75 ; reset motor current to default\nM960 S5 P1 ; turn on logo lamp\nG90\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 5\nM221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem\nG29.1 Z{+0.0} ; clear z-trim value first\nM204 S10000 ; init ACC set to 10m/s^2\n\n;===== heatbed preheat ====================\nM1002 gcode_claim_action:54\nM140 S[bed_temperature_initial_layer_single] ;set bed temp\nM190 S[bed_temperature_initial_layer_single] ;wait for bed temp\n\n{if scan_first_layer}\n;=========register first layer scan=====\nM977 S1 P60\n{endif}\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\n;===== prepare print temperature and material ==========\nM104 S[nozzle_temperature_initial_layer] ;set extruder temp\nG91\nG0 Z10 F1200\nG90\nG28 X\nM975 S1 ; turn on\nG1 X60 F12000\nG1 Y245\nG1 Y265 F3000\nM620 M\nM620 S[initial_no_support_extruder]A   ; switch material if AMS exist\n    M109 S[nozzle_temperature_initial_layer]\n    G1 X120 F12000\n\n    G1 X20 Y50 F12000\n    G1 Y-3\n    T[initial_no_support_extruder]\n    G1 X54 F12000\n    G1 Y265\n    M400\nM621 S[initial_no_support_extruder]A\nM620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T{flush_temperatures[initial_no_support_extruder]}\n\nM412 S1 ; ===turn on filament runout detection===\n\nM109 S250 ;set nozzle to common flush temp\nM106 P1 S0\nG92 E0\nG1 E50 F200\nM400\nM104 S[nozzle_temperature_initial_layer]\nG92 E0\nG1 E50 F200\nM400\nM106 P1 S255\nG92 E0\nG1 E5 F300\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20} ; drop nozzle temp, make filament shink a bit\nG92 E0\nG1 E-0.5 F300\n\nG1 X70 F9000\nG1 X76 F15000\nG1 X65 F15000\nG1 X76 F15000\nG1 X65 F15000; shake to put down garbage\nG1 X80 F6000\nG1 X95 F15000\nG1 X80 F15000\nG1 X165 F15000; wipe and shake\nM400\nM106 P1 S0\n;===== prepare print temperature and material end =====\n\n\n;===== wipe nozzle ===============================\nM1002 gcode_claim_action : 14\nM975 S1\nM106 S255\nG1 X65 Y230 F18000\nG1 Y264 F6000\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20}\nG1 X100 F18000 ; first wipe mouth\n\nG0 X135 Y253 F20000  ; move to exposed steel surface edge\nG28 Z P0 T300; home z with low precision,permit 300deg temperature\nG29.2 S0 ; turn off ABL\nG0 Z5 F20000\n\nG1 X60 Y265\nG92 E0\nG1 E-0.5 F300 ; retrack more\nG1 X100 F5000; second wipe mouth\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X90 F5000\nG0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle\nM104 S140 ; set temp down to heatbed acceptable\nM106 S255 ; turn on fan (G28 has turn off fan)\n\nM221 S; push soft endstop status\nM221 Z0 ;turn off Z axis endstop\nG0 Z0.5 F20000\nG0 X125 Y259.5 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 X128\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\n\nM109 S140 ; wait nozzle temp down to heatbed acceptable\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\n\nM221 R; pop softend status\nG1 Z10 F1200\nM400\nG1 Z10\nG1 F30000\nG1 X128 Y128\nG29.2 S1 ; turn on ABL\n;G28 ; home again after hard wipe mouth\nM106 S0 ; turn off fan , too noisy\n;===== wipe nozzle end ================================\n\n;===== check scanner clarity ===========================\nG1 X128 Y128 F24000\nG28 Z P0\nM972 S5 P0\nG1 X230 Y15 F24000\n;===== check scanner clarity end =======================\n\n;===== bed leveling ==================================\nM1002 judge_flag g29_before_print_flag\nM622 J1\n\n    M1002 gcode_claim_action : 1\n    G29 A X{first_layer_print_min[0]} Y{first_layer_print_min[1]} I{first_layer_print_size[0]} J{first_layer_print_size[1]}\n    M400\n    M500 ; save cali data\n\nM623\n;===== bed leveling end ================================\n\n;===== home after wipe mouth============================\nM1002 judge_flag g29_before_print_flag\nM622 J0\n\n    M1002 gcode_claim_action : 13\n    G28\n\nM623\n;===== home after wipe mouth end =======================\n\nM975 S1 ; turn on vibration supression\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\nM104 S{nozzle_temperature_initial_layer[initial_no_support_extruder]} ; set extrude temp earlier, to reduce wait time\n\n;===== mech mode fast check============================\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q1 A7 B30 C80  H15 K0\nM974 Q1 S2 P0\n\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q0 A7 B30 C90 Q0 H15 K0\nM974 Q0 S2 P0\n\nM975 S1\nG1 F30000\nG1 X230 Y15\nG28 X ; re-home XY\n;===== mech mode fast check============================\n\n{if scan_first_layer}\n;start heatbed  scan====================================\nM976 S2 P1\nG90\nG1 X128 Y128 F20000\nM976 S3 P2  ;register void printing detection\n{endif}\n\n;===== nozzle load line ===============================\nM975 S1\nG90\nM83\nT1000\nG1 X18.0 Y1.0 Z0.8 F18000;Move to start position\nM109 S{nozzle_temperature[initial_no_support_extruder]}\nG1 Z0.2\nG0 E2 F300\nG0 X240 E15 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nG0 Y11 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\nG0 X239.5\nG0 E0.2\nG0 Y1.5 E0.700\nG0 X231 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM400\n\n;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==\n;curr_bed_type={curr_bed_type}\n{if curr_bed_type==\"Textured PEI Plate\"}\nG29.1 Z{-0.04} ; for Textured PEI Plate\n{endif}\n\n;===== draw extrinsic para cali paint =================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M1002 gcode_claim_action : 8\n\n    T1000\n\n    G0 F1200.0 X231 Y12   Z0.2 E0.577\n    G0 F1200.0 X226 Y12   Z0.2 E0.275\n    G0 F1200.0 X226 Y1.5  Z0.2 E0.577\n    G0 F1200.0 X220 Y1.5  Z0.2 E0.330\n    G0 F1200.0 X220 Y8    Z0.2 E0.358\n    G0 F1200.0 X210 Y8    Z0.2 E0.549\n    G0 F1200.0 X210 Y1.5  Z0.2 E0.357\n\n    G0 X48.0 E11.9 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X48.0 Y12 E0.772 F1200.0\n    G0 X45.0 E0.22 F1200.0\n    G0 X35.0 Y6.0 E0.86 F1200.0\n\n    ;=========== extruder cali extrusion ==================\n    T1000\n    M83\n    {if default_acceleration > 0}\n        {if outer_wall_acceleration > 0}\n            M204 S[outer_wall_acceleration]\n        {else}\n            M204 S[default_acceleration]\n        {endif}\n    {endif}\n    G0 X35.000 Y6.000 Z0.300 F30000 E0\n    G1 F1500.000 E0.800\n    M106 S0 ; turn off fan\n    G0 X185.000 E9.35441 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G0 X187 Z0\n    G1 F1500.000 E-0.800\n    G0 Z1\n    G0 X180 Z0.3 F18000\n\n    M900 L1000.0 M1.0\n    M900 K0.040\n    G0 X45.000 F30000\n    G0 Y8.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.020\n    G0 X45.000 F30000\n    G0 Y10.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.000\n    G0 X45.000 F30000\n    G0 Y12.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n\n    G0 X45.000 F30000 ; move to start point\n\nM623 ; end of \"draw extrinsic para cali paint\"\n\n\nM1002 judge_flag extrude_cali_flag\nM622 J0\n    G0 X231 Y1.5 F30000\n    G0 X18 E14.3 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM623\n\nM104 S140\n\n\n;=========== laser and rgb calibration ===========\nM400\nM18 E\nM500 R\n\nM973 S3 P14\n\nG1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nT1100\nG1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nM400 P100\nM960 S1 P1\nM400 P100\nM973 S6 P0; use auto exposure for horizontal laser by xcam\nM960 S0 P0\n\nG1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos\nM960 S2 P1\nM400 P100\nM973 S6 P1; use auto exposure for vertical laser by xcam\nM960 S0 P0\n\n;=========== handeye calibration ======================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M973 S3 P1 ; camera start stream\n    M400 P500\n    M973 S1\n    G0 F6000 X228.500 Y4.750 Z0.000\n    M960 S0 P1\n    M973 S1\n    M400 P800\n    M971 S6 P0\n    M973 S2 P0\n    M400 P500\n    G0 Z0.000 F12000\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P200\n    M971 S5 P1\n    M973 S2 P1\n    M400 P500\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P3\n    G0 Z0.500 F12000\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P4\n    M973 S2 P0\n    M400 P500\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P500\n    M971 S5 P2\n    M963 S1\n    M400 P1500\n    M964\n    T1100\n    G1 Z3 F3000\n\n    M400\n    M500 ; save cali data\n\n    M104 S{nozzle_temperature[initial_no_support_extruder]} ; rise nozzle temp now ,to reduce temp waiting time.\n\n    T1100\n    M400 P400\n    M960 S0 P0\n    G0 F30000.000 Y10.000 X65.000 Z0.000\n    M400 P400\n    M960 S1 P1\n    M400 P50\n\n    M969 S1 N3 A2000\n    G0 F360.000 X181.000 Z0.000\n    M980.3 A70.000 B{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60/4} C5.000 D{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60} E5.000 F175.000 H1.000 I0.000 J0.020 K0.040\n    M400 P100\n    G0 F20000\n    G0 Z1 ; rise nozzle up\n    T1000 ; change to nozzle space\n    G0 X45.000 Y4.000 F30000 ; move to test line pos\n    M969 S0 ; turn off scanning\n    M960 S0 P0\n\n\n    G1 Z2 F20000\n    T1000\n    G0 X45.000 Y4.000 F30000 E0\n    M109 S{nozzle_temperature[initial_no_support_extruder]}\n    G0 Z0.3\n    G1 F1500.000 E3.600\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n\n    ; see if extrude cali success, if not ,use default value\n    M1002 judge_last_extrude_cali_success\n    M622 J0\n        M400\n        M900 K0.02 M{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*0.02}\n    M623\n\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X185.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X190.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X195.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X200.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X205.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X210.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X215.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X220.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X225.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    M973 S4\n\nM623\n\n;========turn off light and wait extrude temperature =============\nM1002 gcode_claim_action : 0\nM973 S4 ; turn off scanner\nM400 ; wait all motion done before implement the emprical L parameters\n;M900 L500.0 ; Empirical parameters\nM109 S[nozzle_temperature_initial_layer]\nM960 S1 P0 ; turn off laser\nM960 S2 P0 ; turn off laser\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off big fan\nM106 P3 S0 ; turn off chamber fan\n\nM975 S1 ; turn on mech mode supression\nG90\nM83\nT1000\n;===== purge line to wipe the nozzle ============================\nG1 E{-retraction_length[initial_no_support_extruder]} F1800\nG1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position\nG1 E{retraction_length[initial_no_support_extruder]} F1800\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]}\nG1 Z0.2\nG0 X239 E15 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\nG0 Y12 E0.7 F{outer_wall_volumetric_speed/(0.3*0.5)/4* 60}\n
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 28
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.2
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = hardened_steel
; nozzle_volume = 107
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 50%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab X1 Carbon 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab P1S 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL X1C
; printable_area = 0x0,256x0,256x256,0x256
; printable_height = 250
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab X1 Carbon
; printer_notes = 
; printer_settings_id = Bambu Lab X1 Carbon 0.4 nozzle
; printer_structure = corexy
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 249
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 1
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 4
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 150
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 15%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45
; supertack_plate_temp_initial_layer = 45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = tree(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45
; template_custom_gcode = 
; textured_plate_temp = 55
; textured_plate_temp_initial_layer = 55
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;========Date 20250206========\n; SKIPPABLE_START\n; SKIPTYPE: timelapse\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n{if timelapse_type == 0} ; timelapse without wipe tower\nM971 S11 C10 O0\nM1004 S5 P1  ; external shutter\n{elsif timelapse_type == 1} ; timelapse with wipe tower\nG92 E0\nG1 X65 Y245 F20000 ; move to safe pos\nG17\nG2 Z{layer_z} I0.86 J0.86 P1 F20000\nG1 Y265 F3000\nM400\nM1004 S5 P1  ; external shutter\nM400 P300\nM971 S11 C10 O0\nG92 E0\nG1 X100 F5000\nG1 Y255 F20000\n{endif}\nM623\n; SKIPPABLE_END\n
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 500
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab P1S 0.4 nozzle";"Bambu Lab P1P 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle";"Bambu Lab A1 0.4 nozzle";"Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R28
M201 X20000 Y20000 Z500 E5000
M203 X500 Y500 Z20 E30
M204 P20000 R5000 T20000
M205 X9.00 Y9.00 Z3.00 E2.50
M106 S0
M106 P2 S0
; FEATURE: Custom
;===== machine: X1-0.4 ====================
;===== date: 20251031 ==================
;===== start printer sound ================
M17
M400 S1
M1006 S1
M1006 A0 B10 L100 C37 D10 M60 E37 F10 N60
M1006 A0 B10 L100 C41 D10 M60 E41 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A46 B10 L100 C43 D10 M70 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A43 B10 L100 C0 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A41 B10 L100 C0 D10 M100 E41 F10 N100
M1006 A44 B10 L100 C0 D10 M100 E44 F10 N100
M1006 A49 B10 L100 C0 D10 M100 E49 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A48 B10 L100 C44 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A44 B10 L100 C0 D10 M90 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A46 B10 L100 C43 D10 M60 E39 F10 N100
M1006 W
;===== turn on the HB fan =================
M104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle
;===== reset machine status =================
M290 X40 Y40 Z2.6666666
G91
M17 Z0.4 ; lower the z-motor current
G380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed
G380 S2 Z-25 F300 ;
G1 Z5 F300;
G90
M17 X1.2 Y1.2 Z0.75 ; reset motor current to default
M960 S5 P1 ; turn on logo lamp
G90
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 5
M221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem
G29.1 Z0 ; clear z-trim value first
M204 S10000 ; init ACC set to 10m/s^2

;===== heatbed preheat ====================
M1002 gcode_claim_action:54
M140 S35 ;set bed temp
M190 S35 ;wait for bed temp


;=========register first layer scan=====
M977 S1 P60


;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

;===== prepare print temperature and material ==========
M104 S220 ;set extruder temp
G91
G0 Z10 F1200
G90
G28 X
M975 S1 ; turn on
G1 X60 F12000
G1 Y245
G1 Y265 F3000
M620 M
M620 S0A   ; switch material if AMS exist
    M109 S220
    G1 X120 F12000

    G1 X20 Y50 F12000
    G1 Y-3
    T0
    G1 X54 F12000
    G1 Y265
    M400
M621 S0A
M620.1 E F523.843 T240

M412 S1 ; ===turn on filament runout detection===

M109 S250 ;set nozzle to common flush temp
M106 P1 S0
G92 E0
M73 P2 R27
G1 E50 F200
M400
M104 S220
G92 E0
M73 P17 R23
G1 E50 F200
M400
M106 P1 S255
G92 E0
G1 E5 F300
M109 S200 ; drop nozzle temp, make filament shink a bit
G92 E0
M73 P18 R23
G1 E-0.5 F300

M73 P19 R22
G1 X70 F9000
G1 X76 F15000
G1 X65 F15000
G1 X76 F15000
G1 X65 F15000; shake to put down garbage
G1 X80 F6000
G1 X95 F15000
G1 X80 F15000
G1 X165 F15000; wipe and shake
M400
M106 P1 S0
;===== prepare print temperature and material end =====


;===== wipe nozzle ===============================
M1002 gcode_claim_action : 14
M975 S1
M106 S255
G1 X65 Y230 F18000
G1 Y264 F6000
M109 S200
G1 X100 F18000 ; first wipe mouth

G0 X135 Y253 F20000  ; move to exposed steel surface edge
G28 Z P0 T300; home z with low precision,permit 300deg temperature
G29.2 S0 ; turn off ABL
G0 Z5 F20000

G1 X60 Y265
G92 E0
G1 E-0.5 F300 ; retrack more
G1 X100 F5000; second wipe mouth
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X90 F5000
G0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle
M104 S140 ; set temp down to heatbed acceptable
M106 S255 ; turn on fan (G28 has turn off fan)

M221 S; push soft endstop status
M221 Z0 ;turn off Z axis endstop
G0 Z0.5 F20000
G0 X125 Y259.5 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 X128
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300

M109 S140 ; wait nozzle temp down to heatbed acceptable
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000

M221 R; pop softend status
G1 Z10 F1200
M400
G1 Z10
G1 F30000
G1 X128 Y128
G29.2 S1 ; turn on ABL
;G28 ; home again after hard wipe mouth
M106 S0 ; turn off fan , too noisy
;===== wipe nozzle end ================================

;===== check scanner clarity ===========================
G1 X128 Y128 F24000
G28 Z P0
M972 S5 P0
G1 X230 Y15 F24000
;===== check scanner clarity end =======================

;===== bed leveling ==================================
M1002 judge_flag g29_before_print_flag
M622 J1

    M1002 gcode_claim_action : 1
    G29 A X72 Y116 I112 J24
    M400
    M500 ; save cali data

M623
;===== bed leveling end ================================

;===== home after wipe mouth============================
M1002 judge_flag g29_before_print_flag
M622 J0

    M1002 gcode_claim_action : 13
    G28

M623
;===== home after wipe mouth end =======================

M975 S1 ; turn on vibration supression

;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

M104 S220 ; set extrude temp earlier, to reduce wait time

;===== mech mode fast check============================
G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q1 A7 B30 C80  H15 K0
M974 Q1 S2 P0

M73 P20 R22
G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q0 A7 B30 C90 Q0 H15 K0
M974 Q0 S2 P0

M975 S1
G1 F30000
G1 X230 Y15
G28 X ; re-home XY
;===== mech mode fast check============================


;start heatbed  scan====================================
M976 S2 P1
G90
G1 X128 Y128 F20000
M976 S3 P2  ;register void printing detection


;===== nozzle load line ===============================
M975 S1
G90
M83
T1000
G1 X18.0 Y1.0 Z0.8 F18000;Move to start position
M109 S220
G1 Z0.2
G0 E2 F300
G0 X240 E15 F6033.27
G0 Y11 E0.700 F1508.32
G0 X239.5
G0 E0.2
G0 Y1.5 E0.700
G0 X231 E0.700 F6033.27
M400

;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==
;curr_bed_type=Cool Plate


;===== draw extrinsic para cali paint =================
M1002 judge_flag extrude_cali_flag
M622 J1

    M1002 gcode_claim_action : 8

    T1000

    G0 F1200.0 X231 Y12   Z0.2 E0.577
    G0 F1200.0 X226 Y12   Z0.2 E0.275
    G0 F1200.0 X226 Y1.5  Z0.2 E0.577
    G0 F1200.0 X220 Y1.5  Z0.2 E0.330
    G0 F1200.0 X220 Y8    Z0.2 E0.358
    G0 F1200.0 X210 Y8    Z0.2 E0.549
    G0 F1200.0 X210 Y1.5  Z0.2 E0.357

    G0 X48.0 E11.9 F6033.27
    G0 X48.0 Y12 E0.772 F1200.0
    G0 X45.0 E0.22 F1200.0
    G0 X35.0 Y6.0 E0.86 F1200.0

    ;=========== extruder cali extrusion ==================
    T1000
    M83
    
        
            M204 S5000
        
    
    G0 X35.000 Y6.000 Z0.300 F30000 E0
    G1 F1500.000 E0.800
    M106 S0 ; turn off fan
    G0 X185.000 E9.35441 F6033.27
    G0 X187 Z0
    G1 F1500.000 E-0.800
    G0 Z1
    G0 X180 Z0.3 F18000

    M900 L1000.0 M1.0
    M900 K0.040
    G0 X45.000 F30000
    G0 Y8.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
M73 P21 R22
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.020
    G0 X45.000 F30000
    G0 Y10.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
M73 P22 R22
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.000
    G0 X45.000 F30000
    G0 Y12.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
M73 P22 R21
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3

    G0 X45.000 F30000 ; move to start point

M623 ; end of "draw extrinsic para cali paint"


M1002 judge_flag extrude_cali_flag
M622 J0
    G0 X231 Y1.5 F30000
    G0 X18 E14.3 F6033.27
M623

M104 S140


;=========== laser and rgb calibration ===========
M400
M18 E
M500 R

M973 S3 P14

G1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
T1100
G1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
M400 P100
M960 S1 P1
M400 P100
M973 S6 P0; use auto exposure for horizontal laser by xcam
M960 S0 P0

G1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos
M960 S2 P1
M400 P100
M973 S6 P1; use auto exposure for vertical laser by xcam
M960 S0 P0

;=========== handeye calibration ======================
M1002 judge_flag extrude_cali_flag
M622 J1

    M973 S3 P1 ; camera start stream
    M400 P500
    M973 S1
    G0 F6000 X228.500 Y4.750 Z0.000
    M960 S0 P1
    M973 S1
    M400 P800
    M971 S6 P0
    M973 S2 P0
    M400 P500
    G0 Z0.000 F12000
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P200
    M971 S5 P1
    M973 S2 P1
    M400 P500
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P3
    G0 Z0.500 F12000
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P4
    M973 S2 P0
    M400 P500
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P500
    M971 S5 P2
    M963 S1
    M400 P1500
    M964
    T1100
    G1 Z3 F3000

    M400
    M500 ; save cali data

    M104 S220 ; rise nozzle temp now ,to reduce temp waiting time.

    T1100
    M400 P400
    M960 S0 P0
    G0 F30000.000 Y10.000 X65.000 Z0.000
    M400 P400
    M960 S1 P1
    M400 P50

    M969 S1 N3 A2000
    G0 F360.000 X181.000 Z0.000
    M980.3 A70.000 B94.1106 C5.000 D376.442 E5.000 F175.000 H1.000 I0.000 J0.020 K0.040
    M400 P100
    G0 F20000
    G0 Z1 ; rise nozzle up
    T1000 ; change to nozzle space
    G0 X45.000 Y4.000 F30000 ; move to test line pos
    M969 S0 ; turn off scanning
    M960 S0 P0


    G1 Z2 F20000
    T1000
    G0 X45.000 Y4.000 F30000 E0
    M109 S220
    G0 Z0.3
    G1 F1500.000 E3.600
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27

    ; see if extrude cali success, if not ,use default value
    M1002 judge_last_extrude_cali_success
    M622 J0
        M400
        M900 K0.02 M0.125481
    M623

    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F1508.32
    G1 X185.000 E0.31181 F6033.27
    G1 X190.000 E0.31181 F1508.32
    G1 X195.000 E0.31181 F6033.27
    G1 X200.000 E0.31181 F1508.32
    G1 X205.000 E0.31181 F6033.27
    G1 X210.000 E0.31181 F1508.32
    G1 X215.000 E0.31181 F6033.27
    G1 X220.000 E0.31181 F1508.32
    G1 X225.000 E0.31181 F6033.27
    M973 S4

M623

;========turn off light and wait extrude temperature =============
M1002 gcode_claim_action : 0
M973 S4 ; turn off scanner
M400 ; wait all motion done before implement the emprical L parameters
;M900 L500.0 ; Empirical parameters
M109 S220
M960 S1 P0 ; turn off laser
M960 S2 P0 ; turn off laser
M106 S0 ; turn off fan
M106 P2 S0 ; turn off big fan
M106 P3 S0 ; turn off chamber fan

M975 S1 ; turn on mech mode supression
G90
M83
T1000
;===== purge line to wipe the nozzle ============================
G1 E-0.8 F1800
G1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position
G1 E0.8 F1800
M109 S220
G1 Z0.2
G0 X239 E15 F6033.27
G0 Y12 E0.7 F1508.32
; MACHINE_START_GCODE_END
; filament start gcode

M142 P1 R35 S40
;VT0 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/32
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
M106 P2 S0
; OBJECT_ID: 15
G1 X72.25 Y114.88 F30000
M204 S6000
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
M73 P23 R21
G1 X72.25 Y114.554 E.01215
G1 X183.75 Y114.554 E4.15295
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X183.75 Y114.88 E.01215
G1 X72.31 Y114.88 E4.15072
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X72.25 Y114.554 E-.12599
G1 X73.918 Y114.554 E-.63401
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/32
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S255
M106 P2 S178
; open powerlost recovery
M1003 S1
M976 S1 P1 ; scan model before printing 2nd layer
M400 P100
G1 E.8
; OBJECT_ID: 15
G1 E-.8
M204 S10000
G1 X72.602 Y114.705 Z.6 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.598 Y114.705 E3.64877
G1 X182.998 Y114.705 E.01327
G1 F10986.246
G1 X183.398 Y114.705 E.01327
G1 F4471.324
G1 X183.398 Y114.948 E.00806
G1 F1920
G1 X183.398 Y115.328 E.01262
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X72.602 Y115.328 E3.6753
G1 F1920
G1 X72.602 Y114.948 E.01262
G1 F3742.486
G1 X72.602 Y114.765 E.00607
M204 S250
G1 X72.21 Y114.473 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F3806.689
M204 S5000
G1 X72.21 Y114.313 E.00493
G1 F2160
G1 X183.79 Y114.313 E3.42854
G1 F3806.689
G1 X183.79 Y114.473 E.00493
G1 F7199.529
G1 X183.79 Y114.961 E.015
G1 F1800
G1 X183.79 Y115.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y115.72 E.01294
G1 F600
G1 X72.21 Y115.72 E3.70131
G1 X72.21 Y115.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
M73 P25 R21
G1 X72.21 Y114.961 E.01134
G1 F6895.25
G1 X72.21 Y114.533 E.01315
M204 S10000
G1 X72.806 Y115.016 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.25925
G1 F15000
G1 X183.194 Y115.016 E1.94595
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X181.194 Y115.016 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/32
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z.8 I.004 J-1.217 P1  F30000
G1 X72.602 Y114.62 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.398 Y114.62 E3.6753
G1 X183.398 Y114.948 E.01087
G1 F14331.075
G1 X183.398 Y115.348 E.01327
G1 F6685.538
G1 X183.398 Y115.748 E.01327
G1 F1920
G1 X183.398 Y116.128 E.01262
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X72.602 Y116.128 E3.6753
G1 F1920
G1 X72.602 Y115.748 E.01262
G1 F6685.538
G1 X72.602 Y115.348 E.01327
G1 F14331.075
G1 X72.602 Y114.948 E.01327
G1 F15476.087
G1 X72.602 Y114.68 E.00888
M204 S250
G1 X72.21 Y114.272 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11993.036
M204 S5000
G1 X72.21 Y114.228 E.00135
G1 F11100
G1 X183.79 Y114.228 E3.42854
G1 F11993.036
G1 X183.79 Y114.272 E.00135
G1 F12000
G1 X183.79 Y114.672 E.01229
G1 X183.79 Y114.961 E.0089
G1 X183.79 Y115.361 E.01229
G1 F6459.938
G1 X183.79 Y115.761 E.01229
G1 F1800
G1 X183.79 Y116.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y116.52 E.01294
G1 F600
G1 X72.21 Y116.52 E3.70131
G1 X72.21 Y116.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y115.761 E.01134
G1 F6459.938
G1 X72.21 Y115.361 E.01229
G1 F12000
G1 X72.21 Y114.961 E.01229
G1 X72.21 Y114.332 E.01934
; WIPE_START
M204 S10000
G1 X72.21 Y114.228 E-.03945
G1 X74.106 Y114.228 E-.72055
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1 I-.921 J-.795 P1  F30000
G1 X72.766 Y115.78 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.44916
G1 F3000
G1 X183.065 Y115.78 E3.65127
G1 X183.065 Y115.374 E.01345
G1 X72.935 Y115.374 E3.64566
G1 X72.935 Y114.968 E.01345
G1 X183.234 Y114.968 E3.65127
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X181.234 Y114.968 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 4/32
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1 I.004 J-1.217 P1  F30000
M73 P26 R20
G1 X72.602 Y114.602 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.398 Y114.602 E3.6753
G1 X183.398 Y115.348 E.02473
G1 X183.398 Y115.748 E.01327
G1 F14331.075
G1 X183.398 Y116.148 E.01327
G1 F6685.538
G1 X183.398 Y116.548 E.01327
G1 F1920
G1 X183.398 Y116.928 E.01262
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X72.602 Y116.928 E3.6753
G1 F1920
G1 X72.602 Y116.548 E.01262
G1 F6685.538
G1 X72.602 Y116.148 E.01327
M73 P27 R20
G1 F14331.075
G1 X72.602 Y115.748 E.01327
G1 F15476.087
G1 X72.602 Y115.348 E.01327
G1 X72.602 Y114.662 E.02274
M204 S250
G1 X72.21 Y114.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X183.79 Y114.21 E3.42854
G1 X183.79 Y115.761 E.04766
G1 X183.79 Y116.161 E.01229
G1 F6459.938
G1 X183.79 Y116.561 E.01229
G1 F1800
G1 X183.79 Y116.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y117.32 E.01294
G1 F600
G1 X72.21 Y117.32 E3.70131
G1 X72.21 Y116.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y116.561 E.01134
G1 F6459.938
G1 X72.21 Y116.161 E.01229
G1 F12000
G1 X72.21 Y115.761 E.01229
G1 X72.21 Y114.27 E.04582
; WIPE_START
M204 S10000
M73 P28 R20
G1 X74.21 Y114.269 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X73.065 Y115.065 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56156
G1 F12147.155
G1 X182.875 Y115.065 E4.64086
G1 X183.234 Y115.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y115.652 E4.06688
G1 X72.935 Y116.104 E.01668
G1 X183.065 Y116.104 E4.06062
G1 X183.065 Y116.557 E.01668
G1 X72.766 Y116.557 E4.06688
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X74.766 Y116.557 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/32
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.2 I.816 J-.903 P1  F30000
G1 X72.602 Y114.602 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.398 Y114.602 E3.6753
G1 X183.398 Y116.148 E.05127
G1 X183.398 Y116.548 E.01327
G1 F14331.075
G1 X183.398 Y116.948 E.01327
G1 F6685.538
G1 X183.398 Y117.348 E.01327
G1 F1920
G1 X183.398 Y117.728 E.01262
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X72.602 Y117.728 E3.6753
G1 F1920
G1 X72.602 Y117.348 E.01262
G1 F6685.538
G1 X72.602 Y116.948 E.01327
G1 F14331.075
G1 X72.602 Y116.548 E.01327
G1 F15476.087
G1 X72.602 Y116.148 E.01327
G1 X72.602 Y114.662 E.04928
M204 S250
G1 X72.21 Y114.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
M73 P29 R20
G1 X183.79 Y114.21 E3.42854
G1 X183.79 Y116.561 E.07224
G1 X183.79 Y116.961 E.01229
G1 F6459.938
G1 X183.79 Y117.361 E.01229
G1 F1800
G1 X183.79 Y117.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y118.12 E.01294
G1 F600
G1 X72.21 Y118.12 E3.70131
G1 X72.21 Y117.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y117.361 E.01134
G1 F6459.938
G1 X72.21 Y116.961 E.01229
G1 F12000
G1 X72.21 Y116.561 E.01229
G1 X72.21 Y114.27 E.0704
; WIPE_START
M204 S10000
G1 X74.21 Y114.269 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X72.952 Y115.978 Z1.4 F30000
G1 Z1
M73 P29 R19
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y115.978 E3.04864
G1 X183.234 Y116.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y116.452 E4.06688
G1 X72.935 Y116.904 E.01668
G1 X183.065 Y116.904 E4.06062
G1 X183.065 Y117.357 E.01668
G1 X72.766 Y117.357 E4.06688
G1 X180.664 Y115.628 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
M73 P30 R19
G1 X179.036 Y115.628 E.05401
G1 X178.358 Y114.95 E.03181
G1 X177.429 Y114.95 E.0308
G1 X176.751 Y115.628 E.03181
G1 X171.36 Y115.628 E.17883
G1 X170.682 Y114.95 E.03181
G1 X169.753 Y114.95 E.0308
G1 X169.075 Y115.628 E.03181
G1 X163.684 Y115.628 E.17883
G1 X163.006 Y114.95 E.03181
G1 X162.078 Y114.95 E.0308
G1 X161.399 Y115.628 E.03181
G1 X156.008 Y115.628 E.17883
G1 X155.33 Y114.95 E.03181
G1 X154.402 Y114.95 E.0308
G1 X153.723 Y115.628 E.03181
G1 X148.332 Y115.628 E.17883
G1 X147.654 Y114.95 E.03181
G1 X146.726 Y114.95 E.0308
G1 X146.047 Y115.628 E.03181
G1 X140.656 Y115.628 E.17883
G1 X139.978 Y114.95 E.03181
G1 X139.05 Y114.95 E.0308
G1 X138.372 Y115.628 E.03181
G1 X132.98 Y115.628 E.17883
G1 X132.302 Y114.95 E.03181
G1 X131.374 Y114.95 E.0308
G1 X130.696 Y115.628 E.03181
G1 X125.304 Y115.628 E.17883
G1 X124.626 Y114.95 E.03181
G1 X123.698 Y114.95 E.0308
G1 X123.02 Y115.628 E.03181
M73 P31 R19
G1 X117.628 Y115.628 E.17883
G1 X116.95 Y114.95 E.03181
G1 X116.022 Y114.95 E.0308
G1 X115.344 Y115.628 E.03181
G1 X109.953 Y115.628 E.17883
G1 X109.274 Y114.95 E.03181
G1 X108.346 Y114.95 E.0308
G1 X107.668 Y115.628 E.03181
G1 X102.277 Y115.628 E.17883
G1 X101.598 Y114.95 E.03181
G1 X100.67 Y114.95 E.0308
G1 X99.992 Y115.628 E.03181
G1 X94.601 Y115.628 E.17883
G1 X93.922 Y114.95 E.03181
G1 X92.994 Y114.95 E.0308
G1 X92.316 Y115.628 E.03181
G1 X86.925 Y115.628 E.17883
G1 X86.247 Y114.95 E.03181
G1 X85.318 Y114.95 E.0308
G1 X84.64 Y115.628 E.03181
G1 X79.249 Y115.628 E.17883
G1 X78.571 Y114.95 E.03181
G1 X77.642 Y114.95 E.0308
G1 X76.964 Y115.628 E.03181
G1 X75.336 Y115.628 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X76.964 Y115.628 E-.61876
G1 X77.227 Y115.366 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 6/32
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.4 I.198 J-1.201 P1  F30000
G1 X72.602 Y114.602 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X183.398 Y114.602 E3.6753
G1 X183.398 Y116.948 E.0778
G1 X183.398 Y117.348 E.01327
G1 F14331.075
G1 X183.398 Y117.748 E.01327
G1 F6685.538
G1 X183.398 Y118.148 E.01327
M73 P32 R19
G1 F1920
G1 X183.398 Y118.528 E.01262
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.602 Y118.528 E.55715
G1 X166.602 Y118.398 E.00431
G1 F1080
G1 X159.398 Y118.398 E.23897
G1 F600
G1 X159.398 Y118.528 E.00431
G1 X152.602 Y118.528 E.22543
G1 X152.602 Y118.398 E.00431
G1 F1080
G1 X145.398 Y118.398 E.23897
G1 F600
G1 X145.398 Y118.528 E.00431
G1 X138.602 Y118.528 E.22543
G1 X138.602 Y118.398 E.00431
G1 F1080
G1 X131.398 Y118.398 E.23897
G1 F600
G1 X131.398 Y118.528 E.00431
G1 X124.602 Y118.528 E.22543
G1 X124.602 Y118.398 E.00431
G1 F1080
G1 X117.398 Y118.398 E.23897
G1 F600
G1 X117.398 Y118.528 E.00431
G1 X110.602 Y118.528 E.22543
G1 X110.602 Y118.398 E.00431
G1 F1080
G1 X103.398 Y118.398 E.23897
G1 F600
G1 X103.398 Y118.528 E.00431
G1 X96.602 Y118.528 E.22543
G1 X96.602 Y118.398 E.00431
G1 F1080
G1 X89.398 Y118.398 E.23897
G1 F600
G1 X89.398 Y118.528 E.00431
G1 X72.602 Y118.528 E.55715
G1 F1920
G1 X72.602 Y118.148 E.01262
G1 F6685.538
G1 X72.602 Y117.748 E.01327
G1 F14331.075
G1 X72.602 Y117.348 E.01327
G1 F15476.087
G1 X72.602 Y116.948 E.01327
G1 X72.602 Y114.662 E.07581
M204 S250
G1 X72.21 Y114.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X183.79 Y114.21 E3.42854
G1 X183.79 Y117.361 E.09682
G1 X183.79 Y117.761 E.01229
G1 F6459.938
G1 X183.79 Y118.161 E.01229
G1 F1800
G1 X183.79 Y118.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y118.92 E.01294
G1 F600
G1 X166.21 Y118.92 E.58316
G1 X166.21 Y118.79 E.00431
M73 P33 R19
G1 X159.79 Y118.79 E.21296
G1 X159.79 Y118.92 E.00431
G1 X152.21 Y118.92 E.25144
G1 X152.21 Y118.79 E.00431
G1 X145.79 Y118.79 E.21296
G1 X145.79 Y118.92 E.00431
G1 X138.21 Y118.92 E.25144
G1 X138.21 Y118.79 E.00431
G1 X131.79 Y118.79 E.21296
G1 X131.79 Y118.92 E.00431
G1 X124.21 Y118.92 E.25144
G1 X124.21 Y118.79 E.00431
G1 X117.79 Y118.79 E.21296
G1 X117.79 Y118.92 E.00431
G1 X110.21 Y118.92 E.25144
G1 X110.21 Y118.79 E.00431
G1 X103.79 Y118.79 E.21296
G1 X103.79 Y118.92 E.00431
G1 X96.21 Y118.92 E.25144
G1 X96.21 Y118.79 E.00431
G1 X89.79 Y118.79 E.21296
G1 X89.79 Y118.92 E.00431
G1 X72.21 Y118.92 E.58316
G1 X72.21 Y118.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y118.161 E.01134
G1 F6459.938
G1 X72.21 Y117.761 E.01229
M73 P33 R18
G1 F12000
G1 X72.21 Y117.361 E.01229
G1 X72.21 Y114.27 E.09498
; WIPE_START
M204 S10000
G1 X74.21 Y114.269 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X72.952 Y116.778 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X89.408 Y116.788 E.45594
G1 X95.233 Y117.215 F30000
; LINE_WIDTH: 0.447056
G1 F15000
G1 X90.784 Y117.211 E.14651
G1 X91.004 Y117.615 E.01516
G1 X95.034 Y117.615 E.13273
G1 X95.206 Y117.269 E.01272
G1 X96.692 Y116.78 F30000
; LINE_WIDTH: 0.417672
G1 F15000
G1 X95.868 Y116.821 E.02521
G1 X89.891 Y116.821 E.18251
G1 X89.505 Y116.797 E.01183
G1 X89.926 Y116.94 E.01359
G1 X90.358 Y117.286 E.01688
G1 X90.645 Y117.757 E.01687
G1 X90.686 Y118.006 E.0077
G1 X95.309 Y118.006 E.14115
G1 X95.493 Y117.532 E.01553
G1 X95.878 Y117.088 E.01794
G1 X96.322 Y116.833 E.01565
G1 X96.633 Y116.789 E.00959
G1 X96.692 Y116.78 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X103.408 Y116.788 E.18606
G1 X109.233 Y117.215 F30000
; LINE_WIDTH: 0.447056
G1 F15000
G1 X104.784 Y117.211 E.14651
G1 X105.004 Y117.615 E.01516
G1 X109.034 Y117.615 E.13273
G1 X109.206 Y117.269 E.01272
G1 X110.692 Y116.78 F30000
; LINE_WIDTH: 0.417672
G1 F15000
G1 X109.868 Y116.821 E.02521
G1 X103.891 Y116.821 E.18251
G1 X103.505 Y116.797 E.01183
G1 X103.926 Y116.94 E.01359
G1 X104.358 Y117.286 E.01688
G1 X104.645 Y117.757 E.01687
G1 X104.686 Y118.006 E.0077
G1 X109.309 Y118.006 E.14115
G1 X109.493 Y117.532 E.01553
G1 X109.878 Y117.088 E.01794
G1 X110.322 Y116.833 E.01565
G1 X110.633 Y116.789 E.00959
G1 X110.692 Y116.78 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X117.408 Y116.788 E.18606
G1 X123.034 Y117.615 F30000
; LINE_WIDTH: 0.447056
G1 F15000
G1 X123.233 Y117.215 E.0147
G1 X118.784 Y117.211 E.14651
G1 X119.004 Y117.615 E.01516
G1 X122.974 Y117.615 E.13076
G1 X123.309 Y118.006 F30000
; LINE_WIDTH: 0.417597
G1 F15000
G1 X123.493 Y117.532 E.01552
G1 X123.878 Y117.088 E.01794
G1 X124.322 Y116.833 E.01565
G1 X124.692 Y116.78 E.01142
G1 X123.868 Y116.821 E.02521
G1 X117.891 Y116.821 E.18248
G1 X117.505 Y116.797 E.01183
G1 X117.926 Y116.94 E.01359
G1 X118.358 Y117.286 E.01688
G1 X118.645 Y117.757 E.01687
G1 X118.686 Y118.006 E.0077
G1 X123.249 Y118.006 E.13929
G1 X124.692 Y116.78 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X131.408 Y116.788 E.18606
G1 X132.686 Y118.006 F30000
; LINE_WIDTH: 0.417597
M73 P34 R18
G1 F15000
G1 X137.309 Y118.006 E.14112
G1 X137.493 Y117.532 E.01552
G1 X137.878 Y117.088 E.01794
G1 X138.322 Y116.833 E.01565
G1 X138.692 Y116.78 E.01142
G1 X137.868 Y116.821 E.02521
G1 X131.891 Y116.821 E.18248
G1 X131.505 Y116.797 E.01183
G1 X131.926 Y116.94 E.01359
G1 X132.358 Y117.286 E.01688
G1 X132.645 Y117.757 E.01687
G1 X132.677 Y117.947 E.00587
G1 X133.004 Y117.615 F30000
; LINE_WIDTH: 0.44705
G1 F15000
G1 X137.034 Y117.615 E.13273
G1 X137.233 Y117.215 E.0147
G1 X132.784 Y117.211 E.14651
G1 X132.975 Y117.563 E.01318
G1 X138.692 Y116.78 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X145.408 Y116.788 E.18606
G1 X145.505 Y116.797 F30000
; LINE_WIDTH: 0.417662
G1 F15000
G1 X145.926 Y116.94 E.01359
G1 X146.358 Y117.286 E.01688
G1 X146.645 Y117.757 E.01687
G1 X146.686 Y118.006 E.0077
G1 X151.309 Y118.006 E.14114
G1 X151.493 Y117.532 E.01552
G1 X151.878 Y117.088 E.01794
G1 X152.322 Y116.833 E.01565
G1 X152.692 Y116.78 E.01142
G1 X151.868 Y116.821 E.02521
G1 X145.891 Y116.821 E.18251
G1 X145.564 Y116.8 E.01
G1 X146.784 Y117.211 F30000
; LINE_WIDTH: 0.44705
G1 F15000
G1 X147.004 Y117.615 E.01516
G1 X151.034 Y117.615 E.13273
G1 X151.233 Y117.215 E.0147
G1 X146.844 Y117.211 E.14453
G1 X152.692 Y116.78 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X159.408 Y116.788 E.18606
G1 X159.505 Y116.797 F30000
; LINE_WIDTH: 0.417662
G1 F15000
G1 X159.926 Y116.94 E.01359
G1 X160.358 Y117.286 E.01688
G1 X160.645 Y117.757 E.01687
G1 X160.686 Y118.006 E.0077
G1 X165.309 Y118.006 E.14114
G1 X165.493 Y117.532 E.01552
G1 X165.878 Y117.088 E.01794
G1 X166.322 Y116.833 E.01565
G1 X166.692 Y116.78 E.01142
G1 X165.868 Y116.821 E.02521
G1 X159.891 Y116.821 E.18251
G1 X159.564 Y116.8 E.01
G1 X160.784 Y117.211 F30000
; LINE_WIDTH: 0.44705
G1 F15000
G1 X161.004 Y117.615 E.01516
G1 X165.034 Y117.615 E.13273
G1 X165.233 Y117.215 E.0147
G1 X160.844 Y117.211 E.14453
G1 X166.692 Y116.78 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y116.778 E.45149
G1 X183.234 Y117.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.303 Y117.252 E.62427
G2 X165.851 Y117.671 I.653 J1.159 E.02295
G1 X165.827 Y117.705 E.00151
G1 X183.065 Y117.705 E.63557
G1 X183.065 Y118.157 E.01668
G1 X165.509 Y118.157 E.6473
G1 X160.007 Y117.252 F30000
G1 F3000
G1 X152.303 Y117.252 E.28403
G2 X151.851 Y117.671 I.653 J1.159 E.02295
G1 X151.827 Y117.705 E.00151
G1 X160.209 Y117.705 E.30905
G3 X160.329 Y118.065 I-.635 J.412 E.01415
G1 X159.065 Y118.065 E.04663
G1 X159.065 Y118.157 E.0034
G1 X151.509 Y118.157 E.27859
G1 X146.007 Y117.252 F30000
G1 F3000
G1 X138.303 Y117.252 E.28403
G2 X137.851 Y117.671 I.653 J1.159 E.02295
G1 X137.827 Y117.705 E.00151
G1 X146.209 Y117.705 E.30905
G3 X146.329 Y118.065 I-.635 J.412 E.01415
G1 X145.065 Y118.065 E.04663
G1 X145.065 Y118.157 E.0034
G1 X137.509 Y118.157 E.27859
G1 X132.007 Y117.252 F30000
G1 F3000
G1 X124.303 Y117.252 E.28403
G2 X123.851 Y117.671 I.653 J1.159 E.02295
G1 X123.827 Y117.705 E.00151
G1 X132.209 Y117.705 E.30905
G3 X132.329 Y118.065 I-.635 J.412 E.01415
G1 X131.065 Y118.065 E.04663
G1 X131.065 Y118.157 E.0034
G1 X123.509 Y118.157 E.27859
G1 X118.007 Y117.252 F30000
G1 F3000
G1 X110.303 Y117.252 E.28403
G2 X109.851 Y117.671 I.653 J1.159 E.02295
G1 X109.827 Y117.705 E.00151
G1 X118.209 Y117.705 E.30905
G3 X118.329 Y118.065 I-.634 J.412 E.01415
G1 X117.065 Y118.065 E.04663
G1 X117.065 Y118.157 E.0034
G1 X109.509 Y118.157 E.27859
G1 X104.007 Y117.252 F30000
G1 F3000
G1 X96.303 Y117.252 E.28403
G2 X95.851 Y117.671 I.653 J1.159 E.02295
G1 X95.827 Y117.705 E.00151
G1 X104.209 Y117.705 E.30905
G3 X104.329 Y118.065 I-.634 J.412 E.01415
G1 X103.065 Y118.065 E.04663
G1 X103.065 Y118.157 E.0034
G1 X95.509 Y118.157 E.27859
G1 X90.007 Y117.252 F30000
G1 F3000
G1 X72.935 Y117.252 E.62945
G1 X72.935 Y117.705 E.01668
G1 X90.209 Y117.705 E.63691
G3 X90.329 Y118.065 I-.634 J.412 E.01415
G1 X89.065 Y118.065 E.04663
G1 X89.065 Y118.157 E.0034
G1 X72.766 Y118.157 E.60098
G1 X74.536 Y116.428 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X76.164 Y116.428 E.05401
G1 X77.642 Y114.95 E.06934
G1 X78.571 Y114.95 E.0308
G1 X80.049 Y116.428 E.06934
G1 X83.84 Y116.428 E.12576
G1 X85.318 Y114.95 E.06934
G1 X86.247 Y114.95 E.0308
G1 X87.725 Y116.428 E.06934
G1 X91.516 Y116.428 E.12576
G1 X92.994 Y114.95 E.06934
G1 X93.922 Y114.95 E.0308
G1 X95.401 Y116.428 E.06934
G1 X99.192 Y116.428 E.12576
G1 X100.67 Y114.95 E.06934
G1 X101.598 Y114.95 E.0308
G1 X103.077 Y116.428 E.06934
G1 X106.868 Y116.428 E.12576
G1 X108.346 Y114.95 E.06934
G1 X109.274 Y114.95 E.0308
G1 X110.753 Y116.428 E.06934
G1 X114.544 Y116.428 E.12576
G1 X116.022 Y114.95 E.06934
G1 X116.95 Y114.95 E.0308
G1 X118.428 Y116.428 E.06934
G1 X122.22 Y116.428 E.12576
G1 X123.698 Y114.95 E.06934
G1 X124.626 Y114.95 E.0308
G1 X126.104 Y116.428 E.06934
G1 X129.896 Y116.428 E.12576
G1 X131.374 Y114.95 E.06934
G1 X132.302 Y114.95 E.0308
G1 X133.78 Y116.428 E.06934
G1 X137.572 Y116.428 E.12576
G1 X139.05 Y114.95 E.06934
G1 X139.978 Y114.95 E.0308
G1 X141.456 Y116.428 E.06934
G1 X145.247 Y116.428 E.12576
G1 X146.726 Y114.95 E.06934
G1 X147.654 Y114.95 E.0308
G1 X149.132 Y116.428 E.06934
G1 X152.923 Y116.428 E.12576
G1 X154.402 Y114.95 E.06934
G1 X155.33 Y114.95 E.0308
G1 X156.808 Y116.428 E.06934
G1 X160.599 Y116.428 E.12576
G1 X162.078 Y114.95 E.06934
G1 X163.006 Y114.95 E.0308
G1 X164.484 Y116.428 E.06934
G1 X168.275 Y116.428 E.12576
G1 X169.753 Y114.95 E.06934
G1 X170.682 Y114.95 E.0308
G1 X172.16 Y116.428 E.06934
G1 X175.951 Y116.428 E.12576
G1 X177.429 Y114.95 E.06934
G1 X178.358 Y114.95 E.0308
G1 X179.836 Y116.428 E.06934
G1 X181.464 Y116.428 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X179.836 Y116.428 E-.61876
G1 X179.573 Y116.166 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/32
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.6 I-.08 J-1.214 P1  F30000
G1 X131.398 Y119.328 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F600
G1 X124.602 Y119.328 E.22543
G1 F1920
G1 X124.602 Y118.948 E.01262
G1 F9207.83
G1 X124.602 Y118.398 E.01823
G1 F15476.087
G1 X124.202 Y118.398 E.01327
G1 X117.798 Y118.398 E.21244
G1 X117.398 Y118.398 E.01327
G1 F9207.83
G1 X117.398 Y118.948 E.01823
G1 F1920
G1 X117.398 Y119.328 E.01262
G1 F600
G1 X110.602 Y119.328 E.22543
G1 F1920
G1 X110.602 Y118.948 E.01262
G1 F9207.83
G1 X110.602 Y118.398 E.01823
G1 F15476.087
G1 X110.202 Y118.398 E.01327
G1 X103.798 Y118.398 E.21244
G1 X103.398 Y118.398 E.01327
G1 F9207.83
G1 X103.398 Y118.948 E.01823
G1 F1920
G1 X103.398 Y119.328 E.01262
G1 F600
G1 X96.602 Y119.328 E.22543
G1 F1920
G1 X96.602 Y118.948 E.01262
G1 F9207.83
G1 X96.602 Y118.398 E.01823
G1 F15476.087
G1 X96.202 Y118.398 E.01327
G1 X89.798 Y118.398 E.21244
G1 X89.398 Y118.398 E.01327
G1 F9207.83
G1 X89.398 Y118.948 E.01823
G1 F1920
G1 X89.398 Y119.328 E.01262
G1 F600
G1 X72.602 Y119.328 E.55715
G1 F1920
G1 X72.602 Y118.948 E.01262
G1 F6685.538
G1 X72.602 Y118.548 E.01327
G1 F14331.075
G1 X72.602 Y118.148 E.01327
G1 F15476.087
G1 X72.602 Y117.748 E.01327
G1 X72.602 Y114.602 E.10434
G1 X183.398 Y114.602 E3.6753
G1 X183.398 Y117.748 E.10434
G1 X183.398 Y118.148 E.01327
G1 F14331.075
G1 X183.398 Y118.548 E.01327
G1 F6685.538
G1 X183.398 Y118.948 E.01327
G1 F1920
G1 X183.398 Y119.328 E.01262
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.602 Y119.328 E.55715
G1 F1920
G1 X166.602 Y118.948 E.01262
G1 F9207.83
G1 X166.602 Y118.398 E.01823
G1 F15476.087
G1 X166.202 Y118.398 E.01327
G1 X159.798 Y118.398 E.21244
G1 X159.398 Y118.398 E.01327
G1 F9207.83
G1 X159.398 Y118.948 E.01823
G1 F1920
G1 X159.398 Y119.328 E.01262
G1 F600
G1 X152.602 Y119.328 E.22543
G1 F1920
G1 X152.602 Y118.948 E.01262
G1 F9207.83
G1 X152.602 Y118.398 E.01823
G1 F15476.087
G1 X152.202 Y118.398 E.01327
G1 X145.798 Y118.398 E.21244
G1 X145.398 Y118.398 E.01327
G1 F9207.83
G1 X145.398 Y118.948 E.01823
G1 F1920
G1 X145.398 Y119.328 E.01262
G1 F600
G1 X138.602 Y119.328 E.22543
G1 F1920
G1 X138.602 Y118.948 E.01262
G1 F9207.83
G1 X138.602 Y118.398 E.01823
G1 F15476.087
G1 X138.202 Y118.398 E.01327
G1 X131.798 Y118.398 E.21244
G1 X131.398 Y118.398 E.01327
G1 F9207.83
G1 X131.398 Y118.948 E.01823
G1 F1920
G1 X131.398 Y119.268 E.01063
M204 S250
G1 X131.79 Y118.961 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
M204 S5000
G1 X131.79 Y119.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y119.72 E.01294
G1 X124.21 Y119.72 E.25144
G1 X124.21 Y119.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y118.961 E.01134
G1 F3440.026
G1 X124.21 Y118.79 E.00526
G1 F9331.38
G1 X123.81 Y118.79 E.01229
G1 F12000
G1 X123.41 Y118.79 E.01229
G1 X118.59 Y118.79 E.1481
G1 X118.19 Y118.79 E.01229
G1 F9331.38
G1 X117.79 Y118.79 E.01229
G1 F3440.026
G1 X117.79 Y118.961 E.00526
G1 F1800
G1 X117.79 Y119.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
M73 P35 R18
G1 F600
G1 X117.79 Y119.72 E.01294
G1 X110.21 Y119.72 E.25144
G1 X110.21 Y119.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y118.961 E.01134
G1 F3440.026
G1 X110.21 Y118.79 E.00526
G1 F9331.38
G1 X109.81 Y118.79 E.01229
G1 F12000
G1 X109.41 Y118.79 E.01229
G1 X104.59 Y118.79 E.1481
G1 X104.19 Y118.79 E.01229
G1 F9331.38
G1 X103.79 Y118.79 E.01229
G1 F3440.026
G1 X103.79 Y118.961 E.00526
G1 F1800
G1 X103.79 Y119.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y119.72 E.01294
G1 X96.21 Y119.72 E.25144
G1 X96.21 Y119.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y118.961 E.01134
G1 F3440.026
G1 X96.21 Y118.79 E.00526
G1 F9331.38
G1 X95.81 Y118.79 E.01229
G1 F12000
G1 X95.41 Y118.79 E.01229
G1 X90.59 Y118.79 E.1481
G1 X90.19 Y118.79 E.01229
G1 F9331.38
G1 X89.79 Y118.79 E.01229
G1 F3440.026
G1 X89.79 Y118.961 E.00526
G1 F1800
G1 X89.79 Y119.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y119.72 E.01294
G1 X72.21 Y119.72 E.58316
G1 X72.21 Y119.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y118.961 E.01134
G1 F6459.938
G1 X72.21 Y118.561 E.01229
G1 F12000
G1 X72.21 Y118.161 E.01229
G1 X72.21 Y114.21 E.1214
G1 X183.79 Y114.21 E3.42854
G1 X183.79 Y118.161 E.1214
G1 X183.79 Y118.561 E.01229
G1 F6459.938
G1 X183.79 Y118.961 E.01229
G1 F1800
G1 X183.79 Y119.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y119.72 E.01294
G1 F600
G1 X166.21 Y119.72 E.58316
G1 X166.21 Y119.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y118.961 E.01134
G1 F3440.026
G1 X166.21 Y118.79 E.00526
G1 F9331.38
G1 X165.81 Y118.79 E.01229
G1 F12000
G1 X165.41 Y118.79 E.01229
G1 X160.59 Y118.79 E.1481
G1 X160.19 Y118.79 E.01229
G1 F9331.38
G1 X159.79 Y118.79 E.01229
G1 F3440.026
G1 X159.79 Y118.961 E.00526
G1 F1800
G1 X159.79 Y119.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y119.72 E.01294
G1 X152.21 Y119.72 E.25144
G1 X152.21 Y119.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y118.961 E.01134
G1 F3440.026
G1 X152.21 Y118.79 E.00526
G1 F9331.38
G1 X151.81 Y118.79 E.01229
G1 F12000
G1 X151.41 Y118.79 E.01229
G1 X146.59 Y118.79 E.1481
G1 X146.19 Y118.79 E.01229
G1 F9331.38
G1 X145.79 Y118.79 E.01229
G1 F3440.026
G1 X145.79 Y118.961 E.00526
G1 F1800
G1 X145.79 Y119.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y119.72 E.01294
G1 X138.21 Y119.72 E.25144
G1 X138.21 Y119.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y118.961 E.01134
G1 F3440.026
G1 X138.21 Y118.79 E.00526
G1 F9331.38
G1 X137.81 Y118.79 E.01229
G1 F12000
G1 X137.41 Y118.79 E.01229
G1 X131.79 Y118.79 E.17269
G1 X131.79 Y118.901 E.00341
M204 S10000
G1 X131.667 Y118.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.573 Y118.052 E.26156
G1 X124.56 Y118.065 E.00066
G1 X124.935 Y118.065 E.01382
G1 X124.935 Y118.505 E.01622
G1 X131.065 Y118.505 E.22601
G1 X131.065 Y118.957 E.01668
G1 X124.766 Y118.957 E.23226
; WIPE_START
G1 X126.766 Y118.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.12 J-1.211 P1  F30000
G1 X117.667 Y118.052 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F3000
G1 X110.573 Y118.052 E.26156
G1 X110.56 Y118.065 E.00066
G1 X110.935 Y118.065 E.01382
G1 X110.935 Y118.505 E.01622
G1 X117.065 Y118.505 E.22601
G1 X117.065 Y118.957 E.01668
G1 X110.766 Y118.957 E.23226
; WIPE_START
G1 X112.766 Y118.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.12 J-1.211 P1  F30000
G1 X103.667 Y118.052 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F3000
G1 X96.573 Y118.052 E.26156
G1 X96.56 Y118.065 E.00066
G1 X96.935 Y118.065 E.01382
G1 X96.935 Y118.505 E.01622
G1 X103.065 Y118.505 E.22601
G1 X103.065 Y118.957 E.01668
G1 X96.766 Y118.957 E.23226
; WIPE_START
G1 X98.766 Y118.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.12 J-1.211 P1  F30000
G1 X89.667 Y118.052 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F3000
G1 X72.935 Y118.052 E.61692
G1 X72.935 Y118.505 E.01668
G1 X89.065 Y118.505 E.59472
G1 X89.065 Y118.957 E.01668
G1 X72.766 Y118.957 E.60098
G1 X72.952 Y117.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X89.193 Y117.578 E.44998
G1 X96.721 Y117.579 F30000
; LINE_WIDTH: 0.422297
G1 F15000
G1 X96.036 Y117.623 E.02122
G1 X89.964 Y117.623 E.18774
G1 X89.433 Y117.608 E.0164
G1 X89.576 Y117.673 E.00485
G1 X89.847 Y117.937 E.01172
G1 X89.874 Y118.004 E.00222
G1 X96.115 Y118.004 E.19294
G1 X96.426 Y117.674 E.01399
G1 X96.664 Y117.598 E.00775
G1 X96.721 Y117.579 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X103.193 Y117.578 E.17931
G1 X110.721 Y117.579 F30000
; LINE_WIDTH: 0.422297
G1 F15000
G1 X110.036 Y117.623 E.02122
G1 X103.964 Y117.623 E.18774
G1 X103.433 Y117.608 E.0164
G1 X103.576 Y117.673 E.00485
G1 X103.847 Y117.937 E.01172
G1 X103.874 Y118.004 E.00222
G1 X110.115 Y118.004 E.19294
G1 X110.426 Y117.674 E.01399
G1 X110.664 Y117.598 E.00775
G1 X110.721 Y117.579 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X117.193 Y117.578 E.17931
G1 X124.115 Y118.004 F30000
; LINE_WIDTH: 0.422198
G1 F15000
G1 X124.426 Y117.674 E.01399
G1 X124.721 Y117.579 E.0096
G1 X124.036 Y117.623 E.02121
G1 X117.964 Y117.623 E.18769
G1 X117.433 Y117.608 E.0164
G1 X117.576 Y117.673 E.00485
G1 X117.847 Y117.937 E.01172
G1 X117.874 Y118.004 E.00222
G1 X124.055 Y118.004 E.19103
G1 X124.721 Y117.579 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X131.193 Y117.578 E.17931
G1 X131.874 Y118.004 F30000
; LINE_WIDTH: 0.422198
G1 F15000
G1 X138.115 Y118.004 E.19289
G1 X138.426 Y117.674 E.01399
G1 X138.721 Y117.579 E.0096
G1 X138.036 Y117.623 E.02121
G1 X131.964 Y117.623 E.18769
G1 X131.433 Y117.608 E.0164
G1 X131.576 Y117.673 E.00485
G1 X131.852 Y117.948 E.01205
G1 X138.721 Y117.579 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X145.193 Y117.578 E.17931
G1 X145.433 Y117.608 F30000
; LINE_WIDTH: 0.422226
G1 F15000
G1 X145.576 Y117.673 E.00485
G1 X145.847 Y117.937 E.01172
G1 X145.874 Y118.004 E.00222
G1 X152.115 Y118.004 E.1929
G1 X152.426 Y117.674 E.01399
G1 X152.721 Y117.579 E.0096
G1 X152.036 Y117.623 E.02121
G1 X145.493 Y117.61 E.20225
G1 X152.721 Y117.579 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X159.193 Y117.578 E.17931
G1 X159.433 Y117.608 F30000
; LINE_WIDTH: 0.422226
G1 F15000
G1 X159.576 Y117.673 E.00485
G1 X159.847 Y117.937 E.01172
G1 X159.874 Y118.004 E.00222
G1 X166.115 Y118.004 E.1929
G1 X166.426 Y117.674 E.01399
G1 X166.721 Y117.579 E.0096
G1 X166.036 Y117.623 E.02121
G1 X159.493 Y117.61 E.20225
G1 X166.721 Y117.579 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y117.578 E.45069
G1 X183.234 Y118.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.573 Y118.052 E.61433
G1 X166.56 Y118.065 E.00066
G1 X166.935 Y118.065 E.01382
G1 X166.935 Y118.505 E.01622
M73 P36 R18
G1 X183.065 Y118.505 E.59472
G1 X183.065 Y118.957 E.01668
G1 X166.766 Y118.957 E.60098
; WIPE_START
G1 X168.766 Y118.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.12 J-1.211 P1  F30000
G1 X159.667 Y118.052 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F3000
G1 X152.573 Y118.052 E.26156
G1 X152.56 Y118.065 E.00066
G1 X152.935 Y118.065 E.01382
G1 X152.935 Y118.505 E.01622
G1 X159.065 Y118.505 E.22601
G1 X159.065 Y118.957 E.01668
G1 X152.766 Y118.957 E.23226
; WIPE_START
G1 X154.766 Y118.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.12 J-1.211 P1  F30000
G1 X145.667 Y118.052 Z1.8
G1 Z1.4
G1 E.8 F1800
G1 F3000
G1 X138.573 Y118.052 E.26156
G1 X138.56 Y118.065 E.00066
G1 X138.935 Y118.065 E.01382
G1 X138.935 Y118.505 E.01622
G1 X145.065 Y118.505 E.22601
G1 X145.065 Y118.957 E.01668
G1 X138.766 Y118.957 E.23226
; WIPE_START
G1 X140.766 Y118.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.103 J1.213 P1  F30000
G1 X183.05 Y115.378 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.05 Y117.006 E.05401
G1 X182.827 Y117.228 E.01043
G1 X180.636 Y117.228 E.07269
G1 X178.358 Y114.95 E.10687
G1 X177.429 Y114.95 E.0308
G1 X175.151 Y117.228 E.10687
G1 X172.96 Y117.228 E.07269
G1 X170.682 Y114.95 E.10687
G1 X169.753 Y114.95 E.0308
G1 X167.475 Y117.228 E.10687
G1 X165.284 Y117.228 E.07269
G1 X163.006 Y114.95 E.10687
G1 X162.078 Y114.95 E.0308
G1 X159.799 Y117.228 E.10687
G1 X157.608 Y117.228 E.07269
G1 X155.33 Y114.95 E.10687
G1 X154.402 Y114.95 E.0308
G1 X152.124 Y117.228 E.10687
G1 X149.932 Y117.228 E.07269
G1 X147.654 Y114.95 E.10687
G1 X146.726 Y114.95 E.0308
G1 X144.448 Y117.228 E.10687
G1 X142.256 Y117.228 E.07269
G1 X139.978 Y114.95 E.10687
G1 X139.05 Y114.95 E.0308
G1 X136.772 Y117.228 E.10687
G1 X134.58 Y117.228 E.07269
G1 X132.302 Y114.95 E.10687
G1 X131.374 Y114.95 E.0308
G1 X129.096 Y117.228 E.10687
G1 X126.904 Y117.228 E.07269
G1 X124.626 Y114.95 E.10687
G1 X123.698 Y114.95 E.0308
G1 X121.42 Y117.228 E.10687
G1 X119.228 Y117.228 E.07269
G1 X116.95 Y114.95 E.10687
G1 X116.022 Y114.95 E.0308
G1 X113.744 Y117.228 E.10687
G1 X111.552 Y117.228 E.07269
G1 X109.274 Y114.95 E.10687
G1 X108.346 Y114.95 E.0308
G1 X106.068 Y117.228 E.10687
G1 X103.876 Y117.228 E.07269
G1 X101.598 Y114.95 E.10687
G1 X100.67 Y114.95 E.0308
G1 X98.392 Y117.228 E.10687
G1 X96.201 Y117.228 E.07269
G1 X93.922 Y114.95 E.10687
G1 X92.994 Y114.95 E.0308
G1 X90.716 Y117.228 E.10687
G1 X88.525 Y117.228 E.07269
G1 X86.247 Y114.95 E.10687
G1 X85.318 Y114.95 E.0308
G1 X83.04 Y117.228 E.10687
G1 X80.849 Y117.228 E.07269
G1 X78.571 Y114.95 E.10687
G1 X77.642 Y114.95 E.0308
G1 X75.364 Y117.228 E.10687
G1 X73.173 Y117.228 E.07269
G1 X72.95 Y117.006 E.01043
G1 X72.95 Y115.378 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X72.95 Y117.006 E-.61876
G1 X73.173 Y117.228 E-.11947
G1 X73.23 Y117.228 E-.02177
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/32
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.8 I-.024 J1.217 P1  F30000
G1 X131.398 Y118.398 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X131.398 Y118.948 E.01823
G1 F14331.075
G1 X131.398 Y119.348 E.01327
G1 F6685.538
G1 X131.398 Y119.748 E.01327
G1 F1920
G1 X131.398 Y120.128 E.01262
G1 F600
G1 X124.602 Y120.128 E.22543
G1 F1920
G1 X124.602 Y119.748 E.01262
G1 F6685.538
G1 X124.602 Y119.348 E.01327
G1 F14331.075
G1 X124.602 Y118.948 E.01327
G1 F15476.087
G1 X124.602 Y118.398 E.01823
G1 X117.398 Y118.398 E.23897
G1 X117.398 Y118.948 E.01823
G1 F14331.075
G1 X117.398 Y119.348 E.01327
G1 F6685.538
G1 X117.398 Y119.748 E.01327
G1 F1920
G1 X117.398 Y120.128 E.01262
G1 F600
G1 X110.602 Y120.128 E.22543
G1 F1920
G1 X110.602 Y119.748 E.01262
G1 F6685.538
G1 X110.602 Y119.348 E.01327
G1 F14331.075
G1 X110.602 Y118.948 E.01327
G1 F15476.087
G1 X110.602 Y118.398 E.01823
G1 X103.398 Y118.398 E.23897
G1 X103.398 Y118.948 E.01823
G1 F14331.075
G1 X103.398 Y119.348 E.01327
G1 F6685.538
G1 X103.398 Y119.748 E.01327
G1 F1920
G1 X103.398 Y120.128 E.01262
G1 F600
G1 X96.602 Y120.128 E.22543
G1 F1920
G1 X96.602 Y119.748 E.01262
G1 F6685.538
G1 X96.602 Y119.348 E.01327
G1 F14331.075
G1 X96.602 Y118.948 E.01327
G1 F15476.087
G1 X96.602 Y118.398 E.01823
G1 X89.398 Y118.398 E.23897
G1 X89.398 Y118.948 E.01823
G1 F14331.075
G1 X89.398 Y119.348 E.01327
G1 F6685.538
G1 X89.398 Y119.748 E.01327
G1 F1920
G1 X89.398 Y120.128 E.01262
G1 F600
G1 X72.602 Y120.128 E.55715
G1 F1920
G1 X72.602 Y119.748 E.01262
G1 F6685.538
G1 X72.602 Y119.348 E.01327
G1 F14331.075
G1 X72.602 Y118.948 E.01327
G1 F15476.087
G1 X72.602 Y118.548 E.01327
G1 X72.602 Y114.602 E.13088
G1 X183.398 Y114.602 E3.6753
G1 X183.398 Y118.548 E.13088
G1 X183.398 Y118.948 E.01327
G1 F14331.075
G1 X183.398 Y119.348 E.01327
G1 F6685.538
G1 X183.398 Y119.748 E.01327
G1 F1920
G1 X183.398 Y120.128 E.01262
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.602 Y120.128 E.55715
G1 F1920
G1 X166.602 Y119.748 E.01262
G1 F6685.538
G1 X166.602 Y119.348 E.01327
G1 F14331.075
G1 X166.602 Y118.948 E.01327
G1 F15476.087
G1 X166.602 Y118.398 E.01823
G1 X159.398 Y118.398 E.23897
G1 X159.398 Y118.948 E.01823
G1 F14331.075
G1 X159.398 Y119.348 E.01327
G1 F6685.538
G1 X159.398 Y119.748 E.01327
G1 F1920
G1 X159.398 Y120.128 E.01262
G1 F600
G1 X152.602 Y120.128 E.22543
G1 F1920
G1 X152.602 Y119.748 E.01262
G1 F6685.538
G1 X152.602 Y119.348 E.01327
G1 F14331.075
G1 X152.602 Y118.948 E.01327
G1 F15476.087
G1 X152.602 Y118.398 E.01823
G1 X145.398 Y118.398 E.23897
G1 X145.398 Y118.948 E.01823
G1 F14331.075
G1 X145.398 Y119.348 E.01327
G1 F6685.538
G1 X145.398 Y119.748 E.01327
G1 F1920
G1 X145.398 Y120.128 E.01262
G1 F600
G1 X138.602 Y120.128 E.22543
G1 F1920
G1 X138.602 Y119.748 E.01262
G1 F6685.538
G1 X138.602 Y119.348 E.01327
G1 F14331.075
G1 X138.602 Y118.948 E.01327
G1 F15476.087
G1 X138.602 Y118.398 E.01823
G1 X131.458 Y118.398 E.23698
M204 S250
G1 X131.79 Y118.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y119.361 E.01755
G1 F6459.938
G1 X131.79 Y119.761 E.01229
G1 F1800
G1 X131.79 Y120.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y120.52 E.01294
G1 X124.21 Y120.52 E.25144
G1 X124.21 Y120.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y119.761 E.01134
G1 F6459.938
G1 X124.21 Y119.361 E.01229
G1 F12000
G1 X124.21 Y118.79 E.01755
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y119.361 E.01755
G1 F6459.938
G1 X117.79 Y119.761 E.01229
G1 F1800
G1 X117.79 Y120.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y120.52 E.01294
G1 X110.21 Y120.52 E.25144
G1 X110.21 Y120.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y119.761 E.01134
G1 F6459.938
G1 X110.21 Y119.361 E.01229
G1 F12000
M73 P36 R17
G1 X110.21 Y118.79 E.01755
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y119.361 E.01755
G1 F6459.938
G1 X103.79 Y119.761 E.01229
G1 F1800
G1 X103.79 Y120.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y120.52 E.01294
G1 X96.21 Y120.52 E.25144
G1 X96.21 Y120.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y119.761 E.01134
G1 F6459.938
G1 X96.21 Y119.361 E.01229
G1 F12000
G1 X96.21 Y118.79 E.01755
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y119.361 E.01755
G1 F6459.938
G1 X89.79 Y119.761 E.01229
G1 F1800
G1 X89.79 Y120.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y120.52 E.01294
G1 X72.21 Y120.52 E.58316
G1 X72.21 Y120.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y119.761 E.01134
G1 F6459.938
G1 X72.21 Y119.361 E.01229
G1 F12000
G1 X72.21 Y118.961 E.01229
G1 X72.21 Y114.21 E.14599
G1 X183.79 Y114.21 E3.42854
G1 X183.79 Y118.961 E.14599
G1 X183.79 Y119.361 E.01229
G1 F6459.938
G1 X183.79 Y119.761 E.01229
G1 F1800
G1 X183.79 Y120.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y120.52 E.01294
G1 F600
G1 X166.21 Y120.52 E.58316
G1 X166.21 Y120.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y119.761 E.01134
G1 F6459.938
G1 X166.21 Y119.361 E.01229
G1 F12000
G1 X166.21 Y118.79 E.01755
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y119.361 E.01755
G1 F6459.938
G1 X159.79 Y119.761 E.01229
G1 F1800
G1 X159.79 Y120.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y120.52 E.01294
G1 X152.21 Y120.52 E.25144
G1 X152.21 Y120.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y119.761 E.01134
G1 F6459.938
G1 X152.21 Y119.361 E.01229
G1 F12000
G1 X152.21 Y118.79 E.01755
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y119.361 E.01755
G1 F6459.938
G1 X145.79 Y119.761 E.01229
G1 F1800
G1 X145.79 Y120.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y120.52 E.01294
G1 X138.21 Y120.52 E.25144
G1 X138.21 Y120.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y119.761 E.01134
G1 F6459.938
G1 X138.21 Y119.361 E.01229
G1 F12000
G1 X138.21 Y118.79 E.01755
G1 X131.85 Y118.79 E.19542
M204 S10000
G1 X131.234 Y118.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y118.852 E.23226
G1 X124.935 Y119.305 E.01668
G1 X131.065 Y119.305 E.22601
G1 X131.065 Y119.757 E.01668
G1 X124.766 Y119.757 E.23226
; WIPE_START
G1 X126.766 Y119.757 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I.508 J-1.106 P1  F30000
G1 X123.018 Y118.035 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.384688
G1 F15000
M73 P37 R17
G1 X124.806 Y118.035 E.04979
G1 X124.937 Y118.063 E.00375
G1 X124.985 Y118.345 E.00798
G1 X125.124 Y118.378 E.00398
G1 X130.876 Y118.378 E.16019
G1 X131.015 Y118.345 E.00398
G1 X131.063 Y118.063 E.00798
G1 X131.194 Y118.035 E.00375
G1 X134.881 Y118.035 E.10268
G1 X135.676 Y118.035 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X136.532 Y118.035 E.02371
G1 X138.004 Y118.035 F30000
G1 F15000
G1 X138.53 Y118.035 E.01458
G1 X138.845 Y118.133 E.00913
G1 X139.037 Y118.361 E.00827
G1 X139.124 Y118.374 E.00244
G1 X144.988 Y118.378 E.16248
G1 X145.234 Y118.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y118.852 E.23226
G1 X138.935 Y119.305 E.01668
G1 X145.065 Y119.305 E.22601
G1 X145.065 Y119.757 E.01668
G1 X138.766 Y119.757 E.23226
G1 X145.803 Y118.035 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X151.677 Y118.035 E.16276
G1 X152.952 Y118.378 F30000
; LINE_WIDTH: 0.385085
G1 F15000
G1 X158.876 Y118.378 E.16518
G1 X159.015 Y118.345 E.00399
G1 X159.063 Y118.063 E.00799
G1 X159.415 Y118.039 E.00984
G1 X159.234 Y118.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y118.852 E.23226
G1 X152.935 Y119.305 E.01668
G1 X159.065 Y119.305 E.22601
G1 X159.065 Y119.757 E.01668
G1 X152.766 Y119.757 E.23226
; WIPE_START
G1 X154.766 Y119.757 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I.306 J1.178 P1  F30000
G1 X161.398 Y118.035 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38374
G1 F15000
G1 X165.966 Y118.035 E.12689
G1 X166.189 Y117.98 E.00638
G1 X166.381 Y118.035 E.00553
G1 X166.937 Y118.063 E.01548
G1 X166.985 Y118.345 E.00795
G1 X167.124 Y118.378 E.00397
G1 X182.988 Y118.378 E.44059
G1 X183.234 Y118.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y118.852 E.60098
G1 X166.935 Y119.305 E.01668
G1 X183.065 Y119.305 E.59472
G1 X183.065 Y119.757 E.01668
G1 X166.766 Y119.757 E.60098
G1 X181.792 Y116.635 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.673 Y116.635 E.02921
G1 X182.673 Y117.383 E.02481
G1 X182.027 Y118.028 E.03027
G1 X181.436 Y118.028 E.01962
G1 X180.043 Y116.635 E.06535
G1 X175.744 Y116.635 E.1426
G1 X174.351 Y118.028 E.06535
G1 X173.76 Y118.028 E.01962
G1 X172.367 Y116.635 E.06535
G1 X168.068 Y116.635 E.1426
G1 X167.031 Y117.673 E.04865
G1 X165.728 Y117.673 E.04323
G1 X164.691 Y116.635 E.04865
G1 X160.392 Y116.635 E.1426
G1 X159.355 Y117.673 E.04865
G1 X158.673 Y117.673 E.02265
G1 X158.673 Y118.028 E.0118
G1 X158.408 Y118.028 E.00877
G1 X157.015 Y116.635 E.06535
G1 X152.716 Y116.635 E.1426
G1 X151.679 Y117.673 E.04865
G1 X150.376 Y117.673 E.04323
G1 X149.339 Y116.635 E.04865
G1 X145.041 Y116.635 E.1426
G1 X143.648 Y118.028 E.06535
G1 X143.056 Y118.028 E.01962
G1 X141.663 Y116.635 E.06535
G1 X137.365 Y116.635 E.1426
G1 X136.327 Y117.673 E.04865
G1 X135.024 Y117.673 E.04323
G1 X133.987 Y116.635 E.04865
G1 X129.689 Y116.635 E.1426
G1 X128.296 Y118.028 E.06535
G1 X127.704 Y118.028 E.01962
G1 X126.311 Y116.635 E.06535
G1 X122.013 Y116.635 E.1426
G1 X120.976 Y117.673 E.04865
G1 X119.673 Y117.673 E.04323
G1 X118.635 Y116.635 E.04865
G1 X114.337 Y116.635 E.1426
G1 X112.944 Y118.028 E.06535
G1 X112.352 Y118.028 E.01962
G1 X110.959 Y116.635 E.06535
G1 X106.661 Y116.635 E.1426
G1 X105.624 Y117.673 E.04865
G1 X104.321 Y117.673 E.04322
G1 X103.284 Y116.635 E.04865
G1 X98.985 Y116.635 E.1426
G1 X97.592 Y118.028 E.06535
G1 X97.327 Y118.028 E.00877
G1 X97.327 Y117.673 E.0118
G1 X96.645 Y117.673 E.02265
G1 X95.608 Y116.635 E.04865
G1 X91.309 Y116.635 E.1426
G1 X90.272 Y117.673 E.04865
G1 X88.969 Y117.673 E.04322
G1 X87.932 Y116.635 E.04865
G1 X83.633 Y116.635 E.1426
G1 X82.24 Y118.028 E.06534
G1 X81.649 Y118.028 E.01962
G1 X80.256 Y116.635 E.06535
G1 X75.957 Y116.635 E.1426
G1 X74.564 Y118.028 E.06535
G1 X73.973 Y118.028 E.01962
G1 X73.327 Y117.383 E.03027
G1 X73.327 Y116.635 E.02481
G1 X74.208 Y116.635 E.02921
G1 X75.184 Y115.78 F30000
G1 F15476.087
G1 X76.812 Y115.78 E.05401
G1 X77.161 Y115.432 E.01634
G1 X79.052 Y115.432 E.06274
G1 X79.4 Y115.78 E.01634
G1 X84.488 Y115.78 E.16878
G1 X84.837 Y115.432 E.01634
G1 X86.728 Y115.432 E.06274
G1 X87.076 Y115.78 E.01634
G1 X92.164 Y115.78 E.16878
G1 X92.513 Y115.432 E.01634
G1 X94.404 Y115.432 E.06274
G1 X94.752 Y115.78 E.01634
G1 X99.84 Y115.78 E.16878
G1 X100.189 Y115.432 E.01634
G1 X102.08 Y115.432 E.06274
G1 X102.428 Y115.78 E.01634
G1 X107.516 Y115.78 E.16878
G1 X107.864 Y115.432 E.01634
G1 X109.756 Y115.432 E.06274
G1 X110.104 Y115.78 E.01634
G1 X115.192 Y115.78 E.16878
G1 X115.54 Y115.432 E.01634
G1 X117.432 Y115.432 E.06274
G1 X117.78 Y115.78 E.01634
G1 X122.868 Y115.78 E.16878
G1 X123.216 Y115.432 E.01634
G1 X125.108 Y115.432 E.06274
G1 X125.456 Y115.78 E.01634
G1 X130.544 Y115.78 E.16878
G1 X130.892 Y115.432 E.01634
G1 X132.784 Y115.432 E.06274
G1 X133.132 Y115.78 E.01634
G1 X138.22 Y115.78 E.16878
G1 X138.568 Y115.432 E.01634
G1 X140.46 Y115.432 E.06274
G1 X140.808 Y115.78 E.01634
G1 X145.896 Y115.78 E.16878
G1 X146.244 Y115.432 E.01634
G1 X148.136 Y115.432 E.06274
G1 X148.484 Y115.78 E.01634
G1 X153.572 Y115.78 E.16878
G1 X153.92 Y115.432 E.01634
G1 X155.811 Y115.432 E.06274
G1 X156.16 Y115.78 E.01634
G1 X161.248 Y115.78 E.16878
G1 X161.596 Y115.432 E.01634
G1 X163.487 Y115.432 E.06274
G1 X163.836 Y115.78 E.01634
G1 X168.924 Y115.78 E.16878
G1 X169.272 Y115.432 E.01634
G1 X171.163 Y115.432 E.06274
G1 X171.512 Y115.78 E.01634
G1 X176.6 Y115.78 E.16878
G1 X176.948 Y115.432 E.01634
G1 X178.839 Y115.432 E.06274
G1 X179.188 Y115.78 E.01634
G1 X180.816 Y115.78 E.05401
; WIPE_START
G1 X179.188 Y115.78 E-.61876
G1 X178.925 Y115.517 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X171.304 Y115.929 Z2 F30000
G1 X117.234 Y118.852 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y118.852 E.23226
G1 X110.935 Y119.305 E.01668
G1 X117.065 Y119.305 E.22601
G1 X117.065 Y119.757 E.01668
G1 X110.766 Y119.757 E.23226
; WIPE_START
G1 X112.766 Y119.757 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I.373 J-1.158 P1  F30000
G1 X107.423 Y118.035 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.384469
G1 F15000
G1 X110.806 Y118.035 E.09415
G1 X110.937 Y118.063 E.00375
G1 X110.985 Y118.345 E.00797
G1 X111.124 Y118.378 E.00398
G1 X116.876 Y118.378 E.16009
G1 X117.015 Y118.345 E.00398
G1 X117.063 Y118.063 E.00797
G1 X117.194 Y118.035 E.00375
G1 X121.035 Y118.035 E.10689
; WIPE_START
G1 X119.035 Y118.035 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X111.413 Y118.429 Z2 F30000
G1 X103.234 Y118.852 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y118.852 E.23226
G1 X96.935 Y119.305 E.01668
G1 X103.065 Y119.305 E.22601
G1 X103.065 Y119.757 E.01668
G1 X96.766 Y119.757 E.23226
G1 X96.952 Y118.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.384157
G1 F15000
G1 X102.876 Y118.378 E.16473
G1 X103.015 Y118.345 E.00398
G1 X103.063 Y118.063 E.00796
G1 X103.194 Y118.035 E.00374
G1 X105.535 Y118.035 E.06508
G1 X92.434 Y118.035 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X96.501 Y118.035 E.1127
; WIPE_START
G1 X94.501 Y118.035 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.234 Y118.852 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y118.852 E.60098
G1 X72.935 Y119.305 E.01668
G1 X89.065 Y119.305 E.59472
G1 X89.065 Y119.757 E.01668
G1 X72.766 Y119.757 E.60098
G1 X72.952 Y118.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.383537
G1 F15000
G1 X88.876 Y118.378 E.44199
G1 X89.015 Y118.345 E.00397
G1 X89.063 Y118.063 E.00795
G1 X89.194 Y118.035 E.00374
G1 X90.4 Y118.035 E.03347
G1 X72.965 Y117.523 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X72.965 Y117.432 E.00251
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X72.965 Y116.432 E.02771
G1 X73.044 Y116.208 E.00658
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.51912
;_EXTRUDE_SET_SPEED
G1 X72.965 Y115.984 E.00922
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.38292
;_EXTRUDE_SET_SPEED
G1 X72.965 Y115.228 E.02093
G1 X73.028 Y115.028 E.00582
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.465541
;_EXTRUDE_SET_SPEED
G1 X182.876 Y115.017 E3.78298
G1 X182.972 Y115.028 E.00333
G1 X183.035 Y115.228 E.00723
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.38292
;_EXTRUDE_SET_SPEED
G1 X183.035 Y115.984 E.02093
G1 X182.956 Y116.208 E.00658
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.491281
;_EXTRUDE_SET_SPEED
G1 X73.104 Y116.208 E4.01354
; Slow Down End
G1 X182.956 Y116.208 F30000
; LINE_WIDTH: 0.49642
G1 F12000
G1 X182.983 Y116.282 E.00293
; LINE_WIDTH: 0.45102
G1 X183.009 Y116.357 E.00263
; LINE_WIDTH: 0.384586
G1 X183.035 Y116.432 E.00221
G1 X183.035 Y117.432 E.02784
; LINE_WIDTH: 0.40562
G1 X183.035 Y117.47 E.00113
; LINE_WIDTH: 0.45102
G1 X183.035 Y117.508 E.00127
; LINE_WIDTH: 0.49642
G1 X183.035 Y117.546 E.00141
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X183.035 Y117.508 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 9/32
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2 I-1.216 J.046 P1  F30000
G1 X183.79 Y137.334 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F2841.688
M204 S5000
G1 X183.79 Y137.366 E.00101
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F2520
G1 X183.79 Y137.633 E.0082
G1 F840
G1 X72.21 Y137.633 E3.42854
G1 F2520
G1 X72.21 Y137.366 E.0082
G1 F2678.429
G1 X72.21 Y137.334 E.00101
G1 F1800
G1 X72.21 Y136.965 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y136.886 E.00263
G1 X183.79 Y136.886 E3.70131
G1 X183.79 Y136.965 E.00263
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y137.274 E.00949
M204 S10000
G1 X183.594 Y137.259 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.3987
G1 F15000
G1 X72.406 Y137.259 E3.22351
; WIPE_START
G1 X74.406 Y137.259 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I.382 J1.155 P1  F30000
G1 X131.398 Y118.398 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y119.348 E.0315
G1 X131.398 Y119.748 E.01327
G1 F14331.075
G1 X131.398 Y120.148 E.01327
G1 F6685.538
G1 X131.398 Y120.548 E.01327
G1 F1920
G1 X131.398 Y120.928 E.01262
G1 F600
G1 X124.602 Y120.928 E.22543
G1 F1920
G1 X124.602 Y120.548 E.01262
G1 F6685.538
G1 X124.602 Y120.148 E.01327
G1 F14331.075
G1 X124.602 Y119.748 E.01327
G1 F15476.087
G1 X124.602 Y119.348 E.01327
G1 X124.602 Y118.398 E.0315
G1 X117.398 Y118.398 E.23897
G1 X117.398 Y119.348 E.0315
G1 X117.398 Y119.748 E.01327
G1 F14331.075
G1 X117.398 Y120.148 E.01327
G1 F6685.538
G1 X117.398 Y120.548 E.01327
G1 F1920
G1 X117.398 Y120.928 E.01262
G1 F600
G1 X110.602 Y120.928 E.22543
G1 F1920
G1 X110.602 Y120.548 E.01262
G1 F6685.538
G1 X110.602 Y120.148 E.01327
G1 F14331.075
G1 X110.602 Y119.748 E.01327
G1 F15476.087
G1 X110.602 Y119.348 E.01327
G1 X110.602 Y118.398 E.0315
G1 X103.398 Y118.398 E.23897
G1 X103.398 Y119.348 E.0315
G1 X103.398 Y119.748 E.01327
G1 F14331.075
G1 X103.398 Y120.148 E.01327
G1 F6685.538
G1 X103.398 Y120.548 E.01327
G1 F1920
G1 X103.398 Y120.928 E.01262
M73 P38 R17
G1 F600
G1 X96.602 Y120.928 E.22543
G1 F1920
G1 X96.602 Y120.548 E.01262
G1 F6685.538
G1 X96.602 Y120.148 E.01327
G1 F14331.075
G1 X96.602 Y119.748 E.01327
G1 F15476.087
G1 X96.602 Y119.348 E.01327
G1 X96.602 Y118.398 E.0315
G1 X89.398 Y118.398 E.23897
G1 X89.398 Y119.348 E.0315
G1 X89.398 Y119.748 E.01327
G1 F14331.075
G1 X89.398 Y120.148 E.01327
G1 F6685.538
G1 X89.398 Y120.548 E.01327
G1 F1920
G1 X89.398 Y120.928 E.01262
G1 F600
G1 X72.602 Y120.928 E.55715
G1 F1920
G1 X72.602 Y120.548 E.01262
G1 F6685.538
G1 X72.602 Y120.148 E.01327
G1 F14331.075
G1 X72.602 Y119.748 E.01327
G1 F15476.087
G1 X72.602 Y119.348 E.01327
G1 X72.602 Y114.602 E.15742
G1 X183.398 Y114.602 E3.6753
G1 X183.398 Y119.348 E.15742
G1 X183.398 Y119.748 E.01327
G1 F14331.075
G1 X183.398 Y120.148 E.01327
M73 P39 R17
G1 F6685.538
G1 X183.398 Y120.548 E.01327
G1 F1920
G1 X183.398 Y120.928 E.01262
G1 F600
G1 X166.602 Y120.928 E.55715
G1 F1920
G1 X166.602 Y120.548 E.01262
G1 F6685.538
G1 X166.602 Y120.148 E.01327
G1 F14331.075
G1 X166.602 Y119.748 E.01327
G1 F15476.087
G1 X166.602 Y119.348 E.01327
G1 X166.602 Y118.398 E.0315
G1 X159.398 Y118.398 E.23897
G1 X159.398 Y119.348 E.0315
G1 X159.398 Y119.748 E.01327
G1 F14331.075
G1 X159.398 Y120.148 E.01327
G1 F6685.538
G1 X159.398 Y120.548 E.01327
G1 F1920
G1 X159.398 Y120.928 E.01262
G1 F600
G1 X152.602 Y120.928 E.22543
G1 F1920
G1 X152.602 Y120.548 E.01262
G1 F6685.538
G1 X152.602 Y120.148 E.01327
G1 F14331.075
G1 X152.602 Y119.748 E.01327
G1 F15476.087
G1 X152.602 Y119.348 E.01327
G1 X152.602 Y118.398 E.0315
G1 X145.398 Y118.398 E.23897
G1 X145.398 Y119.348 E.0315
G1 X145.398 Y119.748 E.01327
G1 F14331.075
G1 X145.398 Y120.148 E.01327
G1 F6685.538
G1 X145.398 Y120.548 E.01327
G1 F1920
G1 X145.398 Y120.928 E.01262
G1 F600
G1 X138.602 Y120.928 E.22543
G1 F1920
G1 X138.602 Y120.548 E.01262
G1 F6685.538
G1 X138.602 Y120.148 E.01327
G1 F14331.075
G1 X138.602 Y119.748 E.01327
G1 F15476.087
G1 X138.602 Y119.348 E.01327
G1 X138.602 Y118.398 E.0315
G1 X131.458 Y118.398 E.23698
M204 S250
G1 X131.79 Y118.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y119.761 E.02984
G1 X131.79 Y120.161 E.01229
G1 F6459.938
G1 X131.79 Y120.561 E.01229
G1 F1800
G1 X131.79 Y120.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y121.32 E.01294
G1 X124.21 Y121.32 E.25144
G1 X124.21 Y120.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y120.561 E.01134
G1 F6459.938
G1 X124.21 Y120.161 E.01229
G1 F12000
G1 X124.21 Y119.761 E.01229
G1 X124.21 Y118.79 E.02984
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y119.761 E.02984
G1 X117.79 Y120.161 E.01229
G1 F6459.938
G1 X117.79 Y120.561 E.01229
G1 F1800
G1 X117.79 Y120.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y121.32 E.01294
G1 X110.21 Y121.32 E.25144
G1 X110.21 Y120.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y120.561 E.01134
G1 F6459.938
G1 X110.21 Y120.161 E.01229
G1 F12000
G1 X110.21 Y119.761 E.01229
G1 X110.21 Y118.79 E.02984
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y119.761 E.02984
G1 X103.79 Y120.161 E.01229
G1 F6459.938
G1 X103.79 Y120.561 E.01229
G1 F1800
G1 X103.79 Y120.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y121.32 E.01294
G1 X96.21 Y121.32 E.25144
G1 X96.21 Y120.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y120.561 E.01134
G1 F6459.938
G1 X96.21 Y120.161 E.01229
G1 F12000
G1 X96.21 Y119.761 E.01229
G1 X96.21 Y118.79 E.02984
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y119.761 E.02984
G1 X89.79 Y120.161 E.01229
G1 F6459.938
G1 X89.79 Y120.561 E.01229
G1 F1800
G1 X89.79 Y120.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y121.32 E.01294
G1 X72.21 Y121.32 E.58316
G1 X72.21 Y120.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y120.561 E.01134
G1 F6459.938
G1 X72.21 Y120.161 E.01229
G1 F12000
G1 X72.21 Y119.761 E.01229
G1 X72.21 Y114.21 E.17057
G1 X183.79 Y114.21 E3.42854
G1 X183.79 Y119.761 E.17057
G1 X183.79 Y120.161 E.01229
G1 F6459.938
G1 X183.79 Y120.561 E.01229
G1 F1800
G1 X183.79 Y120.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y121.32 E.01294
G1 F600
G1 X166.21 Y121.32 E.58316
G1 X166.21 Y120.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y120.561 E.01134
G1 F6459.938
G1 X166.21 Y120.161 E.01229
G1 F12000
G1 X166.21 Y119.761 E.01229
G1 X166.21 Y118.79 E.02984
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y119.761 E.02984
G1 X159.79 Y120.161 E.01229
G1 F6459.938
G1 X159.79 Y120.561 E.01229
G1 F1800
G1 X159.79 Y120.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y121.32 E.01294
G1 X152.21 Y121.32 E.25144
G1 X152.21 Y120.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y120.561 E.01134
G1 F6459.938
G1 X152.21 Y120.161 E.01229
G1 F12000
G1 X152.21 Y119.761 E.01229
G1 X152.21 Y118.79 E.02984
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y119.761 E.02984
G1 X145.79 Y120.161 E.01229
G1 F6459.938
G1 X145.79 Y120.561 E.01229
G1 F1800
G1 X145.79 Y120.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y121.32 E.01294
G1 X138.21 Y121.32 E.25144
G1 X138.21 Y120.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y120.561 E.01134
M73 P40 R17
G1 F6459.938
G1 X138.21 Y120.161 E.01229
G1 F12000
G1 X138.21 Y119.761 E.01229
G1 X138.21 Y118.79 E.02984
G1 X131.85 Y118.79 E.19542
; WIPE_START
M204 S10000
G1 X131.79 Y119.761 E-.3697
G1 X131.79 Y120.161 E-.152
G1 X131.79 Y120.561 E-.152
G1 X131.79 Y120.788 E-.08631
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I1.093 J-.535 P1  F30000
G1 X131.234 Y119.652 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y119.652 E.23225
G1 X124.935 Y120.104 E.01668
G1 X131.065 Y120.104 E.226
G1 X131.065 Y120.557 E.01668
G1 X124.766 Y120.557 E.23225
M73 P40 R16
G1 X124.952 Y119.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y119.178 E.16725
G1 X128.504 Y118.828 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X128.245 Y118.569 E.01219
G1 X125.2 Y118.885 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40112
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X124.769 Y118.292 E.03774
; WIPE_START
G1 X125.2 Y118.885 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I-.117 J-1.211 P1  F30000
G1 X117.234 Y119.652 Z2.2
G1 Z1.8
G1 E.8 F1800
; LINE_WIDTH: 0.4954
; LAYER_HEIGHT: 0.2
G1 F3000
G1 X110.935 Y119.652 E.23225
G1 X110.935 Y120.104 E.01668
G1 X117.065 Y120.104 E.226
G1 X117.065 Y120.557 E.01668
G1 X110.766 Y120.557 E.23225
G1 X110.952 Y119.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y119.178 E.16724
G1 X113.152 Y118.828 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X112.896 Y118.572 E.01203
; WIPE_START
G1 X113.152 Y118.828 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X105.546 Y119.46 Z2.2 F30000
G1 X103.234 Y119.652 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y119.652 E.23225
G1 X96.935 Y120.104 E.01668
G1 X103.065 Y120.104 E.226
G1 X103.065 Y120.557 E.01668
G1 X96.766 Y120.557 E.23225
G1 X96.952 Y119.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y119.178 E.16724
G1 X97.597 Y118.828 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X96.95 Y118.828 E.02145
G1 X96.95 Y118.67 E.00526
G1 X97.255 Y118.366 E.01427
G3 X97.801 Y118.828 I-.524 J1.172 E.02406
G1 X99.429 Y118.828 E.05401
; WIPE_START
G1 X97.801 Y118.828 E-.61876
G1 X97.538 Y118.566 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X89.97 Y119.556 Z2.2 F30000
G1 X89.234 Y119.652 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y119.652 E.60097
G1 X72.935 Y120.104 E.01668
G1 X89.065 Y120.104 E.59471
G1 X89.065 Y120.557 E.01668
G1 X72.766 Y120.557 E.60097
G1 X72.952 Y119.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y119.178 E.4443
G1 X83.019 Y118.471 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X83.488 Y118.828 E.01955
G1 X82.449 Y118.828 E.03446
G3 X82.298 Y118.518 I.112 J-.246 E.01241
G2 X82.806 Y118.309 I.101 J-.477 E.01935
G1 X83.019 Y118.471 E.00887
G1 X72.95 Y118.014 F30000
G1 F15476.087
G1 X72.95 Y118.828 E.02702
G1 X73.764 Y118.828 E.02699
G1 X74.118 Y118.475 E.01659
G2 X74.49 Y118.546 I.227 J-.176 E.01374
G1 X74.773 Y118.828 E.01326
G1 X76.401 Y118.828 E.05401
G1 X72.769 Y116.561 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40112
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X73.42 Y117.457 E.05698
G1 X73.522 Y117.457 E.00527
G1 X74.364 Y118.123 E.05528
G1 X74.458 Y118.118 E.00484
G1 X72.972 Y116.073 E.13019
G1 X72.972 Y115.305 E.03952
G1 X74.889 Y117.944 E.16795
G1 X75.212 Y117.621 E.02352
G1 X73.287 Y114.972 E.16862
G1 X73.845 Y114.972 E.02871
G1 X75.65 Y117.457 E.15816
G1 X76.208 Y117.457 E.02871
G1 X74.402 Y114.972 E.15816
G1 X74.96 Y114.972 E.02871
G1 X77.656 Y118.682 E.23614
G1 X78.213 Y118.682 E.02871
G1 X75.517 Y114.972 E.23614
G1 X76.075 Y114.972 E.02871
G1 X78.771 Y118.682 E.23614
G1 X79.329 Y118.682 E.02871
G1 X76.633 Y114.972 E.23614
G1 X77.19 Y114.972 E.02871
G1 X79.886 Y118.682 E.23614
G1 X80.444 Y118.682 E.02871
G1 X77.748 Y114.972 E.23614
G1 X78.306 Y114.972 E.02871
G1 X81.001 Y118.682 E.23614
G1 X81.559 Y118.682 E.02871
G1 X78.863 Y114.972 E.23614
G1 X79.421 Y114.972 E.02871
G1 X81.849 Y118.314 E.21269
G1 X81.835 Y118.169 E.00747
G1 X82.245 Y118.092 E.02148
G1 X79.978 Y114.972 E.19856
G1 X80.536 Y114.972 E.02871
G1 X82.641 Y117.868 E.18435
G1 X82.768 Y117.741 E.00927
G1 X83.525 Y118.318 E.049
G1 X81.094 Y114.972 E.21296
G1 X81.651 Y114.972 E.02871
G1 X84.347 Y118.682 E.23614
G1 X84.905 Y118.682 E.02871
G1 X82.209 Y114.972 E.23614
G1 X82.766 Y114.972 E.02871
G1 X85.462 Y118.682 E.23614
G1 X86.02 Y118.682 E.02871
G1 X83.324 Y114.972 E.23614
G1 X83.882 Y114.972 E.02871
G1 X86.578 Y118.682 E.23614
G1 X87.135 Y118.682 E.02871
G1 X84.439 Y114.972 E.23614
G1 X84.997 Y114.972 E.02871
G1 X87.693 Y118.682 E.23614
G1 X88.25 Y118.682 E.02871
G1 X85.555 Y114.972 E.23614
G1 X86.112 Y114.972 E.02871
G1 X88.808 Y118.682 E.23614
G1 X89.028 Y118.682 E.01134
G1 X89.028 Y118.218 E.0239
G1 X86.67 Y114.972 E.2066
G1 X87.227 Y114.972 E.02871
G1 X89.448 Y118.028 E.19453
G1 X90.006 Y118.028 E.02871
G1 X87.785 Y114.972 E.19453
G1 X88.343 Y114.972 E.02871
G1 X90.408 Y117.815 E.18095
G1 X90.411 Y117.774 E.0021
G1 X90.715 Y117.47 E.02216
G1 X88.9 Y114.972 E.15899
G1 X89.458 Y114.972 E.02871
G1 X91.263 Y117.457 E.15816
G1 X91.821 Y117.457 E.02871
G1 X90.015 Y114.972 E.15816
G1 X90.573 Y114.972 E.02871
G1 X92.794 Y118.028 E.19453
G1 X93.351 Y118.028 E.02871
G1 X91.131 Y114.972 E.19453
G1 X91.688 Y114.972 E.02871
G1 X93.909 Y118.028 E.19453
G1 X94.467 Y118.028 E.02871
G1 X92.246 Y114.972 E.19453
G1 X92.804 Y114.972 E.02871
G1 X95.024 Y118.028 E.19453
G1 X95.582 Y118.028 E.02871
G1 X93.361 Y114.972 E.19453
G1 X93.919 Y114.972 E.02871
G1 X96.14 Y118.028 E.19453
G1 X96.496 Y118.028 E.01834
G1 X96.504 Y117.762 E.0137
G1 X94.476 Y114.972 E.1776
G1 X95.034 Y114.972 E.02871
G1 X97.071 Y117.776 E.17846
G1 X97.652 Y118.095 E.0341
G1 X97.8 Y118.012 E.00877
G1 X95.592 Y114.972 E.19348
G1 X96.149 Y114.972 E.02871
G1 X98.144 Y117.717 E.17472
G1 X98.404 Y117.457 E.01896
G1 X98.512 Y117.457 E.00557
G1 X96.707 Y114.972 E.15816
G1 X97.264 Y114.972 E.02871
G1 X99.26 Y117.718 E.17479
G1 X100.268 Y118.682 E.07181
G1 X100.518 Y118.682 E.01288
G1 X97.822 Y114.972 E.23614
G1 X98.38 Y114.972 E.02871
G1 X101.076 Y118.682 E.23614
G1 X101.633 Y118.682 E.02871
G1 X98.937 Y114.972 E.23614
G1 X99.495 Y114.972 E.02871
G1 X102.191 Y118.682 E.23614
G1 X102.748 Y118.682 E.02871
G1 X100.053 Y114.972 E.23614
G1 X100.61 Y114.972 E.02871
G1 X103.028 Y118.3 E.21182
G1 X103.028 Y118.028 E.01399
G1 X103.389 Y118.028 E.01855
G1 X101.168 Y114.972 E.19453
G1 X101.725 Y114.972 E.02871
G1 X103.946 Y118.028 E.19453
G1 X104.504 Y118.028 E.02871
G1 X102.283 Y114.972 E.19453
G1 X102.841 Y114.972 E.02871
G1 X105.061 Y118.028 E.19453
G1 X105.509 Y118.028 E.02303
G1 X105.573 Y117.964 E.00465
G1 X103.398 Y114.972 E.19046
G1 X103.956 Y114.972 E.02871
G1 X105.896 Y117.641 E.16991
G1 X106.08 Y117.457 E.01344
G1 X106.319 Y117.457 E.0123
G1 X104.513 Y114.972 E.15816
G1 X105.071 Y114.972 E.02871
G1 X106.951 Y117.559 E.16465
G1 X107.518 Y118.028 E.0379
G1 X107.849 Y118.028 E.01707
G1 X105.629 Y114.972 E.19453
G1 X106.186 Y114.972 E.02871
G1 X108.407 Y118.028 E.19453
G1 X108.965 Y118.028 E.02871
G1 X106.744 Y114.972 E.19453
G1 X107.302 Y114.972 E.02871
G1 X109.522 Y118.028 E.19453
G1 X110.08 Y118.028 E.02871
G1 X107.859 Y114.972 E.19453
G1 X108.417 Y114.972 E.02871
G1 X111.042 Y118.585 E.22996
G1 X111.195 Y118.682 E.00934
G1 X111.67 Y118.682 E.02445
G1 X108.974 Y114.972 E.23614
G1 X109.532 Y114.972 E.02871
G1 X112.228 Y118.682 E.23614
G1 X112.476 Y118.682 E.01278
G1 X112.43 Y118.193 E.02528
G1 X110.09 Y114.972 E.20503
G1 X110.647 Y114.972 E.02871
G1 X112.93 Y118.113 E.19995
G1 X113.109 Y118.104 E.00923
G1 X113.324 Y117.889 E.01568
G1 X111.205 Y114.972 E.18565
G1 X111.762 Y114.972 E.02871
G1 X113.647 Y117.566 E.16509
G1 X113.756 Y117.457 E.00794
G1 X114.126 Y117.457 E.01902
G1 X112.32 Y114.972 E.15816
G1 X112.878 Y114.972 E.02871
G1 X114.895 Y117.749 E.17674
G1 X115.851 Y118.682 E.06877
G1 X116.131 Y118.682 E.01444
G1 X113.435 Y114.972 E.23614
G1 X113.993 Y114.972 E.02871
G1 X116.689 Y118.682 E.23614
G1 X117.028 Y118.682 E.01748
G1 X117.028 Y118.382 E.01545
G1 X114.551 Y114.972 E.21704
G1 X115.108 Y114.972 E.02871
G1 X117.329 Y118.028 E.19453
G1 X117.887 Y118.028 E.02871
G1 X115.666 Y114.972 E.19453
G1 X116.223 Y114.972 E.02871
G1 X118.444 Y118.028 E.19453
G1 X119.002 Y118.028 E.02871
G1 X116.781 Y114.972 E.19453
G1 X117.339 Y114.972 E.02871
G1 X119.559 Y118.028 E.19453
G1 X120.117 Y118.028 E.02871
G1 X117.896 Y114.972 E.19453
G1 X118.454 Y114.972 E.02871
G1 X120.675 Y118.028 E.19453
G1 X121.029 Y118.028 E.01826
G1 X121.057 Y117.831 E.01024
G1 X121.076 Y117.813 E.00134
G1 X119.011 Y114.972 E.18083
G1 X119.569 Y114.972 E.02871
G1 X121.399 Y117.49 E.16028
G1 X121.432 Y117.457 E.00243
G1 X121.932 Y117.457 E.02575
G1 X120.127 Y114.972 E.15816
G1 X120.684 Y114.972 E.02871
G1 X122.56 Y117.554 E.16433
G1 X123.111 Y118.028 E.03741
G1 X123.463 Y118.028 E.01813
G1 X121.242 Y114.972 E.19453
G1 X121.8 Y114.972 E.02871
G1 X124.02 Y118.028 E.19453
G1 X124.578 Y118.028 E.02871
M73 P41 R16
G1 X122.357 Y114.972 E.19453
G1 X122.915 Y114.972 E.02871
G1 X125.611 Y118.682 E.23614
G1 X126.168 Y118.682 E.02871
G1 X123.472 Y114.972 E.23614
G1 X124.03 Y114.972 E.02871
G1 X126.726 Y118.682 E.23614
G1 X127.107 Y118.682 E.01965
G1 X127.22 Y118.595 E.00734
G1 X124.588 Y114.972 E.23057
G1 X125.145 Y114.972 E.02871
G1 X127.576 Y118.318 E.21294
G1 X127.932 Y118.04 E.02324
G1 X125.703 Y114.972 E.1953
G1 X126.26 Y114.972 E.02871
G1 X128.482 Y118.03 E.19461
G1 X128.565 Y118 E.00451
G1 X128.827 Y117.737 E.01914
G1 X126.818 Y114.972 E.17601
G1 X127.376 Y114.972 E.02871
G1 X129.923 Y118.478 E.22313
G1 X130.184 Y118.682 E.01706
G1 X130.629 Y118.682 E.02294
G1 X127.933 Y114.972 E.23614
G1 X128.491 Y114.972 E.02871
G1 X130.712 Y118.028 E.19453
G1 X131.269 Y118.028 E.02871
G1 X129.049 Y114.972 E.19453
G1 X129.606 Y114.972 E.02871
G1 X131.827 Y118.028 E.19453
G1 X132.384 Y118.028 E.02871
G1 X130.164 Y114.972 E.19453
G1 X130.721 Y114.972 E.02871
G1 X132.942 Y118.028 E.19453
G1 X133.5 Y118.028 E.02871
G1 X131.279 Y114.972 E.19453
G1 X131.837 Y114.972 E.02871
G1 X134.057 Y118.028 E.19453
G1 X134.615 Y118.028 E.02871
G1 X132.394 Y114.972 E.19453
G1 X132.952 Y114.972 E.02871
G1 X134.888 Y117.637 E.16961
G1 X134.895 Y117.43 E.01067
G1 X135.679 Y117.958 E.04867
G1 X133.509 Y114.972 E.19002
G1 X134.067 Y114.972 E.02871
G1 X136.288 Y118.028 E.19453
G1 X136.526 Y118.028 E.01226
G1 X136.525 Y117.587 E.02272
G1 X134.625 Y114.972 E.16644
G1 X135.182 Y114.972 E.02871
G1 X136.988 Y117.457 E.15816
G1 X137.393 Y117.457 E.02087
G1 X137.762 Y117.755 E.02444
G1 X135.74 Y114.972 E.17715
G1 X136.298 Y114.972 E.02871
G1 X138.518 Y118.028 E.19453
G1 X138.972 Y118.028 E.02335
G1 X138.972 Y118.307 E.01436
G1 X139.541 Y118.668 E.03468
G1 X136.855 Y114.972 E.23524
G1 X137.413 Y114.972 E.02871
G1 X140.109 Y118.682 E.23614
G1 X140.666 Y118.682 E.02871
G1 X137.97 Y114.972 E.23614
G1 X138.528 Y114.972 E.02871
G1 X141.224 Y118.682 E.23614
G1 X141.781 Y118.682 E.02871
G1 X139.086 Y114.972 E.23614
G1 X139.643 Y114.972 E.02871
G1 X142.339 Y118.682 E.23614
G1 X142.897 Y118.682 E.02871
G1 X140.201 Y114.972 E.23614
G1 X140.758 Y114.972 E.02871
G1 X142.946 Y117.983 E.19165
G1 X143.578 Y118.085 E.03296
G1 X141.316 Y114.972 E.19815
G1 X141.874 Y114.972 E.02871
G1 X144.007 Y117.908 E.18687
G2 X144.331 Y117.586 I-1.474 J-1.806 E.02354
G1 X142.431 Y114.972 E.16638
G1 X142.989 Y114.972 E.02871
G1 X144.794 Y117.457 E.15816
G1 X145.207 Y117.457 E.02126
G1 X145.57 Y117.757 E.02425
G1 X143.547 Y114.972 E.17727
G1 X144.104 Y114.972 E.02871
G1 X146.325 Y118.028 E.19453
G1 X146.882 Y118.028 E.02871
G1 X144.662 Y114.972 E.19453
G1 X145.219 Y114.972 E.02871
G1 X147.44 Y118.028 E.19453
G1 X147.998 Y118.028 E.02871
G1 X145.777 Y114.972 E.19453
G1 X146.335 Y114.972 E.02871
G1 X148.555 Y118.028 E.19453
G1 X149.113 Y118.028 E.02871
G1 X146.892 Y114.972 E.19453
G1 X147.45 Y114.972 E.02871
G1 X149.671 Y118.028 E.19453
G1 X150.228 Y118.028 E.02871
G1 X148.007 Y114.972 E.19453
G1 X148.565 Y114.972 E.02871
G1 X150.786 Y118.028 E.19453
G1 X151.343 Y118.028 E.02871
G1 X149.123 Y114.972 E.19453
G1 X149.68 Y114.972 E.02871
G1 X151.759 Y117.833 E.18212
G1 X152.082 Y117.51 E.02352
G1 X150.238 Y114.972 E.16156
G1 X150.796 Y114.972 E.02871
G1 X152.601 Y117.457 E.15816
G1 X152.976 Y117.457 E.01933
G1 X153.605 Y118.07 E.04521
G1 X151.353 Y114.972 E.19721
G1 X151.911 Y114.972 E.02871
G1 X154.607 Y118.682 E.23614
G1 X155.164 Y118.682 E.02871
G1 X152.468 Y114.972 E.23614
G1 X153.026 Y114.972 E.02871
G1 X155.722 Y118.682 E.23614
G1 X156.279 Y118.682 E.02871
G1 X153.584 Y114.972 E.23614
G1 X154.141 Y114.972 E.02871
G1 X156.837 Y118.682 E.23614
G1 X157.395 Y118.682 E.02871
G1 X154.699 Y114.972 E.23614
G1 X155.256 Y114.972 E.02871
G1 X157.952 Y118.682 E.23614
G1 X158.51 Y118.682 E.02871
G1 X155.814 Y114.972 E.23614
G1 X156.372 Y114.972 E.02871
G1 X158.603 Y118.043 E.19548
G1 X159.028 Y118.176 E.02293
G1 X159.028 Y118.028 E.0076
G1 X159.15 Y118.028 E.00627
G1 X156.929 Y114.972 E.19453
G1 X157.487 Y114.972 E.02871
G1 X159.511 Y117.758 E.1773
G1 X159.812 Y117.457 E.02191
G1 X159.85 Y117.457 E.00196
G1 X158.044 Y114.972 E.15816
G1 X158.602 Y114.972 E.02871
G1 X160.408 Y117.457 E.15816
G1 X160.828 Y117.457 E.02163
G1 X161.196 Y117.774 E.02503
G1 X159.16 Y114.972 E.17836
G1 X159.717 Y114.972 E.02871
G1 X161.938 Y118.028 E.19453
G1 X162.496 Y118.028 E.02871
G1 X160.275 Y114.972 E.19453
G1 X160.833 Y114.972 E.02871
G1 X163.053 Y118.028 E.19453
G1 X163.611 Y118.028 E.02871
G1 X161.39 Y114.972 E.19453
G1 X161.948 Y114.972 E.02871
G1 X164.169 Y118.028 E.19453
G1 X164.726 Y118.028 E.02871
G1 X162.505 Y114.972 E.19453
G1 X163.063 Y114.972 E.02871
G1 X165.284 Y118.028 E.19453
G1 X165.841 Y118.028 E.02871
G1 X163.621 Y114.972 E.19453
G1 X164.178 Y114.972 E.02871
G1 X166.284 Y117.871 E.18448
G1 X166.476 Y118.028 E.01278
G1 X166.957 Y118.028 E.02475
G1 X164.736 Y114.972 E.19453
G1 X165.293 Y114.972 E.02871
G1 X167.426 Y117.907 E.18679
G1 X167.482 Y117.867 E.00352
G1 X168.543 Y118.677 E.06872
G1 X165.851 Y114.972 E.2358
G1 X166.409 Y114.972 E.02871
G1 X169.105 Y118.682 E.23614
G1 X169.662 Y118.682 E.02871
G1 X166.966 Y114.972 E.23614
G1 X167.524 Y114.972 E.02871
G1 X170.22 Y118.682 E.23614
G1 X170.777 Y118.682 E.02871
G1 X168.082 Y114.972 E.23614
G1 X168.639 Y114.972 E.02871
G1 X171.335 Y118.682 E.23614
G1 X171.893 Y118.682 E.02871
G1 X169.197 Y114.972 E.23614
G1 X169.754 Y114.972 E.02871
G1 X172.45 Y118.682 E.23614
G1 X173.008 Y118.682 E.02871
G1 X170.312 Y114.972 E.23614
G1 X170.87 Y114.972 E.02871
G1 X173.489 Y118.577 E.22947
G1 X173.097 Y117.373 E.0652
G1 X173.222 Y117.442 E.00731
G1 X171.427 Y114.972 E.15718
G1 X171.985 Y114.972 E.02871
G1 X174.15 Y117.951 E.18962
G1 X174.411 Y118.095 E.01538
G1 X174.691 Y117.929 E.01675
G1 X172.542 Y114.972 E.18822
G1 X173.1 Y114.972 E.02871
G1 X175.014 Y117.606 E.16767
G1 X175.164 Y117.457 E.01089
G1 X175.463 Y117.457 E.01542
G1 X173.658 Y114.972 E.15816
G1 X174.215 Y114.972 E.02871
G1 X176.646 Y118.317 E.21291
G1 X177.028 Y118.682 E.02719
G1 X177.469 Y118.682 E.02272
G1 X174.773 Y114.972 E.23614
G1 X175.331 Y114.972 E.02871
G1 X178.026 Y118.682 E.23614
G1 X178.584 Y118.682 E.02871
G1 X175.888 Y114.972 E.23614
G1 X176.446 Y114.972 E.02871
G1 X179.142 Y118.682 E.23614
G1 X179.699 Y118.682 E.02871
G1 X177.003 Y114.972 E.23614
G1 X177.561 Y114.972 E.02871
G1 X180.257 Y118.682 E.23614
G1 X180.814 Y118.682 E.02871
G1 X178.119 Y114.972 E.23614
G1 X178.676 Y114.972 E.02871
G1 X181.372 Y118.682 E.23614
G1 X181.411 Y118.682 E.00199
G1 X181.299 Y117.979 E.03665
G1 X181.435 Y118.001 E.00709
G1 X179.234 Y114.972 E.1928
G1 X179.791 Y114.972 E.02871
G1 X182.066 Y118.103 E.19928
G1 X182.135 Y118.114 E.0036
G2 X182.443 Y117.854 I-1.166 J-1.688 E.02078
G1 X180.349 Y114.972 E.18341
G1 X180.907 Y114.972 E.02871
G1 X182.766 Y117.531 E.16286
G1 X182.79 Y117.506 E.00178
G1 X183.028 Y117.539 E.01236
G1 X183.028 Y117.124 E.02134
G1 X181.464 Y114.972 E.137
G1 X182.022 Y114.972 E.02871
G1 X183.028 Y116.357 E.08815
G1 X183.028 Y115.589 E.03952
G1 X182.432 Y114.769 E.0522
G1 X183.05 Y118.014 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
G1 X183.05 Y118.828 E.02702
G1 X182.236 Y118.828 E.02699
G1 X181.921 Y118.514 E.01477
G1 X182.258 Y118.568 E.01131
G2 X182.943 Y117.96 I-2.738 J-3.773 E.03043
G1 X183.05 Y118.014 E.00397
G1 X183.234 Y119.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y119.652 E.60097
G1 X166.935 Y120.104 E.01668
G1 X183.065 Y120.104 E.59471
G1 X183.065 Y120.557 E.01668
G1 X166.766 Y120.557 E.60097
G1 X166.952 Y119.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y119.178 E.4443
G1 X174.357 Y118.828 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X174.022 Y118.828 E.01111
G1 X173.906 Y118.474 E.01238
G1 X174.014 Y118.366 E.00506
G3 X174.56 Y118.828 I-.522 J1.17 E.02406
G1 X176.188 Y118.828 E.05401
; WIPE_START
G1 X174.56 Y118.828 E-.61876
G1 X174.297 Y118.566 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X166.685 Y119.115 Z2.2 F30000
G1 X159.234 Y119.652 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y119.652 E.23225
G1 X152.935 Y120.104 E.01668
G1 X159.065 Y120.104 E.226
G1 X159.065 Y120.557 E.01668
G1 X152.766 Y120.557 E.23225
G1 X152.952 Y119.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y119.178 E.16724
; WIPE_START
G1 X156.988 Y119.178 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I-.049 J-1.216 P1  F30000
G1 X145.234 Y119.652 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y119.652 E.23225
G1 X138.935 Y120.104 E.01668
G1 X145.065 Y120.104 E.226
G1 X145.065 Y120.557 E.01668
G1 X138.766 Y120.557 E.23225
G1 X138.952 Y119.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y119.178 E.16724
G1 X143.856 Y118.828 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X143.541 Y118.513 E.01478
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X143.856 Y118.828 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/32
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.2 I-.516 J1.102 P1  F30000
G1 X183.398 Y137.358 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X72.602 Y137.358 E3.6753
G1 X72.602 Y136.858 E.0166
G1 F14852.35
G1 X72.602 Y136.798 E.00199
G1 F13500
G1 X183.398 Y136.798 E3.6753
G1 F14852.35
G1 X183.398 Y136.858 E.00199
G1 F15476.087
G1 X183.398 Y137.298 E.01461
M204 S250
G1 X183.79 Y137.674 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6843.18
M204 S5000
G1 X183.79 Y137.751 E.00234
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F5700
G1 X72.21 Y137.751 E3.42854
G1 F6843.18
G1 X72.21 Y137.674 E.00234
G1 F12000
G1 X72.21 Y137.274 E.01229
G1 F6923.007
G1 X72.21 Y136.845 E.01321
G1 F1800
G1 X72.21 Y136.476 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y136.406 E.0023
G1 X183.79 Y136.406 E3.70131
G1 X183.79 Y136.476 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y136.845 E.01134
G1 F6459.938
G1 X183.79 Y137.245 E.01229
G1 F12000
G1 X183.79 Y137.614 E.01136
M204 S10000
G1 X183.194 Y137.078 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.19616
G1 F15000
G1 X72.806 Y137.078 E1.37844
; WIPE_START
G1 X74.806 Y137.078 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I.381 J1.156 P1  F30000
G1 X131.398 Y118.398 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y120.148 E.05804
G1 X131.398 Y120.548 E.01327
G1 F14331.075
G1 X131.398 Y120.948 E.01327
G1 F6685.538
G1 X131.398 Y121.348 E.01327
G1 F1920
G1 X131.398 Y121.728 E.01262
G1 F600
G1 X124.602 Y121.728 E.22543
G1 F1920
G1 X124.602 Y121.348 E.01262
G1 F6685.538
G1 X124.602 Y120.948 E.01327
G1 F14331.075
G1 X124.602 Y120.548 E.01327
G1 F15476.087
G1 X124.602 Y120.148 E.01327
G1 X124.602 Y118.398 E.05804
G1 X117.398 Y118.398 E.23897
G1 X117.398 Y120.148 E.05804
G1 X117.398 Y120.548 E.01327
G1 F14331.075
G1 X117.398 Y120.948 E.01327
G1 F6685.538
G1 X117.398 Y121.348 E.01327
G1 F1920
G1 X117.398 Y121.728 E.01262
G1 F600
G1 X110.602 Y121.728 E.22543
G1 F1920
G1 X110.602 Y121.348 E.01262
G1 F6685.538
G1 X110.602 Y120.948 E.01327
G1 F14331.075
G1 X110.602 Y120.548 E.01327
G1 F15476.087
G1 X110.602 Y120.148 E.01327
M73 P42 R16
G1 X110.602 Y118.398 E.05804
G1 X103.398 Y118.398 E.23897
G1 X103.398 Y120.148 E.05804
G1 X103.398 Y120.548 E.01327
G1 F14331.075
G1 X103.398 Y120.948 E.01327
G1 F6685.538
G1 X103.398 Y121.348 E.01327
G1 F1920
G1 X103.398 Y121.728 E.01262
G1 F600
G1 X96.602 Y121.728 E.22543
G1 F1920
G1 X96.602 Y121.348 E.01262
G1 F6685.538
G1 X96.602 Y120.948 E.01327
G1 F14331.075
G1 X96.602 Y120.548 E.01327
G1 F15476.087
G1 X96.602 Y120.148 E.01327
G1 X96.602 Y118.398 E.05804
G1 X89.398 Y118.398 E.23897
G1 X89.398 Y120.148 E.05804
G1 X89.398 Y120.548 E.01327
G1 F14331.075
G1 X89.398 Y120.948 E.01327
G1 F6685.538
G1 X89.398 Y121.348 E.01327
G1 F1920
G1 X89.398 Y121.728 E.01262
G1 F600
G1 X72.602 Y121.728 E.55715
G1 F1920
G1 X72.602 Y121.348 E.01262
G1 F6685.538
G1 X72.602 Y120.948 E.01327
G1 F14331.075
G1 X72.602 Y120.548 E.01327
G1 F15476.087
G1 X72.602 Y120.148 E.01327
G1 X72.602 Y114.63 E.18301
G1 X183.398 Y114.63 E3.6753
G1 X183.398 Y120.148 E.18301
G1 X183.398 Y120.548 E.01327
G1 F14331.075
G1 X183.398 Y120.948 E.01327
G1 F6685.538
G1 X183.398 Y121.348 E.01327
G1 F1920
G1 X183.398 Y121.728 E.01262
G1 F600
G1 X166.602 Y121.728 E.55715
G1 F1920
G1 X166.602 Y121.348 E.01262
G1 F6685.538
G1 X166.602 Y120.948 E.01327
G1 F14331.075
G1 X166.602 Y120.548 E.01327
G1 F15476.087
G1 X166.602 Y120.148 E.01327
G1 X166.602 Y118.398 E.05804
G1 X159.398 Y118.398 E.23897
G1 X159.398 Y120.148 E.05804
G1 X159.398 Y120.548 E.01327
G1 F14331.075
G1 X159.398 Y120.948 E.01327
G1 F6685.538
G1 X159.398 Y121.348 E.01327
G1 F1920
G1 X159.398 Y121.728 E.01262
G1 F600
G1 X152.602 Y121.728 E.22543
G1 F1920
G1 X152.602 Y121.348 E.01262
G1 F6685.538
G1 X152.602 Y120.948 E.01327
G1 F14331.075
G1 X152.602 Y120.548 E.01327
G1 F15476.087
G1 X152.602 Y120.148 E.01327
G1 X152.602 Y118.398 E.05804
G1 X145.398 Y118.398 E.23897
G1 X145.398 Y120.148 E.05804
G1 X145.398 Y120.548 E.01327
G1 F14331.075
G1 X145.398 Y120.948 E.01327
G1 F6685.538
G1 X145.398 Y121.348 E.01327
G1 F1920
G1 X145.398 Y121.728 E.01262
G1 F600
G1 X138.602 Y121.728 E.22543
G1 F1920
G1 X138.602 Y121.348 E.01262
G1 F6685.538
G1 X138.602 Y120.948 E.01327
G1 F14331.075
G1 X138.602 Y120.548 E.01327
G1 F15476.087
G1 X138.602 Y120.148 E.01327
G1 X138.602 Y118.398 E.05804
G1 X131.458 Y118.398 E.23698
M204 S250
G1 X131.79 Y118.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y120.561 E.05442
G1 X131.79 Y120.961 E.01229
G1 F6459.938
G1 X131.79 Y121.361 E.01229
G1 F1800
M73 P43 R16
G1 X131.79 Y121.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y122.12 E.01294
G1 X124.21 Y122.12 E.25144
G1 X124.21 Y121.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y121.361 E.01134
G1 F6459.938
G1 X124.21 Y120.961 E.01229
G1 F12000
G1 X124.21 Y120.561 E.01229
G1 X124.21 Y118.79 E.05442
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y120.561 E.05442
G1 X117.79 Y120.961 E.01229
G1 F6459.938
G1 X117.79 Y121.361 E.01229
G1 F1800
G1 X117.79 Y121.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y122.12 E.01294
G1 X110.21 Y122.12 E.25144
G1 X110.21 Y121.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y121.361 E.01134
G1 F6459.938
G1 X110.21 Y120.961 E.01229
G1 F12000
G1 X110.21 Y120.561 E.01229
G1 X110.21 Y118.79 E.05442
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y120.561 E.05442
G1 X103.79 Y120.961 E.01229
G1 F6459.938
G1 X103.79 Y121.361 E.01229
G1 F1800
G1 X103.79 Y121.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y122.12 E.01294
G1 X96.21 Y122.12 E.25144
G1 X96.21 Y121.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y121.361 E.01134
G1 F6459.938
G1 X96.21 Y120.961 E.01229
G1 F12000
G1 X96.21 Y120.561 E.01229
G1 X96.21 Y118.79 E.05442
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y120.561 E.05442
G1 X89.79 Y120.961 E.01229
G1 F6459.938
G1 X89.79 Y121.361 E.01229
G1 F1800
G1 X89.79 Y121.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y122.12 E.01294
G1 X72.21 Y122.12 E.58316
G1 X72.21 Y121.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y121.361 E.01134
G1 F6459.938
G1 X72.21 Y120.961 E.01229
G1 F12000
G1 X72.21 Y120.561 E.01229
G1 X72.21 Y114.238 E.19428
G1 X183.79 Y114.238 E3.42854
G1 X183.79 Y120.561 E.19428
G1 X183.79 Y120.961 E.01229
G1 F6459.938
G1 X183.79 Y121.361 E.01229
G1 F1800
G1 X183.79 Y121.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y122.12 E.01294
G1 F600
G1 X166.21 Y122.12 E.58316
G1 X166.21 Y121.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y121.361 E.01134
G1 F6459.938
G1 X166.21 Y120.961 E.01229
G1 F12000
G1 X166.21 Y120.561 E.01229
G1 X166.21 Y118.79 E.05442
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y120.561 E.05442
G1 X159.79 Y120.961 E.01229
G1 F6459.938
G1 X159.79 Y121.361 E.01229
G1 F1800
G1 X159.79 Y121.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y122.12 E.01294
G1 X152.21 Y122.12 E.25144
G1 X152.21 Y121.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y121.361 E.01134
G1 F6459.938
G1 X152.21 Y120.961 E.01229
G1 F12000
G1 X152.21 Y120.561 E.01229
G1 X152.21 Y118.79 E.05442
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y120.561 E.05442
G1 X145.79 Y120.961 E.01229
G1 F6459.938
G1 X145.79 Y121.361 E.01229
G1 F1800
G1 X145.79 Y121.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y122.12 E.01294
G1 X138.21 Y122.12 E.25144
G1 X138.21 Y121.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y121.361 E.01134
G1 F6459.938
G1 X138.21 Y120.961 E.01229
G1 F12000
G1 X138.21 Y120.561 E.01229
G1 X138.21 Y118.79 E.05442
G1 X131.85 Y118.79 E.19542
; WIPE_START
M204 S10000
G1 X131.79 Y120.561 E-.67338
G1 X131.79 Y120.789 E-.08662
; WIPE_END
G1 E-.04 F1800
G1 X131.234 Y120.452 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y120.452 E.23226
G1 X124.935 Y120.905 E.01668
G1 X131.065 Y120.905 E.22601
G1 X131.065 Y121.357 E.01668
G1 X124.766 Y121.357 E.23226
; WIPE_START
G1 X126.766 Y121.357 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I.115 J-1.212 P1  F30000
G1 X117.234 Y120.452 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X110.935 Y120.452 E.23226
G1 X110.935 Y120.905 E.01668
G1 X117.065 Y120.905 E.22601
G1 X117.065 Y121.357 E.01668
G1 X110.766 Y121.357 E.23226
; WIPE_START
G1 X112.766 Y121.357 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I.115 J-1.212 P1  F30000
G1 X103.234 Y120.452 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X96.935 Y120.452 E.23226
G1 X96.935 Y120.905 E.01668
M73 P43 R15
G1 X103.065 Y120.905 E.22601
G1 X103.065 Y121.357 E.01668
G1 X96.766 Y121.357 E.23226
; WIPE_START
G1 X98.766 Y121.357 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I.115 J-1.212 P1  F30000
G1 X89.234 Y120.452 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X72.935 Y120.452 E.60098
G1 X72.935 Y120.905 E.01668
G1 X89.065 Y120.905 E.59472
G1 X89.065 Y121.357 E.01668
G1 X72.766 Y121.357 E.60098
G1 X72.952 Y119.978 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y119.978 E.4443
G1 X73.782 Y116.255 F30000
; LINE_WIDTH: 0.48773
G1 F14163.35
G1 X182.218 Y116.255 E3.9304
G1 X182.218 Y115.811 E.01612
G1 X73.782 Y115.811 E3.9304
G1 X73.782 Y116.195 E.01395
G1 X73.371 Y116.666 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X182.629 Y116.666 E3.3571
G1 X182.629 Y115.4 E.03892
G1 X73.371 Y115.4 E3.3571
G1 X73.371 Y116.606 E.03708
G1 X72.994 Y117.043 F30000
G1 F15000
G1 X183.006 Y117.043 E3.38027
G1 X183.006 Y115.023 E.06209
G1 X72.994 Y115.023 E3.38027
G1 X72.994 Y116.983 E.06025
G1 X73.172 Y118.235 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.95 Y118.235 E.00736
G1 X72.95 Y119.628 E.04621
G1 X74.357 Y118.235 E.06567
G1 X74.18 Y118.235 E.00588
G1 X75.573 Y119.628 E.06535
G1 X80.64 Y119.628 E.16809
G1 X82.033 Y118.235 E.06535
G1 X81.856 Y118.235 E.00588
G1 X83.249 Y119.628 E.06535
G1 X88.316 Y119.628 E.16809
G1 X89.05 Y118.895 E.03442
G1 X89.05 Y118.538 E.01182
G1 X88.767 Y118.421 E.01015
G1 X88.767 Y118.235 E.00616
G1 X87.987 Y118.235 E.02588
; WIPE_START
G1 X88.767 Y118.235 E-.29648
G1 X88.767 Y118.421 E-.07052
G1 X89.05 Y118.538 E-.11633
G1 X89.05 Y118.895 E-.13544
G1 X88.787 Y119.157 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X96.412 Y119.493 Z2.4 F30000
G1 X138.766 Y121.357 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X145.065 Y121.357 E.23226
G1 X145.065 Y120.905 E.01668
G1 X138.935 Y120.905 E.22601
G1 X138.935 Y120.452 E.01668
G1 X145.234 Y120.452 E.23226
; WIPE_START
G1 X143.234 Y120.452 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I-.115 J1.212 P1  F30000
G1 X152.766 Y121.357 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X159.065 Y121.357 E.23226
G1 X159.065 Y120.905 E.01668
G1 X152.935 Y120.905 E.22601
G1 X152.935 Y120.452 E.01668
G1 X159.234 Y120.452 E.23226
; WIPE_START
G1 X157.234 Y120.452 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I-.115 J1.212 P1  F30000
G1 X166.766 Y121.357 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X183.065 Y121.357 E.60098
G1 X183.065 Y120.905 E.01668
G1 X166.935 Y120.905 E.59472
G1 X166.935 Y120.452 E.01668
G1 X183.234 Y120.452 E.60098
G1 X168.013 Y118.235 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
M73 P44 R15
G1 F15476.087
G1 X167.233 Y118.235 E.02588
G1 X167.233 Y118.421 E.00616
G1 X166.95 Y118.538 E.01015
G1 X166.95 Y118.895 E.01182
G1 X167.684 Y119.628 E.03442
G1 X172.751 Y119.628 E.16809
G1 X174.144 Y118.235 E.06535
G1 X173.967 Y118.235 E.00588
G1 X175.36 Y119.628 E.06535
G1 X180.427 Y119.628 E.16809
G1 X181.82 Y118.235 E.06535
G1 X181.643 Y118.235 E.00588
G1 X183.05 Y119.628 E.06567
G1 X183.05 Y118.235 E.04621
G1 X182.828 Y118.235 E.00735
G1 X166.918 Y118.21 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.388607
G1 F12000
G1 X166.879 Y118.035 E.00504
G1 X166.976 Y117.836 E.00624
; LINE_WIDTH: 0.491623
G1 X167.122 Y117.808 E.00544
G1 X182.91 Y117.808 E.57726
G1 X160.807 Y117.736 F30000
; LINE_WIDTH: 0.369283
G1 F12000
G1 X162.252 Y117.736 E.03841
; LINE_WIDTH: 0.411168
G1 X163.696 Y117.736 E.04334
; LINE_WIDTH: 0.453053
G1 X165.141 Y117.736 E.04827
; LINE_WIDTH: 0.494938
G1 X166.585 Y117.736 E.0532
; LINE_WIDTH: 0.37119
G1 X166.64 Y117.757 E.00158
; LINE_WIDTH: 0.41689
G1 X166.695 Y117.778 E.0018
; LINE_WIDTH: 0.46259
G1 X166.75 Y117.799 E.00202
; LINE_WIDTH: 0.519615
G2 X166.976 Y117.836 I.18 J-.392 E.009
; LINE_WIDTH: 0.50815
G1 X166.942 Y117.868 E.00177
; LINE_WIDTH: 0.46217
G1 X166.908 Y117.9 E.00159
; LINE_WIDTH: 0.41619
G1 X166.874 Y117.931 E.00142
; LINE_WIDTH: 0.53685
G1 X166.879 Y118.035 E.00419
; LINE_WIDTH: 0.422339
G1 X166.827 Y117.948 E.00313
G1 X166.586 Y118.042 E.00798
; LINE_WIDTH: 0.34834
G1 X161.162 Y118.042 E.13501
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X159.634 Y118.042 E.03801
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.366253
;_EXTRUDE_SET_SPEED
G1 X159.414 Y118.042 E.0058
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.392684
;_EXTRUDE_SET_SPEED
G1 X159.194 Y118.042 E.00627
G1 X159.006 Y118.194 E.00691
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.41999
;_EXTRUDE_SET_SPEED
G1 X159.006 Y119.032 E.02574
; Slow Down End
G1 F12000
G1 X159.006 Y119.936 E.02777
G1 X152.994 Y119.936 E.18472
G1 X152.994 Y119.032 E.02777
; LINE_WIDTH: 0.402078
G1 X152.994 Y118.613 E.01226
; LINE_WIDTH: 0.372823
G1 X152.994 Y118.194 E.01126
G1 X152.806 Y118.042 E.00652
; LINE_WIDTH: 0.34834
G1 X145.561 Y118.042 E.1803
; LINE_WIDTH: 0.366253
G1 X145.378 Y118.042 E.00483
; LINE_WIDTH: 0.391876
G1 X145.194 Y118.042 E.00521
G1 X145.006 Y118.194 E.0069
; LINE_WIDTH: 0.41999
G1 X145.006 Y119.936 E.0535
G1 X138.994 Y119.936 E.18472
G1 X138.994 Y119.032 E.02777
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X138.994 Y118.588 E.01365
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.402078
;_EXTRUDE_SET_SPEED
G1 X138.994 Y118.391 E.00576
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.376144
;_EXTRUDE_SET_SPEED
G1 X138.994 Y118.194 E.00534
G1 X138.806 Y118.042 E.00659
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.34834
;_EXTRUDE_SET_SPEED
G1 X135.1 Y118.042 E.09221
; Slow Down End
; LINE_WIDTH: 0.366253
G1 F12000
G1 X133.147 Y118.042 E.05146
; LINE_WIDTH: 0.400099
G1 X131.194 Y118.042 E.05684
G1 X131.006 Y118.194 E.00706
; LINE_WIDTH: 0.41999
G1 X131.006 Y119.936 E.0535
G1 X124.994 Y119.936 E.18472
G1 X124.994 Y118.907 E.0316
; LINE_WIDTH: 0.402078
G1 X124.994 Y118.551 E.01043
; LINE_WIDTH: 0.373508
G1 X124.994 Y118.194 E.0096
G1 X124.806 Y118.042 E.00654
; LINE_WIDTH: 0.34834
G1 X121.255 Y118.042 E.08838
; LINE_WIDTH: 0.366253
G1 X119.224 Y118.042 E.05349
; LINE_WIDTH: 0.400166
G1 X117.194 Y118.042 E.0591
G1 X117.006 Y118.194 E.00706
; LINE_WIDTH: 0.41999
G1 X117.006 Y119.936 E.0535
G1 X110.994 Y119.936 E.18472
G1 X110.994 Y118.821 E.03425
; LINE_WIDTH: 0.402078
G1 X110.994 Y118.508 E.00917
; LINE_WIDTH: 0.37407
G1 X110.994 Y118.194 E.00846
G1 X110.806 Y118.042 E.00655
; LINE_WIDTH: 0.34834
G1 X105.813 Y118.042 E.12424
; LINE_WIDTH: 0.366253
G1 X104.504 Y118.042 E.0345
; LINE_WIDTH: 0.399278
G1 X103.194 Y118.042 E.03803
G1 X103.006 Y118.194 E.00705
; LINE_WIDTH: 0.41999
G1 X103.006 Y119.936 E.0535
G1 X96.994 Y119.936 E.18472
G1 X96.994 Y119.032 E.02777
; LINE_WIDTH: 0.402078
G1 X96.994 Y118.613 E.01226
; LINE_WIDTH: 0.372823
G1 X96.994 Y118.194 E.01126
G1 X96.806 Y118.042 E.00652
; LINE_WIDTH: 0.34834
G1 X90.619 Y118.042 E.15396
; LINE_WIDTH: 0.369282
G1 X90.318 Y118.042 E.00801
; LINE_WIDTH: 0.411164
G1 X90.017 Y118.042 E.00904
; LINE_WIDTH: 0.453047
G1 X89.716 Y118.042 E.01006
; LINE_WIDTH: 0.494929
G1 X89.415 Y118.042 E.01109
; LINE_WIDTH: 0.37075
G1 X89.194 Y117.958 E.0063
; LINE_WIDTH: 0.493852
G1 X89.121 Y118.035 E.00392
G1 X89.126 Y117.931 E.00383
; LINE_WIDTH: 0.53685
G1 X89.023 Y117.838 E.0056
; LINE_WIDTH: 0.50556
G1 X89.06 Y117.836 E.00137
; LINE_WIDTH: 0.46064
G1 X89.096 Y117.834 E.00123
; LINE_WIDTH: 0.41572
G1 X89.132 Y117.832 E.0011
; LINE_WIDTH: 0.433904
G1 X89.414 Y117.736 E.00949
; LINE_WIDTH: 0.34834
G1 X91.852 Y117.736 E.06068
; LINE_WIDTH: 0.366253
G1 X94.329 Y117.736 E.06526
; LINE_WIDTH: 0.398529
G1 X96.806 Y117.736 E.07177
G1 X97.416 Y117.772 E.01773
; LINE_WIDTH: 0.41999
G1 X98.991 Y117.772 E.04837
; LINE_WIDTH: 0.402078
G1 X100.787 Y117.772 E.05258
; LINE_WIDTH: 0.370804
G1 X102.584 Y117.772 E.048
G1 X103.194 Y117.736 E.01635
; LINE_WIDTH: 0.34834
G1 X106.812 Y117.736 E.09004
; LINE_WIDTH: 0.366253
G1 X108.809 Y117.736 E.05261
; LINE_WIDTH: 0.397876
G1 X110.806 Y117.736 E.05775
G1 X111.416 Y117.772 E.0177
; LINE_WIDTH: 0.41999
G1 X114.597 Y117.772 E.09774
; LINE_WIDTH: 0.402078
G1 X115.59 Y117.772 E.02907
; LINE_WIDTH: 0.373082
G2 X117.194 Y117.736 I.497 J-13.694 E.04319
; LINE_WIDTH: 0.34834
G1 X122.427 Y117.736 E.13024
; LINE_WIDTH: 0.366253
G1 X123.616 Y117.736 E.03133
; LINE_WIDTH: 0.395992
G3 X125.416 Y117.772 I.595 J15.365 E.05183
; LINE_WIDTH: 0.402078
G1 X128 Y117.772 E.07561
; LINE_WIDTH: 0.369683
G1 X130.584 Y117.772 E.06879
G1 X131.194 Y117.736 E.01629
; LINE_WIDTH: 0.34834
G1 X137.381 Y117.736 E.15397
; LINE_WIDTH: 0.366253
G1 X138.093 Y117.736 E.01877
; LINE_WIDTH: 0.393801
G3 X139.416 Y117.772 I.356 J11.3 E.03787
; LINE_WIDTH: 0.41999
G1 X144.463 Y117.772 E.15506
; LINE_WIDTH: 0.402078
G1 X144.523 Y117.772 E.00177
; LINE_WIDTH: 0.382664
G2 X145.192 Y117.736 I.03 J-5.722 E.01856
; LINE_WIDTH: 0.348463
G1 X145.194 Y117.736 E.00005
; LINE_WIDTH: 0.364768
G1 X148.685 Y117.736 E.09153
; LINE_WIDTH: 0.400593
G1 X152.806 Y117.736 E.12011
; LINE_WIDTH: 0.356758
G1 X152.949 Y117.745 E.00368
; LINE_WIDTH: 0.37888
G1 X153.183 Y117.758 E.00641
; LINE_WIDTH: 0.385124
G1 X153.416 Y117.772 E.00653
G1 X158.584 Y117.772 E.14409
; LINE_WIDTH: 0.402078
G1 X158.889 Y117.754 E.00895
; LINE_WIDTH: 0.351289
G3 X160.747 Y117.736 I1.246 J32.856 E.0467
; WIPE_START
G1 X159.194 Y117.736 E-.63491
G1 X158.889 Y117.754 E-.12509
; WIPE_END
G1 E-.04 F1800
G1 X158.629 Y119.559 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X153.371 Y119.559 E.16155
G1 X153.371 Y118.194 E.04192
G1 X153.326 Y118.149 E.00197
G1 X158.667 Y118.149 E.1641
G1 X158.629 Y118.194 E.00181
G1 X158.629 Y119.499 E.04007
G1 X158.182 Y119.112 F30000
; LINE_WIDTH: 0.55911
G1 F12000
G1 X153.818 Y119.112 E.18358
G1 X153.818 Y118.596 E.02171
G1 X158.182 Y118.596 E.18358
G1 X158.182 Y119.052 E.01919
; WIPE_START
G1 X158.182 Y118.596 E-.17336
G1 X156.638 Y118.596 E-.58664
; WIPE_END
G1 E-.04 F1800
G1 X149.03 Y119.206 Z2.4 F30000
G1 X144.629 Y119.559 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X139.371 Y119.559 E.16155
G1 X139.371 Y118.194 E.04192
G1 X139.326 Y118.149 E.00197
G1 X144.667 Y118.149 E.1641
G1 X144.629 Y118.194 E.00181
G1 X144.629 Y119.499 E.04007
G1 X144.182 Y119.112 F30000
; LINE_WIDTH: 0.55911
G1 F12000
G1 X139.818 Y119.112 E.18358
G1 X139.818 Y118.596 E.02171
G1 X144.182 Y118.596 E.18358
G1 X144.182 Y119.052 E.01919
; WIPE_START
G1 X144.182 Y118.596 E-.17336
G1 X142.638 Y118.596 E-.58664
; WIPE_END
G1 E-.04 F1800
G1 X135.011 Y118.311 Z2.4 F30000
G1 X130.667 Y118.149 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X130.629 Y118.194 E.00181
G1 X130.629 Y119.559 E.04192
G1 X125.371 Y119.559 E.16155
G1 X125.371 Y118.194 E.04192
G1 X125.326 Y118.149 E.00197
G1 X130.607 Y118.149 E.16226
G1 X130.182 Y119.112 F30000
; LINE_WIDTH: 0.55911
G1 F12000
G1 X125.818 Y119.112 E.18358
G1 X125.818 Y118.596 E.02171
G1 X127.585 Y118.596 E.07433
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X129.709 Y118.596 E.08934
; Slow Down End
G1 F12000
G1 X130.182 Y118.596 E.01991
G1 X130.182 Y119.052 E.01919
; WIPE_START
G1 X130.182 Y118.596 E-.37303
G1 X129.709 Y118.596 E-.38697
; WIPE_END
G1 E-.04 F1800
G1 X122.097 Y119.156 Z2.4 F30000
G1 X116.629 Y119.559 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X111.371 Y119.559 E.16155
G1 X111.371 Y118.194 E.04192
G1 X111.326 Y118.149 E.00197
G1 X116.667 Y118.149 E.1641
G1 X116.629 Y118.194 E.00181
G1 X116.629 Y119.499 E.04007
G1 X116.182 Y119.112 F30000
; LINE_WIDTH: 0.55911
G1 F12000
G1 X111.818 Y119.112 E.18358
G1 X111.818 Y119.032 E.00337
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X111.818 Y118.596 E.01835
G1 X115.44 Y118.596 E.15237
; Slow Down End
G1 F12000
G1 X116.182 Y118.596 E.03121
G1 X116.182 Y119.052 E.01919
; WIPE_START
G1 X116.182 Y118.596 E-.28939
G1 X115.44 Y118.596 E-.47061
; WIPE_END
G1 E-.04 F1800
G1 X107.812 Y118.329 Z2.4 F30000
G1 X102.667 Y118.149 Z2.4
G1 Z2
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X102.629 Y118.194 E.00181
G1 X102.629 Y119.559 E.04192
G1 X97.371 Y119.559 E.16155
G1 X97.371 Y119.032 E.01618
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X97.371 Y118.194 E.02574
G1 X97.326 Y118.149 E.00197
G1 X99.385 Y118.149 E.06327
; Slow Down End
G1 F12000
G1 X102.607 Y118.149 E.099
G1 X102.182 Y119.112 F30000
; LINE_WIDTH: 0.55911
G1 F12000
G1 X97.818 Y119.112 E.18358
G1 X97.818 Y119.032 E.00337
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X97.818 Y118.596 E.01835
G1 X99.852 Y118.596 E.08556
; Slow Down End
G1 F12000
G1 X102.182 Y118.596 E.09802
G1 X102.182 Y119.052 E.01919
; WIPE_START
G1 X102.182 Y118.596 E-.17336
G1 X100.638 Y118.596 E-.58664
; WIPE_END
G1 E-.04 F1800
G1 X93.009 Y118.378 Z2.4 F30000
G1 X73.03 Y117.808 Z2.4
G1 Z2
G1 E.8 F1800
; Slow Down Start
; LINE_WIDTH: 0.49126
G1 F3000;_EXTRUDE_SET_SPEED
G1 X76.254 Y117.808 E.11779
; Slow Down End
; LINE_WIDTH: 0.491884
G1 F12000
G1 X88.878 Y117.808 E.46184
G1 X89.023 Y117.838 E.00544
G1 X89.121 Y118.035 E.00806
; LINE_WIDTH: 0.39316
G1 X89.095 Y118.152 E.0034
; WIPE_START
G1 X89.121 Y118.035 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X96.751 Y118.226 Z2.4 F30000
G1 X166.952 Y119.978 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y119.978 E.4443
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X180.988 Y119.978 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 11/32
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.4 I-1.205 J.167 P1  F30000
G1 X183.398 Y137.397 Z2.4
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y137.397 E3.6753
G1 X72.602 Y136.779 E.02053
G1 X72.602 Y136.379 E.01327
G1 F14852.35
G1 X72.602 Y136.319 E.00199
G1 F13500
G1 X183.398 Y136.319 E3.6753
G1 F14852.35
G1 X183.398 Y136.379 E.00199
G1 F15476.087
G1 X183.398 Y136.779 E.01327
G1 X183.398 Y137.337 E.01854
M204 S250
G1 X183.79 Y137.789 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y137.789 E3.42854
G1 X72.21 Y137.165 E.01919
G1 X72.21 Y136.765 E.01229
G1 F6459.938
G1 X72.21 Y136.365 E.01229
G1 F1800
G1 X72.21 Y135.996 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y135.927 E.0023
G1 X183.79 Y135.927 E3.70131
G1 X183.79 Y135.996 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y136.365 E.01134
G1 F6459.938
G1 X183.79 Y136.765 E.01229
G1 F12000
G1 X183.79 Y137.165 E.01229
G1 X183.79 Y137.729 E.01734
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X181.79 Y137.731 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X174.158 Y137.658 Z2.6 F30000
G1 X72.974 Y136.69 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.37874
G1 F15000
G1 X72.974 Y137.026 E.00919
G1 X183.027 Y137.026 E3.01161
G1 X183.027 Y136.69 E.00919
G1 X73.034 Y136.69 E3.00997
; WIPE_START
G1 X75.034 Y136.69 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.6 I.376 J1.158 P1  F30000
G1 X131.398 Y118.398 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y120.948 E.08457
G1 X131.398 Y121.348 E.01327
G1 F14331.075
G1 X131.398 Y121.748 E.01327
G1 F6685.538
G1 X131.398 Y122.148 E.01327
G1 F1920
G1 X131.398 Y122.528 E.01262
G1 F600
G1 X124.602 Y122.528 E.22543
G1 F1920
G1 X124.602 Y122.148 E.01262
G1 F6685.538
G1 X124.602 Y121.748 E.01327
G1 F14331.075
G1 X124.602 Y121.348 E.01327
G1 F15476.087
G1 X124.602 Y120.948 E.01327
G1 X124.602 Y118.398 E.08457
G1 X117.398 Y118.398 E.23897
G1 X117.398 Y120.948 E.08457
G1 X117.398 Y121.348 E.01327
G1 F14331.075
G1 X117.398 Y121.748 E.01327
G1 F6685.538
G1 X117.398 Y122.148 E.01327
G1 F1920
G1 X117.398 Y122.528 E.01262
G1 F600
G1 X110.602 Y122.528 E.22543
G1 F1920
G1 X110.602 Y122.148 E.01262
G1 F6685.538
G1 X110.602 Y121.748 E.01327
G1 F14331.075
G1 X110.602 Y121.348 E.01327
G1 F15476.087
G1 X110.602 Y120.948 E.01327
G1 X110.602 Y118.398 E.08457
G1 X103.398 Y118.398 E.23897
G1 X103.398 Y120.948 E.08457
G1 X103.398 Y121.348 E.01327
G1 F14331.075
G1 X103.398 Y121.748 E.01327
G1 F6685.538
G1 X103.398 Y122.148 E.01327
G1 F1920
G1 X103.398 Y122.528 E.01262
G1 F600
G1 X96.602 Y122.528 E.22543
G1 F1920
G1 X96.602 Y122.148 E.01262
G1 F6685.538
G1 X96.602 Y121.748 E.01327
G1 F14331.075
G1 X96.602 Y121.348 E.01327
G1 F15476.087
G1 X96.602 Y120.948 E.01327
G1 X96.602 Y118.398 E.08457
G1 X89.398 Y118.398 E.23897
G1 X89.398 Y120.948 E.08457
G1 X89.398 Y121.348 E.01327
G1 F14331.075
G1 X89.398 Y121.748 E.01327
G1 F6685.538
G1 X89.398 Y122.148 E.01327
G1 F1920
G1 X89.398 Y122.528 E.01262
G1 F600
G1 X72.602 Y122.528 E.55715
G1 F1920
M73 P45 R15
G1 X72.602 Y122.148 E.01262
G1 F6685.538
G1 X72.602 Y121.748 E.01327
G1 F14331.075
G1 X72.602 Y121.348 E.01327
G1 F15476.087
G1 X72.602 Y120.948 E.01327
G1 X72.602 Y114.732 E.20618
G1 X183.398 Y114.732 E3.6753
G1 X183.398 Y120.948 E.20618
G1 X183.398 Y121.348 E.01327
G1 F14331.075
G1 X183.398 Y121.748 E.01327
G1 F6685.538
G1 X183.398 Y122.148 E.01327
G1 F1920
G1 X183.398 Y122.528 E.01262
G1 F600
G1 X166.602 Y122.528 E.55715
G1 F1920
G1 X166.602 Y122.148 E.01262
G1 F6685.538
G1 X166.602 Y121.748 E.01327
G1 F14331.075
G1 X166.602 Y121.348 E.01327
G1 F15476.087
G1 X166.602 Y120.948 E.01327
G1 X166.602 Y118.398 E.08457
G1 X159.398 Y118.398 E.23897
G1 X159.398 Y120.948 E.08457
G1 X159.398 Y121.348 E.01327
G1 F14331.075
G1 X159.398 Y121.748 E.01327
G1 F6685.538
G1 X159.398 Y122.148 E.01327
G1 F1920
G1 X159.398 Y122.528 E.01262
G1 F600
G1 X152.602 Y122.528 E.22543
G1 F1920
G1 X152.602 Y122.148 E.01262
G1 F6685.538
G1 X152.602 Y121.748 E.01327
G1 F14331.075
G1 X152.602 Y121.348 E.01327
G1 F15476.087
G1 X152.602 Y120.948 E.01327
G1 X152.602 Y118.398 E.08457
G1 X145.398 Y118.398 E.23897
G1 X145.398 Y120.948 E.08457
G1 X145.398 Y121.348 E.01327
G1 F14331.075
G1 X145.398 Y121.748 E.01327
G1 F6685.538
G1 X145.398 Y122.148 E.01327
G1 F1920
G1 X145.398 Y122.528 E.01262
G1 F600
G1 X138.602 Y122.528 E.22543
G1 F1920
G1 X138.602 Y122.148 E.01262
G1 F6685.538
G1 X138.602 Y121.748 E.01327
G1 F14331.075
G1 X138.602 Y121.348 E.01327
G1 F15476.087
G1 X138.602 Y120.948 E.01327
G1 X138.602 Y118.398 E.08457
G1 X131.458 Y118.398 E.23698
M204 S250
G1 X131.79 Y118.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y121.361 E.079
G1 X131.79 Y121.761 E.01229
G1 F6459.938
G1 X131.79 Y122.161 E.01229
G1 F1800
G1 X131.79 Y122.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y122.92 E.01294
G1 X124.21 Y122.92 E.25144
G1 X124.21 Y122.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y122.161 E.01134
G1 F6459.938
G1 X124.21 Y121.761 E.01229
G1 F12000
G1 X124.21 Y121.361 E.01229
G1 X124.21 Y118.79 E.079
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y121.361 E.079
G1 X117.79 Y121.761 E.01229
G1 F6459.938
G1 X117.79 Y122.161 E.01229
G1 F1800
G1 X117.79 Y122.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y122.92 E.01294
G1 X110.21 Y122.92 E.25144
G1 X110.21 Y122.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y122.161 E.01134
G1 F6459.938
G1 X110.21 Y121.761 E.01229
G1 F12000
G1 X110.21 Y121.361 E.01229
G1 X110.21 Y118.79 E.079
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y121.361 E.079
G1 X103.79 Y121.761 E.01229
G1 F6459.938
G1 X103.79 Y122.161 E.01229
G1 F1800
G1 X103.79 Y122.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y122.92 E.01294
G1 X96.21 Y122.92 E.25144
M73 P46 R15
G1 X96.21 Y122.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y122.161 E.01134
G1 F6459.938
G1 X96.21 Y121.761 E.01229
G1 F12000
G1 X96.21 Y121.361 E.01229
G1 X96.21 Y118.79 E.079
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y121.361 E.079
G1 X89.79 Y121.761 E.01229
G1 F6459.938
G1 X89.79 Y122.161 E.01229
G1 F1800
G1 X89.79 Y122.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y122.92 E.01294
G1 X72.21 Y122.92 E.58316
G1 X72.21 Y122.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y122.161 E.01134
G1 F6459.938
G1 X72.21 Y121.761 E.01229
G1 F12000
G1 X72.21 Y121.361 E.01229
G1 X72.21 Y114.34 E.21573
G1 X183.79 Y114.34 E3.42854
G1 X183.79 Y121.361 E.21573
G1 X183.79 Y121.761 E.01229
G1 F6459.938
G1 X183.79 Y122.161 E.01229
G1 F1800
G1 X183.79 Y122.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y122.92 E.01294
G1 F600
G1 X166.21 Y122.92 E.58316
G1 X166.21 Y122.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y122.161 E.01134
G1 F6459.938
G1 X166.21 Y121.761 E.01229
G1 F12000
G1 X166.21 Y121.361 E.01229
G1 X166.21 Y118.79 E.079
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y121.361 E.079
G1 X159.79 Y121.761 E.01229
G1 F6459.938
G1 X159.79 Y122.161 E.01229
G1 F1800
G1 X159.79 Y122.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y122.92 E.01294
G1 X152.21 Y122.92 E.25144
G1 X152.21 Y122.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y122.161 E.01134
G1 F6459.938
G1 X152.21 Y121.761 E.01229
G1 F12000
G1 X152.21 Y121.361 E.01229
G1 X152.21 Y118.79 E.079
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y121.361 E.079
G1 X145.79 Y121.761 E.01229
G1 F6459.938
G1 X145.79 Y122.161 E.01229
G1 F1800
G1 X145.79 Y122.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y122.92 E.01294
G1 X138.21 Y122.92 E.25144
G1 X138.21 Y122.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y122.161 E.01134
G1 F6459.938
G1 X138.21 Y121.761 E.01229
G1 F12000
G1 X138.21 Y121.361 E.01229
G1 X138.21 Y118.79 E.079
G1 X131.85 Y118.79 E.19542
; WIPE_START
M204 S10000
G1 X131.803 Y120.789 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.234 Y121.252 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y121.252 E.23226
G1 X124.935 Y121.705 E.01668
G1 X131.065 Y121.705 E.22601
G1 X131.065 Y122.157 E.01668
G1 X124.766 Y122.157 E.23226
G1 X125.39 Y120.905 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42098
G1 F15000
G1 X124.935 Y120.45 E.01982
G1 X124.935 Y119.916 E.01647
G1 X125.755 Y120.736 E.03572
G1 X126.29 Y120.736 E.01647
G1 X124.935 Y119.381 E.05902
G1 X124.935 Y118.846 E.01647
G1 X126.994 Y120.905 E.0897
; WIPE_START
G1 X125.58 Y119.491 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X118.112 Y121.067 Z2.6 F30000
G1 X117.234 Y121.252 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y121.252 E.23226
G1 X110.935 Y121.705 E.01668
G1 X117.065 Y121.705 E.22601
G1 X117.065 Y122.157 E.01668
G1 X110.766 Y122.157 E.23226
G1 X111.489 Y120.905 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42098
G1 F15000
G1 X110.935 Y120.351 E.02413
G1 X110.935 Y119.817 E.01647
G1 X111.854 Y120.736 E.04003
G1 X112.389 Y120.736 E.01647
G1 X110.935 Y119.282 E.06332
G1 X110.935 Y118.747 E.01647
G1 X113.093 Y120.905 E.09401
; WIPE_START
G1 X111.679 Y119.491 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X104.207 Y121.049 Z2.6 F30000
G1 X103.234 Y121.252 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y121.252 E.23226
G1 X96.935 Y121.705 E.01668
G1 X103.065 Y121.705 E.22601
G1 X103.065 Y122.157 E.01668
G1 X96.766 Y122.157 E.23226
G1 X97.588 Y120.905 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42098
G1 F15000
G1 X96.935 Y120.253 E.02844
G1 X96.935 Y119.718 E.01647
G1 X97.953 Y120.736 E.04434
G1 X98.488 Y120.736 E.01647
G1 X96.935 Y119.183 E.06763
G1 X96.935 Y118.649 E.01647
G1 X99.192 Y120.905 E.09832
; WIPE_START
G1 X97.778 Y119.491 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X90.152 Y119.16 Z2.6 F30000
G1 X87.281 Y119.035 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.909 Y119.035 E.05401
G1 X87.516 Y120.428 E.06535
G1 X84.049 Y120.428 E.11502
G1 X82.656 Y119.035 E.06535
G1 X81.233 Y119.035 E.0472
G1 X79.84 Y120.428 E.06535
G1 X76.373 Y120.428 E.11502
G1 X74.98 Y119.035 E.06535
G1 X73.557 Y119.035 E.0472
G1 X72.95 Y119.642 E.02846
G1 X72.95 Y120.428 E.02609
G1 X73.792 Y120.428 E.02793
G1 X72.952 Y120.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y120.778 E.4443
G1 X89.234 Y121.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y121.252 E.60098
G1 X72.935 Y121.705 E.01668
G1 X89.065 Y121.705 E.59472
G1 X89.065 Y122.157 E.01668
G1 X72.766 Y122.157 E.60098
G1 X73.575 Y118.813 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42098
G1 F15000
G1 X72.935 Y118.174 E.02786
G1 X72.935 Y117.639 E.01647
G1 X73.94 Y118.643 E.04376
G1 X74.474 Y118.643 E.01647
G1 X72.935 Y117.104 E.06705
G1 X72.935 Y116.57 E.01647
G1 X75.009 Y118.643 E.09035
G1 X75.544 Y118.643 E.01647
G1 X72.935 Y116.035 E.11364
G1 X72.935 Y115.5 E.01647
G1 X76.078 Y118.643 E.13694
G1 X76.613 Y118.643 E.01647
G1 X73.035 Y115.065 E.15588
G1 X73.57 Y115.065 E.01647
G1 X77.148 Y118.643 E.15588
G1 X77.682 Y118.643 E.01647
G1 X74.104 Y115.065 E.15588
G1 X74.639 Y115.065 E.01647
G1 X78.217 Y118.643 E.15588
G1 X78.752 Y118.643 E.01647
G1 X75.174 Y115.065 E.15588
G1 X75.708 Y115.065 E.01647
G1 X79.286 Y118.643 E.15588
G1 X79.821 Y118.643 E.01647
G1 X76.243 Y115.065 E.15588
G1 X76.778 Y115.065 E.01647
G1 X80.356 Y118.643 E.15588
G1 X80.89 Y118.643 E.01647
G1 X77.312 Y115.065 E.15588
G1 X77.847 Y115.065 E.01647
G1 X81.425 Y118.643 E.15588
G1 X81.96 Y118.643 E.01647
G1 X78.382 Y115.065 E.15588
G1 X78.916 Y115.065 E.01647
G1 X82.494 Y118.643 E.15588
G1 X83.029 Y118.643 E.01647
G1 X79.451 Y115.065 E.15588
G1 X79.986 Y115.065 E.01647
G1 X83.563 Y118.643 E.15588
G1 X84.098 Y118.643 E.01647
G1 X80.52 Y115.065 E.15588
G1 X81.055 Y115.065 E.01647
G1 X84.633 Y118.643 E.15588
G1 X85.167 Y118.643 E.01647
G1 X81.59 Y115.065 E.15588
G1 X82.124 Y115.065 E.01647
G1 X85.702 Y118.643 E.15588
G1 X86.237 Y118.643 E.01647
G1 X82.659 Y115.065 E.15588
G1 X83.193 Y115.065 E.01647
G1 X86.771 Y118.643 E.15588
G1 X87.306 Y118.643 E.01647
G1 X83.728 Y115.065 E.15588
G1 X84.263 Y115.065 E.01647
G1 X87.841 Y118.643 E.15588
G1 X88.375 Y118.643 E.01647
G1 X84.797 Y115.065 E.15588
G1 X85.332 Y115.065 E.01647
G1 X88.91 Y118.643 E.15588
G1 X89.065 Y118.643 E.00477
G1 X89.065 Y118.263 E.0117
G1 X85.867 Y115.065 E.13933
G1 X86.401 Y115.065 E.01647
G1 X89.401 Y118.065 E.13068
G1 X89.936 Y118.065 E.01647
G1 X86.936 Y115.065 E.13068
G1 X87.471 Y115.065 E.01647
G1 X90.47 Y118.065 E.13068
G1 X91.005 Y118.065 E.01647
G1 X88.005 Y115.065 E.13068
G1 X88.54 Y115.065 E.01647
G1 X91.54 Y118.065 E.13068
G1 X92.074 Y118.065 E.01647
G1 X89.075 Y115.065 E.13068
G1 X89.609 Y115.065 E.01647
G1 X92.609 Y118.065 E.13068
G1 X93.143 Y118.065 E.01647
G1 X90.144 Y115.065 E.13068
G1 X90.679 Y115.065 E.01647
G1 X93.678 Y118.065 E.13068
G1 X94.213 Y118.065 E.01647
G1 X91.213 Y115.065 E.13068
G1 X91.748 Y115.065 E.01647
G1 X94.747 Y118.065 E.13068
G1 X95.282 Y118.065 E.01647
G1 X92.283 Y115.065 E.13068
G1 X92.817 Y115.065 E.01647
G1 X95.817 Y118.065 E.13068
G1 X96.351 Y118.065 E.01647
G1 X93.352 Y115.065 E.13068
G1 X93.887 Y115.065 E.01647
G1 X99.557 Y120.736 E.24704
G1 X100.092 Y120.736 E.01647
G1 X94.421 Y115.065 E.24704
G1 X94.956 Y115.065 E.01647
G1 X100.626 Y120.736 E.24704
G1 X101.161 Y120.736 E.01647
G1 X95.491 Y115.065 E.24704
G1 X96.025 Y115.065 E.01647
G1 X101.696 Y120.736 E.24704
G1 X102.23 Y120.736 E.01647
G1 X96.56 Y115.065 E.24704
G1 X97.095 Y115.065 E.01647
G1 X102.765 Y120.736 E.24704
G1 X103.065 Y120.736 E.00924
G1 X103.065 Y120.501 E.00723
G1 X97.629 Y115.065 E.23681
G1 X98.164 Y115.065 E.01647
G1 X103.065 Y119.966 E.21352
G1 X103.065 Y119.432 E.01647
G1 X98.699 Y115.065 E.19023
G1 X99.233 Y115.065 E.01647
G1 X103.065 Y118.897 E.16693
G1 X103.065 Y118.362 E.01647
G1 X99.768 Y115.065 E.14364
G1 X100.303 Y115.065 E.01647
G1 X103.302 Y118.065 E.13068
G1 X103.837 Y118.065 E.01647
G1 X100.837 Y115.065 E.13068
G1 X101.372 Y115.065 E.01647
G1 X104.371 Y118.065 E.13068
G1 X104.906 Y118.065 E.01647
G1 X101.906 Y115.065 E.13068
G1 X102.441 Y115.065 E.01647
G1 X105.441 Y118.065 E.13068
G1 X105.975 Y118.065 E.01647
G1 X102.976 Y115.065 E.13068
G1 X103.51 Y115.065 E.01647
G1 X106.51 Y118.065 E.13068
G1 X107.045 Y118.065 E.01647
G1 X104.045 Y115.065 E.13068
G1 X104.58 Y115.065 E.01647
G1 X107.579 Y118.065 E.13068
G1 X108.114 Y118.065 E.01647
G1 X105.114 Y115.065 E.13068
G1 X105.649 Y115.065 E.01647
G1 X108.649 Y118.065 E.13068
G1 X109.183 Y118.065 E.01647
G1 X106.184 Y115.065 E.13068
G1 X106.718 Y115.065 E.01647
G1 X109.718 Y118.065 E.13068
G1 X110.253 Y118.065 E.01647
G1 X107.253 Y115.065 E.13068
G1 X107.788 Y115.065 E.01647
G1 X113.458 Y120.736 E.24704
G1 X113.993 Y120.736 E.01647
G1 X108.322 Y115.065 E.24704
G1 X108.857 Y115.065 E.01647
G1 X114.527 Y120.736 E.24704
G1 X115.062 Y120.736 E.01647
G1 X109.392 Y115.065 E.24704
G1 X109.926 Y115.065 E.01647
G1 X115.597 Y120.736 E.24704
G1 X116.131 Y120.736 E.01647
G1 X110.461 Y115.065 E.24704
G1 X110.996 Y115.065 E.01647
G1 X116.666 Y120.736 E.24704
G1 X117.065 Y120.736 E.01229
G1 X117.065 Y120.6 E.00418
G1 X111.53 Y115.065 E.24112
G1 X112.065 Y115.065 E.01647
G1 X117.065 Y120.065 E.21783
G1 X117.065 Y119.53 E.01647
G1 X112.6 Y115.065 E.19454
M73 P47 R15
G1 X113.134 Y115.065 E.01647
G1 X117.065 Y118.996 E.17124
G1 X117.065 Y118.461 E.01647
G1 X113.669 Y115.065 E.14795
G1 X114.204 Y115.065 E.01647
G1 X117.203 Y118.065 E.13068
G1 X117.738 Y118.065 E.01647
G1 X114.738 Y115.065 E.13068
G1 X115.273 Y115.065 E.01647
G1 X118.272 Y118.065 E.13068
G1 X118.807 Y118.065 E.01647
G1 X115.808 Y115.065 E.13068
G1 X116.342 Y115.065 E.01647
G1 X119.342 Y118.065 E.13068
G1 X119.876 Y118.065 E.01647
G1 X116.877 Y115.065 E.13068
G1 X117.412 Y115.065 E.01647
G1 X120.411 Y118.065 E.13068
G1 X120.946 Y118.065 E.01647
G1 X117.946 Y115.065 E.13068
G1 X118.481 Y115.065 E.01647
G1 X121.48 Y118.065 E.13068
G1 X122.015 Y118.065 E.01647
G1 X119.016 Y115.065 E.13068
G1 X119.55 Y115.065 E.01647
G1 X122.55 Y118.065 E.13068
G1 X123.084 Y118.065 E.01647
G1 X120.085 Y115.065 E.13068
G1 X120.62 Y115.065 E.01647
G1 X123.619 Y118.065 E.13068
G1 X124.154 Y118.065 E.01647
G1 X121.154 Y115.065 E.13068
G1 X121.689 Y115.065 E.01647
G1 X127.359 Y120.736 E.24704
G1 X127.894 Y120.736 E.01647
G1 X122.223 Y115.065 E.24704
G1 X122.758 Y115.065 E.01647
G1 X128.428 Y120.736 E.24704
G1 X128.963 Y120.736 E.01647
G1 X123.293 Y115.065 E.24704
G1 X123.827 Y115.065 E.01647
G1 X129.498 Y120.736 E.24704
G1 X130.032 Y120.736 E.01647
G1 X124.362 Y115.065 E.24704
G1 X124.897 Y115.065 E.01647
G1 X130.567 Y120.736 E.24704
G1 X131.065 Y120.736 E.01533
G1 X131.065 Y120.699 E.00114
G1 X125.431 Y115.065 E.24543
G1 X125.966 Y115.065 E.01647
G1 X131.065 Y120.164 E.22214
G1 X131.065 Y119.629 E.01647
G1 X126.501 Y115.065 E.19885
G1 X127.035 Y115.065 E.01647
G1 X131.065 Y119.095 E.17555
G1 X131.065 Y118.56 E.01647
G1 X127.57 Y115.065 E.15226
G1 X128.105 Y115.065 E.01647
G1 X131.104 Y118.065 E.13068
G1 X131.639 Y118.065 E.01647
G1 X128.639 Y115.065 E.13068
G1 X129.174 Y115.065 E.01647
G1 X132.173 Y118.065 E.13068
G1 X132.708 Y118.065 E.01647
G1 X129.709 Y115.065 E.13068
G1 X130.243 Y115.065 E.01647
G1 X133.243 Y118.065 E.13068
G1 X133.777 Y118.065 E.01647
G1 X130.778 Y115.065 E.13068
G1 X131.313 Y115.065 E.01647
G1 X134.312 Y118.065 E.13068
G1 X134.847 Y118.065 E.01647
G1 X131.847 Y115.065 E.13068
G1 X132.382 Y115.065 E.01647
G1 X135.381 Y118.065 E.13068
G1 X135.916 Y118.065 E.01647
G1 X132.917 Y115.065 E.13068
G1 X133.451 Y115.065 E.01647
G1 X136.451 Y118.065 E.13068
G1 X136.985 Y118.065 E.01647
G1 X133.986 Y115.065 E.13068
G1 X134.521 Y115.065 E.01647
G1 X137.52 Y118.065 E.13068
G1 X138.055 Y118.065 E.01647
G1 X135.055 Y115.065 E.13068
G1 X135.59 Y115.065 E.01647
G1 X138.759 Y118.234 E.13807
M73 P47 R14
G1 X145.234 Y121.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y121.252 E.23226
G1 X138.935 Y121.705 E.01668
G1 X145.065 Y121.705 E.22601
G1 X145.065 Y122.157 E.01668
G1 X138.766 Y122.157 E.23226
G1 X138.766 Y120.38 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42098
G1 F15000
G1 X139.122 Y120.736 E.01551
G1 X139.656 Y120.736 E.01647
G1 X138.935 Y120.015 E.03141
G1 X138.935 Y119.48 E.01647
G1 X140.191 Y120.736 E.05471
G1 X140.726 Y120.736 E.01647
G1 X138.935 Y118.945 E.078
G1 X138.935 Y118.411 E.01647
G1 X141.26 Y120.736 E.10129
G1 X141.795 Y120.736 E.01647
G1 X136.125 Y115.065 E.24704
G1 X136.659 Y115.065 E.01647
G1 X142.33 Y120.736 E.24704
G1 X142.864 Y120.736 E.01647
G1 X137.194 Y115.065 E.24704
G1 X137.729 Y115.065 E.01647
G1 X143.399 Y120.736 E.24704
G1 X143.933 Y120.736 E.01647
G1 X138.263 Y115.065 E.24704
G1 X138.798 Y115.065 E.01647
G1 X144.468 Y120.736 E.24704
G1 X145.003 Y120.736 E.01647
G1 X139.333 Y115.065 E.24704
G1 X139.867 Y115.065 E.01647
G1 X145.065 Y120.263 E.22645
G1 X145.065 Y119.728 E.01647
G1 X140.402 Y115.065 E.20315
G1 X140.936 Y115.065 E.01647
G1 X145.065 Y119.194 E.17986
G1 X145.065 Y118.659 E.01647
G1 X141.471 Y115.065 E.15657
G1 X142.006 Y115.065 E.01647
G1 X145.065 Y118.124 E.13327
G1 X145.065 Y118.065 E.00183
G1 X145.54 Y118.065 E.01464
G1 X142.54 Y115.065 E.13068
G1 X143.075 Y115.065 E.01647
G1 X146.075 Y118.065 E.13068
G1 X146.609 Y118.065 E.01647
G1 X143.61 Y115.065 E.13068
G1 X144.144 Y115.065 E.01647
G1 X147.144 Y118.065 E.13068
G1 X147.679 Y118.065 E.01647
G1 X144.679 Y115.065 E.13068
G1 X145.214 Y115.065 E.01647
G1 X148.213 Y118.065 E.13068
G1 X148.748 Y118.065 E.01647
G1 X145.748 Y115.065 E.13068
G1 X146.283 Y115.065 E.01647
G1 X149.283 Y118.065 E.13068
G1 X149.817 Y118.065 E.01647
G1 X146.818 Y115.065 E.13068
G1 X147.352 Y115.065 E.01647
G1 X150.352 Y118.065 E.13068
G1 X150.887 Y118.065 E.01647
G1 X147.887 Y115.065 E.13068
G1 X148.422 Y115.065 E.01647
G1 X151.421 Y118.065 E.13068
G1 X151.956 Y118.065 E.01647
G1 X148.956 Y115.065 E.13068
G1 X149.491 Y115.065 E.01647
G1 X152.66 Y118.234 E.13807
G1 X159.234 Y121.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y121.252 E.23226
G1 X152.935 Y121.705 E.01668
G1 X159.065 Y121.705 E.22601
G1 X159.065 Y122.157 E.01668
G1 X152.766 Y122.157 E.23226
G1 X152.766 Y120.478 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42098
G1 F15000
G1 X153.023 Y120.736 E.0112
G1 X153.557 Y120.736 E.01647
G1 X152.935 Y120.114 E.0271
G1 X152.935 Y119.579 E.01647
G1 X154.092 Y120.736 E.0504
G1 X154.627 Y120.736 E.01647
G1 X152.935 Y119.044 E.07369
G1 X152.935 Y118.51 E.01647
G1 X155.161 Y120.736 E.09699
G1 X155.696 Y120.736 E.01647
G1 X150.026 Y115.065 E.24704
G1 X150.56 Y115.065 E.01647
G1 X156.231 Y120.736 E.24704
G1 X156.765 Y120.736 E.01647
G1 X151.095 Y115.065 E.24704
G1 X151.63 Y115.065 E.01647
G1 X157.3 Y120.736 E.24704
G1 X157.835 Y120.736 E.01647
G1 X152.164 Y115.065 E.24704
G1 X152.699 Y115.065 E.01647
G1 X158.369 Y120.736 E.24704
G1 X158.904 Y120.736 E.01647
G1 X153.234 Y115.065 E.24704
G1 X153.768 Y115.065 E.01647
G1 X159.065 Y120.362 E.23076
G1 X159.065 Y119.827 E.01647
G1 X154.303 Y115.065 E.20746
G1 X154.838 Y115.065 E.01647
G1 X159.065 Y119.293 E.18417
G1 X159.065 Y118.758 E.01647
G1 X155.372 Y115.065 E.16088
G1 X155.907 Y115.065 E.01647
G1 X159.065 Y118.223 E.13758
G1 X159.065 Y118.065 E.00488
G1 X159.441 Y118.065 E.01159
G1 X156.442 Y115.065 E.13068
G1 X156.976 Y115.065 E.01647
G1 X159.976 Y118.065 E.13068
G1 X160.51 Y118.065 E.01647
G1 X157.511 Y115.065 E.13068
G1 X158.046 Y115.065 E.01647
G1 X161.045 Y118.065 E.13068
G1 X161.58 Y118.065 E.01647
G1 X158.58 Y115.065 E.13068
G1 X159.115 Y115.065 E.01647
G1 X162.114 Y118.065 E.13068
G1 X162.649 Y118.065 E.01647
G1 X159.65 Y115.065 E.13068
G1 X160.184 Y115.065 E.01647
G1 X163.184 Y118.065 E.13068
G1 X163.718 Y118.065 E.01647
G1 X160.719 Y115.065 E.13068
G1 X161.253 Y115.065 E.01647
G1 X164.253 Y118.065 E.13068
G1 X164.788 Y118.065 E.01647
G1 X161.788 Y115.065 E.13068
G1 X162.323 Y115.065 E.01647
G1 X165.322 Y118.065 E.13068
G1 X165.857 Y118.065 E.01647
G1 X162.857 Y115.065 E.13068
G1 X163.392 Y115.065 E.01647
G1 X166.561 Y118.234 E.13807
G1 X166.766 Y118.439 F30000
G1 F15000
G1 X166.97 Y118.643 E.00891
G1 X167.505 Y118.643 E.01647
G1 X163.927 Y115.065 E.15588
G1 X164.461 Y115.065 E.01647
G1 X168.039 Y118.643 E.15588
G1 X168.574 Y118.643 E.01647
G1 X164.996 Y115.065 E.15588
G1 X165.531 Y115.065 E.01647
G1 X169.109 Y118.643 E.15588
G1 X169.643 Y118.643 E.01647
G1 X166.065 Y115.065 E.15588
G1 X166.6 Y115.065 E.01647
G1 X170.178 Y118.643 E.15588
G1 X170.713 Y118.643 E.01647
G1 X167.135 Y115.065 E.15588
G1 X167.669 Y115.065 E.01647
G1 X171.247 Y118.643 E.15588
G1 X171.782 Y118.643 E.01647
G1 X168.204 Y115.065 E.15588
G1 X168.739 Y115.065 E.01647
G1 X172.317 Y118.643 E.15588
G1 X172.851 Y118.643 E.01647
G1 X169.273 Y115.065 E.15588
G1 X169.808 Y115.065 E.01647
G1 X173.386 Y118.643 E.15588
G1 X173.921 Y118.643 E.01647
G1 X170.343 Y115.065 E.15588
G1 X170.877 Y115.065 E.01647
G1 X174.455 Y118.643 E.15588
G1 X174.99 Y118.643 E.01647
G1 X171.412 Y115.065 E.15588
G1 X171.947 Y115.065 E.01647
G1 X175.525 Y118.643 E.15588
G1 X176.059 Y118.643 E.01647
G1 X172.481 Y115.065 E.15588
G1 X173.016 Y115.065 E.01647
G1 X176.594 Y118.643 E.15588
G1 X177.129 Y118.643 E.01647
G1 X173.551 Y115.065 E.15588
G1 X174.085 Y115.065 E.01647
G1 X177.663 Y118.643 E.15588
G1 X178.198 Y118.643 E.01647
G1 X174.62 Y115.065 E.15588
G1 X175.155 Y115.065 E.01647
G1 X178.733 Y118.643 E.15588
G1 X179.267 Y118.643 E.01647
G1 X175.689 Y115.065 E.15588
G1 X176.224 Y115.065 E.01647
G1 X179.802 Y118.643 E.15588
G1 X180.337 Y118.643 E.01647
G1 X176.759 Y115.065 E.15588
G1 X177.293 Y115.065 E.01647
G1 X180.871 Y118.643 E.15588
G1 X181.406 Y118.643 E.01647
G1 X177.828 Y115.065 E.15588
G1 X178.363 Y115.065 E.01647
G1 X181.94 Y118.643 E.15588
G1 X182.475 Y118.643 E.01647
G1 X178.897 Y115.065 E.15588
G1 X179.432 Y115.065 E.01647
G1 X183.01 Y118.643 E.15588
G1 X183.065 Y118.643 E.00169
G1 X183.065 Y118.164 E.01478
G1 X179.967 Y115.065 E.13499
G1 X180.501 Y115.065 E.01647
G1 X183.065 Y117.629 E.11169
G1 X183.065 Y117.094 E.01647
G1 X181.036 Y115.065 E.0884
G1 X181.57 Y115.065 E.01647
G1 X183.065 Y116.56 E.0651
G1 X183.065 Y116.025 E.01647
G1 X182.105 Y115.065 E.04181
G1 X182.64 Y115.065 E.01647
G1 X183.234 Y115.66 E.02591
G1 X182.208 Y120.428 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.05 Y120.428 E.02793
G1 X183.05 Y119.642 E.02608
G1 X182.443 Y119.035 E.02846
G1 X181.02 Y119.035 E.0472
G1 X179.627 Y120.428 E.06535
G1 X176.16 Y120.428 E.11502
G1 X174.767 Y119.035 E.06535
G1 X173.344 Y119.035 E.0472
G1 X171.951 Y120.428 E.06535
G1 X168.484 Y120.428 E.11502
G1 X167.091 Y119.035 E.06535
G1 X168.719 Y119.035 E.05401
G1 X166.952 Y120.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y120.778 E.4443
G1 X183.234 Y121.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y121.252 E.60098
G1 X166.935 Y121.705 E.01668
G1 X183.065 Y121.705 E.59472
G1 X183.065 Y122.157 E.01668
G1 X166.766 Y122.157 E.60098
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X168.766 Y122.157 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/32
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.6 I-.878 J.843 P1  F30000
G1 X183.398 Y137.398 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y137.398 E3.6753
G1 X72.602 Y136.299 E.03645
G1 X72.602 Y135.899 E.01327
G1 F14852.35
G1 X72.602 Y135.839 E.00199
G1 F13500
G1 X183.398 Y135.839 E3.6753
G1 F14852.35
G1 X183.398 Y135.899 E.00199
G1 F15476.087
G1 X183.398 Y136.299 E.01327
G1 X183.398 Y137.338 E.03446
M204 S250
G1 X183.79 Y137.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y137.79 E3.42854
G1 X72.21 Y136.686 E.03394
G1 X72.21 Y136.286 E.01229
G1 F6459.938
G1 X72.21 Y135.886 E.01229
G1 F1800
G1 X72.21 Y135.517 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y135.447 E.0023
G1 X183.79 Y135.447 E3.70131
G1 X183.79 Y135.517 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y135.886 E.01134
G1 F6459.938
G1 X183.79 Y136.286 E.01229
G1 F12000
G1 X183.79 Y136.686 E.01229
G1 X183.79 Y137.73 E.03209
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X181.79 Y137.731 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X174.158 Y137.626 Z2.8 F30000
G1 X72.994 Y136.231 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X72.994 Y137.006 E.0238
G1 X183.006 Y137.006 E3.38027
G1 X183.006 Y136.231 E.0238
G1 X73.054 Y136.231 E3.37842
G1 X73.381 Y136.619 F30000
; LINE_WIDTH: 0.44044
G1 F15000
G1 X182.559 Y136.619 E3.53656
; WIPE_START
G1 X180.559 Y136.619 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I.423 J-1.141 P1  F30000
G1 X131.398 Y118.398 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y121.748 E.11111
G1 X131.398 Y122.148 E.01327
G1 F14331.075
G1 X131.398 Y122.548 E.01327
G1 F6685.538
G1 X131.398 Y122.948 E.01327
G1 F1920
G1 X131.398 Y123.328 E.01262
G1 F600
G1 X124.602 Y123.328 E.22543
G1 F1920
G1 X124.602 Y122.948 E.01262
G1 F6685.538
G1 X124.602 Y122.548 E.01327
G1 F14331.075
G1 X124.602 Y122.148 E.01327
G1 F15476.087
G1 X124.602 Y121.748 E.01327
G1 X124.602 Y118.398 E.11111
G1 X117.398 Y118.398 E.23897
G1 X117.398 Y121.748 E.11111
G1 X117.398 Y122.148 E.01327
G1 F14331.075
G1 X117.398 Y122.548 E.01327
G1 F6685.538
G1 X117.398 Y122.948 E.01327
G1 F1920
G1 X117.398 Y123.328 E.01262
G1 F600
G1 X110.602 Y123.328 E.22543
G1 F1920
G1 X110.602 Y122.948 E.01262
G1 F6685.538
G1 X110.602 Y122.548 E.01327
G1 F14331.075
G1 X110.602 Y122.148 E.01327
G1 F15476.087
G1 X110.602 Y121.748 E.01327
G1 X110.602 Y118.398 E.11111
G1 X103.398 Y118.398 E.23897
G1 X103.398 Y121.748 E.11111
G1 X103.398 Y122.148 E.01327
G1 F14331.075
G1 X103.398 Y122.548 E.01327
G1 F6685.538
G1 X103.398 Y122.948 E.01327
G1 F1920
G1 X103.398 Y123.328 E.01262
G1 F600
G1 X96.602 Y123.328 E.22543
G1 F1920
G1 X96.602 Y122.948 E.01262
G1 F6685.538
G1 X96.602 Y122.548 E.01327
G1 F14331.075
G1 X96.602 Y122.148 E.01327
G1 F15476.087
G1 X96.602 Y121.748 E.01327
G1 X96.602 Y118.398 E.11111
G1 X89.398 Y118.398 E.23897
G1 X89.398 Y121.748 E.11111
G1 X89.398 Y122.148 E.01327
G1 F14331.075
G1 X89.398 Y122.548 E.01327
G1 F6685.538
G1 X89.398 Y122.948 E.01327
G1 F1920
G1 X89.398 Y123.328 E.01262
M73 P48 R14
G1 F600
G1 X72.602 Y123.328 E.55715
G1 F1920
G1 X72.602 Y122.948 E.01262
G1 F6685.538
G1 X72.602 Y122.548 E.01327
G1 F14331.075
G1 X72.602 Y122.148 E.01327
G1 F15476.087
G1 X72.602 Y121.748 E.01327
G1 X72.602 Y116.208 E.18376
G1 X183.398 Y116.208 E3.6753
G1 X183.398 Y121.748 E.18376
G1 X183.398 Y122.148 E.01327
G1 F14331.075
G1 X183.398 Y122.548 E.01327
G1 F6685.538
G1 X183.398 Y122.948 E.01327
G1 F1920
G1 X183.398 Y123.328 E.01262
G1 F600
G1 X166.602 Y123.328 E.55715
G1 F1920
G1 X166.602 Y122.948 E.01262
G1 F6685.538
G1 X166.602 Y122.548 E.01327
G1 F14331.075
G1 X166.602 Y122.148 E.01327
G1 F15476.087
G1 X166.602 Y121.748 E.01327
G1 X166.602 Y118.398 E.11111
G1 X159.398 Y118.398 E.23897
G1 X159.398 Y121.748 E.11111
G1 X159.398 Y122.148 E.01327
G1 F14331.075
G1 X159.398 Y122.548 E.01327
G1 F6685.538
G1 X159.398 Y122.948 E.01327
G1 F1920
G1 X159.398 Y123.328 E.01262
G1 F600
G1 X152.602 Y123.328 E.22543
G1 F1920
G1 X152.602 Y122.948 E.01262
G1 F6685.538
G1 X152.602 Y122.548 E.01327
G1 F14331.075
G1 X152.602 Y122.148 E.01327
G1 F15476.087
G1 X152.602 Y121.748 E.01327
G1 X152.602 Y118.398 E.11111
G1 X145.398 Y118.398 E.23897
G1 X145.398 Y121.748 E.11111
G1 X145.398 Y122.148 E.01327
G1 F14331.075
G1 X145.398 Y122.548 E.01327
G1 F6685.538
G1 X145.398 Y122.948 E.01327
G1 F1920
G1 X145.398 Y123.328 E.01262
G1 F600
G1 X138.602 Y123.328 E.22543
G1 F1920
G1 X138.602 Y122.948 E.01262
G1 F6685.538
G1 X138.602 Y122.548 E.01327
G1 F14331.075
G1 X138.602 Y122.148 E.01327
G1 F15476.087
G1 X138.602 Y121.748 E.01327
G1 X138.602 Y118.398 E.11111
G1 X131.458 Y118.398 E.23698
M204 S250
G1 X131.79 Y118.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y122.161 E.10358
G1 X131.79 Y122.561 E.01229
G1 F6459.938
G1 X131.79 Y122.961 E.01229
G1 F1800
G1 X131.79 Y123.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y123.72 E.01294
G1 X124.21 Y123.72 E.25144
G1 X124.21 Y123.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y122.961 E.01134
G1 F6459.938
G1 X124.21 Y122.561 E.01229
G1 F12000
G1 X124.21 Y122.161 E.01229
G1 X124.21 Y118.79 E.10358
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y122.161 E.10358
G1 X117.79 Y122.561 E.01229
G1 F6459.938
G1 X117.79 Y122.961 E.01229
G1 F1800
G1 X117.79 Y123.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y123.72 E.01294
G1 X110.21 Y123.72 E.25144
G1 X110.21 Y123.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y122.961 E.01134
G1 F6459.938
G1 X110.21 Y122.561 E.01229
G1 F12000
G1 X110.21 Y122.161 E.01229
G1 X110.21 Y118.79 E.10358
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y122.161 E.10358
G1 X103.79 Y122.561 E.01229
G1 F6459.938
G1 X103.79 Y122.961 E.01229
G1 F1800
G1 X103.79 Y123.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y123.72 E.01294
G1 X96.21 Y123.72 E.25144
M73 P49 R14
G1 X96.21 Y123.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y122.961 E.01134
G1 F6459.938
G1 X96.21 Y122.561 E.01229
G1 F12000
G1 X96.21 Y122.161 E.01229
G1 X96.21 Y118.79 E.10358
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y122.161 E.10358
G1 X89.79 Y122.561 E.01229
G1 F6459.938
G1 X89.79 Y122.961 E.01229
G1 F1800
G1 X89.79 Y123.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y123.72 E.01294
G1 X72.21 Y123.72 E.58316
G1 X72.21 Y123.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y122.961 E.01134
G1 F6459.938
G1 X72.21 Y122.561 E.01229
G1 F12000
G1 X72.21 Y122.161 E.01229
G1 X72.21 Y114.588 E.23271
G1 X183.79 Y114.588 E3.42854
G1 X183.79 Y122.161 E.23271
G1 X183.79 Y122.561 E.01229
G1 F6459.938
G1 X183.79 Y122.961 E.01229
G1 F1800
G1 X183.79 Y123.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y123.72 E.01294
G1 F600
G1 X166.21 Y123.72 E.58316
G1 X166.21 Y123.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y122.961 E.01134
G1 F6459.938
G1 X166.21 Y122.561 E.01229
G1 F12000
G1 X166.21 Y122.161 E.01229
G1 X166.21 Y118.79 E.10358
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y122.161 E.10358
G1 X159.79 Y122.561 E.01229
G1 F6459.938
G1 X159.79 Y122.961 E.01229
G1 F1800
G1 X159.79 Y123.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y123.72 E.01294
G1 X152.21 Y123.72 E.25144
G1 X152.21 Y123.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y122.961 E.01134
G1 F6459.938
G1 X152.21 Y122.561 E.01229
G1 F12000
G1 X152.21 Y122.161 E.01229
G1 X152.21 Y118.79 E.10358
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y122.161 E.10358
G1 X145.79 Y122.561 E.01229
G1 F6459.938
G1 X145.79 Y122.961 E.01229
G1 F1800
G1 X145.79 Y123.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y123.72 E.01294
G1 X138.21 Y123.72 E.25144
G1 X138.21 Y123.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y122.961 E.01134
G1 F6459.938
G1 X138.21 Y122.561 E.01229
G1 F12000
G1 X138.21 Y122.161 E.01229
G1 X138.21 Y118.79 E.10358
G1 X131.85 Y118.79 E.19542
; WIPE_START
M204 S10000
G1 X131.814 Y120.79 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.234 Y122.052 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y122.052 E.23226
G1 X124.935 Y122.505 E.01668
G1 X131.065 Y122.505 E.22601
G1 X131.065 Y122.957 E.01668
G1 X124.766 Y122.957 E.23226
G1 X124.952 Y121.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y121.578 E.16725
G1 X129.276 Y121.228 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X130.904 Y121.228 E.05401
G1 X128.711 Y119.035 E.10288
G1 X127.289 Y119.035 E.04719
G1 X125.096 Y121.228 E.10288
G1 X124.95 Y121.228 E.00482
G1 X124.95 Y119.745 E.0492
; WIPE_START
G1 X124.95 Y121.228 E-.56357
G1 X125.096 Y121.228 E-.05519
G1 X125.358 Y120.966 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X117.727 Y121.087 Z2.8 F30000
G1 X117.05 Y121.097 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F15476.087
G1 X117.05 Y121.228 E.00435
G1 X115.553 Y121.228 E.04966
G1 X113.359 Y119.035 E.10288
G1 X111.937 Y119.035 E.04719
G1 X110.95 Y120.022 E.04628
G1 X110.95 Y121.228 E.04003
G1 X111.372 Y121.228 E.01399
G1 X110.952 Y121.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y121.578 E.16725
G1 X117.234 Y122.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y122.052 E.23226
G1 X110.935 Y122.505 E.01668
G1 X117.065 Y122.505 E.22601
G1 X117.065 Y122.957 E.01668
G1 X110.766 Y122.957 E.23226
; WIPE_START
G1 X112.766 Y122.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I.115 J-1.212 P1  F30000
G1 X103.234 Y122.052 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F3000
G1 X96.935 Y122.052 E.23226
G1 X96.935 Y122.505 E.01668
G1 X103.065 Y122.505 E.22601
G1 X103.065 Y122.957 E.01668
G1 X96.766 Y122.957 E.23226
G1 X96.952 Y121.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y121.578 E.16725
G1 X96.95 Y119.607 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X96.95 Y119.035 E.01895
G1 X98.007 Y119.035 E.03507
G1 X100.201 Y121.228 E.10289
G1 X102.068 Y121.228 E.06193
G1 X103.05 Y120.246 E.04607
G1 X103.05 Y119.035 E.04018
G1 X102.633 Y119.035 E.01384
; WIPE_START
G1 X103.05 Y119.035 E-.15852
G1 X103.05 Y120.246 E-.46024
G1 X102.787 Y120.509 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X95.154 Y120.517 Z2.8 F30000
G1 X89.05 Y120.523 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F15476.087
G1 X89.05 Y119.835 E.02281
G1 X88.109 Y119.835 E.03121
G1 X86.716 Y121.228 E.06536
G1 X84.849 Y121.228 E.06193
G1 X83.456 Y119.835 E.06536
G1 X80.433 Y119.835 E.10027
G1 X79.04 Y121.228 E.06536
G1 X77.173 Y121.228 E.06193
G1 X75.78 Y119.835 E.06536
G1 X74.151 Y119.835 E.05401
G1 X72.952 Y121.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y121.578 E.4443
G1 X89.234 Y122.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y122.052 E.60098
G1 X72.935 Y122.505 E.01668
G1 X89.065 Y122.505 E.59472
G1 X89.065 Y122.957 E.01668
G1 X72.766 Y122.957 E.60098
; WIPE_START
G1 X74.766 Y122.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I0 J1.217 P1  F30000
G1 X138.766 Y122.957 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F3000
G1 X145.065 Y122.957 E.23226
G1 X145.065 Y122.505 E.01668
G1 X138.935 Y122.505 E.22601
G1 X138.935 Y122.052 E.01668
G1 X145.234 Y122.052 E.23226
G1 X144.628 Y121.228 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X145.05 Y121.228 E.01399
G1 X145.05 Y120.022 E.04003
G1 X144.063 Y119.035 E.04628
G1 X142.641 Y119.035 E.04719
G1 X140.447 Y121.228 E.10288
G1 X138.95 Y121.228 E.04966
G1 X138.95 Y121.097 E.00435
G1 X138.952 Y121.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y121.578 E.16725
; WIPE_START
G1 X142.988 Y121.578 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I-.17 J1.205 P1  F30000
G1 X152.766 Y122.957 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X159.065 Y122.957 E.23226
G1 X159.065 Y122.505 E.01668
G1 X152.935 Y122.505 E.22601
G1 X152.935 Y122.052 E.01668
G1 X159.234 Y122.052 E.23226
G1 X152.952 Y121.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y121.578 E.16725
G1 X153.367 Y119.035 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X152.95 Y119.035 E.01384
G1 X152.95 Y120.247 E.04018
G1 X153.932 Y121.228 E.04607
G1 X155.799 Y121.228 E.06193
G1 X157.993 Y119.035 E.10288
G1 X159.05 Y119.035 E.03507
G1 X159.05 Y119.607 E.01895
; WIPE_START
G1 X159.05 Y119.035 E-.21704
G1 X157.993 Y119.035 E-.40172
G1 X157.73 Y119.298 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X165.139 Y121.13 Z2.8 F30000
G1 X166.952 Y121.578 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y121.578 E.4443
G1 X183.234 Y122.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y122.052 E.60098
G1 X166.935 Y122.505 E.01668
G1 X183.065 Y122.505 E.59472
G1 X183.065 Y122.957 E.01668
G1 X166.766 Y122.957 E.60098
G1 X181.849 Y119.835 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.22 Y119.835 E.05401
G1 X178.827 Y121.228 E.06536
G1 X176.96 Y121.228 E.06193
G1 X175.567 Y119.835 E.06536
G1 X172.544 Y119.835 E.10026
G1 X171.151 Y121.228 E.06536
G1 X169.284 Y121.228 E.06193
G1 X167.891 Y119.835 E.06536
G1 X166.95 Y119.835 E.03121
G1 X166.95 Y120.523 E.02281
G1 X183.006 Y119.443 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y116.6 E.08737
G1 X72.994 Y116.6 E3.38027
G1 X72.994 Y119.443 E.08737
G1 X89.006 Y119.443 E.49198
G1 X89.006 Y118.194 E.03837
G1 X89.054 Y118.069 E.00412
G1 X89.194 Y118.006 E.00475
G1 X96.806 Y118.006 E.23386
G1 X96.972 Y118.105 E.00595
G1 X96.994 Y118.643 E.01655
G1 X103.006 Y118.643 E.18472
G1 X103.028 Y118.105 E.01655
G1 X103.194 Y118.006 E.00595
G1 X110.806 Y118.006 E.23386
G1 X110.972 Y118.105 E.00595
G1 X110.994 Y118.643 E.01655
G1 X117.006 Y118.643 E.18472
G1 X117.028 Y118.105 E.01655
G1 X117.194 Y118.006 E.00595
G1 X124.806 Y118.006 E.23386
G1 X124.972 Y118.105 E.00595
G1 X124.994 Y118.643 E.01655
G1 X131.006 Y118.643 E.18472
G1 X131.028 Y118.105 E.01655
G1 X131.194 Y118.006 E.00595
G1 X138.806 Y118.006 E.23386
G1 X138.972 Y118.105 E.00595
G1 X138.994 Y118.643 E.01655
G1 X145.006 Y118.643 E.18472
G1 X145.028 Y118.105 E.01655
G1 X145.194 Y118.006 E.00595
G1 X152.806 Y118.006 E.23386
G1 X152.972 Y118.105 E.00595
G1 X152.994 Y118.643 E.01655
G1 X159.006 Y118.643 E.18472
G1 X159.028 Y118.105 E.01655
G1 X159.194 Y118.006 E.00595
G1 X166.806 Y118.006 E.23386
M73 P50 R14
G1 X166.946 Y118.069 E.00475
G1 X166.994 Y118.194 E.00412
G1 X166.994 Y119.443 E.03837
G1 X182.946 Y119.443 E.49014
G1 X182.629 Y118.022 F30000
G1 F12000
G1 X182.629 Y116.977 E.0321
G1 X167.606 Y116.977 E.4616
; LINE_WIDTH: 0.44289
G1 X167.339 Y117 E.00873
; LINE_WIDTH: 0.48869
G1 X167.072 Y117.023 E.00973
; LINE_WIDTH: 0.556612
G1 X166.806 Y117.046 E.01121
G1 X159.194 Y117.046 E.3186
; LINE_WIDTH: 0.53449
G1 X158.839 Y117.023 E.01426
; LINE_WIDTH: 0.48869
G1 X158.484 Y117 E.01294
; LINE_WIDTH: 0.421758
G1 X158.128 Y116.977 E.01099
G1 X153.872 Y116.977 E.1314
; LINE_WIDTH: 0.44289
G1 X153.516 Y117 E.01161
; LINE_WIDTH: 0.48869
G1 X153.161 Y117.023 E.01294
; LINE_WIDTH: 0.556367
G1 X152.806 Y117.046 E.0149
G1 X145.194 Y117.046 E.31845
; LINE_WIDTH: 0.53449
G1 X144.839 Y117.023 E.01426
; LINE_WIDTH: 0.48869
G1 X144.484 Y117 E.01294
; LINE_WIDTH: 0.421758
G1 X144.128 Y116.977 E.01099
G1 X139.872 Y116.977 E.1314
; LINE_WIDTH: 0.44289
G1 X139.516 Y117 E.01161
; LINE_WIDTH: 0.48869
G1 X139.161 Y117.023 E.01294
; LINE_WIDTH: 0.556367
G1 X138.806 Y117.046 E.0149
G1 X131.194 Y117.046 E.31845
; LINE_WIDTH: 0.53449
G1 X130.839 Y117.023 E.01426
; LINE_WIDTH: 0.48869
G1 X130.484 Y117 E.01294
; LINE_WIDTH: 0.421758
G1 X130.128 Y116.977 E.01099
G1 X125.872 Y116.977 E.13141
; LINE_WIDTH: 0.44289
G1 X125.516 Y117 E.01161
; LINE_WIDTH: 0.48869
G1 X125.161 Y117.023 E.01294
; LINE_WIDTH: 0.556367
G1 X124.806 Y117.046 E.0149
G1 X117.194 Y117.046 E.31845
; LINE_WIDTH: 0.53449
G1 X116.839 Y117.023 E.01426
; LINE_WIDTH: 0.48869
G1 X116.484 Y117 E.01294
; LINE_WIDTH: 0.421758
G1 X116.128 Y116.977 E.01099
G1 X111.872 Y116.977 E.1314
; LINE_WIDTH: 0.44289
G1 X111.516 Y117 E.01161
; LINE_WIDTH: 0.48869
G1 X111.161 Y117.023 E.01294
; LINE_WIDTH: 0.556367
G1 X110.806 Y117.046 E.0149
G1 X103.194 Y117.046 E.31845
; LINE_WIDTH: 0.53449
G1 X102.839 Y117.023 E.01426
; LINE_WIDTH: 0.48869
G1 X102.484 Y117 E.01294
; LINE_WIDTH: 0.421758
G1 X102.128 Y116.977 E.01099
G1 X97.872 Y116.977 E.1314
; LINE_WIDTH: 0.44289
G1 X97.516 Y117 E.01161
; LINE_WIDTH: 0.48869
G1 X97.161 Y117.023 E.01294
; LINE_WIDTH: 0.556367
G1 X96.806 Y117.046 E.0149
G1 X89.194 Y117.046 E.31845
; LINE_WIDTH: 0.53449
G1 X88.928 Y117.023 E.01073
; LINE_WIDTH: 0.48869
G1 X88.661 Y117 E.00973
; LINE_WIDTH: 0.420171
G1 X88.394 Y116.977 E.00823
G1 X73.371 Y116.977 E.46182
G1 X73.371 Y119.066 E.06423
G1 X88.629 Y119.066 E.46904
G1 X88.629 Y118.194 E.0268
G1 X88.772 Y117.819 E.01236
; LINE_WIDTH: 0.444015
G1 X88.876 Y117.734 E.00437
; LINE_WIDTH: 0.492065
G1 X88.98 Y117.65 E.0049
; LINE_WIDTH: 0.557143
G3 X89.194 Y117.56 I.17 J.104 E.01041
G1 X96.806 Y117.56 E.31893
; LINE_WIDTH: 0.53449
G1 X96.972 Y117.682 E.00826
; LINE_WIDTH: 0.48869
G1 X97.138 Y117.805 E.00749
; LINE_WIDTH: 0.420757
G1 X97.304 Y117.927 E.00635
G1 X97.371 Y118.266 E.01066
G1 X102.629 Y118.266 E.16188
G1 X102.696 Y117.927 E.01066
; LINE_WIDTH: 0.444015
G1 X102.826 Y117.807 E.00577
; LINE_WIDTH: 0.492065
G1 X102.955 Y117.686 E.00646
; LINE_WIDTH: 0.557051
G1 X103.084 Y117.566 E.0074
G1 X103.194 Y117.56 E.00462
G1 X110.806 Y117.56 E.31887
; LINE_WIDTH: 0.53449
G1 X110.972 Y117.682 E.00826
; LINE_WIDTH: 0.48869
G1 X111.138 Y117.805 E.00749
; LINE_WIDTH: 0.420757
G1 X111.304 Y117.927 E.00635
G1 X111.371 Y118.266 E.01066
G1 X116.629 Y118.266 E.16188
G1 X116.696 Y117.927 E.01066
; LINE_WIDTH: 0.444015
G1 X116.826 Y117.807 E.00577
; LINE_WIDTH: 0.492065
G1 X116.955 Y117.686 E.00646
; LINE_WIDTH: 0.557051
G1 X117.084 Y117.566 E.0074
G1 X117.194 Y117.56 E.00462
G1 X124.806 Y117.56 E.31887
; LINE_WIDTH: 0.53449
G1 X124.972 Y117.682 E.00826
; LINE_WIDTH: 0.48869
G1 X125.138 Y117.805 E.00749
; LINE_WIDTH: 0.420757
G1 X125.304 Y117.927 E.00635
G1 X125.371 Y118.266 E.01066
G1 X130.629 Y118.266 E.16188
G1 X130.696 Y117.927 E.01066
; LINE_WIDTH: 0.444015
G1 X130.826 Y117.807 E.00577
; LINE_WIDTH: 0.492065
G1 X130.955 Y117.686 E.00646
; LINE_WIDTH: 0.557051
G1 X131.084 Y117.566 E.0074
G1 X131.194 Y117.56 E.00462
G1 X138.806 Y117.56 E.31887
; LINE_WIDTH: 0.53449
G1 X138.972 Y117.682 E.00826
; LINE_WIDTH: 0.48869
G1 X139.138 Y117.805 E.00749
; LINE_WIDTH: 0.420757
G1 X139.304 Y117.927 E.00635
G1 X139.371 Y118.266 E.01066
G1 X144.629 Y118.266 E.16188
G1 X144.696 Y117.927 E.01066
; LINE_WIDTH: 0.444015
G1 X144.826 Y117.807 E.00577
; LINE_WIDTH: 0.492065
G1 X144.955 Y117.686 E.00646
; LINE_WIDTH: 0.557051
G1 X145.084 Y117.566 E.0074
G1 X145.194 Y117.56 E.00462
G1 X152.806 Y117.56 E.31887
; LINE_WIDTH: 0.53449
G1 X152.972 Y117.682 E.00826
; LINE_WIDTH: 0.48869
G1 X153.138 Y117.805 E.00749
; LINE_WIDTH: 0.420757
G1 X153.304 Y117.927 E.00635
G1 X153.371 Y118.266 E.01066
G1 X158.629 Y118.266 E.16188
G1 X158.696 Y117.927 E.01066
; LINE_WIDTH: 0.444015
G1 X158.826 Y117.807 E.00577
; LINE_WIDTH: 0.492065
G1 X158.955 Y117.686 E.00646
; LINE_WIDTH: 0.557051
G1 X159.084 Y117.566 E.0074
G1 X159.194 Y117.56 E.00462
G1 X166.806 Y117.56 E.31887
; LINE_WIDTH: 0.53449
G1 X166.946 Y117.646 E.00661
; LINE_WIDTH: 0.48869
G1 X167.087 Y117.732 E.006
; LINE_WIDTH: 0.420204
G1 X167.228 Y117.819 E.00508
G1 X167.371 Y118.194 E.01236
G1 X167.371 Y119.066 E.0268
G1 X182.629 Y119.066 E.46908
G1 X182.629 Y118.082 E.03027
G1 X182.252 Y118.022 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.252 Y117.354 E.02051
G1 X167.033 Y117.354 E.46761
G1 X167.51 Y117.568 E.01605
G1 X167.743 Y118.093 E.01765
G1 X167.748 Y118.689 E.01831
G1 X182.252 Y118.689 E.44564
G1 X182.252 Y118.082 E.01867
G1 X181.824 Y118.022 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y117.782 E.00935
G1 X168.051 Y117.782 E.53762
G1 X168.168 Y118.047 E.01132
G1 X168.176 Y118.261 E.00835
G1 X181.824 Y118.261 E.53272
G1 X181.824 Y118.082 E.00701
G1 X158.794 Y117.394 F30000
; LINE_WIDTH: 0.499015
G1 F12000
G1 X153.109 Y117.394 E.2113
G1 X153.671 Y117.73 E.02434
G1 X153.701 Y117.85 E.0046
G1 X158.299 Y117.85 E.17089
G1 X158.329 Y117.73 E.0046
G1 X158.746 Y117.429 E.01909
G1 X144.794 Y117.394 F30000
G1 F12000
G1 X139.109 Y117.394 E.2113
G1 X139.671 Y117.73 E.02434
G1 X139.701 Y117.85 E.0046
G1 X144.299 Y117.85 E.17089
G1 X144.329 Y117.73 E.0046
G1 X144.746 Y117.429 E.01909
G1 X130.794 Y117.394 F30000
G1 F12000
G1 X125.109 Y117.394 E.21131
G1 X125.671 Y117.73 E.02434
G1 X125.701 Y117.85 E.0046
G1 X130.299 Y117.85 E.17089
G1 X130.329 Y117.73 E.0046
G1 X130.746 Y117.429 E.01909
G1 X116.794 Y117.394 F30000
G1 F12000
G1 X111.109 Y117.394 E.2113
G1 X111.671 Y117.73 E.02434
G1 X111.701 Y117.85 E.0046
G1 X116.299 Y117.85 E.17089
G1 X116.329 Y117.73 E.0046
G1 X116.746 Y117.429 E.01909
G1 X102.794 Y117.394 F30000
G1 F12000
G1 X97.109 Y117.394 E.2113
G1 X97.671 Y117.73 E.02434
G1 X97.701 Y117.85 E.0046
G1 X102.299 Y117.85 E.17089
G1 X102.329 Y117.73 E.0046
G1 X102.746 Y117.429 E.01909
G1 X88.874 Y117.354 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X73.748 Y117.354 E.46475
G1 X73.748 Y118.689 E.04102
G1 X88.252 Y118.689 E.44564
G1 X88.257 Y118.093 E.01831
G1 X88.49 Y117.568 E.01765
G1 X88.821 Y117.383 E.01165
G1 X87.949 Y117.782 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X74.176 Y117.782 E.53762
G1 X74.176 Y118.261 E.0187
G1 X87.824 Y118.261 E.53272
G3 X87.925 Y117.837 I.581 J-.086 E.01744
; WIPE_START
G1 X87.832 Y118.047 E-.08744
G1 X87.824 Y118.261 E-.08131
G1 X86.268 Y118.261 E-.59125
; WIPE_END
G1 E-.04 F1800
G1 X93.898 Y118.082 Z2.8 F30000
G1 X183.075 Y115.985 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.583 Y115.478 E.02206
G1 X183.583 Y114.944
G1 X182.542 Y115.985 E.04524
G1 X182.008 Y115.985
G1 X183.199 Y114.795 E.05173
G1 X182.666 Y114.795
G1 X181.475 Y115.985 E.05173
G1 X180.942 Y115.985
G1 X182.132 Y114.795 E.05173
G1 X181.599 Y114.795
G1 X180.409 Y115.985 E.05173
G1 X179.875 Y115.985
G1 X181.066 Y114.795 E.05173
G1 X180.532 Y114.795
G1 X179.342 Y115.985 E.05173
G1 X178.809 Y115.985
G1 X179.999 Y114.795 E.05173
G1 X179.466 Y114.795
G1 X178.276 Y115.985 E.05173
G1 X177.742 Y115.985
G1 X178.933 Y114.795 E.05173
G1 X178.399 Y114.795
G1 X177.209 Y115.985 E.05173
G1 X176.676 Y115.985
G1 X177.866 Y114.795 E.05173
G1 X177.333 Y114.795
G1 X176.143 Y115.985 E.05173
G1 X175.609 Y115.985
G1 X176.8 Y114.795 E.05173
G1 X176.266 Y114.795
G1 X175.076 Y115.985 E.05173
G1 X174.543 Y115.985
G1 X175.733 Y114.795 E.05173
G1 X175.2 Y114.795
G1 X174.01 Y115.985 E.05173
G1 X173.476 Y115.985
G1 X174.667 Y114.795 E.05173
G1 X174.133 Y114.795
G1 X172.943 Y115.985 E.05173
G1 X172.41 Y115.985
G1 X173.6 Y114.795 E.05173
G1 X173.067 Y114.795
G1 X171.876 Y115.985 E.05173
G1 X171.343 Y115.985
G1 X172.534 Y114.795 E.05173
G1 X172 Y114.795
G1 X170.81 Y115.985 E.05173
G1 X170.277 Y115.985
G1 X171.467 Y114.795 E.05173
G1 X170.934 Y114.795
G1 X169.743 Y115.985 E.05173
G1 X169.21 Y115.985
G1 X170.401 Y114.795 E.05173
G1 X169.867 Y114.795
G1 X168.677 Y115.985 E.05173
G1 X168.144 Y115.985
G1 X169.334 Y114.795 E.05173
G1 X168.801 Y114.795
G1 X167.61 Y115.985 E.05173
G1 X167.077 Y115.985
G1 X168.268 Y114.795 E.05173
G1 X167.734 Y114.795
G1 X166.544 Y115.985 E.05173
G1 X166.011 Y115.985
G1 X167.201 Y114.795 E.05173
G1 X166.668 Y114.795
G1 X165.477 Y115.985 E.05173
G1 X164.944 Y115.985
G1 X166.135 Y114.795 E.05173
G1 X165.601 Y114.795
G1 X164.411 Y115.985 E.05173
G1 X163.878 Y115.985
G1 X165.068 Y114.795 E.05173
G1 X164.535 Y114.795
G1 X163.344 Y115.985 E.05173
G1 X162.811 Y115.985
G1 X164.001 Y114.795 E.05173
G1 X163.468 Y114.795
G1 X162.278 Y115.985 E.05173
G1 X161.745 Y115.985
G1 X162.935 Y114.795 E.05173
G1 X162.402 Y114.795
G1 X161.211 Y115.985 E.05173
G1 X160.678 Y115.985
G1 X161.868 Y114.795 E.05173
G1 X161.335 Y114.795
G1 X160.145 Y115.985 E.05173
G1 X159.612 Y115.985
G1 X160.802 Y114.795 E.05173
G1 X160.269 Y114.795
G1 X159.078 Y115.985 E.05173
G1 X158.545 Y115.985
G1 X159.735 Y114.795 E.05173
G1 X159.202 Y114.795
G1 X158.012 Y115.985 E.05173
G1 X157.479 Y115.985
G1 X158.669 Y114.795 E.05173
G1 X158.136 Y114.795
G1 X156.945 Y115.985 E.05173
G1 X156.412 Y115.985
G1 X157.602 Y114.795 E.05173
G1 X157.069 Y114.795
G1 X155.879 Y115.985 E.05173
G1 X155.345 Y115.985
G1 X156.536 Y114.795 E.05173
G1 X156.003 Y114.795
G1 X154.812 Y115.985 E.05173
G1 X154.279 Y115.985
G1 X155.469 Y114.795 E.05173
G1 X154.936 Y114.795
G1 X153.746 Y115.985 E.05173
G1 X153.212 Y115.985
G1 X154.403 Y114.795 E.05173
G1 X153.87 Y114.795
G1 X152.679 Y115.985 E.05173
G1 X152.146 Y115.985
G1 X153.336 Y114.795 E.05173
G1 X152.803 Y114.795
G1 X151.613 Y115.985 E.05173
G1 X151.079 Y115.985
G1 X152.27 Y114.795 E.05173
G1 X151.737 Y114.795
G1 X150.546 Y115.985 E.05173
G1 X150.013 Y115.985
G1 X151.203 Y114.795 E.05173
G1 X150.67 Y114.795
G1 X149.48 Y115.985 E.05173
G1 X148.946 Y115.985
G1 X150.137 Y114.795 E.05173
G1 X149.604 Y114.795
G1 X148.413 Y115.985 E.05173
G1 X147.88 Y115.985
G1 X149.07 Y114.795 E.05173
G1 X148.537 Y114.795
G1 X147.347 Y115.985 E.05173
G1 X146.813 Y115.985
G1 X148.004 Y114.795 E.05173
G1 X147.471 Y114.795
G1 X146.28 Y115.985 E.05173
G1 X145.747 Y115.985
G1 X146.937 Y114.795 E.05173
G1 X146.404 Y114.795
G1 X145.214 Y115.985 E.05173
G1 X144.68 Y115.985
G1 X145.871 Y114.795 E.05173
G1 X145.337 Y114.795
G1 X144.147 Y115.985 E.05173
G1 X143.614 Y115.985
G1 X144.804 Y114.795 E.05173
G1 X144.271 Y114.795
G1 X143.081 Y115.985 E.05173
G1 X142.547 Y115.985
G1 X143.738 Y114.795 E.05173
G1 X143.204 Y114.795
G1 X142.014 Y115.985 E.05173
G1 X141.481 Y115.985
G1 X142.671 Y114.795 E.05173
G1 X142.138 Y114.795
G1 X140.948 Y115.985 E.05173
G1 X140.414 Y115.985
G1 X141.605 Y114.795 E.05173
G1 X141.071 Y114.795
G1 X139.881 Y115.985 E.05173
G1 X139.348 Y115.985
G1 X140.538 Y114.795 E.05173
G1 X140.005 Y114.795
G1 X138.815 Y115.985 E.05173
G1 X138.281 Y115.985
G1 X139.472 Y114.795 E.05173
G1 X138.938 Y114.795
G1 X137.748 Y115.985 E.05173
G1 X137.215 Y115.985
G1 X138.405 Y114.795 E.05173
G1 X137.872 Y114.795
G1 X136.681 Y115.985 E.05173
G1 X136.148 Y115.985
G1 X137.339 Y114.795 E.05173
G1 X136.805 Y114.795
G1 X135.615 Y115.985 E.05173
G1 X135.082 Y115.985
G1 X136.272 Y114.795 E.05173
G1 X135.739 Y114.795
G1 X134.548 Y115.985 E.05173
G1 X134.015 Y115.985
G1 X135.206 Y114.795 E.05173
G1 X134.672 Y114.795
G1 X133.482 Y115.985 E.05173
M73 P50 R13
G1 X132.949 Y115.985
G1 X134.139 Y114.795 E.05173
G1 X133.606 Y114.795
G1 X132.415 Y115.985 E.05173
G1 X131.882 Y115.985
G1 X133.073 Y114.795 E.05173
G1 X132.539 Y114.795
G1 X131.349 Y115.985 E.05173
G1 X130.816 Y115.985
G1 X132.006 Y114.795 E.05173
G1 X131.473 Y114.795
G1 X130.282 Y115.985 E.05173
G1 X129.749 Y115.985
G1 X130.94 Y114.795 E.05173
G1 X130.406 Y114.795
G1 X129.216 Y115.985 E.05173
G1 X128.683 Y115.985
G1 X129.873 Y114.795 E.05173
G1 X129.34 Y114.795
G1 X128.149 Y115.985 E.05173
G1 X127.616 Y115.985
G1 X128.806 Y114.795 E.05173
G1 X128.273 Y114.795
G1 X127.083 Y115.985 E.05173
G1 X126.55 Y115.985
G1 X127.74 Y114.795 E.05173
G1 X127.207 Y114.795
G1 X126.016 Y115.985 E.05173
G1 X125.483 Y115.985
G1 X126.673 Y114.795 E.05173
G1 X126.14 Y114.795
G1 X124.95 Y115.985 E.05173
G1 X124.417 Y115.985
G1 X125.607 Y114.795 E.05173
G1 X125.074 Y114.795
G1 X123.883 Y115.985 E.05173
G1 X123.35 Y115.985
G1 X124.54 Y114.795 E.05173
G1 X124.007 Y114.795
G1 X122.817 Y115.985 E.05173
G1 X122.284 Y115.985
G1 X123.474 Y114.795 E.05173
G1 X122.941 Y114.795
G1 X121.75 Y115.985 E.05173
G1 X121.217 Y115.985
G1 X122.407 Y114.795 E.05173
G1 X121.874 Y114.795
G1 X120.684 Y115.985 E.05173
G1 X120.15 Y115.985
G1 X121.341 Y114.795 E.05173
G1 X120.808 Y114.795
G1 X119.617 Y115.985 E.05173
G1 X119.084 Y115.985
G1 X120.274 Y114.795 E.05173
G1 X119.741 Y114.795
G1 X118.551 Y115.985 E.05173
G1 X118.017 Y115.985
G1 X119.208 Y114.795 E.05173
G1 X118.675 Y114.795
G1 X117.484 Y115.985 E.05173
G1 X116.951 Y115.985
G1 X118.141 Y114.795 E.05173
G1 X117.608 Y114.795
G1 X116.418 Y115.985 E.05173
G1 X115.884 Y115.985
G1 X117.075 Y114.795 E.05173
G1 X116.542 Y114.795
G1 X115.351 Y115.985 E.05173
G1 X114.818 Y115.985
G1 X116.008 Y114.795 E.05173
G1 X115.475 Y114.795
G1 X114.285 Y115.985 E.05173
G1 X113.751 Y115.985
G1 X114.942 Y114.795 E.05173
G1 X114.409 Y114.795
G1 X113.218 Y115.985 E.05173
G1 X112.685 Y115.985
G1 X113.875 Y114.795 E.05173
G1 X113.342 Y114.795
G1 X112.152 Y115.985 E.05173
G1 X111.618 Y115.985
G1 X112.809 Y114.795 E.05173
G1 X112.276 Y114.795
G1 X111.085 Y115.985 E.05173
G1 X110.552 Y115.985
G1 X111.742 Y114.795 E.05173
G1 X111.209 Y114.795
G1 X110.019 Y115.985 E.05173
G1 X109.485 Y115.985
G1 X110.676 Y114.795 E.05173
G1 X110.142 Y114.795
G1 X108.952 Y115.985 E.05173
G1 X108.419 Y115.985
G1 X109.609 Y114.795 E.05173
G1 X109.076 Y114.795
G1 X107.886 Y115.985 E.05173
G1 X107.352 Y115.985
G1 X108.543 Y114.795 E.05173
G1 X108.009 Y114.795
G1 X106.819 Y115.985 E.05173
G1 X106.286 Y115.985
G1 X107.476 Y114.795 E.05173
G1 X106.943 Y114.795
G1 X105.753 Y115.985 E.05173
G1 X105.219 Y115.985
G1 X106.41 Y114.795 E.05173
G1 X105.876 Y114.795
G1 X104.686 Y115.985 E.05173
G1 X104.153 Y115.985
G1 X105.343 Y114.795 E.05173
G1 X104.81 Y114.795
G1 X103.62 Y115.985 E.05173
G1 X103.086 Y115.985
G1 X104.277 Y114.795 E.05173
G1 X103.743 Y114.795
G1 X102.553 Y115.985 E.05173
G1 X102.02 Y115.985
G1 X103.21 Y114.795 E.05173
G1 X102.677 Y114.795
G1 X101.486 Y115.985 E.05173
G1 X100.953 Y115.985
G1 X102.144 Y114.795 E.05173
G1 X101.61 Y114.795
G1 X100.42 Y115.985 E.05173
G1 X99.887 Y115.985
G1 X101.077 Y114.795 E.05173
G1 X100.544 Y114.795
G1 X99.353 Y115.985 E.05173
G1 X98.82 Y115.985
G1 X100.011 Y114.795 E.05173
G1 X99.477 Y114.795
G1 X98.287 Y115.985 E.05173
G1 X97.754 Y115.985
G1 X98.944 Y114.795 E.05173
G1 X98.411 Y114.795
G1 X97.22 Y115.985 E.05173
G1 X96.687 Y115.985
G1 X97.878 Y114.795 E.05173
G1 X97.344 Y114.795
G1 X96.154 Y115.985 E.05173
G1 X95.621 Y115.985
G1 X96.811 Y114.795 E.05173
G1 X96.278 Y114.795
G1 X95.087 Y115.985 E.05173
G1 X94.554 Y115.985
G1 X95.745 Y114.795 E.05173
G1 X95.211 Y114.795
G1 X94.021 Y115.985 E.05173
G1 X93.488 Y115.985
G1 X94.678 Y114.795 E.05173
G1 X94.145 Y114.795
G1 X92.954 Y115.985 E.05173
G1 X92.421 Y115.985
G1 X93.611 Y114.795 E.05173
G1 X93.078 Y114.795
G1 X91.888 Y115.985 E.05173
G1 X91.355 Y115.985
M73 P51 R13
G1 X92.545 Y114.795 E.05173
G1 X92.012 Y114.795
G1 X90.821 Y115.985 E.05173
G1 X90.288 Y115.985
G1 X91.478 Y114.795 E.05173
G1 X90.945 Y114.795
G1 X89.755 Y115.985 E.05173
G1 X89.222 Y115.985
G1 X90.412 Y114.795 E.05173
G1 X89.879 Y114.795
G1 X88.688 Y115.985 E.05173
G1 X88.155 Y115.985
G1 X89.345 Y114.795 E.05173
G1 X88.812 Y114.795
G1 X87.622 Y115.985 E.05173
G1 X87.089 Y115.985
G1 X88.279 Y114.795 E.05173
G1 X87.746 Y114.795
G1 X86.555 Y115.985 E.05173
G1 X86.022 Y115.985
G1 X87.212 Y114.795 E.05173
G1 X86.679 Y114.795
G1 X85.489 Y115.985 E.05173
G1 X84.955 Y115.985
G1 X86.146 Y114.795 E.05173
G1 X85.613 Y114.795
G1 X84.422 Y115.985 E.05173
G1 X83.889 Y115.985
G1 X85.079 Y114.795 E.05173
G1 X84.546 Y114.795
G1 X83.356 Y115.985 E.05173
G1 X82.822 Y115.985
G1 X84.013 Y114.795 E.05173
G1 X83.48 Y114.795
G1 X82.289 Y115.985 E.05173
G1 X81.756 Y115.985
G1 X82.946 Y114.795 E.05173
G1 X82.413 Y114.795
G1 X81.223 Y115.985 E.05173
G1 X80.689 Y115.985
G1 X81.88 Y114.795 E.05173
G1 X81.347 Y114.795
G1 X80.156 Y115.985 E.05173
G1 X79.623 Y115.985
G1 X80.813 Y114.795 E.05173
G1 X80.28 Y114.795
G1 X79.09 Y115.985 E.05173
G1 X78.556 Y115.985
G1 X79.747 Y114.795 E.05173
G1 X79.214 Y114.795
G1 X78.023 Y115.985 E.05173
G1 X77.49 Y115.985
G1 X78.68 Y114.795 E.05173
G1 X78.147 Y114.795
G1 X76.957 Y115.985 E.05173
G1 X76.423 Y115.985
G1 X77.614 Y114.795 E.05173
G1 X77.081 Y114.795
G1 X75.89 Y115.985 E.05173
G1 X75.357 Y115.985
G1 X76.547 Y114.795 E.05173
G1 X76.014 Y114.795
G1 X74.824 Y115.985 E.05173
G1 X74.29 Y115.985
G1 X75.481 Y114.795 E.05173
G1 X74.947 Y114.795
G1 X73.757 Y115.985 E.05173
G1 X73.224 Y115.985
G1 X74.414 Y114.795 E.05173
G1 X73.881 Y114.795
G1 X72.691 Y115.985 E.05173
G1 X72.417 Y115.725
G1 X73.348 Y114.795 E.04043
G1 X72.814 Y114.795
G1 X72.417 Y115.192 E.01725
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
M204 S10000
G1 X72.814 Y114.795 E-.21338
G1 X73.348 Y114.795 E-.20264
G1 X72.708 Y115.435 E-.34398
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/32
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.8 I-.237 J1.194 P1  F30000
G1 X183.398 Y137.398 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y137.398 E3.6753
G1 X72.602 Y135.82 E.05235
G1 X72.602 Y135.42 E.01327
G1 F14852.581
G1 X72.602 Y135.36 E.00199
G1 F13500
G1 X183.398 Y135.36 E3.6753
G1 F14852.581
G1 X183.398 Y135.42 E.00199
G1 F15476.087
G1 X183.398 Y135.82 E.01327
G1 X183.398 Y137.338 E.05036
M204 S250
G1 X183.79 Y137.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y137.79 E3.42854
G1 X72.21 Y136.206 E.04867
G1 X72.21 Y135.806 E.01229
G1 F6459.938
G1 X72.21 Y135.406 E.01229
G1 F1800
G1 X72.21 Y135.037 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y134.968 E.0023
G1 X183.79 Y134.968 E3.70131
G1 X183.79 Y135.037 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y135.406 E.01134
G1 F6459.938
G1 X183.79 Y135.806 E.01229
G1 F12000
G1 X183.79 Y136.206 E.01229
G1 X183.79 Y137.73 E.04682
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X181.79 Y137.731 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X174.158 Y137.66 Z3 F30000
G1 X75.71 Y136.746 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X77.339 Y136.746 E.05401
G1 X77.642 Y137.05 E.01423
G1 X78.571 Y137.05 E.0308
G1 X78.874 Y136.746 E.01423
G1 X85.015 Y136.746 E.2037
G1 X85.318 Y137.05 E.01423
G1 X86.246 Y137.05 E.0308
G1 X86.55 Y136.746 E.01423
G1 X92.691 Y136.746 E.2037
G1 X92.994 Y137.05 E.01423
G1 X93.922 Y137.05 E.0308
G1 X94.226 Y136.746 E.01423
G1 X100.367 Y136.746 E.2037
G1 X100.67 Y137.05 E.01423
G1 X101.598 Y137.05 E.0308
G1 X101.902 Y136.746 E.01423
G1 X108.042 Y136.746 E.2037
G1 X108.346 Y137.05 E.01423
G1 X109.274 Y137.05 E.0308
G1 X109.578 Y136.746 E.01423
G1 X115.718 Y136.746 E.2037
G1 X116.022 Y137.05 E.01423
G1 X116.95 Y137.05 E.0308
G1 X117.254 Y136.746 E.01423
G1 X123.394 Y136.746 E.2037
G1 X123.698 Y137.05 E.01423
G1 X124.626 Y137.05 E.0308
G1 X124.93 Y136.746 E.01423
G1 X131.07 Y136.746 E.2037
G1 X131.374 Y137.05 E.01423
G1 X132.302 Y137.05 E.0308
G1 X132.606 Y136.746 E.01423
G1 X138.746 Y136.746 E.2037
G1 X139.05 Y137.05 E.01423
G1 X139.978 Y137.05 E.0308
G1 X140.282 Y136.746 E.01423
G1 X146.422 Y136.746 E.2037
G1 X146.726 Y137.05 E.01423
G1 X147.654 Y137.05 E.0308
G1 X147.957 Y136.746 E.01423
G1 X154.098 Y136.746 E.2037
G1 X154.402 Y137.05 E.01423
G1 X155.33 Y137.05 E.0308
G1 X155.633 Y136.746 E.01423
G1 X161.774 Y136.746 E.2037
G1 X162.078 Y137.05 E.01423
G1 X163.006 Y137.05 E.0308
G1 X163.309 Y136.746 E.01423
G1 X169.45 Y136.746 E.2037
G1 X169.754 Y137.05 E.01423
G1 X170.682 Y137.05 E.0308
G1 X170.985 Y136.746 E.01423
G1 X177.126 Y136.746 E.2037
G1 X177.429 Y137.05 E.01423
G1 X178.358 Y137.05 E.0308
G1 X178.661 Y136.746 E.01423
G1 X180.29 Y136.746 E.05401
G1 X73.05 Y135.808 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53266
G1 F12863.969
G1 X73.05 Y136.298 E.01954
G1 X182.95 Y136.298 E4.38581
G1 X182.95 Y135.808 E.01954
G1 X73.11 Y135.808 E4.38341
; WIPE_START
G1 X75.11 Y135.808 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3 I.36 J1.163 P1  F30000
G1 X131.398 Y118.398 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y122.548 E.13765
G1 X131.398 Y122.948 E.01327
G1 F14331.075
G1 X131.398 Y123.348 E.01327
G1 F6685.538
G1 X131.398 Y123.748 E.01327
G1 F1920
G1 X131.398 Y124.128 E.01262
G1 F600
G1 X124.602 Y124.128 E.22543
G1 F1920
G1 X124.602 Y123.748 E.01262
M73 P52 R13
G1 F6685.538
G1 X124.602 Y123.348 E.01327
G1 F14331.075
G1 X124.602 Y122.948 E.01327
G1 F15476.087
G1 X124.602 Y122.548 E.01327
G1 X124.602 Y118.398 E.13765
G1 X117.398 Y118.398 E.23897
G1 X117.398 Y122.548 E.13765
G1 X117.398 Y122.948 E.01327
G1 F14331.075
G1 X117.398 Y123.348 E.01327
G1 F6685.538
G1 X117.398 Y123.748 E.01327
G1 F1920
G1 X117.398 Y124.128 E.01262
G1 F600
G1 X110.602 Y124.128 E.22543
G1 F1920
G1 X110.602 Y123.748 E.01262
G1 F6685.538
G1 X110.602 Y123.348 E.01327
G1 F14331.075
G1 X110.602 Y122.948 E.01327
G1 F15476.087
G1 X110.602 Y122.548 E.01327
G1 X110.602 Y118.398 E.13765
G1 X103.398 Y118.398 E.23897
G1 X103.398 Y122.548 E.13765
G1 X103.398 Y122.948 E.01327
G1 F14331.075
G1 X103.398 Y123.348 E.01327
G1 F6685.538
G1 X103.398 Y123.748 E.01327
G1 F1920
G1 X103.398 Y124.128 E.01262
G1 F600
G1 X96.602 Y124.128 E.22543
G1 F1920
G1 X96.602 Y123.748 E.01262
G1 F6685.538
G1 X96.602 Y123.348 E.01327
G1 F14331.075
G1 X96.602 Y122.948 E.01327
G1 F15476.087
G1 X96.602 Y122.548 E.01327
G1 X96.602 Y118.398 E.13765
G1 X89.398 Y118.398 E.23897
G1 X89.398 Y122.548 E.13765
G1 X89.398 Y122.948 E.01327
G1 F14331.075
G1 X89.398 Y123.348 E.01327
G1 F6685.538
G1 X89.398 Y123.748 E.01327
G1 F1920
G1 X89.398 Y124.128 E.01262
G1 F600
G1 X72.602 Y124.128 E.55715
G1 F1920
G1 X72.602 Y123.748 E.01262
G1 F6685.538
G1 X72.602 Y123.348 E.01327
G1 F14331.075
G1 X72.602 Y122.948 E.01327
G1 F15476.087
G1 X72.602 Y122.548 E.01327
G1 X72.602 Y117.008 E.18376
G1 X183.398 Y117.008 E3.6753
G1 X183.398 Y122.548 E.18376
G1 X183.398 Y122.948 E.01327
G1 F14331.075
G1 X183.398 Y123.348 E.01327
G1 F6685.538
G1 X183.398 Y123.748 E.01327
G1 F1920
G1 X183.398 Y124.128 E.01262
G1 F600
G1 X166.602 Y124.128 E.55715
G1 F1920
G1 X166.602 Y123.748 E.01262
G1 F6685.538
G1 X166.602 Y123.348 E.01327
G1 F14331.075
G1 X166.602 Y122.948 E.01327
G1 F15476.087
G1 X166.602 Y122.548 E.01327
G1 X166.602 Y118.398 E.13765
G1 X159.398 Y118.398 E.23897
G1 X159.398 Y122.548 E.13765
G1 X159.398 Y122.948 E.01327
G1 F14331.075
G1 X159.398 Y123.348 E.01327
G1 F6685.538
G1 X159.398 Y123.748 E.01327
G1 F1920
G1 X159.398 Y124.128 E.01262
G1 F600
G1 X152.602 Y124.128 E.22543
G1 F1920
G1 X152.602 Y123.748 E.01262
G1 F6685.538
G1 X152.602 Y123.348 E.01327
G1 F14331.075
G1 X152.602 Y122.948 E.01327
G1 F15476.087
G1 X152.602 Y122.548 E.01327
G1 X152.602 Y118.398 E.13765
G1 X145.398 Y118.398 E.23897
G1 X145.398 Y122.548 E.13765
G1 X145.398 Y122.948 E.01327
G1 F14331.075
G1 X145.398 Y123.348 E.01327
G1 F6685.538
G1 X145.398 Y123.748 E.01327
G1 F1920
G1 X145.398 Y124.128 E.01262
G1 F600
G1 X138.602 Y124.128 E.22543
G1 F1920
G1 X138.602 Y123.748 E.01262
G1 F6685.538
G1 X138.602 Y123.348 E.01327
G1 F14331.075
G1 X138.602 Y122.948 E.01327
G1 F15476.087
G1 X138.602 Y122.548 E.01327
G1 X138.602 Y118.398 E.13765
G1 X131.458 Y118.398 E.23698
M204 S250
G1 X131.79 Y118.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y122.961 E.12816
G1 X131.79 Y123.361 E.01229
G1 F6459.938
G1 X131.79 Y123.761 E.01229
G1 F1800
G1 X131.79 Y124.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y124.52 E.01294
G1 X124.21 Y124.52 E.25144
G1 X124.21 Y124.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y123.761 E.01134
G1 F6459.938
G1 X124.21 Y123.361 E.01229
G1 F12000
G1 X124.21 Y122.961 E.01229
G1 X124.21 Y118.79 E.12816
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y122.961 E.12816
G1 X117.79 Y123.361 E.01229
G1 F6459.938
G1 X117.79 Y123.761 E.01229
G1 F1800
G1 X117.79 Y124.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y124.52 E.01294
G1 X110.21 Y124.52 E.25144
G1 X110.21 Y124.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y123.761 E.01134
G1 F6459.938
G1 X110.21 Y123.361 E.01229
G1 F12000
G1 X110.21 Y122.961 E.01229
G1 X110.21 Y118.79 E.12816
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y122.961 E.12816
G1 X103.79 Y123.361 E.01229
G1 F6459.938
G1 X103.79 Y123.761 E.01229
G1 F1800
G1 X103.79 Y124.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y124.52 E.01294
G1 X96.21 Y124.52 E.25144
G1 X96.21 Y124.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y123.761 E.01134
G1 F6459.938
G1 X96.21 Y123.361 E.01229
G1 F12000
G1 X96.21 Y122.961 E.01229
G1 X96.21 Y118.79 E.12816
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y122.961 E.12816
G1 X89.79 Y123.361 E.01229
G1 F6459.938
G1 X89.79 Y123.761 E.01229
G1 F1800
G1 X89.79 Y124.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y124.52 E.01294
G1 X72.21 Y124.52 E.58316
G1 X72.21 Y124.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y123.761 E.01134
G1 F6459.938
G1 X72.21 Y123.361 E.01229
G1 F12000
G1 X72.21 Y122.961 E.01229
G1 X72.21 Y115.34 E.23417
G1 X183.79 Y115.34 E3.42854
G1 X183.79 Y122.961 E.23417
G1 X183.79 Y123.361 E.01229
G1 F6459.938
G1 X183.79 Y123.761 E.01229
G1 F1800
G1 X183.79 Y124.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y124.52 E.01294
G1 F600
G1 X166.21 Y124.52 E.58316
G1 X166.21 Y124.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y123.761 E.01134
G1 F6459.938
G1 X166.21 Y123.361 E.01229
G1 F12000
G1 X166.21 Y122.961 E.01229
G1 X166.21 Y118.79 E.12816
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y122.961 E.12816
G1 X159.79 Y123.361 E.01229
G1 F6459.938
G1 X159.79 Y123.761 E.01229
G1 F1800
G1 X159.79 Y124.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y124.52 E.01294
G1 X152.21 Y124.52 E.25144
G1 X152.21 Y124.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y123.761 E.01134
G1 F6459.938
G1 X152.21 Y123.361 E.01229
G1 F12000
G1 X152.21 Y122.961 E.01229
G1 X152.21 Y118.79 E.12816
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y122.961 E.12816
G1 X145.79 Y123.361 E.01229
G1 F6459.938
G1 X145.79 Y123.761 E.01229
G1 F1800
G1 X145.79 Y124.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y124.52 E.01294
G1 X138.21 Y124.52 E.25144
G1 X138.21 Y124.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y123.761 E.01134
G1 F6459.938
G1 X138.21 Y123.361 E.01229
G1 F12000
G1 X138.21 Y122.961 E.01229
G1 X138.21 Y118.79 E.12816
G1 X131.85 Y118.79 E.19542
; WIPE_START
M204 S10000
G1 X131.821 Y120.79 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3 I-1.171 J-.333 P1  F30000
G1 X131.234 Y122.852 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y122.852 E.23226
G1 X124.935 Y123.305 E.01668
G1 X131.065 Y123.305 E.22601
G1 X131.065 Y123.757 E.01668
G1 X124.766 Y123.757 E.23226
G1 X124.952 Y122.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y122.378 E.16725
G1 X125.924 Y122.028 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
M73 P53 R13
G1 F15476.087
G1 X124.95 Y122.028 E.0323
G1 X124.95 Y121.374 E.02172
G1 X126.489 Y119.835 E.07216
G1 X129.511 Y119.835 E.10027
G1 X131.05 Y121.374 E.07217
G1 X131.05 Y122.028 E.02172
G1 X130.076 Y122.028 E.0323
; WIPE_START
G1 X131.05 Y122.028 E-.37
G1 X131.05 Y121.374 E-.24876
G1 X130.787 Y121.111 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X138.031 Y123.514 Z3 F30000
G1 X138.766 Y123.757 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X145.065 Y123.757 E.23226
G1 X145.065 Y123.305 E.01668
G1 X138.935 Y123.305 E.22601
G1 X138.935 Y122.852 E.01668
G1 X145.234 Y122.852 E.23226
G1 X138.952 Y122.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y122.378 E.16724
G1 X138.95 Y119.97 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.95 Y121.598 E.05401
G1 X139.38 Y122.028 E.02017
G1 X139.648 Y122.028 E.00887
G1 X141.841 Y119.835 E.10287
G1 X144.863 Y119.835 E.10027
G1 X145.05 Y120.022 E.00874
G1 X145.05 Y121.65 E.05401
; WIPE_START
G1 X145.05 Y120.022 E-.61876
G1 X144.863 Y119.835 E-.10016
G1 X144.755 Y119.835 E-.04108
; WIPE_END
G1 E-.04 F1800
G1 X152.045 Y122.097 Z3 F30000
G1 X152.952 Y122.378 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y122.378 E.16724
G1 X159.234 Y122.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y122.852 E.23226
G1 X152.935 Y123.305 E.01668
G1 X159.065 Y123.305 E.22601
G1 X159.065 Y123.757 E.01668
G1 X152.766 Y123.757 E.23226
G1 X158.821 Y119.835 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X157.192 Y119.835 E.05401
G1 X154.999 Y122.028 E.10288
G1 X154.732 Y122.028 E.00887
G1 X152.95 Y120.247 E.08359
G1 X152.95 Y119.835 E.01364
G1 X154.168 Y119.835 E.04038
; WIPE_START
G1 X152.95 Y119.835 E-.46255
G1 X152.95 Y120.247 E-.15621
G1 X153.213 Y120.509 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X160.845 Y120.639 Z3 F30000
G1 X167.108 Y120.746 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G2 X167.374 Y120.635 I.078 J-.188 E.0106
G1 X168.691 Y120.635 E.04368
G1 X170.084 Y122.028 E.06535
G1 X170.351 Y122.028 E.00887
G1 X171.744 Y120.635 E.06535
G1 X176.367 Y120.635 E.15335
G1 X177.76 Y122.028 E.06535
G1 X178.027 Y122.028 E.00887
G1 X179.42 Y120.635 E.06535
G1 X181.049 Y120.635 E.05401
G1 X183.006 Y118.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y117.4 E.04369
G1 X167.789 Y117.4 E.46757
; LINE_WIDTH: 0.439069
G1 X167.461 Y117.419 E.0106
; LINE_WIDTH: 0.477225
G1 X167.133 Y117.438 E.01162
; LINE_WIDTH: 0.533672
G1 X166.806 Y117.457 E.01313
G1 X159.194 Y117.457 E.30437
; LINE_WIDTH: 0.515382
G1 X158.867 Y117.438 E.01264
; LINE_WIDTH: 0.477225
G1 X158.539 Y117.419 E.01162
; LINE_WIDTH: 0.421309
G1 X158.211 Y117.4 E.01012
G1 X153.789 Y117.4 E.13637
; LINE_WIDTH: 0.439069
G1 X153.461 Y117.419 E.0106
; LINE_WIDTH: 0.477225
G1 X153.133 Y117.438 E.01162
; LINE_WIDTH: 0.533672
G1 X152.806 Y117.457 E.01313
G1 X145.194 Y117.457 E.30437
; LINE_WIDTH: 0.515382
G1 X144.867 Y117.438 E.01264
; LINE_WIDTH: 0.477225
G1 X144.539 Y117.419 E.01162
; LINE_WIDTH: 0.421309
G1 X144.211 Y117.4 E.01012
G1 X139.789 Y117.4 E.13637
; LINE_WIDTH: 0.439069
G1 X139.461 Y117.419 E.0106
; LINE_WIDTH: 0.477225
G1 X139.133 Y117.438 E.01162
; LINE_WIDTH: 0.533672
G1 X138.806 Y117.457 E.01313
G1 X131.194 Y117.457 E.30437
; LINE_WIDTH: 0.515382
G1 X130.867 Y117.438 E.01264
; LINE_WIDTH: 0.477225
G1 X130.539 Y117.419 E.01162
; LINE_WIDTH: 0.421308
G1 X130.211 Y117.4 E.01012
G1 X125.789 Y117.4 E.13637
; LINE_WIDTH: 0.439069
G1 X125.461 Y117.419 E.0106
; LINE_WIDTH: 0.477225
G1 X125.133 Y117.438 E.01162
; LINE_WIDTH: 0.533672
G1 X124.806 Y117.457 E.01313
G1 X117.194 Y117.457 E.30437
; LINE_WIDTH: 0.515382
G1 X116.867 Y117.438 E.01264
; LINE_WIDTH: 0.477225
G1 X116.539 Y117.419 E.01162
; LINE_WIDTH: 0.421309
G1 X116.211 Y117.4 E.01012
G1 X111.789 Y117.4 E.13637
; LINE_WIDTH: 0.439069
G1 X111.461 Y117.419 E.0106
; LINE_WIDTH: 0.477225
G1 X111.133 Y117.438 E.01162
; LINE_WIDTH: 0.533672
G1 X110.806 Y117.457 E.01313
G1 X103.194 Y117.457 E.30437
; LINE_WIDTH: 0.515382
G1 X102.867 Y117.438 E.01264
; LINE_WIDTH: 0.477225
G1 X102.539 Y117.419 E.01162
; LINE_WIDTH: 0.421309
G1 X102.211 Y117.4 E.01012
G1 X97.789 Y117.4 E.13637
; LINE_WIDTH: 0.439069
G1 X97.461 Y117.419 E.0106
; LINE_WIDTH: 0.477225
G1 X97.133 Y117.438 E.01162
; LINE_WIDTH: 0.533672
G1 X96.806 Y117.457 E.01313
G1 X89.194 Y117.457 E.30437
; LINE_WIDTH: 0.515382
G1 X88.867 Y117.438 E.01264
; LINE_WIDTH: 0.477225
G1 X88.539 Y117.419 E.01162
; LINE_WIDTH: 0.420162
G1 X88.211 Y117.4 E.01009
G1 X72.994 Y117.4 E.46778
G1 X72.994 Y120.243 E.08741
G1 X88.676 Y120.243 E.48206
G1 X88.915 Y120.353 E.00808
G1 X89.006 Y120.353 E.00281
G1 X89.006 Y118.194 E.06637
; LINE_WIDTH: 0.439689
G1 X89.054 Y118.113 E.00306
; LINE_WIDTH: 0.479085
G1 X89.103 Y118.032 E.00337
; LINE_WIDTH: 0.534275
G1 X89.152 Y117.951 E.00379
G1 X89.194 Y117.949 E.00171
G1 X96.806 Y117.949 E.30475
; LINE_WIDTH: 0.515382
G1 X96.868 Y118.031 E.00398
; LINE_WIDTH: 0.477225
G1 X96.931 Y118.112 E.00365
; LINE_WIDTH: 0.420219
G1 X96.994 Y118.194 E.00317
G1 X96.994 Y119.443 E.0384
G1 X103.006 Y119.443 E.18483
G1 X103.006 Y118.194 E.0384
; LINE_WIDTH: 0.439689
G1 X103.054 Y118.113 E.00306
; LINE_WIDTH: 0.479085
G1 X103.103 Y118.032 E.00337
; LINE_WIDTH: 0.534275
G1 X103.152 Y117.951 E.00379
G1 X103.194 Y117.949 E.00171
G1 X110.806 Y117.949 E.30475
; LINE_WIDTH: 0.515382
G1 X110.868 Y118.031 E.00398
; LINE_WIDTH: 0.477225
G1 X110.931 Y118.112 E.00365
; LINE_WIDTH: 0.420219
G1 X110.994 Y118.194 E.00317
G1 X110.994 Y119.443 E.0384
G1 X117.006 Y119.443 E.18483
G1 X117.006 Y118.194 E.0384
; LINE_WIDTH: 0.439689
G1 X117.054 Y118.113 E.00306
; LINE_WIDTH: 0.479085
G1 X117.103 Y118.032 E.00337
; LINE_WIDTH: 0.534275
G1 X117.152 Y117.951 E.00379
G1 X117.194 Y117.949 E.00171
G1 X124.806 Y117.949 E.30475
; LINE_WIDTH: 0.515382
G1 X124.868 Y118.031 E.00398
; LINE_WIDTH: 0.477225
G1 X124.931 Y118.112 E.00365
; LINE_WIDTH: 0.420219
G1 X124.994 Y118.194 E.00317
G1 X124.994 Y119.443 E.0384
G1 X131.006 Y119.443 E.18483
G1 X131.006 Y118.194 E.0384
; LINE_WIDTH: 0.439689
G1 X131.054 Y118.113 E.00306
; LINE_WIDTH: 0.479085
G1 X131.103 Y118.032 E.00337
; LINE_WIDTH: 0.534275
G1 X131.152 Y117.951 E.00379
G1 X131.194 Y117.949 E.00171
G1 X138.806 Y117.949 E.30475
; LINE_WIDTH: 0.515382
G1 X138.868 Y118.031 E.00398
; LINE_WIDTH: 0.477225
G1 X138.931 Y118.112 E.00365
; LINE_WIDTH: 0.420219
G1 X138.994 Y118.194 E.00317
G1 X138.994 Y119.443 E.0384
G1 X145.006 Y119.443 E.18483
G1 X145.006 Y118.194 E.0384
; LINE_WIDTH: 0.439689
G1 X145.054 Y118.113 E.00306
; LINE_WIDTH: 0.479085
G1 X145.103 Y118.032 E.00337
; LINE_WIDTH: 0.534275
G1 X145.152 Y117.951 E.00379
G1 X145.194 Y117.949 E.00171
G1 X152.806 Y117.949 E.30475
; LINE_WIDTH: 0.515382
G1 X152.868 Y118.031 E.00398
; LINE_WIDTH: 0.477225
G1 X152.931 Y118.112 E.00365
; LINE_WIDTH: 0.420219
G1 X152.994 Y118.194 E.00317
G1 X152.994 Y119.443 E.0384
G1 X159.006 Y119.443 E.18483
G1 X159.006 Y118.194 E.0384
; LINE_WIDTH: 0.439689
G1 X159.054 Y118.113 E.00306
; LINE_WIDTH: 0.479085
G1 X159.103 Y118.032 E.00337
; LINE_WIDTH: 0.534275
G1 X159.152 Y117.951 E.00379
G1 X159.194 Y117.949 E.00171
G1 X166.806 Y117.949 E.30475
; LINE_WIDTH: 0.515382
G1 X166.868 Y118.031 E.00398
; LINE_WIDTH: 0.477225
G1 X166.931 Y118.112 E.00365
; LINE_WIDTH: 0.420091
G1 X166.994 Y118.194 E.00317
G1 X166.994 Y120.353 E.06636
G2 X167.324 Y120.243 I.007 J-.529 E.01089
G1 X183.006 Y120.243 E.48197
G1 X183.006 Y118.882 E.04185
G1 X182.629 Y118.822 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.629 Y117.777 E.0321
G1 X166.954 Y117.777 E.48164
G1 X167.371 Y118.194 E.01814
G1 X167.371 Y119.866 E.05137
G1 X182.629 Y119.866 E.46881
G1 X182.629 Y118.882 E.03026
G1 X182.252 Y118.822 F30000
G1 F12000
G1 X182.252 Y118.154 E.02051
G1 X167.708 Y118.154 E.44688
G1 X167.748 Y118.194 E.00176
G1 X167.748 Y119.489 E.03979
G1 X182.252 Y119.489 E.44564
G1 X182.252 Y118.882 E.01867
G1 X181.824 Y118.822 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X181.824 Y118.582 E.00935
G1 X168.176 Y118.582 E.53278
G1 X168.176 Y119.061 E.0187
G1 X181.824 Y119.061 E.53278
G1 X181.824 Y118.882 E.00701
; WIPE_START
G1 X181.824 Y119.061 E-.06823
G1 X180.003 Y119.061 E-.69177
; WIPE_END
G1 E-.04 F1800
G1 X172.375 Y118.813 Z3 F30000
G1 X153.371 Y118.194 Z3
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X152.954 Y117.777 E.01814
G1 X158.979 Y117.777 E.18515
G1 X158.629 Y118.194 E.01675
G1 X158.629 Y118.832 E.01959
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X158.629 Y119.066 E.00721
G1 X153.371 Y119.066 E.16155
G1 X153.371 Y118.832 E.00721
; Slow Down End
G1 F12000
G1 X153.371 Y118.254 E.01774
G1 X153.789 Y118.194 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X153.788 Y118.65 E.01692
G1 X158.212 Y118.65 E.16446
G1 X158.211 Y118.194 E.01692
G2 X153.849 Y118.194 I-2.209 J547.215 E.16216
G1 X139.371 Y118.194 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X138.954 Y117.777 E.01814
G1 X144.979 Y117.777 E.18515
G1 X144.629 Y118.194 E.01675
G1 X144.629 Y118.832 E.01959
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X144.629 Y119.066 E.00721
G1 X139.371 Y119.066 E.16155
G1 X139.371 Y118.832 E.00721
; Slow Down End
G1 F12000
G1 X139.371 Y118.254 E.01774
G1 X139.789 Y118.194 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X139.788 Y118.65 E.01692
G1 X144.212 Y118.65 E.16446
G1 X144.211 Y118.194 E.01692
G2 X139.849 Y118.194 I-2.209 J547.215 E.16216
G1 X125.371 Y118.194 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.954 Y117.777 E.01814
G1 X130.979 Y117.777 E.18515
G1 X130.629 Y118.194 E.01675
G1 X130.629 Y118.832 E.01959
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X130.629 Y119.066 E.00721
G1 X125.371 Y119.066 E.16155
G1 X125.371 Y118.832 E.00721
; Slow Down End
G1 F12000
G1 X125.371 Y118.254 E.01774
G1 X125.789 Y118.194 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X125.788 Y118.65 E.01692
G1 X130.212 Y118.65 E.16446
G1 X130.211 Y118.194 E.01692
G2 X125.849 Y118.194 I-2.209 J547.215 E.16216
G1 X111.371 Y118.194 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X110.954 Y117.777 E.01814
G1 X116.979 Y117.777 E.18515
G1 X116.629 Y118.194 E.01675
G1 X116.629 Y118.832 E.01959
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X116.629 Y119.066 E.00721
G1 X111.371 Y119.066 E.16155
G1 X111.371 Y118.832 E.00721
; Slow Down End
G1 F12000
G1 X111.371 Y118.254 E.01774
G1 X111.789 Y118.194 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X111.788 Y118.65 E.01692
G1 X116.212 Y118.65 E.16446
G1 X116.211 Y118.194 E.01692
G2 X111.849 Y118.194 I-2.209 J547.214 E.16216
; WIPE_START
G1 X113.849 Y118.194 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X106.227 Y118.598 Z3 F30000
G1 X97.371 Y119.066 Z3
G1 Z2.6
G1 E.8 F1800
; Slow Down Start
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X97.371 Y118.832 E.00721
; Slow Down End
G1 F12000
G1 X97.371 Y118.194 E.01959
G1 X96.954 Y117.777 E.01814
G1 X102.979 Y117.777 E.18515
G1 X102.629 Y118.194 E.01675
G1 X102.629 Y118.832 E.01959
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X102.629 Y119.066 E.00721
; Slow Down End
G1 F12000
G1 X97.431 Y119.066 E.1597
G1 X97.788 Y118.65 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X102.212 Y118.65 E.16446
G1 X102.211 Y118.194 E.01692
G2 X97.789 Y118.194 I-2.211 J547.842 E.16439
G1 X97.788 Y118.59 E.01469
; WIPE_START
G1 X97.789 Y118.194 E-.15021
G1 X99.393 Y118.194 E-.60979
; WIPE_END
G1 E-.04 F1800
G1 X91.762 Y118.072 Z3 F30000
G1 X73.371 Y117.777 Z3
G1 Z2.6
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.979 Y117.777 E.47958
G1 X88.629 Y118.194 E.01675
G1 X88.629 Y119.632 E.04417
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.629 Y119.866 E.00721
G1 X73.371 Y119.866 E.46881
G1 X73.371 Y119.632 E.00721
; Slow Down End
G1 F12000
G1 X73.371 Y117.837 E.05515
G1 X88.286 Y118.154 F30000
G1 F12000
G1 X73.748 Y118.154 E.44668
G1 X73.748 Y119.489 E.04103
G1 X88.252 Y119.489 E.44564
G1 X88.252 Y118.202 E.03956
G1 X87.824 Y118.582 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X74.176 Y118.582 E.53278
G1 X74.176 Y119.061 E.0187
G1 X87.824 Y119.061 E.53278
G1 X87.824 Y118.642 E.01636
G1 X89.234 Y122.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y122.852 E.60098
G1 X72.935 Y123.305 E.01668
G1 X89.065 Y123.305 E.59472
G1 X89.065 Y123.757 E.01668
G1 X72.766 Y123.757 E.60098
G1 X72.952 Y122.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y122.378 E.4443
; WIPE_START
G1 X86.988 Y122.378 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3 I-.17 J1.205 P1  F30000
G1 X96.766 Y123.757 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X103.065 Y123.757 E.23226
G1 X103.065 Y123.305 E.01668
G1 X96.935 Y123.305 E.22601
G1 X96.935 Y122.852 E.01668
G1 X103.234 Y122.852 E.23226
G1 X101.832 Y119.835 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.05 Y119.835 E.04038
G1 X103.05 Y120.246 E.01364
G1 X101.268 Y122.028 E.08359
G1 X101.001 Y122.028 E.00887
G1 X98.808 Y119.835 E.10288
G1 X97.179 Y119.835 E.05401
G1 X96.952 Y122.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y122.378 E.16724
; WIPE_START
G1 X100.988 Y122.378 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3 I-.17 J1.205 P1  F30000
G1 X110.766 Y123.757 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X117.065 Y123.757 E.23226
G1 X117.065 Y123.305 E.01668
G1 X110.935 Y123.305 E.22601
G1 X110.935 Y122.852 E.01668
G1 X117.234 Y122.852 E.23226
G1 X110.952 Y122.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y122.378 E.16724
G1 X110.95 Y121.65 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y120.022 E.05401
G1 X111.137 Y119.835 E.00874
G1 X114.159 Y119.835 E.10027
G1 X116.352 Y122.028 E.10288
G1 X116.62 Y122.028 E.00887
G1 X117.05 Y121.598 E.02017
G1 X117.05 Y119.97 E.05401
; WIPE_START
G1 X117.05 Y121.598 E-.61876
G1 X116.787 Y121.861 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X109.158 Y121.638 Z3 F30000
G1 X74.951 Y120.635 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G1 X76.58 Y120.635 E.05401
G1 X77.973 Y122.028 E.06535
G1 X78.24 Y122.028 E.00887
G1 X79.633 Y120.635 E.06535
G1 X84.256 Y120.635 E.15335
G1 X85.649 Y122.028 E.06535
G1 X85.916 Y122.028 E.00887
G1 X87.309 Y120.635 E.06535
G1 X88.626 Y120.635 E.04368
G2 X88.892 Y120.746 I.188 J-.078 E.0106
; WIPE_START
G1 X88.736 Y120.746 E-.05923
G1 X88.626 Y120.635 E-.05915
G1 X87.309 Y120.635 E-.50038
G1 X87.046 Y120.898 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X94.674 Y121.172 Z3 F30000
G1 X166.766 Y123.757 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X183.065 Y123.757 E.60098
G1 X183.065 Y123.305 E.01668
G1 X166.935 Y123.305 E.59472
G1 X166.935 Y122.852 E.01668
G1 X183.234 Y122.852 E.60098
; WIPE_START
G1 X181.234 Y122.852 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3 I1.188 J.266 P1  F30000
G1 X182.871 Y115.547 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.583 Y116.259 E.03091
G1 X183.576 Y116.785
G1 X182.338 Y115.547 E.05379
G1 X181.805 Y115.547
G1 X183.043 Y116.785 E.05379
G1 X182.51 Y116.785
G1 X181.272 Y115.547 E.05379
G1 X180.738 Y115.547
G1 X181.976 Y116.785 E.05379
G1 X181.443 Y116.785
G1 X180.205 Y115.547 E.05379
G1 X179.672 Y115.547
G1 X180.91 Y116.785 E.05379
G1 X180.376 Y116.785
G1 X179.139 Y115.547 E.05379
G1 X178.605 Y115.547
M73 P54 R13
G1 X179.843 Y116.785 E.05379
G1 X179.31 Y116.785
G1 X178.072 Y115.547 E.05379
G1 X177.539 Y115.547
G1 X178.777 Y116.785 E.05379
G1 X178.243 Y116.785
G1 X177.006 Y115.547 E.05379
G1 X176.472 Y115.547
G1 X177.71 Y116.785 E.05379
G1 X177.177 Y116.785
G1 X175.939 Y115.547 E.05379
G1 X175.406 Y115.547
G1 X176.644 Y116.785 E.05379
G1 X176.11 Y116.785
G1 X174.873 Y115.547 E.05379
G1 X174.339 Y115.547
G1 X175.577 Y116.785 E.05379
G1 X175.044 Y116.785
G1 X173.806 Y115.547 E.05379
G1 X173.273 Y115.547
G1 X174.511 Y116.785 E.05379
G1 X173.977 Y116.785
G1 X172.739 Y115.547 E.05379
G1 X172.206 Y115.547
G1 X173.444 Y116.785 E.05379
G1 X172.911 Y116.785
G1 X171.673 Y115.547 E.05379
G1 X171.14 Y115.547
G1 X172.378 Y116.785 E.05379
G1 X171.844 Y116.785
G1 X170.606 Y115.547 E.05379
G1 X170.073 Y115.547
G1 X171.311 Y116.785 E.05379
G1 X170.778 Y116.785
G1 X169.54 Y115.547 E.05379
G1 X169.007 Y115.547
G1 X170.245 Y116.785 E.05379
G1 X169.711 Y116.785
G1 X168.473 Y115.547 E.05379
G1 X167.94 Y115.547
G1 X169.178 Y116.785 E.05379
G1 X168.645 Y116.785
G1 X167.407 Y115.547 E.05379
G1 X166.874 Y115.547
G1 X168.112 Y116.785 E.05379
G1 X167.578 Y116.785
G1 X166.34 Y115.547 E.05379
G1 X165.807 Y115.547
G1 X167.045 Y116.785 E.05379
G1 X166.512 Y116.785
G1 X165.274 Y115.547 E.05379
G1 X164.741 Y115.547
G1 X165.979 Y116.785 E.05379
G1 X165.445 Y116.785
G1 X164.207 Y115.547 E.05379
G1 X163.674 Y115.547
G1 X164.912 Y116.785 E.05379
G1 X164.379 Y116.785
G1 X163.141 Y115.547 E.05379
G1 X162.608 Y115.547
G1 X163.846 Y116.785 E.05379
G1 X163.312 Y116.785
G1 X162.074 Y115.547 E.05379
G1 X161.541 Y115.547
G1 X162.779 Y116.785 E.05379
G1 X162.246 Y116.785
G1 X161.008 Y115.547 E.05379
G1 X160.475 Y115.547
G1 X161.712 Y116.785 E.05379
G1 X161.179 Y116.785
G1 X159.941 Y115.547 E.05379
G1 X159.408 Y115.547
G1 X160.646 Y116.785 E.05379
G1 X160.113 Y116.785
M73 P54 R12
G1 X158.875 Y115.547 E.05379
G1 X158.342 Y115.547
G1 X159.579 Y116.785 E.05379
G1 X159.046 Y116.785
G1 X157.808 Y115.547 E.05379
G1 X157.275 Y115.547
G1 X158.513 Y116.785 E.05379
G1 X157.98 Y116.785
G1 X156.742 Y115.547 E.05379
G1 X156.209 Y115.547
G1 X157.446 Y116.785 E.05379
G1 X156.913 Y116.785
G1 X155.675 Y115.547 E.05379
G1 X155.142 Y115.547
G1 X156.38 Y116.785 E.05379
G1 X155.847 Y116.785
G1 X154.609 Y115.547 E.05379
G1 X154.075 Y115.547
G1 X155.313 Y116.785 E.05379
G1 X154.78 Y116.785
G1 X153.542 Y115.547 E.05379
G1 X153.009 Y115.547
G1 X154.247 Y116.785 E.05379
G1 X153.714 Y116.785
G1 X152.476 Y115.547 E.05379
G1 X151.942 Y115.547
G1 X153.18 Y116.785 E.05379
G1 X152.647 Y116.785
G1 X151.409 Y115.547 E.05379
G1 X150.876 Y115.547
G1 X152.114 Y116.785 E.05379
G1 X151.581 Y116.785
G1 X150.343 Y115.547 E.05379
G1 X149.809 Y115.547
G1 X151.047 Y116.785 E.05379
G1 X150.514 Y116.785
G1 X149.276 Y115.547 E.05379
G1 X148.743 Y115.547
G1 X149.981 Y116.785 E.05379
G1 X149.448 Y116.785
G1 X148.21 Y115.547 E.05379
G1 X147.676 Y115.547
G1 X148.914 Y116.785 E.05379
G1 X148.381 Y116.785
G1 X147.143 Y115.547 E.05379
G1 X146.61 Y115.547
G1 X147.848 Y116.785 E.05379
G1 X147.315 Y116.785
G1 X146.077 Y115.547 E.05379
G1 X145.543 Y115.547
G1 X146.781 Y116.785 E.05379
G1 X146.248 Y116.785
G1 X145.01 Y115.547 E.05379
G1 X144.477 Y115.547
G1 X145.715 Y116.785 E.05379
G1 X145.181 Y116.785
G1 X143.944 Y115.547 E.05379
G1 X143.41 Y115.547
G1 X144.648 Y116.785 E.05379
G1 X144.115 Y116.785
G1 X142.877 Y115.547 E.05379
G1 X142.344 Y115.547
G1 X143.582 Y116.785 E.05379
G1 X143.048 Y116.785
G1 X141.811 Y115.547 E.05379
G1 X141.277 Y115.547
G1 X142.515 Y116.785 E.05379
G1 X141.982 Y116.785
G1 X140.744 Y115.547 E.05379
G1 X140.211 Y115.547
G1 X141.449 Y116.785 E.05379
G1 X140.915 Y116.785
G1 X139.678 Y115.547 E.05379
G1 X139.144 Y115.547
G1 X140.382 Y116.785 E.05379
G1 X139.849 Y116.785
G1 X138.611 Y115.547 E.05379
G1 X138.078 Y115.547
G1 X139.316 Y116.785 E.05379
G1 X138.782 Y116.785
G1 X137.545 Y115.547 E.05379
G1 X137.011 Y115.547
G1 X138.249 Y116.785 E.05379
G1 X137.716 Y116.785
G1 X136.478 Y115.547 E.05379
G1 X135.945 Y115.547
G1 X137.183 Y116.785 E.05379
G1 X136.649 Y116.785
G1 X135.411 Y115.547 E.05379
G1 X134.878 Y115.547
G1 X136.116 Y116.785 E.05379
G1 X135.583 Y116.785
G1 X134.345 Y115.547 E.05379
G1 X133.812 Y115.547
G1 X135.05 Y116.785 E.05379
G1 X134.516 Y116.785
G1 X133.278 Y115.547 E.05379
G1 X132.745 Y115.547
G1 X133.983 Y116.785 E.05379
G1 X133.45 Y116.785
G1 X132.212 Y115.547 E.05379
G1 X131.679 Y115.547
G1 X132.917 Y116.785 E.05379
G1 X132.383 Y116.785
G1 X131.145 Y115.547 E.05379
G1 X130.612 Y115.547
G1 X131.85 Y116.785 E.05379
G1 X131.317 Y116.785
G1 X130.079 Y115.547 E.05379
G1 X129.546 Y115.547
G1 X130.784 Y116.785 E.05379
G1 X130.25 Y116.785
G1 X129.012 Y115.547 E.05379
G1 X128.479 Y115.547
G1 X129.717 Y116.785 E.05379
G1 X129.184 Y116.785
G1 X127.946 Y115.547 E.05379
G1 X127.413 Y115.547
G1 X128.651 Y116.785 E.05379
G1 X128.117 Y116.785
G1 X126.879 Y115.547 E.05379
G1 X126.346 Y115.547
G1 X127.584 Y116.785 E.05379
G1 X127.051 Y116.785
G1 X125.813 Y115.547 E.05379
G1 X125.28 Y115.547
G1 X126.517 Y116.785 E.05379
G1 X125.984 Y116.785
G1 X124.746 Y115.547 E.05379
G1 X124.213 Y115.547
G1 X125.451 Y116.785 E.05379
G1 X124.918 Y116.785
G1 X123.68 Y115.547 E.05379
G1 X123.147 Y115.547
G1 X124.384 Y116.785 E.05379
G1 X123.851 Y116.785
G1 X122.613 Y115.547 E.05379
G1 X122.08 Y115.547
G1 X123.318 Y116.785 E.05379
G1 X122.785 Y116.785
G1 X121.547 Y115.547 E.05379
G1 X121.014 Y115.547
G1 X122.251 Y116.785 E.05379
G1 X121.718 Y116.785
G1 X120.48 Y115.547 E.05379
G1 X119.947 Y115.547
G1 X121.185 Y116.785 E.05379
G1 X120.652 Y116.785
G1 X119.414 Y115.547 E.05379
G1 X118.88 Y115.547
G1 X120.118 Y116.785 E.05379
G1 X119.585 Y116.785
G1 X118.347 Y115.547 E.05379
G1 X117.814 Y115.547
G1 X119.052 Y116.785 E.05379
G1 X118.519 Y116.785
G1 X117.281 Y115.547 E.05379
G1 X116.747 Y115.547
G1 X117.985 Y116.785 E.05379
G1 X117.452 Y116.785
G1 X116.214 Y115.547 E.05379
G1 X115.681 Y115.547
G1 X116.919 Y116.785 E.05379
G1 X116.386 Y116.785
G1 X115.148 Y115.547 E.05379
G1 X114.614 Y115.547
G1 X115.852 Y116.785 E.05379
G1 X115.319 Y116.785
G1 X114.081 Y115.547 E.05379
G1 X113.548 Y115.547
G1 X114.786 Y116.785 E.05379
G1 X114.253 Y116.785
G1 X113.015 Y115.547 E.05379
G1 X112.481 Y115.547
G1 X113.719 Y116.785 E.05379
G1 X113.186 Y116.785
G1 X111.948 Y115.547 E.05379
G1 X111.415 Y115.547
G1 X112.653 Y116.785 E.05379
G1 X112.12 Y116.785
G1 X110.882 Y115.547 E.05379
G1 X110.348 Y115.547
G1 X111.586 Y116.785 E.05379
G1 X111.053 Y116.785
G1 X109.815 Y115.547 E.05379
G1 X109.282 Y115.547
G1 X110.52 Y116.785 E.05379
G1 X109.986 Y116.785
G1 X108.749 Y115.547 E.05379
G1 X108.215 Y115.547
G1 X109.453 Y116.785 E.05379
G1 X108.92 Y116.785
G1 X107.682 Y115.547 E.05379
G1 X107.149 Y115.547
G1 X108.387 Y116.785 E.05379
G1 X107.853 Y116.785
G1 X106.616 Y115.547 E.05379
G1 X106.082 Y115.547
G1 X107.32 Y116.785 E.05379
G1 X106.787 Y116.785
G1 X105.549 Y115.547 E.05379
G1 X105.016 Y115.547
G1 X106.254 Y116.785 E.05379
G1 X105.72 Y116.785
G1 X104.483 Y115.547 E.05379
G1 X103.949 Y115.547
G1 X105.187 Y116.785 E.05379
G1 X104.654 Y116.785
G1 X103.416 Y115.547 E.05379
G1 X102.883 Y115.547
G1 X104.121 Y116.785 E.05379
G1 X103.587 Y116.785
G1 X102.349 Y115.547 E.05379
G1 X101.816 Y115.547
G1 X103.054 Y116.785 E.05379
G1 X102.521 Y116.785
G1 X101.283 Y115.547 E.05379
G1 X100.75 Y115.547
G1 X101.988 Y116.785 E.05379
G1 X101.454 Y116.785
G1 X100.216 Y115.547 E.05379
G1 X99.683 Y115.547
G1 X100.921 Y116.785 E.05379
G1 X100.388 Y116.785
G1 X99.15 Y115.547 E.05379
G1 X98.617 Y115.547
G1 X99.855 Y116.785 E.05379
G1 X99.321 Y116.785
G1 X98.083 Y115.547 E.05379
G1 X97.55 Y115.547
G1 X98.788 Y116.785 E.05379
G1 X98.255 Y116.785
G1 X97.017 Y115.547 E.05379
G1 X96.484 Y115.547
G1 X97.722 Y116.785 E.05379
G1 X97.188 Y116.785
G1 X95.95 Y115.547 E.05379
G1 X95.417 Y115.547
G1 X96.655 Y116.785 E.05379
G1 X96.122 Y116.785
G1 X94.884 Y115.547 E.05379
G1 X94.351 Y115.547
G1 X95.589 Y116.785 E.05379
G1 X95.055 Y116.785
G1 X93.817 Y115.547 E.05379
G1 X93.284 Y115.547
G1 X94.522 Y116.785 E.05379
G1 X93.989 Y116.785
G1 X92.751 Y115.547 E.05379
G1 X92.218 Y115.547
G1 X93.456 Y116.785 E.05379
G1 X92.922 Y116.785
G1 X91.684 Y115.547 E.05379
G1 X91.151 Y115.547
G1 X92.389 Y116.785 E.05379
G1 X91.856 Y116.785
G1 X90.618 Y115.547 E.05379
G1 X90.085 Y115.547
G1 X91.322 Y116.785 E.05379
G1 X90.789 Y116.785
G1 X89.551 Y115.547 E.05379
G1 X89.018 Y115.547
G1 X90.256 Y116.785 E.05379
G1 X89.723 Y116.785
G1 X88.485 Y115.547 E.05379
G1 X87.952 Y115.547
G1 X89.189 Y116.785 E.05379
G1 X88.656 Y116.785
G1 X87.418 Y115.547 E.05379
G1 X86.885 Y115.547
G1 X88.123 Y116.785 E.05379
G1 X87.59 Y116.785
G1 X86.352 Y115.547 E.05379
G1 X85.819 Y115.547
G1 X87.056 Y116.785 E.05379
G1 X86.523 Y116.785
G1 X85.285 Y115.547 E.05379
G1 X84.752 Y115.547
G1 X85.99 Y116.785 E.05379
G1 X85.457 Y116.785
G1 X84.219 Y115.547 E.05379
G1 X83.685 Y115.547
G1 X84.923 Y116.785 E.05379
G1 X84.39 Y116.785
G1 X83.152 Y115.547 E.05379
G1 X82.619 Y115.547
G1 X83.857 Y116.785 E.05379
G1 X83.324 Y116.785
G1 X82.086 Y115.547 E.05379
G1 X81.552 Y115.547
G1 X82.79 Y116.785 E.05379
G1 X82.257 Y116.785
G1 X81.019 Y115.547 E.05379
G1 X80.486 Y115.547
G1 X81.724 Y116.785 E.05379
G1 X81.191 Y116.785
G1 X79.953 Y115.547 E.05379
G1 X79.419 Y115.547
G1 X80.657 Y116.785 E.05379
G1 X80.124 Y116.785
G1 X78.886 Y115.547 E.05379
G1 X78.353 Y115.547
G1 X79.591 Y116.785 E.05379
G1 X79.058 Y116.785
G1 X77.82 Y115.547 E.05379
G1 X77.286 Y115.547
G1 X78.524 Y116.785 E.05379
G1 X77.991 Y116.785
G1 X76.753 Y115.547 E.05379
G1 X76.22 Y115.547
G1 X77.458 Y116.785 E.05379
G1 X76.925 Y116.785
G1 X75.687 Y115.547 E.05379
G1 X75.153 Y115.547
G1 X76.391 Y116.785 E.05379
G1 X75.858 Y116.785
G1 X74.62 Y115.547 E.05379
G1 X74.087 Y115.547
G1 X75.325 Y116.785 E.05379
G1 X74.791 Y116.785
G1 X73.554 Y115.547 E.05379
G1 X73.02 Y115.547
G1 X74.258 Y116.785 E.05379
G1 X73.725 Y116.785
G1 X72.487 Y115.547 E.05379
G1 X72.417 Y116.011
G1 X73.192 Y116.785 E.03365
; WIPE_START
M204 S10000
G1 X72.417 Y116.011 E-.41613
G1 X72.487 Y115.547 E-.17813
G1 X72.795 Y115.856 E-.16574
; WIPE_END
G1 E-.04 F1800
G1 X80.41 Y116.383 Z3 F30000
G1 X166.952 Y122.378 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y122.378 E.4443
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X180.988 Y122.378 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/32
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3 I-1.202 J.193 P1  F30000
G1 X183.398 Y137.398 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y137.398 E3.6753
G1 X72.602 Y135.34 E.06826
G1 X72.602 Y134.94 E.01327
G1 F14852.35
G1 X72.602 Y134.88 E.00199
G1 F13500
G1 X183.398 Y134.88 E3.6753
G1 F14852.35
G1 X183.398 Y134.94 E.00199
G1 F15476.087
G1 X183.398 Y135.34 E.01327
G1 X183.398 Y137.338 E.06627
M204 S250
G1 X183.79 Y137.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y137.79 E3.42854
G1 X72.21 Y135.727 E.0634
G1 X72.21 Y135.327 E.01229
G1 F6459.938
G1 X72.21 Y134.927 E.01229
G1 F1800
G1 X72.21 Y134.558 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y134.488 E.0023
G1 X183.79 Y134.488 E3.70131
G1 X183.79 Y134.558 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y134.927 E.01134
G1 F6459.938
G1 X183.79 Y135.327 E.01229
G1 F12000
M73 P55 R12
G1 X183.79 Y135.727 E.01229
G1 X183.79 Y137.73 E.06156
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X181.79 Y137.731 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X180.769 Y136.267 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.141 Y136.267 E.05401
G1 X178.358 Y137.05 E.03672
G1 X177.429 Y137.05 E.0308
G1 X176.647 Y136.267 E.03672
G1 X171.465 Y136.267 E.17189
G1 X170.682 Y137.05 E.03672
G1 X169.754 Y137.05 E.0308
G1 X168.971 Y136.267 E.03672
G1 X163.789 Y136.267 E.17189
G1 X163.006 Y137.05 E.03672
G1 X162.078 Y137.05 E.0308
G1 X161.295 Y136.267 E.03672
G1 X156.113 Y136.267 E.17189
G1 X155.33 Y137.05 E.03672
G1 X154.402 Y137.05 E.0308
G1 X153.619 Y136.267 E.03672
G1 X148.437 Y136.267 E.17189
G1 X147.654 Y137.05 E.03672
G1 X146.726 Y137.05 E.0308
G1 X145.943 Y136.267 E.03672
G1 X140.761 Y136.267 E.17189
G1 X139.978 Y137.05 E.03672
G1 X139.05 Y137.05 E.0308
G1 X138.267 Y136.267 E.03672
G1 X133.085 Y136.267 E.17189
G1 X132.302 Y137.05 E.03672
G1 X131.374 Y137.05 E.0308
G1 X130.591 Y136.267 E.03672
G1 X125.409 Y136.267 E.17189
G1 X124.626 Y137.05 E.03672
G1 X123.698 Y137.05 E.0308
G1 X122.915 Y136.267 E.03672
G1 X117.733 Y136.267 E.17189
G1 X116.95 Y137.05 E.03672
G1 X116.022 Y137.05 E.0308
G1 X115.239 Y136.267 E.03672
G1 X110.057 Y136.267 E.17189
G1 X109.274 Y137.05 E.03672
G1 X108.346 Y137.05 E.0308
G1 X107.563 Y136.267 E.03672
G1 X102.381 Y136.267 E.17189
G1 X101.598 Y137.05 E.03672
G1 X100.67 Y137.05 E.0308
G1 X99.887 Y136.267 E.03672
G1 X94.705 Y136.267 E.17189
G1 X93.922 Y137.05 E.03672
G1 X92.994 Y137.05 E.0308
G1 X92.211 Y136.267 E.03672
G1 X87.029 Y136.267 E.17189
G1 X86.246 Y137.05 E.03672
G1 X85.318 Y137.05 E.0308
G1 X84.535 Y136.267 E.03672
G1 X79.353 Y136.267 E.17189
G1 X78.571 Y137.05 E.03672
G1 X77.642 Y137.05 E.0308
G1 X76.859 Y136.267 E.03672
G1 X75.231 Y136.267 E.05401
G1 X73.05 Y135.329 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53266
G1 F12863.969
G1 X73.05 Y135.818 E.01954
G1 X182.95 Y135.818 E4.38581
G1 X182.95 Y135.329 E.01954
G1 X73.11 Y135.329 E4.38341
; WIPE_START
G1 X75.11 Y135.329 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.2 I.351 J1.165 P1  F30000
G1 X131.398 Y118.398 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y123.348 E.16419
G1 X131.398 Y123.748 E.01327
G1 F14331.075
G1 X131.398 Y124.148 E.01327
G1 F6685.538
G1 X131.398 Y124.548 E.01327
G1 F1920
G1 X131.398 Y124.928 E.01262
G1 F600
G1 X124.602 Y124.928 E.22543
G1 F1920
G1 X124.602 Y124.548 E.01262
G1 F6685.538
G1 X124.602 Y124.148 E.01327
G1 F14331.075
G1 X124.602 Y123.748 E.01327
G1 F15476.087
G1 X124.602 Y123.348 E.01327
G1 X124.602 Y118.398 E.16419
G1 X117.398 Y118.398 E.23897
G1 X117.398 Y123.348 E.16419
G1 X117.398 Y123.748 E.01327
G1 F14331.075
G1 X117.398 Y124.148 E.01327
G1 F6685.538
G1 X117.398 Y124.548 E.01327
G1 F1920
G1 X117.398 Y124.928 E.01262
G1 F600
G1 X110.602 Y124.928 E.22543
G1 F1920
G1 X110.602 Y124.548 E.01262
G1 F6685.538
G1 X110.602 Y124.148 E.01327
G1 F14331.075
G1 X110.602 Y123.748 E.01327
G1 F15476.087
G1 X110.602 Y123.348 E.01327
G1 X110.602 Y118.398 E.16419
G1 X103.398 Y118.398 E.23897
G1 X103.398 Y123.348 E.16419
G1 X103.398 Y123.748 E.01327
G1 F14331.075
G1 X103.398 Y124.148 E.01327
G1 F6685.538
G1 X103.398 Y124.548 E.01327
G1 F1920
G1 X103.398 Y124.928 E.01262
G1 F600
G1 X96.602 Y124.928 E.22543
G1 F1920
G1 X96.602 Y124.548 E.01262
G1 F6685.538
G1 X96.602 Y124.148 E.01327
G1 F14331.075
G1 X96.602 Y123.748 E.01327
G1 F15476.087
G1 X96.602 Y123.348 E.01327
G1 X96.602 Y118.398 E.16419
G1 X89.398 Y118.398 E.23897
G1 X89.398 Y123.348 E.16419
G1 X89.398 Y123.748 E.01327
G1 F14331.075
G1 X89.398 Y124.148 E.01327
G1 F6685.538
G1 X89.398 Y124.548 E.01327
G1 F1920
G1 X89.398 Y124.928 E.01262
G1 F600
G1 X72.602 Y124.928 E.55715
G1 F1920
G1 X72.602 Y124.548 E.01262
G1 F6685.538
G1 X72.602 Y124.148 E.01327
G1 F14331.075
G1 X72.602 Y123.748 E.01327
G1 F15476.087
G1 X72.602 Y123.348 E.01327
G1 X72.602 Y117.808 E.18376
G1 X183.398 Y117.808 E3.6753
G1 X183.398 Y123.348 E.18376
G1 X183.398 Y123.748 E.01327
G1 F14331.075
G1 X183.398 Y124.148 E.01327
G1 F6685.538
G1 X183.398 Y124.548 E.01327
G1 F1920
G1 X183.398 Y124.928 E.01262
M73 P56 R12
G1 F600
G1 X166.602 Y124.928 E.55715
G1 F1920
G1 X166.602 Y124.548 E.01262
G1 F6685.538
G1 X166.602 Y124.148 E.01327
G1 F14331.075
G1 X166.602 Y123.748 E.01327
G1 F15476.087
G1 X166.602 Y123.348 E.01327
G1 X166.602 Y118.398 E.16419
G1 X159.398 Y118.398 E.23897
G1 X159.398 Y123.348 E.16419
G1 X159.398 Y123.748 E.01327
G1 F14331.075
G1 X159.398 Y124.148 E.01327
G1 F6685.538
G1 X159.398 Y124.548 E.01327
G1 F1920
G1 X159.398 Y124.928 E.01262
G1 F600
G1 X152.602 Y124.928 E.22543
G1 F1920
G1 X152.602 Y124.548 E.01262
G1 F6685.538
G1 X152.602 Y124.148 E.01327
G1 F14331.075
G1 X152.602 Y123.748 E.01327
G1 F15476.087
G1 X152.602 Y123.348 E.01327
G1 X152.602 Y118.398 E.16419
G1 X145.398 Y118.398 E.23897
G1 X145.398 Y123.348 E.16419
G1 X145.398 Y123.748 E.01327
G1 F14331.075
G1 X145.398 Y124.148 E.01327
G1 F6685.538
G1 X145.398 Y124.548 E.01327
G1 F1920
G1 X145.398 Y124.928 E.01262
G1 F600
G1 X138.602 Y124.928 E.22543
G1 F1920
G1 X138.602 Y124.548 E.01262
G1 F6685.538
G1 X138.602 Y124.148 E.01327
G1 F14331.075
G1 X138.602 Y123.748 E.01327
G1 F15476.087
G1 X138.602 Y123.348 E.01327
G1 X138.602 Y118.398 E.16419
G1 X131.458 Y118.398 E.23698
M204 S250
G1 X131.79 Y118.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y123.761 E.15275
G1 X131.79 Y124.161 E.01229
G1 F6459.938
G1 X131.79 Y124.561 E.01229
G1 F1800
G1 X131.79 Y124.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y125.32 E.01294
G1 X124.21 Y125.32 E.25144
G1 X124.21 Y124.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y124.561 E.01134
G1 F6459.938
G1 X124.21 Y124.161 E.01229
G1 F12000
G1 X124.21 Y123.761 E.01229
G1 X124.21 Y118.79 E.15275
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y123.761 E.15275
G1 X117.79 Y124.161 E.01229
G1 F6459.938
G1 X117.79 Y124.561 E.01229
G1 F1800
G1 X117.79 Y124.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y125.32 E.01294
G1 X110.21 Y125.32 E.25144
G1 X110.21 Y124.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y124.561 E.01134
G1 F6459.938
G1 X110.21 Y124.161 E.01229
G1 F12000
G1 X110.21 Y123.761 E.01229
G1 X110.21 Y118.79 E.15275
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y123.761 E.15275
G1 X103.79 Y124.161 E.01229
G1 F6459.938
G1 X103.79 Y124.561 E.01229
G1 F1800
G1 X103.79 Y124.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y125.32 E.01294
G1 X96.21 Y125.32 E.25144
G1 X96.21 Y124.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y124.561 E.01134
G1 F6459.938
G1 X96.21 Y124.161 E.01229
G1 F12000
G1 X96.21 Y123.761 E.01229
G1 X96.21 Y118.79 E.15275
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y123.761 E.15275
G1 X89.79 Y124.161 E.01229
G1 F6459.938
G1 X89.79 Y124.561 E.01229
G1 F1800
G1 X89.79 Y124.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y125.32 E.01294
G1 X72.21 Y125.32 E.58316
G1 X72.21 Y124.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y124.561 E.01134
G1 F6459.938
G1 X72.21 Y124.161 E.01229
G1 F12000
G1 X72.21 Y123.761 E.01229
G1 X72.21 Y116.14 E.23417
G1 X183.79 Y116.14 E3.42854
G1 X183.79 Y123.761 E.23417
G1 X183.79 Y124.161 E.01229
G1 F6459.938
G1 X183.79 Y124.561 E.01229
G1 F1800
G1 X183.79 Y124.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y125.32 E.01294
G1 F600
G1 X166.21 Y125.32 E.58316
G1 X166.21 Y124.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y124.561 E.01134
G1 F6459.938
G1 X166.21 Y124.161 E.01229
G1 F12000
G1 X166.21 Y123.761 E.01229
G1 X166.21 Y118.79 E.15275
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y123.761 E.15275
G1 X159.79 Y124.161 E.01229
G1 F6459.938
G1 X159.79 Y124.561 E.01229
G1 F1800
G1 X159.79 Y124.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y125.32 E.01294
G1 X152.21 Y125.32 E.25144
G1 X152.21 Y124.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y124.561 E.01134
G1 F6459.938
G1 X152.21 Y124.161 E.01229
G1 F12000
G1 X152.21 Y123.761 E.01229
G1 X152.21 Y118.79 E.15275
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y123.761 E.15275
G1 X145.79 Y124.161 E.01229
G1 F6459.938
G1 X145.79 Y124.561 E.01229
G1 F1800
G1 X145.79 Y124.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y125.32 E.01294
G1 X138.21 Y125.32 E.25144
G1 X138.21 Y124.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y124.561 E.01134
G1 F6459.938
G1 X138.21 Y124.161 E.01229
G1 F12000
G1 X138.21 Y123.761 E.01229
G1 X138.21 Y118.79 E.15275
G1 X131.85 Y118.79 E.19542
M204 S10000
G1 X131.195 Y118.103 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.22599
G1 F15000
G1 X138.806 Y118.103 E.11354
G1 X138.994 Y118.623 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X139.16 Y118.533 E.0058
G1 X139.198 Y118.2 E.01029
G1 X144.802 Y118.2 E.17222
G1 X144.84 Y118.533 E.01029
G1 X145.006 Y118.623 E.0058
G1 X145.006 Y119.632 E.031
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X145.006 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X145.006 Y123.136 E.02777
G1 X138.994 Y123.136 E.18472
G1 X138.994 Y122.232 E.02777
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X138.994 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X138.994 Y118.683 E.02916
G1 X139.371 Y118.804 F30000
G1 F12000
G1 X139.462 Y118.759 E.00311
G1 X139.522 Y118.577 E.00588
G1 X144.478 Y118.577 E.15227
G1 X144.538 Y118.759 E.00588
G1 X144.629 Y118.804 E.00311
G1 X144.629 Y119.632 E.02544
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X144.629 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X144.629 Y122.759 E.01618
G1 X139.371 Y122.759 E.16155
G1 X139.371 Y122.232 E.01618
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X139.371 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X139.371 Y118.864 E.0236
G1 X139.748 Y119.03 F30000
G1 F12000
G1 X139.774 Y118.954 E.00248
G1 X144.175 Y118.954 E.13524
G1 X144.252 Y118.992 E.00263
G1 X144.252 Y119.632 E.01965
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X144.252 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X144.252 Y122.382 E.0046
G1 X139.748 Y122.382 E.13838
G1 X139.748 Y122.232 E.0046
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
M73 P57 R12
G1 X139.748 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X139.748 Y119.09 E.01663
G1 X140.125 Y119.331 F30000
G1 F12000
G1 X143.875 Y119.331 E.1152
G1 X143.875 Y119.632 E.00924
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X143.875 Y122.004 E.0729
G1 X140.125 Y122.004 E.1152
G1 X140.125 Y119.632 E.0729
; Slow Down End
G1 F12000
G1 X140.125 Y119.391 E.0074
G1 X143.498 Y119.708 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X143.498 Y121.627 E.05897
G1 X140.502 Y121.627 E.09203
G1 X140.502 Y119.708 E.05897
G1 X143.438 Y119.708 E.09019
; Slow Down End
G1 X143.121 Y120.085 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X143.121 Y121.25 E.0358
G1 X140.879 Y121.25 E.06886
G1 X140.879 Y120.085 E.0358
G1 X143.061 Y120.085 E.06702
; Slow Down End
G1 X142.735 Y120.471 F30000
; Slow Down Start
; LINE_WIDTH: 0.43695
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.735 Y120.865 E.01265
G1 X141.265 Y120.865 E.0472
G1 X141.265 Y120.471 E.01265
G1 X142.675 Y120.471 E.04527
; Slow Down End
G1 X145.195 Y118.103 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.22599
G1 F15000
G1 X152.806 Y118.103 E.11354
G1 X152.994 Y119.632 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X152.994 Y118.623 E.031
G1 X153.16 Y118.533 E.0058
G1 X153.198 Y118.2 E.01029
G1 X158.802 Y118.2 E.17222
G1 X158.84 Y118.533 E.01029
G1 X159.006 Y118.623 E.0058
G1 X159.006 Y119.632 E.031
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X159.006 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X159.006 Y123.136 E.02777
G1 X152.994 Y123.136 E.18472
G1 X152.994 Y119.692 E.10582
G1 X153.371 Y119.632 F30000
G1 F12000
G1 X153.371 Y118.804 E.02544
G1 X153.462 Y118.759 E.00311
G1 X153.522 Y118.577 E.00588
G1 X158.478 Y118.577 E.15227
G1 X158.538 Y118.759 E.00588
G1 X158.629 Y118.804 E.00311
G1 X158.629 Y119.632 E.02544
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X158.629 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X158.629 Y122.759 E.01618
G1 X153.371 Y122.759 E.16155
G1 X153.371 Y119.692 E.09423
G1 X153.748 Y119.632 F30000
G1 F12000
G1 X153.748 Y119.03 E.01848
G1 X153.774 Y118.954 E.00248
G1 X158.175 Y118.954 E.13524
G1 X158.252 Y118.992 E.00263
G1 X158.252 Y119.632 E.01965
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X158.252 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X158.252 Y122.382 E.0046
G1 X153.748 Y122.382 E.13838
G1 X153.748 Y119.692 E.08265
G1 X154.125 Y119.632 F30000
G1 F12000
G1 X154.125 Y119.331 E.00924
G1 X157.875 Y119.331 E.1152
G1 X157.875 Y119.632 E.00924
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X157.875 Y122.005 E.0729
G1 X154.125 Y122.004 E.1152
; Slow Down End
G1 F12000
G1 X154.125 Y119.692 E.07106
G1 X157.498 Y119.708 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X157.498 Y121.627 E.05897
G1 X154.502 Y121.627 E.09203
G1 X154.502 Y119.708 E.05897
G1 X157.438 Y119.708 E.09019
; Slow Down End
G1 X157.121 Y120.085 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X157.121 Y121.25 E.0358
G1 X154.879 Y121.25 E.06886
G1 X154.879 Y120.085 E.0358
G1 X157.061 Y120.085 E.06702
; Slow Down End
G1 X156.735 Y120.471 F30000
; Slow Down Start
; LINE_WIDTH: 0.436955
G1 F3000;_EXTRUDE_SET_SPEED
G1 X156.735 Y120.865 E.01265
G1 X155.265 Y120.865 E.0472
G1 X155.265 Y120.471 E.01265
G1 X156.675 Y120.471 E.04527
; Slow Down End
G1 X159.195 Y118.103 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.22599
G1 F15000
G1 X166.806 Y118.103 E.11354
G1 X166.952 Y123.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y123.178 E.4443
G1 X183.234 Y123.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y123.652 E.60098
G1 X166.935 Y124.105 E.01668
G1 X183.065 Y124.105 E.59472
G1 X183.065 Y124.557 E.01668
G1 X166.766 Y124.557 E.60098
; WIPE_START
G1 X168.766 Y124.557 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.2 I.115 J-1.212 P1  F30000
G1 X159.234 Y123.652 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F3000
G1 X152.935 Y123.652 E.23226
G1 X152.935 Y124.105 E.01668
G1 X159.065 Y124.105 E.22601
G1 X159.065 Y124.557 E.01668
G1 X152.766 Y124.557 E.23226
; WIPE_START
G1 X154.766 Y124.557 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.2 I.115 J-1.212 P1  F30000
G1 X145.234 Y123.652 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F3000
G1 X138.935 Y123.652 E.23226
G1 X138.935 Y124.105 E.01668
G1 X145.065 Y124.105 E.22601
G1 X145.065 Y124.557 E.01668
G1 X138.766 Y124.557 E.23226
; WIPE_START
G1 X140.766 Y124.557 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.2 I.115 J-1.212 P1  F30000
G1 X131.234 Y123.652 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F3000
G1 X124.935 Y123.652 E.23226
G1 X124.935 Y124.105 E.01668
G1 X131.065 Y124.105 E.22601
G1 X131.065 Y124.557 E.01668
G1 X124.766 Y124.557 E.23226
G1 X124.805 Y118.103 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.22599
G1 F15000
G1 X117.194 Y118.103 E.11354
G1 X117.234 Y123.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y123.652 E.23226
G1 X110.935 Y124.105 E.01668
G1 X117.065 Y124.105 E.22601
G1 X117.065 Y124.557 E.01668
G1 X110.766 Y124.557 E.23226
G1 X110.994 Y118.623 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X111.16 Y118.533 E.0058
G1 X111.198 Y118.2 E.01029
G1 X116.802 Y118.2 E.17222
G1 X116.84 Y118.533 E.01029
G1 X117.006 Y118.623 E.0058
G1 X117.006 Y119.632 E.031
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X117.006 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X117.006 Y123.136 E.02777
G1 X110.994 Y123.136 E.18472
G1 X110.994 Y122.232 E.02777
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X110.994 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X110.994 Y118.683 E.02916
G1 X111.371 Y119.632 F30000
G1 F12000
G1 X111.371 Y118.804 E.02544
G1 X111.462 Y118.759 E.00311
G1 X111.522 Y118.577 E.00588
G1 X116.478 Y118.577 E.15227
G1 X116.538 Y118.759 E.00588
G1 X116.629 Y118.804 E.00311
G1 X116.629 Y119.632 E.02544
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X116.629 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X116.629 Y122.759 E.01618
G1 X111.371 Y122.759 E.16155
G1 X111.371 Y119.692 E.09423
G1 X111.748 Y119.632 F30000
G1 F12000
G1 X111.748 Y119.03 E.01848
G1 X111.774 Y118.954 E.00248
G1 X116.175 Y118.954 E.13524
G1 X116.252 Y118.992 E.00263
G1 X116.252 Y119.632 E.01965
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X116.252 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X116.252 Y122.382 E.0046
G1 X111.748 Y122.382 E.13838
G1 X111.748 Y119.692 E.08265
G1 X112.125 Y119.632 F30000
G1 F12000
G1 X112.125 Y119.331 E.00924
G1 X115.875 Y119.331 E.1152
G1 X115.875 Y119.632 E.00924
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X115.875 Y122.005 E.0729
G1 X112.125 Y122.004 E.1152
; Slow Down End
G1 F12000
G1 X112.125 Y119.692 E.07106
G1 X115.498 Y119.708 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X115.498 Y121.627 E.05897
G1 X112.502 Y121.627 E.09203
G1 X112.502 Y119.708 E.05897
G1 X115.438 Y119.708 E.09019
; Slow Down End
G1 X115.121 Y120.085 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X115.121 Y121.25 E.0358
G1 X112.879 Y121.25 E.06886
G1 X112.879 Y120.085 E.0358
G1 X115.061 Y120.085 E.06702
; Slow Down End
G1 X114.735 Y120.471 F30000
; Slow Down Start
; LINE_WIDTH: 0.436955
G1 F3000;_EXTRUDE_SET_SPEED
G1 X114.735 Y120.865 E.01265
G1 X113.265 Y120.865 E.0472
G1 X113.265 Y120.471 E.01265
G1 X114.675 Y120.471 E.04527
; Slow Down End
G1 X110.805 Y118.103 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.22599
G1 F15000
G1 X103.194 Y118.103 E.11354
G1 X103.234 Y123.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y123.652 E.23226
G1 X96.935 Y124.105 E.01668
G1 X103.065 Y124.105 E.22601
G1 X103.065 Y124.557 E.01668
G1 X96.766 Y124.557 E.23226
G1 X96.994 Y118.623 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X97.16 Y118.533 E.0058
G1 X97.198 Y118.2 E.01029
G1 X102.802 Y118.2 E.17222
G1 X102.84 Y118.533 E.01029
G1 X103.006 Y118.623 E.0058
G1 X103.006 Y119.632 E.031
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X103.006 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X103.006 Y123.136 E.02777
G1 X96.994 Y123.136 E.18472
G1 X96.994 Y122.232 E.02777
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X96.994 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X96.994 Y118.683 E.02916
G1 X97.371 Y119.632 F30000
G1 F12000
G1 X97.371 Y118.804 E.02544
G1 X97.462 Y118.759 E.00311
G1 X97.522 Y118.577 E.00588
G1 X102.478 Y118.577 E.15227
G1 X102.538 Y118.759 E.00588
G1 X102.629 Y118.804 E.00311
G1 X102.629 Y119.632 E.02544
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X102.629 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X102.629 Y122.759 E.01618
G1 X97.371 Y122.759 E.16155
G1 X97.371 Y119.692 E.09423
G1 X97.748 Y119.632 F30000
G1 F12000
G1 X97.748 Y119.03 E.01848
G1 X97.774 Y118.954 E.00248
G1 X102.175 Y118.954 E.13524
G1 X102.252 Y118.992 E.00263
G1 X102.252 Y119.632 E.01965
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X102.252 Y122.232 E.07989
; Slow Down End
G1 F12000
G1 X102.252 Y122.382 E.0046
G1 X97.748 Y122.382 E.13838
G1 X97.748 Y119.692 E.08265
G1 X98.125 Y119.632 F30000
G1 F12000
G1 X98.125 Y119.331 E.00924
G1 X101.875 Y119.331 E.1152
G1 X101.875 Y119.632 E.00924
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X101.875 Y122.005 E.0729
G1 X98.125 Y122.004 E.1152
; Slow Down End
G1 F12000
G1 X98.125 Y119.692 E.07106
G1 X101.498 Y119.708 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X101.498 Y121.627 E.05897
G1 X98.502 Y121.627 E.09203
G1 X98.502 Y119.708 E.05897
G1 X101.438 Y119.708 E.09019
; Slow Down End
G1 X101.121 Y120.085 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X101.121 Y121.25 E.0358
G1 X98.879 Y121.25 E.06886
G1 X98.879 Y120.085 E.0358
G1 X101.061 Y120.085 E.06702
; Slow Down End
G1 X100.735 Y120.471 F30000
; Slow Down Start
; LINE_WIDTH: 0.436955
G1 F3000;_EXTRUDE_SET_SPEED
G1 X100.735 Y120.865 E.01265
G1 X99.265 Y120.865 E.0472
G1 X99.265 Y120.471 E.01265
G1 X100.675 Y120.471 E.04527
; Slow Down End
G1 X96.805 Y118.103 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.22599
G1 F15000
G1 X89.194 Y118.103 E.11354
G1 X88.137 Y121.435 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X86.509 Y121.435 E.05401
G1 X85.116 Y122.828 E.06535
G1 X86.449 Y122.828 E.04421
G1 X85.056 Y121.435 E.06535
G1 X78.833 Y121.435 E.20642
G1 X77.44 Y122.828 E.06535
G1 X78.773 Y122.828 E.04421
G1 X77.38 Y121.435 E.06535
G1 X75.751 Y121.435 E.05401
G1 X72.952 Y123.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y123.178 E.4443
G1 X89.234 Y123.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y123.652 E.60098
G1 X72.935 Y124.105 E.01668
G1 X89.065 Y124.105 E.59472
G1 X89.065 Y124.557 E.01668
G1 X72.766 Y124.557 E.60098
G1 X72.994 Y118.2 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.802 Y118.2 E.48573
G1 X88.84 Y118.533 E.01029
G1 X89.006 Y118.623 E.0058
G1 X89.006 Y120.542 E.05896
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X89.006 Y121.043 E.01541
G1 X72.994 Y121.043 E.49198
G1 X72.994 Y120.432 E.01879
; Slow Down End
G1 F12000
G1 X72.994 Y118.26 E.06674
G1 X73.371 Y118.577 F30000
G1 F12000
G1 X88.478 Y118.577 E.46417
G1 X88.538 Y118.759 E.00588
G1 X88.629 Y118.804 E.00311
G1 X88.629 Y120.432 E.05002
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.629 Y120.666 E.00721
G1 X73.371 Y120.666 E.46881
G1 X73.371 Y120.432 E.00721
; Slow Down End
G1 F12000
G1 X73.371 Y118.637 E.05515
G1 X88.252 Y118.992 F30000
G1 F12000
G1 X88.175 Y118.954 E.00263
G1 X73.748 Y118.954 E.44329
G1 X73.748 Y120.289 E.04103
G1 X88.252 Y120.289 E.44564
G1 X88.252 Y119.052 E.03801
G1 X87.824 Y119.382 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X74.176 Y119.382 E.53278
G1 X74.176 Y119.861 E.0187
G1 X87.824 Y119.861 E.53278
G1 X87.824 Y119.442 E.01636
; WIPE_START
G1 X87.824 Y119.861 E-.15926
G1 X86.243 Y119.861 E-.60074
; WIPE_END
G1 E-.04 F1800
G1 X93.865 Y120.265 Z3.2 F30000
G1 X131.006 Y122.232 Z3.2
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y123.136 E.02777
G1 X124.994 Y123.136 E.18472
G1 X124.994 Y122.232 E.02777
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
M73 P57 R11
G1 X124.994 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X124.994 Y118.623 E.031
G1 X125.16 Y118.533 E.0058
G1 X125.198 Y118.2 E.01029
G1 X130.802 Y118.2 E.17222
G1 X130.84 Y118.533 E.01029
G1 X131.006 Y118.623 E.0058
G1 X131.006 Y122.172 E.10905
G1 X130.629 Y122.232 F30000
G1 F12000
G1 X130.629 Y122.759 E.01618
G1 X125.371 Y122.759 E.16155
G1 X125.371 Y122.232 E.01618
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X125.371 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X125.371 Y118.804 E.02544
G1 X125.462 Y118.759 E.00311
G1 X125.522 Y118.577 E.00588
G1 X130.478 Y118.577 E.15227
G1 X130.538 Y118.759 E.00588
G1 X130.629 Y118.804 E.00311
G1 X130.629 Y122.172 E.10349
G1 X130.252 Y122.232 F30000
G1 F12000
G1 X130.252 Y122.382 E.0046
G1 X125.748 Y122.382 E.13838
G1 X125.748 Y122.232 E.0046
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X125.748 Y119.632 E.07989
; Slow Down End
G1 F12000
G1 X125.748 Y119.03 E.01848
G1 X125.774 Y118.954 E.00248
G1 X130.175 Y118.954 E.13525
G1 X130.252 Y118.992 E.00263
G1 X130.252 Y122.172 E.0977
G1 X126.125 Y119.331 F30000
G1 F12000
G1 X129.875 Y119.331 E.1152
G1 X129.875 Y119.632 E.00924
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X129.875 Y122.004 E.0729
G1 X126.125 Y122.004 E.1152
G1 X126.125 Y119.632 E.0729
; Slow Down End
G1 F12000
G1 X126.125 Y119.391 E.0074
G1 X126.502 Y119.708 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X129.498 Y119.708 E.09203
G1 X129.498 Y121.627 E.05897
G1 X126.502 Y121.627 E.09203
G1 X126.502 Y119.768 E.05713
; Slow Down End
G1 X129.121 Y120.085 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X129.121 Y121.25 E.0358
G1 X126.879 Y121.25 E.06886
G1 X126.879 Y120.085 E.0358
G1 X129.061 Y120.085 E.06702
; Slow Down End
G1 X128.735 Y120.471 F30000
; Slow Down Start
; LINE_WIDTH: 0.43695
G1 F3000;_EXTRUDE_SET_SPEED
G1 X128.735 Y120.865 E.01265
G1 X127.265 Y120.865 E.0472
G1 X127.265 Y120.471 E.01265
G1 X128.675 Y120.471 E.04527
; Slow Down End
; WIPE_START
G1 X127.265 Y120.471 E-.53578
G1 X127.265 Y120.865 E-.14974
G1 X127.461 Y120.865 E-.07448
; WIPE_END
G1 E-.04 F1800
G1 X135.093 Y120.947 Z3.2 F30000
G1 X180.249 Y121.435 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X178.62 Y121.435 E.05401
G1 X177.227 Y122.828 E.06535
G1 X178.56 Y122.828 E.04421
G1 X177.167 Y121.435 E.06535
G1 X170.944 Y121.435 E.20642
G1 X169.551 Y122.828 E.06535
G1 X170.884 Y122.828 E.04421
G1 X169.491 Y121.435 E.06535
G1 X167.863 Y121.435 E.05401
G1 X183.006 Y119.622 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y118.2 E.04369
G1 X167.198 Y118.2 E.48573
G1 X167.16 Y118.533 E.01029
G1 X166.994 Y118.623 E.0058
G1 X166.994 Y121.043 E.07437
G1 X183.006 Y121.043 E.49198
G1 X183.006 Y119.682 E.04184
G1 X182.629 Y119.622 F30000
G1 F12000
G1 X182.629 Y118.577 E.0321
G1 X167.522 Y118.577 E.46417
G1 X167.462 Y118.759 E.00588
G1 X167.371 Y118.804 E.00311
G1 X167.371 Y120.666 E.05723
G1 X182.629 Y120.666 E.46881
G1 X182.629 Y119.682 E.03026
G1 X182.252 Y119.622 F30000
G1 F12000
G1 X182.252 Y118.954 E.02051
G1 X167.774 Y118.954 E.44486
G2 X167.748 Y120.289 I17.494 J1.001 E.04104
G1 X182.252 Y120.289 E.44564
G1 X182.252 Y119.682 E.01867
G1 X181.824 Y119.622 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X181.824 Y119.382 E.00935
G1 X168.176 Y119.382 E.53278
G1 X168.176 Y119.861 E.0187
G1 X181.824 Y119.861 E.53278
G1 X181.824 Y119.682 E.00701
; WIPE_START
G1 X181.824 Y119.861 E-.06823
G1 X180.003 Y119.861 E-.69177
; WIPE_END
G1 E-.04 F1800
G1 X183.075 Y117.585 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.583 Y117.077 E.02207
G1 X183.583 Y116.544
G1 X182.541 Y117.585 E.04525
G1 X182.008 Y117.585
G1 X183.246 Y116.347 E.05379
G1 X182.713 Y116.347
G1 X181.475 Y117.585 E.05379
G1 X180.942 Y117.585
G1 X182.18 Y116.347 E.05379
G1 X181.646 Y116.347
G1 X180.408 Y117.585 E.05379
G1 X179.875 Y117.585
G1 X181.113 Y116.347 E.05379
M73 P58 R11
G1 X180.58 Y116.347
G1 X179.342 Y117.585 E.05379
G1 X178.809 Y117.585
G1 X180.047 Y116.347 E.05379
G1 X179.513 Y116.347
G1 X178.275 Y117.585 E.05379
G1 X177.742 Y117.585
G1 X178.98 Y116.347 E.05379
G1 X178.447 Y116.347
G1 X177.209 Y117.585 E.05379
G1 X176.676 Y117.585
G1 X177.913 Y116.347 E.05379
G1 X177.38 Y116.347
G1 X176.142 Y117.585 E.05379
G1 X175.609 Y117.585
G1 X176.847 Y116.347 E.05379
G1 X176.314 Y116.347
G1 X175.076 Y117.585 E.05379
G1 X174.543 Y117.585
G1 X175.78 Y116.347 E.05379
G1 X175.247 Y116.347
G1 X174.009 Y117.585 E.05379
G1 X173.476 Y117.585
G1 X174.714 Y116.347 E.05379
G1 X174.181 Y116.347
G1 X172.943 Y117.585 E.05379
G1 X172.41 Y117.585
G1 X173.647 Y116.347 E.05379
G1 X173.114 Y116.347
G1 X171.876 Y117.585 E.05379
G1 X171.343 Y117.585
G1 X172.581 Y116.347 E.05379
G1 X172.048 Y116.347
G1 X170.81 Y117.585 E.05379
G1 X170.276 Y117.585
G1 X171.514 Y116.347 E.05379
G1 X170.981 Y116.347
G1 X169.743 Y117.585 E.05379
G1 X169.21 Y117.585
G1 X170.448 Y116.347 E.05379
G1 X169.915 Y116.347
G1 X168.677 Y117.585 E.05379
G1 X168.143 Y117.585
G1 X169.381 Y116.347 E.05379
G1 X168.848 Y116.347
G1 X167.61 Y117.585 E.05379
G1 X167.077 Y117.585
G1 X168.315 Y116.347 E.05379
G1 X167.782 Y116.347
G1 X166.544 Y117.585 E.05379
G1 X166.01 Y117.585
G1 X167.248 Y116.347 E.05379
G1 X166.715 Y116.347
G1 X165.477 Y117.585 E.05379
G1 X164.944 Y117.585
G1 X166.182 Y116.347 E.05379
G1 X165.649 Y116.347
G1 X164.411 Y117.585 E.05379
G1 X163.877 Y117.585
G1 X165.115 Y116.347 E.05379
G1 X164.582 Y116.347
G1 X163.344 Y117.585 E.05379
G1 X162.811 Y117.585
G1 X164.049 Y116.347 E.05379
G1 X163.516 Y116.347
G1 X162.278 Y117.585 E.05379
G1 X161.744 Y117.585
G1 X162.982 Y116.347 E.05379
G1 X162.449 Y116.347
G1 X161.211 Y117.585 E.05379
G1 X160.678 Y117.585
G1 X161.916 Y116.347 E.05379
G1 X161.382 Y116.347
G1 X160.145 Y117.585 E.05379
G1 X159.611 Y117.585
G1 X160.849 Y116.347 E.05379
G1 X160.316 Y116.347
G1 X159.078 Y117.585 E.05379
G1 X158.545 Y117.585
G1 X159.783 Y116.347 E.05379
G1 X159.249 Y116.347
G1 X158.012 Y117.585 E.05379
G1 X157.478 Y117.585
G1 X158.716 Y116.347 E.05379
G1 X158.183 Y116.347
G1 X156.945 Y117.585 E.05379
G1 X156.412 Y117.585
G1 X157.65 Y116.347 E.05379
G1 X157.116 Y116.347
G1 X155.879 Y117.585 E.05379
G1 X155.345 Y117.585
G1 X156.583 Y116.347 E.05379
G1 X156.05 Y116.347
G1 X154.812 Y117.585 E.05379
G1 X154.279 Y117.585
G1 X155.517 Y116.347 E.05379
G1 X154.983 Y116.347
G1 X153.745 Y117.585 E.05379
G1 X153.212 Y117.585
G1 X154.45 Y116.347 E.05379
G1 X153.917 Y116.347
G1 X152.679 Y117.585 E.05379
G1 X152.146 Y117.585
G1 X153.384 Y116.347 E.05379
G1 X152.85 Y116.347
G1 X151.612 Y117.585 E.05379
G1 X151.079 Y117.585
G1 X152.317 Y116.347 E.05379
G1 X151.784 Y116.347
G1 X150.546 Y117.585 E.05379
G1 X150.013 Y117.585
G1 X151.251 Y116.347 E.05379
G1 X150.717 Y116.347
G1 X149.479 Y117.585 E.05379
G1 X148.946 Y117.585
G1 X150.184 Y116.347 E.05379
G1 X149.651 Y116.347
G1 X148.413 Y117.585 E.05379
G1 X147.88 Y117.585
G1 X149.118 Y116.347 E.05379
G1 X148.584 Y116.347
G1 X147.346 Y117.585 E.05379
G1 X146.813 Y117.585
G1 X148.051 Y116.347 E.05379
G1 X147.518 Y116.347
G1 X146.28 Y117.585 E.05379
G1 X145.747 Y117.585
G1 X146.985 Y116.347 E.05379
G1 X146.451 Y116.347
G1 X145.213 Y117.585 E.05379
G1 X144.68 Y117.585
G1 X145.918 Y116.347 E.05379
G1 X145.385 Y116.347
G1 X144.147 Y117.585 E.05379
G1 X143.614 Y117.585
G1 X144.852 Y116.347 E.05379
G1 X144.318 Y116.347
G1 X143.08 Y117.585 E.05379
G1 X142.547 Y117.585
G1 X143.785 Y116.347 E.05379
G1 X143.252 Y116.347
G1 X142.014 Y117.585 E.05379
G1 X141.481 Y117.585
G1 X142.718 Y116.347 E.05379
G1 X142.185 Y116.347
G1 X140.947 Y117.585 E.05379
G1 X140.414 Y117.585
G1 X141.652 Y116.347 E.05379
G1 X141.119 Y116.347
G1 X139.881 Y117.585 E.05379
G1 X139.348 Y117.585
G1 X140.585 Y116.347 E.05379
G1 X140.052 Y116.347
G1 X138.814 Y117.585 E.05379
G1 X138.281 Y117.585
G1 X139.519 Y116.347 E.05379
G1 X138.986 Y116.347
G1 X137.748 Y117.585 E.05379
G1 X137.215 Y117.585
G1 X138.452 Y116.347 E.05379
G1 X137.919 Y116.347
G1 X136.681 Y117.585 E.05379
G1 X136.148 Y117.585
G1 X137.386 Y116.347 E.05379
G1 X136.853 Y116.347
G1 X135.615 Y117.585 E.05379
G1 X135.081 Y117.585
G1 X136.319 Y116.347 E.05379
G1 X135.786 Y116.347
G1 X134.548 Y117.585 E.05379
G1 X134.015 Y117.585
G1 X135.253 Y116.347 E.05379
G1 X134.72 Y116.347
G1 X133.482 Y117.585 E.05379
G1 X132.948 Y117.585
G1 X134.186 Y116.347 E.05379
G1 X133.653 Y116.347
G1 X132.415 Y117.585 E.05379
G1 X131.882 Y117.585
G1 X133.12 Y116.347 E.05379
G1 X132.587 Y116.347
G1 X131.349 Y117.585 E.05379
G1 X130.815 Y117.585
G1 X132.053 Y116.347 E.05379
G1 X131.52 Y116.347
G1 X130.282 Y117.585 E.05379
G1 X129.749 Y117.585
G1 X130.987 Y116.347 E.05379
G1 X130.454 Y116.347
G1 X129.216 Y117.585 E.05379
G1 X128.682 Y117.585
G1 X129.92 Y116.347 E.05379
G1 X129.387 Y116.347
G1 X128.149 Y117.585 E.05379
G1 X127.616 Y117.585
G1 X128.854 Y116.347 E.05379
G1 X128.321 Y116.347
G1 X127.083 Y117.585 E.05379
G1 X126.549 Y117.585
G1 X127.787 Y116.347 E.05379
G1 X127.254 Y116.347
G1 X126.016 Y117.585 E.05379
G1 X125.483 Y117.585
G1 X126.721 Y116.347 E.05379
G1 X126.187 Y116.347
G1 X124.95 Y117.585 E.05379
G1 X124.416 Y117.585
G1 X125.654 Y116.347 E.05379
G1 X125.121 Y116.347
G1 X123.883 Y117.585 E.05379
G1 X123.35 Y117.585
G1 X124.588 Y116.347 E.05379
G1 X124.054 Y116.347
G1 X122.817 Y117.585 E.05379
G1 X122.283 Y117.585
G1 X123.521 Y116.347 E.05379
G1 X122.988 Y116.347
G1 X121.75 Y117.585 E.05379
G1 X121.217 Y117.585
G1 X122.455 Y116.347 E.05379
G1 X121.921 Y116.347
G1 X120.684 Y117.585 E.05379
G1 X120.15 Y117.585
G1 X121.388 Y116.347 E.05379
G1 X120.855 Y116.347
G1 X119.617 Y117.585 E.05379
G1 X119.084 Y117.585
G1 X120.322 Y116.347 E.05379
G1 X119.788 Y116.347
G1 X118.55 Y117.585 E.05379
G1 X118.017 Y117.585
G1 X119.255 Y116.347 E.05379
G1 X118.722 Y116.347
G1 X117.484 Y117.585 E.05379
G1 X116.951 Y117.585
G1 X118.189 Y116.347 E.05379
G1 X117.655 Y116.347
G1 X116.417 Y117.585 E.05379
G1 X115.884 Y117.585
G1 X117.122 Y116.347 E.05379
G1 X116.589 Y116.347
G1 X115.351 Y117.585 E.05379
G1 X114.818 Y117.585
G1 X116.056 Y116.347 E.05379
G1 X115.522 Y116.347
G1 X114.284 Y117.585 E.05379
G1 X113.751 Y117.585
G1 X114.989 Y116.347 E.05379
G1 X114.456 Y116.347
G1 X113.218 Y117.585 E.05379
G1 X112.685 Y117.585
G1 X113.923 Y116.347 E.05379
G1 X113.389 Y116.347
G1 X112.151 Y117.585 E.05379
G1 X111.618 Y117.585
G1 X112.856 Y116.347 E.05379
G1 X112.323 Y116.347
G1 X111.085 Y117.585 E.05379
G1 X110.552 Y117.585
G1 X111.79 Y116.347 E.05379
G1 X111.256 Y116.347
G1 X110.018 Y117.585 E.05379
G1 X109.485 Y117.585
G1 X110.723 Y116.347 E.05379
G1 X110.19 Y116.347
G1 X108.952 Y117.585 E.05379
G1 X108.419 Y117.585
G1 X109.656 Y116.347 E.05379
G1 X109.123 Y116.347
G1 X107.885 Y117.585 E.05379
G1 X107.352 Y117.585
G1 X108.59 Y116.347 E.05379
G1 X108.057 Y116.347
G1 X106.819 Y117.585 E.05379
G1 X106.286 Y117.585
G1 X107.523 Y116.347 E.05379
G1 X106.99 Y116.347
G1 X105.752 Y117.585 E.05379
G1 X105.219 Y117.585
G1 X106.457 Y116.347 E.05379
G1 X105.924 Y116.347
G1 X104.686 Y117.585 E.05379
G1 X104.153 Y117.585
G1 X105.39 Y116.347 E.05379
G1 X104.857 Y116.347
G1 X103.619 Y117.585 E.05379
G1 X103.086 Y117.585
G1 X104.324 Y116.347 E.05379
G1 X103.791 Y116.347
G1 X102.553 Y117.585 E.05379
G1 X102.02 Y117.585
G1 X103.257 Y116.347 E.05379
G1 X102.724 Y116.347
G1 X101.486 Y117.585 E.05379
G1 X100.953 Y117.585
G1 X102.191 Y116.347 E.05379
G1 X101.658 Y116.347
G1 X100.42 Y117.585 E.05379
G1 X99.886 Y117.585
G1 X101.124 Y116.347 E.05379
G1 X100.591 Y116.347
G1 X99.353 Y117.585 E.05379
G1 X98.82 Y117.585
G1 X100.058 Y116.347 E.05379
G1 X99.525 Y116.347
G1 X98.287 Y117.585 E.05379
G1 X97.753 Y117.585
G1 X98.991 Y116.347 E.05379
G1 X98.458 Y116.347
G1 X97.22 Y117.585 E.05379
G1 X96.687 Y117.585
G1 X97.925 Y116.347 E.05379
G1 X97.392 Y116.347
G1 X96.154 Y117.585 E.05379
G1 X95.62 Y117.585
G1 X96.858 Y116.347 E.05379
G1 X96.325 Y116.347
G1 X95.087 Y117.585 E.05379
G1 X94.554 Y117.585
G1 X95.792 Y116.347 E.05379
G1 X95.259 Y116.347
G1 X94.021 Y117.585 E.05379
G1 X93.487 Y117.585
G1 X94.725 Y116.347 E.05379
G1 X94.192 Y116.347
G1 X92.954 Y117.585 E.05379
G1 X92.421 Y117.585
G1 X93.659 Y116.347 E.05379
G1 X93.126 Y116.347
G1 X91.888 Y117.585 E.05379
G1 X91.354 Y117.585
G1 X92.592 Y116.347 E.05379
G1 X92.059 Y116.347
G1 X90.821 Y117.585 E.05379
G1 X90.288 Y117.585
G1 X91.526 Y116.347 E.05379
G1 X90.992 Y116.347
G1 X89.755 Y117.585 E.05379
G1 X89.221 Y117.585
G1 X90.459 Y116.347 E.05379
G1 X89.926 Y116.347
G1 X88.688 Y117.585 E.05379
G1 X88.155 Y117.585
G1 X89.393 Y116.347 E.05379
G1 X88.859 Y116.347
G1 X87.622 Y117.585 E.05379
G1 X87.088 Y117.585
G1 X88.326 Y116.347 E.05379
G1 X87.793 Y116.347
G1 X86.555 Y117.585 E.05379
G1 X86.022 Y117.585
G1 X87.26 Y116.347 E.05379
G1 X86.726 Y116.347
G1 X85.489 Y117.585 E.05379
G1 X84.955 Y117.585
G1 X86.193 Y116.347 E.05379
G1 X85.66 Y116.347
G1 X84.422 Y117.585 E.05379
G1 X83.889 Y117.585
G1 X85.127 Y116.347 E.05379
G1 X84.593 Y116.347
G1 X83.355 Y117.585 E.05379
G1 X82.822 Y117.585
G1 X84.06 Y116.347 E.05379
G1 X83.527 Y116.347
G1 X82.289 Y117.585 E.05379
G1 X81.756 Y117.585
G1 X82.994 Y116.347 E.05379
G1 X82.46 Y116.347
G1 X81.222 Y117.585 E.05379
G1 X80.689 Y117.585
G1 X81.927 Y116.347 E.05379
G1 X81.394 Y116.347
G1 X80.156 Y117.585 E.05379
G1 X79.623 Y117.585
G1 X80.861 Y116.347 E.05379
G1 X80.327 Y116.347
G1 X79.089 Y117.585 E.05379
G1 X78.556 Y117.585
G1 X79.794 Y116.347 E.05379
G1 X79.261 Y116.347
G1 X78.023 Y117.585 E.05379
G1 X77.49 Y117.585
G1 X78.728 Y116.347 E.05379
G1 X78.194 Y116.347
G1 X76.956 Y117.585 E.05379
G1 X76.423 Y117.585
G1 X77.661 Y116.347 E.05379
G1 X77.128 Y116.347
G1 X75.89 Y117.585 E.05379
G1 X75.357 Y117.585
G1 X76.595 Y116.347 E.05379
G1 X76.061 Y116.347
G1 X74.823 Y117.585 E.05379
G1 X74.29 Y117.585
G1 X75.528 Y116.347 E.05379
G1 X74.995 Y116.347
G1 X73.757 Y117.585 E.05379
G1 X73.224 Y117.585
G1 X74.461 Y116.347 E.05379
G1 X73.928 Y116.347
G1 X72.69 Y117.585 E.05379
G1 X72.417 Y117.325
G1 X73.395 Y116.347 E.04248
G1 X72.862 Y116.347
G1 X72.417 Y116.792 E.01931
; WIPE_START
M204 S10000
G1 X72.862 Y116.347 E-.23878
G1 X73.395 Y116.347 E-.20264
G1 X72.802 Y116.94 E-.31858
; WIPE_END
G1 E-.04 F1800
G1 X80.435 Y116.901 Z3.2 F30000
G1 X183.601 Y116.377 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.144598
G1 F15000
G2 X183.316 Y116.418 I-.093 J.365 E.00245
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X183.415 Y116.377 E-.27742
G1 X183.601 Y116.377 E-.48258
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 15/32
; update layer progress
M73 L15
M991 S0 P14 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.2 I-1.217 J-.012 P1  F30000
G1 X183.398 Y137.398 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y137.398 E3.6753
G1 X72.602 Y134.861 E.08416
G1 X72.602 Y134.461 E.01327
G1 F14852.35
G1 X72.602 Y134.401 E.00199
G1 F13500
G1 X183.398 Y134.401 E3.6753
G1 F14852.35
G1 X183.398 Y134.461 E.00199
G1 F15476.087
G1 X183.398 Y134.861 E.01327
G1 X183.398 Y137.338 E.08217
M204 S250
G1 X183.79 Y137.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y137.79 E3.42854
G1 X72.21 Y135.247 E.07813
G1 X72.21 Y134.847 E.01229
G1 F6459.938
G1 X72.21 Y134.447 E.01229
G1 F1800
G1 X72.21 Y134.078 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y134.009 E.0023
G1 X183.79 Y134.009 E3.70131
G1 X183.79 Y134.078 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y134.447 E.01134
G1 F6459.938
G1 X183.79 Y134.847 E.01229
G1 F12000
G1 X183.79 Y135.247 E.01229
G1 X183.79 Y137.73 E.07629
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X181.79 Y137.731 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X183 Y137 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.43156
G1 F3000;_EXTRUDE_SET_SPEED
G1 X73.06 Y137 E3.48172
; Slow Down End
G1 X73.05 Y134.849 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53261
G1 F12865.282
G1 X73.05 Y135.339 E.01954
G1 X182.95 Y135.339 E4.38536
G1 X182.95 Y134.849 E.01954
G1 X73.11 Y134.849 E4.38297
G1 X74.751 Y135.787 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X76.38 Y135.787 E.05401
G1 X77.195 Y136.602 E.03823
G1 X79.018 Y136.602 E.06048
G1 X79.833 Y135.787 E.03823
G1 X84.056 Y135.787 E.14008
G1 X84.871 Y136.602 E.03823
G1 X86.694 Y136.602 E.06048
G1 X87.509 Y135.787 E.03823
G1 X91.732 Y135.787 E.14008
G1 X92.547 Y136.602 E.03823
G1 X94.37 Y136.602 E.06048
M73 P59 R11
G1 X95.185 Y135.787 E.03823
G1 X99.408 Y135.787 E.14008
G1 X100.222 Y136.602 E.03823
G1 X102.046 Y136.602 E.06048
G1 X102.861 Y135.787 E.03823
G1 X107.083 Y135.787 E.14008
G1 X107.898 Y136.602 E.03823
G1 X109.722 Y136.602 E.06048
G1 X110.537 Y135.787 E.03823
G1 X114.759 Y135.787 E.14008
G1 X115.574 Y136.602 E.03823
G1 X117.398 Y136.602 E.06048
G1 X118.213 Y135.787 E.03823
G1 X122.435 Y135.787 E.14008
G1 X123.25 Y136.602 E.03823
G1 X125.074 Y136.602 E.06048
G1 X125.889 Y135.787 E.03823
G1 X130.111 Y135.787 E.14008
G1 X130.926 Y136.602 E.03823
G1 X132.75 Y136.602 E.06048
G1 X133.565 Y135.787 E.03823
G1 X137.787 Y135.787 E.14008
G1 X138.602 Y136.602 E.03823
G1 X140.426 Y136.602 E.06048
G1 X141.241 Y135.787 E.03823
G1 X145.463 Y135.787 E.14008
G1 X146.278 Y136.602 E.03823
G1 X148.102 Y136.602 E.06048
G1 X148.917 Y135.787 E.03823
G1 X153.139 Y135.787 E.14008
G1 X153.954 Y136.602 E.03823
G1 X155.778 Y136.602 E.06048
G1 X156.592 Y135.787 E.03823
G1 X160.815 Y135.787 E.14007
G1 X161.63 Y136.602 E.03823
G1 X163.453 Y136.602 E.06048
G1 X164.268 Y135.787 E.03823
G1 X168.491 Y135.787 E.14008
G1 X169.306 Y136.602 E.03823
G1 X171.129 Y136.602 E.06048
G1 X171.944 Y135.787 E.03823
G1 X176.167 Y135.787 E.14007
G1 X176.982 Y136.602 E.03823
G1 X178.805 Y136.602 E.06048
G1 X179.62 Y135.787 E.03823
G1 X181.249 Y135.787 E.05401
; WIPE_START
G1 X179.62 Y135.787 E-.61876
G1 X179.357 Y136.05 E-.14124
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.4 I.416 J-1.144 P1  F30000
G1 X131.398 Y118.608 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X131.398 Y124.148 E.18376
G1 X131.398 Y124.548 E.01327
G1 F14331.075
G1 X131.398 Y124.948 E.01327
G1 F6685.538
G1 X131.398 Y125.348 E.01327
G1 F1920
G1 X131.398 Y125.728 E.01262
G1 F600
G1 X124.602 Y125.728 E.22543
G1 F1920
G1 X124.602 Y125.348 E.01262
G1 F6685.538
G1 X124.602 Y124.948 E.01327
G1 F14331.075
G1 X124.602 Y124.548 E.01327
G1 F15476.087
G1 X124.602 Y124.148 E.01327
G1 X124.602 Y118.608 E.18376
G1 X131.338 Y118.608 E.22344
; WIPE_START
G1 X131.36 Y120.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X123.804 Y119.525 Z3.4 F30000
G1 X117.398 Y118.608 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X117.398 Y124.148 E.18376
M73 P60 R11
G1 X117.398 Y124.548 E.01327
G1 F14331.075
G1 X117.398 Y124.948 E.01327
G1 F6685.538
G1 X117.398 Y125.348 E.01327
G1 F1920
G1 X117.398 Y125.728 E.01262
G1 F600
G1 X110.602 Y125.728 E.22543
G1 F1920
G1 X110.602 Y125.348 E.01262
G1 F6685.538
G1 X110.602 Y124.948 E.01327
G1 F14331.075
G1 X110.602 Y124.548 E.01327
G1 F15476.087
G1 X110.602 Y124.148 E.01327
G1 X110.602 Y118.608 E.18376
G1 X117.338 Y118.608 E.22344
; WIPE_START
G1 X117.36 Y120.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.804 Y119.525 Z3.4 F30000
G1 X103.398 Y118.608 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X103.398 Y124.148 E.18376
G1 X103.398 Y124.548 E.01327
G1 F14331.075
G1 X103.398 Y124.948 E.01327
G1 F6685.538
G1 X103.398 Y125.348 E.01327
G1 F1920
G1 X103.398 Y125.728 E.01262
G1 F600
G1 X96.602 Y125.728 E.22543
G1 F1920
G1 X96.602 Y125.348 E.01262
G1 F6685.538
G1 X96.602 Y124.948 E.01327
G1 F14331.075
G1 X96.602 Y124.548 E.01327
G1 F15476.087
G1 X96.602 Y124.148 E.01327
G1 X96.602 Y118.608 E.18376
G1 X103.338 Y118.608 E.22344
; WIPE_START
G1 X103.36 Y120.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X95.804 Y119.525 Z3.4 F30000
G1 X89.398 Y118.608 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X89.398 Y124.148 E.18376
G1 X89.398 Y124.548 E.01327
G1 F14331.075
G1 X89.398 Y124.948 E.01327
G1 F6685.538
G1 X89.398 Y125.348 E.01327
G1 F1920
G1 X89.398 Y125.728 E.01262
G1 F600
G1 X72.602 Y125.728 E.55715
G1 F1920
G1 X72.602 Y125.348 E.01262
G1 F6685.538
G1 X72.602 Y124.948 E.01327
G1 F14331.075
G1 X72.602 Y124.548 E.01327
G1 F15476.087
G1 X72.602 Y124.148 E.01327
G1 X72.602 Y118.608 E.18376
G1 X89.338 Y118.608 E.55516
; WIPE_START
G1 X89.36 Y120.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X96.986 Y120.298 Z3.4 F30000
G1 X138.602 Y118.608 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X145.398 Y118.608 E.22543
G1 X145.398 Y124.148 E.18376
G1 X145.398 Y124.548 E.01327
G1 F14331.075
G1 X145.398 Y124.948 E.01327
G1 F6685.538
G1 X145.398 Y125.348 E.01327
G1 F1920
G1 X145.398 Y125.728 E.01262
G1 F600
G1 X138.602 Y125.728 E.22543
G1 F1920
G1 X138.602 Y125.348 E.01262
G1 F6685.538
G1 X138.602 Y124.948 E.01327
G1 F14331.075
G1 X138.602 Y124.548 E.01327
G1 F15476.087
G1 X138.602 Y124.148 E.01327
G1 X138.602 Y118.668 E.18177
; WIPE_START
G1 X140.602 Y118.65 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X148.234 Y118.623 Z3.4 F30000
G1 X152.602 Y118.608 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X159.398 Y118.608 E.22543
G1 X159.398 Y124.148 E.18376
G1 X159.398 Y124.548 E.01327
G1 F14331.075
G1 X159.398 Y124.948 E.01327
G1 F6685.538
G1 X159.398 Y125.348 E.01327
G1 F1920
G1 X159.398 Y125.728 E.01262
G1 F600
G1 X152.602 Y125.728 E.22543
G1 F1920
G1 X152.602 Y125.348 E.01262
G1 F6685.538
G1 X152.602 Y124.948 E.01327
G1 F14331.075
G1 X152.602 Y124.548 E.01327
G1 F15476.087
G1 X152.602 Y124.148 E.01327
G1 X152.602 Y118.668 E.18177
; WIPE_START
G1 X154.602 Y118.65 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X162.234 Y118.623 Z3.4 F30000
G1 X166.602 Y118.608 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X183.398 Y118.608 E.55715
G1 X183.398 Y124.148 E.18376
G1 X183.398 Y124.548 E.01327
G1 F14331.075
G1 X183.398 Y124.948 E.01327
G1 F6685.538
G1 X183.398 Y125.348 E.01327
G1 F1920
G1 X183.398 Y125.728 E.01262
G1 F600
G1 X166.602 Y125.728 E.55715
G1 F1920
G1 X166.602 Y125.348 E.01262
G1 F6685.538
G1 X166.602 Y124.948 E.01327
G1 F14331.075
G1 X166.602 Y124.548 E.01327
G1 F15476.087
G1 X166.602 Y124.148 E.01327
G1 X166.602 Y118.668 E.18177
; WIPE_START
G1 X168.602 Y118.661 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X160.97 Y118.687 Z3.4 F30000
G1 X131.79 Y118.79 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y124.561 E.17733
G1 X131.79 Y124.961 E.01229
G1 F6459.938
G1 X131.79 Y125.361 E.01229
G1 F1800
G1 X131.79 Y125.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y126.12 E.01294
G1 X124.21 Y126.12 E.25144
G1 X124.21 Y125.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y125.361 E.01134
G1 F6459.938
G1 X124.21 Y124.961 E.01229
G1 F12000
G1 X124.21 Y124.561 E.01229
G1 X124.21 Y118.79 E.17733
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y124.561 E.17733
G1 X117.79 Y124.961 E.01229
G1 F6459.938
G1 X117.79 Y125.361 E.01229
G1 F1800
G1 X117.79 Y125.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y126.12 E.01294
G1 X110.21 Y126.12 E.25144
G1 X110.21 Y125.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y125.361 E.01134
G1 F6459.938
G1 X110.21 Y124.961 E.01229
G1 F12000
G1 X110.21 Y124.561 E.01229
G1 X110.21 Y118.79 E.17733
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y124.561 E.17733
G1 X103.79 Y124.961 E.01229
G1 F6459.938
G1 X103.79 Y125.361 E.01229
G1 F1800
G1 X103.79 Y125.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y126.12 E.01294
G1 X96.21 Y126.12 E.25144
G1 X96.21 Y125.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y125.361 E.01134
G1 F6459.938
G1 X96.21 Y124.961 E.01229
G1 F12000
G1 X96.21 Y124.561 E.01229
G1 X96.21 Y118.79 E.17733
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y124.561 E.17733
G1 X89.79 Y124.961 E.01229
G1 F6459.938
G1 X89.79 Y125.361 E.01229
G1 F1800
G1 X89.79 Y125.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y126.12 E.01294
G1 X72.21 Y126.12 E.58316
G1 X72.21 Y125.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y125.361 E.01134
G1 F6459.938
G1 X72.21 Y124.961 E.01229
G1 F12000
G1 X72.21 Y124.561 E.01229
G1 X72.21 Y116.94 E.23417
G1 X183.79 Y116.94 E3.42854
G1 X183.79 Y124.561 E.23417
G1 X183.79 Y124.961 E.01229
G1 F6459.938
G1 X183.79 Y125.361 E.01229
G1 F1800
G1 X183.79 Y125.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y126.12 E.01294
G1 F600
G1 X166.21 Y126.12 E.58316
G1 X166.21 Y125.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y125.361 E.01134
G1 F6459.938
G1 X166.21 Y124.961 E.01229
G1 F12000
G1 X166.21 Y124.561 E.01229
G1 X166.21 Y118.79 E.17733
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y124.561 E.17733
G1 X159.79 Y124.961 E.01229
G1 F6459.938
G1 X159.79 Y125.361 E.01229
G1 F1800
G1 X159.79 Y125.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y126.12 E.01294
G1 X152.21 Y126.12 E.25144
G1 X152.21 Y125.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y125.361 E.01134
G1 F6459.938
G1 X152.21 Y124.961 E.01229
G1 F12000
G1 X152.21 Y124.561 E.01229
G1 X152.21 Y118.79 E.17733
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y124.561 E.17733
G1 X145.79 Y124.961 E.01229
G1 F6459.938
G1 X145.79 Y125.361 E.01229
G1 F1800
G1 X145.79 Y125.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y126.12 E.01294
G1 X138.21 Y126.12 E.25144
G1 X138.21 Y125.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y125.361 E.01134
G1 F6459.938
G1 X138.21 Y124.961 E.01229
G1 F12000
G1 X138.21 Y124.561 E.01229
G1 X138.21 Y118.79 E.17733
G1 X131.85 Y118.79 E.19542
M204 S10000
G1 X131.594 Y118.503 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.22513
G1 F15000
G1 X138.406 Y118.503 E.10114
; WIPE_START
G1 X136.406 Y118.503 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X139.788 Y120.25 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.49902
G1 F13812.761
G1 X144.212 Y120.25 E.16444
G1 X144.212 Y119.794 E.01695
G1 X139.788 Y119.794 E.16444
G1 X139.788 Y120.19 E.01472
G1 X139.371 Y120.666 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X144.629 Y120.666 E.16155
G1 X144.629 Y119.377 E.03961
G1 X139.371 Y119.377 E.16155
G1 X139.371 Y120.606 E.03777
G1 X138.994 Y121.043 F30000
G1 F15000
G1 X145.006 Y121.043 E.18472
G1 X145.006 Y119 E.06279
G1 X138.994 Y119 E.18472
G1 X138.994 Y120.983 E.06094
G1 X141.869 Y121.435 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X140.241 Y121.435 E.05401
G1 X138.95 Y122.726 E.06053
G1 X138.95 Y121.598 E.03739
G1 X140.98 Y123.628 E.09523
G1 X142.609 Y123.628 E.05401
G1 X145.234 Y124.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y124.452 E.23226
G1 X138.935 Y124.905 E.01668
M73 P61 R11
G1 X145.065 Y124.905 E.22601
G1 X145.065 Y125.357 E.01668
G1 X138.766 Y125.357 E.23226
G1 X138.952 Y123.978 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y123.978 E.16725
; WIPE_START
G1 X142.988 Y123.978 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.594 Y118.503 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.22513
G1 F15000
G1 X152.406 Y118.503 E.10114
; WIPE_START
G1 X150.406 Y118.503 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X153.788 Y120.25 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.49902
G1 F13812.761
G1 X158.212 Y120.25 E.16444
G1 X158.212 Y119.794 E.01695
G1 X153.788 Y119.794 E.16444
G1 X153.788 Y120.19 E.01472
G1 X153.371 Y120.666 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X158.629 Y120.666 E.16155
G1 X158.629 Y119.377 E.03961
G1 X153.371 Y119.377 E.16155
G1 X153.371 Y120.606 E.03777
G1 X152.994 Y121.043 F30000
G1 F15000
G1 X159.006 Y121.043 E.18472
G1 X159.006 Y119 E.06279
G1 X152.994 Y119 E.18472
G1 X152.994 Y120.983 E.06094
G1 X152.952 Y123.978 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y123.978 E.16725
G1 X159.234 Y124.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y124.452 E.23226
G1 X152.935 Y124.905 E.01668
G1 X159.065 Y124.905 E.22601
G1 X159.065 Y125.357 E.01668
G1 X152.766 Y125.357 E.23226
G1 X157.961 Y123.628 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X156.332 Y123.628 E.05401
G1 X154.139 Y121.435 E.10288
G1 X155.593 Y121.435 E.04821
G1 X153.399 Y123.628 E.10288
G1 X152.95 Y123.628 E.0149
M73 P61 R10
G1 X152.95 Y122.449 E.03912
; WIPE_START
G1 X152.95 Y123.628 E-.44812
G1 X153.399 Y123.628 E-.17064
G1 X153.662 Y123.366 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X159.565 Y118.527 Z3.4 F30000
G1 X159.594 Y118.503 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.22513
G1 F15000
G1 X166.406 Y118.503 E.10114
; WIPE_START
G1 X164.406 Y118.503 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X166.952 Y123.978 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y123.978 E.4443
G1 X183.234 Y124.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y124.452 E.60098
G1 X166.935 Y124.905 E.01668
G1 X183.065 Y124.905 E.59472
G1 X183.065 Y125.357 E.01668
G1 X166.766 Y125.357 E.60098
G1 X180.988 Y123.628 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.36 Y123.628 E.05401
G1 X177.967 Y122.235 E.06536
G1 X177.82 Y122.235 E.00486
G1 X176.427 Y123.628 E.06536
G1 X171.684 Y123.628 E.15734
G1 X170.291 Y122.235 E.06536
G1 X170.144 Y122.235 E.00486
G1 X168.751 Y123.628 E.06536
G1 X167.123 Y123.628 E.05401
G1 X183.006 Y120.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y119 E.04368
G1 X166.994 Y119 E.49198
G1 X166.994 Y121.843 E.08737
G1 X183.006 Y121.843 E.49198
G1 X183.006 Y120.482 E.04184
G1 X182.629 Y120.422 F30000
G1 F12000
G1 X182.629 Y119.377 E.0321
G1 X167.371 Y119.377 E.46881
G1 X167.371 Y121.466 E.0642
G1 X182.629 Y121.466 E.46881
G1 X182.629 Y120.482 E.03025
G1 X182.252 Y120.422 F30000
G1 F12000
G1 X182.252 Y119.754 E.02051
G1 X167.748 Y119.754 E.44564
G1 X167.748 Y121.089 E.04102
G1 X182.252 Y121.089 E.44564
G1 X182.252 Y120.482 E.01867
G1 X181.824 Y120.422 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y120.182 E.00935
G1 X168.176 Y120.182 E.53272
G1 X168.176 Y120.661 E.0187
G1 X181.824 Y120.661 E.53272
G1 X181.824 Y120.482 E.00701
; WIPE_START
G1 X181.824 Y120.661 E-.06822
G1 X180.003 Y120.661 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X182.872 Y117.147 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.583 Y117.858 E.0309
G1 X183.576 Y118.385
G1 X182.338 Y117.147 E.05379
G1 X181.805 Y117.147
G1 X183.043 Y118.385 E.05379
G1 X182.51 Y118.385
G1 X181.272 Y117.147 E.05379
G1 X180.739 Y117.147
G1 X181.976 Y118.385 E.05379
G1 X181.443 Y118.385
G1 X180.205 Y117.147 E.05379
G1 X179.672 Y117.147
G1 X180.91 Y118.385 E.05379
G1 X180.377 Y118.385
G1 X179.139 Y117.147 E.05379
G1 X178.606 Y117.147
G1 X179.843 Y118.385 E.05379
G1 X179.31 Y118.385
G1 X178.072 Y117.147 E.05379
G1 X177.539 Y117.147
G1 X178.777 Y118.385 E.05379
G1 X178.244 Y118.385
G1 X177.006 Y117.147 E.05379
G1 X176.473 Y117.147
G1 X177.71 Y118.385 E.05379
G1 X177.177 Y118.385
G1 X175.939 Y117.147 E.05379
G1 X175.406 Y117.147
G1 X176.644 Y118.385 E.05379
G1 X176.111 Y118.385
G1 X174.873 Y117.147 E.05379
G1 X174.339 Y117.147
G1 X175.577 Y118.385 E.05379
G1 X175.044 Y118.385
G1 X173.806 Y117.147 E.05379
G1 X173.273 Y117.147
G1 X174.511 Y118.385 E.05379
G1 X173.978 Y118.385
G1 X172.74 Y117.147 E.05379
G1 X172.206 Y117.147
G1 X173.444 Y118.385 E.05379
G1 X172.911 Y118.385
G1 X171.673 Y117.147 E.05379
G1 X171.14 Y117.147
G1 X172.378 Y118.385 E.05379
G1 X171.845 Y118.385
G1 X170.607 Y117.147 E.05379
G1 X170.073 Y117.147
G1 X171.311 Y118.385 E.05379
G1 X170.778 Y118.385
G1 X169.54 Y117.147 E.05379
G1 X169.007 Y117.147
G1 X170.245 Y118.385 E.05379
G1 X169.712 Y118.385
G1 X168.474 Y117.147 E.05379
G1 X167.94 Y117.147
G1 X169.178 Y118.385 E.05379
G1 X168.645 Y118.385
G1 X167.407 Y117.147 E.05379
G1 X166.874 Y117.147
G1 X168.112 Y118.385 E.05379
G1 X167.579 Y118.385
G1 X166.341 Y117.147 E.05379
G1 X165.807 Y117.147
G1 X167.045 Y118.385 E.05379
G1 X166.512 Y118.385
G1 X165.274 Y117.147 E.05379
G1 X164.741 Y117.147
G1 X165.979 Y118.385 E.05379
G1 X165.445 Y118.385
G1 X164.208 Y117.147 E.05379
G1 X163.674 Y117.147
G1 X164.912 Y118.385 E.05379
G1 X164.379 Y118.385
G1 X163.141 Y117.147 E.05379
G1 X162.608 Y117.147
G1 X163.846 Y118.385 E.05379
G1 X163.312 Y118.385
G1 X162.075 Y117.147 E.05379
G1 X161.541 Y117.147
G1 X162.779 Y118.385 E.05379
G1 X162.246 Y118.385
G1 X161.008 Y117.147 E.05379
G1 X160.475 Y117.147
G1 X161.713 Y118.385 E.05379
G1 X161.179 Y118.385
G1 X159.942 Y117.147 E.05379
G1 X159.408 Y117.147
G1 X160.646 Y118.385 E.05379
G1 X160.113 Y118.385
G1 X158.875 Y117.147 E.05379
G1 X158.342 Y117.147
G1 X159.58 Y118.385 E.05379
G1 X159.046 Y118.385
G1 X157.809 Y117.147 E.05379
G1 X157.275 Y117.147
G1 X158.513 Y118.385 E.05379
G1 X157.98 Y118.385
G1 X156.742 Y117.147 E.05379
G1 X156.209 Y117.147
G1 X157.447 Y118.385 E.05379
G1 X156.913 Y118.385
G1 X155.675 Y117.147 E.05379
G1 X155.142 Y117.147
G1 X156.38 Y118.385 E.05379
G1 X155.847 Y118.385
G1 X154.609 Y117.147 E.05379
G1 X154.076 Y117.147
G1 X155.314 Y118.385 E.05379
G1 X154.78 Y118.385
G1 X153.542 Y117.147 E.05379
G1 X153.009 Y117.147
G1 X154.247 Y118.385 E.05379
G1 X153.714 Y118.385
G1 X152.476 Y117.147 E.05379
G1 X151.943 Y117.147
G1 X153.181 Y118.385 E.05379
G1 X152.647 Y118.385
G1 X151.409 Y117.147 E.05379
G1 X150.876 Y117.147
G1 X152.114 Y118.385 E.05379
G1 X151.581 Y118.385
G1 X150.343 Y117.147 E.05379
G1 X149.81 Y117.147
G1 X151.048 Y118.385 E.05379
G1 X150.514 Y118.385
G1 X149.276 Y117.147 E.05379
G1 X148.743 Y117.147
G1 X149.981 Y118.385 E.05379
G1 X149.448 Y118.385
G1 X148.21 Y117.147 E.05379
G1 X147.677 Y117.147
G1 X148.915 Y118.385 E.05379
G1 X148.381 Y118.385
G1 X147.143 Y117.147 E.05379
G1 X146.61 Y117.147
G1 X147.848 Y118.385 E.05379
G1 X147.315 Y118.385
G1 X146.077 Y117.147 E.05379
G1 X145.544 Y117.147
G1 X146.781 Y118.385 E.05379
G1 X146.248 Y118.385
G1 X145.01 Y117.147 E.05379
G1 X144.477 Y117.147
G1 X145.715 Y118.385 E.05379
G1 X145.182 Y118.385
G1 X143.944 Y117.147 E.05379
G1 X143.411 Y117.147
G1 X144.648 Y118.385 E.05379
G1 X144.115 Y118.385
G1 X142.877 Y117.147 E.05379
G1 X142.344 Y117.147
G1 X143.582 Y118.385 E.05379
G1 X143.049 Y118.385
G1 X141.811 Y117.147 E.05379
G1 X141.278 Y117.147
G1 X142.515 Y118.385 E.05379
G1 X141.982 Y118.385
G1 X140.744 Y117.147 E.05379
G1 X140.211 Y117.147
G1 X141.449 Y118.385 E.05379
G1 X140.916 Y118.385
G1 X139.678 Y117.147 E.05379
G1 X139.144 Y117.147
G1 X140.382 Y118.385 E.05379
G1 X139.849 Y118.385
G1 X138.611 Y117.147 E.05379
G1 X138.078 Y117.147
G1 X139.316 Y118.385 E.05379
G1 X138.783 Y118.385
G1 X137.545 Y117.147 E.05379
G1 X137.011 Y117.147
G1 X138.249 Y118.385 E.05379
G1 X137.716 Y118.385
G1 X136.478 Y117.147 E.05379
G1 X135.945 Y117.147
G1 X137.183 Y118.385 E.05379
G1 X136.65 Y118.385
G1 X135.412 Y117.147 E.05379
G1 X134.878 Y117.147
G1 X136.116 Y118.385 E.05379
G1 X135.583 Y118.385
G1 X134.345 Y117.147 E.05379
G1 X133.812 Y117.147
G1 X135.05 Y118.385 E.05379
G1 X134.517 Y118.385
G1 X133.279 Y117.147 E.05379
G1 X132.745 Y117.147
G1 X133.983 Y118.385 E.05379
G1 X133.45 Y118.385
G1 X132.212 Y117.147 E.05379
G1 X131.679 Y117.147
G1 X132.917 Y118.385 E.05379
G1 X132.384 Y118.385
G1 X131.146 Y117.147 E.05379
G1 X130.612 Y117.147
G1 X131.85 Y118.385 E.05379
G1 X131.317 Y118.385
G1 X130.079 Y117.147 E.05379
G1 X129.546 Y117.147
G1 X130.784 Y118.385 E.05379
G1 X130.251 Y118.385
G1 X129.013 Y117.147 E.05379
G1 X128.479 Y117.147
G1 X129.717 Y118.385 E.05379
G1 X129.184 Y118.385
G1 X127.946 Y117.147 E.05379
G1 X127.413 Y117.147
G1 X128.651 Y118.385 E.05379
G1 X128.117 Y118.385
G1 X126.88 Y117.147 E.05379
G1 X126.346 Y117.147
G1 X127.584 Y118.385 E.05379
G1 X127.051 Y118.385
G1 X125.813 Y117.147 E.05379
G1 X125.28 Y117.147
G1 X126.518 Y118.385 E.05379
G1 X125.984 Y118.385
G1 X124.747 Y117.147 E.05379
G1 X124.213 Y117.147
G1 X125.451 Y118.385 E.05379
G1 X124.918 Y118.385
G1 X123.68 Y117.147 E.05379
G1 X123.147 Y117.147
G1 X124.385 Y118.385 E.05379
G1 X123.851 Y118.385
G1 X122.614 Y117.147 E.05379
G1 X122.08 Y117.147
G1 X123.318 Y118.385 E.05379
G1 X122.785 Y118.385
G1 X121.547 Y117.147 E.05379
G1 X121.014 Y117.147
G1 X122.252 Y118.385 E.05379
G1 X121.718 Y118.385
G1 X120.48 Y117.147 E.05379
G1 X119.947 Y117.147
G1 X121.185 Y118.385 E.05379
G1 X120.652 Y118.385
G1 X119.414 Y117.147 E.05379
G1 X118.881 Y117.147
G1 X120.119 Y118.385 E.05379
G1 X119.585 Y118.385
G1 X118.347 Y117.147 E.05379
G1 X117.814 Y117.147
G1 X119.052 Y118.385 E.05379
G1 X118.519 Y118.385
G1 X117.281 Y117.147 E.05379
G1 X116.748 Y117.147
G1 X117.986 Y118.385 E.05379
G1 X117.452 Y118.385
G1 X116.214 Y117.147 E.05379
G1 X115.681 Y117.147
G1 X116.919 Y118.385 E.05379
G1 X116.386 Y118.385
G1 X115.148 Y117.147 E.05379
G1 X114.615 Y117.147
G1 X115.853 Y118.385 E.05379
G1 X115.319 Y118.385
G1 X114.081 Y117.147 E.05379
G1 X113.548 Y117.147
G1 X114.786 Y118.385 E.05379
G1 X114.253 Y118.385
G1 X113.015 Y117.147 E.05379
G1 X112.482 Y117.147
G1 X113.72 Y118.385 E.05379
G1 X113.186 Y118.385
G1 X111.948 Y117.147 E.05379
G1 X111.415 Y117.147
G1 X112.653 Y118.385 E.05379
G1 X112.12 Y118.385
G1 X110.882 Y117.147 E.05379
G1 X110.349 Y117.147
G1 X111.586 Y118.385 E.05379
G1 X111.053 Y118.385
G1 X109.815 Y117.147 E.05379
G1 X109.282 Y117.147
G1 X110.52 Y118.385 E.05379
M73 P62 R10
G1 X109.987 Y118.385
G1 X108.749 Y117.147 E.05379
G1 X108.216 Y117.147
G1 X109.453 Y118.385 E.05379
G1 X108.92 Y118.385
G1 X107.682 Y117.147 E.05379
G1 X107.149 Y117.147
G1 X108.387 Y118.385 E.05379
G1 X107.854 Y118.385
G1 X106.616 Y117.147 E.05379
G1 X106.083 Y117.147
G1 X107.32 Y118.385 E.05379
G1 X106.787 Y118.385
G1 X105.549 Y117.147 E.05379
G1 X105.016 Y117.147
G1 X106.254 Y118.385 E.05379
G1 X105.721 Y118.385
G1 X104.483 Y117.147 E.05379
G1 X103.95 Y117.147
G1 X105.187 Y118.385 E.05379
G1 X104.654 Y118.385
G1 X103.416 Y117.147 E.05379
G1 X102.883 Y117.147
G1 X104.121 Y118.385 E.05379
G1 X103.588 Y118.385
G1 X102.35 Y117.147 E.05379
G1 X101.816 Y117.147
G1 X103.054 Y118.385 E.05379
G1 X102.521 Y118.385
G1 X101.283 Y117.147 E.05379
G1 X100.75 Y117.147
G1 X101.988 Y118.385 E.05379
G1 X101.455 Y118.385
G1 X100.217 Y117.147 E.05379
G1 X99.683 Y117.147
G1 X100.921 Y118.385 E.05379
G1 X100.388 Y118.385
G1 X99.15 Y117.147 E.05379
G1 X98.617 Y117.147
G1 X99.855 Y118.385 E.05379
G1 X99.322 Y118.385
G1 X98.084 Y117.147 E.05379
G1 X97.55 Y117.147
G1 X98.788 Y118.385 E.05379
G1 X98.255 Y118.385
G1 X97.017 Y117.147 E.05379
G1 X96.484 Y117.147
G1 X97.722 Y118.385 E.05379
G1 X97.189 Y118.385
G1 X95.951 Y117.147 E.05379
G1 X95.417 Y117.147
G1 X96.655 Y118.385 E.05379
G1 X96.122 Y118.385
G1 X94.884 Y117.147 E.05379
G1 X94.351 Y117.147
G1 X95.589 Y118.385 E.05379
G1 X95.056 Y118.385
G1 X93.818 Y117.147 E.05379
G1 X93.284 Y117.147
G1 X94.522 Y118.385 E.05379
G1 X93.989 Y118.385
G1 X92.751 Y117.147 E.05379
G1 X92.218 Y117.147
G1 X93.456 Y118.385 E.05379
G1 X92.922 Y118.385
G1 X91.685 Y117.147 E.05379
G1 X91.151 Y117.147
G1 X92.389 Y118.385 E.05379
G1 X91.856 Y118.385
G1 X90.618 Y117.147 E.05379
G1 X90.085 Y117.147
G1 X91.323 Y118.385 E.05379
G1 X90.789 Y118.385
G1 X89.552 Y117.147 E.05379
G1 X89.018 Y117.147
G1 X90.256 Y118.385 E.05379
G1 X89.723 Y118.385
G1 X88.485 Y117.147 E.05379
G1 X87.952 Y117.147
G1 X89.19 Y118.385 E.05379
G1 X88.656 Y118.385
G1 X87.419 Y117.147 E.05379
G1 X86.885 Y117.147
G1 X88.123 Y118.385 E.05379
G1 X87.59 Y118.385
G1 X86.352 Y117.147 E.05379
G1 X85.819 Y117.147
G1 X87.057 Y118.385 E.05379
G1 X86.523 Y118.385
G1 X85.285 Y117.147 E.05379
G1 X84.752 Y117.147
G1 X85.99 Y118.385 E.05379
G1 X85.457 Y118.385
G1 X84.219 Y117.147 E.05379
G1 X83.686 Y117.147
G1 X84.924 Y118.385 E.05379
G1 X84.39 Y118.385
G1 X83.152 Y117.147 E.05379
G1 X82.619 Y117.147
G1 X83.857 Y118.385 E.05379
G1 X83.324 Y118.385
G1 X82.086 Y117.147 E.05379
G1 X81.553 Y117.147
G1 X82.791 Y118.385 E.05379
G1 X82.257 Y118.385
G1 X81.019 Y117.147 E.05379
G1 X80.486 Y117.147
G1 X81.724 Y118.385 E.05379
G1 X81.191 Y118.385
G1 X79.953 Y117.147 E.05379
G1 X79.42 Y117.147
G1 X80.658 Y118.385 E.05379
G1 X80.124 Y118.385
G1 X78.886 Y117.147 E.05379
G1 X78.353 Y117.147
G1 X79.591 Y118.385 E.05379
G1 X79.058 Y118.385
G1 X77.82 Y117.147 E.05379
G1 X77.287 Y117.147
G1 X78.525 Y118.385 E.05379
G1 X77.991 Y118.385
G1 X76.753 Y117.147 E.05379
G1 X76.22 Y117.147
G1 X77.458 Y118.385 E.05379
G1 X76.925 Y118.385
G1 X75.687 Y117.147 E.05379
G1 X75.154 Y117.147
G1 X76.391 Y118.385 E.05379
G1 X75.858 Y118.385
G1 X74.62 Y117.147 E.05379
G1 X74.087 Y117.147
G1 X75.325 Y118.385 E.05379
G1 X74.792 Y118.385
G1 X73.554 Y117.147 E.05379
G1 X73.021 Y117.147
G1 X74.258 Y118.385 E.05379
G1 X73.725 Y118.385
G1 X72.487 Y117.147 E.05379
G1 X72.417 Y117.611
G1 X73.192 Y118.385 E.03366
; WIPE_START
M204 S10000
G1 X72.417 Y117.611 E-.41625
G1 X72.487 Y117.147 E-.17806
G1 X72.796 Y117.456 E-.16569
; WIPE_END
G1 E-.04 F1800
G1 X72.952 Y123.978 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y123.978 E.4443
G1 X88.877 Y123.628 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X87.249 Y123.628 E.05401
G1 X85.856 Y122.235 E.06536
G1 X85.709 Y122.235 E.00486
G1 X84.316 Y123.628 E.06536
G1 X79.573 Y123.628 E.15734
G1 X78.18 Y122.235 E.06536
G1 X78.033 Y122.235 E.00486
G1 X76.64 Y123.628 E.06535
G1 X75.012 Y123.628 E.05401
G1 X72.766 Y125.357 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X89.065 Y125.357 E.60098
G1 X89.065 Y124.905 E.01668
G1 X72.935 Y124.905 E.59472
G1 X72.935 Y124.452 E.01668
G1 X89.234 Y124.452 E.60098
G1 X89.006 Y120.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y119 E.04368
G1 X72.994 Y119 E.49198
G1 X72.994 Y121.843 E.08737
G1 X89.006 Y121.843 E.49198
G1 X89.006 Y120.482 E.04184
G1 X88.629 Y120.422 F30000
G1 F12000
G1 X88.629 Y119.377 E.0321
G1 X73.371 Y119.377 E.46881
G1 X73.371 Y121.466 E.0642
G1 X88.629 Y121.466 E.46881
G1 X88.629 Y120.482 E.03025
G1 X88.252 Y120.422 F30000
G1 F12000
G1 X88.252 Y119.754 E.02051
G1 X73.748 Y119.754 E.44564
G1 X73.748 Y121.089 E.04102
G1 X88.252 Y121.089 E.44564
G1 X88.252 Y120.482 E.01867
G1 X87.824 Y120.422 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X87.824 Y120.182 E.00935
G1 X74.176 Y120.182 E.53272
G1 X74.176 Y120.661 E.0187
G1 X87.824 Y120.661 E.53272
G1 X87.824 Y120.482 E.00701
; WIPE_START
G1 X87.824 Y120.661 E-.06822
G1 X86.003 Y120.661 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X89.594 Y118.503 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.22513
G1 F15000
G1 X96.406 Y118.503 E.10114
; WIPE_START
G1 X94.406 Y118.503 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X96.952 Y123.978 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y123.978 E.16725
G1 X103.234 Y124.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y124.452 E.23226
G1 X96.935 Y124.905 E.01668
G1 X103.065 Y124.905 E.22601
G1 X103.065 Y125.357 E.01668
G1 X96.766 Y125.357 E.23226
G1 X103.05 Y122.449 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.05 Y123.628 E.03912
G1 X102.601 Y123.628 E.0149
G1 X100.407 Y121.435 E.10288
G1 X101.861 Y121.435 E.04821
G1 X99.668 Y123.628 E.10288
G1 X98.039 Y123.628 E.05401
G1 X102.212 Y120.25 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.49902
G1 F13812.761
G1 X102.212 Y119.794 E.01695
G1 X97.788 Y119.794 E.16444
G1 X97.788 Y120.25 E.01695
G1 X102.152 Y120.25 E.16221
G1 X102.629 Y120.666 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X102.629 Y119.377 E.03961
G1 X97.371 Y119.377 E.16155
G1 X97.371 Y120.666 E.03961
G1 X102.569 Y120.666 E.1597
G1 X103.006 Y121.043 F30000
G1 F15000
G1 X103.006 Y119 E.06279
G1 X96.994 Y119 E.18472
G1 X96.994 Y121.043 E.06279
G1 X102.946 Y121.043 E.18288
; WIPE_START
G1 X100.946 Y121.043 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.594 Y118.503 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.22513
G1 F15000
G1 X110.406 Y118.503 E.10114
; WIPE_START
G1 X108.406 Y118.503 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X110.952 Y123.978 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y123.978 E.16725
G1 X117.234 Y124.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y124.452 E.23226
G1 X110.935 Y124.905 E.01668
G1 X117.065 Y124.905 E.22601
G1 X117.065 Y125.357 E.01668
G1 X110.766 Y125.357 E.23226
G1 X113.391 Y123.628 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X115.02 Y123.628 E.05401
G1 X117.05 Y121.598 E.09523
G1 X117.05 Y122.726 E.03739
G1 X115.759 Y121.435 E.06053
G1 X114.131 Y121.435 E.05401
G1 X116.212 Y120.25 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.49902
G1 F13812.761
G1 X116.212 Y119.794 E.01695
G1 X111.788 Y119.794 E.16444
G1 X111.788 Y120.25 E.01695
G1 X116.152 Y120.25 E.16221
G1 X116.629 Y120.666 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X116.629 Y119.377 E.03961
G1 X111.371 Y119.377 E.16155
G1 X111.371 Y120.666 E.03961
G1 X116.569 Y120.666 E.1597
G1 X117.006 Y121.043 F30000
G1 F15000
G1 X117.006 Y119 E.06279
G1 X110.994 Y119 E.18472
G1 X110.994 Y121.043 E.06279
G1 X116.946 Y121.043 E.18288
; WIPE_START
G1 X114.946 Y121.043 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X117.594 Y118.503 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.22513
G1 F15000
G1 X124.406 Y118.503 E.10114
; WIPE_START
G1 X122.406 Y118.503 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X125.788 Y120.25 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.49902
G1 F13812.761
G1 X130.212 Y120.25 E.16444
G1 X130.212 Y119.794 E.01695
G1 X125.788 Y119.794 E.16444
G1 X125.788 Y120.19 E.01472
G1 X125.371 Y120.666 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X130.629 Y120.666 E.16155
G1 X130.629 Y119.377 E.03961
G1 X125.371 Y119.377 E.16155
G1 X125.371 Y120.606 E.03777
G1 X124.994 Y121.043 F30000
G1 F15000
G1 X131.006 Y121.043 E.18472
G1 X131.006 Y119 E.06279
G1 X124.994 Y119 E.18472
G1 X124.994 Y120.983 E.06094
G1 X124.952 Y123.978 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y123.978 E.16725
G1 X131.234 Y124.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y124.452 E.23226
G1 X124.935 Y124.905 E.01668
G1 X131.065 Y124.905 E.22601
G1 X131.065 Y125.357 E.01668
G1 X124.766 Y125.357 E.23226
G1 X130.936 Y121.435 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.05 Y121.435 E.00376
G1 X131.05 Y122.95 E.05025
G1 X130.372 Y123.628 E.03181
G1 X125.628 Y123.628 E.15734
G1 X124.95 Y122.95 E.03181
G1 X124.95 Y121.435 E.05025
G1 X125.064 Y121.435 E.00376
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X124.95 Y121.435 E-.04307
G1 X124.95 Y122.95 E-.5757
G1 X125.213 Y123.213 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 16/32
; update layer progress
M73 L16
M991 S0 P15 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.4 I-.288 J1.182 P1  F30000
G1 X183.398 Y137.398 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X72.602 Y137.398 E3.6753
G1 X72.602 Y134.381 E.10007
G1 X72.602 Y133.981 E.01327
G1 F14852.35
G1 X72.602 Y133.921 E.00199
G1 F13500
G1 X183.398 Y133.921 E3.6753
G1 F14852.35
G1 X183.398 Y133.981 E.00199
G1 F15476.087
G1 X183.398 Y134.381 E.01327
G1 X183.398 Y137.338 E.09808
M204 S250
G1 X183.79 Y137.79 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y137.79 E3.42854
G1 X72.21 Y134.768 E.09286
G1 X72.21 Y134.368 E.01229
G1 F6459.938
G1 X72.21 Y133.968 E.01229
G1 F1800
G1 X72.21 Y133.599 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y133.529 E.0023
G1 X183.79 Y133.529 E3.70131
G1 X183.79 Y133.599 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y133.968 E.01134
G1 F6459.938
G1 X183.79 Y134.368 E.01229
G1 F12000
G1 X183.79 Y134.768 E.01229
G1 X183.79 Y137.73 E.09102
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X181.79 Y137.731 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.728 Y135.308 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.1 Y135.308 E.05401
G1 X179.282 Y136.125 E.03835
G1 X176.505 Y136.125 E.09212
G1 X175.688 Y135.308 E.03835
G1 X172.424 Y135.308 E.10827
G1 X171.606 Y136.125 E.03835
G1 X168.829 Y136.125 E.09212
G1 X168.012 Y135.308 E.03835
G1 X164.748 Y135.308 E.10827
G1 X163.93 Y136.125 E.03835
G1 X161.153 Y136.125 E.09212
G1 X160.336 Y135.308 E.03835
G1 X157.072 Y135.308 E.10827
G1 X156.254 Y136.125 E.03835
G1 X153.477 Y136.125 E.09212
G1 X152.66 Y135.308 E.03835
G1 X149.396 Y135.308 E.10827
G1 X148.578 Y136.125 E.03835
G1 X145.801 Y136.125 E.09212
G1 X144.984 Y135.308 E.03835
G1 X141.72 Y135.308 E.10827
G1 X140.902 Y136.125 E.03835
G1 X138.125 Y136.125 E.09212
G1 X137.308 Y135.308 E.03835
G1 X134.044 Y135.308 E.10827
G1 X133.227 Y136.125 E.03835
G1 X130.449 Y136.125 E.09212
G1 X129.632 Y135.308 E.03835
G1 X126.368 Y135.308 E.10827
G1 X125.551 Y136.125 E.03835
G1 X122.773 Y136.125 E.09212
G1 X121.956 Y135.308 E.03835
G1 X118.692 Y135.308 E.10827
G1 X117.875 Y136.125 E.03835
G1 X115.097 Y136.125 E.09212
G1 X114.28 Y135.308 E.03835
G1 X111.016 Y135.308 E.10827
G1 X110.199 Y136.125 E.03835
G1 X107.422 Y136.125 E.09212
G1 X106.604 Y135.308 E.03835
G1 X103.34 Y135.308 E.10827
G1 X102.523 Y136.125 E.03835
G1 X99.746 Y136.125 E.09212
G1 X98.928 Y135.308 E.03835
G1 X95.664 Y135.308 E.10827
G1 X94.847 Y136.125 E.03835
G1 X92.07 Y136.125 E.09212
G1 X91.252 Y135.308 E.03835
G1 X87.988 Y135.308 E.10827
G1 X87.171 Y136.125 E.03835
G1 X84.394 Y136.125 E.09212
G1 X83.576 Y135.308 E.03835
G1 X80.312 Y135.308 E.10827
G1 X79.495 Y136.125 E.03835
G1 X76.718 Y136.125 E.09212
G1 X75.9 Y135.308 E.03835
G1 X74.272 Y135.308 E.05401
G1 X73.05 Y134.37 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53261
G1 F12865.282
G1 X73.05 Y134.859 E.01954
G1 X182.95 Y134.859 E4.38536
G1 X182.95 Y134.37 E.01954
G1 X73.11 Y134.37 E4.38297
G1 X73.022 Y136.978 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.47568
G1 F12000
G1 X182.978 Y136.978 E3.87754
G1 X182.978 Y136.545 E.01526
G1 X73.022 Y136.545 E3.87754
G1 X73.022 Y136.918 E.01315
; WIPE_START
G1 X73.022 Y136.545 E-.14165
G1 X74.649 Y136.545 E-.61835
; WIPE_END
G1 E-.04 F1800
G1 X81.952 Y134.327 Z3.6 F30000
G1 X131.058 Y119.408 Z3.6
M73 P63 R10
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y119.408 E.01127
G1 X131.398 Y124.948 E.18376
G1 X131.398 Y125.348 E.01327
G1 F14331.075
G1 X131.398 Y125.748 E.01327
G1 F6685.538
G1 X131.398 Y126.148 E.01327
G1 F1920
G1 X131.398 Y126.528 E.01262
G1 F600
G1 X124.602 Y126.528 E.22543
G1 F1920
G1 X124.602 Y126.148 E.01262
G1 F6685.538
G1 X124.602 Y125.748 E.01327
G1 F14331.075
G1 X124.602 Y125.348 E.01327
G1 F15476.087
G1 X124.602 Y124.948 E.01327
G1 X124.602 Y119.408 E.18376
G1 X130.998 Y119.408 E.21218
; WIPE_START
G1 X131.398 Y119.408 E-.15186
G1 X131.398 Y121.008 E-.60814
; WIPE_END
G1 E-.04 F1800
G1 X123.815 Y120.142 Z3.6 F30000
G1 X117.385 Y119.408 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G1 X117.398 Y119.408 E.00043
G1 X117.398 Y124.948 E.18376
G1 X117.398 Y125.348 E.01327
G1 F14331.075
G1 X117.398 Y125.748 E.01327
G1 F6685.538
G1 X117.398 Y126.148 E.01327
G1 F1920
G1 X117.398 Y126.528 E.01262
G1 F600
G1 X110.602 Y126.528 E.22543
G1 F1920
G1 X110.602 Y126.148 E.01262
G1 F6685.538
G1 X110.602 Y125.748 E.01327
G1 F14331.075
G1 X110.602 Y125.348 E.01327
G1 F15476.087
G1 X110.602 Y124.948 E.01327
G1 X110.602 Y119.408 E.18376
G1 X117.325 Y119.408 E.22301
; WIPE_START
G1 X117.398 Y119.408 E-.02778
G1 X117.398 Y121.335 E-.73222
; WIPE_END
G1 E-.04 F1800
G1 X109.837 Y120.294 Z3.6 F30000
G1 X103.392 Y119.408 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G1 X103.398 Y119.408 E.00021
G1 X103.398 Y124.948 E.18376
G1 X103.398 Y125.348 E.01327
G1 F14331.075
G1 X103.398 Y125.748 E.01327
G1 F6685.538
G1 X103.398 Y126.148 E.01327
G1 F1920
G1 X103.398 Y126.528 E.01262
G1 F600
G1 X96.602 Y126.528 E.22543
G1 F1920
G1 X96.602 Y126.148 E.01262
G1 F6685.538
G1 X96.602 Y125.748 E.01327
G1 F14331.075
G1 X96.602 Y125.348 E.01327
G1 F15476.087
G1 X96.602 Y124.948 E.01327
G1 X96.602 Y119.408 E.18376
G1 X103.332 Y119.408 E.22323
; WIPE_START
G1 X103.398 Y119.408 E-.02524
G1 X103.398 Y121.341 E-.73476
; WIPE_END
G1 E-.04 F1800
G1 X95.837 Y120.297 Z3.6 F30000
G1 X89.394 Y119.408 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G1 X89.398 Y119.408 E.00014
G1 X89.398 Y124.948 E.18376
G1 X89.398 Y125.348 E.01327
G1 F14331.075
G1 X89.398 Y125.748 E.01327
G1 F6685.538
G1 X89.398 Y126.148 E.01327
G1 F1920
G1 X89.398 Y126.528 E.01262
G1 F600
G1 X72.602 Y126.528 E.55715
G1 F1920
G1 X72.602 Y126.148 E.01262
G1 F6685.538
G1 X72.602 Y125.748 E.01327
G1 F14331.075
G1 X72.602 Y125.348 E.01327
G1 F15476.087
G1 X72.602 Y124.948 E.01327
G1 X72.602 Y119.408 E.18376
G1 X89.334 Y119.408 E.55502
; WIPE_START
G1 X89.398 Y119.408 E-.02435
G1 X89.398 Y121.344 E-.73565
; WIPE_END
G1 E-.04 F1800
G1 X97.024 Y121.044 Z3.6 F30000
G1 X138.602 Y119.408 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G1 X145.398 Y119.408 E.22543
G1 X145.398 Y124.948 E.18376
G1 X145.398 Y125.348 E.01327
G1 F14331.075
G1 X145.398 Y125.748 E.01327
G1 F6685.538
G1 X145.398 Y126.148 E.01327
G1 F1920
G1 X145.398 Y126.528 E.01262
G1 F600
G1 X138.602 Y126.528 E.22543
G1 F1920
G1 X138.602 Y126.148 E.01262
G1 F6685.538
G1 X138.602 Y125.748 E.01327
G1 F14331.075
G1 X138.602 Y125.348 E.01327
G1 F15476.087
G1 X138.602 Y124.948 E.01327
G1 X138.602 Y119.468 E.18177
; WIPE_START
G1 X140.602 Y119.45 E-.76
; WIPE_END
M73 P64 R10
G1 E-.04 F1800
G1 X148.234 Y119.423 Z3.6 F30000
G1 X152.602 Y119.408 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G1 X159.398 Y119.408 E.22543
G1 X159.398 Y124.948 E.18376
G1 X159.398 Y125.348 E.01327
G1 F14331.075
G1 X159.398 Y125.748 E.01327
G1 F6685.538
G1 X159.398 Y126.148 E.01327
G1 F1920
G1 X159.398 Y126.528 E.01262
G1 F600
G1 X152.602 Y126.528 E.22543
G1 F1920
G1 X152.602 Y126.148 E.01262
G1 F6685.538
G1 X152.602 Y125.748 E.01327
G1 F14331.075
G1 X152.602 Y125.348 E.01327
G1 F15476.087
G1 X152.602 Y124.948 E.01327
G1 X152.602 Y119.468 E.18177
; WIPE_START
G1 X154.602 Y119.45 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X162.234 Y119.423 Z3.6 F30000
G1 X166.602 Y119.408 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F15476.087
G1 X183.398 Y119.408 E.55715
G1 X183.398 Y124.948 E.18376
G1 X183.398 Y125.348 E.01327
G1 F14331.075
G1 X183.398 Y125.748 E.01327
G1 F6685.538
G1 X183.398 Y126.148 E.01327
G1 F1920
G1 X183.398 Y126.528 E.01262
G1 F600
G1 X166.602 Y126.528 E.55715
G1 F1920
G1 X166.602 Y126.148 E.01262
G1 F6685.538
G1 X166.602 Y125.748 E.01327
G1 F14331.075
G1 X166.602 Y125.348 E.01327
G1 F15476.087
G1 X166.602 Y124.948 E.01327
G1 X166.602 Y119.468 E.18177
; WIPE_START
G1 X168.602 Y119.461 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X160.971 Y119.322 Z3.6 F30000
G1 X131.79 Y118.79 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y125.361 E.20191
G1 X131.79 Y125.761 E.01229
G1 F6459.938
G1 X131.79 Y126.161 E.01229
G1 F1800
G1 X131.79 Y126.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y126.92 E.01294
G1 X124.21 Y126.92 E.25144
G1 X124.21 Y126.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y126.161 E.01134
G1 F6459.938
G1 X124.21 Y125.761 E.01229
G1 F12000
G1 X124.21 Y125.361 E.01229
G1 X124.21 Y118.79 E.20191
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y125.361 E.20191
G1 X117.79 Y125.761 E.01229
G1 F6459.938
G1 X117.79 Y126.161 E.01229
G1 F1800
G1 X117.79 Y126.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y126.92 E.01294
G1 X110.21 Y126.92 E.25144
G1 X110.21 Y126.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y126.161 E.01134
G1 F6459.938
G1 X110.21 Y125.761 E.01229
G1 F12000
G1 X110.21 Y125.361 E.01229
G1 X110.21 Y118.79 E.20191
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y125.361 E.20191
G1 X103.79 Y125.761 E.01229
G1 F6459.938
G1 X103.79 Y126.161 E.01229
G1 F1800
G1 X103.79 Y126.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y126.92 E.01294
G1 X96.21 Y126.92 E.25144
G1 X96.21 Y126.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y126.161 E.01134
G1 F6459.938
G1 X96.21 Y125.761 E.01229
G1 F12000
G1 X96.21 Y125.361 E.01229
G1 X96.21 Y118.79 E.20191
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y125.361 E.20191
G1 X89.79 Y125.761 E.01229
G1 F6459.938
G1 X89.79 Y126.161 E.01229
G1 F1800
G1 X89.79 Y126.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y126.92 E.01294
G1 X72.21 Y126.92 E.58316
G1 X72.21 Y126.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y126.161 E.01134
G1 F6459.938
G1 X72.21 Y125.761 E.01229
G1 F12000
G1 X72.21 Y125.361 E.01229
G1 X72.21 Y117.74 E.23417
G1 X183.79 Y117.74 E3.42854
G1 X183.79 Y125.361 E.23417
G1 X183.79 Y125.761 E.01229
G1 F6459.938
G1 X183.79 Y126.161 E.01229
G1 F1800
G1 X183.79 Y126.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y126.92 E.01294
G1 F600
G1 X166.21 Y126.92 E.58316
G1 X166.21 Y126.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y126.161 E.01134
G1 F6459.938
G1 X166.21 Y125.761 E.01229
G1 F12000
G1 X166.21 Y125.361 E.01229
G1 X166.21 Y118.79 E.20191
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y125.361 E.20191
G1 X159.79 Y125.761 E.01229
G1 F6459.938
G1 X159.79 Y126.161 E.01229
G1 F1800
G1 X159.79 Y126.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y126.92 E.01294
G1 X152.21 Y126.92 E.25144
G1 X152.21 Y126.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y126.161 E.01134
G1 F6459.938
G1 X152.21 Y125.761 E.01229
G1 F12000
G1 X152.21 Y125.361 E.01229
G1 X152.21 Y118.79 E.20191
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y125.361 E.20191
G1 X145.79 Y125.761 E.01229
G1 F6459.938
G1 X145.79 Y126.161 E.01229
G1 F1800
G1 X145.79 Y126.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y126.92 E.01294
G1 X138.21 Y126.92 E.25144
G1 X138.21 Y126.53 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y126.161 E.01134
G1 F6459.938
G1 X138.21 Y125.761 E.01229
G1 F12000
G1 X138.21 Y125.361 E.01229
G1 X138.21 Y118.79 E.20191
G1 X131.85 Y118.79 E.19542
; WIPE_START
M204 S10000
G1 X131.832 Y120.79 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.006 Y120.822 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y119.8 E.03139
G1 X124.994 Y119.8 E.18472
G1 X124.994 Y121.843 E.06279
G1 X131.006 Y121.843 E.18472
G1 X131.006 Y120.882 E.02955
G1 X130.629 Y120.822 F30000
G1 F12000
G1 X130.629 Y120.177 E.01981
G1 X125.371 Y120.177 E.16155
G1 X125.371 Y121.466 E.03961
G1 X130.629 Y121.466 E.16155
G1 X130.629 Y120.882 E.01796
G1 X130.212 Y120.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X130.212 Y120.594 E.00848
G1 X125.788 Y120.594 E.16444
G1 X125.788 Y121.05 E.01695
G1 X130.212 Y121.05 E.16444
G1 X130.212 Y120.882 E.00625
G1 X131.234 Y125.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y125.252 E.23226
G1 X124.935 Y125.705 E.01668
G1 X131.065 Y125.705 E.22601
G1 X131.065 Y126.157 E.01668
G1 X124.766 Y126.157 E.23226
G1 X124.952 Y124.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
M73 P64 R9
G1 F15000
G1 X130.988 Y124.778 E.16725
G1 X125.864 Y122.235 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.95 Y122.235 E.0303
G1 X124.95 Y122.95 E.02372
G1 X126.428 Y124.428 E.06934
G1 X129.572 Y124.428 E.10426
G1 X131.05 Y122.95 E.06934
G1 X131.05 Y122.235 E.02372
G1 X130.136 Y122.235 E.0303
; WIPE_START
G1 X131.05 Y122.235 E-.34707
G1 X131.05 Y122.95 E-.27169
G1 X130.787 Y123.213 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X138.283 Y124.65 Z3.6 F30000
G1 X138.952 Y124.778 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y124.778 E.16725
G1 X145.234 Y125.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y125.252 E.23226
G1 X138.935 Y125.705 E.01668
G1 X145.065 Y125.705 E.22601
G1 X145.065 Y126.157 E.01668
G1 X138.766 Y126.157 E.23226
G1 X143.409 Y124.428 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X141.78 Y124.428 E.05401
G1 X139.587 Y122.235 E.10288
G1 X139.441 Y122.235 E.00486
G1 X138.95 Y122.726 E.023
G1 X138.95 Y124.354 E.05401
G1 X145.006 Y120.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y119.8 E.03139
M73 P65 R9
G1 X138.994 Y119.8 E.18472
G1 X138.994 Y121.843 E.06279
G1 X145.006 Y121.843 E.18472
G1 X145.006 Y120.882 E.02955
G1 X144.629 Y120.822 F30000
G1 F12000
G1 X144.629 Y120.177 E.01981
G1 X139.371 Y120.177 E.16155
G1 X139.371 Y121.466 E.03961
G1 X144.629 Y121.466 E.16155
G1 X144.629 Y120.882 E.01796
G1 X144.212 Y120.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X144.212 Y120.594 E.00848
G1 X139.788 Y120.594 E.16444
G1 X139.788 Y121.05 E.01695
G1 X144.212 Y121.05 E.16444
G1 X144.212 Y120.882 E.00625
; WIPE_START
G1 X144.212 Y121.05 E-.06386
G1 X142.38 Y121.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X149.578 Y123.588 Z3.6 F30000
G1 X152.952 Y124.778 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y124.778 E.16725
G1 X158.761 Y124.428 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X157.132 Y124.428 E.05401
G1 X154.939 Y122.235 E.10288
G1 X154.793 Y122.235 E.00486
G1 X152.95 Y124.078 E.08642
G1 X152.95 Y124.428 E.01164
G1 X154.228 Y124.428 E.04237
G1 X152.766 Y126.157 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X159.065 Y126.157 E.23226
G1 X159.065 Y125.705 E.01668
G1 X152.935 Y125.705 E.22601
G1 X152.935 Y125.252 E.01668
G1 X159.234 Y125.252 E.23226
G1 X159.006 Y120.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y119.8 E.03139
G1 X152.994 Y119.8 E.18472
G1 X152.994 Y121.843 E.06279
G1 X159.006 Y121.843 E.18472
G1 X159.006 Y120.882 E.02955
G1 X158.629 Y120.822 F30000
G1 F12000
G1 X158.629 Y120.177 E.01981
G1 X153.371 Y120.177 E.16155
G1 X153.371 Y121.466 E.03961
G1 X158.629 Y121.466 E.16155
G1 X158.629 Y120.882 E.01796
G1 X158.212 Y120.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X158.212 Y120.594 E.00848
G1 X153.788 Y120.594 E.16444
G1 X153.788 Y121.05 E.01695
G1 X158.212 Y121.05 E.16444
G1 X158.212 Y120.882 E.00625
; WIPE_START
G1 X158.212 Y121.05 E-.06386
G1 X156.38 Y121.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X163.767 Y122.972 Z3.6 F30000
G1 X166.95 Y123.801 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X166.95 Y124.428 E.02081
G1 X167.951 Y124.428 E.0332
G1 X169.344 Y123.035 E.06536
G1 X171.091 Y123.035 E.05794
G1 X172.484 Y124.428 E.06536
G1 X175.627 Y124.428 E.10426
G1 X177.02 Y123.035 E.06536
G1 X178.767 Y123.035 E.05794
G1 X180.16 Y124.428 E.06536
G1 X181.788 Y124.428 E.05401
G1 X183.234 Y125.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y125.252 E.60098
G1 X166.935 Y125.705 E.01668
G1 X183.065 Y125.705 E.59472
G1 X183.065 Y126.157 E.01668
G1 X166.766 Y126.157 E.60098
G1 X166.952 Y124.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y124.778 E.4443
G1 X183.006 Y121.222 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y119.8 E.04368
G1 X166.994 Y119.8 E.49198
G1 X166.994 Y122.643 E.08737
G1 X183.006 Y122.643 E.49198
G1 X183.006 Y121.282 E.04184
G1 X182.629 Y121.222 F30000
G1 F12000
G1 X182.629 Y120.177 E.0321
G1 X167.371 Y120.177 E.46881
G1 X167.371 Y122.266 E.0642
G1 X182.629 Y122.266 E.46881
G1 X182.629 Y121.282 E.03025
G1 X182.252 Y121.222 F30000
G1 F12000
G1 X182.252 Y120.554 E.02051
G1 X167.748 Y120.554 E.44564
G1 X167.748 Y121.889 E.04102
G1 X182.252 Y121.889 E.44564
G1 X182.252 Y121.282 E.01867
G1 X181.824 Y121.222 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y120.982 E.00935
G1 X168.176 Y120.982 E.53272
G1 X168.176 Y121.461 E.0187
G1 X181.824 Y121.461 E.53272
G1 X181.824 Y121.282 E.00701
; WIPE_START
G1 X181.824 Y121.461 E-.06822
G1 X180.003 Y121.461 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X183.074 Y119.185 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.583 Y118.677 E.02208
G1 X183.583 Y118.144
G1 X182.541 Y119.185 E.04526
G1 X182.008 Y119.185
G1 X183.246 Y117.947 E.05379
G1 X182.713 Y117.947
G1 X181.475 Y119.185 E.05379
G1 X180.941 Y119.185
G1 X182.179 Y117.947 E.05379
G1 X181.646 Y117.947
G1 X180.408 Y119.185 E.05379
G1 X179.875 Y119.185
G1 X181.113 Y117.947 E.05379
G1 X180.58 Y117.947
G1 X179.342 Y119.185 E.05379
G1 X178.808 Y119.185
G1 X180.046 Y117.947 E.05379
G1 X179.513 Y117.947
G1 X178.275 Y119.185 E.05379
G1 X177.742 Y119.185
G1 X178.98 Y117.947 E.05379
G1 X178.447 Y117.947
G1 X177.209 Y119.185 E.05379
G1 X176.675 Y119.185
G1 X177.913 Y117.947 E.05379
G1 X177.38 Y117.947
G1 X176.142 Y119.185 E.05379
G1 X175.609 Y119.185
G1 X176.847 Y117.947 E.05379
G1 X176.313 Y117.947
G1 X175.076 Y119.185 E.05379
G1 X174.542 Y119.185
G1 X175.78 Y117.947 E.05379
G1 X175.247 Y117.947
G1 X174.009 Y119.185 E.05379
G1 X173.476 Y119.185
G1 X174.714 Y117.947 E.05379
G1 X174.18 Y117.947
G1 X172.943 Y119.185 E.05379
G1 X172.409 Y119.185
G1 X173.647 Y117.947 E.05379
G1 X173.114 Y117.947
G1 X171.876 Y119.185 E.05379
G1 X171.343 Y119.185
G1 X172.581 Y117.947 E.05379
G1 X172.047 Y117.947
G1 X170.81 Y119.185 E.05379
G1 X170.276 Y119.185
G1 X171.514 Y117.947 E.05379
G1 X170.981 Y117.947
G1 X169.743 Y119.185 E.05379
G1 X169.21 Y119.185
G1 X170.448 Y117.947 E.05379
G1 X169.914 Y117.947
G1 X168.676 Y119.185 E.05379
G1 X168.143 Y119.185
G1 X169.381 Y117.947 E.05379
G1 X168.848 Y117.947
G1 X167.61 Y119.185 E.05379
G1 X167.077 Y119.185
G1 X168.315 Y117.947 E.05379
G1 X167.781 Y117.947
G1 X166.543 Y119.185 E.05379
G1 X166.417 Y118.778
G1 X167.248 Y117.947 E.0361
G1 X166.715 Y117.947
G1 X166.08 Y118.583 E.0276
G1 X165.546 Y118.583
G1 X166.182 Y117.947 E.0276
G1 X165.648 Y117.947
G1 X165.013 Y118.583 E.0276
G1 X164.48 Y118.583
G1 X165.115 Y117.947 E.0276
G1 X164.582 Y117.947
G1 X163.947 Y118.583 E.0276
G1 X163.413 Y118.583
G1 X164.049 Y117.947 E.0276
G1 X163.515 Y117.947
G1 X162.88 Y118.583 E.0276
G1 X162.347 Y118.583
G1 X162.982 Y117.947 E.0276
G1 X162.449 Y117.947
G1 X161.814 Y118.583 E.0276
G1 X161.28 Y118.583
G1 X161.916 Y117.947 E.0276
G1 X161.382 Y117.947
G1 X160.747 Y118.583 E.0276
G1 X160.214 Y118.583
G1 X160.849 Y117.947 E.0276
G1 X160.316 Y117.947
G1 X159.681 Y118.583 E.0276
G1 X159.583 Y118.681
G1 X159.078 Y119.185 E.02194
G1 X158.545 Y119.185
G1 X159.782 Y117.947 E.05379
G1 X159.249 Y117.947
G1 X158.011 Y119.185 E.05379
G1 X157.478 Y119.185
G1 X158.716 Y117.947 E.05379
G1 X158.183 Y117.947
G1 X156.945 Y119.185 E.05379
G1 X156.412 Y119.185
G1 X157.649 Y117.947 E.05379
G1 X157.116 Y117.947
G1 X155.878 Y119.185 E.05379
G1 X155.345 Y119.185
G1 X156.583 Y117.947 E.05379
G1 X156.05 Y117.947
G1 X154.812 Y119.185 E.05379
G1 X154.279 Y119.185
G1 X155.516 Y117.947 E.05379
G1 X154.983 Y117.947
G1 X153.745 Y119.185 E.05379
G1 X153.212 Y119.185
G1 X154.45 Y117.947 E.05379
G1 X153.917 Y117.947
G1 X152.679 Y119.185 E.05379
G1 X152.417 Y118.913
G1 X153.383 Y117.947 E.04198
G1 X152.85 Y117.947
G1 X152.215 Y118.583 E.0276
G1 X151.682 Y118.583
G1 X152.317 Y117.947 E.0276
G1 X151.784 Y117.947
G1 X151.148 Y118.583 E.0276
G1 X150.615 Y118.583
G1 X151.25 Y117.947 E.0276
G1 X150.717 Y117.947
G1 X150.082 Y118.583 E.0276
G1 X149.549 Y118.583
G1 X150.184 Y117.947 E.0276
G1 X149.651 Y117.947
G1 X149.015 Y118.583 E.0276
G1 X148.482 Y118.583
G1 X149.117 Y117.947 E.0276
G1 X148.584 Y117.947
G1 X147.949 Y118.583 E.0276
G1 X147.416 Y118.583
G1 X148.051 Y117.947 E.0276
G1 X147.518 Y117.947
G1 X146.882 Y118.583 E.0276
G1 X146.349 Y118.583
G1 X146.984 Y117.947 E.0276
G1 X146.451 Y117.947
G1 X145.816 Y118.583 E.0276
G1 X145.583 Y118.816
G1 X145.213 Y119.185 E.01606
G1 X144.68 Y119.185
G1 X145.918 Y117.947 E.05379
G1 X145.385 Y117.947
G1 X144.147 Y119.185 E.05379
G1 X143.613 Y119.185
G1 X144.851 Y117.947 E.05379
G1 X144.318 Y117.947
G1 X143.08 Y119.185 E.05379
G1 X142.547 Y119.185
G1 X143.785 Y117.947 E.05379
G1 X143.251 Y117.947
G1 X142.014 Y119.185 E.05379
G1 X141.48 Y119.185
G1 X142.718 Y117.947 E.05379
G1 X142.185 Y117.947
G1 X140.947 Y119.185 E.05379
G1 X140.414 Y119.185
G1 X141.652 Y117.947 E.05379
G1 X141.118 Y117.947
G1 X139.881 Y119.185 E.05379
G1 X139.347 Y119.185
G1 X140.585 Y117.947 E.05379
G1 X140.052 Y117.947
G1 X138.814 Y119.185 E.05379
G1 X138.417 Y119.049
G1 X139.519 Y117.947 E.04786
G1 X138.985 Y117.947
G1 X138.35 Y118.583 E.0276
G1 X137.817 Y118.583
G1 X138.452 Y117.947 E.0276
G1 X137.919 Y117.947
G1 X137.284 Y118.583 E.0276
G1 X136.75 Y118.583
G1 X137.386 Y117.947 E.0276
G1 X136.852 Y117.947
G1 X136.217 Y118.583 E.0276
G1 X135.684 Y118.583
G1 X136.319 Y117.947 E.0276
G1 X135.786 Y117.947
G1 X135.151 Y118.583 E.0276
G1 X134.617 Y118.583
G1 X135.253 Y117.947 E.0276
G1 X134.719 Y117.947
G1 X134.084 Y118.583 E.0276
G1 X133.551 Y118.583
G1 X134.186 Y117.947 E.0276
G1 X133.653 Y117.947
G1 X133.018 Y118.583 E.0276
G1 X132.484 Y118.583
G1 X133.12 Y117.947 E.0276
G1 X132.586 Y117.947
G1 X131.951 Y118.583 E.0276
M204 S10000
G1 X130.815 Y119.185 F30000
G1 F12000
M204 S2000
G1 X132.053 Y117.947 E.05379
G1 X131.52 Y117.947
G1 X130.282 Y119.185 E.05379
G1 X129.749 Y119.185
G1 X130.987 Y117.947 E.05379
G1 X130.453 Y117.947
G1 X129.215 Y119.185 E.05379
G1 X128.682 Y119.185
G1 X129.92 Y117.947 E.05379
G1 X129.387 Y117.947
G1 X128.149 Y119.185 E.05379
G1 X127.616 Y119.185
G1 X128.854 Y117.947 E.05379
G1 X128.32 Y117.947
G1 X127.082 Y119.185 E.05379
G1 X126.549 Y119.185
G1 X127.787 Y117.947 E.05379
G1 X127.254 Y117.947
G1 X126.016 Y119.185 E.05379
G1 X125.483 Y119.185
G1 X126.721 Y117.947 E.05379
G1 X126.187 Y117.947
G1 X124.949 Y119.185 E.05379
G1 X124.417 Y119.184
G1 X125.654 Y117.947 E.05374
G1 X125.121 Y117.947
G1 X124.417 Y118.651 E.03056
G1 X123.952 Y118.583
G1 X124.587 Y117.947 E.0276
G1 X124.054 Y117.947
G1 X123.419 Y118.583 E.0276
G1 X122.886 Y118.583
G1 X123.521 Y117.947 E.0276
G1 X122.988 Y117.947
G1 X122.353 Y118.583 E.0276
G1 X121.819 Y118.583
G1 X122.454 Y117.947 E.0276
G1 X121.921 Y117.947
G1 X121.286 Y118.583 E.0276
G1 X120.753 Y118.583
G1 X121.388 Y117.947 E.0276
G1 X120.855 Y117.947
G1 X120.219 Y118.583 E.0276
G1 X119.686 Y118.583
G1 X120.321 Y117.947 E.0276
G1 X119.788 Y117.947
G1 X119.153 Y118.583 E.0276
G1 X118.62 Y118.583
G1 X119.255 Y117.947 E.0276
G1 X118.722 Y117.947
G1 X118.086 Y118.583 E.0276
M204 S10000
G1 X116.95 Y119.185 F30000
G1 F12000
M204 S2000
G1 X118.188 Y117.947 E.05379
G1 X117.655 Y117.947
G1 X116.417 Y119.185 E.05379
G1 X115.884 Y119.185
G1 X117.122 Y117.947 E.05379
G1 X116.589 Y117.947
G1 X115.351 Y119.185 E.05379
G1 X114.817 Y119.185
G1 X116.055 Y117.947 E.05379
G1 X115.522 Y117.947
G1 X114.284 Y119.185 E.05379
G1 X113.751 Y119.185
G1 X114.989 Y117.947 E.05379
G1 X114.456 Y117.947
G1 X113.218 Y119.185 E.05379
G1 X112.684 Y119.185
G1 X113.922 Y117.947 E.05379
G1 X113.389 Y117.947
G1 X112.151 Y119.185 E.05379
G1 X111.618 Y119.185
G1 X112.856 Y117.947 E.05379
G1 X112.323 Y117.947
G1 X111.085 Y119.185 E.05379
G1 X110.551 Y119.185
G1 X111.789 Y117.947 E.05379
G1 X111.256 Y117.947
G1 X110.417 Y118.786 E.03644
G1 X110.088 Y118.583
G1 X110.723 Y117.947 E.0276
G1 X110.19 Y117.947
G1 X109.554 Y118.583 E.0276
G1 X109.021 Y118.583
G1 X109.656 Y117.947 E.0276
G1 X109.123 Y117.947
G1 X108.488 Y118.583 E.0276
G1 X107.955 Y118.583
G1 X108.59 Y117.947 E.0276
G1 X108.056 Y117.947
G1 X107.421 Y118.583 E.0276
G1 X106.888 Y118.583
G1 X107.523 Y117.947 E.0276
G1 X106.99 Y117.947
G1 X106.355 Y118.583 E.0276
G1 X105.822 Y118.583
G1 X106.457 Y117.947 E.0276
G1 X105.923 Y117.947
G1 X105.288 Y118.583 E.0276
G1 X104.755 Y118.583
G1 X105.39 Y117.947 E.0276
G1 X104.857 Y117.947
G1 X104.222 Y118.583 E.0276
G1 X103.688 Y118.583
G1 X104.324 Y117.947 E.0276
G1 X103.583 Y118.688
G1 X103.086 Y119.185 E.02159
G1 X102.553 Y119.185
G1 X103.79 Y117.947 E.05379
G1 X103.257 Y117.947
G1 X102.019 Y119.185 E.05379
G1 X101.486 Y119.185
G1 X102.724 Y117.947 E.05379
G1 X102.191 Y117.947
G1 X100.953 Y119.185 E.05379
G1 X100.42 Y119.185
G1 X101.657 Y117.947 E.05379
G1 X101.124 Y117.947
G1 X99.886 Y119.185 E.05379
G1 X99.353 Y119.185
G1 X100.591 Y117.947 E.05379
G1 X100.058 Y117.947
G1 X98.82 Y119.185 E.05379
G1 X98.286 Y119.185
G1 X99.524 Y117.947 E.05379
G1 X98.991 Y117.947
G1 X97.753 Y119.185 E.05379
G1 X97.22 Y119.185
G1 X98.458 Y117.947 E.05379
G1 X97.925 Y117.947
G1 X96.687 Y119.185 E.05379
G1 X96.417 Y118.921
G1 X97.391 Y117.947 E.04232
G1 X96.858 Y117.947
G1 X96.223 Y118.583 E.0276
G1 X95.69 Y118.583
G1 X96.325 Y117.947 E.0276
G1 X95.792 Y117.947
G1 X95.156 Y118.583 E.0276
G1 X94.623 Y118.583
G1 X95.258 Y117.947 E.0276
G1 X94.725 Y117.947
G1 X94.09 Y118.583 E.0276
G1 X93.557 Y118.583
G1 X94.192 Y117.947 E.0276
G1 X93.659 Y117.947
G1 X93.023 Y118.583 E.0276
G1 X92.49 Y118.583
G1 X93.125 Y117.947 E.0276
G1 X92.592 Y117.947
G1 X91.957 Y118.583 E.0276
G1 X91.424 Y118.583
G1 X92.059 Y117.947 E.0276
G1 X91.526 Y117.947
G1 X90.89 Y118.583 E.0276
G1 X90.357 Y118.583
G1 X90.992 Y117.947 E.0276
G1 X90.459 Y117.947
G1 X89.824 Y118.583 E.0276
G1 X89.583 Y118.824
G1 X89.221 Y119.185 E.01571
G1 X88.688 Y119.185
G1 X89.926 Y117.947 E.05379
G1 X89.392 Y117.947
G1 X88.155 Y119.185 E.05379
G1 X87.621 Y119.185
G1 X88.859 Y117.947 E.05379
G1 X88.326 Y117.947
G1 X87.088 Y119.185 E.05379
G1 X86.555 Y119.185
G1 X87.793 Y117.947 E.05379
G1 X87.259 Y117.947
G1 X86.022 Y119.185 E.05379
G1 X85.488 Y119.185
G1 X86.726 Y117.947 E.05379
G1 X86.193 Y117.947
G1 X84.955 Y119.185 E.05379
G1 X84.422 Y119.185
G1 X85.66 Y117.947 E.05379
G1 X85.126 Y117.947
G1 X83.889 Y119.185 E.05379
G1 X83.355 Y119.185
M73 P66 R9
G1 X84.593 Y117.947 E.05379
G1 X84.06 Y117.947
G1 X82.822 Y119.185 E.05379
G1 X82.289 Y119.185
G1 X83.527 Y117.947 E.05379
G1 X82.993 Y117.947
G1 X81.755 Y119.185 E.05379
G1 X81.222 Y119.185
G1 X82.46 Y117.947 E.05379
G1 X81.927 Y117.947
G1 X80.689 Y119.185 E.05379
G1 X80.156 Y119.185
G1 X81.394 Y117.947 E.05379
G1 X80.86 Y117.947
G1 X79.622 Y119.185 E.05379
G1 X79.089 Y119.185
G1 X80.327 Y117.947 E.05379
G1 X79.794 Y117.947
G1 X78.556 Y119.185 E.05379
G1 X78.023 Y119.185
G1 X79.261 Y117.947 E.05379
G1 X78.727 Y117.947
G1 X77.489 Y119.185 E.05379
G1 X76.956 Y119.185
G1 X78.194 Y117.947 E.05379
G1 X77.661 Y117.947
G1 X76.423 Y119.185 E.05379
G1 X75.89 Y119.185
G1 X77.128 Y117.947 E.05379
G1 X76.594 Y117.947
G1 X75.356 Y119.185 E.05379
G1 X74.823 Y119.185
G1 X76.061 Y117.947 E.05379
G1 X75.528 Y117.947
G1 X74.29 Y119.185 E.05379
G1 X73.757 Y119.185
G1 X74.995 Y117.947 E.05379
G1 X74.461 Y117.947
G1 X73.223 Y119.185 E.05379
G1 X72.69 Y119.185
G1 X73.928 Y117.947 E.05379
G1 X73.395 Y117.947
G1 X72.417 Y118.925 E.04247
G1 X72.417 Y118.392
G1 X72.861 Y117.947 E.0193
; WIPE_START
M204 S10000
G1 X72.417 Y118.392 E-.23866
G1 X72.417 Y118.925 E-.20264
G1 X73.01 Y118.332 E-.3187
; WIPE_END
G1 E-.04 F1800
G1 X80.643 Y118.307 Z3.6 F30000
G1 X183.601 Y117.977 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.144381
G1 F15000
G2 X183.316 Y118.018 I-.093 J.365 E.00245
; WIPE_START
G1 X183.415 Y117.977 E-.27809
G1 X183.601 Y117.977 E-.48191
; WIPE_END
G1 E-.04 F1800
G1 X175.982 Y118.419 Z3.6 F30000
G1 X117.006 Y121.843 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y119.8 E.06279
G1 X110.994 Y119.8 E.18472
G1 X110.994 Y121.843 E.06279
G1 X116.946 Y121.843 E.18288
G1 X116.629 Y120.822 F30000
G1 F12000
G1 X116.629 Y120.177 E.01981
G1 X111.371 Y120.177 E.16155
G1 X111.371 Y121.466 E.03961
G1 X116.629 Y121.466 E.16155
G1 X116.629 Y120.882 E.01796
G1 X116.212 Y120.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X116.212 Y120.594 E.00848
G1 X111.788 Y120.594 E.16444
G1 X111.788 Y121.05 E.01695
G1 X116.212 Y121.05 E.16444
G1 X116.212 Y120.882 E.00625
G1 X117.05 Y124.354 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X117.05 Y122.726 E.05401
G1 X116.559 Y122.235 E.023
G1 X116.413 Y122.235 E.00486
G1 X114.22 Y124.428 E.10288
G1 X112.591 Y124.428 E.05401
G1 X110.952 Y124.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y124.778 E.16725
G1 X117.234 Y125.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y125.252 E.23226
G1 X110.935 Y125.705 E.01668
G1 X117.065 Y125.705 E.22601
G1 X117.065 Y126.157 E.01668
G1 X110.766 Y126.157 E.23226
; WIPE_START
G1 X112.766 Y126.157 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.6 I.115 J-1.212 P1  F30000
G1 X103.234 Y125.252 Z3.6
G1 Z3.2
G1 E.8 F1800
G1 F3000
G1 X96.935 Y125.252 E.23226
G1 X96.935 Y125.705 E.01668
G1 X103.065 Y125.705 E.22601
G1 X103.065 Y126.157 E.01668
G1 X96.766 Y126.157 E.23226
G1 X96.952 Y124.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y124.778 E.16725
G1 X101.772 Y124.428 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.05 Y124.428 E.04237
G1 X103.05 Y124.078 E.01164
G1 X101.207 Y122.235 E.08642
G1 X101.061 Y122.235 E.00486
G1 X98.868 Y124.428 E.10288
G1 X97.239 Y124.428 E.05401
G1 X103.006 Y120.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y119.8 E.03139
G1 X96.994 Y119.8 E.18472
G1 X96.994 Y121.843 E.06279
G1 X103.006 Y121.843 E.18472
G1 X103.006 Y120.882 E.02955
G1 X102.629 Y120.822 F30000
G1 F12000
G1 X102.629 Y120.177 E.01981
G1 X97.371 Y120.177 E.16155
G1 X97.371 Y121.466 E.03961
G1 X102.629 Y121.466 E.16155
G1 X102.629 Y120.882 E.01796
G1 X102.212 Y120.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X102.212 Y120.594 E.00848
G1 X97.788 Y120.594 E.16444
G1 X97.788 Y121.05 E.01695
G1 X102.212 Y121.05 E.16444
G1 X102.212 Y120.882 E.00625
; WIPE_START
G1 X102.212 Y121.05 E-.06386
G1 X100.38 Y121.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X92.749 Y121.165 Z3.6 F30000
G1 X89.006 Y121.222 Z3.6
G1 Z3.2
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y119.8 E.04368
G1 X72.994 Y119.8 E.49198
G1 X72.994 Y122.643 E.08737
G1 X89.006 Y122.643 E.49198
G1 X89.006 Y121.282 E.04184
G1 X88.629 Y121.222 F30000
G1 F12000
G1 X88.629 Y120.177 E.0321
G1 X73.371 Y120.177 E.46881
G1 X73.371 Y122.266 E.0642
G1 X88.629 Y122.266 E.46881
G1 X88.629 Y121.282 E.03025
G1 X88.252 Y121.222 F30000
G1 F12000
G1 X88.252 Y120.554 E.02051
G1 X73.748 Y120.554 E.44564
G1 X73.748 Y121.889 E.04102
G1 X88.252 Y121.889 E.44564
G1 X88.252 Y121.282 E.01867
G1 X87.824 Y121.222 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X87.824 Y120.982 E.00935
G1 X74.176 Y120.982 E.53272
G1 X74.176 Y121.461 E.0187
G1 X87.824 Y121.461 E.53272
G1 X87.824 Y121.282 E.00701
G1 X89.234 Y125.252 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y125.252 E.60098
G1 X72.935 Y125.705 E.01668
G1 X89.065 Y125.705 E.59472
G1 X89.065 Y126.157 E.01668
G1 X72.766 Y126.157 E.60098
G1 X72.952 Y124.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y124.778 E.4443
G1 X74.212 Y124.428 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X75.84 Y124.428 E.05401
G1 X77.233 Y123.035 E.06536
G1 X78.98 Y123.035 E.05794
G1 X80.373 Y124.428 E.06536
G1 X83.516 Y124.428 E.10426
G1 X84.909 Y123.035 E.06536
G1 X86.656 Y123.035 E.05794
G1 X88.049 Y124.428 E.06536
G1 X89.05 Y124.428 E.0332
G1 X89.05 Y123.801 E.02081
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X89.05 Y124.428 E-.23839
G1 X88.049 Y124.428 E-.38037
G1 X87.786 Y124.166 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 17/32
; update layer progress
M73 L17
M991 S0 P16 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.6 I-.166 J1.206 P1  F30000
G1 X183.398 Y137.371 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X72.602 Y137.371 E3.6753
G1 X72.602 Y133.902 E.11507
G1 X72.602 Y133.502 E.01327
G1 F14852.581
G1 X72.602 Y133.442 E.00199
G1 F13500
G1 X89.398 Y133.442 E.55715
G1 F14852.812
G1 X89.398 Y133.502 E.00199
G1 F15476.087
G1 X89.398 Y133.602 E.00332
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y133.502 E.00332
G1 F14852.581
G1 X96.602 Y133.442 E.00199
G1 F13500
G1 X103.398 Y133.442 E.22543
G1 F14852.581
G1 X103.398 Y133.502 E.00199
G1 F15476.087
G1 X103.398 Y133.602 E.00332
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y133.502 E.00332
G1 F14852.581
G1 X110.602 Y133.442 E.00199
G1 F13500
G1 X117.398 Y133.442 E.22543
G1 F14852.581
G1 X117.398 Y133.502 E.00199
G1 F15476.087
G1 X117.398 Y133.602 E.00332
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y133.502 E.00332
G1 F14852.581
G1 X124.602 Y133.442 E.00199
G1 F13500
G1 X131.398 Y133.442 E.22543
G1 F14852.581
G1 X131.398 Y133.502 E.00199
G1 F15476.087
G1 X131.398 Y133.602 E.00332
G1 X138.602 Y133.602 E.23897
G1 X138.602 Y133.502 E.00332
G1 F14852.581
G1 X138.602 Y133.442 E.00199
G1 F13500
G1 X145.398 Y133.442 E.22543
G1 F14852.581
G1 X145.398 Y133.502 E.00199
G1 F15476.087
G1 X145.398 Y133.602 E.00332
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y133.502 E.00332
G1 F14852.581
G1 X152.602 Y133.442 E.00199
G1 F13500
G1 X159.398 Y133.442 E.22543
G1 F14852.581
G1 X159.398 Y133.502 E.00199
G1 F15476.087
G1 X159.398 Y133.602 E.00332
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y133.502 E.00332
G1 F14852.812
G1 X166.602 Y133.442 E.00199
G1 F13500
G1 X183.398 Y133.442 E.55715
G1 F14852.581
G1 X183.398 Y133.502 E.00199
G1 F15476.087
G1 X183.398 Y133.902 E.01327
G1 X183.398 Y137.311 E.11308
M204 S250
G1 X183.79 Y137.763 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y137.763 E3.42854
G1 X72.21 Y134.288 E.10676
G1 X72.21 Y133.888 E.01229
G1 F6459.938
G1 X72.21 Y133.488 E.01229
G1 F1800
G1 X72.21 Y133.119 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y133.05 E.0023
G1 X89.79 Y133.05 E.58316
G1 X89.79 Y133.119 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X89.79 Y133.21 E.00279
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y133.119 E.00279
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X96.21 Y133.05 E.0023
G1 X103.79 Y133.05 E.25144
G1 X103.79 Y133.119 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X103.79 Y133.21 E.00279
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y133.119 E.00279
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X110.21 Y133.05 E.0023
G1 X117.79 Y133.05 E.25144
G1 X117.79 Y133.119 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X117.79 Y133.21 E.00279
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y133.119 E.00279
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X124.21 Y133.05 E.0023
G1 X131.79 Y133.05 E.25144
G1 X131.79 Y133.119 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X131.79 Y133.21 E.00279
G1 X138.21 Y133.21 E.19727
G1 X138.21 Y133.119 E.00279
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X138.21 Y133.05 E.0023
G1 X145.79 Y133.05 E.25144
G1 X145.79 Y133.119 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X145.79 Y133.21 E.00279
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y133.119 E.00279
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X152.21 Y133.05 E.0023
G1 X159.79 Y133.05 E.25144
G1 X159.79 Y133.119 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X159.79 Y133.21 E.00279
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y133.119 E.00279
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X166.21 Y133.05 E.0023
G1 X183.79 Y133.05 E.58316
G1 F3000
G1 X183.79 Y133.119 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y133.488 E.01134
G1 F6459.938
G1 X183.79 Y133.888 E.01229
G1 F12000
G1 X183.79 Y134.288 E.01229
G1 X183.79 Y137.703 E.10492
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X181.79 Y137.704 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.073 Y135.646 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.05 Y135.646 E.03239
G1 X183.05 Y134.994 E.02163
G1 X182.884 Y134.828 E.00777
G1 X180.579 Y134.828 E.07646
G1 X179.762 Y135.646 E.03835
G1 X176.026 Y135.646 E.12393
G1 X175.208 Y134.828 E.03835
G1 X172.903 Y134.828 E.07646
G1 X172.086 Y135.646 E.03835
G1 X168.35 Y135.646 E.12393
G1 X167.532 Y134.828 E.03835
G1 X165.227 Y134.828 E.07646
G1 X164.41 Y135.646 E.03835
G1 X160.674 Y135.646 E.12393
G1 X159.856 Y134.828 E.03835
G1 X157.551 Y134.828 E.07646
G1 X156.734 Y135.646 E.03835
G1 X152.998 Y135.646 E.12393
G1 X152.18 Y134.828 E.03835
G1 X149.875 Y134.828 E.07646
G1 X149.058 Y135.646 E.03835
G1 X145.322 Y135.646 E.12393
G1 X144.504 Y134.828 E.03835
G1 X142.199 Y134.828 E.07646
G1 X141.382 Y135.646 E.03835
G1 X137.646 Y135.646 E.12393
G1 X136.828 Y134.828 E.03835
G1 X134.523 Y134.828 E.07646
G1 X133.706 Y135.646 E.03835
G1 X129.97 Y135.646 E.12393
G1 X129.152 Y134.828 E.03835
G1 X126.848 Y134.828 E.07646
G1 X126.03 Y135.646 E.03835
G1 X122.294 Y135.646 E.12393
G1 X121.476 Y134.828 E.03835
G1 X119.172 Y134.828 E.07646
G1 X118.354 Y135.646 E.03835
G1 X114.618 Y135.646 E.12393
G1 X113.801 Y134.828 E.03835
G1 X111.496 Y134.828 E.07646
G1 X110.678 Y135.646 E.03835
G1 X106.942 Y135.646 E.12393
G1 X106.125 Y134.828 E.03835
G1 X103.82 Y134.828 E.07646
G1 X103.002 Y135.646 E.03835
G1 X99.266 Y135.646 E.12393
G1 X98.449 Y134.828 E.03835
G1 X96.144 Y134.828 E.07646
G1 X95.326 Y135.646 E.03835
G1 X91.59 Y135.646 E.12393
G1 X90.773 Y134.828 E.03835
G1 X88.468 Y134.828 E.07646
G1 X87.65 Y135.646 E.03835
G1 X83.914 Y135.646 E.12393
G1 X83.097 Y134.828 E.03835
G1 X80.792 Y134.828 E.07646
G1 X79.974 Y135.646 E.03835
G1 X76.238 Y135.646 E.12393
M73 P67 R9
G1 X75.421 Y134.828 E.03835
G1 X73.116 Y134.828 E.07646
G1 X72.95 Y134.994 E.00776
G1 X72.95 Y135.646 E.02163
G1 X73.927 Y135.646 E.03239
G1 X72.994 Y136.979 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y136.979 E3.38027
G1 X183.006 Y136.038 E.02891
G1 X72.994 Y136.038 E3.38027
G1 X72.994 Y136.919 E.02706
G1 X73.465 Y136.508 F30000
; LINE_WIDTH: 0.6066
G1 F11176.555
G1 X182.476 Y136.508 E5.00718
G1 X125.018 Y133.89 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53262
G1 F12865.019
G1 X124.987 Y133.97 E.00343
; LINE_WIDTH: 0.512605
G1 F13413.245
G1 X124.896 Y133.99 E.00355
; LINE_WIDTH: 0.452801
G1 F15000
G1 X124.806 Y134.01 E.0031
G1 X117.194 Y134.01 E.25421
; LINE_WIDTH: 0.472573
G1 F14663.012
G1 X117.104 Y133.99 E.00325
; LINE_WIDTH: 0.532317
G1 F12872.985
G1 X117.013 Y133.97 E.0037
G1 X116.982 Y133.89 E.00342
G1 X111.018 Y133.89 E.23787
G1 X110.987 Y133.97 E.00342
; LINE_WIDTH: 0.512605
G1 F13413.245
G1 X110.896 Y133.99 E.00355
; LINE_WIDTH: 0.452801
G1 F15000
G1 X110.806 Y134.01 E.0031
G1 X103.194 Y134.01 E.25421
; LINE_WIDTH: 0.472573
G1 F14663.012
G1 X103.104 Y133.99 E.00325
; LINE_WIDTH: 0.532317
G1 F12872.985
G1 X103.013 Y133.97 E.0037
G1 X102.982 Y133.89 E.00342
G1 X97.018 Y133.89 E.23787
G1 X96.987 Y133.97 E.00342
; LINE_WIDTH: 0.512605
G1 F13413.245
G1 X96.896 Y133.99 E.00355
; LINE_WIDTH: 0.452801
G1 F15000
G1 X96.806 Y134.01 E.0031
G1 X89.194 Y134.01 E.25421
; LINE_WIDTH: 0.472573
G1 F14663.012
G1 X89.104 Y133.99 E.00325
; LINE_WIDTH: 0.532558
G1 F12866.655
G1 X89.013 Y133.97 E.0037
G1 X88.982 Y133.89 E.00343
G1 X73.05 Y133.89 E.63567
G1 X73.05 Y134.38 E.01954
G1 X88.832 Y134.38 E.62968
; LINE_WIDTH: 0.512598
G1 F13413.46
G1 X89.013 Y134.4 E.00697
; LINE_WIDTH: 0.453028
G1 F15000
G1 X89.194 Y134.42 E.00609
G1 X96.806 Y134.42 E.25436
; LINE_WIDTH: 0.472575
G1 F14662.927
G1 X96.987 Y134.4 E.00638
; LINE_WIDTH: 0.531992
G1 F12881.554
G1 X97.168 Y134.38 E.00726
G1 X102.832 Y134.38 E.22575
; LINE_WIDTH: 0.512598
G1 F13413.46
G1 X103.013 Y134.4 E.00697
; LINE_WIDTH: 0.453028
G1 F15000
G1 X103.194 Y134.42 E.00609
G1 X110.806 Y134.42 E.25436
; LINE_WIDTH: 0.472575
G1 F14662.927
G1 X110.987 Y134.4 E.00638
; LINE_WIDTH: 0.531992
G1 F12881.554
G1 X111.168 Y134.38 E.00726
G1 X116.832 Y134.38 E.22575
; LINE_WIDTH: 0.512598
G1 F13413.46
G1 X117.013 Y134.4 E.00697
; LINE_WIDTH: 0.453028
G1 F15000
G1 X117.194 Y134.42 E.00609
G1 X124.806 Y134.42 E.25436
; LINE_WIDTH: 0.472575
G1 F14662.927
G1 X124.987 Y134.4 E.00638
; LINE_WIDTH: 0.531992
G1 F12881.554
G1 X125.168 Y134.38 E.00726
G1 X130.832 Y134.38 E.22575
; LINE_WIDTH: 0.512598
G1 F13413.46
G1 X131.013 Y134.4 E.00697
; LINE_WIDTH: 0.453028
G1 F15000
G1 X131.194 Y134.42 E.00609
G1 X138.806 Y134.42 E.25436
; LINE_WIDTH: 0.472575
G1 F14662.927
G1 X138.987 Y134.4 E.00638
; LINE_WIDTH: 0.531992
G1 F12881.554
G1 X139.168 Y134.38 E.00726
G1 X144.832 Y134.38 E.22575
; LINE_WIDTH: 0.512598
G1 F13413.46
G1 X145.013 Y134.4 E.00697
; LINE_WIDTH: 0.453028
G1 F15000
G1 X145.194 Y134.42 E.00609
G1 X152.806 Y134.42 E.25436
; LINE_WIDTH: 0.472575
G1 F14662.927
G1 X152.987 Y134.4 E.00638
; LINE_WIDTH: 0.531992
G1 F12881.554
G1 X153.168 Y134.38 E.00726
G1 X158.832 Y134.38 E.22575
; LINE_WIDTH: 0.512598
G1 F13413.46
G1 X159.013 Y134.4 E.00697
; LINE_WIDTH: 0.453028
G1 F15000
G1 X159.194 Y134.42 E.00609
G1 X166.806 Y134.42 E.25436
; LINE_WIDTH: 0.472575
G1 F14662.927
G1 X166.987 Y134.4 E.00638
; LINE_WIDTH: 0.532508
G1 F12867.97
G1 X167.168 Y134.38 E.00727
G1 X182.95 Y134.38 E.62962
G1 X182.95 Y133.89 E.01954
G1 X167.018 Y133.89 E.63561
G1 X166.987 Y133.97 E.00343
; LINE_WIDTH: 0.512605
G1 F13413.245
G1 X166.896 Y133.99 E.00355
; LINE_WIDTH: 0.452801
G1 F15000
G1 X166.806 Y134.01 E.0031
G1 X159.194 Y134.01 E.25421
; LINE_WIDTH: 0.472573
G1 F14663.012
G1 X159.104 Y133.99 E.00325
; LINE_WIDTH: 0.532317
G1 F12872.985
G1 X159.013 Y133.97 E.0037
G1 X158.982 Y133.89 E.00342
G1 X153.018 Y133.89 E.23787
G1 X152.987 Y133.97 E.00342
; LINE_WIDTH: 0.512605
G1 F13413.245
G1 X152.896 Y133.99 E.00355
; LINE_WIDTH: 0.452801
G1 F15000
G1 X152.806 Y134.01 E.0031
G1 X145.194 Y134.01 E.25421
; LINE_WIDTH: 0.472573
G1 F14663.012
G1 X145.104 Y133.99 E.00325
; LINE_WIDTH: 0.532317
G1 F12872.985
G1 X145.013 Y133.97 E.0037
G1 X144.982 Y133.89 E.00342
G1 X139.018 Y133.89 E.23787
G1 X138.987 Y133.97 E.00342
; LINE_WIDTH: 0.512605
G1 F13413.245
G1 X138.896 Y133.99 E.00355
; LINE_WIDTH: 0.452801
G1 F15000
G1 X138.806 Y134.01 E.0031
G1 X131.194 Y134.01 E.25421
; LINE_WIDTH: 0.472573
G1 F14663.012
G1 X131.104 Y133.99 E.00325
; LINE_WIDTH: 0.53231
G1 F12873.174
G1 X131.013 Y133.97 E.0037
G1 X130.982 Y133.89 E.00342
G1 X125.078 Y133.89 E.23547
; WIPE_START
G1 X127.078 Y133.89 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I1.186 J.272 P1  F30000
G1 X130.213 Y120.208 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X130.922 Y120.208 E.02354
G1 X130.922 Y120.318 E.00365
G1 X131.398 Y120.318 E.01578
G1 X131.398 Y125.748 E.18011
G1 X131.398 Y126.148 E.01327
G1 F14331.075
G1 X131.398 Y126.548 E.01327
G1 F6685.538
G1 X131.398 Y126.948 E.01327
G1 F1920
G1 X131.398 Y127.328 E.01262
G1 F600
G1 X124.602 Y127.328 E.22543
G1 F1920
G1 X124.602 Y126.948 E.01262
G1 F6685.538
G1 X124.602 Y126.548 E.01327
G1 F14331.075
G1 X124.602 Y126.148 E.01327
G1 F15476.087
G1 X124.602 Y125.748 E.01327
G1 X124.602 Y120.318 E.18011
G1 X125.078 Y120.318 E.01578
G1 X125.078 Y120.208 E.00365
G1 X130.153 Y120.208 E.16834
; WIPE_START
G1 X130.922 Y120.208 E-.29244
G1 X130.922 Y120.318 E-.04183
G1 X131.398 Y120.318 E-.18077
G1 X131.398 Y120.963 E-.24497
; WIPE_END
G1 E-.04 F1800
G1 X138.602 Y120.318 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G1 X139.078 Y120.318 E.01578
G1 X139.078 Y120.208 E.00365
G1 X144.922 Y120.208 E.19387
G1 X144.922 Y120.318 E.00365
G1 X145.398 Y120.318 E.01578
G1 X145.398 Y125.748 E.18011
G1 X145.398 Y126.148 E.01327
G1 F14331.075
G1 X145.398 Y126.548 E.01327
G1 F6685.538
G1 X145.398 Y126.948 E.01327
G1 F1920
G1 X145.398 Y127.328 E.01262
G1 F600
G1 X138.602 Y127.328 E.22543
G1 F1920
G1 X138.602 Y126.948 E.01262
G1 F6685.538
G1 X138.602 Y126.548 E.01327
G1 F14331.075
G1 X138.602 Y126.148 E.01327
G1 F15476.087
G1 X138.602 Y125.748 E.01327
G1 X138.602 Y120.378 E.17812
; WIPE_START
G1 X139.078 Y120.318 E-.1822
G1 X139.078 Y120.208 E-.04183
G1 X140.488 Y120.208 E-.53598
; WIPE_END
G1 E-.04 F1800
G1 X148.12 Y120.277 Z3.8 F30000
G1 X152.602 Y120.318 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G1 X153.078 Y120.318 E.01578
G1 X153.078 Y120.208 E.00365
G1 X158.922 Y120.208 E.19387
G1 X158.922 Y120.318 E.00365
G1 X159.398 Y120.318 E.01578
G1 X159.398 Y125.748 E.18011
G1 X159.398 Y126.148 E.01327
G1 F14331.075
G1 X159.398 Y126.548 E.01327
G1 F6685.538
G1 X159.398 Y126.948 E.01327
G1 F1920
G1 X159.398 Y127.328 E.01262
G1 F600
G1 X152.602 Y127.328 E.22543
G1 F1920
G1 X152.602 Y126.948 E.01262
G1 F6685.538
G1 X152.602 Y126.548 E.01327
G1 F14331.075
G1 X152.602 Y126.148 E.01327
G1 F15476.087
G1 X152.602 Y125.748 E.01327
G1 X152.602 Y120.378 E.17812
; WIPE_START
G1 X153.078 Y120.318 E-.1822
G1 X153.078 Y120.208 E-.04183
G1 X154.488 Y120.208 E-.53598
; WIPE_END
G1 E-.04 F1800
G1 X162.12 Y120.277 Z3.8 F30000
G1 X166.602 Y120.318 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G1 X167.078 Y120.318 E.01578
G1 X167.078 Y120.208 E.00365
G1 X183.398 Y120.208 E.54137
G1 X183.398 Y125.748 E.18376
G1 X183.398 Y126.148 E.01327
G1 F14331.075
G1 X183.398 Y126.548 E.01327
G1 F6685.538
G1 X183.398 Y126.948 E.01327
G1 F1920
G1 X183.398 Y127.328 E.01262
G1 F600
G1 X166.602 Y127.328 E.55715
G1 F1920
G1 X166.602 Y126.948 E.01262
G1 F6685.538
G1 X166.602 Y126.548 E.01327
G1 F14331.075
G1 X166.602 Y126.148 E.01327
G1 F15476.087
G1 X166.602 Y125.748 E.01327
G1 X166.602 Y120.378 E.17812
; WIPE_START
G1 X167.078 Y120.318 E-.1822
G1 X167.078 Y120.208 E-.04183
G1 X168.488 Y120.208 E-.53598
; WIPE_END
G1 E-.04 F1800
G1 X160.856 Y120.208 Z3.8 F30000
G1 X116.922 Y120.208 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G1 X116.922 Y120.318 E.00365
G1 X117.398 Y120.318 E.01578
G1 X117.398 Y125.748 E.18011
G1 X117.398 Y126.148 E.01327
G1 F14331.075
G1 X117.398 Y126.548 E.01327
G1 F6685.538
G1 X117.398 Y126.948 E.01327
G1 F1920
G1 X117.398 Y127.328 E.01262
G1 F600
G1 X110.602 Y127.328 E.22543
G1 F1920
G1 X110.602 Y126.948 E.01262
G1 F6685.538
G1 X110.602 Y126.548 E.01327
G1 F14331.075
G1 X110.602 Y126.148 E.01327
G1 F15476.087
G1 X110.602 Y125.748 E.01327
G1 X110.602 Y120.318 E.18011
G1 X111.078 Y120.318 E.01578
G1 X111.078 Y120.208 E.00365
G1 X116.862 Y120.208 E.19188
; WIPE_START
G1 X116.922 Y120.318 E-.04764
G1 X117.398 Y120.318 E-.18077
G1 X117.398 Y121.717 E-.5316
; WIPE_END
G1 E-.04 F1800
G1 X109.807 Y120.925 Z3.8 F30000
G1 X102.922 Y120.208 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G1 X102.922 Y120.318 E.00365
G1 X103.398 Y120.318 E.01578
G1 X103.398 Y125.748 E.18011
G1 X103.398 Y126.148 E.01327
G1 F14331.075
G1 X103.398 Y126.548 E.01327
G1 F6685.538
G1 X103.398 Y126.948 E.01327
G1 F1920
G1 X103.398 Y127.328 E.01262
G1 F600
G1 X96.602 Y127.328 E.22543
G1 F1920
G1 X96.602 Y126.948 E.01262
G1 F6685.538
G1 X96.602 Y126.548 E.01327
G1 F14331.075
G1 X96.602 Y126.148 E.01327
G1 F15476.087
G1 X96.602 Y125.748 E.01327
G1 X96.602 Y120.318 E.18011
G1 X97.078 Y120.318 E.01578
G1 X97.078 Y120.208 E.00365
G1 X102.862 Y120.208 E.19188
; WIPE_START
G1 X102.922 Y120.318 E-.04764
G1 X103.398 Y120.318 E-.18077
G1 X103.398 Y121.717 E-.5316
; WIPE_END
G1 E-.04 F1800
G1 X95.807 Y120.925 Z3.8 F30000
G1 X88.922 Y120.208 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F15476.087
G1 X88.922 Y120.318 E.00365
G1 X89.398 Y120.318 E.01578
G1 X89.398 Y125.748 E.18011
G1 X89.398 Y126.148 E.01327
G1 F14331.075
G1 X89.398 Y126.548 E.01327
G1 F6685.538
G1 X89.398 Y126.948 E.01327
G1 F1920
G1 X89.398 Y127.328 E.01262
G1 F600
G1 X72.602 Y127.328 E.55715
G1 F1920
M73 P68 R9
G1 X72.602 Y126.948 E.01262
G1 F6685.538
G1 X72.602 Y126.548 E.01327
G1 F14331.075
G1 X72.602 Y126.148 E.01327
G1 F15476.087
G1 X72.602 Y125.748 E.01327
G1 X72.602 Y120.208 E.18376
G1 X88.862 Y120.208 E.53938
; WIPE_START
G1 X88.922 Y120.318 E-.04764
G1 X89.398 Y120.318 E-.18077
G1 X89.398 Y121.717 E-.5316
; WIPE_END
G1 E-.04 F1800
G1 X97.012 Y121.191 Z3.8 F30000
G1 X131.79 Y118.79 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y126.161 E.22649
G1 X131.79 Y126.561 E.01229
G1 F6459.938
G1 X131.79 Y126.961 E.01229
G1 F1800
G1 X131.79 Y127.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X131.79 Y127.72 E.01294
G1 X124.21 Y127.72 E.25144
G1 X124.21 Y127.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y126.961 E.01134
G1 F6459.938
G1 X124.21 Y126.561 E.01229
G1 F12000
G1 X124.21 Y126.161 E.01229
G1 X124.21 Y118.79 E.22649
G1 X117.79 Y118.79 E.19727
G1 X117.79 Y126.161 E.22649
G1 X117.79 Y126.561 E.01229
G1 F6459.938
G1 X117.79 Y126.961 E.01229
G1 F1800
G1 X117.79 Y127.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X117.79 Y127.72 E.01294
G1 X110.21 Y127.72 E.25144
G1 X110.21 Y127.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y126.961 E.01134
G1 F6459.938
G1 X110.21 Y126.561 E.01229
G1 F12000
G1 X110.21 Y126.161 E.01229
G1 X110.21 Y118.79 E.22649
G1 X103.79 Y118.79 E.19727
G1 X103.79 Y126.161 E.22649
G1 X103.79 Y126.561 E.01229
G1 F6459.938
G1 X103.79 Y126.961 E.01229
G1 F1800
G1 X103.79 Y127.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X103.79 Y127.72 E.01294
G1 X96.21 Y127.72 E.25144
G1 X96.21 Y127.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y126.961 E.01134
G1 F6459.938
G1 X96.21 Y126.561 E.01229
G1 F12000
G1 X96.21 Y126.161 E.01229
G1 X96.21 Y118.79 E.22649
G1 X89.79 Y118.79 E.19727
G1 X89.79 Y126.161 E.22649
G1 X89.79 Y126.561 E.01229
G1 F6459.938
G1 X89.79 Y126.961 E.01229
G1 F1800
G1 X89.79 Y127.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.79 Y127.72 E.01294
G1 X72.21 Y127.72 E.58316
G1 X72.21 Y127.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y126.961 E.01134
G1 F6459.938
G1 X72.21 Y126.561 E.01229
G1 F12000
G1 X72.21 Y126.161 E.01229
G1 X72.21 Y118.54 E.23417
G1 X183.79 Y118.54 E3.42854
G1 X183.79 Y126.161 E.23417
G1 X183.79 Y126.561 E.01229
G1 F6459.938
G1 X183.79 Y126.961 E.01229
G1 F1800
G1 X183.79 Y127.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y127.72 E.01294
G1 F600
G1 X166.21 Y127.72 E.58316
G1 X166.21 Y127.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y126.961 E.01134
G1 F6459.938
G1 X166.21 Y126.561 E.01229
G1 F12000
G1 X166.21 Y126.161 E.01229
G1 X166.21 Y118.79 E.22649
G1 X159.79 Y118.79 E.19727
G1 X159.79 Y126.161 E.22649
G1 X159.79 Y126.561 E.01229
M73 P68 R8
G1 F6459.938
G1 X159.79 Y126.961 E.01229
G1 F1800
G1 X159.79 Y127.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X159.79 Y127.72 E.01294
G1 X152.21 Y127.72 E.25144
G1 X152.21 Y127.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y126.961 E.01134
G1 F6459.938
G1 X152.21 Y126.561 E.01229
G1 F12000
G1 X152.21 Y126.161 E.01229
G1 X152.21 Y118.79 E.22649
G1 X145.79 Y118.79 E.19727
G1 X145.79 Y126.161 E.22649
G1 X145.79 Y126.561 E.01229
G1 F6459.938
G1 X145.79 Y126.961 E.01229
G1 F1800
G1 X145.79 Y127.33 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X145.79 Y127.72 E.01294
G1 X138.21 Y127.72 E.25144
G1 X138.21 Y127.33 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y126.961 E.01134
G1 F6459.938
G1 X138.21 Y126.561 E.01229
G1 F12000
G1 X138.21 Y126.161 E.01229
G1 X138.21 Y118.79 E.22649
G1 X131.85 Y118.79 E.19542
M204 S10000
G1 X131.583 Y119.184 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X131.146 Y118.747 E.01898
G1 X130.613 Y118.747
G1 X131.583 Y119.717 E.04215
G1 X131.427 Y120.095
G1 X130.079 Y118.747 E.05858
G1 X129.546 Y118.747
G1 X130.784 Y119.985 E.05379
G1 X130.251 Y119.985
G1 X129.013 Y118.747 E.05379
G1 X128.48 Y118.747
G1 X129.717 Y119.985 E.05379
G1 X129.184 Y119.985
G1 X127.946 Y118.747 E.05379
G1 X127.413 Y118.747
G1 X128.651 Y119.985 E.05379
G1 X128.118 Y119.985
G1 X126.88 Y118.747 E.05379
G1 X126.347 Y118.747
G1 X127.584 Y119.985 E.05379
G1 X127.051 Y119.985
G1 X125.813 Y118.747 E.05379
G1 X125.28 Y118.747
G1 X126.518 Y119.985 E.05379
G1 X125.985 Y119.985
G1 X124.747 Y118.747 E.05379
G1 X124.417 Y118.951
G1 X125.451 Y119.985 E.04493
G1 X124.918 Y119.985
G1 X124.417 Y119.485 E.02176
; WIPE_START
M204 S10000
G1 X124.918 Y119.985 E-.26911
G1 X125.451 Y119.985 E-.20264
G1 X124.915 Y119.449 E-.28825
; WIPE_END
G1 E-.04 F1800
G1 X124.952 Y125.578 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y125.578 E.16725
G1 X131.234 Y126.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y126.052 E.23226
G1 X124.935 Y126.505 E.01668
G1 X131.065 Y126.505 E.22601
G1 X131.065 Y126.957 E.01668
G1 X124.766 Y126.957 E.23226
G1 X131.05 Y124.579 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.05 Y123.035 E.05119
G1 X130.965 Y123.035 E.00282
G1 X128.772 Y125.228 E.10288
G1 X127.228 Y125.228 E.05119
G1 X125.035 Y123.035 E.10288
G1 X126.664 Y123.035 E.05401
G1 X131.006 Y120.997 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y120.71 E.00882
G1 X130.629 Y120.687 E.01161
G1 X130.577 Y120.6 E.00312
G1 X125.423 Y120.6 E.15836
G1 X125.371 Y120.687 E.00312
G1 X124.994 Y120.71 E.01161
G1 X124.994 Y122.643 E.0594
G1 X131.006 Y122.643 E.18472
G1 X131.006 Y121.057 E.04874
G1 X130.629 Y121.064 F30000
G1 F12000
G1 X130.629 Y122.032 E.02973
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X130.629 Y122.266 E.0072
G1 X125.371 Y122.266 E.16155
G1 X125.371 Y122.032 E.0072
; Slow Down End
G1 F12000
G1 X125.371 Y121.064 E.02973
G1 X125.551 Y121.019 E.0057
G1 X125.576 Y120.977 E.00149
G1 X130.424 Y120.977 E.14897
G1 X130.449 Y121.019 E.00149
G1 X130.571 Y121.049 E.00386
G1 X130.212 Y121.394 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X125.788 Y121.394 E.16444
G1 X125.788 Y121.85 E.01695
G1 X130.212 Y121.85 E.16444
G1 X130.212 Y121.454 E.01472
; WIPE_START
G1 X130.212 Y121.85 E-.15053
G1 X128.608 Y121.85 E-.60947
; WIPE_END
G1 E-.04 F1800
G1 X135.789 Y124.438 Z3.8 F30000
G1 X138.952 Y125.578 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y125.578 E.16725
G1 X145.234 Y126.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y126.052 E.23226
G1 X138.935 Y126.505 E.01668
G1 X145.065 Y126.505 E.22601
G1 X145.065 Y126.957 E.01668
G1 X138.766 Y126.957 E.23226
G1 X144.688 Y123.035 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X145.05 Y123.035 E.01199
G1 X145.05 Y124.302 E.04203
G1 X144.123 Y125.228 E.04345
G1 X142.58 Y125.228 E.05119
G1 X140.387 Y123.035 E.10288
G1 X138.95 Y123.035 E.04766
G1 X138.95 Y123.227 E.00635
G1 X145.006 Y120.997 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y120.71 E.00882
G1 X144.629 Y120.687 E.01161
G1 X144.577 Y120.6 E.00312
G1 X139.423 Y120.6 E.15836
G1 X139.371 Y120.687 E.00312
G1 X138.994 Y120.71 E.01161
G1 X138.994 Y122.643 E.0594
G1 X145.006 Y122.643 E.18472
G1 X145.006 Y121.057 E.04874
G1 X139.371 Y122.266 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X139.371 Y122.032 E.0072
; Slow Down End
G1 F12000
G1 X139.371 Y121.064 E.02973
G1 X139.551 Y121.019 E.0057
G1 X139.576 Y120.977 E.00149
G1 X144.424 Y120.977 E.14897
G1 X144.449 Y121.019 E.00149
G1 X144.629 Y121.064 E.0057
G1 X144.629 Y122.032 E.02973
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X144.629 Y122.266 E.0072
; Slow Down End
G1 F12000
G1 X139.431 Y122.266 E.1597
G1 X139.788 Y121.85 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X144.212 Y121.85 E.16444
G1 X144.212 Y121.394 E.01695
G1 X139.788 Y121.394 E.16444
G1 X139.788 Y121.79 E.01472
; WIPE_START
G1 X139.788 Y121.394 E-.15053
G1 X141.392 Y121.394 E-.60947
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y119.319 Z3.8 F30000
M73 P69 R8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.011 Y118.747 E.02486
G1 X144.477 Y118.747
G1 X145.583 Y119.853 E.04803
G1 X145.292 Y120.095
G1 X143.944 Y118.747 E.05858
G1 X143.411 Y118.747
G1 X144.649 Y119.985 E.05379
G1 X144.115 Y119.985
G1 X142.878 Y118.747 E.05379
G1 X142.344 Y118.747
G1 X143.582 Y119.985 E.05379
G1 X143.049 Y119.985
G1 X141.811 Y118.747 E.05379
G1 X141.278 Y118.747
G1 X142.516 Y119.985 E.05379
G1 X141.982 Y119.985
G1 X140.744 Y118.747 E.05379
G1 X140.211 Y118.747
G1 X141.449 Y119.985 E.05379
G1 X140.916 Y119.985
G1 X139.678 Y118.747 E.05379
G1 X139.145 Y118.747
G1 X140.383 Y119.985 E.05379
G1 X139.849 Y119.985
G1 X138.611 Y118.747 E.05379
G1 X138.417 Y119.087
G1 X139.316 Y119.985 E.03905
G1 X138.855 Y120.058
G1 X138.417 Y119.62 E.01903
; WIPE_START
M204 S10000
G1 X138.855 Y120.058 E-.23532
G1 X139.316 Y119.985 E-.17726
G1 X138.67 Y119.339 E-.34742
; WIPE_END
G1 E-.04 F1800
G1 X145.664 Y122.394 Z3.8 F30000
G1 X152.952 Y125.578 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y125.578 E.16725
G1 X159.234 Y126.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y126.052 E.23226
G1 X152.935 Y126.505 E.01668
G1 X159.065 Y126.505 E.22601
G1 X159.065 Y126.957 E.01668
G1 X152.766 Y126.957 E.23226
G1 X153.428 Y125.228 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X152.95 Y125.228 E.01583
G1 X152.95 Y124.078 E.03818
G1 X153.993 Y123.035 E.04889
G1 X155.739 Y123.035 E.05794
G1 X157.932 Y125.228 E.10288
G1 X159.05 Y125.228 E.03707
G1 X159.05 Y124.718 E.01695
G1 X159.006 Y120.997 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y120.71 E.00882
G1 X158.629 Y120.687 E.01161
G1 X158.577 Y120.6 E.00312
G1 X153.423 Y120.6 E.15836
G1 X153.371 Y120.687 E.00312
G1 X152.994 Y120.71 E.01161
G1 X152.994 Y122.643 E.0594
G1 X159.006 Y122.643 E.18472
G1 X159.006 Y121.057 E.04874
G1 X153.371 Y121.064 F30000
G1 F12000
G1 X153.551 Y121.019 E.0057
G1 X153.576 Y120.977 E.00149
G1 X158.424 Y120.977 E.14897
G1 X158.449 Y121.019 E.00149
G1 X158.629 Y121.064 E.0057
G1 X158.629 Y122.032 E.02973
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X158.629 Y122.266 E.0072
G1 X153.371 Y122.266 E.16155
G1 X153.371 Y122.032 E.0072
; Slow Down End
G1 F12000
G1 X153.371 Y121.124 E.02789
G1 X153.788 Y121.394 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X153.788 Y121.85 E.01695
G1 X158.212 Y121.85 E.16444
G1 X158.212 Y121.394 E.01695
G1 X153.848 Y121.394 E.16221
; WIPE_START
G1 X155.848 Y121.394 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y119.455 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X158.875 Y118.747 E.03074
G1 X158.342 Y118.747
G1 X159.583 Y119.988 E.05391
G1 X159.047 Y119.985
G1 X157.809 Y118.747 E.05379
G1 X157.275 Y118.747
G1 X158.513 Y119.985 E.05379
G1 X157.98 Y119.985
G1 X156.742 Y118.747 E.05379
G1 X156.209 Y118.747
G1 X157.447 Y119.985 E.05379
G1 X156.914 Y119.985
G1 X155.676 Y118.747 E.05379
G1 X155.142 Y118.747
G1 X156.38 Y119.985 E.05379
G1 X155.847 Y119.985
G1 X154.609 Y118.747 E.05379
G1 X154.076 Y118.747
G1 X155.314 Y119.985 E.05379
G1 X154.781 Y119.985
G1 X153.543 Y118.747 E.05379
G1 X153.009 Y118.747
G1 X154.247 Y119.985 E.05379
G1 X153.714 Y119.985
G1 X152.476 Y118.747 E.05379
G1 X152.417 Y119.222
G1 X153.181 Y119.985 E.03317
G1 X152.758 Y120.095
G1 X152.417 Y119.755 E.01478
; WIPE_START
M204 S10000
G1 X152.758 Y120.095 E-.18284
G1 X153.181 Y119.985 E-.16616
G1 X152.417 Y119.222 E-.41026
G1 X152.418 Y119.22 E-.00074
; WIPE_END
G1 E-.04 F1800
G1 X159.41 Y122.279 Z3.8 F30000
G1 X166.952 Y125.578 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y125.578 E.4443
G1 X183.234 Y126.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y126.052 E.60098
G1 X166.935 Y126.505 E.01668
G1 X183.065 Y126.505 E.59472
G1 X183.065 Y126.957 E.01668
G1 X166.766 Y126.957 E.60098
G1 X168.78 Y125.228 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.151 Y125.228 E.05401
G1 X168.544 Y123.835 E.06536
G1 X171.891 Y123.835 E.11101
G1 X173.284 Y125.228 E.06536
G1 X174.827 Y125.228 E.05119
G1 X176.22 Y123.835 E.06536
G1 X179.567 Y123.835 E.11101
G1 X180.96 Y125.228 E.06536
G1 X182.503 Y125.228 E.05119
G1 X183.05 Y124.682 E.02564
G1 X183.05 Y123.835 E.02809
G1 X182.268 Y123.835 E.02593
G1 X183.006 Y122.022 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y120.6 E.04368
G1 X167.423 Y120.6 E.4788
G1 X167.371 Y120.687 E.00312
G1 X166.994 Y120.71 E.01161
G1 X166.994 Y123.443 E.08399
G1 X183.006 Y123.443 E.49198
G1 X183.006 Y122.082 E.04184
G1 X182.629 Y122.022 F30000
G1 F12000
G1 X182.629 Y120.977 E.0321
G1 X167.576 Y120.977 E.46253
G1 X167.551 Y121.019 E.00149
G1 X167.371 Y121.064 E.0057
G1 X167.371 Y123.066 E.06151
G1 X182.629 Y123.066 E.46881
G1 X182.629 Y122.082 E.03025
G1 X182.252 Y122.022 F30000
G1 F12000
G1 X182.252 Y121.354 E.02051
G1 X167.748 Y121.354 E.44564
G1 X167.748 Y122.689 E.04102
G1 X182.252 Y122.689 E.44564
G1 X182.252 Y122.082 E.01867
G1 X181.824 Y122.022 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y121.782 E.00935
G1 X168.176 Y121.782 E.53272
G1 X168.176 Y122.261 E.0187
G1 X181.824 Y122.261 E.53272
G1 X181.824 Y122.082 E.00701
; WIPE_START
G1 X181.824 Y122.261 E-.06822
G1 X180.003 Y122.261 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y119.458 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X182.872 Y118.747 E.03089
G1 X182.339 Y118.747
G1 X183.576 Y119.985 E.05379
G1 X183.043 Y119.985
G1 X181.805 Y118.747 E.05379
G1 X181.272 Y118.747
G1 X182.51 Y119.985 E.05379
G1 X181.977 Y119.985
G1 X180.739 Y118.747 E.05379
G1 X180.206 Y118.747
G1 X181.443 Y119.985 E.05379
G1 X180.91 Y119.985
G1 X179.672 Y118.747 E.05379
G1 X179.139 Y118.747
G1 X180.377 Y119.985 E.05379
G1 X179.844 Y119.985
G1 X178.606 Y118.747 E.05379
G1 X178.073 Y118.747
G1 X179.31 Y119.985 E.05379
G1 X178.777 Y119.985
G1 X177.539 Y118.747 E.05379
G1 X177.006 Y118.747
G1 X178.244 Y119.985 E.05379
G1 X177.711 Y119.985
G1 X176.473 Y118.747 E.05379
G1 X175.939 Y118.747
G1 X177.177 Y119.985 E.05379
G1 X176.644 Y119.985
G1 X175.406 Y118.747 E.05379
G1 X174.873 Y118.747
G1 X176.111 Y119.985 E.05379
G1 X175.578 Y119.985
G1 X174.34 Y118.747 E.05379
G1 X173.806 Y118.747
G1 X175.044 Y119.985 E.05379
G1 X174.511 Y119.985
G1 X173.273 Y118.747 E.05379
G1 X172.74 Y118.747
G1 X173.978 Y119.985 E.05379
G1 X173.445 Y119.985
G1 X172.207 Y118.747 E.05379
G1 X171.673 Y118.747
G1 X172.911 Y119.985 E.05379
G1 X172.378 Y119.985
G1 X171.14 Y118.747 E.05379
G1 X170.607 Y118.747
G1 X171.845 Y119.985 E.05379
G1 X171.312 Y119.985
G1 X170.074 Y118.747 E.05379
G1 X169.54 Y118.747
G1 X170.778 Y119.985 E.05379
G1 X170.245 Y119.985
G1 X169.007 Y118.747 E.05379
G1 X168.474 Y118.747
G1 X169.712 Y119.985 E.05379
G1 X169.179 Y119.985
G1 X167.941 Y118.747 E.05379
G1 X167.407 Y118.747
G1 X168.645 Y119.985 E.05379
G1 X168.112 Y119.985
G1 X166.874 Y118.747 E.05379
G1 X166.417 Y118.824
G1 X167.579 Y119.985 E.05047
G1 X167.045 Y119.985
G1 X166.417 Y119.357 E.02729
; WIPE_START
M204 S10000
G1 X167.045 Y119.985 E-.33754
G1 X167.579 Y119.985 E-.20264
G1 X167.17 Y119.576 E-.21982
; WIPE_END
G1 E-.04 F1800
G1 X159.557 Y120.131 Z3.8 F30000
G1 X117.05 Y123.227 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X117.05 Y123.035 E.00635
G1 X115.613 Y123.035 E.04767
G1 X113.42 Y125.228 E.10288
G1 X111.877 Y125.228 E.05119
G1 X110.95 Y124.302 E.04345
G1 X110.95 Y123.035 E.04203
G1 X111.312 Y123.035 E.01199
G1 X110.952 Y125.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y125.578 E.16725
G1 X117.234 Y126.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y126.052 E.23226
G1 X110.935 Y126.505 E.01668
G1 X117.065 Y126.505 E.22601
G1 X117.065 Y126.957 E.01668
G1 X110.766 Y126.957 E.23226
; WIPE_START
G1 X112.766 Y126.957 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I.115 J-1.212 P1  F30000
G1 X103.234 Y126.052 Z3.8
G1 Z3.4
G1 E.8 F1800
G1 F3000
G1 X96.935 Y126.052 E.23226
G1 X96.935 Y126.505 E.01668
G1 X103.065 Y126.505 E.22601
G1 X103.065 Y126.957 E.01668
G1 X96.766 Y126.957 E.23226
G1 X96.952 Y125.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y125.578 E.16725
G1 X103.006 Y120.997 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y120.71 E.00882
G1 X102.629 Y120.687 E.01161
G1 X102.577 Y120.6 E.00312
G1 X97.423 Y120.6 E.15836
G1 X97.371 Y120.687 E.00312
G1 X96.994 Y120.71 E.01161
G1 X96.994 Y122.643 E.0594
G1 X103.006 Y122.643 E.18472
G1 X103.006 Y121.057 E.04874
G1 X97.371 Y121.064 F30000
G1 F12000
G1 X97.551 Y121.019 E.0057
G1 X97.576 Y120.977 E.00149
G1 X102.424 Y120.977 E.14897
G1 X102.449 Y121.019 E.00149
G1 X102.629 Y121.064 E.0057
G1 X102.629 Y122.032 E.02973
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X102.629 Y122.266 E.0072
G1 X97.371 Y122.266 E.16155
G1 X97.371 Y122.032 E.0072
; Slow Down End
G1 F12000
G1 X97.371 Y121.124 E.02789
G1 X97.788 Y121.394 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X97.788 Y121.85 E.01695
G1 X102.212 Y121.85 E.16444
G1 X102.212 Y121.394 E.01695
G1 X97.848 Y121.394 E.16221
G1 X96.95 Y124.718 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X96.95 Y125.228 E.01695
G1 X98.068 Y125.228 E.03707
G1 X100.261 Y123.035 E.10288
G1 X102.007 Y123.035 E.05794
G1 X103.05 Y124.078 E.04889
G1 X103.05 Y125.228 E.03818
G1 X102.572 Y125.228 E.01584
; WIPE_START
G1 X103.05 Y125.228 E-.1814
G1 X103.05 Y124.078 E-.43735
G1 X102.787 Y123.815 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y119.447 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X102.883 Y118.747 E.03039
G1 X102.35 Y118.747
G1 X103.583 Y119.98 E.05357
G1 X103.055 Y119.985
G1 X101.817 Y118.747 E.05379
G1 X101.283 Y118.747
G1 X102.521 Y119.985 E.05379
G1 X101.988 Y119.985
G1 X100.75 Y118.747 E.05379
G1 X100.217 Y118.747
G1 X101.455 Y119.985 E.05379
G1 X100.922 Y119.985
G1 X99.684 Y118.747 E.05379
G1 X99.15 Y118.747
G1 X100.388 Y119.985 E.05379
G1 X99.855 Y119.985
G1 X98.617 Y118.747 E.05379
G1 X98.084 Y118.747
G1 X99.322 Y119.985 E.05379
G1 X98.789 Y119.985
G1 X97.551 Y118.747 E.05379
G1 X97.017 Y118.747
G1 X98.255 Y119.985 E.05379
G1 X97.722 Y119.985
G1 X96.484 Y118.747 E.05379
G1 X96.417 Y119.214
G1 X97.189 Y119.985 E.03352
G1 X96.766 Y120.095
G1 X96.417 Y119.747 E.01513
; WIPE_START
M204 S10000
G1 X96.766 Y120.095 E-.18712
G1 X97.189 Y119.985 E-.16616
G1 X96.432 Y119.228 E-.40672
; WIPE_END
G1 E-.04 F1800
G1 X89.583 Y119.312 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X89.019 Y118.747 E.02451
G1 X88.485 Y118.747
G1 X89.583 Y119.845 E.04769
G1 X89.3 Y120.095
G1 X87.952 Y118.747 E.05858
G1 X87.419 Y118.747
G1 X88.657 Y119.985 E.05379
G1 X88.123 Y119.985
G1 X86.885 Y118.747 E.05379
G1 X86.352 Y118.747
G1 X87.59 Y119.985 E.05379
G1 X87.057 Y119.985
G1 X85.819 Y118.747 E.05379
G1 X85.286 Y118.747
G1 X86.524 Y119.985 E.05379
G1 X85.99 Y119.985
G1 X84.752 Y118.747 E.05379
G1 X84.219 Y118.747
G1 X85.457 Y119.985 E.05379
G1 X84.924 Y119.985
G1 X83.686 Y118.747 E.05379
G1 X83.153 Y118.747
G1 X84.391 Y119.985 E.05379
G1 X83.857 Y119.985
G1 X82.619 Y118.747 E.05379
G1 X82.086 Y118.747
G1 X83.324 Y119.985 E.05379
G1 X82.791 Y119.985
G1 X81.553 Y118.747 E.05379
G1 X81.02 Y118.747
G1 X82.258 Y119.985 E.05379
G1 X81.724 Y119.985
G1 X80.486 Y118.747 E.05379
G1 X79.953 Y118.747
G1 X81.191 Y119.985 E.05379
G1 X80.658 Y119.985
G1 X79.42 Y118.747 E.05379
G1 X78.887 Y118.747
G1 X80.125 Y119.985 E.05379
G1 X79.591 Y119.985
G1 X78.353 Y118.747 E.05379
G1 X77.82 Y118.747
G1 X79.058 Y119.985 E.05379
G1 X78.525 Y119.985
G1 X77.287 Y118.747 E.05379
G1 X76.754 Y118.747
G1 X77.991 Y119.985 E.05379
G1 X77.458 Y119.985
G1 X76.22 Y118.747 E.05379
G1 X75.687 Y118.747
G1 X76.925 Y119.985 E.05379
G1 X76.392 Y119.985
G1 X75.154 Y118.747 E.05379
G1 X74.621 Y118.747
G1 X75.858 Y119.985 E.05379
G1 X75.325 Y119.985
G1 X74.087 Y118.747 E.05379
G1 X73.554 Y118.747
G1 X74.792 Y119.985 E.05379
G1 X74.259 Y119.985
G1 X73.021 Y118.747 E.05379
G1 X72.488 Y118.747
G1 X73.725 Y119.985 E.05379
G1 X73.192 Y119.985
G1 X72.417 Y119.211 E.03367
; WIPE_START
M204 S10000
G1 X73.192 Y119.985 E-.41637
G1 X73.725 Y119.985 E-.20264
G1 X73.463 Y119.723 E-.14099
; WIPE_END
G1 E-.04 F1800
G1 X73.732 Y123.835 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.95 Y123.835 E.02593
G1 X72.95 Y124.682 E.02809
G1 X73.497 Y125.228 E.02564
G1 X75.04 Y125.228 E.05119
G1 X76.433 Y123.835 E.06535
G1 X79.78 Y123.835 E.11101
G1 X81.173 Y125.228 E.06536
G1 X82.716 Y125.228 E.05119
G1 X84.109 Y123.835 E.06535
G1 X87.456 Y123.835 E.11101
G1 X88.849 Y125.228 E.06536
G1 X87.22 Y125.228 E.05401
G1 X89.234 Y126.052 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y126.052 E.60098
G1 X72.935 Y126.505 E.01668
G1 X89.065 Y126.505 E.59472
G1 X89.065 Y126.957 E.01668
G1 X72.766 Y126.957 E.60098
G1 X72.952 Y125.578 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y125.578 E.4443
G1 X89.006 Y120.997 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y120.71 E.00882
G1 X88.629 Y120.687 E.01161
G1 X88.577 Y120.6 E.00312
G1 X72.994 Y120.6 E.4788
G1 X72.994 Y123.443 E.08737
G1 X89.006 Y123.443 E.49198
G1 X89.006 Y121.057 E.07332
G1 X73.371 Y120.977 F30000
G1 F12000
G1 X88.424 Y120.977 E.46253
G1 X88.449 Y121.019 E.00149
G1 X88.629 Y121.064 E.0057
G1 X88.629 Y122.832 E.05431
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.629 Y123.066 E.0072
G1 X73.371 Y123.066 E.46881
G1 X73.371 Y122.832 E.0072
; Slow Down End
G1 F12000
G1 X73.371 Y121.037 E.05515
G1 X88.252 Y121.354 F30000
G1 F12000
G1 X73.748 Y121.354 E.44564
G1 X73.748 Y122.689 E.04102
G1 X88.252 Y122.689 E.44564
G1 X88.252 Y121.414 E.03918
G1 X87.824 Y121.782 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X74.176 Y121.782 E.53272
G1 X74.176 Y122.261 E.0187
G1 X87.824 Y122.261 E.53272
G1 X87.824 Y121.842 E.01636
; WIPE_START
G1 X87.824 Y122.261 E-.15924
G1 X86.243 Y122.261 E-.60076
; WIPE_END
G1 E-.04 F1800
G1 X93.825 Y121.388 Z3.8 F30000
G1 X116.748 Y118.747 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X117.583 Y119.582 E.03627
G1 X117.563 Y120.095
G1 X116.215 Y118.747 E.05858
G1 X115.681 Y118.747
G1 X116.919 Y119.985 E.05379
G1 X116.386 Y119.985
G1 X115.148 Y118.747 E.05379
G1 X114.615 Y118.747
G1 X115.853 Y119.985 E.05379
G1 X115.32 Y119.985
G1 X114.082 Y118.747 E.05379
G1 X113.548 Y118.747
G1 X114.786 Y119.985 E.05379
G1 X114.253 Y119.985
G1 X113.015 Y118.747 E.05379
G1 X112.482 Y118.747
G1 X113.72 Y119.985 E.05379
G1 X113.186 Y119.985
G1 X111.949 Y118.747 E.05379
G1 X111.415 Y118.747
G1 X112.653 Y119.985 E.05379
G1 X112.12 Y119.985
G1 X110.882 Y118.747 E.05379
G1 X110.417 Y118.816
G1 X111.587 Y119.985 E.05081
G1 X111.053 Y119.985
M73 P70 R8
G1 X110.417 Y119.349 E.02764
M204 S10000
G1 X117.269 Y120.114 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.108159
G1 F15000
G1 X117.029 Y119.875 E.0018
; WIPE_START
G1 X117.269 Y120.114 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X117.006 Y122.643 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y120.71 E.0594
G1 X116.629 Y120.687 E.01161
G1 X116.577 Y120.6 E.00312
G1 X111.423 Y120.6 E.15836
G1 X111.371 Y120.687 E.00312
G1 X110.994 Y120.71 E.01161
G1 X110.994 Y122.643 E.0594
G1 X116.946 Y122.643 E.18288
G1 X111.371 Y121.064 F30000
G1 F12000
G1 X111.551 Y121.019 E.0057
G1 X111.576 Y120.977 E.00149
G1 X116.424 Y120.977 E.14897
G1 X116.449 Y121.019 E.00149
G1 X116.629 Y121.064 E.0057
G1 X116.629 Y122.032 E.02973
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X116.629 Y122.266 E.0072
G1 X111.371 Y122.266 E.16155
G1 X111.371 Y122.032 E.0072
; Slow Down End
G1 F12000
G1 X111.371 Y121.124 E.02789
G1 X111.788 Y121.394 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X111.788 Y121.85 E.01695
G1 X116.212 Y121.85 E.16444
G1 X116.212 Y121.394 E.01695
G1 X111.848 Y121.394 E.16221
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X113.848 Y121.394 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 18/32
; update layer progress
M73 L18
M991 S0 P17 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.8 I.009 J1.217 P1  F30000
G1 X166.602 Y121.008 Z3.8
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.398 Y121.008 E.55715
G1 X183.398 Y126.548 E.18376
G1 X183.398 Y126.948 E.01327
G1 F14331.075
G1 X183.398 Y127.348 E.01327
G1 F6685.538
G1 X183.398 Y127.748 E.01327
G1 F1920
G1 X183.398 Y128.128 E.01262
G1 F600
G1 X166.602 Y128.128 E.55715
G1 F1920
G1 X166.602 Y127.748 E.01262
G1 F6685.538
G1 X166.602 Y127.348 E.01327
G1 F14331.075
G1 X166.602 Y126.948 E.01327
G1 F15476.087
G1 X166.602 Y126.548 E.01327
G1 X166.602 Y121.068 E.18177
; WIPE_START
G1 X168.602 Y121.061 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X166.21 Y119.34 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X183.79 Y119.34 E.54018
G1 X183.79 Y126.961 E.23417
G1 X183.79 Y127.361 E.01229
G1 F6459.938
G1 X183.79 Y127.761 E.01229
G1 F1800
G1 X183.79 Y128.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y128.52 E.01294
G1 F600
G1 X166.21 Y128.52 E.58316
G1 X166.21 Y128.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y127.761 E.01134
G1 F6459.938
G1 X166.21 Y127.361 E.01229
G1 F12000
G1 X166.21 Y126.961 E.01229
G1 X166.21 Y119.4 E.23233
; WIPE_START
M204 S10000
G1 X168.21 Y119.393 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X166.952 Y126.378 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y126.378 E.4443
G1 X183.234 Y126.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y126.852 E.60098
G1 X166.935 Y127.305 E.01668
G1 X183.065 Y127.305 E.59472
G1 X183.065 Y127.757 E.01668
G1 X166.766 Y127.757 E.60098
G1 X181.468 Y124.635 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.05 Y124.635 E.05247
G1 X183.05 Y124.682 E.00155
G1 X181.703 Y126.028 E.06317
G1 X181.76 Y126.028 E.00189
G1 X180.367 Y124.635 E.06536
G1 X175.42 Y124.635 E.16409
G1 X174.027 Y126.028 E.06536
G1 X174.084 Y126.028 E.00189
G1 X172.691 Y124.635 E.06536
G1 X167.744 Y124.635 E.16409
G1 X166.95 Y125.429 E.03725
G1 X166.95 Y126.028 E.01987
G1 X167.98 Y126.028 E.03414
G1 X183.006 Y124.243 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y121.4 E.08737
G1 X166.994 Y121.4 E.49198
G1 X166.994 Y124.243 E.08737
G1 X182.946 Y124.243 E.49014
G1 X182.629 Y123.866 F30000
G1 F12000
G1 X182.629 Y121.777 E.0642
G1 X167.371 Y121.777 E.46881
G1 X167.371 Y123.866 E.0642
G1 X182.569 Y123.866 E.46697
G1 X182.252 Y122.822 F30000
G1 F12000
G1 X182.252 Y122.154 E.02051
G1 X167.748 Y122.154 E.44564
G1 X167.748 Y123.489 E.04102
G1 X182.252 Y123.489 E.44564
G1 X182.252 Y122.882 E.01867
G1 X181.824 Y122.822 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y122.582 E.00935
G1 X168.176 Y122.582 E.53272
G1 X168.176 Y123.061 E.0187
G1 X181.824 Y123.061 E.53272
G1 X181.824 Y122.882 E.00701
; WIPE_START
G1 X181.824 Y123.061 E-.06822
G1 X180.003 Y123.061 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y120.277 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.074 Y120.785 E.02209
G1 X182.541 Y120.785
G1 X183.583 Y119.744 E.04527
G1 X183.246 Y119.547
G1 X182.008 Y120.785 E.05379
G1 X181.474 Y120.785
G1 X182.712 Y119.547 E.05379
G1 X182.179 Y119.547
G1 X180.941 Y120.785 E.05379
G1 X180.408 Y120.785
G1 X181.646 Y119.547 E.05379
G1 X181.113 Y119.547
G1 X179.875 Y120.785 E.05379
G1 X179.341 Y120.785
G1 X180.579 Y119.547 E.05379
G1 X180.046 Y119.547
G1 X178.808 Y120.785 E.05379
G1 X178.275 Y120.785
G1 X179.513 Y119.547 E.05379
G1 X178.98 Y119.547
G1 X177.742 Y120.785 E.05379
G1 X177.208 Y120.785
G1 X178.446 Y119.547 E.05379
G1 X177.913 Y119.547
G1 X176.675 Y120.785 E.05379
G1 X176.142 Y120.785
G1 X177.38 Y119.547 E.05379
G1 X176.847 Y119.547
G1 X175.609 Y120.785 E.05379
G1 X175.075 Y120.785
G1 X176.313 Y119.547 E.05379
G1 X175.78 Y119.547
G1 X174.542 Y120.785 E.05379
G1 X174.009 Y120.785
G1 X175.247 Y119.547 E.05379
G1 X174.713 Y119.547
G1 X173.476 Y120.785 E.05379
G1 X172.942 Y120.785
G1 X174.18 Y119.547 E.05379
G1 X173.647 Y119.547
G1 X172.409 Y120.785 E.05379
G1 X171.876 Y120.785
G1 X173.114 Y119.547 E.05379
G1 X172.58 Y119.547
G1 X171.343 Y120.785 E.05379
G1 X170.809 Y120.785
G1 X172.047 Y119.547 E.05379
G1 X171.514 Y119.547
G1 X170.276 Y120.785 E.05379
G1 X169.743 Y120.785
G1 X170.981 Y119.547 E.05379
G1 X170.447 Y119.547
G1 X169.21 Y120.785 E.05379
G1 X168.676 Y120.785
G1 X169.914 Y119.547 E.05379
G1 X169.381 Y119.547
G1 X168.143 Y120.785 E.05379
G1 X167.61 Y120.785
G1 X168.848 Y119.547 E.05379
G1 X168.314 Y119.547
G1 X167.076 Y120.785 E.05379
G1 X166.543 Y120.785
G1 X167.781 Y119.547 E.05379
G1 X167.248 Y119.547
G1 X166.417 Y120.378 E.03609
; WIPE_START
M204 S10000
G1 X167.248 Y119.547 E-.4463
G1 X167.781 Y119.547 E-.20264
G1 X167.574 Y119.754 E-.11107
; WIPE_END
G1 E-.04 F1800
G1 X159.969 Y120.391 Z4 F30000
G1 X152.602 Y121.008 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X159.398 Y121.008 E.22543
G1 X159.398 Y126.548 E.18376
G1 X159.398 Y126.948 E.01327
G1 F14331.075
G1 X159.398 Y127.348 E.01327
G1 F6685.538
G1 X159.398 Y127.748 E.01327
G1 F1920
G1 X159.398 Y128.128 E.01262
G1 F600
G1 X152.602 Y128.128 E.22543
G1 F1920
G1 X152.602 Y127.748 E.01262
G1 F6685.538
G1 X152.602 Y127.348 E.01327
G1 F14331.075
G1 X152.602 Y126.948 E.01327
G1 F15476.087
G1 X152.602 Y126.548 E.01327
G1 X152.602 Y121.068 E.18177
; WIPE_START
G1 X154.602 Y121.05 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X152.21 Y119.34 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X159.79 Y119.34 E.23291
G1 X159.79 Y126.961 E.23417
G1 X159.79 Y127.361 E.01229
G1 F6459.938
G1 X159.79 Y127.761 E.01229
G1 F1800
G1 X159.79 Y128.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X159.79 Y128.52 E.01294
G1 F600
G1 X152.21 Y128.52 E.25144
G1 X152.21 Y128.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y127.761 E.01134
G1 F6459.938
G1 X152.21 Y127.361 E.01229
G1 F12000
G1 X152.21 Y126.961 E.01229
G1 X152.21 Y119.4 E.23233
; WIPE_START
M204 S10000
G1 X154.21 Y119.384 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X152.952 Y126.378 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y126.378 E.16725
G1 X159.234 Y126.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y126.852 E.23226
G1 X152.935 Y127.305 E.01668
G1 X159.065 Y127.305 E.22601
G1 X159.065 Y127.757 E.01668
G1 X152.766 Y127.757 E.23226
G1 X159.05 Y124.026 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X159.05 Y125.654 E.05401
G1 X158.675 Y126.028 E.01756
G1 X158.732 Y126.028 E.00189
G1 X156.539 Y123.835 E.10288
G1 X153.193 Y123.835 E.11101
G1 X152.95 Y124.078 E.01136
G1 X152.95 Y125.706 E.05401
G1 X159.006 Y122.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y121.4 E.03139
G1 X152.994 Y121.4 E.18472
G1 X152.994 Y123.443 E.06279
G1 X159.006 Y123.443 E.18472
G1 X159.006 Y122.482 E.02955
G1 X158.629 Y122.422 F30000
G1 F12000
G1 X158.629 Y121.777 E.01981
G1 X153.371 Y121.777 E.16155
G1 X153.371 Y123.066 E.03961
G1 X158.629 Y123.066 E.16155
G1 X158.629 Y122.482 E.01796
G1 X158.212 Y122.422 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X158.212 Y122.194 E.00848
G1 X153.788 Y122.194 E.16444
G1 X153.788 Y122.65 E.01695
G1 X158.212 Y122.65 E.16444
G1 X158.212 Y122.482 E.00625
; WIPE_START
G1 X158.212 Y122.65 E-.06386
G1 X156.38 Y122.65 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y120.28 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X159.078 Y120.785 E.02194
G1 X158.544 Y120.785
G1 X159.583 Y119.747 E.04512
G1 X159.249 Y119.547
G1 X158.011 Y120.785 E.05379
G1 X157.478 Y120.785
G1 X158.716 Y119.547 E.05379
G1 X158.182 Y119.547
G1 X156.945 Y120.785 E.05379
G1 X156.411 Y120.785
G1 X157.649 Y119.547 E.05379
G1 X157.116 Y119.547
G1 X155.878 Y120.785 E.05379
G1 X155.345 Y120.785
G1 X156.583 Y119.547 E.05379
G1 X156.049 Y119.547
G1 X154.812 Y120.785 E.05379
G1 X154.278 Y120.785
G1 X155.516 Y119.547 E.05379
G1 X154.983 Y119.547
G1 X153.745 Y120.785 E.05379
G1 X153.212 Y120.785
G1 X154.45 Y119.547 E.05379
G1 X153.916 Y119.547
G1 X152.679 Y120.785 E.05379
G1 X152.417 Y120.513
G1 X153.383 Y119.547 E.04197
G1 X152.85 Y119.547
G1 X152.417 Y119.98 E.01879
; WIPE_START
M204 S10000
G1 X152.85 Y119.547 E-.23243
G1 X153.383 Y119.547 E-.20264
G1 X152.779 Y120.152 E-.32493
; WIPE_END
G1 E-.04 F1800
G1 X145.16 Y120.612 Z4 F30000
G1 X138.602 Y121.008 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X145.398 Y121.008 E.22543
G1 X145.398 Y126.548 E.18376
G1 X145.398 Y126.948 E.01327
G1 F14331.075
G1 X145.398 Y127.348 E.01327
G1 F6685.538
G1 X145.398 Y127.748 E.01327
G1 F1920
G1 X145.398 Y128.128 E.01262
G1 F600
G1 X138.602 Y128.128 E.22543
G1 F1920
G1 X138.602 Y127.748 E.01262
G1 F6685.538
G1 X138.602 Y127.348 E.01327
G1 F14331.075
G1 X138.602 Y126.948 E.01327
G1 F15476.087
M73 P71 R8
G1 X138.602 Y126.548 E.01327
G1 X138.602 Y121.068 E.18177
; WIPE_START
G1 X140.602 Y121.05 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.21 Y119.34 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X145.79 Y119.34 E.23291
G1 X145.79 Y126.961 E.23417
G1 X145.79 Y127.361 E.01229
G1 F6459.938
G1 X145.79 Y127.761 E.01229
G1 F1800
G1 X145.79 Y128.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X145.79 Y128.52 E.01294
G1 F600
G1 X138.21 Y128.52 E.25144
G1 X138.21 Y128.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y127.761 E.01134
G1 F6459.938
G1 X138.21 Y127.361 E.01229
G1 F12000
G1 X138.21 Y126.961 E.01229
G1 X138.21 Y119.4 E.23233
; WIPE_START
M204 S10000
G1 X140.21 Y119.384 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.952 Y126.378 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y126.378 E.16725
G1 X145.234 Y126.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y126.852 E.23226
G1 X138.935 Y127.305 E.01668
G1 X145.065 Y127.305 E.22601
G1 X145.065 Y127.757 E.01668
G1 X138.766 Y127.757 E.23226
G1 X143.888 Y123.835 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X145.05 Y123.835 E.03853
G1 X145.05 Y124.302 E.01549
G1 X143.323 Y126.028 E.08098
G1 X143.38 Y126.028 E.00189
G1 X141.187 Y123.835 E.10289
G1 X139.559 Y123.835 E.05401
G1 X145.006 Y123.443 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y121.4 E.06279
G1 X138.994 Y121.4 E.18472
G1 X138.994 Y123.443 E.06279
G1 X144.946 Y123.443 E.18288
G1 X144.629 Y122.422 F30000
G1 F12000
G1 X144.629 Y121.777 E.01981
G1 X139.371 Y121.777 E.16155
G1 X139.371 Y123.066 E.03961
G1 X144.629 Y123.066 E.16155
G1 X144.629 Y122.482 E.01796
G1 X144.212 Y122.422 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X144.212 Y122.194 E.00848
G1 X139.788 Y122.194 E.16444
G1 X139.788 Y122.65 E.01695
G1 X144.212 Y122.65 E.16444
G1 X144.212 Y122.482 E.00625
; WIPE_START
G1 X144.212 Y122.65 E-.06386
G1 X142.38 Y122.65 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y120.416 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.213 Y120.785 E.01607
G1 X144.68 Y120.785
G1 X145.583 Y119.882 E.03924
G1 X145.384 Y119.547
G1 X144.146 Y120.785 E.05379
G1 X143.613 Y120.785
G1 X144.851 Y119.547 E.05379
G1 X144.318 Y119.547
G1 X143.08 Y120.785 E.05379
G1 X142.547 Y120.785
G1 X143.785 Y119.547 E.05379
G1 X143.251 Y119.547
G1 X142.013 Y120.785 E.05379
G1 X141.48 Y120.785
G1 X142.718 Y119.547 E.05379
G1 X142.185 Y119.547
G1 X140.947 Y120.785 E.05379
G1 X140.414 Y120.785
G1 X141.651 Y119.547 E.05379
G1 X141.118 Y119.547
G1 X139.88 Y120.785 E.05379
G1 X139.347 Y120.785
G1 X140.585 Y119.547 E.05379
G1 X140.052 Y119.547
G1 X138.814 Y120.785 E.05379
G1 X138.417 Y120.648
G1 X139.518 Y119.547 E.04785
G1 X138.985 Y119.547
G1 X138.417 Y120.115 E.02467
; WIPE_START
M204 S10000
G1 X138.985 Y119.547 E-.30515
G1 X139.518 Y119.547 E-.20264
G1 X139.049 Y120.017 E-.25222
; WIPE_END
G1 E-.04 F1800
G1 X131.48 Y120.997 Z4 F30000
G1 X131.398 Y121.008 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y126.548 E.18376
G1 X131.398 Y126.948 E.01327
G1 F14331.075
G1 X131.398 Y127.348 E.01327
G1 F6685.538
G1 X131.398 Y127.748 E.01327
G1 F1920
G1 X131.398 Y128.128 E.01262
G1 F600
G1 X124.602 Y128.128 E.22543
G1 F1920
G1 X124.602 Y127.748 E.01262
G1 F6685.538
G1 X124.602 Y127.348 E.01327
G1 F14331.075
G1 X124.602 Y126.948 E.01327
G1 F15476.087
G1 X124.602 Y126.548 E.01327
G1 X124.602 Y121.008 E.18376
G1 X131.338 Y121.008 E.22344
; WIPE_START
G1 X131.36 Y123.008 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.79 Y119.34 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y126.961 E.23417
G1 X131.79 Y127.361 E.01229
G1 F6459.938
G1 X131.79 Y127.761 E.01229
G1 F1800
G1 X131.79 Y128.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X131.79 Y128.52 E.01294
G1 F600
G1 X124.21 Y128.52 E.25144
G1 X124.21 Y128.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y127.761 E.01134
G1 F6459.938
G1 X124.21 Y127.361 E.01229
G1 F12000
G1 X124.21 Y126.961 E.01229
G1 X124.21 Y119.34 E.23417
G1 X131.73 Y119.34 E.23107
; WIPE_START
M204 S10000
G1 X131.746 Y121.34 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.815 Y120.785 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X131.583 Y120.018 E.03336
G1 X131.52 Y119.547
G1 X130.282 Y120.785 E.05379
G1 X129.748 Y120.785
G1 X130.986 Y119.547 E.05379
G1 X130.453 Y119.547
G1 X129.215 Y120.785 E.05379
G1 X128.682 Y120.785
G1 X129.92 Y119.547 E.05379
G1 X129.387 Y119.547
G1 X128.149 Y120.785 E.05379
G1 X127.615 Y120.785
G1 X128.853 Y119.547 E.05379
G1 X128.32 Y119.547
G1 X127.082 Y120.785 E.05379
G1 X126.549 Y120.785
G1 X127.787 Y119.547 E.05379
G1 X127.254 Y119.547
G1 X126.016 Y120.785 E.05379
G1 X125.482 Y120.785
G1 X126.72 Y119.547 E.05379
G1 X126.187 Y119.547
G1 X124.949 Y120.785 E.05379
G1 X124.417 Y120.784
G1 X125.654 Y119.547 E.05373
G1 X125.121 Y119.547
G1 X124.417 Y120.251 E.03055
; WIPE_START
M204 S10000
G1 X125.121 Y119.547 E-.37786
G1 X125.654 Y119.547 E-.20264
G1 X125.32 Y119.881 E-.1795
; WIPE_END
G1 E-.04 F1800
G1 X124.952 Y126.378 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y126.378 E.16725
G1 X131.234 Y126.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y126.852 E.23226
G1 X124.935 Y127.305 E.01668
G1 X131.065 Y127.305 E.22601
G1 X131.065 Y127.757 E.01668
G1 X124.766 Y127.757 E.23226
G1 X131.05 Y124.579 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.05 Y123.835 E.02466
G1 X130.165 Y123.835 E.02936
G1 X127.972 Y126.028 E.10288
G1 X128.028 Y126.028 E.00189
G1 X125.835 Y123.835 E.10288
G1 X124.95 Y123.835 E.02936
G1 X124.95 Y124.579 E.02466
G1 X131.006 Y123.443 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y121.4 E.06279
G1 X124.994 Y121.4 E.18472
G1 X124.994 Y123.443 E.06279
G1 X130.946 Y123.443 E.18288
G1 X130.629 Y122.422 F30000
G1 F12000
G1 X130.629 Y121.777 E.01981
G1 X125.371 Y121.777 E.16155
G1 X125.371 Y123.066 E.03961
G1 X130.629 Y123.066 E.16155
G1 X130.629 Y122.482 E.01796
G1 X130.212 Y122.422 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X130.212 Y122.194 E.00848
G1 X125.788 Y122.194 E.16444
G1 X125.788 Y122.65 E.01695
G1 X130.212 Y122.65 E.16444
G1 X130.212 Y122.482 E.00625
; WIPE_START
G1 X130.212 Y122.65 E-.06386
G1 X128.38 Y122.65 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X120.832 Y121.521 Z4 F30000
G1 X117.398 Y121.008 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X117.398 Y126.548 E.18376
G1 X117.398 Y126.948 E.01327
G1 F14331.075
G1 X117.398 Y127.348 E.01327
G1 F6685.538
G1 X117.398 Y127.748 E.01327
G1 F1920
G1 X117.398 Y128.128 E.01262
G1 F600
G1 X110.602 Y128.128 E.22543
G1 F1920
G1 X110.602 Y127.748 E.01262
G1 F6685.538
G1 X110.602 Y127.348 E.01327
G1 F14331.075
G1 X110.602 Y126.948 E.01327
G1 F15476.087
G1 X110.602 Y126.548 E.01327
G1 X110.602 Y121.008 E.18376
G1 X117.338 Y121.008 E.22344
; WIPE_START
G1 X117.36 Y123.008 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X117.79 Y119.34 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X117.79 Y126.961 E.23417
G1 X117.79 Y127.361 E.01229
G1 F6459.938
G1 X117.79 Y127.761 E.01229
G1 F1800
G1 X117.79 Y128.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X117.79 Y128.52 E.01294
G1 F600
G1 X110.21 Y128.52 E.25144
G1 X110.21 Y128.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y127.761 E.01134
G1 F6459.938
G1 X110.21 Y127.361 E.01229
G1 F12000
G1 X110.21 Y126.961 E.01229
G1 X110.21 Y119.34 E.23417
G1 X117.73 Y119.34 E.23107
M204 S10000
G1 X117.583 Y120.153 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X116.95 Y120.785 E.02748
G1 X116.417 Y120.785
G1 X117.583 Y119.62 E.05065
G1 X117.122 Y119.547
G1 X115.884 Y120.785 E.05379
G1 X115.35 Y120.785
G1 X116.588 Y119.547 E.05379
G1 X116.055 Y119.547
G1 X114.817 Y120.785 E.05379
G1 X114.284 Y120.785
G1 X115.522 Y119.547 E.05379
G1 X114.989 Y119.547
G1 X113.751 Y120.785 E.05379
G1 X113.217 Y120.785
G1 X114.455 Y119.547 E.05379
G1 X113.922 Y119.547
G1 X112.684 Y120.785 E.05379
G1 X112.151 Y120.785
G1 X113.389 Y119.547 E.05379
G1 X112.856 Y119.547
G1 X111.618 Y120.785 E.05379
G1 X111.084 Y120.785
G1 X112.322 Y119.547 E.05379
G1 X111.789 Y119.547
G1 X110.551 Y120.785 E.05379
G1 X110.417 Y120.386
G1 X111.256 Y119.547 E.03643
; WIPE_START
M204 S10000
G1 X110.417 Y120.386 E-.45057
G1 X110.551 Y120.785 E-.16009
G1 X110.829 Y120.507 E-.14934
; WIPE_END
G1 E-.04 F1800
G1 X117.006 Y122.422 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y121.4 E.03139
G1 X110.994 Y121.4 E.18472
G1 X110.994 Y123.443 E.06279
G1 X117.006 Y123.443 E.18472
G1 X117.006 Y122.482 E.02955
G1 X116.629 Y123.066 F30000
G1 F12000
G1 X116.629 Y121.777 E.03961
G1 X111.371 Y121.777 E.16155
G1 X111.371 Y123.066 E.03961
G1 X116.569 Y123.066 E.1597
G1 X116.212 Y122.65 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X116.212 Y122.194 E.01695
G1 X111.788 Y122.194 E.16444
G1 X111.788 Y122.65 E.01695
G1 X116.152 Y122.65 E.16221
G1 X116.441 Y123.835 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X114.813 Y123.835 E.05401
G1 X112.62 Y126.028 E.10288
G1 X112.677 Y126.028 E.00189
G1 X110.95 Y124.302 E.08098
G1 X110.95 Y123.835 E.01549
G1 X112.112 Y123.835 E.03853
G1 X110.952 Y126.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y126.378 E.16725
G1 X117.234 Y126.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y126.852 E.23226
G1 X110.935 Y127.305 E.01668
G1 X117.065 Y127.305 E.22601
G1 X117.065 Y127.757 E.01668
G1 X110.766 Y127.757 E.23226
; WIPE_START
G1 X112.766 Y127.757 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.711 J-.987 P1  F30000
G1 X103.398 Y121.008 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.398 Y126.548 E.18376
G1 X103.398 Y126.948 E.01327
G1 F14331.075
G1 X103.398 Y127.348 E.01327
G1 F6685.538
G1 X103.398 Y127.748 E.01327
G1 F1920
G1 X103.398 Y128.128 E.01262
G1 F600
G1 X96.602 Y128.128 E.22543
G1 F1920
G1 X96.602 Y127.748 E.01262
G1 F6685.538
G1 X96.602 Y127.348 E.01327
G1 F14331.075
G1 X96.602 Y126.948 E.01327
G1 F15476.087
G1 X96.602 Y126.548 E.01327
G1 X96.602 Y121.008 E.18376
G1 X103.338 Y121.008 E.22344
; WIPE_START
G1 X103.36 Y123.008 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.79 Y119.34 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X103.79 Y126.961 E.23417
G1 X103.79 Y127.361 E.01229
G1 F6459.938
G1 X103.79 Y127.761 E.01229
G1 F1800
M73 P71 R7
G1 X103.79 Y128.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X103.79 Y128.52 E.01294
G1 F600
G1 X96.21 Y128.52 E.25144
G1 X96.21 Y128.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y127.761 E.01134
G1 F6459.938
G1 X96.21 Y127.361 E.01229
G1 F12000
G1 X96.21 Y126.961 E.01229
G1 X96.21 Y119.34 E.23417
G1 X103.73 Y119.34 E.23107
M204 S10000
G1 X103.583 Y120.288 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X103.086 Y120.785 E.0216
G1 X102.552 Y120.785
G1 X103.583 Y119.755 E.04477
G1 X103.257 Y119.547
G1 X102.019 Y120.785 E.05379
G1 X101.486 Y120.785
G1 X102.724 Y119.547 E.05379
G1 X102.19 Y119.547
G1 X100.953 Y120.785 E.05379
G1 X100.419 Y120.785
G1 X101.657 Y119.547 E.05379
G1 X101.124 Y119.547
G1 X99.886 Y120.785 E.05379
G1 X99.353 Y120.785
G1 X100.591 Y119.547 E.05379
G1 X100.057 Y119.547
G1 X98.82 Y120.785 E.05379
G1 X98.286 Y120.785
G1 X99.524 Y119.547 E.05379
G1 X98.991 Y119.547
G1 X97.753 Y120.785 E.05379
G1 X97.22 Y120.785
G1 X98.458 Y119.547 E.05379
G1 X97.924 Y119.547
G1 X96.686 Y120.785 E.05379
G1 X96.417 Y120.521
G1 X97.391 Y119.547 E.04231
G1 X96.858 Y119.547
G1 X96.417 Y119.988 E.01914
; WIPE_START
M204 S10000
G1 X96.858 Y119.547 E-.23671
G1 X97.391 Y119.547 E-.20264
G1 X96.794 Y120.144 E-.32065
; WIPE_END
G1 E-.04 F1800
G1 X96.952 Y126.378 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y126.378 E.16725
G1 X103.234 Y126.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y126.852 E.23226
G1 X96.935 Y127.305 E.01668
G1 X103.065 Y127.305 E.22601
G1 X103.065 Y127.757 E.01668
G1 X96.766 Y127.757 E.23226
G1 X103.05 Y125.706 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.05 Y124.078 E.05401
G1 X102.807 Y123.835 E.01136
G1 X99.461 Y123.835 E.11101
G1 X97.268 Y126.028 E.10288
G1 X97.325 Y126.028 E.00189
G1 X96.95 Y125.654 E.01756
G1 X96.95 Y124.026 E.05401
G1 X103.006 Y122.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y121.4 E.03139
G1 X96.994 Y121.4 E.18472
G1 X96.994 Y123.443 E.06279
G1 X103.006 Y123.443 E.18472
G1 X103.006 Y122.482 E.02955
G1 X102.629 Y122.422 F30000
G1 F12000
G1 X102.629 Y121.777 E.01981
G1 X97.371 Y121.777 E.16155
G1 X97.371 Y123.066 E.03961
G1 X102.629 Y123.066 E.16155
G1 X102.629 Y122.482 E.01796
G1 X102.212 Y122.422 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X102.212 Y122.194 E.00848
G1 X97.788 Y122.194 E.16444
G1 X97.788 Y122.65 E.01695
G1 X102.212 Y122.65 E.16444
M73 P72 R7
G1 X102.212 Y122.482 E.00625
; WIPE_START
G1 X102.212 Y122.65 E-.06386
G1 X100.38 Y122.65 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X92.832 Y121.521 Z4 F30000
G1 X89.398 Y121.008 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.398 Y126.548 E.18376
G1 X89.398 Y126.948 E.01327
G1 F14331.075
G1 X89.398 Y127.348 E.01327
G1 F6685.538
G1 X89.398 Y127.748 E.01327
G1 F1920
G1 X89.398 Y128.128 E.01262
G1 F600
G1 X72.602 Y128.128 E.55715
G1 F1920
G1 X72.602 Y127.748 E.01262
G1 F6685.538
G1 X72.602 Y127.348 E.01327
G1 F14331.075
G1 X72.602 Y126.948 E.01327
G1 F15476.087
G1 X72.602 Y126.548 E.01327
G1 X72.602 Y121.008 E.18376
G1 X89.338 Y121.008 E.55516
; WIPE_START
G1 X89.36 Y123.008 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.79 Y119.34 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X89.79 Y126.961 E.23417
G1 X89.79 Y127.361 E.01229
G1 F6459.938
G1 X89.79 Y127.761 E.01229
G1 F1800
G1 X89.79 Y128.13 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X89.79 Y128.52 E.01294
G1 F600
G1 X72.21 Y128.52 E.58316
G1 X72.21 Y128.13 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y127.761 E.01134
G1 F6459.938
G1 X72.21 Y127.361 E.01229
G1 F12000
G1 X72.21 Y126.961 E.01229
G1 X72.21 Y119.34 E.23417
G1 X89.73 Y119.34 E.53834
; WIPE_START
M204 S10000
G1 X89.746 Y121.34 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.221 Y120.785 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X89.583 Y120.424 E.01572
G1 X89.583 Y119.89
G1 X88.688 Y120.785 E.03889
G1 X88.154 Y120.785
G1 X89.392 Y119.547 E.05379
G1 X88.859 Y119.547
G1 X87.621 Y120.785 E.05379
G1 X87.088 Y120.785
G1 X88.326 Y119.547 E.05379
G1 X87.792 Y119.547
G1 X86.555 Y120.785 E.05379
G1 X86.021 Y120.785
G1 X87.259 Y119.547 E.05379
G1 X86.726 Y119.547
G1 X85.488 Y120.785 E.05379
G1 X84.955 Y120.785
G1 X86.193 Y119.547 E.05379
G1 X85.659 Y119.547
G1 X84.422 Y120.785 E.05379
G1 X83.888 Y120.785
G1 X85.126 Y119.547 E.05379
G1 X84.593 Y119.547
G1 X83.355 Y120.785 E.05379
G1 X82.822 Y120.785
G1 X84.06 Y119.547 E.05379
G1 X83.526 Y119.547
G1 X82.289 Y120.785 E.05379
G1 X81.755 Y120.785
G1 X82.993 Y119.547 E.05379
G1 X82.46 Y119.547
G1 X81.222 Y120.785 E.05379
G1 X80.689 Y120.785
G1 X81.927 Y119.547 E.05379
G1 X81.393 Y119.547
G1 X80.155 Y120.785 E.05379
G1 X79.622 Y120.785
G1 X80.86 Y119.547 E.05379
G1 X80.327 Y119.547
G1 X79.089 Y120.785 E.05379
G1 X78.556 Y120.785
G1 X79.794 Y119.547 E.05379
G1 X79.26 Y119.547
G1 X78.022 Y120.785 E.05379
G1 X77.489 Y120.785
G1 X78.727 Y119.547 E.05379
G1 X78.194 Y119.547
G1 X76.956 Y120.785 E.05379
G1 X76.423 Y120.785
G1 X77.661 Y119.547 E.05379
G1 X77.127 Y119.547
G1 X75.889 Y120.785 E.05379
G1 X75.356 Y120.785
G1 X76.594 Y119.547 E.05379
G1 X76.061 Y119.547
G1 X74.823 Y120.785 E.05379
G1 X74.29 Y120.785
G1 X75.528 Y119.547 E.05379
G1 X74.994 Y119.547
G1 X73.756 Y120.785 E.05379
G1 X73.223 Y120.785
G1 X74.461 Y119.547 E.05379
G1 X73.928 Y119.547
G1 X72.69 Y120.785 E.05379
G1 X72.417 Y120.525
G1 X73.395 Y119.547 E.04246
G1 X72.861 Y119.547
G1 X72.417 Y119.991 E.01929
; WIPE_START
M204 S10000
G1 X72.861 Y119.547 E-.23854
G1 X73.395 Y119.547 E-.20264
G1 X72.801 Y120.141 E-.31882
; WIPE_END
G1 E-.04 F1800
G1 X80.433 Y120.015 Z4 F30000
G1 X89.557 Y119.865 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.131751
G1 F15000
G1 X89.557 Y119.529 E.00243
; WIPE_START
G1 X89.557 Y119.865 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.006 Y122.822 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y121.4 E.04368
G1 X72.994 Y121.4 E.49198
G1 X72.994 Y124.243 E.08737
G1 X89.006 Y124.243 E.49198
G1 X89.006 Y122.882 E.04184
G1 X88.629 Y122.822 F30000
G1 F12000
G1 X88.629 Y121.777 E.0321
G1 X73.371 Y121.777 E.46881
G1 X73.371 Y123.866 E.0642
G1 X88.629 Y123.866 E.46881
G1 X88.629 Y122.882 E.03025
G1 X88.252 Y122.822 F30000
G1 F12000
G1 X88.252 Y122.154 E.02051
G1 X73.748 Y122.154 E.44564
G1 X73.748 Y123.489 E.04102
G1 X88.252 Y123.489 E.44564
G1 X88.252 Y122.882 E.01867
G1 X87.824 Y122.822 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X87.824 Y122.582 E.00935
G1 X74.176 Y122.582 E.53272
G1 X74.176 Y123.061 E.0187
G1 X87.824 Y123.061 E.53272
G1 X87.824 Y122.882 E.00701
G1 X88.02 Y126.028 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.05 Y126.028 E.03414
G1 X89.05 Y125.429 E.01987
G1 X88.256 Y124.635 E.03725
G1 X83.309 Y124.635 E.16409
G1 X81.916 Y126.028 E.06536
G1 X81.973 Y126.028 E.00189
G1 X80.58 Y124.635 E.06536
G1 X75.633 Y124.635 E.16409
G1 X74.24 Y126.028 E.06536
G1 X74.297 Y126.028 E.00189
G1 X72.95 Y124.682 E.06316
G1 X72.95 Y124.635 E.00155
G1 X74.532 Y124.635 E.05247
G1 X72.952 Y126.378 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y126.378 E.4443
G1 X89.234 Y126.852 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y126.852 E.60098
G1 X72.935 Y127.305 E.01668
G1 X89.065 Y127.305 E.59472
G1 X89.065 Y127.757 E.01668
G1 X72.766 Y127.757 E.60098
; WIPE_START
G1 X74.766 Y127.757 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I-.111 J1.212 P1  F30000
G1 X138.602 Y133.602 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y133.022 E.01923
G1 F14852.35
G1 X138.602 Y132.963 E.00199
G1 F13500
G1 X145.398 Y132.963 E.22543
G1 F14852.35
G1 X145.398 Y133.022 E.00199
G1 F15476.087
G1 X145.398 Y133.602 E.01923
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y133.022 E.01923
G1 F14852.35
G1 X152.602 Y132.963 E.00199
G1 F13500
G1 X159.398 Y132.963 E.22543
G1 F14852.35
G1 X159.398 Y133.022 E.00199
G1 F15476.087
G1 X159.398 Y133.602 E.01923
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y133.022 E.01923
G1 F14852.35
G1 X166.602 Y132.963 E.00199
G1 F13500
G1 X183.398 Y132.963 E.55715
G1 F14852.35
G1 X183.398 Y133.022 E.00199
G1 F15476.087
G1 X183.398 Y133.422 E.01327
G1 X183.398 Y137.271 E.12767
G1 X72.602 Y137.271 E3.6753
G1 X72.602 Y133.422 E.12767
G1 X72.602 Y133.022 E.01327
G1 F14852.35
G1 X72.602 Y132.963 E.00199
G1 F13500
G1 X89.398 Y132.963 E.55715
G1 F14852.35
G1 X89.398 Y133.022 E.00199
G1 F15476.087
G1 X89.398 Y133.602 E.01923
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y133.022 E.01923
G1 F14852.35
G1 X96.602 Y132.963 E.00199
G1 F13500
G1 X103.398 Y132.963 E.22543
G1 F14852.35
G1 X103.398 Y133.022 E.00199
G1 F15476.087
G1 X103.398 Y133.602 E.01923
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y133.022 E.01923
G1 F14852.35
G1 X110.602 Y132.963 E.00199
G1 F13500
G1 X117.398 Y132.963 E.22543
G1 F14852.35
G1 X117.398 Y133.022 E.00199
G1 F15476.087
G1 X117.398 Y133.602 E.01923
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y133.022 E.01923
G1 F14852.35
G1 X124.602 Y132.963 E.00199
G1 F13500
G1 X131.398 Y132.963 E.22543
G1 F14852.35
G1 X131.398 Y133.022 E.00199
G1 F15476.087
G1 X131.398 Y133.602 E.01923
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F3783.028
M204 S5000
G1 X138.21 Y133.009 E.00618
G1 F1800
G1 X138.21 Y132.64 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X138.21 Y132.57 E.0023
G1 X145.79 Y132.57 E.25144
G1 X145.79 Y132.64 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X145.79 Y133.009 E.01134
G1 F3783.028
G1 X145.79 Y133.21 E.00618
G1 F9891.03
G1 X146.19 Y133.21 E.01229
G1 F12000
G1 X146.59 Y133.21 E.01229
G1 X151.41 Y133.21 E.1481
G1 X151.81 Y133.21 E.01229
G1 F9891.03
G1 X152.21 Y133.21 E.01229
G1 F3783.028
G1 X152.21 Y133.009 E.00618
G1 F1800
G1 X152.21 Y132.64 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X152.21 Y132.57 E.0023
G1 X159.79 Y132.57 E.25144
G1 X159.79 Y132.64 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X159.79 Y133.009 E.01134
G1 F3783.028
G1 X159.79 Y133.21 E.00618
G1 F9891.03
G1 X160.19 Y133.21 E.01229
G1 F12000
G1 X160.59 Y133.21 E.01229
G1 X165.41 Y133.21 E.1481
G1 X165.81 Y133.21 E.01229
G1 F9891.03
G1 X166.21 Y133.21 E.01229
G1 F3783.028
G1 X166.21 Y133.009 E.00618
G1 F1800
G1 X166.21 Y132.64 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X166.21 Y132.57 E.0023
G1 X183.79 Y132.57 E.58316
G1 X183.79 Y132.64 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y133.009 E.01134
G1 F6459.938
G1 X183.79 Y133.409 E.01229
G1 F12000
G1 X183.79 Y133.809 E.01229
G1 X183.79 Y137.663 E.11843
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y137.663 E3.42854
G1 X72.21 Y133.809 E.11843
G1 X72.21 Y133.409 E.01229
G1 F6459.938
G1 X72.21 Y133.009 E.01229
G1 F1800
G1 X72.21 Y132.64 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y132.57 E.0023
G1 X89.79 Y132.57 E.58316
G1 X89.79 Y132.64 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X89.79 Y133.009 E.01134
G1 F3783.028
G1 X89.79 Y133.21 E.00618
G1 F9891.03
G1 X90.19 Y133.21 E.01229
G1 F12000
G1 X90.59 Y133.21 E.01229
G1 X95.41 Y133.21 E.1481
G1 X95.81 Y133.21 E.01229
G1 F9891.03
G1 X96.21 Y133.21 E.01229
G1 F3783.028
G1 X96.21 Y133.009 E.00618
G1 F1800
G1 X96.21 Y132.64 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X96.21 Y132.57 E.0023
G1 X103.79 Y132.57 E.25144
G1 X103.79 Y132.64 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X103.79 Y133.009 E.01134
G1 F3783.028
G1 X103.79 Y133.21 E.00618
G1 F9891.03
G1 X104.19 Y133.21 E.01229
G1 F12000
G1 X104.59 Y133.21 E.01229
G1 X109.41 Y133.21 E.1481
G1 X109.81 Y133.21 E.01229
G1 F9891.03
G1 X110.21 Y133.21 E.01229
G1 F3783.028
G1 X110.21 Y133.009 E.00618
G1 F1800
G1 X110.21 Y132.64 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X110.21 Y132.57 E.0023
G1 X117.79 Y132.57 E.25144
G1 X117.79 Y132.64 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X117.79 Y133.009 E.01134
G1 F3783.028
G1 X117.79 Y133.21 E.00618
G1 F9891.03
G1 X118.19 Y133.21 E.01229
G1 F12000
G1 X118.59 Y133.21 E.01229
G1 X123.41 Y133.21 E.1481
G1 X123.81 Y133.21 E.01229
G1 F9891.03
G1 X124.21 Y133.21 E.01229
G1 F3783.028
G1 X124.21 Y133.009 E.00618
G1 F1800
G1 X124.21 Y132.64 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X124.21 Y132.57 E.0023
G1 X131.79 Y132.57 E.25144
G1 X131.79 Y132.64 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X131.79 Y133.009 E.01134
G1 F3783.028
G1 X131.79 Y133.21 E.00618
G1 F9891.03
G1 X132.19 Y133.21 E.01229
G1 F12000
G1 X132.59 Y133.21 E.01229
G1 X138.15 Y133.21 E.17084
; WIPE_START
M204 S10000
G1 X138.21 Y133.009 E-.07975
G1 X138.21 Y132.64 E-.14022
G1 X138.21 Y132.57 E-.02639
G1 X139.562 Y132.57 E-.51363
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I-.102 J1.213 P1  F30000
G1 X183.006 Y136.219 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
M73 P73 R7
G1 F12000
G1 X183.006 Y135.559 E.02029
G1 X72.994 Y135.559 E3.38027
G1 X72.994 Y136.879 E.04058
G1 X183.006 Y136.879 E3.38027
G1 X183.006 Y136.279 E.01844
G1 X182.581 Y136.219 F30000
; LINE_WIDTH: 0.51467
G1 F12000
G1 X182.581 Y135.983 E.00907
G1 X73.419 Y135.983 E4.1964
G1 X73.419 Y136.455 E.01814
G1 X182.581 Y136.455 E4.1964
G1 X182.581 Y136.279 E.00676
G1 X89.194 Y133.976 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X96.775 Y133.976 E.21003
G1 X89.194 Y133.976 F30000
; LINE_WIDTH: 0.406615
G1 F15000
G1 X89.114 Y133.919 E.00291
; LINE_WIDTH: 0.454005
G1 X89.034 Y133.862 E.00329
; LINE_WIDTH: 0.501395
G1 F13741.208
G1 X88.953 Y133.806 E.00367
; LINE_WIDTH: 0.532565
G1 F12866.483
G1 X88.95 Y133.411 E.01575
G1 X73.05 Y133.411 E.63437
G1 X73.05 Y133.901 E.01954
G1 X88.705 Y133.901 E.6246
; LINE_WIDTH: 0.507662
G1 F13555.917
G1 X88.848 Y133.923 E.0055
; LINE_WIDTH: 0.457765
G1 F15000
G1 X88.992 Y133.944 E.00491
; LINE_WIDTH: 0.407869
G1 X89.135 Y133.966 E.00432
G1 X103.194 Y133.976 F30000
; LINE_WIDTH: 0.406617
G1 F15000
G1 X103.114 Y133.919 E.00291
; LINE_WIDTH: 0.45401
G1 X103.034 Y133.862 E.00329
; LINE_WIDTH: 0.501404
G1 F13740.958
G1 X102.953 Y133.806 E.00367
; LINE_WIDTH: 0.531889
G1 F12884.269
G1 X102.95 Y133.411 E.01573
G1 X97.05 Y133.411 E.23505
G1 X97.042 Y133.806 E.01573
; LINE_WIDTH: 0.493679
G1 F13976.447
G1 X96.973 Y133.862 E.00327
; LINE_WIDTH: 0.450335
G1 F15000
G1 X96.904 Y133.918 E.00295
; LINE_WIDTH: 0.406992
G1 X96.835 Y133.974 E.00264
; LINE_WIDTH: 0.40987
G1 X96.989 Y133.95 E.00464
; LINE_WIDTH: 0.45897
G1 X97.142 Y133.925 E.00527
; LINE_WIDTH: 0.531935
G1 F12883.048
G1 X97.295 Y133.901 E.00619
G1 X102.705 Y133.901 E.21556
; LINE_WIDTH: 0.50767
G1 F13555.676
G1 X102.848 Y133.923 E.0055
; LINE_WIDTH: 0.45777
G1 F15000
G1 X102.992 Y133.944 E.00491
; LINE_WIDTH: 0.40787
G1 X103.135 Y133.966 E.00432
G1 X103.194 Y133.976 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X110.775 Y133.976 E.21003
G1 X116.95 Y133.411 F30000
; LINE_WIDTH: 0.532079
G1 F12879.265
G1 X111.05 Y133.411 E.23514
G1 X111.042 Y133.806 E.01574
; LINE_WIDTH: 0.493679
G1 F13976.447
G1 X110.973 Y133.862 E.00327
; LINE_WIDTH: 0.450335
G1 F15000
G1 X110.904 Y133.918 E.00295
; LINE_WIDTH: 0.406992
G1 X110.835 Y133.974 E.00264
; LINE_WIDTH: 0.40987
G1 X110.989 Y133.95 E.00464
; LINE_WIDTH: 0.45897
G1 X111.142 Y133.925 E.00527
; LINE_WIDTH: 0.531935
G1 F12883.048
G1 X111.295 Y133.901 E.00619
G1 X116.705 Y133.901 E.21556
; LINE_WIDTH: 0.50767
G1 F13555.676
G1 X116.868 Y133.926 E.00625
; LINE_WIDTH: 0.45777
G1 F15000
G1 X117.031 Y133.951 E.00558
; LINE_WIDTH: 0.40787
G1 X117.194 Y133.976 E.00491
; LINE_WIDTH: 0.406617
G1 X117.114 Y133.919 E.00291
; LINE_WIDTH: 0.45401
G1 X117.034 Y133.862 E.00329
; LINE_WIDTH: 0.501404
G1 F13740.958
G1 X116.953 Y133.806 E.00367
; LINE_WIDTH: 0.52886
G1 F12964.564
G1 X116.95 Y133.471 E.01326
G1 X117.194 Y133.976 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.775 Y133.976 E.21003
G1 X125.05 Y133.411 F30000
; LINE_WIDTH: 0.523985
G1 F13095.945
G1 X125.042 Y133.806 E.01548
; LINE_WIDTH: 0.493679
G1 F13976.447
G1 X124.973 Y133.862 E.00327
; LINE_WIDTH: 0.450335
G1 F15000
G1 X124.904 Y133.918 E.00295
; LINE_WIDTH: 0.406992
G1 X124.835 Y133.974 E.00264
; LINE_WIDTH: 0.40987
G1 X124.989 Y133.95 E.00464
; LINE_WIDTH: 0.45897
G1 X125.142 Y133.925 E.00527
; LINE_WIDTH: 0.53193
G1 F12883.174
G1 X125.295 Y133.901 E.00619
G1 X130.705 Y133.901 E.21556
; LINE_WIDTH: 0.507662
G1 F13555.917
G1 X130.868 Y133.926 E.00625
; LINE_WIDTH: 0.457765
G1 F15000
G1 X131.031 Y133.951 E.00558
; LINE_WIDTH: 0.407869
G1 X131.194 Y133.976 E.00491
; LINE_WIDTH: 0.406615
G1 X131.114 Y133.919 E.00291
; LINE_WIDTH: 0.454005
G1 X131.034 Y133.862 E.00329
; LINE_WIDTH: 0.501395
G1 F13741.208
G1 X130.953 Y133.806 E.00367
; LINE_WIDTH: 0.532377
G1 F12871.418
G1 X130.95 Y133.411 E.01574
G1 X125.11 Y133.411 E.23289
G1 X131.194 Y133.976 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X138.775 Y133.976 E.21003
G1 X139.05 Y133.411 F30000
; LINE_WIDTH: 0.523985
G1 F13095.945
G1 X139.042 Y133.806 E.01548
; LINE_WIDTH: 0.493679
G1 F13976.447
G1 X138.973 Y133.862 E.00327
; LINE_WIDTH: 0.450335
G1 F15000
G1 X138.904 Y133.918 E.00295
; LINE_WIDTH: 0.406992
G1 X138.835 Y133.974 E.00264
; LINE_WIDTH: 0.40987
G1 X138.989 Y133.95 E.00464
; LINE_WIDTH: 0.45897
G1 X139.142 Y133.925 E.00527
; LINE_WIDTH: 0.531935
G1 F12883.048
G1 X139.295 Y133.901 E.00619
G1 X144.705 Y133.901 E.21556
; LINE_WIDTH: 0.50767
G1 F13555.676
G1 X144.868 Y133.926 E.00625
; LINE_WIDTH: 0.45777
G1 F15000
G1 X145.031 Y133.951 E.00558
; LINE_WIDTH: 0.40787
G1 X145.194 Y133.976 E.00491
; LINE_WIDTH: 0.406617
G1 X145.114 Y133.919 E.00291
; LINE_WIDTH: 0.45401
G1 X145.034 Y133.862 E.00329
; LINE_WIDTH: 0.501404
G1 F13740.958
G1 X144.953 Y133.806 E.00367
; LINE_WIDTH: 0.532382
G1 F12871.277
G1 X144.95 Y133.411 E.01574
G1 X139.11 Y133.411 E.23289
G1 X145.194 Y133.976 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X152.775 Y133.976 E.21003
G1 X152.835 Y133.974 F30000
; LINE_WIDTH: 0.40987
G1 F15000
G1 X152.989 Y133.95 E.00464
; LINE_WIDTH: 0.45897
G1 X153.142 Y133.925 E.00527
; LINE_WIDTH: 0.53193
G1 F12883.176
G1 X153.295 Y133.901 E.00619
G1 X158.705 Y133.901 E.21556
; LINE_WIDTH: 0.507662
G1 F13555.917
G1 X158.868 Y133.926 E.00625
; LINE_WIDTH: 0.457765
G1 F15000
G1 X159.031 Y133.951 E.00558
; LINE_WIDTH: 0.407869
G1 X159.194 Y133.976 E.00491
; LINE_WIDTH: 0.406615
G1 X159.114 Y133.919 E.00291
; LINE_WIDTH: 0.454005
G1 X159.034 Y133.862 E.00329
; LINE_WIDTH: 0.501395
G1 F13741.208
G1 X158.953 Y133.806 E.00367
; LINE_WIDTH: 0.531884
G1 F12884.399
G1 X158.95 Y133.411 E.01573
G1 X153.05 Y133.411 E.23505
G1 X153.042 Y133.806 E.01573
; LINE_WIDTH: 0.493679
G1 F13976.447
G1 X152.988 Y133.849 E.00253
; LINE_WIDTH: 0.450335
G1 F15000
G1 X152.935 Y133.893 E.00229
; LINE_WIDTH: 0.406992
G1 X152.882 Y133.936 E.00204
G1 X159.194 Y133.976 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X166.775 Y133.976 E.21003
G1 X166.835 Y133.974 F30000
; LINE_WIDTH: 0.409869
G1 F15000
G1 X166.989 Y133.95 E.00464
; LINE_WIDTH: 0.458965
G1 X167.142 Y133.925 E.00527
; LINE_WIDTH: 0.532389
G1 F12871.107
G1 X167.295 Y133.901 E.0062
G1 X182.95 Y133.901 E.62438
G1 X182.95 Y133.411 E.01953
G1 X167.05 Y133.411 E.63414
G1 X167.042 Y133.806 E.01575
; LINE_WIDTH: 0.49367
G1 F13976.706
G1 X166.988 Y133.849 E.00253
; LINE_WIDTH: 0.45033
G1 F15000
G1 X166.935 Y133.893 E.00229
; LINE_WIDTH: 0.40699
G1 X166.882 Y133.936 E.00204
G1 X74.406 Y135.166 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.95 Y135.166 E.04829
G1 X72.95 Y134.994 E.00572
G1 X73.595 Y134.349 E.03026
G1 X74.941 Y134.349 E.04465
G1 X75.759 Y135.166 E.03835
G1 X80.454 Y135.166 E.15574
G1 X81.271 Y134.349 E.03835
G1 X82.617 Y134.349 E.04465
G1 X83.435 Y135.166 E.03835
G1 X88.13 Y135.166 E.15574
G1 X88.947 Y134.349 E.03835
G1 X90.293 Y134.349 E.04465
G1 X91.111 Y135.166 E.03835
G1 X95.806 Y135.166 E.15574
G1 X96.623 Y134.349 E.03835
G1 X97.969 Y134.349 E.04465
G1 X98.787 Y135.166 E.03835
G1 X103.482 Y135.166 E.15574
G1 X104.299 Y134.349 E.03835
G1 X105.645 Y134.349 E.04465
G1 X106.463 Y135.166 E.03835
G1 X111.158 Y135.166 E.15574
G1 X111.975 Y134.349 E.03835
G1 X113.321 Y134.349 E.04465
G1 X114.139 Y135.166 E.03835
G1 X118.834 Y135.166 E.15574
G1 X119.651 Y134.349 E.03835
G1 X120.997 Y134.349 E.04465
G1 X121.815 Y135.166 E.03835
G1 X126.509 Y135.166 E.15574
G1 X127.327 Y134.349 E.03835
G1 X128.673 Y134.349 E.04465
G1 X129.49 Y135.166 E.03835
G1 X134.185 Y135.166 E.15574
G1 X135.003 Y134.349 E.03835
G1 X136.349 Y134.349 E.04465
G1 X137.166 Y135.166 E.03835
G1 X141.861 Y135.166 E.15574
G1 X142.679 Y134.349 E.03835
G1 X144.025 Y134.349 E.04465
G1 X144.842 Y135.166 E.03835
G1 X149.537 Y135.166 E.15574
G1 X150.355 Y134.349 E.03835
G1 X151.701 Y134.349 E.04465
G1 X152.518 Y135.166 E.03835
G1 X157.213 Y135.166 E.15574
G1 X158.031 Y134.349 E.03835
G1 X159.377 Y134.349 E.04465
G1 X160.194 Y135.166 E.03835
G1 X164.889 Y135.166 E.15574
G1 X165.707 Y134.349 E.03835
G1 X167.053 Y134.349 E.04465
G1 X167.87 Y135.166 E.03835
G1 X172.565 Y135.166 E.15574
G1 X173.383 Y134.349 E.03835
G1 X174.729 Y134.349 E.04465
G1 X175.546 Y135.166 E.03835
G1 X180.241 Y135.166 E.15574
G1 X181.059 Y134.349 E.03835
G1 X182.405 Y134.349 E.04465
G1 X183.05 Y134.994 E.03026
G1 X183.05 Y135.166 E.00572
G1 X181.594 Y135.166 E.04829
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X183.05 Y135.166 E-.55321
G1 X183.05 Y134.994 E-.06555
G1 X182.787 Y134.731 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 19/32
; update layer progress
M73 L19
M991 S0 P18 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4 I.759 J-.951 P1  F30000
G1 X166.602 Y121.808 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X183.398 Y121.808 E.55715
G1 X183.398 Y127.348 E.18376
G1 X183.398 Y127.748 E.01327
G1 F14331.075
G1 X183.398 Y128.148 E.01327
G1 F6685.538
G1 X183.398 Y128.548 E.01327
G1 F1920
G1 X183.398 Y128.928 E.01262
G1 F600
G1 X166.602 Y128.928 E.55715
G1 F1920
G1 X166.602 Y128.548 E.01262
G1 F6685.538
G1 X166.602 Y128.148 E.01327
G1 F14331.075
G1 X166.602 Y127.748 E.01327
G1 F15476.087
G1 X166.602 Y127.348 E.01327
G1 X166.602 Y121.868 E.18177
; WIPE_START
G1 X168.602 Y121.861 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X166.21 Y120.14 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X183.79 Y120.14 E.54018
G1 X183.79 Y127.761 E.23417
G1 X183.79 Y128.161 E.01229
G1 F6459.938
G1 X183.79 Y128.561 E.01229
G1 F1800
G1 X183.79 Y128.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y129.32 E.01294
G1 F600
G1 X166.21 Y129.32 E.58316
G1 X166.21 Y128.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y128.561 E.01134
G1 F6459.938
G1 X166.21 Y128.161 E.01229
G1 F12000
G1 X166.21 Y127.761 E.01229
G1 X166.21 Y120.2 E.23233
; WIPE_START
M204 S10000
G1 X168.21 Y120.193 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X166.952 Y127.178 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y127.178 E.4443
G1 X183.234 Y127.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y127.652 E.60098
G1 X166.935 Y128.105 E.01668
G1 X183.065 Y128.105 E.59472
G1 X183.065 Y128.557 E.01668
G1 X166.766 Y128.557 E.60098
G1 X183.05 Y125.69 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.05 Y126.828 E.03778
G1 X182.56 Y126.828 E.01624
G1 X181.167 Y125.435 E.06535
G1 X182.296 Y125.435 E.03746
G1 X180.903 Y126.828 E.06536
G1 X174.884 Y126.828 E.19966
G1 X173.491 Y125.435 E.06535
G1 X174.62 Y125.435 E.03746
G1 X173.227 Y126.828 E.06536
G1 X167.208 Y126.828 E.19966
G1 X166.95 Y126.571 E.0121
G1 X166.95 Y125.435 E.03766
G1 X167.443 Y125.435 E.01636
G1 X183.006 Y125.043 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y122.2 E.08737
G1 X166.994 Y122.2 E.49198
G1 X166.994 Y125.043 E.08737
G1 X182.946 Y125.043 E.49014
G1 X182.629 Y124.666 F30000
G1 F12000
G1 X182.629 Y122.577 E.0642
G1 X167.371 Y122.577 E.46881
G1 X167.371 Y124.666 E.0642
G1 X182.569 Y124.666 E.46697
G1 X182.252 Y123.622 F30000
G1 F12000
G1 X182.252 Y122.954 E.02051
G1 X167.748 Y122.954 E.44564
G1 X167.748 Y124.289 E.04102
G1 X182.252 Y124.289 E.44564
G1 X182.252 Y123.682 E.01867
G1 X181.824 Y123.622 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y123.382 E.00935
G1 X168.176 Y123.382 E.53272
G1 X168.176 Y123.861 E.0187
G1 X181.824 Y123.861 E.53272
G1 X181.824 Y123.682 E.00701
; WIPE_START
G1 X181.824 Y123.861 E-.06822
G1 X180.003 Y123.861 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y121.058 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X182.872 Y120.347 E.03088
G1 X182.339 Y120.347
G1 X183.577 Y121.585 E.05379
G1 X183.043 Y121.585
G1 X181.806 Y120.347 E.05379
G1 X181.272 Y120.347
G1 X182.51 Y121.585 E.05379
G1 X181.977 Y121.585
G1 X180.739 Y120.347 E.05379
G1 X180.206 Y120.347
G1 X181.444 Y121.585 E.05379
G1 X180.91 Y121.585
G1 X179.673 Y120.347 E.05379
G1 X179.139 Y120.347
G1 X180.377 Y121.585 E.05379
G1 X179.844 Y121.585
G1 X178.606 Y120.347 E.05379
G1 X178.073 Y120.347
G1 X179.311 Y121.585 E.05379
G1 X178.777 Y121.585
G1 X177.539 Y120.347 E.05379
G1 X177.006 Y120.347
G1 X178.244 Y121.585 E.05379
G1 X177.711 Y121.585
G1 X176.473 Y120.347 E.05379
G1 X175.94 Y120.347
G1 X177.178 Y121.585 E.05379
M73 P74 R7
G1 X176.644 Y121.585
G1 X175.406 Y120.347 E.05379
G1 X174.873 Y120.347
G1 X176.111 Y121.585 E.05379
G1 X175.578 Y121.585
G1 X174.34 Y120.347 E.05379
G1 X173.807 Y120.347
G1 X175.045 Y121.585 E.05379
G1 X174.511 Y121.585
G1 X173.273 Y120.347 E.05379
G1 X172.74 Y120.347
G1 X173.978 Y121.585 E.05379
G1 X173.445 Y121.585
G1 X172.207 Y120.347 E.05379
G1 X171.674 Y120.347
G1 X172.912 Y121.585 E.05379
G1 X172.378 Y121.585
G1 X171.14 Y120.347 E.05379
G1 X170.607 Y120.347
G1 X171.845 Y121.585 E.05379
G1 X171.312 Y121.585
G1 X170.074 Y120.347 E.05379
G1 X169.541 Y120.347
G1 X170.779 Y121.585 E.05379
G1 X170.245 Y121.585
G1 X169.007 Y120.347 E.05379
G1 X168.474 Y120.347
G1 X169.712 Y121.585 E.05379
G1 X169.179 Y121.585
G1 X167.941 Y120.347 E.05379
G1 X167.408 Y120.347
G1 X168.646 Y121.585 E.05379
G1 X168.112 Y121.585
G1 X166.874 Y120.347 E.05379
G1 X166.417 Y120.424
G1 X167.579 Y121.585 E.05048
G1 X167.046 Y121.585
G1 X166.417 Y120.957 E.0273
; WIPE_START
M204 S10000
G1 X167.046 Y121.585 E-.33767
G1 X167.579 Y121.585 E-.20264
G1 X167.17 Y121.177 E-.2197
; WIPE_END
G1 E-.04 F1800
G1 X159.545 Y121.507 Z4.2 F30000
G1 X152.602 Y121.808 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X159.398 Y121.808 E.22543
G1 X159.398 Y127.348 E.18376
G1 X159.398 Y127.748 E.01327
G1 F14331.075
G1 X159.398 Y128.148 E.01327
G1 F6685.538
G1 X159.398 Y128.548 E.01327
G1 F1920
G1 X159.398 Y128.928 E.01262
G1 F600
G1 X152.602 Y128.928 E.22543
G1 F1920
G1 X152.602 Y128.548 E.01262
G1 F6685.538
G1 X152.602 Y128.148 E.01327
G1 F14331.075
G1 X152.602 Y127.748 E.01327
G1 F15476.087
G1 X152.602 Y127.348 E.01327
G1 X152.602 Y121.868 E.18177
; WIPE_START
G1 X154.602 Y121.85 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X152.21 Y120.14 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X159.79 Y120.14 E.23291
G1 X159.79 Y127.761 E.23417
G1 X159.79 Y128.161 E.01229
G1 F6459.938
G1 X159.79 Y128.561 E.01229
G1 F1800
G1 X159.79 Y128.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X159.79 Y129.32 E.01294
G1 F600
G1 X152.21 Y129.32 E.25144
G1 X152.21 Y128.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y128.561 E.01134
G1 F6459.938
G1 X152.21 Y128.161 E.01229
G1 F12000
G1 X152.21 Y127.761 E.01229
G1 X152.21 Y120.2 E.23233
; WIPE_START
M204 S10000
G1 X154.21 Y120.184 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X152.952 Y127.178 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y127.178 E.16725
G1 X159.234 Y127.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y127.652 E.23226
G1 X152.935 Y128.105 E.01668
G1 X159.065 Y128.105 E.22601
G1 X159.065 Y128.557 E.01668
G1 X152.766 Y128.557 E.23226
G1 X156.247 Y126.828 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X157.875 Y126.828 E.05401
G1 X159.05 Y125.654 E.05509
G1 X159.05 Y126.346 E.02295
G1 X157.339 Y124.635 E.08024
G1 X155.711 Y124.635 E.05401
G1 X159.006 Y123.222 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y122.2 E.03139
G1 X152.994 Y122.2 E.18472
G1 X152.994 Y124.243 E.06279
G1 X159.006 Y124.243 E.18472
G1 X159.006 Y123.282 E.02955
G1 X158.629 Y123.222 F30000
G1 F12000
G1 X158.629 Y122.577 E.01981
G1 X153.371 Y122.577 E.16155
G1 X153.371 Y123.866 E.03961
G1 X158.629 Y123.866 E.16155
G1 X158.629 Y123.282 E.01796
G1 X158.212 Y123.222 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X158.212 Y122.994 E.00848
G1 X153.788 Y122.994 E.16444
G1 X153.788 Y123.45 E.01695
G1 X158.212 Y123.45 E.16444
G1 X158.212 Y123.282 E.00625
; WIPE_START
G1 X158.212 Y123.45 E-.06386
G1 X156.38 Y123.45 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y121.055 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X158.875 Y120.347 E.03073
G1 X158.342 Y120.347
G1 X159.58 Y121.585 E.05379
G1 X159.047 Y121.585
G1 X157.809 Y120.347 E.05379
G1 X157.276 Y120.347
G1 X158.514 Y121.585 E.05379
G1 X157.98 Y121.585
G1 X156.742 Y120.347 E.05379
G1 X156.209 Y120.347
G1 X157.447 Y121.585 E.05379
G1 X156.914 Y121.585
G1 X155.676 Y120.347 E.05379
G1 X155.143 Y120.347
G1 X156.381 Y121.585 E.05379
G1 X155.847 Y121.585
G1 X154.609 Y120.347 E.05379
G1 X154.076 Y120.347
G1 X155.314 Y121.585 E.05379
G1 X154.781 Y121.585
G1 X153.543 Y120.347 E.05379
G1 X153.01 Y120.347
G1 X154.248 Y121.585 E.05379
G1 X153.714 Y121.585
G1 X152.476 Y120.347 E.05379
G1 X152.417 Y120.822
G1 X153.181 Y121.585 E.03318
; WIPE_START
M204 S10000
G1 X152.417 Y120.822 E-.41038
G1 X152.476 Y120.347 E-.1816
G1 X152.789 Y120.66 E-.16802
; WIPE_END
G1 E-.04 F1800
G1 X145.398 Y121.808 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X145.398 Y127.348 E.18376
G1 X145.398 Y127.748 E.01327
G1 F14331.075
G1 X145.398 Y128.148 E.01327
G1 F6685.538
G1 X145.398 Y128.548 E.01327
G1 F1920
G1 X145.398 Y128.928 E.01262
G1 F600
G1 X138.602 Y128.928 E.22543
G1 F1920
G1 X138.602 Y128.548 E.01262
G1 F6685.538
G1 X138.602 Y128.148 E.01327
G1 F14331.075
G1 X138.602 Y127.748 E.01327
G1 F15476.087
G1 X138.602 Y127.348 E.01327
G1 X138.602 Y121.808 E.18376
G1 X145.338 Y121.808 E.22344
; WIPE_START
G1 X145.36 Y123.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.79 Y120.14 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X145.79 Y127.761 E.23417
G1 X145.79 Y128.161 E.01229
G1 F6459.938
G1 X145.79 Y128.561 E.01229
G1 F1800
G1 X145.79 Y128.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X145.79 Y129.32 E.01294
G1 F600
G1 X138.21 Y129.32 E.25144
G1 X138.21 Y128.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y128.561 E.01134
G1 F6459.938
G1 X138.21 Y128.161 E.01229
G1 F12000
G1 X138.21 Y127.761 E.01229
G1 X138.21 Y120.14 E.23417
G1 X145.73 Y120.14 E.23107
M204 S10000
G1 X145.583 Y120.919 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X145.011 Y120.347 E.02485
G1 X144.478 Y120.347
G1 X145.583 Y121.453 E.04802
G1 X145.182 Y121.585
G1 X143.944 Y120.347 E.05379
G1 X143.411 Y120.347
G1 X144.649 Y121.585 E.05379
G1 X144.116 Y121.585
G1 X142.878 Y120.347 E.05379
G1 X142.344 Y120.347
G1 X143.582 Y121.585 E.05379
G1 X143.049 Y121.585
G1 X141.811 Y120.347 E.05379
G1 X141.278 Y120.347
G1 X142.516 Y121.585 E.05379
G1 X141.983 Y121.585
G1 X140.745 Y120.347 E.05379
G1 X140.211 Y120.347
G1 X141.449 Y121.585 E.05379
G1 X140.916 Y121.585
G1 X139.678 Y120.347 E.05379
G1 X139.145 Y120.347
G1 X140.383 Y121.585 E.05379
G1 X139.85 Y121.585
G1 X138.612 Y120.347 E.05379
G1 X138.417 Y120.686
G1 X139.316 Y121.585 E.03906
G1 X138.783 Y121.585
G1 X138.417 Y121.22 E.01589
; WIPE_START
M204 S10000
G1 X138.783 Y121.585 E-.19652
G1 X139.316 Y121.585 E-.20264
G1 X138.645 Y120.914 E-.36084
; WIPE_END
G1 E-.04 F1800
G1 X140.359 Y124.635 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X141.987 Y124.635 E.05401
G1 X144.18 Y126.828 E.10288
G1 X142.523 Y126.828 E.05496
G1 X144.717 Y124.635 E.10288
G1 X145.05 Y124.635 E.01105
G1 X145.05 Y125.931 E.04296
G1 X145.006 Y124.243 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y122.2 E.06279
G1 X138.994 Y122.2 E.18472
G1 X138.994 Y124.243 E.06279
G1 X144.946 Y124.243 E.18288
G1 X144.629 Y123.866 F30000
G1 F12000
G1 X144.629 Y122.577 E.03961
G1 X139.371 Y122.577 E.16155
G1 X139.371 Y123.866 E.03961
G1 X144.569 Y123.866 E.1597
G1 X144.212 Y123.45 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X144.212 Y122.994 E.01695
G1 X139.788 Y122.994 E.16444
G1 X139.788 Y123.45 E.01695
G1 X144.152 Y123.45 E.16221
G1 X145.234 Y127.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y127.652 E.23226
G1 X138.935 Y128.105 E.01668
G1 X145.065 Y128.105 E.22601
G1 X145.065 Y128.557 E.01668
G1 X138.766 Y128.557 E.23226
G1 X138.952 Y127.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y127.178 E.16725
; WIPE_START
G1 X142.988 Y127.178 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X136.063 Y123.969 Z4.2 F30000
G1 X131.398 Y121.808 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y127.348 E.18376
G1 X131.398 Y127.748 E.01327
G1 F14331.075
G1 X131.398 Y128.148 E.01327
G1 F6685.538
G1 X131.398 Y128.548 E.01327
G1 F1920
G1 X131.398 Y128.928 E.01262
G1 F600
G1 X124.602 Y128.928 E.22543
G1 F1920
G1 X124.602 Y128.548 E.01262
G1 F6685.538
G1 X124.602 Y128.148 E.01327
G1 F14331.075
G1 X124.602 Y127.748 E.01327
G1 F15476.087
G1 X124.602 Y127.348 E.01327
G1 X124.602 Y121.808 E.18376
G1 X131.338 Y121.808 E.22344
; WIPE_START
G1 X131.36 Y123.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.79 Y120.14 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y127.761 E.23417
G1 X131.79 Y128.161 E.01229
G1 F6459.938
G1 X131.79 Y128.561 E.01229
G1 F1800
G1 X131.79 Y128.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X131.79 Y129.32 E.01294
G1 F600
G1 X124.21 Y129.32 E.25144
G1 X124.21 Y128.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y128.561 E.01134
G1 F6459.938
G1 X124.21 Y128.161 E.01229
G1 F12000
G1 X124.21 Y127.761 E.01229
G1 X124.21 Y120.14 E.23417
G1 X131.73 Y120.14 E.23107
M204 S10000
G1 X131.583 Y120.784 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X131.146 Y120.347 E.01897
G1 X130.613 Y120.347
G1 X131.583 Y121.317 E.04214
G1 X131.317 Y121.585
G1 X130.08 Y120.347 E.05379
G1 X129.546 Y120.347
G1 X130.784 Y121.585 E.05379
G1 X130.251 Y121.585
G1 X129.013 Y120.347 E.05379
G1 X128.48 Y120.347
G1 X129.718 Y121.585 E.05379
G1 X129.184 Y121.585
G1 X127.947 Y120.347 E.05379
G1 X127.413 Y120.347
G1 X128.651 Y121.585 E.05379
G1 X128.118 Y121.585
G1 X126.88 Y120.347 E.05379
G1 X126.347 Y120.347
G1 X127.585 Y121.585 E.05379
G1 X127.051 Y121.585
G1 X125.814 Y120.347 E.05379
G1 X125.28 Y120.347
G1 X126.518 Y121.585 E.05379
G1 X125.985 Y121.585
G1 X124.747 Y120.347 E.05379
G1 X124.417 Y120.551
G1 X125.452 Y121.585 E.04494
G1 X124.918 Y121.585
G1 X124.417 Y121.084 E.02177
; WIPE_START
M204 S10000
G1 X124.918 Y121.585 E-.26924
G1 X125.452 Y121.585 E-.20264
G1 X124.915 Y121.049 E-.28812
; WIPE_END
G1 E-.04 F1800
G1 X125.007 Y124.635 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X126.635 Y124.635 E.05401
G1 X128.828 Y126.828 E.10288
G1 X127.172 Y126.828 E.05496
G1 X129.365 Y124.635 E.10288
G1 X130.993 Y124.635 E.05401
G1 X131.006 Y123.222 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y122.2 E.03139
G1 X124.994 Y122.2 E.18472
G1 X124.994 Y124.243 E.06279
G1 X131.006 Y124.243 E.18472
G1 X131.006 Y123.282 E.02955
G1 X130.629 Y123.222 F30000
G1 F12000
G1 X130.629 Y122.577 E.01981
G1 X125.371 Y122.577 E.16155
G1 X125.371 Y123.866 E.03961
G1 X130.629 Y123.866 E.16155
G1 X130.629 Y123.282 E.01796
G1 X130.212 Y123.222 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X130.212 Y122.994 E.00848
G1 X125.788 Y122.994 E.16444
G1 X125.788 Y123.45 E.01695
G1 X130.212 Y123.45 E.16444
G1 X130.212 Y123.282 E.00625
G1 X131.234 Y127.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y127.652 E.23226
G1 X124.935 Y128.105 E.01668
G1 X131.065 Y128.105 E.22601
G1 X131.065 Y128.557 E.01668
G1 X124.766 Y128.557 E.23226
G1 X124.952 Y127.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y127.178 E.16725
; WIPE_START
G1 X128.988 Y127.178 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X122.063 Y123.969 Z4.2 F30000
G1 X117.398 Y121.808 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X117.398 Y127.348 E.18376
G1 X117.398 Y127.748 E.01327
G1 F14331.075
G1 X117.398 Y128.148 E.01327
G1 F6685.538
G1 X117.398 Y128.548 E.01327
G1 F1920
G1 X117.398 Y128.928 E.01262
G1 F600
G1 X110.602 Y128.928 E.22543
G1 F1920
G1 X110.602 Y128.548 E.01262
G1 F6685.538
G1 X110.602 Y128.148 E.01327
G1 F14331.075
G1 X110.602 Y127.748 E.01327
G1 F15476.087
G1 X110.602 Y127.348 E.01327
G1 X110.602 Y121.808 E.18376
G1 X117.338 Y121.808 E.22344
; WIPE_START
G1 X117.36 Y123.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X117.79 Y120.14 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
M73 P75 R7
G1 X117.79 Y127.761 E.23417
G1 X117.79 Y128.161 E.01229
G1 F6459.938
G1 X117.79 Y128.561 E.01229
G1 F1800
G1 X117.79 Y128.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X117.79 Y129.32 E.01294
G1 F600
G1 X110.21 Y129.32 E.25144
G1 X110.21 Y128.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y128.561 E.01134
G1 F6459.938
G1 X110.21 Y128.161 E.01229
G1 F12000
G1 X110.21 Y127.761 E.01229
G1 X110.21 Y120.14 E.23417
G1 X117.73 Y120.14 E.23107
; WIPE_START
M204 S10000
G1 X117.746 Y122.14 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X116.748 Y120.347 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X117.583 Y121.182 E.03626
G1 X117.453 Y121.585
G1 X116.215 Y120.347 E.05379
G1 X115.682 Y120.347
G1 X116.92 Y121.585 E.05379
G1 X116.386 Y121.585
G1 X115.148 Y120.347 E.05379
G1 X114.615 Y120.347
G1 X115.853 Y121.585 E.05379
G1 X115.32 Y121.585
G1 X114.082 Y120.347 E.05379
G1 X113.549 Y120.347
G1 X114.786 Y121.585 E.05379
G1 X114.253 Y121.585
G1 X113.015 Y120.347 E.05379
G1 X112.482 Y120.347
G1 X113.72 Y121.585 E.05379
G1 X113.187 Y121.585
G1 X111.949 Y120.347 E.05379
G1 X111.416 Y120.347
G1 X112.653 Y121.585 E.05379
G1 X112.12 Y121.585
G1 X110.882 Y120.347 E.05379
G1 X110.417 Y120.416
G1 X111.587 Y121.585 E.05082
G1 X111.054 Y121.585
G1 X110.417 Y120.949 E.02765
; WIPE_START
M204 S10000
G1 X111.054 Y121.585 E-.34195
G1 X111.587 Y121.585 E-.20264
G1 X111.186 Y121.184 E-.21541
; WIPE_END
G1 E-.04 F1800
G1 X110.95 Y125.931 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y124.635 E.04296
G1 X111.283 Y124.635 E.01105
G1 X113.477 Y126.828 E.10288
G1 X111.82 Y126.828 E.05496
G1 X114.013 Y124.635 E.10288
G1 X115.641 Y124.635 E.05401
G1 X117.006 Y123.222 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y122.2 E.03139
G1 X110.994 Y122.2 E.18472
G1 X110.994 Y124.243 E.06279
G1 X117.006 Y124.243 E.18472
G1 X117.006 Y123.282 E.02955
G1 X116.629 Y123.222 F30000
G1 F12000
G1 X116.629 Y122.577 E.01981
G1 X111.371 Y122.577 E.16155
G1 X111.371 Y123.866 E.03961
G1 X116.629 Y123.866 E.16155
G1 X116.629 Y123.282 E.01796
G1 X116.212 Y123.222 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X116.212 Y122.994 E.00848
G1 X111.788 Y122.994 E.16444
G1 X111.788 Y123.45 E.01695
G1 X116.212 Y123.45 E.16444
G1 X116.212 Y123.282 E.00625
G1 X117.234 Y127.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y127.652 E.23226
G1 X110.935 Y128.105 E.01668
G1 X117.065 Y128.105 E.22601
G1 X117.065 Y128.557 E.01668
G1 X110.766 Y128.557 E.23226
G1 X110.952 Y127.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y127.178 E.16725
; WIPE_START
G1 X114.988 Y127.178 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.662 Y125.038 Z4.2 F30000
G1 X96.602 Y121.808 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.398 Y121.808 E.22543
G1 X103.398 Y127.348 E.18376
G1 X103.398 Y127.748 E.01327
G1 F14331.075
G1 X103.398 Y128.148 E.01327
G1 F6685.538
G1 X103.398 Y128.548 E.01327
G1 F1920
G1 X103.398 Y128.928 E.01262
G1 F600
G1 X96.602 Y128.928 E.22543
G1 F1920
G1 X96.602 Y128.548 E.01262
G1 F6685.538
G1 X96.602 Y128.148 E.01327
G1 F14331.075
G1 X96.602 Y127.748 E.01327
G1 F15476.087
G1 X96.602 Y127.348 E.01327
G1 X96.602 Y121.868 E.18177
; WIPE_START
G1 X98.602 Y121.85 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X96.21 Y120.14 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X103.79 Y120.14 E.23291
G1 X103.79 Y127.761 E.23417
G1 X103.79 Y128.161 E.01229
G1 F6459.938
G1 X103.79 Y128.561 E.01229
G1 F1800
G1 X103.79 Y128.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X103.79 Y129.32 E.01294
G1 F600
G1 X96.21 Y129.32 E.25144
G1 X96.21 Y128.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y128.561 E.01134
G1 F6459.938
G1 X96.21 Y128.161 E.01229
G1 F12000
G1 X96.21 Y127.761 E.01229
G1 X96.21 Y120.2 E.23233
; WIPE_START
M204 S10000
G1 X98.21 Y120.184 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.289 Y124.635 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X98.661 Y124.635 E.05401
G1 X96.95 Y126.346 E.08024
G1 X96.95 Y125.654 E.02294
G1 X98.125 Y126.828 E.05509
G1 X99.753 Y126.828 E.05401
G1 X96.952 Y127.178 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y127.178 E.16725
G1 X103.234 Y127.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y127.652 E.23226
G1 X96.935 Y128.105 E.01668
G1 X103.065 Y128.105 E.22601
G1 X103.065 Y128.557 E.01668
G1 X96.766 Y128.557 E.23226
G1 X103.006 Y123.222 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y122.2 E.03139
G1 X96.994 Y122.2 E.18472
G1 X96.994 Y124.243 E.06279
G1 X103.006 Y124.243 E.18472
G1 X103.006 Y123.282 E.02955
G1 X102.629 Y123.866 F30000
M73 P75 R6
G1 F12000
G1 X102.629 Y122.577 E.03961
G1 X97.371 Y122.577 E.16155
G1 X97.371 Y123.866 E.03961
G1 X102.569 Y123.866 E.1597
G1 X102.212 Y123.45 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X102.212 Y122.994 E.01695
G1 X97.788 Y122.994 E.16444
G1 X97.788 Y123.45 E.01695
G1 X102.152 Y123.45 E.16221
; WIPE_START
G1 X100.152 Y123.45 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y121.047 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X102.883 Y120.347 E.03038
G1 X102.35 Y120.347
G1 X103.583 Y121.58 E.05356
G1 X103.055 Y121.585
G1 X101.817 Y120.347 E.05379
G1 X101.284 Y120.347
G1 X102.522 Y121.585 E.05379
G1 X101.988 Y121.585
G1 X100.75 Y120.347 E.05379
G1 X100.217 Y120.347
G1 X101.455 Y121.585 E.05379
G1 X100.922 Y121.585
G1 X99.684 Y120.347 E.05379
G1 X99.151 Y120.347
G1 X100.389 Y121.585 E.05379
G1 X99.855 Y121.585
G1 X98.617 Y120.347 E.05379
G1 X98.084 Y120.347
G1 X99.322 Y121.585 E.05379
G1 X98.789 Y121.585
G1 X97.551 Y120.347 E.05379
G1 X97.018 Y120.347
G1 X98.256 Y121.585 E.05379
G1 X97.722 Y121.585
G1 X96.484 Y120.347 E.05379
G1 X96.417 Y120.814
G1 X97.189 Y121.585 E.03353
; WIPE_START
M204 S10000
G1 X96.417 Y120.814 E-.41466
G1 X96.484 Y120.347 E-.17901
G1 X96.794 Y120.657 E-.16633
; WIPE_END
G1 E-.04 F1800
G1 X89.398 Y121.808 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.398 Y127.348 E.18376
G1 X89.398 Y127.748 E.01327
G1 F14331.075
G1 X89.398 Y128.148 E.01327
G1 F6685.538
G1 X89.398 Y128.548 E.01327
G1 F1920
G1 X89.398 Y128.928 E.01262
G1 F600
G1 X72.602 Y128.928 E.55715
G1 F1920
G1 X72.602 Y128.548 E.01262
G1 F6685.538
G1 X72.602 Y128.148 E.01327
G1 F14331.075
G1 X72.602 Y127.748 E.01327
G1 F15476.087
G1 X72.602 Y127.348 E.01327
G1 X72.602 Y121.808 E.18376
G1 X89.338 Y121.808 E.55516
; WIPE_START
G1 X89.36 Y123.808 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.79 Y120.14 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X89.79 Y127.761 E.23417
G1 X89.79 Y128.161 E.01229
G1 F6459.938
G1 X89.79 Y128.561 E.01229
G1 F1800
G1 X89.79 Y128.93 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X89.79 Y129.32 E.01294
G1 F600
G1 X72.21 Y129.32 E.58316
G1 X72.21 Y128.93 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y128.561 E.01134
G1 F6459.938
G1 X72.21 Y128.161 E.01229
G1 F12000
G1 X72.21 Y127.761 E.01229
G1 X72.21 Y120.14 E.23417
G1 X89.73 Y120.14 E.53834
M204 S10000
G1 X89.583 Y120.911 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X89.019 Y120.347 E.0245
G1 X88.485 Y120.347
G1 X89.583 Y121.445 E.04768
G1 X89.19 Y121.585
G1 X87.952 Y120.347 E.05379
G1 X87.419 Y120.347
G1 X88.657 Y121.585 E.05379
G1 X88.124 Y121.585
G1 X86.886 Y120.347 E.05379
G1 X86.352 Y120.347
G1 X87.59 Y121.585 E.05379
G1 X87.057 Y121.585
G1 X85.819 Y120.347 E.05379
G1 X85.286 Y120.347
G1 X86.524 Y121.585 E.05379
G1 X85.991 Y121.585
G1 X84.753 Y120.347 E.05379
G1 X84.219 Y120.347
G1 X85.457 Y121.585 E.05379
G1 X84.924 Y121.585
G1 X83.686 Y120.347 E.05379
G1 X83.153 Y120.347
G1 X84.391 Y121.585 E.05379
G1 X83.858 Y121.585
G1 X82.62 Y120.347 E.05379
G1 X82.086 Y120.347
G1 X83.324 Y121.585 E.05379
G1 X82.791 Y121.585
G1 X81.553 Y120.347 E.05379
G1 X81.02 Y120.347
G1 X82.258 Y121.585 E.05379
G1 X81.725 Y121.585
G1 X80.487 Y120.347 E.05379
G1 X79.953 Y120.347
G1 X81.191 Y121.585 E.05379
G1 X80.658 Y121.585
G1 X79.42 Y120.347 E.05379
G1 X78.887 Y120.347
G1 X80.125 Y121.585 E.05379
G1 X79.591 Y121.585
G1 X78.354 Y120.347 E.05379
G1 X77.82 Y120.347
G1 X79.058 Y121.585 E.05379
G1 X78.525 Y121.585
G1 X77.287 Y120.347 E.05379
G1 X76.754 Y120.347
G1 X77.992 Y121.585 E.05379
G1 X77.458 Y121.585
G1 X76.221 Y120.347 E.05379
G1 X75.687 Y120.347
G1 X76.925 Y121.585 E.05379
G1 X76.392 Y121.585
G1 X75.154 Y120.347 E.05379
G1 X74.621 Y120.347
G1 X75.859 Y121.585 E.05379
G1 X75.325 Y121.585
G1 X74.088 Y120.347 E.05379
G1 X73.554 Y120.347
G1 X74.792 Y121.585 E.05379
G1 X74.259 Y121.585
G1 X73.021 Y120.347 E.05379
G1 X72.488 Y120.347
G1 X73.726 Y121.585 E.05379
G1 X73.192 Y121.585
G1 X72.417 Y120.81 E.03368
; WIPE_START
M204 S10000
G1 X73.192 Y121.585 E-.4165
G1 X73.726 Y121.585 E-.20264
G1 X73.464 Y121.323 E-.14086
; WIPE_END
G1 E-.04 F1800
G1 X72.952 Y127.178 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y127.178 E.4443
G1 X89.234 Y127.652 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y127.652 E.60098
G1 X72.935 Y128.105 E.01668
G1 X89.065 Y128.105 E.59472
G1 X89.065 Y128.557 E.01668
G1 X72.766 Y128.557 E.60098
G1 X88.557 Y125.435 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.05 Y125.435 E.01636
G1 X89.05 Y126.571 E.03766
G1 X88.792 Y126.828 E.0121
G1 X82.773 Y126.828 E.19966
G1 X81.38 Y125.435 E.06536
G1 X82.509 Y125.435 E.03746
G1 X81.116 Y126.828 E.06536
G1 X75.097 Y126.828 E.19966
G1 X73.704 Y125.435 E.06536
G1 X74.833 Y125.435 E.03746
G1 X73.44 Y126.828 E.06536
G1 X72.95 Y126.828 E.01624
G1 X72.95 Y125.69 E.03778
G1 X89.006 Y123.622 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y122.2 E.04368
G1 X72.994 Y122.2 E.49198
G1 X72.994 Y125.043 E.08737
G1 X89.006 Y125.043 E.49198
G1 X89.006 Y123.682 E.04184
G1 X88.629 Y123.622 F30000
G1 F12000
G1 X88.629 Y122.577 E.0321
G1 X73.371 Y122.577 E.46881
G1 X73.371 Y124.666 E.0642
G1 X88.629 Y124.666 E.46881
G1 X88.629 Y123.682 E.03025
G1 X88.252 Y123.622 F30000
G1 F12000
G1 X88.252 Y122.954 E.02051
G1 X73.748 Y122.954 E.44564
G1 X73.748 Y124.289 E.04102
G1 X88.252 Y124.289 E.44564
G1 X88.252 Y123.682 E.01867
G1 X87.824 Y123.622 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X87.824 Y123.382 E.00935
G1 X74.176 Y123.382 E.53272
G1 X74.176 Y123.861 E.0187
G1 X87.824 Y123.861 E.53272
G1 X87.824 Y123.682 E.00701
; WIPE_START
G1 X87.824 Y123.861 E-.06822
G1 X86.003 Y123.861 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X93.508 Y125.251 Z4.2 F30000
G1 X138.602 Y133.602 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y132.943 E.02186
G1 X138.602 Y132.543 E.01327
G1 F14852.35
G1 X138.602 Y132.483 E.00199
G1 F13500
G1 X145.398 Y132.483 E.22543
G1 F14852.35
G1 X145.398 Y132.543 E.00199
M73 P76 R6
G1 F15476.087
G1 X145.398 Y132.943 E.01327
G1 X145.398 Y133.602 E.02186
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y132.943 E.02186
G1 X152.602 Y132.543 E.01327
G1 F14852.35
G1 X152.602 Y132.483 E.00199
G1 F13500
G1 X159.398 Y132.483 E.22543
G1 F14852.35
G1 X159.398 Y132.543 E.00199
G1 F15476.087
G1 X159.398 Y132.943 E.01327
G1 X159.398 Y133.602 E.02186
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y132.943 E.02186
G1 X166.602 Y132.543 E.01327
G1 F14852.35
G1 X166.602 Y132.483 E.00199
G1 F13500
G1 X183.398 Y132.483 E.55715
G1 F14852.35
G1 X183.398 Y132.543 E.00199
G1 F15476.087
G1 X183.398 Y132.943 E.01327
G1 X183.398 Y137.03 E.13557
G1 X72.602 Y137.03 E3.6753
G1 X72.602 Y132.943 E.13557
G1 X72.602 Y132.543 E.01327
G1 F14852.35
G1 X72.602 Y132.483 E.00199
G1 F13500
G1 X89.398 Y132.483 E.55715
G1 F14852.35
G1 X89.398 Y132.543 E.00199
G1 F15476.087
G1 X89.398 Y132.943 E.01327
G1 X89.398 Y133.602 E.02186
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y132.943 E.02186
G1 X96.602 Y132.543 E.01327
G1 F14852.35
G1 X96.602 Y132.483 E.00199
G1 F13500
G1 X103.398 Y132.483 E.22543
G1 F14852.35
G1 X103.398 Y132.543 E.00199
G1 F15476.087
G1 X103.398 Y132.943 E.01327
G1 X103.398 Y133.602 E.02186
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y132.943 E.02186
G1 X110.602 Y132.543 E.01327
G1 F14852.35
G1 X110.602 Y132.483 E.00199
G1 F13500
G1 X117.398 Y132.483 E.22543
G1 F14852.35
G1 X117.398 Y132.543 E.00199
G1 F15476.087
G1 X117.398 Y132.943 E.01327
G1 X117.398 Y133.602 E.02186
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y132.943 E.02186
G1 X124.602 Y132.543 E.01327
G1 F14852.35
G1 X124.602 Y132.483 E.00199
G1 F13500
G1 X131.398 Y132.483 E.22543
G1 F14852.35
G1 X131.398 Y132.543 E.00199
G1 F15476.087
G1 X131.398 Y132.943 E.01327
G1 X131.398 Y133.602 E.02186
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F11447.063
M204 S5000
G1 X138.21 Y132.929 E.00862
G1 F6459.938
G1 X138.21 Y132.529 E.01229
G1 F1800
G1 X138.21 Y132.16 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X138.21 Y132.091 E.0023
G1 X145.79 Y132.091 E.25144
G1 X145.79 Y132.16 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X145.79 Y132.529 E.01134
G1 F6459.938
G1 X145.79 Y132.929 E.01229
G1 F11447.063
G1 X145.79 Y133.21 E.00862
G1 F12000
G1 X146.19 Y133.21 E.01229
G1 X151.81 Y133.21 E.17269
G1 X152.21 Y133.21 E.01229
G1 F11447.063
G1 X152.21 Y132.929 E.00862
G1 F6459.938
G1 X152.21 Y132.529 E.01229
G1 F1800
G1 X152.21 Y132.16 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X152.21 Y132.091 E.0023
G1 X159.79 Y132.091 E.25144
G1 X159.79 Y132.16 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X159.79 Y132.529 E.01134
G1 F6459.938
G1 X159.79 Y132.929 E.01229
G1 F11447.063
G1 X159.79 Y133.21 E.00862
G1 F12000
G1 X160.19 Y133.21 E.01229
G1 X165.81 Y133.21 E.17269
G1 X166.21 Y133.21 E.01229
G1 F11447.063
G1 X166.21 Y132.929 E.00862
G1 F6459.938
G1 X166.21 Y132.529 E.01229
G1 F1800
G1 X166.21 Y132.16 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X166.21 Y132.091 E.0023
G1 X183.79 Y132.091 E.58316
G1 X183.79 Y132.16 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y132.529 E.01134
G1 F6459.938
G1 X183.79 Y132.929 E.01229
G1 F12000
G1 X183.79 Y133.329 E.01229
G1 X183.79 Y137.422 E.12575
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y137.422 E3.42854
G1 X72.21 Y133.329 E.12575
G1 X72.21 Y132.929 E.01229
G1 F6459.938
G1 X72.21 Y132.529 E.01229
G1 F1800
G1 X72.21 Y132.16 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y132.091 E.0023
G1 X89.79 Y132.091 E.58316
G1 X89.79 Y132.16 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X89.79 Y132.529 E.01134
G1 F6459.938
G1 X89.79 Y132.929 E.01229
G1 F11447.063
G1 X89.79 Y133.21 E.00862
G1 F12000
G1 X90.19 Y133.21 E.01229
G1 X95.81 Y133.21 E.17269
G1 X96.21 Y133.21 E.01229
G1 F11447.063
G1 X96.21 Y132.929 E.00862
G1 F6459.938
G1 X96.21 Y132.529 E.01229
G1 F1800
G1 X96.21 Y132.16 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X96.21 Y132.091 E.0023
G1 X103.79 Y132.091 E.25144
G1 X103.79 Y132.16 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X103.79 Y132.529 E.01134
G1 F6459.938
G1 X103.79 Y132.929 E.01229
G1 F11447.063
G1 X103.79 Y133.21 E.00862
G1 F12000
G1 X104.19 Y133.21 E.01229
G1 X109.81 Y133.21 E.17269
G1 X110.21 Y133.21 E.01229
G1 F11447.063
G1 X110.21 Y132.929 E.00862
G1 F6459.938
G1 X110.21 Y132.529 E.01229
G1 F1800
G1 X110.21 Y132.16 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X110.21 Y132.091 E.0023
G1 X117.79 Y132.091 E.25144
G1 X117.79 Y132.16 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X117.79 Y132.529 E.01134
G1 F6459.938
G1 X117.79 Y132.929 E.01229
G1 F11447.063
G1 X117.79 Y133.21 E.00862
G1 F12000
G1 X118.19 Y133.21 E.01229
G1 X123.81 Y133.21 E.17269
G1 X124.21 Y133.21 E.01229
G1 F11447.063
G1 X124.21 Y132.929 E.00862
G1 F6459.938
G1 X124.21 Y132.529 E.01229
G1 F1800
G1 X124.21 Y132.16 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X124.21 Y132.091 E.0023
G1 X131.79 Y132.091 E.25144
G1 X131.79 Y132.16 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X131.79 Y132.529 E.01134
G1 F6459.938
G1 X131.79 Y132.929 E.01229
G1 F11447.063
G1 X131.79 Y133.21 E.00862
G1 F12000
G1 X132.19 Y133.21 E.01229
G1 X138.15 Y133.21 E.18313
M204 S10000
G1 X139.05 Y132.931 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53261
G1 F12865.282
G1 X139.05 Y133.421 E.01954
G1 X144.95 Y133.421 E.2354
G1 X144.95 Y132.931 E.01954
G1 X139.11 Y132.931 E.233
; WIPE_START
G1 X141.11 Y132.931 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I0 J1.217 P1  F30000
G1 X153.05 Y132.931 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F12865.282
G1 X153.05 Y133.421 E.01954
G1 X158.95 Y133.421 E.2354
G1 X158.95 Y132.931 E.01954
G1 X153.11 Y132.931 E.233
; WIPE_START
G1 X155.11 Y132.931 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I0 J1.217 P1  F30000
G1 X167.05 Y132.931 Z4.2
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.532605
G1 F12865.414
G1 X167.05 Y133.421 E.01954
G1 X182.95 Y133.421 E.63442
G1 X182.95 Y132.931 E.01954
G1 X167.11 Y132.931 E.63203
G1 X182.546 Y133.87 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.05 Y133.87 E.01671
G1 X183.05 Y134.687 E.02712
G1 X182.743 Y134.687 E.01018
G1 X181.925 Y133.87 E.03835
G1 X181.538 Y133.87 E.01284
G1 X180.721 Y134.687 E.03835
G1 X175.067 Y134.687 E.18755
G1 X174.249 Y133.87 E.03835
G1 X173.862 Y133.869 E.01284
G1 X173.045 Y134.687 E.03835
G1 X167.391 Y134.687 E.18755
G1 X166.654 Y133.95 E.03456
G1 X166.105 Y133.95 E.0182
G1 X165.369 Y134.687 E.03456
G1 X159.715 Y134.687 E.18755
G1 X158.897 Y133.87 E.03835
G1 X158.51 Y133.87 E.01284
G1 X157.693 Y134.687 E.03835
G1 X152.039 Y134.687 E.18755
G1 X151.302 Y133.95 E.03456
G1 X150.753 Y133.95 E.0182
G1 X150.017 Y134.687 E.03456
G1 X144.363 Y134.687 E.18755
G1 X143.545 Y133.87 E.03835
G1 X143.158 Y133.87 E.01284
G1 X142.341 Y134.687 E.03835
G1 X136.687 Y134.687 E.18755
G1 X135.95 Y133.95 E.03456
G1 X135.402 Y133.95 E.0182
G1 X134.665 Y134.687 E.03456
G1 X129.011 Y134.687 E.18755
G1 X128.194 Y133.87 E.03835
G1 X127.806 Y133.87 E.01284
G1 X126.989 Y134.687 E.03835
G1 X121.335 Y134.687 E.18755
G1 X120.598 Y133.95 E.03456
G1 X120.05 Y133.95 E.0182
G1 X119.313 Y134.687 E.03456
G1 X113.659 Y134.687 E.18755
G1 X112.842 Y133.87 E.03835
G1 X112.455 Y133.87 E.01284
G1 X111.637 Y134.687 E.03835
G1 X105.983 Y134.687 E.18755
G1 X105.247 Y133.95 E.03456
G1 X104.698 Y133.95 E.0182
G1 X103.961 Y134.687 E.03456
G1 X98.307 Y134.687 E.18755
G1 X97.49 Y133.87 E.03835
G1 X97.103 Y133.87 E.01284
G1 X96.285 Y134.687 E.03835
G1 X90.631 Y134.687 E.18755
G1 X89.895 Y133.95 E.03456
G1 X89.346 Y133.95 E.0182
G1 X88.609 Y134.687 E.03456
G1 X82.955 Y134.687 E.18755
G1 X82.138 Y133.869 E.03835
G1 X81.751 Y133.87 E.01284
G1 X80.933 Y134.687 E.03835
G1 X75.279 Y134.687 E.18755
G1 X74.462 Y133.87 E.03835
G1 X74.075 Y133.87 E.01284
G1 X73.257 Y134.687 E.03835
G1 X72.95 Y134.687 E.01018
G1 X72.95 Y133.87 E.02712
G1 X73.454 Y133.87 E.01671
G1 X88.95 Y132.931 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.532605
G1 F12865.414
G1 X73.05 Y132.931 E.63442
G1 X73.05 Y133.421 E.01954
G1 X88.95 Y133.421 E.63442
G1 X88.95 Y132.991 E.01715
; WIPE_START
G1 X88.95 Y133.421 E-.16328
G1 X87.379 Y133.421 E-.59672
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I.038 J1.216 P1  F30000
G1 X102.95 Y132.931 Z4.2
G1 Z3.8
G1 E.8 F1800
; LINE_WIDTH: 0.53261
G1 F12865.282
G1 X97.05 Y132.931 E.2354
G1 X97.05 Y133.421 E.01954
G1 X102.95 Y133.421 E.2354
G1 X102.95 Y132.991 E.01715
; WIPE_START
G1 X102.95 Y133.421 E-.16329
G1 X101.379 Y133.421 E-.59671
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I.038 J1.216 P1  F30000
G1 X116.95 Y132.931 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F12865.282
G1 X111.05 Y132.931 E.2354
G1 X111.05 Y133.421 E.01954
G1 X116.95 Y133.421 E.2354
G1 X116.95 Y132.991 E.01715
; WIPE_START
G1 X116.95 Y133.421 E-.16329
G1 X115.379 Y133.421 E-.59671
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I.062 J1.215 P1  F30000
G1 X125.05 Y132.931 Z4.2
G1 Z3.8
G1 E.8 F1800
G1 F12865.282
G1 X125.05 Y133.421 E.01954
G1 X130.95 Y133.421 E.2354
G1 X130.95 Y132.931 E.01954
G1 X125.11 Y132.931 E.233
; WIPE_START
G1 X127.11 Y132.931 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-.064 J1.215 P1  F30000
G1 X183.006 Y135.858 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y135.079 E.02395
G1 X72.994 Y135.079 E3.38027
G1 X72.994 Y136.638 E.04789
G1 X183.006 Y136.638 E3.38027
G1 X183.006 Y135.918 E.0221
G1 X182.629 Y135.858 F30000
G1 F12000
G1 X182.629 Y135.456 E.01236
G1 X73.371 Y135.456 E3.3571
G1 X73.371 Y136.261 E.02472
G1 X182.629 Y136.261 E3.3571
G1 X182.629 Y135.918 E.01052
G1 X73.773 Y135.858 F30000
; LINE_WIDTH: 0.47036
G1 F12000
G1 X182.167 Y135.858 E3.77543
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X180.167 Y135.858 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 20/32
; update layer progress
M73 L20
M991 S0 P19 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.2 I.85 J-.871 P1  F30000
G1 X166.602 Y122.608 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.398 Y122.608 E.55715
G1 X183.398 Y128.148 E.18376
G1 X183.398 Y128.548 E.01327
G1 F14331.075
G1 X183.398 Y128.948 E.01327
G1 F6685.538
G1 X183.398 Y129.348 E.01327
G1 F1920
G1 X183.398 Y129.728 E.01262
G1 F600
G1 X166.602 Y129.728 E.55715
G1 F1920
G1 X166.602 Y129.348 E.01262
G1 F6685.538
G1 X166.602 Y128.948 E.01327
G1 F14331.075
G1 X166.602 Y128.548 E.01327
G1 F15476.087
G1 X166.602 Y128.148 E.01327
G1 X166.602 Y122.668 E.18177
; WIPE_START
G1 X168.602 Y122.661 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X166.21 Y120.94 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X183.79 Y120.94 E.54018
G1 X183.79 Y128.561 E.23417
G1 X183.79 Y128.961 E.01229
G1 F6459.938
G1 X183.79 Y129.361 E.01229
G1 F1800
G1 X183.79 Y129.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y130.12 E.01294
G1 F600
M73 P77 R6
G1 X166.21 Y130.12 E.58316
G1 X166.21 Y129.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y129.361 E.01134
G1 F6459.938
G1 X166.21 Y128.961 E.01229
G1 F12000
G1 X166.21 Y128.561 E.01229
G1 X166.21 Y121 E.23233
; WIPE_START
M204 S10000
G1 X168.21 Y120.993 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X168.243 Y126.235 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X166.95 Y126.235 E.04289
G1 X166.95 Y126.571 E.01112
G1 X168.008 Y127.628 E.04963
G1 X172.427 Y127.628 E.14659
G1 X173.82 Y126.235 E.06535
G1 X174.291 Y126.235 E.01561
G1 X175.684 Y127.628 E.06536
G1 X180.103 Y127.628 E.14659
G1 X181.496 Y126.235 E.06536
G1 X181.967 Y126.235 E.01561
G1 X183.05 Y127.318 E.05079
G1 X183.05 Y127.628 E.0103
G1 X181.732 Y127.628 E.04372
G1 X183.234 Y128.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.935 Y128.452 E.60098
G1 X166.935 Y128.905 E.01668
G1 X183.065 Y128.905 E.59472
G1 X183.065 Y129.357 E.01668
G1 X166.766 Y129.357 E.60098
G1 X166.952 Y127.978 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y127.978 E.4443
G1 X183.006 Y124.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y123 E.04368
G1 X166.994 Y123 E.49198
G1 X166.994 Y125.843 E.08737
G1 X183.006 Y125.843 E.49198
G1 X183.006 Y124.482 E.04184
G1 X182.629 Y124.422 F30000
G1 F12000
G1 X182.629 Y123.377 E.0321
G1 X167.371 Y123.377 E.46881
G1 X167.371 Y125.466 E.0642
G1 X182.629 Y125.466 E.46881
G1 X182.629 Y124.482 E.03025
G1 X182.252 Y124.422 F30000
G1 F12000
G1 X182.252 Y123.754 E.02051
G1 X167.748 Y123.754 E.44564
G1 X167.748 Y125.089 E.04102
G1 X182.252 Y125.089 E.44564
G1 X182.252 Y124.482 E.01867
G1 X181.824 Y124.422 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y124.182 E.00935
G1 X168.176 Y124.182 E.53272
G1 X168.176 Y124.661 E.0187
G1 X181.824 Y124.661 E.53272
G1 X181.824 Y124.482 E.00701
; WIPE_START
G1 X181.824 Y124.661 E-.06822
G1 X180.003 Y124.661 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y121.877 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.074 Y122.385 E.0221
G1 X182.541 Y122.385
G1 X183.583 Y121.343 E.04528
G1 X183.245 Y121.147
G1 X182.007 Y122.385 E.05379
G1 X181.474 Y122.385
G1 X182.712 Y121.147 E.05379
G1 X182.179 Y121.147
G1 X180.941 Y122.385 E.05379
G1 X180.408 Y122.385
G1 X181.646 Y121.147 E.05379
G1 X181.112 Y121.147
G1 X179.874 Y122.385 E.05379
G1 X179.341 Y122.385
G1 X180.579 Y121.147 E.05379
G1 X180.046 Y121.147
G1 X178.808 Y122.385 E.05379
G1 X178.275 Y122.385
G1 X179.513 Y121.147 E.05379
G1 X178.979 Y121.147
G1 X177.741 Y122.385 E.05379
G1 X177.208 Y122.385
G1 X178.446 Y121.147 E.05379
G1 X177.913 Y121.147
G1 X176.675 Y122.385 E.05379
G1 X176.142 Y122.385
G1 X177.38 Y121.147 E.05379
G1 X176.846 Y121.147
G1 X175.608 Y122.385 E.05379
G1 X175.075 Y122.385
G1 X176.313 Y121.147 E.05379
G1 X175.78 Y121.147
G1 X174.542 Y122.385 E.05379
G1 X174.009 Y122.385
G1 X175.247 Y121.147 E.05379
G1 X174.713 Y121.147
G1 X173.475 Y122.385 E.05379
G1 X172.942 Y122.385
G1 X174.18 Y121.147 E.05379
G1 X173.647 Y121.147
G1 X172.409 Y122.385 E.05379
G1 X171.876 Y122.385
G1 X173.113 Y121.147 E.05379
G1 X172.58 Y121.147
G1 X171.342 Y122.385 E.05379
G1 X170.809 Y122.385
G1 X172.047 Y121.147 E.05379
G1 X171.514 Y121.147
G1 X170.276 Y122.385 E.05379
G1 X169.743 Y122.385
G1 X170.98 Y121.147 E.05379
G1 X170.447 Y121.147
G1 X169.209 Y122.385 E.05379
G1 X168.676 Y122.385
G1 X169.914 Y121.147 E.05379
G1 X169.381 Y121.147
G1 X168.143 Y122.385 E.05379
G1 X167.61 Y122.385
G1 X168.847 Y121.147 E.05379
G1 X168.314 Y121.147
G1 X167.076 Y122.385 E.05379
G1 X166.543 Y122.385
G1 X167.781 Y121.147 E.05379
G1 X167.248 Y121.147
G1 X166.417 Y121.978 E.03608
; WIPE_START
M204 S10000
G1 X167.248 Y121.147 E-.44617
G1 X167.781 Y121.147 E-.20264
G1 X167.574 Y121.354 E-.11119
; WIPE_END
G1 E-.04 F1800
G1 X160.03 Y122.511 Z4.4 F30000
G1 X159.398 Y122.608 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X159.398 Y128.148 E.18376
G1 X159.398 Y128.548 E.01327
G1 F14331.075
G1 X159.398 Y128.948 E.01327
G1 F6685.538
G1 X159.398 Y129.348 E.01327
G1 F1920
G1 X159.398 Y129.728 E.01262
G1 F600
G1 X152.602 Y129.728 E.22543
G1 F1920
G1 X152.602 Y129.348 E.01262
G1 F6685.538
G1 X152.602 Y128.948 E.01327
G1 F14331.075
G1 X152.602 Y128.548 E.01327
G1 F15476.087
G1 X152.602 Y128.148 E.01327
G1 X152.602 Y122.608 E.18376
G1 X159.338 Y122.608 E.22344
; WIPE_START
G1 X159.36 Y124.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.79 Y120.94 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X159.79 Y128.561 E.23417
G1 X159.79 Y128.961 E.01229
G1 F6459.938
G1 X159.79 Y129.361 E.01229
G1 F1800
G1 X159.79 Y129.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X159.79 Y130.12 E.01294
G1 F600
G1 X152.21 Y130.12 E.25144
G1 X152.21 Y129.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y129.361 E.01134
G1 F6459.938
G1 X152.21 Y128.961 E.01229
G1 F12000
G1 X152.21 Y128.561 E.01229
G1 X152.21 Y120.94 E.23417
G1 X159.73 Y120.94 E.23107
M204 S10000
G1 X159.583 Y121.88 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X159.077 Y122.385 E.02195
G1 X158.544 Y122.385
G1 X159.583 Y121.347 E.04513
G1 X159.249 Y121.147
G1 X158.011 Y122.385 E.05379
G1 X157.478 Y122.385
G1 X158.716 Y121.147 E.05379
G1 X158.182 Y121.147
G1 X156.944 Y122.385 E.05379
G1 X156.411 Y122.385
G1 X157.649 Y121.147 E.05379
G1 X157.116 Y121.147
G1 X155.878 Y122.385 E.05379
G1 X155.345 Y122.385
G1 X156.582 Y121.147 E.05379
G1 X156.049 Y121.147
G1 X154.811 Y122.385 E.05379
G1 X154.278 Y122.385
G1 X155.516 Y121.147 E.05379
G1 X154.983 Y121.147
G1 X153.745 Y122.385 E.05379
G1 X153.212 Y122.385
G1 X154.449 Y121.147 E.05379
G1 X153.916 Y121.147
G1 X152.678 Y122.385 E.05379
G1 X152.417 Y122.113
G1 X153.383 Y121.147 E.04196
G1 X152.85 Y121.147
G1 X152.417 Y121.58 E.01878
; WIPE_START
M204 S10000
G1 X152.85 Y121.147 E-.23231
G1 X153.383 Y121.147 E-.20264
G1 X152.778 Y121.752 E-.32505
; WIPE_END
G1 E-.04 F1800
G1 X159.006 Y124.022 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y123 E.03139
G1 X152.994 Y123 E.18472
G1 X152.994 Y125.043 E.06279
G1 X159.006 Y125.043 E.18472
G1 X159.006 Y124.082 E.02955
G1 X158.629 Y124.022 F30000
G1 F12000
G1 X158.629 Y123.377 E.01981
G1 X153.371 Y123.377 E.16155
G1 X153.371 Y124.666 E.03961
G1 X158.629 Y124.666 E.16155
G1 X158.629 Y124.082 E.01796
G1 X158.212 Y124.022 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X158.212 Y123.794 E.00848
G1 X153.788 Y123.794 E.16444
G1 X153.788 Y124.25 E.01695
G1 X158.212 Y124.25 E.16444
G1 X158.212 Y124.082 E.00625
G1 X156.511 Y125.435 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X158.139 Y125.435 E.05401
G1 X159.05 Y126.346 E.04271
G1 X159.05 Y125.654 E.02295
G1 X157.075 Y127.628 E.09262
G1 X155.447 Y127.628 E.05401
G1 X152.952 Y127.978 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y127.978 E.16725
G1 X159.234 Y128.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X152.935 Y128.452 E.23226
G1 X152.935 Y128.905 E.01668
G1 X159.065 Y128.905 E.22601
G1 X159.065 Y129.357 E.01668
G1 X152.766 Y129.357 E.23226
; WIPE_START
G1 X154.766 Y129.357 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I.469 J-1.123 P1  F30000
G1 X138.602 Y122.608 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X145.398 Y122.608 E.22543
G1 X145.398 Y128.148 E.18376
G1 X145.398 Y128.548 E.01327
G1 F14331.075
G1 X145.398 Y128.948 E.01327
G1 F6685.538
G1 X145.398 Y129.348 E.01327
G1 F1920
G1 X145.398 Y129.728 E.01262
G1 F600
G1 X138.602 Y129.728 E.22543
G1 F1920
G1 X138.602 Y129.348 E.01262
G1 F6685.538
G1 X138.602 Y128.948 E.01327
G1 F14331.075
G1 X138.602 Y128.548 E.01327
G1 F15476.087
G1 X138.602 Y128.148 E.01327
G1 X138.602 Y122.668 E.18177
; WIPE_START
G1 X140.602 Y122.65 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.21 Y120.94 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X145.79 Y120.94 E.23291
G1 X145.79 Y128.561 E.23417
G1 X145.79 Y128.961 E.01229
G1 F6459.938
G1 X145.79 Y129.361 E.01229
G1 F1800
G1 X145.79 Y129.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X145.79 Y130.12 E.01294
G1 F600
G1 X138.21 Y130.12 E.25144
G1 X138.21 Y129.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y129.361 E.01134
G1 F6459.938
G1 X138.21 Y128.961 E.01229
G1 F12000
G1 X138.21 Y128.561 E.01229
G1 X138.21 Y121 E.23233
; WIPE_START
M204 S10000
M73 P78 R6
G1 X140.21 Y120.984 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X140.095 Y127.628 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X141.723 Y127.628 E.05401
G1 X143.917 Y125.435 E.10288
G1 X142.787 Y125.435 E.03746
G1 X144.98 Y127.628 E.10288
G1 X145.05 Y127.628 E.0023
G1 X145.05 Y126.069 E.05172
G1 X145.006 Y125.043 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y123 E.06279
G1 X138.994 Y123 E.18472
G1 X138.994 Y125.043 E.06279
G1 X144.946 Y125.043 E.18288
G1 X144.629 Y124.666 F30000
G1 F12000
G1 X144.629 Y123.377 E.03961
G1 X139.371 Y123.377 E.16155
G1 X139.371 Y124.666 E.03961
G1 X144.569 Y124.666 E.1597
G1 X144.212 Y124.25 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X144.212 Y123.794 E.01695
G1 X139.788 Y123.794 E.16444
G1 X139.788 Y124.25 E.01695
G1 X144.152 Y124.25 E.16221
; WIPE_START
G1 X142.152 Y124.25 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y122.015 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.213 Y122.385 E.01608
G1 X144.679 Y122.385
G1 X145.583 Y121.482 E.03925
G1 X145.384 Y121.147
G1 X144.146 Y122.385 E.05379
G1 X143.613 Y122.385
G1 X144.851 Y121.147 E.05379
G1 X144.318 Y121.147
G1 X143.08 Y122.385 E.05379
G1 X142.546 Y122.385
G1 X143.784 Y121.147 E.05379
G1 X143.251 Y121.147
G1 X142.013 Y122.385 E.05379
G1 X141.48 Y122.385
G1 X142.718 Y121.147 E.05379
G1 X142.185 Y121.147
G1 X140.947 Y122.385 E.05379
G1 X140.413 Y122.385
G1 X141.651 Y121.147 E.05379
G1 X141.118 Y121.147
G1 X139.88 Y122.385 E.05379
G1 X139.347 Y122.385
G1 X140.585 Y121.147 E.05379
G1 X140.051 Y121.147
G1 X138.814 Y122.385 E.05379
G1 X138.417 Y122.248
G1 X139.518 Y121.147 E.04784
G1 X138.985 Y121.147
G1 X138.417 Y121.715 E.02466
; WIPE_START
M204 S10000
G1 X138.985 Y121.147 E-.30502
G1 X139.518 Y121.147 E-.20264
G1 X139.049 Y121.617 E-.25235
; WIPE_END
G1 E-.04 F1800
G1 X138.952 Y127.978 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y127.978 E.16725
G1 X145.234 Y128.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X138.935 Y128.452 E.23226
G1 X138.935 Y128.905 E.01668
G1 X145.065 Y128.905 E.22601
G1 X145.065 Y129.357 E.01668
G1 X138.766 Y129.357 E.23226
; WIPE_START
G1 X140.766 Y129.357 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I.711 J-.987 P1  F30000
G1 X131.398 Y122.608 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.398 Y128.148 E.18376
G1 X131.398 Y128.548 E.01327
G1 F14331.075
G1 X131.398 Y128.948 E.01327
G1 F6685.538
G1 X131.398 Y129.348 E.01327
G1 F1920
G1 X131.398 Y129.728 E.01262
G1 F600
G1 X124.602 Y129.728 E.22543
G1 F1920
G1 X124.602 Y129.348 E.01262
G1 F6685.538
G1 X124.602 Y128.948 E.01327
G1 F14331.075
G1 X124.602 Y128.548 E.01327
G1 F15476.087
G1 X124.602 Y128.148 E.01327
G1 X124.602 Y122.608 E.18376
G1 X131.338 Y122.608 E.22344
; WIPE_START
G1 X131.36 Y124.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.79 Y120.94 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X131.79 Y128.561 E.23417
G1 X131.79 Y128.961 E.01229
G1 F6459.938
G1 X131.79 Y129.361 E.01229
G1 F1800
G1 X131.79 Y129.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X131.79 Y130.12 E.01294
G1 F600
G1 X124.21 Y130.12 E.25144
G1 X124.21 Y129.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y129.361 E.01134
G1 F6459.938
G1 X124.21 Y128.961 E.01229
G1 F12000
G1 X124.21 Y128.561 E.01229
G1 X124.21 Y120.94 E.23417
G1 X131.73 Y120.94 E.23107
; WIPE_START
M204 S10000
G1 X131.746 Y122.94 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.815 Y122.385 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X131.583 Y121.617 E.03337
G1 X131.519 Y121.147
G1 X130.281 Y122.385 E.05379
G1 X129.748 Y122.385
G1 X130.986 Y121.147 E.05379
G1 X130.453 Y121.147
G1 X129.215 Y122.385 E.05379
G1 X128.682 Y122.385
G1 X129.92 Y121.147 E.05379
G1 X129.386 Y121.147
G1 X128.148 Y122.385 E.05379
G1 X127.615 Y122.385
G1 X128.853 Y121.147 E.05379
G1 X128.32 Y121.147
G1 X127.082 Y122.385 E.05379
G1 X126.549 Y122.385
G1 X127.787 Y121.147 E.05379
G1 X127.253 Y121.147
G1 X126.015 Y122.385 E.05379
G1 X125.482 Y122.385
G1 X126.72 Y121.147 E.05379
G1 X126.187 Y121.147
G1 X124.949 Y122.385 E.05379
G1 X124.417 Y122.384
G1 X125.654 Y121.147 E.05372
G1 X125.12 Y121.147
G1 X124.417 Y121.85 E.03054
; WIPE_START
M204 S10000
G1 X125.12 Y121.147 E-.37774
G1 X125.654 Y121.147 E-.20264
G1 X125.319 Y121.482 E-.17962
; WIPE_END
G1 E-.04 F1800
G1 X124.95 Y127.421 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.95 Y127.628 E.00687
G1 X126.372 Y127.628 E.04714
G1 X128.565 Y125.435 E.10288
G1 X127.435 Y125.435 E.03746
G1 X129.628 Y127.628 E.10288
G1 X131.05 Y127.628 E.04714
G1 X131.05 Y127.421 E.00687
G1 X131.234 Y128.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X124.935 Y128.452 E.23226
G1 X124.935 Y128.905 E.01668
G1 X131.065 Y128.905 E.22601
G1 X131.065 Y129.357 E.01668
G1 X124.766 Y129.357 E.23226
G1 X124.952 Y127.978 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y127.978 E.16725
G1 X131.006 Y124.022 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y123 E.03139
G1 X124.994 Y123 E.18472
G1 X124.994 Y125.043 E.06279
G1 X131.006 Y125.043 E.18472
G1 X131.006 Y124.082 E.02955
G1 X130.629 Y124.022 F30000
G1 F12000
G1 X130.629 Y123.377 E.01981
G1 X125.371 Y123.377 E.16155
G1 X125.371 Y124.666 E.03961
G1 X130.629 Y124.666 E.16155
G1 X130.629 Y124.082 E.01796
G1 X130.212 Y124.022 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X130.212 Y123.794 E.00848
G1 X125.788 Y123.794 E.16444
G1 X125.788 Y124.25 E.01695
G1 X130.212 Y124.25 E.16444
G1 X130.212 Y124.082 E.00625
; WIPE_START
G1 X130.212 Y124.25 E-.06386
G1 X128.38 Y124.25 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X120.78 Y123.548 Z4.4 F30000
G1 X110.602 Y122.608 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X117.398 Y122.608 E.22543
G1 X117.398 Y128.148 E.18376
G1 X117.398 Y128.548 E.01327
G1 F14331.075
G1 X117.398 Y128.948 E.01327
G1 F6685.538
G1 X117.398 Y129.348 E.01327
G1 F1920
G1 X117.398 Y129.728 E.01262
G1 F600
G1 X110.602 Y129.728 E.22543
G1 F1920
G1 X110.602 Y129.348 E.01262
G1 F6685.538
G1 X110.602 Y128.948 E.01327
G1 F14331.075
G1 X110.602 Y128.548 E.01327
G1 F15476.087
G1 X110.602 Y128.148 E.01327
G1 X110.602 Y122.668 E.18177
; WIPE_START
G1 X112.602 Y122.65 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X110.21 Y120.94 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X117.79 Y120.94 E.23291
G1 X117.79 Y128.561 E.23417
G1 X117.79 Y128.961 E.01229
G1 F6459.938
G1 X117.79 Y129.361 E.01229
G1 F1800
G1 X117.79 Y129.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X117.79 Y130.12 E.01294
G1 F600
G1 X110.21 Y130.12 E.25144
G1 X110.21 Y129.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y129.361 E.01134
G1 F6459.938
G1 X110.21 Y128.961 E.01229
G1 F12000
G1 X110.21 Y128.561 E.01229
G1 X110.21 Y121 E.23233
; WIPE_START
M204 S10000
G1 X112.21 Y120.984 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X110.95 Y126.069 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y127.628 E.05172
G1 X111.02 Y127.628 E.0023
G1 X113.213 Y125.435 E.10288
G1 X112.083 Y125.435 E.03746
G1 X114.277 Y127.628 E.10288
G1 X115.905 Y127.628 E.05401
G1 X117.234 Y128.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X110.935 Y128.452 E.23226
G1 X110.935 Y128.905 E.01668
G1 X117.065 Y128.905 E.22601
G1 X117.065 Y129.357 E.01668
G1 X110.766 Y129.357 E.23226
G1 X110.952 Y127.978 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y127.978 E.16725
G1 X117.006 Y124.022 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y123 E.03139
G1 X110.994 Y123 E.18472
G1 X110.994 Y125.043 E.06279
G1 X117.006 Y125.043 E.18472
G1 X117.006 Y124.082 E.02955
G1 X116.629 Y124.022 F30000
G1 F12000
G1 X116.629 Y123.377 E.01981
G1 X111.371 Y123.377 E.16155
G1 X111.371 Y124.666 E.03961
G1 X116.629 Y124.666 E.16155
G1 X116.629 Y124.082 E.01796
G1 X116.212 Y124.022 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X116.212 Y123.794 E.00848
G1 X111.788 Y123.794 E.16444
G1 X111.788 Y124.25 E.01695
G1 X116.212 Y124.25 E.16444
G1 X116.212 Y124.082 E.00625
; WIPE_START
G1 X116.212 Y124.25 E-.06386
G1 X114.38 Y124.25 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X117.583 Y121.753 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X116.95 Y122.385 E.02749
G1 X116.417 Y122.385
G1 X117.583 Y121.219 E.05066
G1 X117.121 Y121.147
G1 X115.884 Y122.385 E.05379
G1 X115.35 Y122.385
G1 X116.588 Y121.147 E.05379
G1 X116.055 Y121.147
G1 X114.817 Y122.385 E.05379
G1 X114.284 Y122.385
G1 X115.522 Y121.147 E.05379
G1 X114.988 Y121.147
G1 X113.75 Y122.385 E.05379
G1 X113.217 Y122.385
G1 X114.455 Y121.147 E.05379
G1 X113.922 Y121.147
G1 X112.684 Y122.385 E.05379
G1 X112.151 Y122.385
G1 X113.389 Y121.147 E.05379
G1 X112.855 Y121.147
G1 X111.617 Y122.385 E.05379
G1 X111.084 Y122.385
G1 X112.322 Y121.147 E.05379
G1 X111.789 Y121.147
G1 X110.551 Y122.385 E.05379
G1 X110.417 Y121.986
G1 X111.256 Y121.147 E.03642
; WIPE_START
M204 S10000
G1 X110.417 Y121.986 E-.45045
G1 X110.551 Y122.385 E-.16014
G1 X110.829 Y122.107 E-.14941
; WIPE_END
G1 E-.04 F1800
G1 X103.398 Y122.608 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.398 Y128.148 E.18376
G1 X103.398 Y128.548 E.01327
G1 F14331.075
G1 X103.398 Y128.948 E.01327
G1 F6685.538
G1 X103.398 Y129.348 E.01327
G1 F1920
G1 X103.398 Y129.728 E.01262
G1 F600
G1 X96.602 Y129.728 E.22543
G1 F1920
G1 X96.602 Y129.348 E.01262
G1 F6685.538
G1 X96.602 Y128.948 E.01327
G1 F14331.075
G1 X96.602 Y128.548 E.01327
G1 F15476.087
G1 X96.602 Y128.148 E.01327
G1 X96.602 Y122.608 E.18376
G1 X103.338 Y122.608 E.22344
; WIPE_START
G1 X103.36 Y124.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.79 Y120.94 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X103.79 Y128.561 E.23417
G1 X103.79 Y128.961 E.01229
G1 F6459.938
G1 X103.79 Y129.361 E.01229
G1 F1800
G1 X103.79 Y129.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X103.79 Y130.12 E.01294
G1 F600
G1 X96.21 Y130.12 E.25144
G1 X96.21 Y129.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y129.361 E.01134
G1 F6459.938
G1 X96.21 Y128.961 E.01229
G1 F12000
G1 X96.21 Y128.561 E.01229
G1 X96.21 Y120.94 E.23417
G1 X103.73 Y120.94 E.23107
M204 S10000
G1 X103.583 Y121.888 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X103.085 Y122.385 E.02161
G1 X102.552 Y122.385
G1 X103.583 Y121.355 E.04478
G1 X103.257 Y121.147
G1 X102.019 Y122.385 E.05379
G1 X101.486 Y122.385
G1 X102.723 Y121.147 E.05379
G1 X102.19 Y121.147
G1 X100.952 Y122.385 E.05379
G1 X100.419 Y122.385
G1 X101.657 Y121.147 E.05379
G1 X101.124 Y121.147
G1 X99.886 Y122.385 E.05379
G1 X99.353 Y122.385
G1 X100.59 Y121.147 E.05379
G1 X100.057 Y121.147
G1 X98.819 Y122.385 E.05379
G1 X98.286 Y122.385
G1 X99.524 Y121.147 E.05379
G1 X98.991 Y121.147
G1 X97.753 Y122.385 E.05379
G1 X97.22 Y122.385
G1 X98.457 Y121.147 E.05379
G1 X97.924 Y121.147
G1 X96.686 Y122.385 E.05379
G1 X96.417 Y122.121
G1 X97.391 Y121.147 E.0423
G1 X96.858 Y121.147
G1 X96.417 Y121.588 E.01913
; WIPE_START
M204 S10000
G1 X96.858 Y121.147 E-.23659
G1 X97.391 Y121.147 E-.20264
G1 X96.794 Y121.744 E-.32077
; WIPE_END
G1 E-.04 F1800
M73 P78 R5
G1 X96.952 Y127.978 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y127.978 E.16725
G1 X103.234 Y128.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X96.935 Y128.452 E.23226
G1 X96.935 Y128.905 E.01668
G1 X103.065 Y128.905 E.22601
G1 X103.065 Y129.357 E.01668
G1 X96.766 Y129.357 E.23226
G1 X100.553 Y127.628 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X98.925 Y127.628 E.05401
G1 X96.95 Y125.654 E.09262
G1 X96.95 Y126.346 E.02294
G1 X97.861 Y125.435 E.04271
G1 X99.489 Y125.435 E.05401
G1 X103.006 Y124.022 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y123 E.03139
G1 X96.994 Y123 E.18472
G1 X96.994 Y125.043 E.06279
G1 X103.006 Y125.043 E.18472
G1 X103.006 Y124.082 E.02955
G1 X102.629 Y124.022 F30000
G1 F12000
G1 X102.629 Y123.377 E.01981
G1 X97.371 Y123.377 E.16155
G1 X97.371 Y124.666 E.03961
G1 X102.629 Y124.666 E.16155
G1 X102.629 Y124.082 E.01796
G1 X102.212 Y124.022 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X102.212 Y123.794 E.00848
G1 X97.788 Y123.794 E.16444
G1 X97.788 Y124.25 E.01695
G1 X102.212 Y124.25 E.16444
G1 X102.212 Y124.082 E.00625
; WIPE_START
G1 X102.212 Y124.25 E-.06386
G1 X100.38 Y124.25 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X92.832 Y123.121 Z4.4 F30000
G1 X89.398 Y122.608 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.398 Y128.148 E.18376
G1 X89.398 Y128.548 E.01327
G1 F14331.075
G1 X89.398 Y128.948 E.01327
G1 F6685.538
M73 P79 R5
G1 X89.398 Y129.348 E.01327
G1 F1920
G1 X89.398 Y129.728 E.01262
G1 F600
G1 X72.602 Y129.728 E.55715
G1 F1920
G1 X72.602 Y129.348 E.01262
G1 F6685.538
G1 X72.602 Y128.948 E.01327
G1 F14331.075
G1 X72.602 Y128.548 E.01327
G1 F15476.087
G1 X72.602 Y128.148 E.01327
G1 X72.602 Y122.608 E.18376
G1 X89.338 Y122.608 E.55516
; WIPE_START
G1 X89.36 Y124.608 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.79 Y120.94 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X89.79 Y128.561 E.23417
G1 X89.79 Y128.961 E.01229
G1 F6459.938
G1 X89.79 Y129.361 E.01229
G1 F1800
G1 X89.79 Y129.73 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X89.79 Y130.12 E.01294
G1 F600
G1 X72.21 Y130.12 E.58316
G1 X72.21 Y129.73 E.01294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y129.361 E.01134
G1 F6459.938
G1 X72.21 Y128.961 E.01229
G1 F12000
G1 X72.21 Y128.561 E.01229
G1 X72.21 Y120.94 E.23417
G1 X89.73 Y120.94 E.53834
; WIPE_START
M204 S10000
G1 X89.746 Y122.94 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.221 Y122.385 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X89.583 Y122.023 E.01573
G1 X89.583 Y121.49
G1 X88.687 Y122.385 E.0389
G1 X88.154 Y122.385
G1 X89.392 Y121.147 E.05379
G1 X88.859 Y121.147
G1 X87.621 Y122.385 E.05379
G1 X87.088 Y122.385
G1 X88.326 Y121.147 E.05379
G1 X87.792 Y121.147
G1 X86.554 Y122.385 E.05379
G1 X86.021 Y122.385
G1 X87.259 Y121.147 E.05379
G1 X86.726 Y121.147
G1 X85.488 Y122.385 E.05379
G1 X84.955 Y122.385
G1 X86.192 Y121.147 E.05379
G1 X85.659 Y121.147
G1 X84.421 Y122.385 E.05379
G1 X83.888 Y122.385
G1 X85.126 Y121.147 E.05379
G1 X84.593 Y121.147
G1 X83.355 Y122.385 E.05379
G1 X82.822 Y122.385
G1 X84.059 Y121.147 E.05379
G1 X83.526 Y121.147
G1 X82.288 Y122.385 E.05379
G1 X81.755 Y122.385
G1 X82.993 Y121.147 E.05379
G1 X82.46 Y121.147
G1 X81.222 Y122.385 E.05379
G1 X80.689 Y122.385
G1 X81.926 Y121.147 E.05379
G1 X81.393 Y121.147
G1 X80.155 Y122.385 E.05379
G1 X79.622 Y122.385
G1 X80.86 Y121.147 E.05379
G1 X80.327 Y121.147
G1 X79.089 Y122.385 E.05379
G1 X78.555 Y122.385
G1 X79.793 Y121.147 E.05379
G1 X79.26 Y121.147
G1 X78.022 Y122.385 E.05379
G1 X77.489 Y122.385
G1 X78.727 Y121.147 E.05379
G1 X78.194 Y121.147
G1 X76.956 Y122.385 E.05379
G1 X76.422 Y122.385
G1 X77.66 Y121.147 E.05379
G1 X77.127 Y121.147
G1 X75.889 Y122.385 E.05379
G1 X75.356 Y122.385
G1 X76.594 Y121.147 E.05379
G1 X76.061 Y121.147
G1 X74.823 Y122.385 E.05379
G1 X74.289 Y122.385
G1 X75.527 Y121.147 E.05379
G1 X74.994 Y121.147
G1 X73.756 Y122.385 E.05379
G1 X73.223 Y122.385
G1 X74.461 Y121.147 E.05379
G1 X73.928 Y121.147
G1 X72.69 Y122.385 E.05379
G1 X72.417 Y122.124
G1 X73.394 Y121.147 E.04245
G1 X72.861 Y121.147
G1 X72.417 Y121.591 E.01928
; WIPE_START
M204 S10000
G1 X72.861 Y121.147 E-.23842
G1 X73.394 Y121.147 E-.20264
G1 X72.801 Y121.741 E-.31894
; WIPE_END
G1 E-.04 F1800
G1 X80.432 Y121.615 Z4.4 F30000
G1 X89.557 Y121.464 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.132018
G1 F15000
G1 X89.557 Y121.129 E.00244
; WIPE_START
G1 X89.557 Y121.464 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.006 Y124.422 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y123 E.04368
G1 X72.994 Y123 E.49198
G1 X72.994 Y125.843 E.08737
G1 X89.006 Y125.843 E.49198
G1 X89.006 Y124.482 E.04184
G1 X88.629 Y125.466 F30000
G1 F12000
G1 X88.629 Y123.377 E.0642
G1 X73.371 Y123.377 E.46881
G1 X73.371 Y125.466 E.0642
G1 X88.569 Y125.466 E.46697
G1 X88.252 Y124.422 F30000
G1 F12000
G1 X88.252 Y123.754 E.02051
G1 X73.748 Y123.754 E.44564
G1 X73.748 Y125.089 E.04102
G1 X88.252 Y125.089 E.44564
G1 X88.252 Y124.482 E.01867
G1 X87.824 Y124.422 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X87.824 Y124.182 E.00935
G1 X74.176 Y124.182 E.53272
G1 X74.176 Y124.661 E.0187
G1 X87.824 Y124.661 E.53272
G1 X87.824 Y124.482 E.00701
G1 X89.234 Y128.452 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X72.935 Y128.452 E.60098
G1 X72.935 Y128.905 E.01668
G1 X89.065 Y128.905 E.59472
G1 X89.065 Y129.357 E.01668
G1 X72.766 Y129.357 E.60098
G1 X72.952 Y127.978 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y127.978 E.4443
G1 X74.268 Y127.628 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.95 Y127.628 E.04371
G1 X72.95 Y127.318 E.0103
G1 X74.033 Y126.235 E.05079
G1 X74.504 Y126.235 E.01561
G1 X75.897 Y127.628 E.06535
G1 X80.316 Y127.628 E.14659
G1 X81.709 Y126.235 E.06536
G1 X82.18 Y126.235 E.01561
G1 X83.573 Y127.628 E.06535
G1 X87.992 Y127.628 E.14659
G1 X89.05 Y126.571 E.04963
G1 X89.05 Y126.235 E.01112
G1 X87.757 Y126.235 E.04289
; WIPE_START
G1 X89.05 Y126.235 E-.49138
G1 X89.05 Y126.571 E-.12738
G1 X88.787 Y126.833 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X96.35 Y127.861 Z4.4 F30000
G1 X138.602 Y133.602 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X138.602 Y132.463 E.03777
G1 X138.602 Y132.063 E.01327
G1 F14852.35
G1 X138.602 Y132.004 E.00199
G1 F13500
G1 X145.398 Y132.004 E.22543
G1 F14852.35
G1 X145.398 Y132.063 E.00199
G1 F15476.087
G1 X145.398 Y132.463 E.01327
G1 X145.398 Y133.602 E.03777
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y132.463 E.03777
G1 X152.602 Y132.063 E.01327
G1 F14852.35
G1 X152.602 Y132.004 E.00199
G1 F13500
G1 X159.398 Y132.004 E.22543
G1 F14852.35
G1 X159.398 Y132.063 E.00199
G1 F15476.087
G1 X159.398 Y132.463 E.01327
G1 X159.398 Y133.602 E.03777
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y132.463 E.03777
G1 X166.602 Y132.063 E.01327
G1 F14852.35
G1 X166.602 Y132.004 E.00199
G1 F13500
G1 X183.398 Y132.004 E.55715
G1 F14852.35
G1 X183.398 Y132.063 E.00199
G1 F15476.087
G1 X183.398 Y132.463 E.01327
G1 X183.398 Y136.553 E.13565
G1 X72.602 Y136.553 E3.6753
G1 X72.602 Y132.463 E.13565
G1 X72.602 Y132.063 E.01327
G1 F14852.35
G1 X72.602 Y132.004 E.00199
G1 F13500
G1 X89.398 Y132.004 E.55715
G1 F14852.35
G1 X89.398 Y132.063 E.00199
G1 F15476.087
G1 X89.398 Y132.463 E.01327
G1 X89.398 Y133.602 E.03777
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y132.463 E.03777
G1 X96.602 Y132.063 E.01327
G1 F14852.35
G1 X96.602 Y132.004 E.00199
G1 F13500
G1 X103.398 Y132.004 E.22543
G1 F14852.35
G1 X103.398 Y132.063 E.00199
G1 F15476.087
G1 X103.398 Y132.463 E.01327
G1 X103.398 Y133.602 E.03777
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y132.463 E.03777
G1 X110.602 Y132.063 E.01327
G1 F14852.35
G1 X110.602 Y132.004 E.00199
G1 F13500
G1 X117.398 Y132.004 E.22543
G1 F14852.35
G1 X117.398 Y132.063 E.00199
G1 F15476.087
G1 X117.398 Y132.463 E.01327
G1 X117.398 Y133.602 E.03777
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y132.463 E.03777
G1 X124.602 Y132.063 E.01327
G1 F14852.35
G1 X124.602 Y132.004 E.00199
G1 F13500
G1 X131.398 Y132.004 E.22543
G1 F14852.35
G1 X131.398 Y132.063 E.00199
G1 F15476.087
G1 X131.398 Y132.463 E.01327
G1 X131.398 Y133.602 E.03777
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y132.85 E.01106
G1 X138.21 Y132.45 E.01229
G1 F6459.938
G1 X138.21 Y132.05 E.01229
G1 F1800
G1 X138.21 Y131.681 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X138.21 Y131.612 E.0023
G1 X145.79 Y131.612 E.25144
G1 X145.79 Y131.681 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X145.79 Y132.05 E.01134
G1 F6459.938
G1 X145.79 Y132.45 E.01229
G1 F12000
G1 X145.79 Y132.85 E.01229
G1 X145.79 Y133.21 E.01106
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y132.85 E.01106
G1 X152.21 Y132.45 E.01229
G1 F6459.938
G1 X152.21 Y132.05 E.01229
G1 F1800
G1 X152.21 Y131.681 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X152.21 Y131.612 E.0023
G1 X159.79 Y131.612 E.25144
G1 X159.79 Y131.681 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X159.79 Y132.05 E.01134
G1 F6459.938
G1 X159.79 Y132.45 E.01229
G1 F12000
G1 X159.79 Y132.85 E.01229
G1 X159.79 Y133.21 E.01106
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y132.85 E.01106
G1 X166.21 Y132.45 E.01229
G1 F6459.938
G1 X166.21 Y132.05 E.01229
G1 F1800
G1 X166.21 Y131.681 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X166.21 Y131.612 E.0023
G1 X183.79 Y131.612 E.58316
G1 X183.79 Y131.681 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y132.05 E.01134
G1 F6459.938
G1 X183.79 Y132.45 E.01229
G1 F12000
G1 X183.79 Y132.85 E.01229
G1 X183.79 Y136.945 E.12583
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y136.945 E3.42854
G1 X72.21 Y132.85 E.12583
G1 X72.21 Y132.45 E.01229
G1 F6459.938
G1 X72.21 Y132.05 E.01229
G1 F1800
G1 X72.21 Y131.681 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X72.21 Y131.612 E.0023
G1 X89.79 Y131.612 E.58316
G1 X89.79 Y131.681 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X89.79 Y132.05 E.01134
G1 F6459.938
G1 X89.79 Y132.45 E.01229
G1 F12000
G1 X89.79 Y132.85 E.01229
G1 X89.79 Y133.21 E.01106
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y132.85 E.01106
G1 X96.21 Y132.45 E.01229
G1 F6459.938
G1 X96.21 Y132.05 E.01229
G1 F1800
G1 X96.21 Y131.681 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X96.21 Y131.612 E.0023
G1 X103.79 Y131.612 E.25144
G1 X103.79 Y131.681 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X103.79 Y132.05 E.01134
G1 F6459.938
G1 X103.79 Y132.45 E.01229
G1 F12000
G1 X103.79 Y132.85 E.01229
G1 X103.79 Y133.21 E.01106
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y132.85 E.01106
G1 X110.21 Y132.45 E.01229
G1 F6459.938
G1 X110.21 Y132.05 E.01229
G1 F1800
G1 X110.21 Y131.681 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X110.21 Y131.612 E.0023
G1 X117.79 Y131.612 E.25144
G1 X117.79 Y131.681 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X117.79 Y132.05 E.01134
G1 F6459.938
G1 X117.79 Y132.45 E.01229
G1 F12000
G1 X117.79 Y132.85 E.01229
G1 X117.79 Y133.21 E.01106
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y132.85 E.01106
G1 X124.21 Y132.45 E.01229
G1 F6459.938
G1 X124.21 Y132.05 E.01229
G1 F1800
G1 X124.21 Y131.681 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X124.21 Y131.612 E.0023
G1 X131.79 Y131.612 E.25144
G1 X131.79 Y131.681 E.0023
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X131.79 Y132.05 E.01134
G1 F6459.938
G1 X131.79 Y132.45 E.01229
G1 F12000
G1 X131.79 Y132.85 E.01229
G1 X131.79 Y133.21 E.01106
G1 X138.15 Y133.21 E.19542
; WIPE_START
M204 S10000
G1 X138.21 Y132.85 E-.13869
G1 X138.21 Y132.45 E-.152
G1 X138.21 Y132.05 E-.152
G1 X138.21 Y131.681 E-.14022
G1 X138.21 Y131.612 E-.02639
G1 X138.607 Y131.612 E-.15069
; WIPE_END
G1 E-.04 F1800
G1 X146.236 Y131.837 Z4.4 F30000
G1 X167.05 Y132.452 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53261
G1 F12865.282
G1 X167.05 Y132.942 E.01954
G1 X182.95 Y132.942 E.63443
G1 X182.95 Y132.452 E.01954
G1 X167.11 Y132.452 E.63204
M73 P80 R5
G1 X171.896 Y134.208 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X173.524 Y134.208 E.05401
G1 X174.342 Y133.39 E.03835
G1 X173.77 Y133.39 E.01897
G1 X174.587 Y134.208 E.03835
G1 X181.2 Y134.208 E.21936
G1 X182.018 Y133.39 E.03835
G1 X181.446 Y133.39 E.01897
G1 X182.263 Y134.208 E.03835
G1 X183.05 Y134.208 E.02609
G1 X183.025 Y133.39 E.02713
; WIPE_START
G1 X183.05 Y134.208 E-.31079
G1 X182.263 Y134.208 E-.29883
G1 X181.983 Y133.928 E-.15038
; WIPE_END
G1 E-.03999 F1800
G1 X174.351 Y133.96 Z4.4 F30000
G1 X89.159 Y134.318 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.419844
G1 F12000
G1 X89.104 Y134.452 E.00443
G1 X88.91 Y134.597 E.00743
G1 X88.878 Y134.6 E.001
G1 X72.994 Y134.6 E.48786
G1 X72.994 Y136.161 E.04795
G1 X183.006 Y136.161 E3.37896
G1 X183.006 Y134.6 E.04795
G1 X167.122 Y134.6 E.48786
G3 X166.841 Y134.318 I.097 J-.378 E.01282
G1 X166.917 Y133.825 E.01533
G1 X166.806 Y133.962 E.00543
G1 X166.009 Y133.994 E.02449
G1 X159.194 Y133.994 E.20931
G1 X159.039 Y133.912 E.00541
G1 X159.006 Y133.806 E.00341
G1 X159.006 Y132.396 E.04331
G1 X152.994 Y132.396 E.18465
G1 X152.994 Y133.806 E.04331
G1 X152.961 Y133.912 E.00341
G1 X152.806 Y133.994 E.00541
G1 X145.194 Y133.994 E.23377
G1 X145.039 Y133.912 E.00541
G1 X145.006 Y133.806 E.00341
G1 X145.006 Y132.396 E.04331
G1 X138.994 Y132.396 E.18465
G1 X138.994 Y133.806 E.04331
G1 X138.961 Y133.912 E.00341
G1 X138.806 Y133.994 E.00541
G1 X131.194 Y133.994 E.23377
G1 X131.039 Y133.912 E.00541
G1 X131.006 Y133.806 E.00341
G1 X131.006 Y132.396 E.04331
G1 X124.994 Y132.396 E.18465
G1 X124.994 Y133.806 E.04331
G1 X124.961 Y133.912 E.00341
G1 X124.806 Y133.994 E.00541
G1 X117.194 Y133.994 E.23377
G1 X117.039 Y133.912 E.00541
G1 X117.006 Y133.806 E.00341
G1 X117.006 Y132.396 E.04331
G1 X110.994 Y132.396 E.18465
G1 X110.994 Y133.806 E.04331
G1 X110.961 Y133.912 E.00341
G1 X110.806 Y133.994 E.00541
G1 X103.194 Y133.994 E.23377
G1 X103.039 Y133.912 E.00541
G1 X103.006 Y133.806 E.00341
G1 X103.006 Y132.396 E.04331
G1 X96.994 Y132.396 E.18465
G1 X96.994 Y133.806 E.04331
G1 X96.961 Y133.912 E.00341
G1 X96.806 Y133.994 E.00541
G1 X89.483 Y133.994 E.2249
G1 X89.194 Y133.962 E.00893
G1 X89.083 Y133.825 E.00543
G1 X89.15 Y134.259 E.01349
G1 X88.976 Y134.968 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X73.371 Y134.977 E.47946
G1 X73.371 Y135.784 E.0248
G1 X182.629 Y135.784 E3.3571
G1 X182.629 Y134.977 E.0248
G1 X167.122 Y134.977 E.47646
G1 X166.722 Y134.811 E.0133
G1 X166.576 Y134.656 E.00656
G1 X166.481 Y134.371 E.00922
G1 X159.194 Y134.371 E.2239
G1 X158.915 Y134.297 E.00888
G1 X158.727 Y134.124 E.00785
G1 X158.629 Y133.806 E.01025
G1 X158.629 Y132.773 E.03174
G1 X153.371 Y132.773 E.16155
G1 X153.371 Y133.806 E.03174
G1 X153.273 Y134.124 E.01025
G1 X153.085 Y134.297 E.00785
G1 X152.806 Y134.371 E.00888
G1 X145.194 Y134.371 E.23386
G1 X144.915 Y134.297 E.00888
G1 X144.727 Y134.124 E.00785
G1 X144.629 Y133.806 E.01025
G1 X144.629 Y132.773 E.03174
G1 X139.371 Y132.773 E.16155
G1 X139.371 Y133.806 E.03174
G1 X139.273 Y134.124 E.01025
G1 X139.085 Y134.297 E.00785
G1 X138.806 Y134.371 E.00888
G1 X131.194 Y134.371 E.23386
G1 X130.915 Y134.297 E.00888
G1 X130.727 Y134.124 E.00785
G1 X130.629 Y133.806 E.01025
G1 X130.629 Y132.773 E.03174
G1 X125.371 Y132.773 E.16155
G1 X125.371 Y133.806 E.03174
G1 X125.273 Y134.124 E.01025
G1 X125.085 Y134.297 E.00785
G1 X124.806 Y134.371 E.00888
G1 X117.194 Y134.371 E.23386
G1 X116.915 Y134.297 E.00888
G1 X116.727 Y134.124 E.00785
G1 X116.629 Y133.806 E.01025
G1 X116.629 Y132.773 E.03174
G1 X111.371 Y132.773 E.16155
G1 X111.371 Y133.806 E.03174
G1 X111.273 Y134.124 E.01025
G1 X111.085 Y134.297 E.00785
G1 X110.806 Y134.371 E.00888
G1 X103.194 Y134.371 E.23386
G1 X102.915 Y134.297 E.00888
G1 X102.727 Y134.124 E.00785
G1 X102.629 Y133.806 E.01025
G1 X102.629 Y132.773 E.03174
G1 X97.371 Y132.773 E.16155
G1 X97.371 Y133.806 E.03174
G1 X97.273 Y134.124 E.01025
G1 X97.085 Y134.297 E.00785
G1 X96.806 Y134.371 E.00888
G1 X89.519 Y134.371 E.2239
G1 X89.424 Y134.656 E.00922
G1 X89.278 Y134.811 E.00656
G1 X89.029 Y134.941 E.00862
G1 X167.122 Y135.38 F30000
; LINE_WIDTH: 0.47293
G1 F12000
G1 X182.165 Y135.38 E.52711
G1 X166.217 Y134.923 F30000
; LINE_WIDTH: 0.53873
G1 F12000
G1 X166.311 Y135.025 E.00563
; LINE_WIDTH: 0.513403
G1 X166.406 Y135.127 E.00534
G1 X167.122 Y135.38 E.02912
; LINE_WIDTH: 0.494873
G1 X166.721 Y135.358 E.01481
; LINE_WIDTH: 0.538738
G1 X166.319 Y135.336 E.01624
; LINE_WIDTH: 0.537215
G1 X163.944 Y135.336 E.09566
; LINE_WIDTH: 0.490325
G1 X161.569 Y135.336 E.08659
; LINE_WIDTH: 0.453824
G1 X159.194 Y135.336 E.07952
G1 X158.522 Y135.407 E.02263
; LINE_WIDTH: 0.43878
G1 X157.261 Y135.407 E.04068
; LINE_WIDTH: 0.47636
G1 X156 Y135.407 E.04454
; LINE_WIDTH: 0.51394
G1 X154.739 Y135.407 E.0484
; LINE_WIDTH: 0.535246
G1 X153.478 Y135.407 E.05059
G1 X153.027 Y135.332 E.01833
; LINE_WIDTH: 0.56549
G1 X152.806 Y135.336 E.00943
; LINE_WIDTH: 0.537224
G1 X150.269 Y135.336 E.10219
; LINE_WIDTH: 0.49033
G1 X147.731 Y135.336 E.0925
; LINE_WIDTH: 0.453301
G1 X145.194 Y135.336 E.08484
G1 X144.522 Y135.407 E.0226
; LINE_WIDTH: 0.43878
G1 X143.261 Y135.407 E.04068
; LINE_WIDTH: 0.47636
G1 X142 Y135.407 E.04454
; LINE_WIDTH: 0.51394
G1 X140.739 Y135.407 E.0484
; LINE_WIDTH: 0.535246
G1 X139.478 Y135.407 E.05059
G1 X139.027 Y135.332 E.01833
; LINE_WIDTH: 0.56549
G1 X138.806 Y135.336 E.00943
; LINE_WIDTH: 0.537224
G1 X136.269 Y135.336 E.10219
; LINE_WIDTH: 0.49033
G1 X133.731 Y135.336 E.0925
; LINE_WIDTH: 0.453301
G1 X131.194 Y135.336 E.08484
G1 X130.522 Y135.407 E.0226
; LINE_WIDTH: 0.43878
G1 X129.261 Y135.407 E.04068
; LINE_WIDTH: 0.47636
G1 X128 Y135.407 E.04454
; LINE_WIDTH: 0.51394
G1 X126.739 Y135.407 E.0484
; LINE_WIDTH: 0.535246
G1 X125.478 Y135.407 E.05059
G1 X125.027 Y135.332 E.01833
; LINE_WIDTH: 0.56549
G1 X124.806 Y135.336 E.00943
; LINE_WIDTH: 0.537224
G1 X122.269 Y135.336 E.10219
; LINE_WIDTH: 0.49033
G1 X119.731 Y135.336 E.0925
; LINE_WIDTH: 0.453301
G1 X117.194 Y135.336 E.08484
G1 X116.522 Y135.407 E.0226
; LINE_WIDTH: 0.43878
G1 X115.261 Y135.407 E.04068
; LINE_WIDTH: 0.47636
G1 X114 Y135.407 E.04454
; LINE_WIDTH: 0.51394
G1 X112.739 Y135.407 E.0484
; LINE_WIDTH: 0.535246
G1 X111.478 Y135.407 E.05059
G1 X111.027 Y135.332 E.01833
; LINE_WIDTH: 0.56549
G1 X110.806 Y135.336 E.00943
; LINE_WIDTH: 0.537224
G1 X108.269 Y135.336 E.10219
; LINE_WIDTH: 0.49033
G1 X105.731 Y135.336 E.0925
; LINE_WIDTH: 0.453301
G1 X103.194 Y135.336 E.08484
G1 X102.522 Y135.407 E.0226
; LINE_WIDTH: 0.43878
G1 X101.261 Y135.407 E.04068
; LINE_WIDTH: 0.47636
G1 X100 Y135.407 E.04454
; LINE_WIDTH: 0.51394
G1 X98.739 Y135.407 E.0484
; LINE_WIDTH: 0.535246
G1 X97.478 Y135.407 E.05059
G1 X97.027 Y135.332 E.01833
; LINE_WIDTH: 0.56549
G1 X96.806 Y135.336 E.00943
; LINE_WIDTH: 0.542408
G1 X93.243 Y135.336 E.145
; LINE_WIDTH: 0.515421
G1 X89.681 Y135.336 E.13717
G1 X89.046 Y135.373 E.02446
G1 X89.594 Y135.127 E.02311
; LINE_WIDTH: 0.56067
G2 X89.774 Y134.891 I-.394 J-.486 E.01268
; Slow Down Start
; LINE_WIDTH: 0.565433
G1 F3000;_EXTRUDE_SET_SPEED
G1 X89.818 Y134.819 E.00358
G1 X96.806 Y134.819 E.29753
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.537224
;_EXTRUDE_SET_SPEED
G1 X96.864 Y134.815 E.00237
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X96.923 Y134.812 E.00214
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.487585
;_EXTRUDE_SET_SPEED
G1 X96.981 Y134.808 E.00213
G1 X97.271 Y134.625 E.01242
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.41999
;_EXTRUDE_SET_SPEED
G1 X97.584 Y134.337 E.01308
G1 X97.723 Y134.021 E.01061
G2 X97.748 Y133.666 I-1.522 J-.285 E.01095
; Slow Down End
G1 F12000
G1 X97.748 Y133.15 E.01586
G1 X102.252 Y133.15 E.13838
G1 X102.266 Y133.666 E.01587
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X102.277 Y134.021 E.01091
G1 X102.416 Y134.337 E.01061
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.443437
;_EXTRUDE_SET_SPEED
G1 X102.52 Y134.433 E.00463
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X102.624 Y134.529 E.00518
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.500632
;_EXTRUDE_SET_SPEED
G1 X102.729 Y134.625 E.00529
G1 X103.194 Y134.819 E.01881
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.56549
;_EXTRUDE_SET_SPEED
G1 X110.806 Y134.819 E.32411
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.537224
;_EXTRUDE_SET_SPEED
G1 X110.864 Y134.815 E.00237
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X110.923 Y134.812 E.00214
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.487585
;_EXTRUDE_SET_SPEED
G1 X110.981 Y134.808 E.00213
G1 X111.271 Y134.625 E.01242
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.41999
;_EXTRUDE_SET_SPEED
G1 X111.584 Y134.337 E.01308
G1 X111.723 Y134.021 E.01061
G2 X111.748 Y133.666 I-1.522 J-.285 E.01095
; Slow Down End
G1 F12000
G1 X111.748 Y133.15 E.01586
G1 X116.252 Y133.15 E.13838
G1 X116.266 Y133.666 E.01587
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X116.277 Y134.021 E.01091
G1 X116.416 Y134.337 E.01061
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.443437
;_EXTRUDE_SET_SPEED
G1 X116.52 Y134.433 E.00463
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X116.624 Y134.529 E.00518
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.500632
;_EXTRUDE_SET_SPEED
G1 X116.729 Y134.625 E.00529
G1 X117.194 Y134.819 E.01881
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.56549
;_EXTRUDE_SET_SPEED
G1 X124.806 Y134.819 E.32411
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.537224
;_EXTRUDE_SET_SPEED
G1 X124.864 Y134.815 E.00237
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X124.923 Y134.812 E.00214
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.487585
;_EXTRUDE_SET_SPEED
G1 X124.981 Y134.808 E.00213
G1 X125.271 Y134.625 E.01242
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.41999
;_EXTRUDE_SET_SPEED
G1 X125.584 Y134.337 E.01308
G1 X125.723 Y134.021 E.01061
G2 X125.748 Y133.666 I-1.522 J-.285 E.01095
; Slow Down End
G1 F12000
G1 X125.748 Y133.15 E.01586
G1 X130.252 Y133.15 E.13838
G1 X130.266 Y133.666 E.01587
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X130.277 Y134.021 E.01091
G1 X130.416 Y134.337 E.01061
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.443437
;_EXTRUDE_SET_SPEED
G1 X130.52 Y134.433 E.00463
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X130.624 Y134.529 E.00518
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.500632
;_EXTRUDE_SET_SPEED
G1 X130.729 Y134.625 E.00529
G1 X131.194 Y134.819 E.01881
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.56549
;_EXTRUDE_SET_SPEED
G1 X138.806 Y134.819 E.32411
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.537224
;_EXTRUDE_SET_SPEED
G1 X138.864 Y134.815 E.00237
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X138.923 Y134.812 E.00214
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.487585
;_EXTRUDE_SET_SPEED
G1 X138.981 Y134.808 E.00213
G1 X139.271 Y134.625 E.01242
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.41999
;_EXTRUDE_SET_SPEED
G1 X139.584 Y134.337 E.01308
G1 X139.723 Y134.021 E.01061
G2 X139.748 Y133.666 I-1.522 J-.285 E.01095
; Slow Down End
G1 F12000
G1 X139.748 Y133.15 E.01586
G1 X144.252 Y133.15 E.13838
G1 X144.266 Y133.666 E.01587
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X144.277 Y134.021 E.01091
G1 X144.416 Y134.337 E.01061
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.443437
;_EXTRUDE_SET_SPEED
G1 X144.52 Y134.433 E.00463
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X144.624 Y134.529 E.00518
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.500632
;_EXTRUDE_SET_SPEED
G1 X144.729 Y134.625 E.00529
G1 X145.194 Y134.819 E.01881
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.56549
;_EXTRUDE_SET_SPEED
G1 X152.806 Y134.819 E.32411
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.537224
;_EXTRUDE_SET_SPEED
G1 X152.864 Y134.815 E.00237
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X152.923 Y134.812 E.00214
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.487585
;_EXTRUDE_SET_SPEED
G1 X152.981 Y134.808 E.00213
G1 X153.271 Y134.625 E.01242
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.41999
;_EXTRUDE_SET_SPEED
G1 X153.584 Y134.337 E.01308
G1 X153.723 Y134.021 E.01061
G2 X153.748 Y133.666 I-1.522 J-.285 E.01095
; Slow Down End
G1 F12000
G1 X153.748 Y133.15 E.01586
G1 X158.252 Y133.15 E.13838
G1 X158.266 Y133.666 E.01587
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X158.277 Y134.021 E.01091
G1 X158.416 Y134.337 E.01061
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.443437
;_EXTRUDE_SET_SPEED
G1 X158.52 Y134.433 E.00463
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.49033
;_EXTRUDE_SET_SPEED
G1 X158.624 Y134.529 E.00518
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.500628
;_EXTRUDE_SET_SPEED
G1 X158.729 Y134.625 E.00529
G1 X159.194 Y134.819 E.01881
; Slow Down End
; Slow Down Start
; LINE_WIDTH: 0.560665
;_EXTRUDE_SET_SPEED
G1 X166.182 Y134.819 E.29481
G1 X166.198 Y134.866 E.00211
; Slow Down End
G1 X158.542 Y134.953 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X158.832 Y135.03 E.00921
G1 X153.245 Y135.03 E.17169
G1 X153.458 Y134.953 E.00695
G1 X153.896 Y134.549 E.01832
G1 X154.091 Y134.107 E.01485
G1 X154.125 Y133.527 E.01785
G1 X157.875 Y133.527 E.1152
G1 X157.909 Y134.107 E.01785
G1 X158.104 Y134.549 E.01485
G1 X158.498 Y134.912 E.01647
G1 X157.745 Y134.653 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X154.255 Y134.653 E.10721
G1 X154.458 Y134.193 E.01543
G1 X154.491 Y133.904 E.00894
G1 X157.509 Y133.904 E.09273
G1 X157.542 Y134.193 E.00894
G1 X157.72 Y134.598 E.01359
; Slow Down End
G1 X157.178 Y134.278 F30000
; Slow Down Start
; LINE_WIDTH: 0.41446
G1 F3000;_EXTRUDE_SET_SPEED
G1 X154.882 Y134.278 E.06951
; Slow Down End
G1 X143.909 Y134.107 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X144.104 Y134.549 E.01485
G1 X144.542 Y134.953 E.01832
G1 X144.832 Y135.03 E.00921
G1 X139.245 Y135.03 E.17169
G1 X139.458 Y134.953 E.00695
G1 X139.896 Y134.549 E.01832
G1 X140.091 Y134.107 E.01485
G1 X140.125 Y133.527 E.01785
G1 X143.875 Y133.527 E.1152
G1 X143.906 Y134.047 E.01601
G1 X143.745 Y134.653 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X140.255 Y134.653 E.10721
G1 X140.458 Y134.193 E.01543
G1 X140.491 Y133.904 E.00894
G1 X143.509 Y133.904 E.09273
G1 X143.542 Y134.193 E.00894
G1 X143.72 Y134.598 E.01359
; Slow Down End
G1 X143.178 Y134.278 F30000
; Slow Down Start
; LINE_WIDTH: 0.41446
G1 F3000;_EXTRUDE_SET_SPEED
G1 X140.882 Y134.278 E.06951
; Slow Down End
G1 X130.104 Y134.549 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X130.542 Y134.953 E.01832
G1 X130.832 Y135.03 E.00921
G1 X125.245 Y135.03 E.17169
G1 X125.458 Y134.953 E.00695
G1 X125.896 Y134.549 E.01832
G1 X126.091 Y134.107 E.01485
G1 X126.125 Y133.527 E.01785
G1 X129.875 Y133.527 E.1152
G1 X129.909 Y134.107 E.01785
G1 X130.08 Y134.494 E.013
G1 X129.745 Y134.653 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X126.255 Y134.653 E.10721
G1 X126.458 Y134.193 E.01543
G1 X126.491 Y133.904 E.00894
G1 X129.509 Y133.904 E.09273
G1 X129.542 Y134.193 E.00894
G1 X129.72 Y134.598 E.01359
; Slow Down End
G1 X129.178 Y134.278 F30000
; Slow Down Start
; LINE_WIDTH: 0.41446
G1 F3000;_EXTRUDE_SET_SPEED
G1 X126.882 Y134.278 E.06951
; Slow Down End
G1 X116.104 Y134.549 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X116.542 Y134.953 E.01832
G1 X116.832 Y135.03 E.00921
G1 X111.245 Y135.03 E.17169
G1 X111.458 Y134.953 E.00695
G1 X111.896 Y134.549 E.01832
G1 X112.091 Y134.107 E.01485
G1 X112.125 Y133.527 E.01785
G1 X115.875 Y133.527 E.1152
G1 X115.909 Y134.107 E.01785
G1 X116.08 Y134.494 E.013
G1 X115.745 Y134.653 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X112.255 Y134.653 E.10721
G1 X112.458 Y134.193 E.01543
G1 X112.491 Y133.904 E.00894
G1 X115.509 Y133.904 E.09273
G1 X115.542 Y134.193 E.00894
G1 X115.72 Y134.598 E.01359
; Slow Down End
G1 X115.178 Y134.278 F30000
; Slow Down Start
; LINE_WIDTH: 0.41446
G1 F3000;_EXTRUDE_SET_SPEED
G1 X112.882 Y134.278 E.06951
; Slow Down End
G1 X102.104 Y134.549 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X102.542 Y134.953 E.01832
G1 X102.832 Y135.03 E.00921
G1 X97.245 Y135.03 E.17169
G1 X97.458 Y134.953 E.00695
G1 X97.896 Y134.549 E.01832
G1 X98.091 Y134.107 E.01485
G1 X98.125 Y133.527 E.01785
G1 X101.875 Y133.527 E.1152
G1 X101.909 Y134.107 E.01785
G1 X102.08 Y134.494 E.013
G1 X101.745 Y134.653 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X98.255 Y134.653 E.10721
G1 X98.458 Y134.193 E.01543
G1 X98.491 Y133.904 E.00894
G1 X101.509 Y133.904 E.09273
G1 X101.542 Y134.193 E.00894
G1 X101.72 Y134.598 E.01359
; Slow Down End
G1 X101.178 Y134.278 F30000
; Slow Down Start
; LINE_WIDTH: 0.41446
G1 F3000;_EXTRUDE_SET_SPEED
G1 X98.882 Y134.278 E.06951
; Slow Down End
G1 X73.775 Y135.38 F30000
; LINE_WIDTH: 0.472983
G1 F12000
G1 X88.987 Y135.376 E.53309
G1 X88.95 Y132.452 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.53261
G1 F12865.282
G1 X73.05 Y132.452 E.63443
G1 X73.05 Y132.942 E.01954
G1 X88.95 Y132.942 E.63443
G1 X88.95 Y132.512 E.01715
G1 X72.975 Y133.39 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.95 Y134.208 E.02713
G1 X73.737 Y134.208 E.02609
G1 X74.554 Y133.39 E.03835
G1 X73.982 Y133.39 E.01897
G1 X74.8 Y134.208 E.03835
G1 X81.413 Y134.208 E.21936
G1 X82.23 Y133.39 E.03835
G1 X81.658 Y133.39 E.01897
G1 X82.476 Y134.208 E.03835
G1 X84.104 Y134.208 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X82.476 Y134.208 E-.61876
G1 X82.213 Y133.945 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 21/32
; update layer progress
M73 L21
M991 S0 P20 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.4 I.007 J1.217 P1  F30000
G1 X138.602 Y133.602 Z4.4
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X138.602 Y132.784 E.02714
G1 X138.602 Y132.384 E.01327
G1 F13999.876
G1 X138.602 Y131.984 E.01327
G1 F6459.938
G1 X138.602 Y131.584 E.01327
G1 F1800
G1 X138.602 Y131.202 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X138.602 Y130.53 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X138.602 Y130.148 E.01269
G1 F6459.938
G1 X138.602 Y129.748 E.01327
G1 F13999.876
G1 X138.602 Y129.348 E.01327
G1 F15476.087
G1 X138.602 Y128.948 E.01327
G1 X138.602 Y123.408 E.18376
G1 X145.398 Y123.408 E.22543
G1 X145.398 Y128.948 E.18376
G1 X145.398 Y129.348 E.01327
G1 F13999.876
G1 X145.398 Y129.748 E.01327
G1 F6459.938
G1 X145.398 Y130.148 E.01327
G1 F1800
G1 X145.398 Y130.53 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X145.398 Y131.202 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X145.398 Y131.584 E.01269
G1 F6459.938
G1 X145.398 Y131.984 E.01327
G1 F13999.876
G1 X145.398 Y132.384 E.01327
G1 F15476.087
G1 X145.398 Y132.784 E.01327
G1 X145.398 Y133.602 E.02714
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y132.784 E.02714
G1 X152.602 Y132.384 E.01327
G1 F13999.876
G1 X152.602 Y131.984 E.01327
G1 F6459.938
G1 X152.602 Y131.584 E.01327
G1 F1800
G1 X152.602 Y131.202 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X152.602 Y130.53 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X152.602 Y130.148 E.01269
G1 F6459.938
G1 X152.602 Y129.748 E.01327
G1 F13999.876
G1 X152.602 Y129.348 E.01327
G1 F15476.087
G1 X152.602 Y128.948 E.01327
G1 X152.602 Y123.408 E.18376
G1 X159.398 Y123.408 E.22543
G1 X159.398 Y128.948 E.18376
G1 X159.398 Y129.348 E.01327
G1 F13999.876
G1 X159.398 Y129.748 E.01327
G1 F6459.938
G1 X159.398 Y130.148 E.01327
G1 F1800
G1 X159.398 Y130.53 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X159.398 Y131.202 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X159.398 Y131.584 E.01269
G1 F6459.938
G1 X159.398 Y131.984 E.01327
G1 F13999.876
G1 X159.398 Y132.384 E.01327
G1 F15476.087
G1 X159.398 Y132.784 E.01327
G1 X159.398 Y133.602 E.02714
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y132.784 E.02714
G1 X166.602 Y132.384 E.01327
G1 F13999.876
G1 X166.602 Y131.984 E.01327
G1 F6459.938
G1 X166.602 Y131.584 E.01327
G1 F1800
G1 X166.602 Y131.202 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X166.602 Y130.53 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X166.602 Y130.148 E.01269
G1 F6459.938
G1 X166.602 Y129.748 E.01327
G1 F13999.876
G1 X166.602 Y129.348 E.01327
G1 F15476.087
G1 X166.602 Y128.948 E.01327
G1 X166.602 Y123.408 E.18376
G1 X183.398 Y123.408 E.55715
G1 X183.398 Y128.948 E.18376
G1 X183.398 Y129.348 E.01327
G1 F13999.876
G1 X183.398 Y129.748 E.01327
G1 F6459.938
G1 X183.398 Y130.148 E.01327
G1 F1800
G1 X183.398 Y130.53 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X183.398 Y131.202 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X183.398 Y131.584 E.01269
G1 F6459.938
G1 X183.398 Y131.984 E.01327
G1 F13999.876
G1 X183.398 Y132.384 E.01327
G1 F15476.087
G1 X183.398 Y132.784 E.01327
G1 X183.398 Y136.073 E.10912
G1 X72.602 Y136.073 E3.6753
G1 X72.602 Y132.784 E.10912
G1 X72.602 Y132.384 E.01327
G1 F13999.876
G1 X72.602 Y131.984 E.01327
G1 F6459.938
G1 X72.602 Y131.584 E.01327
G1 F1800
G1 X72.602 Y131.202 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X72.602 Y130.53 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X72.602 Y130.148 E.01269
G1 F6459.938
G1 X72.602 Y129.748 E.01327
G1 F13999.876
G1 X72.602 Y129.348 E.01327
G1 F15476.087
G1 X72.602 Y128.948 E.01327
G1 X72.602 Y123.408 E.18376
G1 X89.398 Y123.408 E.55715
G1 X89.398 Y128.948 E.18376
G1 X89.398 Y129.348 E.01327
G1 F13999.876
G1 X89.398 Y129.748 E.01327
G1 F6459.938
G1 X89.398 Y130.148 E.01327
G1 F1800
G1 X89.398 Y130.53 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X89.398 Y131.202 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X89.398 Y131.584 E.01269
G1 F6459.938
G1 X89.398 Y131.984 E.01327
G1 F13999.876
G1 X89.398 Y132.384 E.01327
G1 F15476.087
G1 X89.398 Y132.784 E.01327
M73 P81 R5
G1 X89.398 Y133.602 E.02714
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y132.784 E.02714
G1 X96.602 Y132.384 E.01327
G1 F13999.876
G1 X96.602 Y131.984 E.01327
G1 F6459.938
G1 X96.602 Y131.584 E.01327
G1 F1800
G1 X96.602 Y131.202 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X96.602 Y130.53 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X96.602 Y130.148 E.01269
G1 F6459.938
G1 X96.602 Y129.748 E.01327
G1 F13999.876
G1 X96.602 Y129.348 E.01327
G1 F15476.087
G1 X96.602 Y128.948 E.01327
G1 X96.602 Y123.408 E.18376
G1 X103.398 Y123.408 E.22543
G1 X103.398 Y128.948 E.18376
G1 X103.398 Y129.348 E.01327
G1 F13999.876
G1 X103.398 Y129.748 E.01327
G1 F6459.938
G1 X103.398 Y130.148 E.01327
G1 F1800
G1 X103.398 Y130.53 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X103.398 Y131.202 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X103.398 Y131.584 E.01269
G1 F6459.938
G1 X103.398 Y131.984 E.01327
G1 F13999.876
G1 X103.398 Y132.384 E.01327
G1 F15476.087
G1 X103.398 Y132.784 E.01327
G1 X103.398 Y133.602 E.02714
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y132.784 E.02714
G1 X110.602 Y132.384 E.01327
G1 F13999.876
G1 X110.602 Y131.984 E.01327
G1 F6459.938
G1 X110.602 Y131.584 E.01327
G1 F1800
G1 X110.602 Y131.202 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X110.602 Y130.53 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X110.602 Y130.148 E.01269
G1 F6459.938
G1 X110.602 Y129.748 E.01327
G1 F13999.876
G1 X110.602 Y129.348 E.01327
G1 F15476.087
G1 X110.602 Y128.948 E.01327
G1 X110.602 Y123.408 E.18376
G1 X117.398 Y123.408 E.22543
G1 X117.398 Y128.948 E.18376
G1 X117.398 Y129.348 E.01327
G1 F13999.876
G1 X117.398 Y129.748 E.01327
G1 F6459.938
G1 X117.398 Y130.148 E.01327
G1 F1800
G1 X117.398 Y130.53 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X117.398 Y131.202 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X117.398 Y131.584 E.01269
G1 F6459.938
G1 X117.398 Y131.984 E.01327
G1 F13999.876
G1 X117.398 Y132.384 E.01327
G1 F15476.087
G1 X117.398 Y132.784 E.01327
G1 X117.398 Y133.602 E.02714
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y132.784 E.02714
G1 X124.602 Y132.384 E.01327
G1 F13999.876
G1 X124.602 Y131.984 E.01327
G1 F6459.938
G1 X124.602 Y131.584 E.01327
G1 F1800
G1 X124.602 Y131.202 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X124.602 Y130.53 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X124.602 Y130.148 E.01269
G1 F6459.938
G1 X124.602 Y129.748 E.01327
G1 F13999.876
G1 X124.602 Y129.348 E.01327
G1 F15476.087
G1 X124.602 Y128.948 E.01327
G1 X124.602 Y123.408 E.18376
G1 X131.398 Y123.408 E.22543
G1 X131.398 Y128.948 E.18376
G1 X131.398 Y129.348 E.01327
G1 F13999.876
G1 X131.398 Y129.748 E.01327
G1 F6459.938
G1 X131.398 Y130.148 E.01327
G1 F1800
G1 X131.398 Y130.53 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X131.398 Y131.202 E.02227
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X131.398 Y131.584 E.01269
G1 F6459.938
G1 X131.398 Y131.984 E.01327
G1 F13999.876
G1 X131.398 Y132.384 E.01327
G1 F15476.087
G1 X131.398 Y132.784 E.01327
G1 X131.398 Y133.602 E.02714
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y132.371 E.02579
G1 X138.21 Y131.971 E.01229
G1 F6459.938
G1 X138.21 Y131.571 E.01229
G1 F1800
G1 X138.21 Y131.202 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X138.21 Y130.53 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X138.21 Y130.161 E.01134
G1 F6459.938
G1 X138.21 Y129.761 E.01229
G1 F12000
G1 X138.21 Y129.361 E.01229
G1 X138.21 Y121.74 E.23417
G1 X145.79 Y121.74 E.23291
G1 X145.79 Y129.361 E.23417
G1 X145.79 Y129.761 E.01229
G1 F6459.938
G1 X145.79 Y130.161 E.01229
G1 F1800
G1 X145.79 Y130.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X145.79 Y131.202 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X145.79 Y131.571 E.01134
G1 F6459.938
G1 X145.79 Y131.971 E.01229
G1 F12000
G1 X145.79 Y132.371 E.01229
G1 X145.79 Y133.21 E.02579
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y132.371 E.02579
G1 X152.21 Y131.971 E.01229
G1 F6459.938
G1 X152.21 Y131.571 E.01229
G1 F1800
G1 X152.21 Y131.202 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X152.21 Y130.53 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X152.21 Y130.161 E.01134
G1 F6459.938
G1 X152.21 Y129.761 E.01229
G1 F12000
G1 X152.21 Y129.361 E.01229
G1 X152.21 Y121.74 E.23417
G1 X159.79 Y121.74 E.23291
G1 X159.79 Y129.361 E.23417
G1 X159.79 Y129.761 E.01229
G1 F6459.938
G1 X159.79 Y130.161 E.01229
G1 F1800
G1 X159.79 Y130.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X159.79 Y131.202 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X159.79 Y131.571 E.01134
G1 F6459.938
G1 X159.79 Y131.971 E.01229
G1 F12000
G1 X159.79 Y132.371 E.01229
G1 X159.79 Y133.21 E.02579
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y132.371 E.02579
G1 X166.21 Y131.971 E.01229
G1 F6459.938
G1 X166.21 Y131.571 E.01229
G1 F1800
G1 X166.21 Y131.202 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X166.21 Y130.53 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.21 Y130.161 E.01134
G1 F6459.938
G1 X166.21 Y129.761 E.01229
G1 F12000
G1 X166.21 Y129.361 E.01229
G1 X166.21 Y121.74 E.23417
G1 X183.79 Y121.74 E.54018
G1 X183.79 Y129.361 E.23417
G1 X183.79 Y129.761 E.01229
G1 F6459.938
G1 X183.79 Y130.161 E.01229
G1 F1800
G1 X183.79 Y130.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X183.79 Y131.202 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X183.79 Y131.571 E.01134
G1 F6459.938
G1 X183.79 Y131.971 E.01229
G1 F12000
G1 X183.79 Y132.371 E.01229
G1 X183.79 Y136.466 E.12583
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y136.466 E3.42854
G1 X72.21 Y132.371 E.12583
G1 X72.21 Y131.971 E.01229
G1 F6459.938
G1 X72.21 Y131.571 E.01229
G1 F1800
G1 X72.21 Y131.202 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X72.21 Y130.53 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X72.21 Y130.161 E.01134
G1 F6459.938
G1 X72.21 Y129.761 E.01229
G1 F12000
G1 X72.21 Y129.361 E.01229
G1 X72.21 Y121.74 E.23417
G1 X89.79 Y121.74 E.54018
G1 X89.79 Y129.361 E.23417
G1 X89.79 Y129.761 E.01229
G1 F6459.938
G1 X89.79 Y130.161 E.01229
G1 F1800
G1 X89.79 Y130.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X89.79 Y131.202 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X89.79 Y131.571 E.01134
G1 F6459.938
G1 X89.79 Y131.971 E.01229
G1 F12000
G1 X89.79 Y132.371 E.01229
G1 X89.79 Y133.21 E.02579
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y132.371 E.02579
G1 X96.21 Y131.971 E.01229
G1 F6459.938
G1 X96.21 Y131.571 E.01229
G1 F1800
G1 X96.21 Y131.202 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X96.21 Y130.53 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X96.21 Y130.161 E.01134
G1 F6459.938
G1 X96.21 Y129.761 E.01229
G1 F12000
G1 X96.21 Y129.361 E.01229
G1 X96.21 Y121.74 E.23417
G1 X103.79 Y121.74 E.23291
G1 X103.79 Y129.361 E.23417
G1 X103.79 Y129.761 E.01229
G1 F6459.938
G1 X103.79 Y130.161 E.01229
G1 F1800
G1 X103.79 Y130.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X103.79 Y131.202 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X103.79 Y131.571 E.01134
G1 F6459.938
G1 X103.79 Y131.971 E.01229
G1 F12000
G1 X103.79 Y132.371 E.01229
G1 X103.79 Y133.21 E.02579
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y132.371 E.02579
G1 X110.21 Y131.971 E.01229
G1 F6459.938
G1 X110.21 Y131.571 E.01229
G1 F1800
G1 X110.21 Y131.202 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X110.21 Y130.53 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X110.21 Y130.161 E.01134
G1 F6459.938
G1 X110.21 Y129.761 E.01229
G1 F12000
G1 X110.21 Y129.361 E.01229
G1 X110.21 Y121.74 E.23417
G1 X117.79 Y121.74 E.23291
G1 X117.79 Y129.361 E.23417
G1 X117.79 Y129.761 E.01229
G1 F6459.938
G1 X117.79 Y130.161 E.01229
G1 F1800
G1 X117.79 Y130.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X117.79 Y131.202 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X117.79 Y131.571 E.01134
G1 F6459.938
G1 X117.79 Y131.971 E.01229
G1 F12000
G1 X117.79 Y132.371 E.01229
G1 X117.79 Y133.21 E.02579
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y132.371 E.02579
G1 X124.21 Y131.971 E.01229
G1 F6459.938
G1 X124.21 Y131.571 E.01229
G1 F1800
G1 X124.21 Y131.202 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X124.21 Y130.53 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X124.21 Y130.161 E.01134
G1 F6459.938
G1 X124.21 Y129.761 E.01229
G1 F12000
G1 X124.21 Y129.361 E.01229
G1 X124.21 Y121.74 E.23417
G1 X131.79 Y121.74 E.23291
G1 X131.79 Y129.361 E.23417
G1 X131.79 Y129.761 E.01229
G1 F6459.938
G1 X131.79 Y130.161 E.01229
G1 F1800
G1 X131.79 Y130.53 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X131.79 Y131.202 E.02227
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X131.79 Y131.571 E.01134
G1 F6459.938
G1 X131.79 Y131.971 E.01229
G1 F12000
G1 X131.79 Y132.371 E.01229
G1 X131.79 Y133.21 E.02579
G1 X138.15 Y133.21 E.19542
; WIPE_START
M204 S10000
G1 X138.21 Y132.371 E-.31981
G1 X138.21 Y131.971 E-.152
G1 X138.21 Y131.571 E-.152
G1 X138.21 Y131.212 E-.13619
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I1.159 J.372 P1  F30000
G1 X138.938 Y128.943 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42566
G1 F3000
G1 X138.938 Y132.519 E.11152
G1 X139.321 Y132.519 E.01194
G1 X139.321 Y129.113 E.10622
G1 X139.704 Y129.113 E.01194
G1 X139.704 Y132.519 E.10622
G1 X140.086 Y132.519 E.01194
G1 X140.086 Y129.113 E.10622
G1 X140.469 Y129.113 E.01194
G1 X140.469 Y132.519 E.10622
G1 X140.852 Y132.519 E.01194
G1 X140.852 Y129.113 E.10622
G1 X141.235 Y129.113 E.01194
G1 X141.235 Y132.519 E.10622
G1 X141.617 Y132.519 E.01194
G1 X141.617 Y129.113 E.10622
G1 X142 Y129.113 E.01194
G1 X142 Y132.519 E.10622
G1 X142.383 Y132.519 E.01194
G1 X142.383 Y129.113 E.10622
G1 X142.766 Y129.113 E.01194
G1 X142.766 Y132.519 E.10622
G1 X143.148 Y132.519 E.01194
G1 X143.148 Y129.113 E.10622
G1 X143.531 Y129.113 E.01194
G1 X143.531 Y132.519 E.10622
G1 X143.914 Y132.519 E.01194
G1 X143.914 Y129.113 E.10622
G1 X144.296 Y129.113 E.01194
G1 X144.296 Y132.519 E.10622
G1 X144.679 Y132.519 E.01194
G1 X144.679 Y129.113 E.10622
G1 X145.062 Y129.113 E.01194
G1 X145.062 Y132.688 E.11152
; WIPE_START
G1 X145.062 Y130.688 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I.444 J-1.133 P1  F30000
G1 X139.295 Y128.428 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X140.923 Y128.428 E.05401
G1 X143.117 Y126.235 E.10288
G1 X143.587 Y126.235 E.01561
G1 X145.05 Y127.698 E.06861
G1 X145.05 Y128.428 E.02424
G1 X144.152 Y128.428 E.02978
G1 X145.006 Y124.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y123.8 E.03139
G1 X138.994 Y123.8 E.18472
G1 X138.994 Y125.843 E.06279
G1 X145.006 Y125.843 E.18472
G1 X145.006 Y124.882 E.02955
G1 X144.629 Y124.822 F30000
G1 F12000
G1 X144.629 Y124.177 E.01981
G1 X139.371 Y124.177 E.16155
G1 X139.371 Y125.466 E.03961
G1 X144.629 Y125.466 E.16155
G1 X144.629 Y124.882 E.01796
G1 X144.212 Y124.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X144.212 Y124.594 E.00848
G1 X139.788 Y124.594 E.16444
G1 X139.788 Y125.05 E.01695
G1 X144.212 Y125.05 E.16444
G1 X144.212 Y124.882 E.00625
; WIPE_START
G1 X144.212 Y125.05 E-.06386
G1 X142.38 Y125.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y122.519 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.011 Y121.947 E.02484
G1 X144.478 Y121.947
G1 X145.583 Y123.052 E.04801
G1 X145.182 Y123.185
G1 X143.944 Y121.947 E.05379
G1 X143.411 Y121.947
G1 X144.649 Y123.185 E.05379
G1 X144.116 Y123.185
G1 X142.878 Y121.947 E.05379
G1 X142.345 Y121.947
G1 X143.583 Y123.185 E.05379
G1 X143.049 Y123.185
G1 X141.811 Y121.947 E.05379
G1 X141.278 Y121.947
G1 X142.516 Y123.185 E.05379
G1 X141.983 Y123.185
G1 X140.745 Y121.947 E.05379
G1 X140.212 Y121.947
G1 X141.45 Y123.185 E.05379
G1 X140.916 Y123.185
G1 X139.678 Y121.947 E.05379
G1 X139.145 Y121.947
G1 X140.383 Y123.185 E.05379
G1 X139.85 Y123.185
G1 X138.612 Y121.947 E.05379
G1 X138.417 Y122.286
G1 X139.317 Y123.185 E.03907
G1 X138.783 Y123.185
G1 X138.417 Y122.819 E.0159
; WIPE_START
M204 S10000
G1 X138.783 Y123.185 E-.19664
G1 X139.317 Y123.185 E-.20264
G1 X138.645 Y122.514 E-.36072
; WIPE_END
G1 E-.04 F1800
G1 X138.952 Y128.778 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X144.988 Y128.778 E.16725
; WIPE_START
G1 X142.988 Y128.778 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I-.02 J1.217 P1  F30000
G1 X152.938 Y128.943 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42566
G1 F3000
G1 X152.938 Y132.519 E.11152
G1 X153.321 Y132.519 E.01194
G1 X153.321 Y129.113 E.10622
G1 X153.704 Y129.113 E.01194
G1 X153.704 Y132.519 E.10622
G1 X154.086 Y132.519 E.01194
G1 X154.086 Y129.113 E.10622
G1 X154.469 Y129.113 E.01194
G1 X154.469 Y132.519 E.10622
G1 X154.852 Y132.519 E.01194
G1 X154.852 Y129.113 E.10622
G1 X155.235 Y129.113 E.01194
G1 X155.235 Y132.519 E.10622
G1 X155.617 Y132.519 E.01194
G1 X155.617 Y129.113 E.10622
G1 X156 Y129.113 E.01194
G1 X156 Y132.519 E.10622
G1 X156.383 Y132.519 E.01194
G1 X156.383 Y129.113 E.10622
G1 X156.766 Y129.113 E.01194
G1 X156.766 Y132.519 E.10622
G1 X157.148 Y132.519 E.01194
G1 X157.148 Y129.113 E.10622
G1 X157.531 Y129.113 E.01194
G1 X157.531 Y132.519 E.10622
G1 X157.914 Y132.519 E.01194
G1 X157.914 Y129.113 E.10622
G1 X158.296 Y129.113 E.01194
G1 X158.296 Y132.519 E.10622
G1 X158.679 Y132.519 E.01194
G1 X158.679 Y129.113 E.10622
G1 X159.062 Y129.113 E.01194
G1 X159.062 Y132.688 E.11152
; WIPE_START
G1 X159.062 Y130.688 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I1.089 J-.543 P1  F30000
G1 X156.84 Y126.235 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X158.468 Y126.235 E.05401
G1 X156.275 Y128.428 E.10288
G1 X153.456 Y128.428 E.09351
G1 X152.95 Y127.922 E.02374
G1 X152.95 Y126.294 E.05401
G1 X152.952 Y128.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X158.988 Y128.778 E.16725
G1 X159.006 Y125.843 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y123.8 E.06279
G1 X152.994 Y123.8 E.18472
G1 X152.994 Y125.843 E.06279
G1 X158.946 Y125.843 E.18288
G1 X158.629 Y124.822 F30000
G1 F12000
G1 X158.629 Y124.177 E.01981
G1 X153.371 Y124.177 E.16155
G1 X153.371 Y125.466 E.03961
G1 X158.629 Y125.466 E.16155
G1 X158.629 Y124.882 E.01796
G1 X158.212 Y124.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X158.212 Y124.594 E.00848
G1 X153.788 Y124.594 E.16444
G1 X153.788 Y125.05 E.01695
G1 X158.212 Y125.05 E.16444
G1 X158.212 Y124.882 E.00625
; WIPE_START
G1 X158.212 Y125.05 E-.06386
G1 X156.38 Y125.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y122.654 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X158.876 Y121.947 E.03072
G1 X158.342 Y121.947
G1 X159.58 Y123.185 E.05379
G1 X159.047 Y123.185
G1 X157.809 Y121.947 E.05379
G1 X157.276 Y121.947
G1 X158.514 Y123.185 E.05379
G1 X157.981 Y123.185
G1 X156.743 Y121.947 E.05379
G1 X156.209 Y121.947
G1 X157.447 Y123.185 E.05379
G1 X156.914 Y123.185
G1 X155.676 Y121.947 E.05379
G1 X155.143 Y121.947
G1 X156.381 Y123.185 E.05379
G1 X155.848 Y123.185
G1 X154.61 Y121.947 E.05379
G1 X154.076 Y121.947
G1 X155.314 Y123.185 E.05379
G1 X154.781 Y123.185
G1 X153.543 Y121.947 E.05379
G1 X153.01 Y121.947
G1 X154.248 Y123.185 E.05379
G1 X153.715 Y123.185
G1 X152.477 Y121.947 E.05379
G1 X152.417 Y122.421
G1 X153.181 Y123.185 E.03319
; WIPE_START
M204 S10000
G1 X152.417 Y122.421 E-.4105
G1 X152.477 Y121.947 E-.18153
G1 X152.789 Y122.26 E-.16797
; WIPE_END
G1 E-.04 F1800
G1 X159.723 Y125.451 Z4.6 F30000
G1 X166.952 Y128.778 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.988 Y128.778 E.4443
G1 X182.532 Y128.428 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X183.05 Y128.428 E.01718
G1 X183.05 Y127.318 E.03684
G1 X182.767 Y127.035 E.01326
G1 X180.696 Y127.035 E.06869
G1 X179.303 Y128.428 E.06536
G1 X176.484 Y128.428 E.09351
G1 X175.091 Y127.035 E.06536
G1 X173.02 Y127.035 E.06869
G1 X171.627 Y128.428 E.06536
G1 X168.808 Y128.428 E.09351
G1 X167.415 Y127.035 E.06535
G1 X169.043 Y127.035 E.05401
G1 X166.939 Y128.943 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42679
G1 F3000
G1 X166.939 Y132.519 E.11185
G1 X167.323 Y132.519 E.01201
G1 X167.323 Y129.113 E.10654
G1 X167.706 Y129.113 E.01201
G1 X167.706 Y132.519 E.10654
G1 X168.09 Y132.519 E.01201
G1 X168.09 Y129.113 E.10654
G1 X168.474 Y129.113 E.01201
G1 X168.474 Y132.519 E.10654
G1 X168.858 Y132.519 E.01201
G1 X168.858 Y129.113 E.10654
G1 X169.242 Y129.113 E.01201
G1 X169.242 Y132.519 E.10654
G1 X169.626 Y132.519 E.01201
G1 X169.626 Y129.113 E.10654
G1 X170.01 Y129.113 E.01201
G1 X170.01 Y132.519 E.10654
G1 X170.394 Y132.519 E.01201
G1 X170.394 Y129.113 E.10654
G1 X170.777 Y129.113 E.01201
G1 X170.777 Y132.519 E.10654
G1 X171.161 Y132.519 E.01201
G1 X171.161 Y129.113 E.10654
G1 X171.545 Y129.113 E.01201
G1 X171.545 Y132.519 E.10654
G1 X171.929 Y132.519 E.01201
G1 X171.929 Y129.113 E.10654
G1 X172.313 Y129.113 E.01201
G1 X172.313 Y132.519 E.10654
G1 X172.697 Y132.519 E.01201
G1 X172.697 Y129.113 E.10654
G1 X173.081 Y129.113 E.01201
G1 X173.081 Y132.519 E.10654
G1 X173.464 Y132.519 E.01201
G1 X173.464 Y129.113 E.10654
G1 X173.848 Y129.113 E.01201
G1 X173.848 Y132.519 E.10654
G1 X174.232 Y132.519 E.01201
G1 X174.232 Y129.113 E.10654
G1 X174.616 Y129.113 E.01201
G1 X174.616 Y132.519 E.10654
G1 X175 Y132.519 E.01201
G1 X175 Y129.113 E.10654
G1 X175.384 Y129.113 E.01201
G1 X175.384 Y132.519 E.10654
G1 X175.768 Y132.519 E.01201
G1 X175.768 Y129.113 E.10654
G1 X176.152 Y129.113 E.01201
G1 X176.152 Y132.519 E.10654
G1 X176.535 Y132.519 E.01201
G1 X176.535 Y129.113 E.10654
G1 X176.919 Y129.113 E.01201
G1 X176.919 Y132.519 E.10654
G1 X177.303 Y132.519 E.01201
G1 X177.303 Y129.113 E.10654
G1 X177.687 Y129.113 E.01201
G1 X177.687 Y132.519 E.10654
G1 X178.071 Y132.519 E.01201
G1 X178.071 Y129.113 E.10654
G1 X178.455 Y129.113 E.01201
G1 X178.455 Y132.519 E.10654
G1 X178.839 Y132.519 E.01201
G1 X178.839 Y129.113 E.10654
G1 X179.223 Y129.113 E.01201
G1 X179.223 Y132.519 E.10654
G1 X179.606 Y132.519 E.01201
G1 X179.606 Y129.113 E.10654
G1 X179.99 Y129.113 E.01201
G1 X179.99 Y132.519 E.10654
G1 X180.374 Y132.519 E.01201
G1 X180.374 Y129.113 E.10654
G1 X180.758 Y129.113 E.01201
G1 X180.758 Y132.519 E.10654
G1 X181.142 Y132.519 E.01201
G1 X181.142 Y129.113 E.10654
G1 X181.526 Y129.113 E.01201
G1 X181.526 Y132.519 E.10654
G1 X181.91 Y132.519 E.01201
G1 X181.91 Y129.113 E.10654
G1 X182.293 Y129.113 E.01201
G1 X182.293 Y132.519 E.10654
G1 X182.677 Y132.519 E.01201
G1 X182.677 Y129.113 E.10654
G1 X183.061 Y129.113 E.01201
G1 X183.061 Y132.688 E.11185
; WIPE_START
G1 X183.061 Y130.688 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I1.217 J-.012 P1  F30000
G1 X183.006 Y125.222 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y123.8 E.04368
G1 X166.994 Y123.8 E.49198
G1 X166.994 Y126.643 E.08737
G1 X183.006 Y126.643 E.49198
G1 X183.006 Y125.282 E.04184
G1 X182.629 Y125.222 F30000
G1 F12000
G1 X182.629 Y124.177 E.0321
G1 X167.371 Y124.177 E.46881
G1 X167.371 Y126.266 E.0642
G1 X182.629 Y126.266 E.46881
G1 X182.629 Y125.282 E.03025
G1 X182.252 Y125.222 F30000
G1 F12000
G1 X182.252 Y124.554 E.02051
G1 X167.748 Y124.554 E.44564
G1 X167.748 Y125.889 E.04102
G1 X182.252 Y125.889 E.44564
G1 X182.252 Y125.282 E.01867
G1 X181.824 Y125.222 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X181.824 Y124.982 E.00935
G1 X168.176 Y124.982 E.53272
G1 X168.176 Y125.461 E.0187
G1 X181.824 Y125.461 E.53272
G1 X181.824 Y125.282 E.00701
; WIPE_START
G1 X181.824 Y125.461 E-.06822
G1 X180.003 Y125.461 E-.69178
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y122.658 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X182.872 Y121.947 E.03087
G1 X182.339 Y121.947
G1 X183.577 Y123.185 E.05379
G1 X183.044 Y123.185
G1 X181.806 Y121.947 E.05379
G1 X181.273 Y121.947
G1 X182.51 Y123.185 E.05379
G1 X181.977 Y123.185
G1 X180.739 Y121.947 E.05379
G1 X180.206 Y121.947
G1 X181.444 Y123.185 E.05379
G1 X180.911 Y123.185
G1 X179.673 Y121.947 E.05379
G1 X179.139 Y121.947
G1 X180.377 Y123.185 E.05379
G1 X179.844 Y123.185
G1 X178.606 Y121.947 E.05379
G1 X178.073 Y121.947
G1 X179.311 Y123.185 E.05379
G1 X178.778 Y123.185
G1 X177.54 Y121.947 E.05379
G1 X177.006 Y121.947
G1 X178.244 Y123.185 E.05379
G1 X177.711 Y123.185
G1 X176.473 Y121.947 E.05379
G1 X175.94 Y121.947
G1 X177.178 Y123.185 E.05379
G1 X176.645 Y123.185
G1 X175.407 Y121.947 E.05379
G1 X174.873 Y121.947
G1 X176.111 Y123.185 E.05379
G1 X175.578 Y123.185
G1 X174.34 Y121.947 E.05379
G1 X173.807 Y121.947
G1 X175.045 Y123.185 E.05379
G1 X174.512 Y123.185
G1 X173.274 Y121.947 E.05379
G1 X172.74 Y121.947
G1 X173.978 Y123.185 E.05379
G1 X173.445 Y123.185
G1 X172.207 Y121.947 E.05379
G1 X171.674 Y121.947
G1 X172.912 Y123.185 E.05379
G1 X172.379 Y123.185
G1 X171.141 Y121.947 E.05379
G1 X170.607 Y121.947
G1 X171.845 Y123.185 E.05379
M73 P82 R5
G1 X171.312 Y123.185
G1 X170.074 Y121.947 E.05379
G1 X169.541 Y121.947
G1 X170.779 Y123.185 E.05379
G1 X170.246 Y123.185
G1 X169.008 Y121.947 E.05379
G1 X168.474 Y121.947
G1 X169.712 Y123.185 E.05379
G1 X169.179 Y123.185
G1 X167.941 Y121.947 E.05379
G1 X167.408 Y121.947
G1 X168.646 Y123.185 E.05379
G1 X168.112 Y123.185
G1 X166.875 Y121.947 E.05379
G1 X166.417 Y122.023
G1 X167.579 Y123.185 E.05049
G1 X167.046 Y123.185
G1 X166.417 Y122.557 E.02731
; WIPE_START
M204 S10000
G1 X167.046 Y123.185 E-.33779
G1 X167.579 Y123.185 E-.20264
G1 X167.171 Y122.777 E-.21957
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I-1.213 J.097 P1  F30000
G1 X168.05 Y133.728 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.233 Y133.728 E.02709
G1 X167.233 Y133.579 E.00494
G1 X166.95 Y133.462 E.01015
G1 X166.95 Y133.105 E.01183
G1 X167.145 Y132.911 E.00914
G1 X173.29 Y132.911 E.20385
G1 X174.108 Y133.728 E.03835
G1 X174.004 Y133.728 E.00346
G1 X174.821 Y132.911 E.03835
G1 X180.966 Y132.911 E.20385
G1 X181.784 Y133.728 E.03835
G1 X181.68 Y133.728 E.00346
G1 X182.497 Y132.911 E.03835
G1 X183.05 Y132.911 E.01833
G1 X183.05 Y133.728 E.02712
G1 X182.792 Y133.728 E.00856
; WIPE_START
G1 X183.05 Y133.728 E-.0981
G1 X183.05 Y132.911 E-.31065
G1 X182.497 Y132.911 E-.21001
G1 X182.234 Y133.173 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X174.602 Y133.101 Z4.6 F30000
G1 X131.062 Y132.688 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42566
G1 F3000
G1 X131.062 Y129.113 E.11152
G1 X130.679 Y129.113 E.01194
G1 X130.679 Y132.519 E.10622
G1 X130.296 Y132.519 E.01194
G1 X130.296 Y129.113 E.10622
G1 X129.914 Y129.113 E.01194
G1 X129.914 Y132.519 E.10622
G1 X129.531 Y132.519 E.01194
G1 X129.531 Y129.113 E.10622
G1 X129.148 Y129.113 E.01194
G1 X129.148 Y132.519 E.10622
G1 X128.766 Y132.519 E.01194
G1 X128.766 Y129.113 E.10622
G1 X128.383 Y129.113 E.01194
G1 X128.383 Y132.519 E.10622
G1 X128 Y132.519 E.01194
G1 X128 Y129.113 E.10622
G1 X127.617 Y129.113 E.01194
G1 X127.617 Y132.519 E.10622
G1 X127.235 Y132.519 E.01194
G1 X127.235 Y129.113 E.10622
G1 X126.852 Y129.113 E.01194
G1 X126.852 Y132.519 E.10622
G1 X126.469 Y132.519 E.01194
G1 X126.469 Y129.113 E.10622
G1 X126.086 Y129.113 E.01194
G1 X126.086 Y132.519 E.10622
G1 X125.704 Y132.519 E.01194
G1 X125.704 Y129.113 E.10622
G1 X125.321 Y129.113 E.01194
G1 X125.321 Y132.519 E.10622
G1 X124.938 Y132.519 E.01194
G1 X124.938 Y128.943 E.11152
G1 X124.952 Y128.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X130.988 Y128.778 E.16725
G1 X131.006 Y124.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y123.8 E.03139
G1 X124.994 Y123.8 E.18472
G1 X124.994 Y125.843 E.06279
G1 X131.006 Y125.843 E.18472
G1 X131.006 Y124.882 E.02955
G1 X130.629 Y124.822 F30000
G1 F12000
G1 X130.629 Y124.177 E.01981
G1 X125.371 Y124.177 E.16155
G1 X125.371 Y125.466 E.03961
G1 X130.629 Y125.466 E.16155
G1 X130.629 Y124.882 E.01796
G1 X130.212 Y124.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X130.212 Y124.594 E.00848
G1 X125.788 Y124.594 E.16444
G1 X125.788 Y125.05 E.01695
G1 X130.212 Y125.05 E.16444
G1 X130.212 Y124.882 E.00625
; WIPE_START
G1 X130.212 Y125.05 E-.06386
G1 X128.38 Y125.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X131.583 Y122.384 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X131.146 Y121.947 E.01896
G1 X130.613 Y121.947
G1 X131.583 Y122.917 E.04213
G1 X131.318 Y123.185
G1 X130.08 Y121.947 E.05379
G1 X129.547 Y121.947
G1 X130.784 Y123.185 E.05379
G1 X130.251 Y123.185
G1 X129.013 Y121.947 E.05379
G1 X128.48 Y121.947
G1 X129.718 Y123.185 E.05379
G1 X129.185 Y123.185
G1 X127.947 Y121.947 E.05379
G1 X127.414 Y121.947
G1 X128.651 Y123.185 E.05379
G1 X128.118 Y123.185
G1 X126.88 Y121.947 E.05379
G1 X126.347 Y121.947
G1 X127.585 Y123.185 E.05379
G1 X127.052 Y123.185
G1 X125.814 Y121.947 E.05379
G1 X125.28 Y121.947
G1 X126.518 Y123.185 E.05379
G1 X125.985 Y123.185
G1 X124.747 Y121.947 E.05379
G1 X124.417 Y122.151
G1 X125.452 Y123.185 E.04495
G1 X124.919 Y123.185
G1 X124.417 Y122.684 E.02178
; WIPE_START
M204 S10000
G1 X124.919 Y123.185 E-.26936
G1 X125.452 Y123.185 E-.20264
G1 X124.916 Y122.649 E-.288
; WIPE_END
G1 E-.04 F1800
G1 X124.95 Y127.421 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.95 Y128.428 E.03341
G1 X125.572 Y128.428 E.02061
G1 X127.765 Y126.235 E.10288
G1 X128.235 Y126.235 E.01561
G1 X130.428 Y128.428 E.10288
G1 X131.05 Y128.428 E.02061
G1 X131.05 Y127.421 E.03341
; WIPE_START
G1 X131.05 Y128.428 E-.3827
G1 X130.428 Y128.428 E-.23606
G1 X130.166 Y128.166 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X122.768 Y126.286 Z4.6 F30000
G1 X117.006 Y124.822 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y123.8 E.03139
G1 X110.994 Y123.8 E.18472
G1 X110.994 Y125.843 E.06279
G1 X117.006 Y125.843 E.18472
G1 X117.006 Y124.882 E.02955
G1 X116.629 Y124.822 F30000
G1 F12000
G1 X116.629 Y124.177 E.01981
G1 X111.371 Y124.177 E.16155
G1 X111.371 Y125.466 E.03961
G1 X116.629 Y125.466 E.16155
G1 X116.629 Y124.882 E.01796
G1 X116.212 Y124.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X116.212 Y124.594 E.00848
G1 X111.788 Y124.594 E.16444
G1 X111.788 Y125.05 E.01695
G1 X116.212 Y125.05 E.16444
G1 X116.212 Y124.882 E.00625
; WIPE_START
G1 X116.212 Y125.05 E-.06386
G1 X114.38 Y125.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X116.748 Y121.947 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X117.583 Y122.782 E.03625
G1 X117.453 Y123.185
G1 X116.215 Y121.947 E.05379
G1 X115.682 Y121.947
G1 X116.92 Y123.185 E.05379
G1 X116.386 Y123.185
G1 X115.149 Y121.947 E.05379
G1 X114.615 Y121.947
G1 X115.853 Y123.185 E.05379
G1 X115.32 Y123.185
G1 X114.082 Y121.947 E.05379
G1 X113.549 Y121.947
M73 P82 R4
G1 X114.787 Y123.185 E.05379
G1 X114.253 Y123.185
G1 X113.016 Y121.947 E.05379
G1 X112.482 Y121.947
G1 X113.72 Y123.185 E.05379
G1 X113.187 Y123.185
G1 X111.949 Y121.947 E.05379
G1 X111.416 Y121.947
G1 X112.654 Y123.185 E.05379
G1 X112.12 Y123.185
G1 X110.883 Y121.947 E.05379
G1 X110.417 Y122.016
G1 X111.587 Y123.185 E.05083
G1 X111.054 Y123.185
G1 X110.417 Y122.549 E.02766
; WIPE_START
M204 S10000
G1 X111.054 Y123.185 E-.34207
G1 X111.587 Y123.185 E-.20264
G1 X111.187 Y122.785 E-.21529
; WIPE_END
G1 E-.04 F1800
G1 X111.848 Y128.428 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y128.428 E.02977
G1 X110.95 Y127.698 E.02424
G1 X112.413 Y126.235 E.0686
G1 X112.883 Y126.235 E.01561
G1 X115.077 Y128.428 E.10288
G1 X116.705 Y128.428 E.05401
; WIPE_START
G1 X115.077 Y128.428 E-.61876
G1 X114.814 Y128.166 E-.14124
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I-1.09 J.542 P1  F30000
G1 X117.062 Y132.688 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42566
G1 F3000
G1 X117.062 Y129.113 E.11152
G1 X116.679 Y129.113 E.01194
G1 X116.679 Y132.519 E.10622
G1 X116.296 Y132.519 E.01194
G1 X116.296 Y129.113 E.10622
G1 X115.914 Y129.113 E.01194
G1 X115.914 Y132.519 E.10622
G1 X115.531 Y132.519 E.01194
G1 X115.531 Y129.113 E.10622
G1 X115.148 Y129.113 E.01194
G1 X115.148 Y132.519 E.10622
G1 X114.766 Y132.519 E.01194
G1 X114.766 Y129.113 E.10622
G1 X114.383 Y129.113 E.01194
G1 X114.383 Y132.519 E.10622
G1 X114 Y132.519 E.01194
G1 X114 Y129.113 E.10622
G1 X113.617 Y129.113 E.01194
G1 X113.617 Y132.519 E.10622
G1 X113.235 Y132.519 E.01194
G1 X113.235 Y129.113 E.10622
G1 X112.852 Y129.113 E.01194
G1 X112.852 Y132.519 E.10622
G1 X112.469 Y132.519 E.01194
G1 X112.469 Y129.113 E.10622
G1 X112.086 Y129.113 E.01194
G1 X112.086 Y132.519 E.10622
G1 X111.704 Y132.519 E.01194
G1 X111.704 Y129.113 E.10622
G1 X111.321 Y129.113 E.01194
G1 X111.321 Y132.519 E.10622
G1 X110.938 Y132.519 E.01194
G1 X110.938 Y128.943 E.11152
G1 X110.952 Y128.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X116.988 Y128.778 E.16725
; WIPE_START
G1 X114.988 Y128.778 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.516 Y127.223 Z4.6 F30000
G1 X103.05 Y126.294 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X103.05 Y127.922 E.05401
G1 X102.544 Y128.428 E.02374
G1 X99.725 Y128.428 E.09351
G1 X97.532 Y126.235 E.10288
G1 X99.16 Y126.235 E.05401
G1 X96.952 Y128.778 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X102.988 Y128.778 E.16725
; WIPE_START
G1 X100.988 Y128.778 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I-1.075 J.57 P1  F30000
G1 X103.062 Y132.688 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42566
G1 F3000
G1 X103.062 Y129.113 E.11152
G1 X102.679 Y129.113 E.01194
G1 X102.679 Y132.519 E.10622
G1 X102.296 Y132.519 E.01194
G1 X102.296 Y129.113 E.10622
G1 X101.914 Y129.113 E.01194
G1 X101.914 Y132.519 E.10622
G1 X101.531 Y132.519 E.01194
G1 X101.531 Y129.113 E.10622
G1 X101.148 Y129.113 E.01194
G1 X101.148 Y132.519 E.10622
G1 X100.766 Y132.519 E.01194
G1 X100.766 Y129.113 E.10622
G1 X100.383 Y129.113 E.01194
G1 X100.383 Y132.519 E.10622
G1 X100 Y132.519 E.01194
G1 X100 Y129.113 E.10622
G1 X99.617 Y129.113 E.01194
G1 X99.617 Y132.519 E.10622
G1 X99.235 Y132.519 E.01194
G1 X99.235 Y129.113 E.10622
G1 X98.852 Y129.113 E.01194
G1 X98.852 Y132.519 E.10622
G1 X98.469 Y132.519 E.01194
G1 X98.469 Y129.113 E.10622
G1 X98.086 Y129.113 E.01194
G1 X98.086 Y132.519 E.10622
G1 X97.704 Y132.519 E.01194
G1 X97.704 Y129.113 E.10622
G1 X97.321 Y129.113 E.01194
G1 X97.321 Y132.519 E.10622
G1 X96.938 Y132.519 E.01194
G1 X96.938 Y128.943 E.11152
G1 X103.006 Y124.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y123.8 E.03139
G1 X96.994 Y123.8 E.18472
G1 X96.994 Y125.843 E.06279
G1 X103.006 Y125.843 E.18472
G1 X103.006 Y124.882 E.02955
G1 X102.629 Y124.822 F30000
G1 F12000
G1 X102.629 Y124.177 E.01981
G1 X97.371 Y124.177 E.16155
G1 X97.371 Y125.466 E.03961
G1 X102.629 Y125.466 E.16155
G1 X102.629 Y124.882 E.01796
G1 X102.212 Y124.822 F30000
; LINE_WIDTH: 0.49902
G1 F12000
G1 X102.212 Y124.594 E.00848
G1 X97.788 Y124.594 E.16444
G1 X97.788 Y125.05 E.01695
G1 X102.212 Y125.05 E.16444
G1 X102.212 Y124.882 E.00625
; WIPE_START
G1 X102.212 Y125.05 E-.06386
G1 X100.38 Y125.05 E-.69614
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y122.646 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X102.884 Y121.947 E.03037
G1 X102.35 Y121.947
G1 X103.583 Y123.18 E.05355
G1 X103.055 Y123.185
G1 X101.817 Y121.947 E.05379
G1 X101.284 Y121.947
G1 X102.522 Y123.185 E.05379
G1 X101.989 Y123.185
G1 X100.751 Y121.947 E.05379
G1 X100.217 Y121.947
G1 X101.455 Y123.185 E.05379
G1 X100.922 Y123.185
G1 X99.684 Y121.947 E.05379
G1 X99.151 Y121.947
G1 X100.389 Y123.185 E.05379
G1 X99.856 Y123.185
G1 X98.618 Y121.947 E.05379
G1 X98.084 Y121.947
G1 X99.322 Y123.185 E.05379
G1 X98.789 Y123.185
G1 X97.551 Y121.947 E.05379
G1 X97.018 Y121.947
G1 X98.256 Y123.185 E.05379
G1 X97.722 Y123.185
G1 X96.485 Y121.947 E.05379
G1 X96.417 Y122.413
G1 X97.189 Y123.185 E.03354
; WIPE_START
M204 S10000
G1 X96.417 Y122.413 E-.41479
G1 X96.485 Y121.947 E-.17894
G1 X96.794 Y122.257 E-.16628
; WIPE_END
G1 E-.04 F1800
G1 X89.583 Y122.511 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X89.019 Y121.947 E.02449
G1 X88.486 Y121.947
G1 X89.583 Y123.044 E.04767
G1 X89.19 Y123.185
G1 X87.952 Y121.947 E.05379
G1 X87.419 Y121.947
G1 X88.657 Y123.185 E.05379
G1 X88.124 Y123.185
G1 X86.886 Y121.947 E.05379
G1 X86.353 Y121.947
G1 X87.591 Y123.185 E.05379
G1 X87.057 Y123.185
G1 X85.819 Y121.947 E.05379
G1 X85.286 Y121.947
G1 X86.524 Y123.185 E.05379
G1 X85.991 Y123.185
G1 X84.753 Y121.947 E.05379
G1 X84.22 Y121.947
G1 X85.458 Y123.185 E.05379
G1 X84.924 Y123.185
G1 X83.686 Y121.947 E.05379
G1 X83.153 Y121.947
G1 X84.391 Y123.185 E.05379
G1 X83.858 Y123.185
G1 X82.62 Y121.947 E.05379
G1 X82.087 Y121.947
G1 X83.325 Y123.185 E.05379
G1 X82.791 Y123.185
G1 X81.553 Y121.947 E.05379
G1 X81.02 Y121.947
G1 X82.258 Y123.185 E.05379
G1 X81.725 Y123.185
G1 X80.487 Y121.947 E.05379
G1 X79.954 Y121.947
G1 X81.191 Y123.185 E.05379
G1 X80.658 Y123.185
G1 X79.42 Y121.947 E.05379
G1 X78.887 Y121.947
G1 X80.125 Y123.185 E.05379
G1 X79.592 Y123.185
G1 X78.354 Y121.947 E.05379
G1 X77.821 Y121.947
G1 X79.058 Y123.185 E.05379
G1 X78.525 Y123.185
G1 X77.287 Y121.947 E.05379
G1 X76.754 Y121.947
G1 X77.992 Y123.185 E.05379
G1 X77.459 Y123.185
G1 X76.221 Y121.947 E.05379
G1 X75.688 Y121.947
G1 X76.925 Y123.185 E.05379
G1 X76.392 Y123.185
G1 X75.154 Y121.947 E.05379
G1 X74.621 Y121.947
G1 X75.859 Y123.185 E.05379
G1 X75.326 Y123.185
G1 X74.088 Y121.947 E.05379
G1 X73.555 Y121.947
G1 X74.792 Y123.185 E.05379
G1 X74.259 Y123.185
G1 X73.021 Y121.947 E.05379
G1 X72.488 Y121.947
G1 X73.726 Y123.185 E.05379
G1 X73.193 Y123.185
G1 X72.417 Y122.41 E.03369
; WIPE_START
M204 S10000
G1 X73.193 Y123.185 E-.41662
G1 X73.726 Y123.185 E-.20264
G1 X73.464 Y122.923 E-.14075
; WIPE_END
G1 E-.04 F1800
G1 X72.952 Y128.778 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.988 Y128.778 E.4443
G1 X89.006 Y126.643 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y123.8 E.08737
G1 X72.994 Y123.8 E.49198
G1 X72.994 Y126.643 E.08737
G1 X88.946 Y126.643 E.49014
G1 X88.629 Y126.266 F30000
G1 F12000
G1 X88.629 Y124.177 E.0642
G1 X73.371 Y124.177 E.46881
G1 X73.371 Y126.266 E.0642
G1 X88.569 Y126.266 E.46697
G1 X88.252 Y125.222 F30000
G1 F12000
G1 X88.252 Y124.554 E.02051
G1 X73.748 Y124.554 E.44564
G1 X73.748 Y125.889 E.04102
G1 X88.252 Y125.889 E.44564
G1 X88.252 Y125.282 E.01867
G1 X87.824 Y125.222 F30000
; LINE_WIDTH: 0.52195
G1 F12000
G1 X87.824 Y124.982 E.00935
G1 X74.176 Y124.982 E.53272
G1 X74.176 Y125.461 E.0187
G1 X87.824 Y125.461 E.53272
G1 X87.824 Y125.282 E.00701
G1 X86.957 Y127.035 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.585 Y127.035 E.05401
G1 X87.192 Y128.428 E.06535
G1 X84.373 Y128.428 E.09351
G1 X82.98 Y127.035 E.06536
G1 X80.909 Y127.035 E.06869
G1 X79.516 Y128.428 E.06536
G1 X76.697 Y128.428 E.09351
G1 X75.304 Y127.035 E.06536
G1 X73.233 Y127.035 E.06869
G1 X72.95 Y127.318 E.01326
G1 X72.95 Y128.428 E.03684
G1 X73.468 Y128.428 E.01718
G1 X72.939 Y128.943 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42679
G1 F3000
G1 X72.939 Y132.519 E.11185
G1 X73.323 Y132.519 E.01201
G1 X73.323 Y129.113 E.10654
G1 X73.706 Y129.113 E.01201
G1 X73.706 Y132.519 E.10654
G1 X74.09 Y132.519 E.01201
G1 X74.09 Y129.113 E.10654
G1 X74.474 Y129.113 E.01201
G1 X74.474 Y132.519 E.10654
G1 X74.858 Y132.519 E.01201
G1 X74.858 Y129.113 E.10654
G1 X75.242 Y129.113 E.01201
G1 X75.242 Y132.519 E.10654
G1 X75.626 Y132.519 E.01201
G1 X75.626 Y129.113 E.10654
G1 X76.01 Y129.113 E.01201
G1 X76.01 Y132.519 E.10654
G1 X76.394 Y132.519 E.01201
M73 P83 R4
G1 X76.394 Y129.113 E.10654
G1 X76.777 Y129.113 E.01201
G1 X76.777 Y132.519 E.10654
G1 X77.161 Y132.519 E.01201
G1 X77.161 Y129.113 E.10654
G1 X77.545 Y129.113 E.01201
G1 X77.545 Y132.519 E.10654
G1 X77.929 Y132.519 E.01201
G1 X77.929 Y129.113 E.10654
G1 X78.313 Y129.113 E.01201
G1 X78.313 Y132.519 E.10654
G1 X78.697 Y132.519 E.01201
G1 X78.697 Y129.113 E.10654
G1 X79.081 Y129.113 E.01201
G1 X79.081 Y132.519 E.10654
G1 X79.464 Y132.519 E.01201
G1 X79.464 Y129.113 E.10654
G1 X79.848 Y129.113 E.01201
G1 X79.848 Y132.519 E.10654
G1 X80.232 Y132.519 E.01201
G1 X80.232 Y129.113 E.10654
G1 X80.616 Y129.113 E.01201
G1 X80.616 Y132.519 E.10654
G1 X81 Y132.519 E.01201
G1 X81 Y129.113 E.10654
G1 X81.384 Y129.113 E.01201
G1 X81.384 Y132.519 E.10654
G1 X81.768 Y132.519 E.01201
G1 X81.768 Y129.113 E.10654
G1 X82.152 Y129.113 E.01201
G1 X82.152 Y132.519 E.10654
G1 X82.535 Y132.519 E.01201
G1 X82.535 Y129.113 E.10654
G1 X82.919 Y129.113 E.01201
G1 X82.919 Y132.519 E.10654
G1 X83.303 Y132.519 E.01201
G1 X83.303 Y129.113 E.10654
G1 X83.687 Y129.113 E.01201
G1 X83.687 Y132.519 E.10654
G1 X84.071 Y132.519 E.01201
G1 X84.071 Y129.113 E.10654
G1 X84.455 Y129.113 E.01201
G1 X84.455 Y132.519 E.10654
G1 X84.839 Y132.519 E.01201
G1 X84.839 Y129.113 E.10654
G1 X85.223 Y129.113 E.01201
G1 X85.223 Y132.519 E.10654
G1 X85.606 Y132.519 E.01201
G1 X85.606 Y129.113 E.10654
G1 X85.99 Y129.113 E.01201
G1 X85.99 Y132.519 E.10654
G1 X86.374 Y132.519 E.01201
G1 X86.374 Y129.113 E.10654
G1 X86.758 Y129.113 E.01201
G1 X86.758 Y132.519 E.10654
G1 X87.142 Y132.519 E.01201
G1 X87.142 Y129.113 E.10654
G1 X87.526 Y129.113 E.01201
G1 X87.526 Y132.519 E.10654
G1 X87.91 Y132.519 E.01201
G1 X87.91 Y129.113 E.10654
G1 X88.293 Y129.113 E.01201
G1 X88.293 Y132.519 E.10654
G1 X88.677 Y132.519 E.01201
G1 X88.677 Y129.113 E.10654
G1 X89.061 Y129.113 E.01201
G1 X89.061 Y132.688 E.11185
G1 X73.209 Y133.728 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.95 Y133.728 E.00856
G1 X72.95 Y132.911 E.02712
G1 X73.503 Y132.911 E.01833
G1 X74.32 Y133.728 E.03835
G1 X74.216 Y133.728 E.00346
G1 X75.034 Y132.911 E.03835
G1 X81.179 Y132.911 E.20385
G1 X81.996 Y133.728 E.03835
G1 X81.892 Y133.728 E.00346
G1 X82.71 Y132.911 E.03835
G1 X88.855 Y132.911 E.20385
G1 X89.05 Y133.105 E.00914
G1 X89.05 Y133.462 E.01183
G1 X88.767 Y133.579 E.01015
G1 X88.767 Y133.728 E.00494
G1 X87.95 Y133.728 E.02709
G1 X72.994 Y134.12 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.419954
G1 F12000
G1 X72.994 Y135.681 E.04797
G1 X183.006 Y135.681 E3.37994
G1 X183.006 Y134.12 E.04797
G1 X167.122 Y134.12 E.488
G1 X166.989 Y134.065 E.00443
G1 X166.908 Y133.886 E.00602
G1 X166.806 Y133.994 E.00457
G1 X159.194 Y133.994 E.23384
G1 X159.073 Y133.95 E.00397
G1 X159.006 Y133.806 E.00489
G1 X159.006 Y132.896 E.02796
G1 X152.994 Y132.896 E.1847
G1 X152.994 Y133.806 E.02796
G1 X152.927 Y133.95 E.00489
G1 X152.806 Y133.994 E.00397
G1 X145.194 Y133.994 E.23384
G1 X145.073 Y133.95 E.00397
G1 X145.006 Y133.806 E.00489
G1 X145.006 Y132.896 E.02796
G1 X138.994 Y132.896 E.1847
G1 X138.994 Y133.806 E.02796
G1 X138.927 Y133.95 E.00489
G1 X138.806 Y133.994 E.00397
G1 X131.194 Y133.994 E.23384
G1 X131.073 Y133.95 E.00397
G1 X131.006 Y133.806 E.00489
G1 X131.006 Y132.896 E.02796
G1 X124.994 Y132.896 E.1847
G1 X124.994 Y133.806 E.02796
G1 X124.927 Y133.95 E.00489
G1 X124.806 Y133.994 E.00397
G1 X117.194 Y133.994 E.23384
G1 X117.073 Y133.95 E.00397
G1 X117.006 Y133.806 E.00489
G1 X117.006 Y132.896 E.02796
G1 X110.994 Y132.896 E.1847
G1 X110.994 Y133.806 E.02796
G1 X110.927 Y133.95 E.00489
G1 X110.806 Y133.994 E.00397
G1 X103.194 Y133.994 E.23384
G1 X103.073 Y133.95 E.00397
G1 X103.006 Y133.806 E.00489
G1 X103.006 Y132.896 E.02796
G1 X96.994 Y132.896 E.1847
G1 X96.994 Y133.806 E.02796
G1 X96.927 Y133.95 E.00489
G1 X96.806 Y133.994 E.00397
G1 X89.189 Y133.994 E.234
G1 X89.092 Y133.886 E.00446
G1 X88.968 Y134.097 E.00751
G1 X88.878 Y134.12 E.00286
G1 X73.054 Y134.12 E.48616
G1 X182.629 Y134.901 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.629 Y134.497 E.0124
G1 X167.122 Y134.497 E.47646
G1 X166.851 Y134.428 E.00859
G1 X166.773 Y134.371 E.00298
G1 X159.194 Y134.371 E.23286
G1 X158.83 Y134.238 E.01191
G1 X158.656 Y133.978 E.00962
G1 X158.629 Y133.273 E.0217
G1 X153.371 Y133.273 E.16155
G1 X153.371 Y133.806 E.01638
G1 X153.344 Y133.978 E.00537
G1 X153.17 Y134.238 E.00962
G1 X152.903 Y134.363 E.00903
G1 X152.806 Y134.371 E.00301
G1 X145.194 Y134.371 E.23386
G1 X144.83 Y134.238 E.01191
G1 X144.656 Y133.978 E.00962
G1 X144.629 Y133.273 E.0217
G1 X139.371 Y133.273 E.16155
G1 X139.371 Y133.806 E.01638
G1 X139.344 Y133.978 E.00537
G1 X139.17 Y134.238 E.00962
G1 X138.903 Y134.363 E.00903
G1 X138.806 Y134.371 E.00301
G1 X131.194 Y134.371 E.23386
G1 X130.83 Y134.238 E.01191
G1 X130.656 Y133.978 E.00962
G1 X130.629 Y133.273 E.0217
G1 X125.371 Y133.273 E.16155
G1 X125.371 Y133.806 E.01638
G1 X125.344 Y133.978 E.00537
G1 X125.17 Y134.238 E.00962
G1 X124.903 Y134.363 E.00903
G1 X124.806 Y134.371 E.00301
G1 X117.194 Y134.371 E.23386
G1 X116.83 Y134.238 E.01191
G1 X116.656 Y133.978 E.00962
G1 X116.629 Y133.273 E.0217
G1 X111.371 Y133.273 E.16155
G1 X111.371 Y133.806 E.01638
G1 X111.344 Y133.978 E.00537
G1 X111.17 Y134.238 E.00962
G1 X110.903 Y134.363 E.00903
G1 X110.806 Y134.371 E.00301
G1 X103.194 Y134.371 E.23386
G1 X102.83 Y134.238 E.01191
G1 X102.656 Y133.978 E.00962
G1 X102.629 Y133.273 E.0217
G1 X97.371 Y133.273 E.16155
G1 X97.371 Y133.806 E.01638
G1 X97.344 Y133.978 E.00537
G1 X97.17 Y134.238 E.00962
G1 X96.903 Y134.363 E.00903
G1 X96.806 Y134.371 E.00301
G1 X89.227 Y134.371 E.23286
G1 X88.976 Y134.489 E.00853
G1 X88.878 Y134.497 E.00301
G1 X73.371 Y134.497 E.47646
G1 X73.371 Y135.304 E.0248
G1 X182.629 Y135.304 E3.3571
G1 X182.629 Y134.961 E.01056
G1 X159.194 Y134.838 F30000
; LINE_WIDTH: 0.59896
G1 F11330.12
G1 X166.628 Y134.838 E.33682
; LINE_WIDTH: 0.577957
G1 F11774.894
G1 X166.793 Y134.859 E.00724
; LINE_WIDTH: 0.53595
G1 F12000
G1 X166.957 Y134.88 E.00667
; LINE_WIDTH: 0.47316
G1 X167.122 Y134.901 E.00582
G1 X182.165 Y134.901 E.52739
G1 X159.194 Y134.838 F30000
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X159.043 Y134.76 E.00741
; LINE_WIDTH: 0.531847
G1 F12000
G1 X158.891 Y134.682 E.00679
; LINE_WIDTH: 0.487104
G1 X158.739 Y134.605 E.00617
; LINE_WIDTH: 0.420567
G1 X158.587 Y134.527 E.00525
G1 X158.297 Y134.093 E.01606
G1 X158.252 Y133.65 E.01373
G1 X153.748 Y133.65 E.13859
G1 X153.703 Y134.093 E.01373
G1 X153.413 Y134.527 E.01606
; LINE_WIDTH: 0.444317
G1 X153.306 Y134.603 E.00428
; LINE_WIDTH: 0.492969
G1 X153.199 Y134.678 E.0048
; LINE_WIDTH: 0.541622
G1 X153.092 Y134.754 E.00532
; LINE_WIDTH: 0.590274
G1 F11509.924
G1 X152.985 Y134.83 E.00584
G1 X153.129 Y134.854 E.00648
; LINE_WIDTH: 0.541622
G1 F12000
G1 X153.272 Y134.879 E.00591
; LINE_WIDTH: 0.492969
G1 X153.415 Y134.903 E.00533
; LINE_WIDTH: 0.420694
G1 X153.559 Y134.927 E.00448
G1 X158.441 Y134.927 E.15031
; LINE_WIDTH: 0.442362
G1 X158.615 Y134.907 E.00568
; LINE_WIDTH: 0.487104
G1 X158.788 Y134.886 E.00632
; LINE_WIDTH: 0.531847
G1 X158.961 Y134.865 E.00696
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X159.135 Y134.845 E.00759
G1 X158.1 Y134.514 F30000
; LINE_WIDTH: 0.49319
G1 F12000
G1 X157.903 Y134.22 E.01298
G1 X157.878 Y134.063 E.00581
G1 X154.122 Y134.063 E.13784
G1 X154.097 Y134.22 E.00581
G1 X153.9 Y134.514 E.01298
G1 X158.04 Y134.514 E.1519
G1 X145.194 Y134.838 F30000
; LINE_WIDTH: 0.599082
G1 F11327.651
G1 X152.925 Y134.833 E.35037
G1 X145.194 Y134.838 F30000
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X145.043 Y134.76 E.00741
; LINE_WIDTH: 0.531847
G1 F12000
G1 X144.891 Y134.682 E.00679
; LINE_WIDTH: 0.487104
G1 X144.739 Y134.605 E.00617
; LINE_WIDTH: 0.420567
G1 X144.587 Y134.527 E.00525
G1 X144.297 Y134.093 E.01606
G1 X144.252 Y133.65 E.01373
G1 X139.748 Y133.65 E.13859
G1 X139.703 Y134.093 E.01373
G1 X139.413 Y134.527 E.01606
; LINE_WIDTH: 0.444317
G1 X139.306 Y134.603 E.00428
; LINE_WIDTH: 0.492969
G1 X139.199 Y134.678 E.0048
; LINE_WIDTH: 0.541622
G1 X139.092 Y134.754 E.00532
; LINE_WIDTH: 0.590274
G1 F11509.924
G1 X138.985 Y134.83 E.00584
G1 X139.129 Y134.854 E.00648
; LINE_WIDTH: 0.541622
G1 F12000
G1 X139.272 Y134.879 E.00591
; LINE_WIDTH: 0.492969
G1 X139.415 Y134.903 E.00533
; LINE_WIDTH: 0.420694
G1 X139.559 Y134.927 E.00448
G1 X144.441 Y134.927 E.15031
; LINE_WIDTH: 0.442362
G1 X144.615 Y134.907 E.00568
; LINE_WIDTH: 0.487104
G1 X144.788 Y134.886 E.00632
; LINE_WIDTH: 0.531847
G1 X144.961 Y134.865 E.00696
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X145.135 Y134.845 E.00759
G1 X144.1 Y134.514 F30000
; LINE_WIDTH: 0.49319
G1 F12000
G1 X143.903 Y134.22 E.01298
G1 X143.878 Y134.063 E.00581
G1 X140.122 Y134.063 E.13784
G1 X140.097 Y134.22 E.00581
G1 X139.9 Y134.514 E.01298
G1 X144.04 Y134.514 E.1519
G1 X131.194 Y134.838 F30000
; LINE_WIDTH: 0.599082
G1 F11327.651
G1 X138.925 Y134.833 E.35037
G1 X131.194 Y134.838 F30000
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X131.043 Y134.76 E.00741
; LINE_WIDTH: 0.531847
G1 F12000
G1 X130.891 Y134.682 E.00679
; LINE_WIDTH: 0.487104
G1 X130.739 Y134.605 E.00617
; LINE_WIDTH: 0.420567
G1 X130.587 Y134.527 E.00525
G1 X130.297 Y134.093 E.01606
G1 X130.252 Y133.65 E.01373
G1 X125.748 Y133.65 E.13859
G1 X125.703 Y134.093 E.01373
G1 X125.413 Y134.527 E.01606
; LINE_WIDTH: 0.444317
G1 X125.306 Y134.603 E.00428
; LINE_WIDTH: 0.492969
G1 X125.199 Y134.678 E.0048
; LINE_WIDTH: 0.541622
G1 X125.092 Y134.754 E.00532
; LINE_WIDTH: 0.590274
G1 F11509.924
G1 X124.985 Y134.83 E.00584
G1 X125.129 Y134.854 E.00648
; LINE_WIDTH: 0.541622
G1 F12000
G1 X125.272 Y134.879 E.00591
; LINE_WIDTH: 0.492969
G1 X125.415 Y134.903 E.00533
; LINE_WIDTH: 0.420694
G1 X125.559 Y134.927 E.00448
G1 X130.441 Y134.927 E.15031
; LINE_WIDTH: 0.442362
G1 X130.615 Y134.907 E.00568
; LINE_WIDTH: 0.487104
G1 X130.788 Y134.886 E.00632
; LINE_WIDTH: 0.531847
G1 X130.961 Y134.865 E.00696
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X131.135 Y134.845 E.00759
G1 X130.1 Y134.514 F30000
; LINE_WIDTH: 0.49319
G1 F12000
G1 X129.903 Y134.22 E.01298
G1 X129.878 Y134.063 E.00581
G1 X126.122 Y134.063 E.13784
G1 X126.097 Y134.22 E.00581
G1 X125.9 Y134.514 E.01298
G1 X130.04 Y134.514 E.1519
G1 X117.194 Y134.838 F30000
; LINE_WIDTH: 0.599082
G1 F11327.651
G1 X124.925 Y134.833 E.35037
G1 X117.194 Y134.838 F30000
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X117.043 Y134.76 E.00741
; LINE_WIDTH: 0.531847
G1 F12000
G1 X116.891 Y134.682 E.00679
; LINE_WIDTH: 0.487104
G1 X116.739 Y134.605 E.00617
; LINE_WIDTH: 0.420567
G1 X116.587 Y134.527 E.00525
G1 X116.297 Y134.093 E.01606
G1 X116.252 Y133.65 E.01373
G1 X111.748 Y133.65 E.13859
G1 X111.703 Y134.093 E.01373
G1 X111.413 Y134.527 E.01606
; LINE_WIDTH: 0.444317
G1 X111.306 Y134.603 E.00428
; LINE_WIDTH: 0.492969
G1 X111.199 Y134.678 E.0048
; LINE_WIDTH: 0.541622
G1 X111.092 Y134.754 E.00532
; LINE_WIDTH: 0.590274
G1 F11509.924
G1 X110.985 Y134.83 E.00584
G1 X111.129 Y134.854 E.00648
; LINE_WIDTH: 0.541622
G1 F12000
G1 X111.272 Y134.879 E.00591
; LINE_WIDTH: 0.492969
G1 X111.415 Y134.903 E.00533
; LINE_WIDTH: 0.420694
G1 X111.559 Y134.927 E.00448
G1 X116.441 Y134.927 E.15031
; LINE_WIDTH: 0.442362
G1 X116.615 Y134.907 E.00568
; LINE_WIDTH: 0.487104
G1 X116.788 Y134.886 E.00632
; LINE_WIDTH: 0.531847
G1 X116.961 Y134.865 E.00696
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X117.135 Y134.845 E.00759
G1 X116.1 Y134.514 F30000
; LINE_WIDTH: 0.49319
G1 F12000
G1 X115.903 Y134.22 E.01298
G1 X115.878 Y134.063 E.00581
G1 X112.122 Y134.063 E.13784
G1 X112.097 Y134.22 E.00581
G1 X111.9 Y134.514 E.01298
G1 X116.04 Y134.514 E.1519
G1 X103.194 Y134.838 F30000
; LINE_WIDTH: 0.599082
G1 F11327.651
G1 X110.925 Y134.833 E.35037
G1 X103.194 Y134.838 F30000
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X103.043 Y134.76 E.00741
; LINE_WIDTH: 0.531847
G1 F12000
G1 X102.891 Y134.682 E.00679
; LINE_WIDTH: 0.487104
G1 X102.739 Y134.605 E.00617
; LINE_WIDTH: 0.420567
G1 X102.587 Y134.527 E.00525
G1 X102.297 Y134.093 E.01606
G1 X102.252 Y133.65 E.01373
G1 X97.748 Y133.65 E.13859
G1 X97.703 Y134.093 E.01373
G1 X97.413 Y134.527 E.01606
; LINE_WIDTH: 0.444317
G1 X97.306 Y134.603 E.00428
; LINE_WIDTH: 0.492969
G1 X97.199 Y134.678 E.0048
; LINE_WIDTH: 0.541622
G1 X97.092 Y134.754 E.00532
; LINE_WIDTH: 0.590274
G1 F11509.924
G1 X96.985 Y134.83 E.00584
G1 X97.129 Y134.854 E.00648
; LINE_WIDTH: 0.541622
G1 F12000
G1 X97.272 Y134.879 E.00591
; LINE_WIDTH: 0.492969
G1 X97.415 Y134.903 E.00533
; LINE_WIDTH: 0.420694
G1 X97.559 Y134.927 E.00448
G1 X102.441 Y134.927 E.15031
; LINE_WIDTH: 0.442362
G1 X102.615 Y134.907 E.00568
; LINE_WIDTH: 0.487104
G1 X102.788 Y134.886 E.00632
; LINE_WIDTH: 0.531847
G1 X102.961 Y134.865 E.00696
; LINE_WIDTH: 0.576589
G1 F11805.076
G1 X103.135 Y134.845 E.00759
G1 X102.1 Y134.514 F30000
; LINE_WIDTH: 0.49319
G1 F12000
G1 X101.903 Y134.22 E.01298
G1 X101.878 Y134.063 E.00581
G1 X98.122 Y134.063 E.13784
G1 X98.097 Y134.22 E.00581
G1 X97.9 Y134.514 E.01298
G1 X102.04 Y134.514 E.1519
G1 X73.775 Y134.901 F30000
; LINE_WIDTH: 0.47293
G1 F12000
G1 X88.878 Y134.901 E.52922
; LINE_WIDTH: 0.493944
G1 X89.043 Y134.88 E.0061
; LINE_WIDTH: 0.53595
G1 X89.207 Y134.859 E.00667
; LINE_WIDTH: 0.598501
G1 F11339.481
G1 X89.372 Y134.838 E.00752
G1 X96.806 Y134.838 E.33654
; LINE_WIDTH: 0.60678
G1 F11172.987
G1 X96.925 Y134.833 E.00551
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F11172.987
G1 X96.806 Y134.838 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 22/32
; update layer progress
M73 L22
M991 S0 P21 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.6 I.036 J1.216 P1  F30000
G1 X138.602 Y133.602 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y124.208 E.31163
G1 X145.398 Y124.208 E.22543
G1 X145.398 Y133.602 E.31163
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y124.208 E.31163
G1 X159.398 Y124.208 E.22543
G1 X159.398 Y133.602 E.31163
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y124.208 E.31163
G1 X183.398 Y124.208 E.55715
G1 X183.398 Y135.594 E.3777
G1 X72.602 Y135.594 E3.6753
G1 X72.602 Y124.208 E.3777
G1 X89.398 Y124.208 E.55715
G1 X89.398 Y133.602 E.31163
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y124.208 E.31163
G1 X103.398 Y124.208 E.22543
G1 X103.398 Y133.602 E.31163
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y124.208 E.31163
G1 X117.398 Y124.208 E.22543
G1 X117.398 Y133.602 E.31163
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y124.208 E.31163
G1 X131.398 Y124.208 E.22543
G1 X131.398 Y133.602 E.31163
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y122.54 E.32786
G1 X145.79 Y122.54 E.23291
G1 X145.79 Y133.21 E.32786
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y122.54 E.32786
G1 X159.79 Y122.54 E.23291
G1 X159.79 Y133.21 E.32786
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y122.54 E.32786
G1 X183.79 Y122.54 E.54018
G1 X183.79 Y135.986 E.41316
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y135.986 E3.42854
G1 X72.21 Y122.54 E.41316
G1 X89.79 Y122.54 E.54018
G1 X89.79 Y133.21 E.32786
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y122.54 E.32786
G1 X103.79 Y122.54 E.23291
G1 X103.79 Y133.21 E.32786
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y122.54 E.32786
G1 X117.79 Y122.54 E.23291
G1 X117.79 Y133.21 E.32786
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y122.54 E.32786
G1 X131.79 Y122.54 E.23291
G1 X131.79 Y133.21 E.32786
G1 X138.15 Y133.21 E.19542
M204 S10000
G1 X138.766 Y133.615 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42159
G1 F15000
G1 X142.76 Y129.621 E.17429
G1 X142.224 Y129.621 E.01652
G1 X138.935 Y132.909 E.14352
G1 X138.935 Y132.374 E.01652
G1 X141.689 Y129.621 E.12015
G1 X141.153 Y129.621 E.01652
G1 X138.935 Y131.838 E.09678
G1 X138.935 Y131.303 E.01652
G1 X140.618 Y129.621 E.07341
G1 X140.082 Y129.621 E.01652
G1 X138.935 Y130.767 E.05004
G1 X138.935 Y130.232 E.01652
G1 X139.546 Y129.621 E.02667
G1 X139.011 Y129.621 E.01652
G1 X138.766 Y129.866 E.01071
G1 X144.952 Y129.228 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X145.05 Y129.228 E.00324
G1 X145.05 Y127.698 E.05078
G1 X144.387 Y127.035 E.03108
G1 X142.317 Y127.035 E.06869
G1 X140.123 Y129.228 E.10288
G1 X138.95 Y129.228 E.03891
G1 X138.95 Y128.773 E.0151
G1 X145.006 Y125.622 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y124.6 E.0314
G1 X138.994 Y124.6 E.18472
G1 X138.994 Y126.643 E.06279
G1 X145.006 Y126.643 E.18472
G1 X145.006 Y125.682 E.02955
G1 X144.629 Y125.622 F30000
G1 F12000
G1 X144.629 Y124.977 E.01981
G1 X139.371 Y124.977 E.16155
G1 X139.371 Y126.266 E.03962
G1 X144.629 Y126.266 E.16155
G1 X144.629 Y125.682 E.01797
G1 X144.212 Y125.622 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X144.212 Y125.394 E.00848
G1 X139.788 Y125.394 E.16446
G1 X139.788 Y125.85 E.01696
G1 X144.212 Y125.85 E.16446
G1 X144.212 Y125.682 E.00625
; WIPE_START
G1 X144.212 Y125.85 E-.06387
G1 X142.38 Y125.85 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y123.615 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.212 Y123.985 E.01609
G1 X144.679 Y123.985
G1 X145.583 Y123.082 E.03926
G1 X145.384 Y122.747
G1 X144.146 Y123.985 E.05379
G1 X143.613 Y123.985
G1 X144.851 Y122.747 E.05379
G1 X144.317 Y122.747
G1 X143.079 Y123.985 E.05379
G1 X142.546 Y123.985
G1 X143.784 Y122.747 E.05379
G1 X143.251 Y122.747
G1 X142.013 Y123.985 E.05379
G1 X141.48 Y123.985
G1 X142.718 Y122.747 E.05379
G1 X142.184 Y122.747
G1 X140.946 Y123.985 E.05379
G1 X140.413 Y123.985
G1 X141.651 Y122.747 E.05379
G1 X141.118 Y122.747
G1 X139.88 Y123.985 E.05379
G1 X139.347 Y123.985
G1 X140.585 Y122.747 E.05379
G1 X140.051 Y122.747
G1 X138.813 Y123.985 E.05379
G1 X138.417 Y123.848
G1 X139.518 Y122.747 E.04783
G1 X138.985 Y122.747
G1 X138.417 Y123.315 E.02465
; WIPE_START
M204 S10000
G1 X138.985 Y122.747 E-.3049
M73 P84 R4
G1 X139.518 Y122.747 E-.20264
G1 X139.048 Y123.217 E-.25247
; WIPE_END
G1 E-.04 F1800
G1 X131.449 Y123.926 Z4.8 F30000
G1 X130.815 Y123.985 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X131.583 Y123.217 E.03338
G1 X131.519 Y122.747
G1 X130.281 Y123.985 E.05379
G1 X129.748 Y123.985
G1 X130.986 Y122.747 E.05379
G1 X130.453 Y122.747
G1 X129.215 Y123.985 E.05379
G1 X128.681 Y123.985
G1 X129.919 Y122.747 E.05379
G1 X129.386 Y122.747
G1 X128.148 Y123.985 E.05379
G1 X127.615 Y123.985
G1 X128.853 Y122.747 E.05379
G1 X128.32 Y122.747
G1 X127.082 Y123.985 E.05379
G1 X126.548 Y123.985
G1 X127.786 Y122.747 E.05379
G1 X127.253 Y122.747
G1 X126.015 Y123.985 E.05379
G1 X125.482 Y123.985
G1 X126.72 Y122.747 E.05379
G1 X126.187 Y122.747
G1 X124.949 Y123.985 E.05379
G1 X124.417 Y123.983
G1 X125.653 Y122.747 E.05371
G1 X125.12 Y122.747
G1 X124.417 Y123.45 E.03053
; WIPE_START
M204 S10000
G1 X125.12 Y122.747 E-.37762
G1 X125.653 Y122.747 E-.20264
G1 X125.319 Y123.082 E-.17974
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.8 I-1.213 J-.098 P1  F30000
G1 X124.766 Y129.942 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42159
G1 F15000
G1 X125.087 Y129.621 E.01405
G1 X125.623 Y129.621 E.01652
G1 X124.935 Y130.308 E.03001
G1 X124.935 Y130.844 E.01652
G1 X126.158 Y129.621 E.05338
G1 X126.694 Y129.621 E.01652
G1 X124.935 Y131.379 E.07675
G1 X124.935 Y131.915 E.01652
G1 X127.229 Y129.621 E.10012
G1 X127.765 Y129.621 E.01652
G1 X124.935 Y132.45 E.12349
G1 X124.935 Y132.986 E.01652
G1 X128.301 Y129.621 E.14686
G1 X128.836 Y129.621 E.01652
G1 X124.766 Y133.691 E.17763
G1 X129.6 Y129.228 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.05 Y129.228 E.04808
G1 X131.05 Y129.05 E.00593
G1 X129.035 Y127.035 E.0945
G1 X126.965 Y127.035 E.06869
G1 X124.95 Y129.05 E.0945
G1 X124.95 Y129.228 E.00593
G1 X126.4 Y129.228 E.04808
G1 X131.006 Y125.622 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y124.6 E.0314
G1 X124.994 Y124.6 E.18472
G1 X124.994 Y126.643 E.06279
G1 X131.006 Y126.643 E.18472
G1 X131.006 Y125.682 E.02955
G1 X130.629 Y125.622 F30000
G1 F12000
G1 X130.629 Y124.977 E.01981
G1 X125.371 Y124.977 E.16155
G1 X125.371 Y126.266 E.03962
G1 X130.629 Y126.266 E.16155
G1 X130.629 Y125.682 E.01797
G1 X130.212 Y125.622 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X130.212 Y125.394 E.00848
G1 X125.788 Y125.394 E.16446
G1 X125.788 Y125.85 E.01696
G1 X130.212 Y125.85 E.16446
G1 X130.212 Y125.682 E.00625
; WIPE_START
G1 X130.212 Y125.85 E-.06387
G1 X128.38 Y125.85 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X120.944 Y124.13 Z4.8 F30000
G1 X117.583 Y123.353 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X116.95 Y123.985 E.0275
G1 X116.417 Y123.985
G1 X117.583 Y122.819 E.05067
G1 X117.121 Y122.747
G1 X115.883 Y123.985 E.05379
G1 X115.35 Y123.985
G1 X116.588 Y122.747 E.05379
G1 X116.055 Y122.747
G1 X114.817 Y123.985 E.05379
G1 X114.284 Y123.985
G1 X115.521 Y122.747 E.05379
G1 X114.988 Y122.747
G1 X113.75 Y123.985 E.05379
G1 X113.217 Y123.985
G1 X114.455 Y122.747 E.05379
G1 X113.922 Y122.747
G1 X112.684 Y123.985 E.05379
G1 X112.15 Y123.985
G1 X113.388 Y122.747 E.05379
G1 X112.855 Y122.747
G1 X111.617 Y123.985 E.05379
G1 X111.084 Y123.985
G1 X112.322 Y122.747 E.05379
G1 X111.789 Y122.747
G1 X110.551 Y123.985 E.05379
G1 X110.417 Y123.585
G1 X111.255 Y122.747 E.03641
; WIPE_START
M204 S10000
G1 X110.417 Y123.585 E-.45033
G1 X110.551 Y123.985 E-.1602
G1 X110.829 Y123.707 E-.14948
; WIPE_END
G1 E-.04 F1800
G1 X117.006 Y125.622 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y124.6 E.0314
G1 X110.994 Y124.6 E.18472
G1 X110.994 Y126.643 E.06279
G1 X117.006 Y126.643 E.18472
G1 X117.006 Y125.682 E.02955
G1 X116.629 Y125.622 F30000
G1 F12000
G1 X116.629 Y124.977 E.01981
G1 X111.371 Y124.977 E.16155
G1 X111.371 Y126.266 E.03962
G1 X116.629 Y126.266 E.16155
G1 X116.629 Y125.682 E.01797
G1 X116.212 Y125.622 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X116.212 Y125.394 E.00848
G1 X111.788 Y125.394 E.16446
G1 X111.788 Y125.85 E.01696
G1 X116.212 Y125.85 E.16446
G1 X116.212 Y125.682 E.00625
G1 X117.05 Y128.773 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X117.05 Y129.228 E.0151
G1 X115.877 Y129.228 E.03891
G1 X113.683 Y127.035 E.10288
G1 X111.613 Y127.035 E.06869
G1 X110.95 Y127.698 E.03108
G1 X110.95 Y129.228 E.05078
G1 X111.048 Y129.228 E.00324
G1 X110.766 Y130.019 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42159
G1 F15000
G1 X111.164 Y129.621 E.01738
G1 X111.699 Y129.621 E.01652
G1 X110.935 Y130.385 E.03335
G1 X110.935 Y130.92 E.01652
G1 X112.235 Y129.621 E.05672
G1 X112.77 Y129.621 E.01652
G1 X110.935 Y131.456 E.08009
G1 X110.935 Y131.991 E.01652
G1 X113.306 Y129.621 E.10345
G1 X113.841 Y129.621 E.01652
G1 X110.935 Y132.527 E.12682
G1 X110.935 Y133.062 E.01652
G1 X114.377 Y129.621 E.15019
G1 X114.913 Y129.621 E.01652
G1 X109.272 Y135.261 E.24613
G1 X109.808 Y135.261 E.01652
G1 X115.448 Y129.621 E.24613
G1 X115.984 Y129.621 E.01652
G1 X110.343 Y135.261 E.24613
G1 X110.879 Y135.261 E.01652
G1 X116.519 Y129.621 E.24613
G1 X117.055 Y129.621 E.01652
G1 X111.414 Y135.261 E.24613
G1 X111.95 Y135.261 E.01652
G1 X117.065 Y130.146 E.22321
G1 X117.065 Y130.681 E.01652
G1 X112.485 Y135.261 E.19984
G1 X113.021 Y135.261 E.01652
G1 X117.065 Y131.217 E.17647
G1 X117.065 Y131.752 E.01652
G1 X113.556 Y135.261 E.1531
G1 X114.092 Y135.261 E.01652
G1 X117.065 Y132.288 E.12973
G1 X117.065 Y132.823 E.01652
G1 X114.627 Y135.261 E.10636
G1 X115.163 Y135.261 E.01652
G1 X117.065 Y133.359 E.08299
G1 X117.065 Y133.895 E.01652
G1 X115.698 Y135.261 E.05962
G1 X116.234 Y135.261 E.01652
G1 X117.56 Y133.935 E.05785
G1 X118.095 Y133.935 E.01652
G1 X116.77 Y135.261 E.05785
G1 X117.305 Y135.261 E.01652
G1 X118.631 Y133.935 E.05785
G1 X119.166 Y133.935 E.01652
G1 X117.841 Y135.261 E.05785
G1 X118.376 Y135.261 E.01652
G1 X119.702 Y133.935 E.05785
G1 X120.237 Y133.935 E.01652
G1 X118.912 Y135.261 E.05785
G1 X119.447 Y135.261 E.01652
G1 X120.773 Y133.935 E.05785
G1 X121.308 Y133.935 E.01652
G1 X119.983 Y135.261 E.05785
G1 X120.518 Y135.261 E.01652
G1 X121.844 Y133.935 E.05785
G1 X122.379 Y133.935 E.01652
G1 X121.054 Y135.261 E.05785
G1 X121.589 Y135.261 E.01652
G1 X122.915 Y133.935 E.05785
G1 X123.45 Y133.935 E.01652
G1 X122.125 Y135.261 E.05785
G1 X122.66 Y135.261 E.01652
G1 X123.986 Y133.935 E.05785
G1 X124.521 Y133.935 E.01652
G1 X123.196 Y135.261 E.05785
G1 X123.731 Y135.261 E.01652
G1 X129.372 Y129.621 E.24613
G1 X129.907 Y129.621 E.01652
G1 X124.267 Y135.261 E.24613
G1 X124.802 Y135.261 E.01652
G1 X130.443 Y129.621 E.24613
G1 X130.978 Y129.621 E.01652
G1 X125.338 Y135.261 E.24613
G1 X125.873 Y135.261 E.01652
G1 X131.065 Y130.069 E.22654
G1 X131.065 Y130.605 E.01652
G1 X126.409 Y135.261 E.20318
G1 X126.944 Y135.261 E.01652
G1 X131.065 Y131.14 E.17981
G1 X131.065 Y131.676 E.01652
G1 X127.48 Y135.261 E.15644
G1 X128.015 Y135.261 E.01652
G1 X131.065 Y132.211 E.13307
G1 X131.065 Y132.747 E.01652
G1 X128.551 Y135.261 E.1097
G1 X129.086 Y135.261 E.01652
G1 X131.065 Y133.283 E.08633
G1 X131.065 Y133.818 E.01652
G1 X129.622 Y135.261 E.06296
G1 X130.158 Y135.261 E.01652
G1 X131.483 Y133.935 E.05785
G1 X132.019 Y133.935 E.01652
G1 X130.693 Y135.261 E.05785
G1 X131.229 Y135.261 E.01652
G1 X132.554 Y133.935 E.05785
G1 X133.09 Y133.935 E.01652
G1 X131.764 Y135.261 E.05785
G1 X132.3 Y135.261 E.01652
G1 X133.625 Y133.935 E.05785
G1 X134.161 Y133.935 E.01652
G1 X132.835 Y135.261 E.05785
G1 X133.371 Y135.261 E.01652
G1 X134.696 Y133.935 E.05785
G1 X135.232 Y133.935 E.01652
G1 X133.906 Y135.261 E.05785
G1 X134.442 Y135.261 E.01652
G1 X135.767 Y133.935 E.05785
G1 X136.303 Y133.935 E.01652
G1 X134.977 Y135.261 E.05785
G1 X135.513 Y135.261 E.01652
G1 X136.838 Y133.935 E.05785
G1 X137.374 Y133.935 E.01652
G1 X136.048 Y135.261 E.05785
G1 X136.584 Y135.261 E.01652
G1 X137.909 Y133.935 E.05785
G1 X138.445 Y133.935 E.01652
G1 X137.119 Y135.261 E.05785
G1 X137.655 Y135.261 E.01652
G1 X143.295 Y129.621 E.24613
G1 X143.831 Y129.621 E.01652
G1 X138.19 Y135.261 E.24613
G1 X138.726 Y135.261 E.01652
G1 X144.366 Y129.621 E.24613
G1 X144.902 Y129.621 E.01652
G1 X139.261 Y135.261 E.24613
G1 X139.797 Y135.261 E.01652
G1 X145.065 Y129.993 E.22988
G1 X145.065 Y130.528 E.01652
G1 X140.332 Y135.261 E.20651
G1 X140.868 Y135.261 E.01652
G1 X145.065 Y131.064 E.18314
G1 X145.065 Y131.599 E.01652
G1 X141.403 Y135.261 E.15977
G1 X141.939 Y135.261 E.01652
G1 X145.065 Y132.135 E.13641
G1 X145.065 Y132.671 E.01652
G1 X142.474 Y135.261 E.11304
G1 X143.01 Y135.261 E.01652
G1 X145.065 Y133.206 E.08967
G1 X145.065 Y133.742 E.01652
G1 X143.546 Y135.261 E.0663
G1 X144.081 Y135.261 E.01652
G1 X145.407 Y133.935 E.05785
G1 X145.942 Y133.935 E.01652
G1 X144.617 Y135.261 E.05785
G1 X145.152 Y135.261 E.01652
G1 X146.478 Y133.935 E.05785
G1 X147.013 Y133.935 E.01652
G1 X145.688 Y135.261 E.05785
G1 X146.223 Y135.261 E.01652
G1 X147.549 Y133.935 E.05785
G1 X148.084 Y133.935 E.01652
G1 X146.759 Y135.261 E.05785
G1 X147.294 Y135.261 E.01652
G1 X148.62 Y133.935 E.05785
G1 X149.155 Y133.935 E.01652
G1 X147.83 Y135.261 E.05785
G1 X148.365 Y135.261 E.01652
G1 X149.691 Y133.935 E.05785
G1 X150.226 Y133.935 E.01652
G1 X148.901 Y135.261 E.05785
G1 X149.436 Y135.261 E.01652
G1 X150.762 Y133.935 E.05785
G1 X151.297 Y133.935 E.01652
G1 X149.972 Y135.261 E.05785
G1 X150.507 Y135.261 E.01652
G1 X151.833 Y133.935 E.05785
G1 X152.368 Y133.935 E.01652
G1 X151.043 Y135.261 E.05785
G1 X151.578 Y135.261 E.01652
G1 X157.219 Y129.621 E.24613
G1 X157.754 Y129.621 E.01652
G1 X152.114 Y135.261 E.24613
G1 X152.649 Y135.261 E.01652
G1 X158.29 Y129.621 E.24613
G1 X158.825 Y129.621 E.01652
G1 X153.185 Y135.261 E.24613
G1 X153.72 Y135.261 E.01652
G1 X159.065 Y129.916 E.23322
G1 X159.065 Y130.452 E.01652
G1 X154.256 Y135.261 E.20985
G1 X154.791 Y135.261 E.01652
G1 X159.065 Y130.988 E.18648
G1 X159.065 Y131.523 E.01652
G1 X155.327 Y135.261 E.16311
G1 X155.862 Y135.261 E.01652
G1 X159.065 Y132.059 E.13974
G1 X159.065 Y132.594 E.01652
G1 X156.398 Y135.261 E.11637
G1 X156.934 Y135.261 E.01652
G1 X159.065 Y133.13 E.093
G1 X159.065 Y133.665 E.01652
G1 X157.469 Y135.261 E.06963
G1 X158.005 Y135.261 E.01652
G1 X159.33 Y133.935 E.05785
G1 X159.866 Y133.935 E.01652
G1 X158.54 Y135.261 E.05785
G1 X159.076 Y135.261 E.01652
G1 X160.401 Y133.935 E.05785
G1 X160.937 Y133.935 E.01652
G1 X159.611 Y135.261 E.05785
G1 X160.147 Y135.261 E.01652
G1 X161.472 Y133.935 E.05785
G1 X162.008 Y133.935 E.01652
G1 X160.682 Y135.261 E.05785
G1 X161.218 Y135.261 E.01652
G1 X162.543 Y133.935 E.05785
G1 X163.079 Y133.935 E.01652
G1 X161.753 Y135.261 E.05785
G1 X162.289 Y135.261 E.01652
G1 X163.614 Y133.935 E.05785
G1 X164.15 Y133.935 E.01652
G1 X162.824 Y135.261 E.05785
G1 X163.36 Y135.261 E.01652
G1 X164.685 Y133.935 E.05785
G1 X165.221 Y133.935 E.01652
G1 X163.895 Y135.261 E.05785
G1 X164.431 Y135.261 E.01652
G1 X165.756 Y133.935 E.05785
G1 X166.292 Y133.935 E.01652
G1 X164.797 Y135.431 E.06525
G1 X167.292 Y133.471 F30000
G1 F15000
G1 X165.502 Y135.261 E.0781
G1 X166.037 Y135.261 E.01652
G1 X167.658 Y133.641 E.0707
G1 X168.193 Y133.641 E.01652
G1 X166.573 Y135.261 E.0707
G1 X167.108 Y135.261 E.01652
G1 X168.729 Y133.641 E.0707
G1 X169.264 Y133.641 E.01652
G1 X167.644 Y135.261 E.0707
G1 X168.179 Y135.261 E.01652
G1 X169.8 Y133.641 E.0707
G1 X170.335 Y133.641 E.01652
G1 X168.715 Y135.261 E.0707
G1 X169.25 Y135.261 E.01652
G1 X170.871 Y133.641 E.0707
G1 X171.406 Y133.641 E.01652
G1 X169.786 Y135.261 E.0707
G1 X170.322 Y135.261 E.01652
G1 X171.942 Y133.641 E.0707
G1 X172.477 Y133.641 E.01652
G1 X170.857 Y135.261 E.0707
G1 X171.393 Y135.261 E.01652
G1 X173.013 Y133.641 E.0707
G1 X173.548 Y133.641 E.01652
G1 X171.928 Y135.261 E.0707
G1 X172.464 Y135.261 E.01652
G1 X174.084 Y133.641 E.0707
G1 X174.619 Y133.641 E.01652
G1 X172.999 Y135.261 E.0707
G1 X173.535 Y135.261 E.01652
G1 X175.155 Y133.641 E.0707
G1 X175.69 Y133.641 E.01652
G1 X174.07 Y135.261 E.0707
G1 X174.606 Y135.261 E.01652
G1 X176.226 Y133.641 E.0707
G1 X176.761 Y133.641 E.01652
G1 X175.141 Y135.261 E.0707
G1 X175.677 Y135.261 E.01652
G1 X177.297 Y133.641 E.0707
G1 X177.832 Y133.641 E.01652
G1 X176.212 Y135.261 E.0707
G1 X176.748 Y135.261 E.01652
G1 X178.368 Y133.641 E.0707
G1 X178.903 Y133.641 E.01652
G1 X177.283 Y135.261 E.0707
G1 X177.819 Y135.261 E.01652
G1 X179.439 Y133.641 E.0707
G1 X179.974 Y133.641 E.01652
G1 X178.354 Y135.261 E.0707
G1 X178.89 Y135.261 E.01652
G1 X180.51 Y133.641 E.0707
G1 X181.046 Y133.641 E.01652
G1 X179.425 Y135.261 E.0707
G1 X179.961 Y135.261 E.01652
G1 X181.581 Y133.641 E.0707
G1 X182.117 Y133.641 E.01652
G1 X180.496 Y135.261 E.0707
G1 X181.032 Y135.261 E.01652
G1 X182.652 Y133.641 E.0707
G1 X183.065 Y133.641 E.01274
G1 X183.065 Y133.764 E.00379
G1 X181.567 Y135.261 E.06534
G1 X182.103 Y135.261 E.01652
G1 X183.065 Y134.299 E.04197
G1 X183.065 Y134.835 E.01652
G1 X182.469 Y135.431 E.02601
G1 X181.348 Y132.431 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.976 Y132.431 E.05401
G1 X182.159 Y133.249 E.03835
G1 X181.304 Y133.249 E.02835
G1 X180.487 Y132.431 E.03835
G1 X175.301 Y132.431 E.17204
G1 X174.483 Y133.249 E.03835
G1 X173.628 Y133.249 E.02835
G1 X172.811 Y132.431 E.03835
G1 X167.625 Y132.431 E.17204
G1 X166.95 Y133.105 E.03163
G1 X166.95 Y133.249 E.00475
G1 X168.435 Y133.249 E.04926
G1 X168.204 Y130.83 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.5763
G1 F11811.468
G1 X181.737 Y130.83 E.58819
G1 X167.748 Y130.375 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X167.748 Y131.285 E.02798
G1 X182.252 Y131.285 E.44564
G1 X182.252 Y130.375 E.02798
G1 X167.808 Y130.375 E.4438
G1 X167.371 Y129.998 F30000
G1 F15000
G1 X167.371 Y131.662 E.05115
G1 X182.629 Y131.662 E.46881
G1 X182.629 Y129.998 E.05115
G1 X167.431 Y129.998 E.46697
G1 X166.994 Y129.62 F30000
G1 F15000
G1 X166.994 Y132.039 E.07432
G1 X183.006 Y132.039 E.49198
G1 X183.006 Y129.62 E.07432
G1 X167.054 Y129.62 E.49014
; WIPE_START
G1 X169.054 Y129.62 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X161.963 Y126.798 Z4.8 F30000
G1 X159.006 Y125.622 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
G1 F12000
G1 X159.006 Y124.6 E.0314
G1 X152.994 Y124.6 E.18472
G1 X152.994 Y126.643 E.06279
G1 X159.006 Y126.643 E.18472
G1 X159.006 Y125.682 E.02955
G1 X158.629 Y126.266 F30000
G1 F12000
G1 X158.629 Y124.977 E.03962
G1 X153.371 Y124.977 E.16155
G1 X153.371 Y126.266 E.03962
G1 X158.569 Y126.266 E.1597
G1 X158.212 Y125.85 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X158.212 Y125.394 E.01696
G1 X153.788 Y125.394 E.16446
G1 X153.788 Y125.85 E.01696
G1 X158.152 Y125.85 E.16223
; WIPE_START
G1 X156.152 Y125.85 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y123.48 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X159.077 Y123.985 E.02196
G1 X158.544 Y123.985
G1 X159.583 Y122.947 E.04514
G1 X159.249 Y122.747
G1 X158.011 Y123.985 E.05379
G1 X157.477 Y123.985
G1 X158.715 Y122.747 E.05379
G1 X158.182 Y122.747
G1 X156.944 Y123.985 E.05379
G1 X156.411 Y123.985
G1 X157.649 Y122.747 E.05379
G1 X157.116 Y122.747
G1 X155.878 Y123.985 E.05379
G1 X155.344 Y123.985
G1 X156.582 Y122.747 E.05379
G1 X156.049 Y122.747
G1 X154.811 Y123.985 E.05379
G1 X154.278 Y123.985
G1 X155.516 Y122.747 E.05379
G1 X154.982 Y122.747
G1 X153.745 Y123.985 E.05379
G1 X153.211 Y123.985
G1 X154.449 Y122.747 E.05379
G1 X153.916 Y122.747
G1 X152.678 Y123.985 E.05379
G1 X152.417 Y123.713
G1 X153.383 Y122.747 E.04195
G1 X152.849 Y122.747
G1 X152.417 Y123.179 E.01878
; WIPE_START
M204 S10000
G1 X152.849 Y122.747 E-.23219
G1 X153.383 Y122.747 E-.20264
G1 X152.778 Y123.353 E-.32518
; WIPE_END
G1 E-.04 F1800
G1 X153.692 Y127.035 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X152.95 Y127.035 E.02459
G1 X152.95 Y127.922 E.02943
G1 X154.256 Y129.228 E.06127
G1 X155.475 Y129.228 E.04044
G1 X157.668 Y127.035 E.10288
G1 X159.05 Y127.035 E.04582
G1 X159.05 Y127.282 E.0082
G1 X153.64 Y129.451 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42159
G1 F15000
G1 X152.935 Y130.155 E.03074
G1 X152.935 Y130.691 E.01652
G1 X154.006 Y129.621 E.0467
G1 X154.541 Y129.621 E.01652
G1 X152.935 Y131.226 E.07007
G1 X152.935 Y131.762 E.01652
G1 X155.077 Y129.621 E.09344
G1 X155.612 Y129.621 E.01652
G1 X152.935 Y132.297 E.11681
G1 X152.935 Y132.833 E.01652
G1 X156.148 Y129.621 E.14018
G1 X156.683 Y129.621 E.01652
G1 X152.766 Y133.538 E.17095
; WIPE_START
G1 X154.18 Y132.124 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X161.72 Y130.941 Z4.8 F30000
G1 X181.525 Y127.835 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.896 Y127.835 E.05401
G1 X178.503 Y129.228 E.06536
G1 X177.284 Y129.228 E.04044
G1 X175.891 Y127.835 E.06536
G1 X172.22 Y127.835 E.12176
G1 X170.827 Y129.228 E.06536
G1 X169.608 Y129.228 E.04044
G1 X168.215 Y127.835 E.06536
G1 X166.95 Y127.835 E.04195
G1 X166.95 Y128.199 E.01206
G1 X183.006 Y127.443 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y124.6 E.08737
G1 X166.994 Y124.6 E.49198
G1 X166.994 Y127.443 E.08737
G1 X182.946 Y127.443 E.49014
G1 X182.629 Y126.022 F30000
G1 F12000
G1 X182.629 Y124.977 E.0321
G1 X167.371 Y124.977 E.46881
G1 X167.371 Y127.066 E.0642
G1 X182.629 Y127.066 E.46881
G1 X182.629 Y126.082 E.03026
G1 X182.252 Y126.022 F30000
G1 F12000
G1 X182.252 Y125.354 E.02051
G1 X167.748 Y125.354 E.44564
G1 X167.748 Y126.689 E.04103
G1 X182.252 Y126.689 E.44564
G1 X182.252 Y126.082 E.01867
G1 X181.824 Y126.022 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X181.824 Y125.782 E.00935
G1 X168.176 Y125.782 E.53278
G1 X168.176 Y126.261 E.0187
G1 X181.824 Y126.261 E.53278
G1 X181.824 Y126.082 E.00701
; WIPE_START
G1 X181.824 Y126.261 E-.06823
G1 X180.003 Y126.261 E-.69177
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y123.476 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.074 Y123.985 E.02211
G1 X182.54 Y123.985
G1 X183.583 Y122.943 E.04529
G1 X183.245 Y122.747
G1 X182.007 Y123.985 E.05379
G1 X181.474 Y123.985
G1 X182.712 Y122.747 E.05379
G1 X182.179 Y122.747
G1 X180.941 Y123.985 E.05379
G1 X180.407 Y123.985
G1 X181.645 Y122.747 E.05379
G1 X181.112 Y122.747
G1 X179.874 Y123.985 E.05379
G1 X179.341 Y123.985
G1 X180.579 Y122.747 E.05379
G1 X180.046 Y122.747
G1 X178.808 Y123.985 E.05379
G1 X178.274 Y123.985
G1 X179.512 Y122.747 E.05379
M73 P85 R4
G1 X178.979 Y122.747
G1 X177.741 Y123.985 E.05379
G1 X177.208 Y123.985
G1 X178.446 Y122.747 E.05379
G1 X177.913 Y122.747
G1 X176.675 Y123.985 E.05379
G1 X176.141 Y123.985
G1 X177.379 Y122.747 E.05379
G1 X176.846 Y122.747
G1 X175.608 Y123.985 E.05379
G1 X175.075 Y123.985
G1 X176.313 Y122.747 E.05379
G1 X175.78 Y122.747
G1 X174.542 Y123.985 E.05379
G1 X174.008 Y123.985
G1 X175.246 Y122.747 E.05379
G1 X174.713 Y122.747
G1 X173.475 Y123.985 E.05379
G1 X172.942 Y123.985
G1 X174.18 Y122.747 E.05379
G1 X173.647 Y122.747
G1 X172.409 Y123.985 E.05379
G1 X171.875 Y123.985
G1 X173.113 Y122.747 E.05379
G1 X172.58 Y122.747
G1 X171.342 Y123.985 E.05379
G1 X170.809 Y123.985
G1 X172.047 Y122.747 E.05379
G1 X171.513 Y122.747
G1 X170.276 Y123.985 E.05379
G1 X169.742 Y123.985
G1 X170.98 Y122.747 E.05379
G1 X170.447 Y122.747
G1 X169.209 Y123.985 E.05379
G1 X168.676 Y123.985
G1 X169.914 Y122.747 E.05379
G1 X169.38 Y122.747
G1 X168.143 Y123.985 E.05379
G1 X167.609 Y123.985
G1 X168.847 Y122.747 E.05379
G1 X168.314 Y122.747
G1 X167.076 Y123.985 E.05379
G1 X166.543 Y123.985
G1 X167.781 Y122.747 E.05379
G1 X167.247 Y122.747
G1 X166.417 Y123.577 E.03607
; WIPE_START
M204 S10000
G1 X167.247 Y122.747 E-.44605
G1 X167.781 Y122.747 E-.20264
G1 X167.574 Y122.955 E-.11131
; WIPE_END
G1 E-.04 F1800
G1 X160.106 Y124.533 Z4.8 F30000
G1 X108.567 Y135.431 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42159
G1 F15000
G1 X110.062 Y133.935 E.06525
G1 X109.527 Y133.935 E.01652
G1 X108.201 Y135.261 E.05785
G1 X107.666 Y135.261 E.01652
G1 X108.991 Y133.935 E.05785
G1 X108.456 Y133.935 E.01652
G1 X107.13 Y135.261 E.05785
G1 X106.595 Y135.261 E.01652
G1 X107.92 Y133.935 E.05785
G1 X107.385 Y133.935 E.01652
G1 X106.059 Y135.261 E.05785
G1 X105.524 Y135.261 E.01652
G1 X106.849 Y133.935 E.05785
G1 X106.314 Y133.935 E.01652
G1 X104.988 Y135.261 E.05785
G1 X104.453 Y135.261 E.01652
G1 X105.778 Y133.935 E.05785
G1 X105.243 Y133.935 E.01652
G1 X103.917 Y135.261 E.05785
G1 X103.381 Y135.261 E.01652
G1 X104.707 Y133.935 E.05785
G1 X104.172 Y133.935 E.01652
G1 X102.846 Y135.261 E.05785
G1 X102.31 Y135.261 E.01652
G1 X103.636 Y133.935 E.05785
G1 X103.101 Y133.935 E.01652
G1 X101.775 Y135.261 E.05785
G1 X101.239 Y135.261 E.01652
G1 X103.065 Y133.435 E.07966
G1 X103.065 Y132.9 E.01652
G1 X100.704 Y135.261 E.10302
G1 X100.168 Y135.261 E.01652
G1 X103.065 Y132.364 E.12639
G1 X103.065 Y131.829 E.01652
G1 X99.633 Y135.261 E.14976
G1 X99.097 Y135.261 E.01652
G1 X103.065 Y131.293 E.17313
G1 X103.065 Y130.758 E.01652
G1 X98.562 Y135.261 E.1965
G1 X98.026 Y135.261 E.01652
G1 X103.065 Y130.222 E.21987
G1 X103.065 Y129.687 E.01652
G1 X97.491 Y135.261 E.24324
G1 X96.955 Y135.261 E.01652
G1 X102.596 Y129.621 E.24613
G1 X102.06 Y129.621 E.01652
G1 X96.42 Y135.261 E.24613
G1 X95.884 Y135.261 E.01652
G1 X101.525 Y129.621 E.24613
G1 X100.989 Y129.621 E.01652
G1 X95.349 Y135.261 E.24613
G1 X94.813 Y135.261 E.01652
G1 X96.139 Y133.935 E.05785
G1 X95.603 Y133.935 E.01652
G1 X94.278 Y135.261 E.05785
G1 X93.742 Y135.261 E.01652
G1 X95.068 Y133.935 E.05785
G1 X94.532 Y133.935 E.01652
G1 X93.207 Y135.261 E.05785
G1 X92.671 Y135.261 E.01652
G1 X93.997 Y133.935 E.05785
G1 X93.461 Y133.935 E.01652
G1 X92.136 Y135.261 E.05785
G1 X91.6 Y135.261 E.01652
G1 X92.926 Y133.935 E.05785
G1 X92.39 Y133.935 E.01652
G1 X91.065 Y135.261 E.05785
G1 X90.529 Y135.261 E.01652
G1 X91.855 Y133.935 E.05785
G1 X91.319 Y133.935 E.01652
G1 X89.993 Y135.261 E.05785
G1 X89.458 Y135.261 E.01652
G1 X90.784 Y133.935 E.05785
G1 X90.248 Y133.935 E.01652
G1 X88.922 Y135.261 E.05785
G1 X88.387 Y135.261 E.01652
G1 X89.713 Y133.935 E.05785
G1 X89.177 Y133.935 E.01652
G1 X87.851 Y135.261 E.05785
G1 X87.316 Y135.261 E.01652
G1 X88.936 Y133.641 E.0707
G1 X88.4 Y133.641 E.01652
G1 X86.78 Y135.261 E.0707
G1 X86.245 Y135.261 E.01652
G1 X87.865 Y133.641 E.0707
G1 X87.329 Y133.641 E.01652
G1 X85.709 Y135.261 E.0707
G1 X85.174 Y135.261 E.01652
G1 X86.794 Y133.641 E.0707
G1 X86.258 Y133.641 E.01652
G1 X84.638 Y135.261 E.0707
G1 X84.103 Y135.261 E.01652
G1 X85.723 Y133.641 E.0707
G1 X85.187 Y133.641 E.01652
G1 X83.567 Y135.261 E.0707
G1 X83.032 Y135.261 E.01652
G1 X84.652 Y133.641 E.0707
G1 X84.116 Y133.641 E.01652
G1 X82.496 Y135.261 E.0707
G1 X81.961 Y135.261 E.01652
G1 X83.581 Y133.641 E.0707
G1 X83.045 Y133.641 E.01652
G1 X81.425 Y135.261 E.0707
G1 X80.89 Y135.261 E.01652
G1 X82.51 Y133.641 E.0707
G1 X81.974 Y133.641 E.01652
G1 X80.354 Y135.261 E.0707
G1 X79.819 Y135.261 E.01652
G1 X81.439 Y133.641 E.0707
G1 X80.903 Y133.641 E.01652
G1 X79.283 Y135.261 E.0707
G1 X78.748 Y135.261 E.01652
G1 X80.368 Y133.641 E.0707
G1 X79.832 Y133.641 E.01652
G1 X78.212 Y135.261 E.0707
G1 X77.677 Y135.261 E.01652
G1 X79.297 Y133.641 E.0707
G1 X78.761 Y133.641 E.01652
G1 X77.141 Y135.261 E.0707
G1 X76.605 Y135.261 E.01652
G1 X78.226 Y133.641 E.0707
G1 X77.69 Y133.641 E.01652
G1 X76.07 Y135.261 E.0707
G1 X75.534 Y135.261 E.01652
G1 X77.155 Y133.641 E.0707
G1 X76.619 Y133.641 E.01652
G1 X74.999 Y135.261 E.0707
G1 X74.463 Y135.261 E.01652
G1 X76.084 Y133.641 E.0707
G1 X75.548 Y133.641 E.01652
G1 X73.928 Y135.261 E.0707
G1 X73.392 Y135.261 E.01652
G1 X75.012 Y133.641 E.0707
G1 X74.477 Y133.641 E.01652
G1 X72.935 Y135.182 E.06728
G1 X72.935 Y134.647 E.01652
G1 X73.941 Y133.641 E.04391
G1 X73.406 Y133.641 E.01652
G1 X72.766 Y134.281 E.02794
G1 X74.203 Y130.83 F30000
; LINE_WIDTH: 0.5763
G1 F11811.468
G1 X87.737 Y130.83 E.58819
G1 X88.252 Y130.375 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X73.748 Y130.375 E.44564
G1 X73.748 Y131.285 E.02798
G1 X88.252 Y131.285 E.44564
G1 X88.252 Y130.435 E.02613
G1 X88.629 Y129.998 F30000
G1 F15000
G1 X73.371 Y129.998 E.46881
G1 X73.371 Y131.662 E.05115
G1 X88.629 Y131.662 E.46881
G1 X88.629 Y130.058 E.0493
G1 X89.006 Y129.62 F30000
G1 F15000
G1 X72.994 Y129.62 E.49198
G1 X72.994 Y132.039 E.07432
G1 X89.006 Y132.039 E.49198
G1 X89.006 Y129.68 E.07248
G1 X89.05 Y128.199 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.05 Y127.835 E.01206
G1 X87.785 Y127.835 E.04196
G1 X86.392 Y129.228 E.06536
G1 X85.173 Y129.228 E.04044
G1 X83.78 Y127.835 E.06536
G1 X80.109 Y127.835 E.12176
G1 X78.716 Y129.228 E.06536
G1 X77.497 Y129.228 E.04044
G1 X76.104 Y127.835 E.06536
G1 X74.475 Y127.835 E.05401
G1 X87.565 Y133.249 F30000
G1 F15476.087
G1 X89.05 Y133.249 E.04926
G1 X89.05 Y133.105 E.00475
G1 X88.375 Y132.431 E.03163
G1 X83.189 Y132.431 E.17204
G1 X82.372 Y133.249 E.03835
G1 X81.517 Y133.249 E.02835
G1 X80.699 Y132.431 E.03835
G1 X75.513 Y132.431 E.17204
G1 X74.696 Y133.249 E.03835
G1 X73.841 Y133.249 E.02835
G1 X73.024 Y132.431 E.03835
G1 X74.652 Y132.431 E.05401
G1 X89.006 Y126.022 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y124.6 E.04369
G1 X72.994 Y124.6 E.49198
G1 X72.994 Y127.443 E.08737
G1 X89.006 Y127.443 E.49198
G1 X89.006 Y126.082 E.04184
G1 X88.629 Y126.022 F30000
G1 F12000
G1 X88.629 Y124.977 E.0321
G1 X73.371 Y124.977 E.46881
G1 X73.371 Y127.066 E.0642
G1 X88.629 Y127.066 E.46881
G1 X88.629 Y126.082 E.03026
G1 X88.252 Y126.022 F30000
G1 F12000
G1 X88.252 Y125.354 E.02051
G1 X73.748 Y125.354 E.44564
G1 X73.748 Y126.689 E.04103
G1 X88.252 Y126.689 E.44564
G1 X88.252 Y126.082 E.01867
G1 X87.824 Y126.022 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X87.824 Y125.782 E.00935
G1 X74.176 Y125.782 E.53278
G1 X74.176 Y126.261 E.0187
G1 X87.824 Y126.261 E.53278
G1 X87.824 Y126.082 E.00701
; WIPE_START
G1 X87.824 Y126.261 E-.06823
G1 X86.003 Y126.261 E-.69177
; WIPE_END
G1 E-.04 F1800
G1 X89.22 Y123.985 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.583 Y123.623 E.01574
G1 X89.583 Y123.09
G1 X88.687 Y123.985 E.03891
G1 X88.154 Y123.985
G1 X89.392 Y122.747 E.05379
G1 X88.859 Y122.747
G1 X87.621 Y123.985 E.05379
G1 X87.087 Y123.985
G1 X88.325 Y122.747 E.05379
G1 X87.792 Y122.747
G1 X86.554 Y123.985 E.05379
G1 X86.021 Y123.985
G1 X87.259 Y122.747 E.05379
G1 X86.726 Y122.747
G1 X85.488 Y123.985 E.05379
G1 X84.954 Y123.985
G1 X86.192 Y122.747 E.05379
G1 X85.659 Y122.747
G1 X84.421 Y123.985 E.05379
G1 X83.888 Y123.985
G1 X85.126 Y122.747 E.05379
G1 X84.592 Y122.747
G1 X83.355 Y123.985 E.05379
G1 X82.821 Y123.985
G1 X84.059 Y122.747 E.05379
G1 X83.526 Y122.747
G1 X82.288 Y123.985 E.05379
G1 X81.755 Y123.985
G1 X82.993 Y122.747 E.05379
G1 X82.459 Y122.747
G1 X81.222 Y123.985 E.05379
G1 X80.688 Y123.985
G1 X81.926 Y122.747 E.05379
G1 X81.393 Y122.747
G1 X80.155 Y123.985 E.05379
G1 X79.622 Y123.985
G1 X80.86 Y122.747 E.05379
G1 X80.326 Y122.747
G1 X79.089 Y123.985 E.05379
G1 X78.555 Y123.985
G1 X79.793 Y122.747 E.05379
G1 X79.26 Y122.747
G1 X78.022 Y123.985 E.05379
G1 X77.489 Y123.985
G1 X78.727 Y122.747 E.05379
G1 X78.193 Y122.747
G1 X76.955 Y123.985 E.05379
G1 X76.422 Y123.985
G1 X77.66 Y122.747 E.05379
G1 X77.127 Y122.747
G1 X75.889 Y123.985 E.05379
G1 X75.356 Y123.985
G1 X76.594 Y122.747 E.05379
G1 X76.06 Y122.747
G1 X74.822 Y123.985 E.05379
G1 X74.289 Y123.985
G1 X75.527 Y122.747 E.05379
G1 X74.994 Y122.747
G1 X73.756 Y123.985 E.05379
G1 X73.223 Y123.985
G1 X74.461 Y122.747 E.05379
G1 X73.927 Y122.747
G1 X72.689 Y123.985 E.05379
G1 X72.417 Y123.724
G1 X73.394 Y122.747 E.04244
G1 X72.861 Y122.747
G1 X72.417 Y123.191 E.01927
; WIPE_START
M204 S10000
G1 X72.861 Y122.747 E-.2383
G1 X73.394 Y122.747 E-.20264
G1 X72.8 Y123.341 E-.31906
; WIPE_END
G1 E-.04 F1800
G1 X80.432 Y123.215 Z4.8 F30000
G1 X89.557 Y123.064 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.132307
G1 F15000
G1 X89.557 Y122.729 E.00244
; WIPE_START
G1 X89.557 Y123.064 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X96.186 Y126.846 Z4.8 F30000
G1 X96.95 Y127.282 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X96.95 Y127.035 E.0082
G1 X98.332 Y127.035 E.04582
G1 X100.525 Y129.228 E.10288
G1 X101.744 Y129.228 E.04044
G1 X103.05 Y127.922 E.06127
G1 X103.05 Y127.035 E.02943
G1 X102.308 Y127.035 E.02459
G1 X103.006 Y126.643 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y124.6 E.06279
G1 X96.994 Y124.6 E.18472
G1 X96.994 Y126.643 E.06279
G1 X102.946 Y126.643 E.18288
G1 X102.629 Y125.622 F30000
G1 F12000
G1 X102.629 Y124.977 E.01981
G1 X97.371 Y124.977 E.16155
G1 X97.371 Y126.266 E.03962
G1 X102.629 Y126.266 E.16155
G1 X102.629 Y125.682 E.01797
G1 X102.212 Y125.622 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X102.212 Y125.394 E.00848
G1 X97.788 Y125.394 E.16446
G1 X97.788 Y125.85 E.01696
G1 X102.212 Y125.85 E.16446
G1 X102.212 Y125.682 E.00625
; WIPE_START
G1 X102.212 Y125.85 E-.06387
G1 X100.38 Y125.85 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y123.488 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X103.085 Y123.985 E.02162
G1 X102.552 Y123.985
G1 X103.583 Y122.955 E.04479
G1 X103.256 Y122.747
G1 X102.019 Y123.985 E.05379
G1 X101.485 Y123.985
G1 X102.723 Y122.747 E.05379
G1 X102.19 Y122.747
G1 X100.952 Y123.985 E.05379
G1 X100.419 Y123.985
G1 X101.657 Y122.747 E.05379
G1 X101.123 Y122.747
G1 X99.886 Y123.985 E.05379
G1 X99.352 Y123.985
G1 X100.59 Y122.747 E.05379
G1 X100.057 Y122.747
G1 X98.819 Y123.985 E.05379
G1 X98.286 Y123.985
G1 X99.524 Y122.747 E.05379
G1 X98.99 Y122.747
G1 X97.753 Y123.985 E.05379
G1 X97.219 Y123.985
G1 X98.457 Y122.747 E.05379
G1 X97.924 Y122.747
G1 X96.686 Y123.985 E.05379
G1 X96.417 Y123.721
G1 X97.391 Y122.747 E.04229
G1 X96.857 Y122.747
G1 X96.417 Y123.187 E.01912
; WIPE_START
M204 S10000
G1 X96.857 Y122.747 E-.23647
G1 X97.391 Y122.747 E-.20264
G1 X96.794 Y123.345 E-.3209
; WIPE_END
G1 E-.04 F1800
G1 X97.41 Y129.451 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42159
G1 F15000
G1 X96.935 Y129.926 E.02072
G1 X96.935 Y130.461 E.01652
G1 X97.776 Y129.621 E.03668
G1 X98.311 Y129.621 E.01652
G1 X96.935 Y130.997 E.06005
G1 X96.935 Y131.532 E.01652
G1 X98.847 Y129.621 E.08342
G1 X99.382 Y129.621 E.01652
G1 X96.935 Y132.068 E.10679
G1 X96.935 Y132.603 E.01652
G1 X99.918 Y129.621 E.13016
G1 X100.453 Y129.621 E.01652
G1 X96.766 Y133.308 E.16093
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X98.18 Y131.894 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 23/32
; update layer progress
M73 L23
M991 S0 P22 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.8 I-.051 J1.216 P1  F30000
G1 X138.602 Y133.602 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y125.008 E.28509
G1 X145.398 Y125.008 E.22543
G1 X145.398 Y133.602 E.28509
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y125.008 E.28509
G1 X159.398 Y125.008 E.22543
G1 X159.398 Y133.602 E.28509
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y125.008 E.28509
G1 X183.398 Y125.008 E.55715
G1 X183.398 Y135.115 E.33526
G1 X72.602 Y135.115 E3.6753
G1 X72.602 Y125.008 E.33526
G1 X89.398 Y125.008 E.55715
G1 X89.398 Y133.602 E.28509
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y125.008 E.28509
G1 X103.398 Y125.008 E.22543
G1 X103.398 Y133.602 E.28509
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y125.008 E.28509
G1 X117.398 Y125.008 E.22543
G1 X117.398 Y133.602 E.28509
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y125.008 E.28509
G1 X131.398 Y125.008 E.22543
G1 X131.398 Y133.602 E.28509
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y123.34 E.30328
G1 X145.79 Y123.34 E.23291
G1 X145.79 Y133.21 E.30328
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y123.34 E.30328
G1 X159.79 Y123.34 E.23291
G1 X159.79 Y133.21 E.30328
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y123.34 E.30328
G1 X183.79 Y123.34 E.54018
G1 X183.79 Y135.507 E.37385
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y135.507 E3.42854
G1 X72.21 Y123.34 E.37385
G1 X89.79 Y123.34 E.54018
G1 X89.79 Y133.21 E.30328
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y123.34 E.30328
G1 X103.79 Y123.34 E.23291
G1 X103.79 Y133.21 E.30328
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y123.34 E.30328
G1 X117.79 Y123.34 E.23291
G1 X117.79 Y133.21 E.30328
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y123.34 E.30328
G1 X131.79 Y123.34 E.23291
G1 X131.79 Y133.21 E.30328
G1 X138.15 Y133.21 E.19542
; WIPE_START
M204 S10000
G1 X138.162 Y131.21 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z5 I1.169 J.339 P1  F30000
G1 X139.14 Y127.835 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.95 Y127.835 E.00628
G1 X138.95 Y129.274 E.04774
G1 X139.704 Y130.028 E.03538
G1 X139.323 Y130.028 E.01264
G1 X141.517 Y127.835 E.10288
G1 X143.145 Y127.835 E.05401
G1 X145.006 Y127.443 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y125.4 E.06279
G1 X138.994 Y125.4 E.18472
G1 X138.994 Y127.443 E.06279
G1 X144.946 Y127.443 E.18288
G1 X144.629 Y127.066 F30000
G1 F12000
G1 X144.629 Y125.777 E.03962
G1 X139.371 Y125.777 E.16155
G1 X139.371 Y127.066 E.03962
G1 X144.569 Y127.066 E.1597
G1 X144.212 Y126.65 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X144.212 Y126.194 E.01696
G1 X139.788 Y126.194 E.16446
G1 X139.788 Y126.65 E.01696
G1 X144.152 Y126.65 E.16223
; WIPE_START
G1 X142.152 Y126.65 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y124.119 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.011 Y123.547 E.02483
G1 X144.478 Y123.547
G1 X145.583 Y124.652 E.048
G1 X145.183 Y124.785
M73 P85 R3
G1 X143.945 Y123.547 E.05379
G1 X143.411 Y123.547
G1 X144.649 Y124.785 E.05379
G1 X144.116 Y124.785
G1 X142.878 Y123.547 E.05379
G1 X142.345 Y123.547
G1 X143.583 Y124.785 E.05379
G1 X143.05 Y124.785
G1 X141.812 Y123.547 E.05379
G1 X141.278 Y123.547
G1 X142.516 Y124.785 E.05379
G1 X141.983 Y124.785
G1 X140.745 Y123.547 E.05379
G1 X140.212 Y123.547
M73 P86 R3
G1 X141.45 Y124.785 E.05379
G1 X140.917 Y124.785
G1 X139.679 Y123.547 E.05379
G1 X139.145 Y123.547
G1 X140.383 Y124.785 E.05379
G1 X139.85 Y124.785
G1 X138.612 Y123.547 E.05379
G1 X138.417 Y123.886
G1 X139.317 Y124.785 E.03908
G1 X138.784 Y124.785
G1 X138.417 Y124.419 E.01591
; WIPE_START
M204 S10000
G1 X138.784 Y124.785 E-.19676
G1 X139.317 Y124.785 E-.20264
G1 X138.646 Y124.114 E-.3606
; WIPE_END
G1 E-.04 F1800
G1 X131.583 Y123.983 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X131.147 Y123.547 E.01895
G1 X130.613 Y123.547
G1 X131.583 Y124.517 E.04212
G1 X131.318 Y124.785
G1 X130.08 Y123.547 E.05379
G1 X129.547 Y123.547
G1 X130.785 Y124.785 E.05379
G1 X130.251 Y124.785
G1 X129.014 Y123.547 E.05379
G1 X128.48 Y123.547
G1 X129.718 Y124.785 E.05379
G1 X129.185 Y124.785
G1 X127.947 Y123.547 E.05379
G1 X127.414 Y123.547
G1 X128.652 Y124.785 E.05379
G1 X128.118 Y124.785
G1 X126.88 Y123.547 E.05379
G1 X126.347 Y123.547
G1 X127.585 Y124.785 E.05379
G1 X127.052 Y124.785
G1 X125.814 Y123.547 E.05379
G1 X125.281 Y123.547
G1 X126.519 Y124.785 E.05379
G1 X125.985 Y124.785
G1 X124.747 Y123.547 E.05379
G1 X124.417 Y123.751
G1 X125.452 Y124.785 E.04496
G1 X124.919 Y124.785
G1 X124.417 Y124.284 E.02179
; WIPE_START
M204 S10000
G1 X124.919 Y124.785 E-.26948
G1 X125.452 Y124.785 E-.20264
G1 X124.916 Y124.25 E-.28788
; WIPE_END
G1 E-.04 F1800
G1 X125.6 Y130.028 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.95 Y130.028 E.02155
G1 X124.95 Y129.05 E.03247
G1 X126.165 Y127.835 E.05697
G1 X129.835 Y127.835 E.12176
G1 X131.05 Y129.05 E.05697
G1 X131.05 Y130.028 E.03247
G1 X130.4 Y130.028 E.02155
G1 X131.006 Y126.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y125.4 E.0314
G1 X124.994 Y125.4 E.18472
G1 X124.994 Y127.443 E.06279
G1 X131.006 Y127.443 E.18472
G1 X131.006 Y126.482 E.02955
G1 X130.629 Y126.422 F30000
G1 F12000
G1 X130.629 Y125.777 E.01981
G1 X125.371 Y125.777 E.16155
G1 X125.371 Y127.066 E.03962
G1 X130.629 Y127.066 E.16155
G1 X130.629 Y126.482 E.01797
G1 X130.212 Y126.422 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X130.212 Y126.194 E.00848
G1 X125.788 Y126.194 E.16446
G1 X125.788 Y126.65 E.01696
G1 X130.212 Y126.65 E.16446
G1 X130.212 Y126.482 E.00625
; WIPE_START
G1 X130.212 Y126.65 E-.06387
G1 X128.38 Y126.65 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X120.749 Y126.497 Z5 F30000
G1 X117.006 Y126.422 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X117.006 Y125.4 E.0314
G1 X110.994 Y125.4 E.18472
G1 X110.994 Y127.443 E.06279
G1 X117.006 Y127.443 E.18472
G1 X117.006 Y126.482 E.02955
G1 X116.629 Y126.422 F30000
G1 F12000
G1 X116.629 Y125.777 E.01981
G1 X111.371 Y125.777 E.16155
G1 X111.371 Y127.066 E.03962
G1 X116.629 Y127.066 E.16155
G1 X116.629 Y126.482 E.01797
G1 X116.212 Y126.422 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X116.212 Y126.194 E.00848
G1 X111.788 Y126.194 E.16446
G1 X111.788 Y126.65 E.01696
G1 X116.212 Y126.65 E.16446
G1 X116.212 Y126.482 E.00625
; WIPE_START
G1 X116.212 Y126.65 E-.06387
G1 X114.38 Y126.65 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X116.749 Y123.547 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X117.583 Y124.381 E.03624
G1 X117.453 Y124.785
G1 X116.215 Y123.547 E.05379
G1 X115.682 Y123.547
G1 X116.92 Y124.785 E.05379
G1 X116.387 Y124.785
G1 X115.149 Y123.547 E.05379
G1 X114.616 Y123.547
G1 X115.853 Y124.785 E.05379
G1 X115.32 Y124.785
G1 X114.082 Y123.547 E.05379
G1 X113.549 Y123.547
G1 X114.787 Y124.785 E.05379
G1 X114.254 Y124.785
G1 X113.016 Y123.547 E.05379
G1 X112.483 Y123.547
G1 X113.72 Y124.785 E.05379
G1 X113.187 Y124.785
G1 X111.949 Y123.547 E.05379
G1 X111.416 Y123.547
G1 X112.654 Y124.785 E.05379
G1 X112.121 Y124.785
G1 X110.883 Y123.547 E.05379
G1 X110.417 Y123.615
G1 X111.587 Y124.785 E.05084
G1 X111.054 Y124.785
G1 X110.417 Y124.149 E.02767
; WIPE_START
M204 S10000
G1 X111.054 Y124.785 E-.3422
G1 X111.587 Y124.785 E-.20264
G1 X111.187 Y124.385 E-.21516
; WIPE_END
G1 E-.04 F1800
G1 X112.855 Y127.835 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X114.483 Y127.835 E.05401
G1 X116.677 Y130.028 E.10288
G1 X116.296 Y130.028 E.01264
G1 X117.05 Y129.274 E.03538
G1 X117.05 Y127.835 E.04773
G1 X116.86 Y127.835 E.00628
; WIPE_START
G1 X117.05 Y127.835 E-.07193
G1 X117.05 Y129.274 E-.54683
G1 X116.787 Y129.537 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X109.702 Y126.698 Z5 F30000
G1 X103.583 Y124.246 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X102.884 Y123.547 E.03036
G1 X102.351 Y123.547
G1 X103.583 Y124.779 E.05354
G1 X103.055 Y124.785
G1 X101.817 Y123.547 E.05379
G1 X101.284 Y123.547
G1 X102.522 Y124.785 E.05379
G1 X101.989 Y124.785
G1 X100.751 Y123.547 E.05379
G1 X100.218 Y123.547
G1 X101.456 Y124.785 E.05379
G1 X100.922 Y124.785
G1 X99.684 Y123.547 E.05379
G1 X99.151 Y123.547
G1 X100.389 Y124.785 E.05379
G1 X99.856 Y124.785
G1 X98.618 Y123.547 E.05379
G1 X98.085 Y123.547
G1 X99.322 Y124.785 E.05379
G1 X98.789 Y124.785
G1 X97.551 Y123.547 E.05379
G1 X97.018 Y123.547
G1 X98.256 Y124.785 E.05379
G1 X97.723 Y124.785
G1 X96.485 Y123.547 E.05379
G1 X96.417 Y124.013
G1 X97.189 Y124.785 E.03355
; WIPE_START
M204 S10000
G1 X96.417 Y124.013 E-.41491
G1 X96.485 Y123.547 E-.17886
G1 X96.794 Y123.857 E-.16623
; WIPE_END
G1 E-.04 F1800
G1 X97.503 Y127.835 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X99.132 Y127.835 E.05401
G1 X101.325 Y130.028 E.10289
G1 X100.944 Y130.028 E.01264
G1 X103.05 Y127.922 E.0988
G1 X103.05 Y127.835 E.00289
G1 X101.508 Y127.835 E.05112
G1 X103.006 Y127.443 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X103.006 Y125.4 E.06279
G1 X96.994 Y125.4 E.18472
G1 X96.994 Y127.443 E.06279
G1 X102.946 Y127.443 E.18288
G1 X102.629 Y126.422 F30000
G1 F12000
G1 X102.629 Y125.777 E.01981
G1 X97.371 Y125.777 E.16155
G1 X97.371 Y127.066 E.03962
G1 X102.629 Y127.066 E.16155
G1 X102.629 Y126.482 E.01797
G1 X102.212 Y126.422 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X102.212 Y126.194 E.00848
G1 X97.788 Y126.194 E.16446
G1 X97.788 Y126.65 E.01696
G1 X102.212 Y126.65 E.16446
G1 X102.212 Y126.482 E.00625
; WIPE_START
G1 X102.212 Y126.65 E-.06387
G1 X100.38 Y126.65 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X92.95 Y124.903 Z5 F30000
G1 X89.583 Y124.111 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.019 Y123.547 E.02448
G1 X88.486 Y123.547
G1 X89.583 Y124.644 E.04766
G1 X89.191 Y124.785
G1 X87.953 Y123.547 E.05379
G1 X87.419 Y123.547
G1 X88.657 Y124.785 E.05379
G1 X88.124 Y124.785
G1 X86.886 Y123.547 E.05379
G1 X86.353 Y123.547
G1 X87.591 Y124.785 E.05379
G1 X87.058 Y124.785
G1 X85.82 Y123.547 E.05379
G1 X85.286 Y123.547
G1 X86.524 Y124.785 E.05379
G1 X85.991 Y124.785
G1 X84.753 Y123.547 E.05379
G1 X84.22 Y123.547
G1 X85.458 Y124.785 E.05379
G1 X84.925 Y124.785
G1 X83.687 Y123.547 E.05379
G1 X83.153 Y123.547
G1 X84.391 Y124.785 E.05379
G1 X83.858 Y124.785
G1 X82.62 Y123.547 E.05379
G1 X82.087 Y123.547
G1 X83.325 Y124.785 E.05379
G1 X82.791 Y124.785
G1 X81.554 Y123.547 E.05379
G1 X81.02 Y123.547
G1 X82.258 Y124.785 E.05379
G1 X81.725 Y124.785
G1 X80.487 Y123.547 E.05379
G1 X79.954 Y123.547
G1 X81.192 Y124.785 E.05379
G1 X80.658 Y124.785
G1 X79.421 Y123.547 E.05379
G1 X78.887 Y123.547
G1 X80.125 Y124.785 E.05379
G1 X79.592 Y124.785
G1 X78.354 Y123.547 E.05379
G1 X77.821 Y123.547
G1 X79.059 Y124.785 E.05379
G1 X78.525 Y124.785
G1 X77.288 Y123.547 E.05379
G1 X76.754 Y123.547
G1 X77.992 Y124.785 E.05379
G1 X77.459 Y124.785
G1 X76.221 Y123.547 E.05379
G1 X75.688 Y123.547
G1 X76.926 Y124.785 E.05379
G1 X76.392 Y124.785
G1 X75.155 Y123.547 E.05379
G1 X74.621 Y123.547
G1 X75.859 Y124.785 E.05379
G1 X75.326 Y124.785
G1 X74.088 Y123.547 E.05379
G1 X73.555 Y123.547
G1 X74.793 Y124.785 E.05379
G1 X74.259 Y124.785
G1 X73.021 Y123.547 E.05379
G1 X72.488 Y123.547
G1 X73.726 Y124.785 E.05379
G1 X73.193 Y124.785
G1 X72.417 Y124.01 E.0337
; WIPE_START
M204 S10000
G1 X73.193 Y124.785 E-.41674
G1 X73.726 Y124.785 E-.20264
G1 X73.464 Y124.524 E-.14062
; WIPE_END
G1 E-.04 F1800
G1 X75.275 Y128.635 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X76.904 Y128.635 E.05401
G1 X78.297 Y130.028 E.06536
G1 X77.916 Y130.028 E.01264
G1 X79.309 Y128.635 E.06536
G1 X84.58 Y128.635 E.17484
G1 X85.973 Y130.028 E.06536
G1 X85.592 Y130.028 E.01264
G1 X86.985 Y128.635 E.06536
G1 X88.613 Y128.635 E.05401
G1 X89.006 Y130.42 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X72.994 Y130.42 E.49198
G1 X72.994 Y131.311 E.02737
G1 X89.006 Y131.311 E.49198
G1 X89.006 Y130.48 E.02552
G1 X73.439 Y130.866 F30000
; LINE_WIDTH: 0.55654
G1 F12265.878
G1 X88.501 Y130.866 E.63036
G1 X89.006 Y126.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y125.4 E.04369
G1 X72.994 Y125.4 E.49198
G1 X72.994 Y128.243 E.08737
G1 X89.006 Y128.243 E.49198
G1 X89.006 Y126.882 E.04184
G1 X88.629 Y127.866 F30000
G1 F12000
G1 X88.629 Y125.777 E.0642
G1 X73.371 Y125.777 E.46881
G1 X73.371 Y127.866 E.0642
G1 X88.569 Y127.866 E.46697
G1 X88.252 Y126.822 F30000
G1 F12000
G1 X88.252 Y126.154 E.02051
G1 X73.748 Y126.154 E.44564
G1 X73.748 Y127.489 E.04103
G1 X88.252 Y127.489 E.44564
G1 X88.252 Y126.882 E.01867
G1 X87.824 Y126.822 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X87.824 Y126.582 E.00935
G1 X74.176 Y126.582 E.53278
G1 X74.176 Y127.061 E.0187
G1 X87.824 Y127.061 E.53278
G1 X87.824 Y126.882 E.00701
G1 X73.924 Y131.703 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.95 Y131.703 E.03229
G1 X72.95 Y132.358 E.02172
G1 X73.362 Y132.769 E.01929
G1 X75.175 Y132.769 E.06016
G1 X76.241 Y131.703 E.05001
G1 X79.971 Y131.703 E.12374
G1 X81.038 Y132.769 E.05001
G1 X82.851 Y132.769 E.06016
G1 X83.917 Y131.703 E.05001
G1 X87.647 Y131.703 E.12374
G1 X88.713 Y132.769 E.05001
G1 X87.085 Y132.769 E.05401
; WIPE_START
G1 X88.713 Y132.769 E-.61876
G1 X88.451 Y132.506 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X96.064 Y131.968 Z5 F30000
G1 X154.492 Y127.835 Z5
G1 Z4.6
G1 E.8 F1800
G1 F15476.087
G1 X152.95 Y127.835 E.05112
G1 X152.95 Y127.922 E.00289
G1 X155.056 Y130.028 E.0988
G1 X154.675 Y130.028 E.01264
G1 X156.868 Y127.835 E.10288
G1 X158.497 Y127.835 E.05401
G1 X159.006 Y126.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y125.4 E.0314
G1 X152.994 Y125.4 E.18472
G1 X152.994 Y127.443 E.06279
G1 X159.006 Y127.443 E.18472
G1 X159.006 Y126.482 E.02955
G1 X158.629 Y126.422 F30000
G1 F12000
G1 X158.629 Y125.777 E.01981
G1 X153.371 Y125.777 E.16155
G1 X153.371 Y127.066 E.03962
G1 X158.629 Y127.066 E.16155
G1 X158.629 Y126.482 E.01797
G1 X158.212 Y126.422 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X158.212 Y126.194 E.00848
G1 X153.788 Y126.194 E.16446
G1 X153.788 Y126.65 E.01696
G1 X158.212 Y126.65 E.16446
G1 X158.212 Y126.482 E.00625
; WIPE_START
G1 X158.212 Y126.65 E-.06387
G1 X156.38 Y126.65 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y124.254 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X158.876 Y123.547 E.03071
G1 X158.343 Y123.547
G1 X159.581 Y124.785 E.05379
G1 X159.047 Y124.785
G1 X157.809 Y123.547 E.05379
G1 X157.276 Y123.547
G1 X158.514 Y124.785 E.05379
G1 X157.981 Y124.785
G1 X156.743 Y123.547 E.05379
G1 X156.21 Y123.547
G1 X157.448 Y124.785 E.05379
G1 X156.914 Y124.785
G1 X155.676 Y123.547 E.05379
G1 X155.143 Y123.547
G1 X156.381 Y124.785 E.05379
G1 X155.848 Y124.785
G1 X154.61 Y123.547 E.05379
G1 X154.077 Y123.547
G1 X155.315 Y124.785 E.05379
G1 X154.781 Y124.785
G1 X153.543 Y123.547 E.05379
G1 X153.01 Y123.547
G1 X154.248 Y124.785 E.05379
G1 X153.715 Y124.785
G1 X152.477 Y123.547 E.05379
G1 X152.417 Y124.021
G1 X153.181 Y124.785 E.0332
; WIPE_START
M204 S10000
G1 X152.417 Y124.021 E-.41062
G1 X152.477 Y123.547 E-.18146
G1 X152.789 Y123.86 E-.16792
; WIPE_END
G1 E-.04 F1800
G1 X160.043 Y126.233 Z5 F30000
G1 X167.387 Y128.635 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X169.015 Y128.635 E.05401
G1 X170.408 Y130.028 E.06536
G1 X170.027 Y130.028 E.01264
G1 X171.42 Y128.635 E.06536
G1 X176.691 Y128.635 E.17484
G1 X178.084 Y130.028 E.06535
G1 X177.703 Y130.028 E.01264
G1 X179.096 Y128.635 E.06536
G1 X180.725 Y128.635 E.05401
G1 X183.006 Y126.822 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y125.4 E.04369
G1 X166.994 Y125.4 E.49198
G1 X166.994 Y128.243 E.08737
G1 X183.006 Y128.243 E.49198
G1 X183.006 Y126.882 E.04184
G1 X182.629 Y126.822 F30000
G1 F12000
G1 X182.629 Y125.777 E.0321
G1 X167.371 Y125.777 E.46881
G1 X167.371 Y127.866 E.0642
G1 X182.629 Y127.866 E.46881
G1 X182.629 Y126.882 E.03026
G1 X182.252 Y126.822 F30000
G1 F12000
G1 X182.252 Y126.154 E.02051
G1 X167.748 Y126.154 E.44564
G1 X167.748 Y127.489 E.04103
G1 X182.252 Y127.489 E.44564
G1 X182.252 Y126.882 E.01867
G1 X181.824 Y126.822 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X181.824 Y126.582 E.00935
G1 X168.176 Y126.582 E.53278
G1 X168.176 Y127.061 E.0187
G1 X181.824 Y127.061 E.53278
G1 X181.824 Y126.882 E.00701
; WIPE_START
G1 X181.824 Y127.061 E-.06823
G1 X180.003 Y127.061 E-.69177
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y124.258 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X182.873 Y123.547 E.03086
G1 X182.339 Y123.547
G1 X183.577 Y124.785 E.05379
G1 X183.044 Y124.785
G1 X181.806 Y123.547 E.05379
G1 X181.273 Y123.547
G1 X182.511 Y124.785 E.05379
G1 X181.977 Y124.785
G1 X180.739 Y123.547 E.05379
G1 X180.206 Y123.547
G1 X181.444 Y124.785 E.05379
G1 X180.911 Y124.785
G1 X179.673 Y123.547 E.05379
G1 X179.14 Y123.547
G1 X180.378 Y124.785 E.05379
G1 X179.844 Y124.785
G1 X178.606 Y123.547 E.05379
G1 X178.073 Y123.547
M73 P87 R3
G1 X179.311 Y124.785 E.05379
G1 X178.778 Y124.785
G1 X177.54 Y123.547 E.05379
G1 X177.007 Y123.547
G1 X178.245 Y124.785 E.05379
G1 X177.711 Y124.785
G1 X176.473 Y123.547 E.05379
G1 X175.94 Y123.547
G1 X177.178 Y124.785 E.05379
G1 X176.645 Y124.785
G1 X175.407 Y123.547 E.05379
G1 X174.874 Y123.547
G1 X176.112 Y124.785 E.05379
G1 X175.578 Y124.785
G1 X174.34 Y123.547 E.05379
G1 X173.807 Y123.547
G1 X175.045 Y124.785 E.05379
G1 X174.512 Y124.785
G1 X173.274 Y123.547 E.05379
G1 X172.741 Y123.547
G1 X173.979 Y124.785 E.05379
G1 X173.445 Y124.785
G1 X172.207 Y123.547 E.05379
G1 X171.674 Y123.547
G1 X172.912 Y124.785 E.05379
G1 X172.379 Y124.785
G1 X171.141 Y123.547 E.05379
G1 X170.608 Y123.547
G1 X171.846 Y124.785 E.05379
G1 X171.312 Y124.785
G1 X170.074 Y123.547 E.05379
G1 X169.541 Y123.547
G1 X170.779 Y124.785 E.05379
G1 X170.246 Y124.785
G1 X169.008 Y123.547 E.05379
G1 X168.475 Y123.547
G1 X169.712 Y124.785 E.05379
G1 X169.179 Y124.785
G1 X167.941 Y123.547 E.05379
G1 X167.408 Y123.547
G1 X168.646 Y124.785 E.05379
G1 X168.113 Y124.785
G1 X166.875 Y123.547 E.05379
G1 X166.417 Y123.623
G1 X167.579 Y124.785 E.0505
G1 X167.046 Y124.785
G1 X166.417 Y124.157 E.02732
; WIPE_START
M204 S10000
G1 X167.046 Y124.785 E-.33791
G1 X167.579 Y124.785 E-.20264
G1 X167.171 Y124.377 E-.21945
; WIPE_END
G1 E-.04 F1800
G1 X166.994 Y130.42 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X166.994 Y131.311 E.02737
G1 X183.006 Y131.311 E.49198
G1 X183.006 Y130.42 E.02737
G1 X167.054 Y130.42 E.49014
G1 X167.439 Y130.866 F30000
; LINE_WIDTH: 0.55654
G1 F12265.878
G1 X182.501 Y130.866 E.63036
G1 X168.915 Y132.769 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.287 Y132.769 E.05401
G1 X168.353 Y131.703 E.05001
G1 X172.083 Y131.703 E.12374
G1 X173.149 Y132.769 E.05001
G1 X174.962 Y132.769 E.06016
G1 X176.029 Y131.703 E.05001
G1 X179.759 Y131.703 E.12374
G1 X180.825 Y132.769 E.05001
G1 X182.638 Y132.769 E.06016
G1 X183.05 Y132.358 E.01929
G1 X183.05 Y131.703 E.02172
G1 X182.076 Y131.703 E.03229
G1 X166.994 Y133.161 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X166.994 Y133.806 E.0198
G1 X166.838 Y133.991 E.00745
G1 X159.194 Y133.994 E.23487
G1 X159.006 Y133.806 E.00819
G1 X159.006 Y130.42 E.10401
G1 X152.994 Y130.42 E.18472
G1 X152.994 Y133.806 E.10401
G1 X152.806 Y133.994 E.00819
G1 X145.194 Y133.994 E.23386
G1 X145.006 Y133.806 E.00819
G1 X145.006 Y130.42 E.10401
G1 X138.994 Y130.42 E.18472
G1 X138.994 Y133.806 E.10401
G1 X138.806 Y133.994 E.00819
G1 X131.194 Y133.994 E.23386
G1 X131.006 Y133.806 E.00819
G1 X131.006 Y130.42 E.10401
G1 X124.994 Y130.42 E.18472
G1 X124.994 Y133.806 E.10401
G1 X124.806 Y133.994 E.00819
G1 X117.194 Y133.994 E.23386
G1 X117.006 Y133.806 E.00819
G1 X117.006 Y130.42 E.10401
G1 X110.994 Y130.42 E.18472
G1 X110.994 Y133.806 E.10401
G1 X110.806 Y133.994 E.00819
G1 X103.194 Y133.994 E.23386
G1 X103.006 Y133.806 E.00819
G1 X103.006 Y130.42 E.10401
G1 X96.994 Y130.42 E.18472
G1 X96.994 Y133.806 E.10401
G1 X96.806 Y133.994 E.00819
G1 X89.194 Y133.994 E.23386
G1 X89.006 Y133.806 E.00819
G1 X89.006 Y133.161 E.0198
G1 X72.994 Y133.161 E.49198
G1 X72.994 Y134.722 E.04797
G1 X183.006 Y134.722 E3.38027
G1 X183.006 Y133.161 E.04797
G1 X167.054 Y133.161 E.49014
G1 X167.371 Y133.538 F30000
; LINE_WIDTH: 0.419585
G1 F12000
G1 X167.366 Y133.885 E.01065
G1 X166.902 Y134.354 E.02025
G1 X182.629 Y134.345 E.48272
G1 X182.629 Y133.538 E.02478
G1 X167.431 Y133.538 E.46647
G1 X167.765 Y133.942 F30000
; LINE_WIDTH: 0.47304
G1 F12000
G1 X182.165 Y133.942 E.50471
G1 X159.194 Y134.358 F30000
; LINE_WIDTH: 0.39422
G1 F12000
G1 X166.842 Y134.357 E.21892
G1 X159.194 Y134.358 F30000
; LINE_WIDTH: 0.417953
G1 F12000
G1 X158.629 Y133.806 E.02417
G1 X158.629 Y130.798 E.09193
G1 X153.371 Y130.798 E.16067
G1 X153.371 Y133.806 E.09193
G1 X152.902 Y134.354 E.02206
G3 X159.134 Y134.358 I2.857 J464.862 E.19047
G1 X158.414 Y133.968 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X158.252 Y133.806 E.00707
G1 X158.252 Y131.175 E.08084
G1 X153.748 Y131.175 E.13838
G1 X153.748 Y133.806 E.08084
G1 X153.612 Y133.968 E.00653
G1 X158.354 Y133.968 E.14573
G1 X157.875 Y133.591 F30000
G1 F12000
G1 X157.875 Y131.552 E.06267
G1 X154.125 Y131.552 E.1152
G1 X154.125 Y133.591 E.06267
G1 X157.815 Y133.591 E.11336
G1 X157.498 Y133.214 F30000
G1 F12000
G1 X157.498 Y131.929 E.0395
G1 X154.502 Y131.929 E.09203
G1 X154.502 Y133.214 E.0395
G1 X157.438 Y133.214 E.09019
G1 X157.082 Y132.799 F30000
; LINE_WIDTH: 0.497125
G1 F12000
G1 X157.082 Y132.344 E.01681
G1 X154.918 Y132.344 E.08009
G1 X154.918 Y132.799 E.01681
G1 X157.022 Y132.799 E.07787
; WIPE_START
G1 X155.022 Y132.799 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X147.484 Y133.995 Z5 F30000
G1 X145.194 Y134.358 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.39422
G1 F12000
G1 X152.842 Y134.357 E.21892
G1 X145.194 Y134.358 F30000
; LINE_WIDTH: 0.417953
G1 F12000
G1 X144.629 Y133.806 E.02417
G1 X144.629 Y130.798 E.09193
G1 X139.371 Y130.798 E.16067
G1 X139.371 Y133.806 E.09193
G1 X138.902 Y134.354 E.02206
G3 X145.134 Y134.358 I2.857 J464.862 E.19047
G1 X144.414 Y133.968 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X144.252 Y133.806 E.00707
G1 X144.252 Y131.175 E.08084
G1 X139.748 Y131.175 E.13838
G1 X139.748 Y133.806 E.08084
G1 X139.612 Y133.968 E.00653
G1 X144.354 Y133.968 E.14573
G1 X143.875 Y133.591 F30000
G1 F12000
G1 X143.875 Y131.552 E.06267
G1 X140.125 Y131.552 E.1152
G1 X140.125 Y133.591 E.06267
G1 X143.815 Y133.591 E.11336
G1 X143.498 Y133.214 F30000
G1 F12000
G1 X143.498 Y131.929 E.0395
G1 X140.502 Y131.929 E.09203
G1 X140.502 Y133.214 E.0395
G1 X143.438 Y133.214 E.09019
G1 X143.082 Y132.799 F30000
; LINE_WIDTH: 0.497125
G1 F12000
G1 X143.082 Y132.344 E.01681
G1 X140.918 Y132.344 E.08009
G1 X140.918 Y132.799 E.01681
G1 X143.022 Y132.799 E.07787
; WIPE_START
G1 X141.022 Y132.799 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X133.484 Y133.995 Z5 F30000
G1 X131.194 Y134.358 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.39422
G1 F12000
G1 X138.842 Y134.357 E.21892
G1 X131.194 Y134.358 F30000
; LINE_WIDTH: 0.417953
G1 F12000
G1 X130.629 Y133.806 E.02417
G1 X130.629 Y130.798 E.09193
G1 X125.371 Y130.798 E.16068
G1 X125.371 Y133.806 E.09193
G1 X124.902 Y134.354 E.02206
G3 X131.134 Y134.358 I2.857 J464.864 E.19047
G1 X130.414 Y133.968 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X130.252 Y133.806 E.00707
G1 X130.252 Y131.175 E.08084
G1 X125.748 Y131.175 E.13838
G1 X125.748 Y133.806 E.08084
G1 X125.612 Y133.968 E.00653
G1 X130.354 Y133.968 E.14573
G1 X129.875 Y133.591 F30000
G1 F12000
G1 X129.875 Y131.552 E.06267
G1 X126.125 Y131.552 E.1152
G1 X126.125 Y133.591 E.06267
G1 X129.815 Y133.591 E.11336
G1 X129.498 Y133.214 F30000
G1 F12000
G1 X129.498 Y131.929 E.0395
G1 X126.502 Y131.929 E.09203
G1 X126.502 Y133.214 E.0395
G1 X129.438 Y133.214 E.09019
G1 X129.082 Y132.799 F30000
; LINE_WIDTH: 0.497125
G1 F12000
G1 X129.082 Y132.344 E.01681
G1 X126.918 Y132.344 E.08009
G1 X126.918 Y132.799 E.01681
G1 X129.022 Y132.799 E.07787
; WIPE_START
G1 X127.022 Y132.799 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X119.484 Y133.995 Z5 F30000
G1 X117.194 Y134.358 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.39422
G1 F12000
G1 X124.842 Y134.357 E.21892
G1 X117.194 Y134.358 F30000
; LINE_WIDTH: 0.417953
G1 F12000
G1 X116.629 Y133.806 E.02417
G1 X116.629 Y130.798 E.09193
G1 X111.371 Y130.798 E.16067
G1 X111.371 Y133.806 E.09193
G1 X110.902 Y134.354 E.02206
G3 X117.134 Y134.358 I2.857 J464.864 E.19047
G1 X116.414 Y133.968 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X116.252 Y133.806 E.00707
G1 X116.252 Y131.175 E.08084
G1 X111.748 Y131.175 E.13838
G1 X111.748 Y133.806 E.08084
G1 X111.612 Y133.968 E.00653
G1 X116.354 Y133.968 E.14573
G1 X115.875 Y133.591 F30000
G1 F12000
G1 X115.875 Y131.552 E.06267
G1 X112.125 Y131.552 E.1152
G1 X112.125 Y133.591 E.06267
G1 X115.815 Y133.591 E.11336
G1 X115.498 Y133.214 F30000
G1 F12000
G1 X115.498 Y131.929 E.0395
G1 X112.502 Y131.929 E.09203
G1 X112.502 Y133.214 E.0395
G1 X115.438 Y133.214 E.09019
G1 X115.082 Y132.799 F30000
; LINE_WIDTH: 0.49713
G1 F12000
G1 X115.082 Y132.344 E.01681
G1 X112.918 Y132.344 E.08009
G1 X112.918 Y132.799 E.01681
G1 X115.022 Y132.799 E.07787
; WIPE_START
G1 X113.022 Y132.799 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X105.484 Y133.995 Z5 F30000
G1 X103.194 Y134.358 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.39422
G1 F12000
G1 X110.842 Y134.357 E.21892
G1 X103.194 Y134.358 F30000
; LINE_WIDTH: 0.417953
G1 F12000
G1 X102.629 Y133.806 E.02417
G1 X102.629 Y130.798 E.09193
G1 X97.371 Y130.798 E.16067
G1 X97.371 Y133.806 E.09193
G1 X96.902 Y134.354 E.02206
G3 X103.134 Y134.358 I2.857 J464.864 E.19047
G1 X102.414 Y133.968 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X102.252 Y133.806 E.00707
G1 X102.252 Y131.175 E.08084
G1 X97.748 Y131.175 E.13838
G1 X97.748 Y133.806 E.08084
G1 X97.612 Y133.968 E.00653
G1 X102.354 Y133.968 E.14573
G1 X101.875 Y133.591 F30000
G1 F12000
G1 X101.875 Y131.552 E.06267
G1 X98.125 Y131.552 E.1152
G1 X98.125 Y133.591 E.06267
G1 X101.815 Y133.591 E.11336
G1 X101.498 Y133.214 F30000
G1 F12000
G1 X101.498 Y131.929 E.0395
G1 X98.502 Y131.929 E.09203
G1 X98.502 Y133.214 E.0395
G1 X101.438 Y133.214 E.09019
G1 X101.082 Y132.799 F30000
; LINE_WIDTH: 0.49713
G1 F12000
G1 X101.082 Y132.344 E.01681
G1 X98.918 Y132.344 E.08009
G1 X98.918 Y132.799 E.01681
G1 X101.022 Y132.799 E.07787
; WIPE_START
G1 X99.022 Y132.799 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X91.484 Y133.995 Z5 F30000
G1 X89.194 Y134.358 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.39422
G1 F12000
G1 X96.842 Y134.357 E.21892
G1 X89.194 Y134.358 F30000
; LINE_WIDTH: 0.419351
G1 F12000
G1 X88.634 Y133.885 E.02249
G1 X88.629 Y133.538 E.01064
G1 X73.371 Y133.538 E.46802
G1 X73.371 Y134.345 E.02476
G1 X89.134 Y134.358 E.48353
G1 X73.775 Y133.942 F30000
; LINE_WIDTH: 0.47303
G1 F12000
G1 X88.175 Y133.942 E.5047
; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X86.175 Y133.942 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 24/32
; update layer progress
M73 L24
M991 S0 P23 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5 I.008 J1.217 P1  F30000
G1 X138.602 Y133.602 Z5
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y125.808 E.25855
G1 X145.398 Y125.808 E.22543
G1 X145.398 Y133.602 E.25855
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y125.808 E.25855
G1 X159.398 Y125.808 E.22543
G1 X159.398 Y133.602 E.25855
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y125.808 E.25855
G1 X183.398 Y125.808 E.55715
G1 X183.398 Y134.635 E.29282
G1 X72.602 Y134.635 E3.6753
G1 X72.602 Y125.808 E.29282
G1 X89.398 Y125.808 E.55715
G1 X89.398 Y133.602 E.25855
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y125.808 E.25855
G1 X103.398 Y125.808 E.22543
G1 X103.398 Y133.602 E.25855
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y125.808 E.25855
G1 X117.398 Y125.808 E.22543
G1 X117.398 Y133.602 E.25855
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y125.808 E.25855
G1 X131.398 Y125.808 E.22543
G1 X131.398 Y133.602 E.25855
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y124.14 E.2787
G1 X145.79 Y124.14 E.23291
G1 X145.79 Y133.21 E.2787
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y124.14 E.2787
G1 X159.79 Y124.14 E.23291
G1 X159.79 Y133.21 E.2787
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y124.14 E.2787
G1 X183.79 Y124.14 E.54018
G1 X183.79 Y135.027 E.33453
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y135.027 E3.42854
G1 X72.21 Y124.14 E.33453
G1 X89.79 Y124.14 E.54018
G1 X89.79 Y133.21 E.2787
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y124.14 E.2787
G1 X103.79 Y124.14 E.23291
G1 X103.79 Y133.21 E.2787
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y124.14 E.2787
G1 X117.79 Y124.14 E.23291
G1 X117.79 Y133.21 E.2787
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y124.14 E.2787
G1 X131.79 Y124.14 E.23291
G1 X131.79 Y133.21 E.2787
G1 X138.15 Y133.21 E.19542
; WIPE_START
M204 S10000
G1 X138.163 Y131.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.806 Y134.119 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.66887
G1 F10064.702
G1 X131.195 Y134.119 E.38821
G1 X125.971 Y133.462 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.47302
G1 F14647.756
G1 X129.969 Y133.462 E.14012
G1 X125.371 Y133.059 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X125.391 Y133.163 E.00326
G1 X125.575 Y133.581 E.01401
G1 X125.575 Y133.866 E.00877
G1 X130.425 Y133.866 E.14905
G1 X130.43 Y133.512 E.01089
G1 X130.629 Y133.119 E.01353
G1 X130.629 Y133.059 E.00185
G1 X125.431 Y133.059 E.1597
G1 X124.994 Y132.682 F30000
G1 F15000
G1 X124.994 Y133.392 E.02182
G1 X125.136 Y133.441 E.00462
G1 X125.198 Y133.581 E.00467
G1 X125.198 Y134.243 E.02036
G1 X130.802 Y134.243 E.17222
G1 X130.802 Y133.581 E.02036
G1 X130.864 Y133.441 E.00467
G1 X131.006 Y133.377 E.00479
G1 X131.006 Y132.682 E.02137
G1 X125.054 Y132.682 E.18288
G1 X124.805 Y134.119 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.66887
G1 F10064.702
G1 X117.194 Y134.119 E.38821
G1 X111.971 Y133.462 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.47302
G1 F14647.756
G1 X115.969 Y133.462 E.14012
G1 X116.629 Y133.059 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X111.371 Y133.059 E.16155
G1 X111.391 Y133.163 E.00326
G1 X111.575 Y133.581 E.01401
G1 X111.575 Y133.866 E.00877
G1 X116.425 Y133.866 E.14905
G1 X116.43 Y133.512 E.01089
G1 X116.629 Y133.119 E.01353
G1 X117.006 Y132.682 F30000
G1 F15000
G1 X110.994 Y132.682 E.18472
G1 X110.994 Y133.392 E.02182
G1 X111.136 Y133.441 E.00462
G1 X111.198 Y133.581 E.00467
G1 X111.198 Y134.243 E.02036
G1 X116.802 Y134.243 E.17222
G1 X116.802 Y133.581 E.02036
G1 X116.864 Y133.441 E.00467
G1 X117.006 Y133.377 E.00479
G1 X117.006 Y132.742 E.01952
G1 X117.006 Y128.243 F30000
; FEATURE: Floating vertical shell
G1 F12000
G1 X117.006 Y126.2 E.06279
G1 X110.994 Y126.2 E.18472
G1 X110.994 Y128.243 E.06279
G1 X116.946 Y128.243 E.18288
G1 X116.629 Y127.222 F30000
G1 F12000
G1 X116.629 Y126.577 E.01981
G1 X111.371 Y126.577 E.16155
G1 X111.371 Y127.866 E.03962
G1 X116.629 Y127.866 E.16155
G1 X116.629 Y127.282 E.01797
G1 X116.212 Y127.222 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X116.212 Y126.994 E.00848
G1 X111.788 Y126.994 E.16446
G1 X111.788 Y127.45 E.01696
G1 X116.212 Y127.45 E.16446
G1 X116.212 Y127.282 E.00625
; WIPE_START
G1 X116.212 Y127.45 E-.06387
G1 X114.38 Y127.45 E-.69613
; WIPE_END
M73 P88 R3
G1 E-.04 F1800
G1 X117.583 Y124.952 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X116.95 Y125.585 E.02751
G1 X116.416 Y125.585
G1 X117.583 Y124.419 E.05068
G1 X117.121 Y124.347
G1 X115.883 Y125.585 E.05379
G1 X115.35 Y125.585
G1 X116.588 Y124.347 E.05379
G1 X116.054 Y124.347
G1 X114.817 Y125.585 E.05379
G1 X114.283 Y125.585
G1 X115.521 Y124.347 E.05379
G1 X114.988 Y124.347
G1 X113.75 Y125.585 E.05379
G1 X113.217 Y125.585
G1 X114.455 Y124.347 E.05379
G1 X113.921 Y124.347
G1 X112.684 Y125.585 E.05379
G1 X112.15 Y125.585
G1 X113.388 Y124.347 E.05379
G1 X112.855 Y124.347
G1 X111.617 Y125.585 E.05379
G1 X111.084 Y125.585
G1 X112.322 Y124.347 E.05379
G1 X111.788 Y124.347
G1 X110.55 Y125.585 E.05379
G1 X110.417 Y125.185
G1 X111.255 Y124.347 E.0364
; WIPE_START
M204 S10000
G1 X110.417 Y125.185 E-.45021
G1 X110.55 Y125.585 E-.16025
G1 X110.829 Y125.307 E-.14955
; WIPE_END
G1 E-.04 F1800
G1 X110.95 Y130.35 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.95 Y131.978 E.05401
G1 X111.262 Y132.29 E.01462
G1 X114.034 Y132.29 E.09197
G1 X117.05 Y129.274 E.14146
G1 X117.05 Y130.402 E.03739
G1 X115.283 Y128.635 E.08286
G1 X113.655 Y128.635 E.05401
G1 X110.805 Y134.119 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.66887
G1 F10064.702
G1 X103.194 Y134.119 E.38821
G1 X97.971 Y133.462 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.47302
G1 F14647.756
G1 X101.969 Y133.462 E.14012
G1 X102.629 Y133.059 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X97.371 Y133.059 E.16155
G1 X97.391 Y133.163 E.00326
G1 X97.575 Y133.581 E.01401
G1 X97.575 Y133.866 E.00877
G1 X102.425 Y133.866 E.14905
G1 X102.43 Y133.512 E.01089
G1 X102.629 Y133.119 E.01353
G1 X103.006 Y132.682 F30000
G1 F15000
G1 X96.994 Y132.682 E.18472
G1 X96.994 Y133.392 E.02182
G1 X97.136 Y133.441 E.00462
G1 X97.198 Y133.581 E.00467
G1 X97.198 Y134.243 E.02036
G1 X102.802 Y134.243 E.17222
G1 X102.802 Y133.581 E.02036
G1 X102.864 Y133.441 E.00467
G1 X103.006 Y133.377 E.00479
G1 X103.006 Y132.742 E.01952
G1 X103.006 Y128.243 F30000
; FEATURE: Floating vertical shell
G1 F12000
G1 X103.006 Y126.2 E.06279
G1 X96.994 Y126.2 E.18472
G1 X96.994 Y128.243 E.06279
G1 X102.946 Y128.243 E.18288
G1 X102.629 Y127.866 F30000
G1 F12000
G1 X102.629 Y126.577 E.03962
G1 X97.371 Y126.577 E.16155
G1 X97.371 Y127.866 E.03962
G1 X102.569 Y127.866 E.1597
G1 X102.212 Y127.45 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X102.212 Y126.994 E.01696
G1 X97.788 Y126.994 E.16446
G1 X97.788 Y127.45 E.01696
G1 X102.152 Y127.45 E.16223
; WIPE_START
G1 X100.152 Y127.45 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y125.088 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X103.085 Y125.585 E.02163
G1 X102.552 Y125.585
G1 X103.583 Y124.554 E.0448
G1 X103.256 Y124.347
G1 X102.018 Y125.585 E.05379
G1 X101.485 Y125.585
G1 X102.723 Y124.347 E.05379
G1 X102.19 Y124.347
G1 X100.952 Y125.585 E.05379
G1 X100.419 Y125.585
G1 X101.656 Y124.347 E.05379
G1 X101.123 Y124.347
G1 X99.885 Y125.585 E.05379
G1 X99.352 Y125.585
G1 X100.59 Y124.347 E.05379
G1 X100.057 Y124.347
G1 X98.819 Y125.585 E.05379
G1 X98.286 Y125.585
G1 X99.523 Y124.347 E.05379
G1 X98.99 Y124.347
G1 X97.752 Y125.585 E.05379
G1 X97.219 Y125.585
G1 X98.457 Y124.347 E.05379
G1 X97.924 Y124.347
G1 X96.686 Y125.585 E.05379
G1 X96.417 Y125.32
G1 X97.39 Y124.347 E.04228
G1 X96.857 Y124.347
G1 X96.417 Y124.787 E.01911
; WIPE_START
M204 S10000
G1 X96.857 Y124.347 E-.23635
G1 X97.39 Y124.347 E-.20264
G1 X96.793 Y124.945 E-.32102
; WIPE_END
G1 E-.04 F1800
G1 X89.22 Y125.585 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X89.583 Y125.223 E.01575
G1 X89.583 Y124.69
G1 X88.687 Y125.585 E.03892
G1 X88.154 Y125.585
G1 X89.392 Y124.347 E.05379
G1 X88.858 Y124.347
G1 X87.62 Y125.585 E.05379
G1 X87.087 Y125.585
G1 X88.325 Y124.347 E.05379
G1 X87.792 Y124.347
G1 X86.554 Y125.585 E.05379
G1 X86.021 Y125.585
G1 X87.259 Y124.347 E.05379
G1 X86.725 Y124.347
G1 X85.487 Y125.585 E.05379
G1 X84.954 Y125.585
G1 X86.192 Y124.347 E.05379
G1 X85.659 Y124.347
G1 X84.421 Y125.585 E.05379
G1 X83.888 Y125.585
G1 X85.126 Y124.347 E.05379
G1 X84.592 Y124.347
G1 X83.354 Y125.585 E.05379
G1 X82.821 Y125.585
G1 X84.059 Y124.347 E.05379
G1 X83.526 Y124.347
G1 X82.288 Y125.585 E.05379
G1 X81.755 Y125.585
G1 X82.992 Y124.347 E.05379
G1 X82.459 Y124.347
G1 X81.221 Y125.585 E.05379
G1 X80.688 Y125.585
G1 X81.926 Y124.347 E.05379
G1 X81.393 Y124.347
G1 X80.155 Y125.585 E.05379
G1 X79.622 Y125.585
G1 X80.859 Y124.347 E.05379
G1 X80.326 Y124.347
G1 X79.088 Y125.585 E.05379
G1 X78.555 Y125.585
G1 X79.793 Y124.347 E.05379
G1 X79.26 Y124.347
G1 X78.022 Y125.585 E.05379
G1 X77.489 Y125.585
G1 X78.726 Y124.347 E.05379
G1 X78.193 Y124.347
G1 X76.955 Y125.585 E.05379
G1 X76.422 Y125.585
G1 X77.66 Y124.347 E.05379
G1 X77.127 Y124.347
G1 X75.889 Y125.585 E.05379
G1 X75.355 Y125.585
G1 X76.593 Y124.347 E.05379
G1 X76.06 Y124.347
G1 X74.822 Y125.585 E.05379
G1 X74.289 Y125.585
G1 X75.527 Y124.347 E.05379
G1 X74.994 Y124.347
G1 X73.756 Y125.585 E.05379
G1 X73.222 Y125.585
G1 X74.46 Y124.347 E.05379
G1 X73.927 Y124.347
G1 X72.689 Y125.585 E.05379
G1 X72.417 Y125.324
G1 X73.394 Y124.347 E.04243
G1 X72.861 Y124.347
G1 X72.417 Y124.791 E.01926
; WIPE_START
M204 S10000
G1 X72.861 Y124.347 E-.23818
G1 X73.394 Y124.347 E-.20264
G1 X72.8 Y124.941 E-.31919
; WIPE_END
G1 E-.04 F1800
G1 X80.431 Y124.815 Z5.2 F30000
G1 X89.557 Y124.664 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.132557
G1 F15000
G1 X89.557 Y124.329 E.00245
; WIPE_START
G1 X89.557 Y124.664 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.006 Y127.622 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y126.2 E.04369
G1 X72.994 Y126.2 E.49198
G1 X72.994 Y129.043 E.08737
G1 X89.006 Y129.043 E.49198
G1 X89.006 Y127.682 E.04184
G1 X88.629 Y127.622 F30000
G1 F12000
G1 X88.629 Y126.577 E.0321
G1 X73.371 Y126.577 E.46881
G1 X73.371 Y128.666 E.0642
G1 X88.629 Y128.666 E.46881
G1 X88.629 Y127.682 E.03026
G1 X88.252 Y127.622 F30000
G1 F12000
G1 X88.252 Y126.954 E.02051
G1 X73.748 Y126.954 E.44564
G1 X73.748 Y128.289 E.04103
G1 X88.252 Y128.289 E.44564
G1 X88.252 Y127.682 E.01867
G1 X87.824 Y127.622 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X87.824 Y127.382 E.00935
G1 X74.176 Y127.382 E.53278
G1 X74.176 Y127.861 E.0187
G1 X87.824 Y127.861 E.53278
G1 X87.824 Y127.682 E.00701
G1 X89.194 Y134.119 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.66887
G1 F10064.702
G1 X96.805 Y134.119 E.38821
G1 X97.054 Y132.29 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X98.682 Y132.29 E.05401
G1 X102.337 Y128.635 E.17144
G1 X99.932 Y128.635 E.07979
G1 X103.05 Y131.753 E.14628
G1 X103.05 Y132.29 E.01779
G1 X101.958 Y132.29 E.03623
; WIPE_START
G1 X103.05 Y132.29 E-.41498
G1 X103.05 Y131.753 E-.20378
G1 X102.787 Y131.491 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X110.367 Y130.597 Z5.2 F30000
G1 X126.993 Y128.635 Z5.2
G1 Z4.8
G1 E.8 F1800
G1 F15476.087
G1 X125.365 Y128.635 E.05401
G1 X124.95 Y129.05 E.01944
G1 X124.95 Y130.626 E.0523
G1 X126.614 Y132.29 E.07804
G1 X129.386 Y132.29 E.09197
G1 X131.05 Y130.626 E.07804
G1 X131.05 Y129.05 E.0523
G1 X130.635 Y128.635 E.01944
G1 X129.007 Y128.635 E.05401
G1 X131.006 Y127.222 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.006 Y126.2 E.0314
G1 X124.994 Y126.2 E.18472
G1 X124.994 Y128.243 E.06279
G1 X131.006 Y128.243 E.18472
G1 X131.006 Y127.282 E.02955
G1 X130.629 Y127.222 F30000
G1 F12000
G1 X130.629 Y126.577 E.01981
G1 X125.371 Y126.577 E.16155
G1 X125.371 Y127.866 E.03962
G1 X130.629 Y127.866 E.16155
G1 X130.629 Y127.282 E.01797
G1 X130.212 Y127.222 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X130.212 Y126.994 E.00848
G1 X125.788 Y126.994 E.16446
G1 X125.788 Y127.45 E.01696
G1 X130.212 Y127.45 E.16446
G1 X130.212 Y127.282 E.00625
; WIPE_START
G1 X130.212 Y127.45 E-.06387
G1 X128.38 Y127.45 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X130.814 Y125.585 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X131.583 Y124.817 E.03339
G1 X131.519 Y124.347
G1 X130.281 Y125.585 E.05379
G1 X129.748 Y125.585
G1 X130.986 Y124.347 E.05379
G1 X130.452 Y124.347
G1 X129.215 Y125.585 E.05379
G1 X128.681 Y125.585
G1 X129.919 Y124.347 E.05379
G1 X129.386 Y124.347
G1 X128.148 Y125.585 E.05379
G1 X127.615 Y125.585
G1 X128.853 Y124.347 E.05379
G1 X128.319 Y124.347
G1 X127.081 Y125.585 E.05379
G1 X126.548 Y125.585
G1 X127.786 Y124.347 E.05379
G1 X127.253 Y124.347
G1 X126.015 Y125.585 E.05379
G1 X125.482 Y125.585
G1 X126.72 Y124.347 E.05379
G1 X126.186 Y124.347
G1 X124.948 Y125.585 E.05379
G1 X124.417 Y125.583
G1 X125.653 Y124.347 E.0537
G1 X125.12 Y124.347
G1 X124.417 Y125.05 E.03052
; WIPE_START
M204 S10000
G1 X125.12 Y124.347 E-.3775
G1 X125.653 Y124.347 E-.20264
G1 X125.318 Y124.682 E-.17987
; WIPE_END
G1 E-.04 F1800
G1 X131.865 Y128.605 Z5.2 F30000
G1 X139.971 Y133.462 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.47302
G1 F14647.756
G1 X143.969 Y133.462 E.14012
G1 X139.371 Y133.059 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X139.391 Y133.163 E.00326
G1 X139.575 Y133.581 E.01402
G1 X139.575 Y133.866 E.00877
G1 X144.425 Y133.866 E.14905
G1 X144.43 Y133.512 E.01089
G1 X144.629 Y133.119 E.01353
G1 X144.629 Y133.059 E.00185
G1 X139.431 Y133.059 E.1597
G1 X138.994 Y132.682 F30000
G1 F15000
G1 X138.994 Y133.392 E.02182
G1 X139.136 Y133.441 E.00462
G1 X139.198 Y133.581 E.00467
G1 X139.198 Y134.243 E.02036
G1 X144.802 Y134.243 E.17222
G1 X144.802 Y133.581 E.02036
G1 X144.864 Y133.441 E.00467
G1 X145.006 Y133.377 E.00479
G1 X145.006 Y132.682 E.02137
G1 X139.054 Y132.682 E.18288
G1 X142.345 Y128.635 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X140.717 Y128.635 E.05401
G1 X138.95 Y130.402 E.08286
G1 X138.95 Y129.274 E.03739
G1 X141.966 Y132.29 E.14146
G1 X144.738 Y132.29 E.09197
G1 X145.05 Y131.978 E.01462
G1 X145.05 Y130.35 E.05401
G1 X145.006 Y127.222 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X145.006 Y126.2 E.0314
G1 X138.994 Y126.2 E.18472
G1 X138.994 Y128.243 E.06279
G1 X145.006 Y128.243 E.18472
G1 X145.006 Y127.282 E.02955
G1 X144.629 Y127.222 F30000
G1 F12000
G1 X144.629 Y126.577 E.01981
G1 X139.371 Y126.577 E.16155
G1 X139.371 Y127.866 E.03962
G1 X144.629 Y127.866 E.16155
G1 X144.629 Y127.282 E.01797
G1 X144.212 Y127.222 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X144.212 Y126.994 E.00848
G1 X139.788 Y126.994 E.16446
G1 X139.788 Y127.45 E.01696
G1 X144.212 Y127.45 E.16446
G1 X144.212 Y127.282 E.00625
; WIPE_START
G1 X144.212 Y127.45 E-.06387
G1 X142.38 Y127.45 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y125.215 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.212 Y125.585 E.0161
G1 X144.679 Y125.585
G1 X145.583 Y124.682 E.03927
G1 X145.384 Y124.347
G1 X144.146 Y125.585 E.05379
G1 X143.612 Y125.585
G1 X144.85 Y124.347 E.05379
G1 X144.317 Y124.347
G1 X143.079 Y125.585 E.05379
G1 X142.546 Y125.585
G1 X143.784 Y124.347 E.05379
G1 X143.251 Y124.347
G1 X142.013 Y125.585 E.05379
G1 X141.479 Y125.585
G1 X142.717 Y124.347 E.05379
G1 X142.184 Y124.347
G1 X140.946 Y125.585 E.05379
G1 X140.413 Y125.585
G1 X141.651 Y124.347 E.05379
G1 X141.118 Y124.347
G1 X139.88 Y125.585 E.05379
G1 X139.346 Y125.585
G1 X140.584 Y124.347 E.05379
G1 X140.051 Y124.347
G1 X138.813 Y125.585 E.05379
G1 X138.417 Y125.448
G1 X139.518 Y124.347 E.04782
G1 X138.985 Y124.347
G1 X138.417 Y124.915 E.02464
; WIPE_START
M204 S10000
G1 X138.985 Y124.347 E-.30477
G1 X139.518 Y124.347 E-.20264
G1 X139.048 Y124.817 E-.25259
; WIPE_END
G1 E-.04 F1800
G1 X143.256 Y131.185 Z5.2 F30000
G1 X145.195 Y134.119 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.66887
G1 F10064.702
G1 X152.806 Y134.119 E.38821
G1 X153.971 Y133.462 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.47302
G1 F14647.756
G1 X157.969 Y133.462 E.14012
G1 X153.371 Y133.059 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X153.391 Y133.163 E.00326
G1 X153.575 Y133.581 E.01402
G1 X153.575 Y133.866 E.00877
G1 X158.425 Y133.866 E.14905
G1 X158.43 Y133.512 E.01089
G1 X158.629 Y133.119 E.01353
G1 X158.629 Y133.059 E.00185
G1 X153.431 Y133.059 E.1597
G1 X152.994 Y132.682 F30000
G1 F15000
G1 X152.994 Y133.392 E.02182
G1 X153.136 Y133.441 E.00462
G1 X153.198 Y133.581 E.00467
G1 X153.198 Y134.243 E.02036
G1 X158.802 Y134.243 E.17222
G1 X158.802 Y133.581 E.02036
G1 X158.864 Y133.441 E.00467
G1 X159.006 Y133.377 E.00479
G1 X159.006 Y132.682 E.02137
G1 X153.054 Y132.682 E.18288
G1 X154.042 Y132.29 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X152.95 Y132.29 E.03622
G1 X152.95 Y131.753 E.01779
G1 X156.068 Y128.635 E.14628
G1 X153.663 Y128.635 E.07979
G1 X157.318 Y132.29 E.17144
G1 X158.946 Y132.29 E.05401
G1 X159.195 Y134.119 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.66887
G1 F10064.702
G1 X166.806 Y134.119 E.38821
G1 X166.994 Y133.392 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X167.136 Y133.441 E.00462
G1 X167.198 Y133.581 E.00467
G1 X167.198 Y134.243 E.02036
G1 X183.006 Y134.243 E.48573
G1 X183.006 Y132.682 E.04797
G1 X166.994 Y132.682 E.49198
G1 X166.994 Y133.332 E.01998
G1 X167.391 Y133.163 F30000
G1 F12000
G1 X167.575 Y133.581 E.01402
G1 X167.575 Y133.866 E.00877
G1 X182.629 Y133.866 E.46256
G1 X182.629 Y133.059 E.0248
G1 X167.371 Y133.059 E.46881
G1 X167.38 Y133.104 E.00142
G1 X167.971 Y133.462 F30000
; LINE_WIDTH: 0.47303
G1 F12000
G1 X182.165 Y133.462 E.49749
G1 X183.006 Y127.622 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y126.2 E.04369
G1 X166.994 Y126.2 E.49198
G1 X166.994 Y129.043 E.08737
G1 X183.006 Y129.043 E.49198
G1 X183.006 Y127.682 E.04184
G1 X182.629 Y127.622 F30000
G1 F12000
G1 X182.629 Y126.577 E.0321
G1 X167.371 Y126.577 E.46881
G1 X167.371 Y128.666 E.0642
G1 X182.629 Y128.666 E.46881
G1 X182.629 Y127.682 E.03026
G1 X182.252 Y127.622 F30000
G1 F12000
G1 X182.252 Y126.954 E.02051
G1 X167.748 Y126.954 E.44564
G1 X167.748 Y128.289 E.04103
G1 X182.252 Y128.289 E.44564
G1 X182.252 Y127.682 E.01867
G1 X181.824 Y127.622 F30000
; LINE_WIDTH: 0.522
G1 F12000
G1 X181.824 Y127.382 E.00935
G1 X168.176 Y127.382 E.53278
G1 X168.176 Y127.861 E.0187
G1 X181.824 Y127.861 E.53278
G1 X181.824 Y127.682 E.00701
; WIPE_START
G1 X181.824 Y127.861 E-.06823
G1 X180.003 Y127.861 E-.69177
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y125.076 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.074 Y125.585 E.02212
G1 X182.54 Y125.585
G1 X183.583 Y124.543 E.0453
G1 X183.245 Y124.347
G1 X182.007 Y125.585 E.05379
G1 X181.474 Y125.585
G1 X182.712 Y124.347 E.05379
G1 X182.178 Y124.347
G1 X180.94 Y125.585 E.05379
G1 X180.407 Y125.585
G1 X181.645 Y124.347 E.05379
G1 X181.112 Y124.347
G1 X179.874 Y125.585 E.05379
G1 X179.341 Y125.585
G1 X180.579 Y124.347 E.05379
G1 X180.045 Y124.347
G1 X178.807 Y125.585 E.05379
G1 X178.274 Y125.585
G1 X179.512 Y124.347 E.05379
G1 X178.979 Y124.347
G1 X177.741 Y125.585 E.05379
G1 X177.208 Y125.585
G1 X178.446 Y124.347 E.05379
G1 X177.912 Y124.347
G1 X176.674 Y125.585 E.05379
G1 X176.141 Y125.585
G1 X177.379 Y124.347 E.05379
G1 X176.846 Y124.347
G1 X175.608 Y125.585 E.05379
G1 X175.075 Y125.585
G1 X176.313 Y124.347 E.05379
G1 X175.779 Y124.347
G1 X174.541 Y125.585 E.05379
G1 X174.008 Y125.585
G1 X175.246 Y124.347 E.05379
G1 X174.713 Y124.347
G1 X173.475 Y125.585 E.05379
G1 X172.942 Y125.585
G1 X174.18 Y124.347 E.05379
G1 X173.646 Y124.347
G1 X172.408 Y125.585 E.05379
G1 X171.875 Y125.585
G1 X173.113 Y124.347 E.05379
G1 X172.58 Y124.347
G1 X171.342 Y125.585 E.05379
G1 X170.809 Y125.585
G1 X172.047 Y124.347 E.05379
G1 X171.513 Y124.347
G1 X170.275 Y125.585 E.05379
G1 X169.742 Y125.585
G1 X170.98 Y124.347 E.05379
G1 X170.447 Y124.347
G1 X169.209 Y125.585 E.05379
G1 X168.676 Y125.585
G1 X169.913 Y124.347 E.05379
G1 X169.38 Y124.347
G1 X168.142 Y125.585 E.05379
G1 X167.609 Y125.585
G1 X168.847 Y124.347 E.05379
G1 X168.314 Y124.347
G1 X167.076 Y125.585 E.05379
G1 X166.543 Y125.585
G1 X167.78 Y124.347 E.05379
G1 X167.247 Y124.347
G1 X166.417 Y125.177 E.03606
; WIPE_START
M204 S10000
G1 X167.247 Y124.347 E-.44593
G1 X167.78 Y124.347 E-.20264
G1 X167.573 Y124.555 E-.11144
; WIPE_END
M73 P89 R3
G1 E-.04 F1800
G1 X166.95 Y131.477 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X166.95 Y132.29 E.02696
G1 X167.766 Y132.29 E.02706
G1 X170.62 Y129.435 E.13391
G1 X169.815 Y129.435 E.02671
G1 X172.67 Y132.29 E.13391
G1 X175.442 Y132.29 E.09197
G1 X178.296 Y129.435 E.13391
G1 X177.491 Y129.435 E.02671
G1 X180.345 Y132.29 E.13391
G1 X181.974 Y132.29 E.05401
; WIPE_START
G1 X180.345 Y132.29 E-.61876
G1 X180.083 Y132.027 E-.14125
; WIPE_END
G1 E-.04 F1800
G1 X172.641 Y130.33 Z5.2 F30000
G1 X159.006 Y127.222 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X159.006 Y126.2 E.0314
G1 X152.994 Y126.2 E.18472
G1 X152.994 Y128.243 E.06279
G1 X159.006 Y128.243 E.18472
G1 X159.006 Y127.282 E.02955
G1 X158.629 Y127.222 F30000
G1 F12000
G1 X158.629 Y126.577 E.01981
G1 X153.371 Y126.577 E.16155
G1 X153.371 Y127.866 E.03962
G1 X158.629 Y127.866 E.16155
G1 X158.629 Y127.282 E.01797
G1 X158.212 Y127.222 F30000
; LINE_WIDTH: 0.49907
G1 F12000
G1 X158.212 Y126.994 E.00848
G1 X153.788 Y126.994 E.16446
G1 X153.788 Y127.45 E.01696
G1 X158.212 Y127.45 E.16446
G1 X158.212 Y127.282 E.00625
; WIPE_START
G1 X158.212 Y127.45 E-.06387
G1 X156.38 Y127.45 E-.69613
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y125.08 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X159.077 Y125.585 E.02197
G1 X158.544 Y125.585
G1 X159.583 Y124.546 E.04515
G1 X159.248 Y124.347
G1 X158.01 Y125.585 E.05379
G1 X157.477 Y125.585
G1 X158.715 Y124.347 E.05379
G1 X158.182 Y124.347
G1 X156.944 Y125.585 E.05379
G1 X156.411 Y125.585
G1 X157.649 Y124.347 E.05379
G1 X157.115 Y124.347
G1 X155.877 Y125.585 E.05379
G1 X155.344 Y125.585
G1 X156.582 Y124.347 E.05379
G1 X156.049 Y124.347
G1 X154.811 Y125.585 E.05379
G1 X154.278 Y125.585
G1 X155.516 Y124.347 E.05379
G1 X154.982 Y124.347
G1 X153.744 Y125.585 E.05379
G1 X153.211 Y125.585
G1 X154.449 Y124.347 E.05379
G1 X153.916 Y124.347
G1 X152.678 Y125.585 E.05379
G1 X152.417 Y125.313
G1 X153.382 Y124.347 E.04194
G1 X152.849 Y124.347
G1 X152.417 Y124.779 E.01877
; WIPE_START
M204 S10000
G1 X152.849 Y124.347 E-.23207
G1 X153.382 Y124.347 E-.20264
G1 X152.777 Y124.953 E-.3253
; WIPE_END
G1 E-.04 F1800
G1 X145.178 Y125.661 Z5.2 F30000
G1 X74.026 Y132.29 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X75.654 Y132.29 E.05401
G1 X78.509 Y129.435 E.13391
G1 X77.704 Y129.435 E.02671
G1 X80.558 Y132.29 E.13391
G1 X83.33 Y132.29 E.09197
G1 X86.185 Y129.435 E.13391
G1 X85.38 Y129.435 E.02671
G1 X88.234 Y132.29 E.13391
G1 X89.05 Y132.29 E.02706
G1 X89.05 Y131.477 E.02696
G1 X72.994 Y132.682 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X72.994 Y134.243 E.04797
G1 X88.802 Y134.243 E.48573
G1 X88.802 Y133.581 E.02036
G1 X88.864 Y133.441 E.00467
G1 X89.006 Y133.377 E.00479
G1 X89.006 Y132.682 E.02137
G1 X73.054 Y132.682 E.49014
G1 X73.371 Y133.059 F30000
G1 F12000
G1 X73.371 Y133.866 E.0248
G1 X88.425 Y133.866 E.46256
G1 X88.43 Y133.512 E.01089
G1 X88.629 Y133.119 E.01353
G1 X88.629 Y133.059 E.00184
G1 X73.431 Y133.059 E.46697
G1 X73.775 Y133.462 F30000
; LINE_WIDTH: 0.47302
G1 F12000
G1 X87.969 Y133.462 E.49747
; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X85.969 Y133.462 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 25/32
; update layer progress
M73 L25
M991 S0 P24 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.2 I-.003 J1.217 P1  F30000
G1 X138.602 Y133.602 Z5.2
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y126.608 E.23201
G1 X145.398 Y126.608 E.22543
G1 X145.398 Y133.602 E.23201
G1 X152.602 Y133.602 E.23897
G1 X152.602 Y126.608 E.23201
G1 X159.398 Y126.608 E.22543
G1 X159.398 Y133.602 E.23201
G1 X166.602 Y133.602 E.23897
G1 X166.602 Y126.608 E.23201
G1 X183.398 Y126.608 E.55715
G1 X183.398 Y134.156 E.25038
G1 X72.602 Y134.156 E3.6753
G1 X72.602 Y126.608 E.25038
G1 X89.398 Y126.608 E.55715
G1 X89.398 Y133.602 E.23201
G1 X96.602 Y133.602 E.23897
G1 X96.602 Y126.608 E.23201
G1 X103.398 Y126.608 E.22543
G1 X103.398 Y133.602 E.23201
G1 X110.602 Y133.602 E.23897
G1 X110.602 Y126.608 E.23201
G1 X117.398 Y126.608 E.22543
G1 X117.398 Y133.602 E.23201
G1 X124.602 Y133.602 E.23897
G1 X124.602 Y126.608 E.23201
G1 X131.398 Y126.608 E.22543
G1 X131.398 Y133.602 E.23201
G1 X138.542 Y133.602 E.23698
M204 S250
G1 X138.21 Y133.21 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y124.94 E.25411
G1 X145.79 Y124.94 E.23291
G1 X145.79 Y133.21 E.25411
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y124.94 E.25411
G1 X159.79 Y124.94 E.23291
G1 X159.79 Y133.21 E.25411
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y124.94 E.25411
G1 X183.79 Y124.94 E.54018
G1 X183.79 Y134.548 E.29522
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y134.548 E3.42854
G1 X72.21 Y124.94 E.29522
G1 X89.79 Y124.94 E.54018
G1 X89.79 Y133.21 E.25411
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y124.94 E.25411
G1 X103.79 Y124.94 E.23291
G1 X103.79 Y133.21 E.25411
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y124.94 E.25411
G1 X117.79 Y124.94 E.23291
G1 X117.79 Y133.21 E.25411
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y124.94 E.25411
G1 X131.79 Y124.94 E.23291
G1 X131.79 Y133.21 E.25411
G1 X138.15 Y133.21 E.19542
M204 S10000
G1 X138.806 Y133.879 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.18942
G1 F15000
G1 X131.195 Y133.879 E.09086
G1 X130.612 Y129.435 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X130.673 Y129.435 E.002
G1 X130.673 Y131.003 E.05201
G1 X129.866 Y131.81 E.03785
G1 X126.134 Y131.81 E.12378
G1 X125.327 Y131.003 E.03785
G1 X125.327 Y129.435 E.05201
G1 X125.388 Y129.435 E.002
G1 X124.966 Y132.041 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.965 Y129.292 E.07617
; Slow Down End
G1 X131.006 Y133.377 F30000
; LINE_WIDTH: 0.416824
G1 F12000
G1 X130.842 Y133.465 E.00566
G1 X130.802 Y133.764 E.00919
G1 X125.198 Y133.764 E.17077
G1 X125.158 Y133.465 E.00919
G1 X125.009 Y133.392 E.00504
G3 X124.966 Y132.041 I165.046 J-5.93 E.04117
; Slow Down Start
; LINE_WIDTH: 0.413928
G1 F3000;_EXTRUDE_SET_SPEED
G1 X125.124 Y132.197 E.00671
G2 X130.876 Y132.197 I2.874 J-851.803 E.17389
G1 X131.034 Y132.041 E.00671
G2 X131.01 Y132.493 I2.991 J.385 E.0137
; Slow Down End
; LINE_WIDTH: 0.41728
G1 F12000
G1 X131.006 Y133.317 E.02513
G1 X130.629 Y133.192 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X130.629 Y132.579 E.01882
G1 X125.371 Y132.579 E.16155
G1 X125.371 Y133.192 E.01883
G1 X125.455 Y133.233 E.00287
G1 X125.508 Y133.387 E.00499
G1 X130.492 Y133.387 E.15314
G1 X130.545 Y133.233 E.00499
G1 X130.575 Y133.218 E.00103
G1 X130.225 Y132.983 F30000
; LINE_WIDTH: 0.47313
G1 F12000
G1 X125.835 Y132.983 E.15391
G1 X131.035 Y129.232 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.035 Y131.981 E.07617
; Slow Down End
G1 X131.035 Y129.232 F30000
; Slow Down Start
; LINE_WIDTH: 0.414405
G1 F3000;_EXTRUDE_SET_SPEED
G1 X130.876 Y129.047 E.0074
G2 X125.124 Y129.047 I-2.876 J1284.32 E.17412
M73 P89 R2
G1 X124.965 Y129.232 E.0074
G2 X124.993 Y128.432 I-5.099 J-.578 E.02426
; Slow Down End
; LINE_WIDTH: 0.417772
G1 F12000
G2 X124.994 Y127 I-198.411 J-.921 E.04374
G1 X131.006 Y127 E.18363
G2 X131.034 Y129.172 I53.888 J.396 E.06636
G1 X130.629 Y128.022 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X130.629 Y127.377 E.01981
G1 X125.371 Y127.377 E.16155
G1 X125.371 Y128.666 E.03962
G1 X130.629 Y128.666 E.16155
G1 X130.629 Y128.082 E.01797
G1 X130.212 Y128.022 F30000
; LINE_WIDTH: 0.49912
G1 F12000
G1 X130.212 Y127.794 E.00848
G1 X125.788 Y127.794 E.16447
G1 X125.788 Y128.25 E.01696
G1 X130.212 Y128.25 E.16447
G1 X130.212 Y128.082 E.00625
; WIPE_START
G1 X130.212 Y128.25 E-.06388
G1 X128.38 Y128.25 E-.69612
; WIPE_END
G1 E-.04 F1800
G1 X131.583 Y125.583 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X131.147 Y125.147 E.01894
G1 X130.614 Y125.147
G1 X131.583 Y126.117 E.04211
G1 X131.318 Y126.385
G1 X130.08 Y125.147 E.05379
G1 X129.547 Y125.147
G1 X130.785 Y126.385 E.05379
G1 X130.252 Y126.385
G1 X129.014 Y125.147 E.05379
G1 X128.48 Y125.147
G1 X129.718 Y126.385 E.05379
G1 X129.185 Y126.385
G1 X127.947 Y125.147 E.05379
G1 X127.414 Y125.147
G1 X128.652 Y126.385 E.05379
G1 X128.119 Y126.385
G1 X126.881 Y125.147 E.05379
G1 X126.347 Y125.147
G1 X127.585 Y126.385 E.05379
G1 X127.052 Y126.385
G1 X125.814 Y125.147 E.05379
G1 X125.281 Y125.147
G1 X126.519 Y126.385 E.05379
G1 X125.986 Y126.385
G1 X124.748 Y125.147 E.05379
G1 X124.417 Y125.35
G1 X125.452 Y126.385 E.04497
G1 X124.919 Y126.385
G1 X124.417 Y125.884 E.0218
; WIPE_START
M204 S10000
G1 X124.919 Y126.385 E-.2696
G1 X125.452 Y126.385 E-.20264
G1 X124.917 Y125.85 E-.28776
; WIPE_END
G1 E-.04 F1800
G1 X117.312 Y125.196 Z5.4 F30000
G1 X116.749 Y125.147 Z5.4
G1 Z5
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X117.583 Y125.981 E.03623
G1 X117.453 Y126.385
G1 X116.216 Y125.147 E.05379
G1 X115.682 Y125.147
G1 X116.92 Y126.385 E.05379
G1 X116.387 Y126.385
G1 X115.149 Y125.147 E.05379
G1 X114.616 Y125.147
G1 X115.854 Y126.385 E.05379
G1 X115.32 Y126.385
G1 X114.083 Y125.147 E.05379
G1 X113.549 Y125.147
G1 X114.787 Y126.385 E.05379
G1 X114.254 Y126.385
G1 X113.016 Y125.147 E.05379
G1 X112.483 Y125.147
G1 X113.721 Y126.385 E.05379
G1 X113.187 Y126.385
G1 X111.95 Y125.147 E.05379
G1 X111.416 Y125.147
G1 X112.654 Y126.385 E.05379
G1 X112.121 Y126.385
G1 X110.883 Y125.147 E.05379
G1 X110.417 Y125.215
G1 X111.588 Y126.385 E.05085
G1 X111.054 Y126.385
G1 X110.417 Y125.748 E.02768
; WIPE_START
M204 S10000
G1 X111.054 Y126.385 E-.34232
G1 X111.588 Y126.385 E-.20264
G1 X111.187 Y125.985 E-.21505
; WIPE_END
G1 E-.04 F1800
G1 X110.966 Y132.041 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X110.965 Y129.292 E.07617
; Slow Down End
G1 X110.966 Y132.041 F30000
; Slow Down Start
; LINE_WIDTH: 0.413928
G1 F3000;_EXTRUDE_SET_SPEED
G1 X111.124 Y132.197 E.00671
G2 X116.876 Y132.197 I2.874 J-851.8 E.17389
G1 X117.034 Y132.041 E.00671
G2 X117.01 Y132.493 I2.991 J.385 E.0137
; Slow Down End
; LINE_WIDTH: 0.417042
G1 F12000
G1 X117.006 Y133.377 E.02694
G1 X116.842 Y133.465 E.00566
G1 X116.802 Y133.764 E.00919
G1 X111.198 Y133.764 E.17087
G1 X111.158 Y133.465 E.00919
G1 X111.009 Y133.392 E.00505
G3 X110.968 Y132.101 I157.134 J-5.662 E.03937
G1 X111.371 Y132.579 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X111.371 Y133.192 E.01883
G1 X111.455 Y133.233 E.00287
G1 X111.508 Y133.387 E.00499
G1 X116.492 Y133.387 E.15314
G1 X116.545 Y133.233 E.00499
G1 X116.629 Y133.192 E.00287
G1 X116.629 Y132.579 E.01883
G1 X111.431 Y132.579 E.1597
G1 X116.225 Y132.983 F30000
; LINE_WIDTH: 0.47314
G1 F12000
G1 X111.835 Y132.983 E.15391
G1 X117.035 Y129.232 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X117.035 Y131.981 E.07617
; Slow Down End
G1 X110.994 Y128.022 F30000
; LINE_WIDTH: 0.419686
G1 F12000
G1 X110.994 Y127 E.03137
G1 X117.006 Y127 E.18457
G2 X117.016 Y128.432 I29.577 J.511 E.04397
; Slow Down Start
; LINE_WIDTH: 0.414126
G1 F3000;_EXTRUDE_SET_SPEED
G1 X117.035 Y129.232 E.02421
G1 X116.876 Y129.047 E.00739
G2 X111.124 Y129.047 I-2.876 J1284.315 E.17399
G1 X110.965 Y129.232 E.00739
G2 X110.993 Y128.432 I-5.099 J-.578 E.02424
; Slow Down End
; LINE_WIDTH: 0.419052
G1 F12000
G1 X110.994 Y128.082 E.01073
G1 X116.629 Y128.022 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X116.629 Y127.377 E.01981
G1 X111.371 Y127.377 E.16155
G1 X111.371 Y128.666 E.03962
G1 X116.629 Y128.666 E.16155
G1 X116.629 Y128.082 E.01797
G1 X116.212 Y128.022 F30000
; LINE_WIDTH: 0.49912
G1 F12000
G1 X116.212 Y127.794 E.00848
G1 X111.788 Y127.794 E.16447
G1 X111.788 Y128.25 E.01696
G1 X116.212 Y128.25 E.16447
G1 X116.212 Y128.082 E.00625
G1 X112.886 Y131.81 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X114.514 Y131.81 E.05401
G1 X116.673 Y129.652 E.10127
G1 X116.673 Y130.024 E.01237
G1 X116.084 Y129.435 E.02763
G1 X114.455 Y129.435 E.05401
G1 X117.194 Y133.879 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.18942
G1 F15000
G1 X124.805 Y133.879 E.09086
G1 X110.805 Y133.879 F30000
G1 F15000
G1 X103.194 Y133.879 E.09086
G1 X101.478 Y131.81 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.673 Y131.81 E.03962
G1 X102.673 Y131.376 E.01439
G1 X100.732 Y129.435 E.09105
G1 X101.537 Y129.435 E.02671
G1 X99.162 Y131.81 E.1114
G1 X97.534 Y131.81 E.05401
G1 X96.966 Y132.041 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X96.965 Y129.292 E.07617
; Slow Down End
G1 X97.124 Y132.197 F30000
; Slow Down Start
; LINE_WIDTH: 0.414358
G1 F3000;_EXTRUDE_SET_SPEED
G2 X102.876 Y132.197 I2.874 J-851.8 E.1741
G1 X103.034 Y132.041 E.00672
G2 X103.01 Y132.493 I2.991 J.385 E.01371
; Slow Down End
; LINE_WIDTH: 0.416533
G1 F12000
G1 X103.006 Y133.377 E.02691
G1 X102.842 Y133.465 E.00565
G1 X102.802 Y133.764 E.00918
G1 X97.198 Y133.764 E.17064
G1 X97.158 Y133.465 E.00918
G1 X97.009 Y133.392 E.00504
G3 X96.966 Y132.041 I165.046 J-5.93 E.04114
G1 X97.081 Y132.155 E.00493
G1 X97.371 Y132.579 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X97.371 Y133.192 E.01883
G1 X97.455 Y133.233 E.00287
G1 X97.508 Y133.387 E.00499
G1 X102.492 Y133.387 E.15314
G1 X102.545 Y133.233 E.00499
G1 X102.629 Y133.192 E.00287
G1 X102.629 Y132.579 E.01883
G1 X97.431 Y132.579 E.1597
G1 X102.225 Y132.983 F30000
; LINE_WIDTH: 0.47314
G1 F12000
G1 X97.835 Y132.983 E.15391
G1 X103.035 Y129.232 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X103.035 Y131.981 E.07617
; Slow Down End
G1 X96.994 Y128.022 F30000
; LINE_WIDTH: 0.419686
G1 F12000
G1 X96.994 Y127 E.03137
G1 X103.006 Y127 E.18457
G2 X103.016 Y128.432 I29.577 J.511 E.04397
; Slow Down Start
; LINE_WIDTH: 0.414126
G1 F3000;_EXTRUDE_SET_SPEED
G1 X103.035 Y129.232 E.02421
G1 X102.876 Y129.047 E.00739
G2 X97.124 Y129.047 I-2.876 J1284.315 E.17399
G1 X96.965 Y129.232 E.00739
G2 X96.993 Y128.432 I-5.099 J-.578 E.02424
; Slow Down End
; LINE_WIDTH: 0.419052
G1 F12000
G1 X96.994 Y128.082 E.01073
G1 X102.629 Y128.022 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X102.629 Y127.377 E.01981
G1 X97.371 Y127.377 E.16155
G1 X97.371 Y128.666 E.03962
G1 X102.629 Y128.666 E.16155
G1 X102.629 Y128.082 E.01797
G1 X102.212 Y128.022 F30000
; LINE_WIDTH: 0.49912
G1 F12000
G1 X102.212 Y127.794 E.00848
G1 X97.788 Y127.794 E.16447
G1 X97.788 Y128.25 E.01696
G1 X102.212 Y128.25 E.16447
G1 X102.212 Y128.082 E.00625
; WIPE_START
G1 X102.212 Y128.25 E-.06388
G1 X100.38 Y128.25 E-.69612
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y125.846 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X102.884 Y125.147 E.03035
G1 X102.351 Y125.147
G1 X103.583 Y126.379 E.05353
G1 X103.056 Y126.385
G1 X101.818 Y125.147 E.05379
G1 X101.284 Y125.147
G1 X102.522 Y126.385 E.05379
G1 X101.989 Y126.385
M73 P90 R2
G1 X100.751 Y125.147 E.05379
G1 X100.218 Y125.147
G1 X101.456 Y126.385 E.05379
G1 X100.922 Y126.385
G1 X99.685 Y125.147 E.05379
G1 X99.151 Y125.147
G1 X100.389 Y126.385 E.05379
G1 X99.856 Y126.385
G1 X98.618 Y125.147 E.05379
G1 X98.085 Y125.147
G1 X99.323 Y126.385 E.05379
G1 X98.789 Y126.385
G1 X97.552 Y125.147 E.05379
G1 X97.018 Y125.147
G1 X98.256 Y126.385 E.05379
G1 X97.723 Y126.385
G1 X96.485 Y125.147 E.05379
G1 X96.417 Y125.613
G1 X97.19 Y126.385 E.03356
; WIPE_START
M204 S10000
G1 X96.417 Y125.613 E-.41503
G1 X96.485 Y125.147 E-.17879
G1 X96.794 Y125.457 E-.16619
; WIPE_END
G1 E-.04 F1800
G1 X96.804 Y133.089 Z5.4 F30000
G1 X96.805 Y133.879 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.18942
G1 F15000
G1 X89.194 Y133.879 E.09086
G1 X89.05 Y131.477 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.05 Y131.81 E.01105
G1 X87.754 Y131.81 E.04296
G1 X86.18 Y130.235 E.07388
G1 X85.385 Y130.235 E.02637
G1 X83.81 Y131.81 E.07387
G1 X80.079 Y131.81 E.12378
G1 X78.504 Y130.235 E.07388
G1 X77.709 Y130.235 E.02637
G1 X76.134 Y131.81 E.07388
G1 X74.506 Y131.81 E.05401
G1 X72.994 Y133.764 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.802 Y133.764 E.48573
G1 X88.842 Y133.465 E.00927
G1 X89.006 Y133.377 E.0057
G1 X89.006 Y132.202 E.0361
G1 X72.994 Y132.202 E.49198
G1 X72.994 Y133.704 E.04613
G1 X73.371 Y133.387 F30000
G1 F12000
G1 X88.492 Y133.387 E.46461
G1 X88.545 Y133.233 E.00499
G1 X88.629 Y133.192 E.00287
G1 X88.629 Y132.579 E.01883
G1 X73.371 Y132.579 E.46881
G1 X73.371 Y133.327 E.02296
G1 X73.775 Y132.983 F30000
; LINE_WIDTH: 0.47313
G1 F12000
G1 X88.165 Y132.983 E.50448
G1 X89.006 Y128.422 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.006 Y127 E.04369
G1 X72.994 Y127 E.49198
G1 X72.994 Y129.843 E.08737
G1 X89.006 Y129.843 E.49198
G1 X89.006 Y128.482 E.04184
G1 X88.629 Y128.422 F30000
G1 F12000
G1 X88.629 Y127.377 E.0321
G1 X73.371 Y127.377 E.46881
G1 X73.371 Y129.466 E.0642
G1 X88.629 Y129.466 E.46881
G1 X88.629 Y128.482 E.03026
G1 X88.252 Y128.422 F30000
G1 F12000
G1 X88.252 Y127.754 E.02052
G1 X73.748 Y127.754 E.44564
G1 X73.748 Y129.089 E.04103
G1 X88.252 Y129.089 E.44564
G1 X88.252 Y128.482 E.01867
G1 X87.824 Y128.422 F30000
; LINE_WIDTH: 0.52205
G1 F12000
G1 X87.824 Y128.182 E.00935
G1 X74.176 Y128.182 E.53283
G1 X74.176 Y128.661 E.01871
G1 X87.824 Y128.661 E.53283
G1 X87.824 Y128.482 E.00701
; WIPE_START
G1 X87.824 Y128.661 E-.06824
G1 X86.003 Y128.661 E-.69176
; WIPE_END
G1 E-.04 F1800
G1 X89.583 Y125.711 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.019 Y125.147 E.02447
G1 X88.486 Y125.147
G1 X89.583 Y126.244 E.04765
G1 X89.191 Y126.385
G1 X87.953 Y125.147 E.05379
G1 X87.42 Y125.147
G1 X88.658 Y126.385 E.05379
G1 X88.124 Y126.385
G1 X86.886 Y125.147 E.05379
G1 X86.353 Y125.147
G1 X87.591 Y126.385 E.05379
G1 X87.058 Y126.385
G1 X85.82 Y125.147 E.05379
G1 X85.287 Y125.147
G1 X86.525 Y126.385 E.05379
G1 X85.991 Y126.385
G1 X84.753 Y125.147 E.05379
G1 X84.22 Y125.147
G1 X85.458 Y126.385 E.05379
G1 X84.925 Y126.385
G1 X83.687 Y125.147 E.05379
G1 X83.154 Y125.147
G1 X84.391 Y126.385 E.05379
G1 X83.858 Y126.385
G1 X82.62 Y125.147 E.05379
G1 X82.087 Y125.147
G1 X83.325 Y126.385 E.05379
G1 X82.792 Y126.385
G1 X81.554 Y125.147 E.05379
G1 X81.021 Y125.147
G1 X82.258 Y126.385 E.05379
G1 X81.725 Y126.385
G1 X80.487 Y125.147 E.05379
G1 X79.954 Y125.147
G1 X81.192 Y126.385 E.05379
G1 X80.659 Y126.385
G1 X79.421 Y125.147 E.05379
G1 X78.888 Y125.147
G1 X80.125 Y126.385 E.05379
G1 X79.592 Y126.385
G1 X78.354 Y125.147 E.05379
G1 X77.821 Y125.147
G1 X79.059 Y126.385 E.05379
G1 X78.526 Y126.385
G1 X77.288 Y125.147 E.05379
G1 X76.755 Y125.147
G1 X77.992 Y126.385 E.05379
G1 X77.459 Y126.385
G1 X76.221 Y125.147 E.05379
G1 X75.688 Y125.147
G1 X76.926 Y126.385 E.05379
G1 X76.393 Y126.385
G1 X75.155 Y125.147 E.05379
G1 X74.621 Y125.147
G1 X75.859 Y126.385 E.05379
G1 X75.326 Y126.385
G1 X74.088 Y125.147 E.05379
G1 X73.555 Y125.147
G1 X74.793 Y126.385 E.05379
G1 X74.26 Y126.385
G1 X73.022 Y125.147 E.05379
G1 X72.488 Y125.147
G1 X73.726 Y126.385 E.05379
G1 X73.193 Y126.385
G1 X72.417 Y125.61 E.03371
; WIPE_START
M204 S10000
G1 X73.193 Y126.385 E-.41686
G1 X73.726 Y126.385 E-.20264
G1 X73.465 Y126.124 E-.1405
; WIPE_END
G1 E-.04 F1800
G1 X81.066 Y126.811 Z5.4 F30000
G1 X138.966 Y132.041 Z5.4
G1 Z5
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X138.965 Y129.292 E.07617
; Slow Down End
G1 X144.225 Y132.202 F30000
; Slow Down Start
; LINE_WIDTH: 0.40502
G1 F3000;_EXTRUDE_SET_SPEED
G1 X144.876 Y132.197 E.0192
G1 X145.034 Y132.041 E.00655
G2 X145.01 Y132.493 I2.991 J.385 E.01337
; Slow Down End
; LINE_WIDTH: 0.41687
G1 F12000
G1 X145.006 Y133.377 E.02693
G1 X144.842 Y133.465 E.00566
G1 X144.802 Y133.764 E.00919
G1 X139.198 Y133.764 E.17079
G1 X139.158 Y133.465 E.00919
G1 X139.009 Y133.392 E.00504
G3 X138.966 Y132.041 I163.254 J-5.875 E.04118
; Slow Down Start
; LINE_WIDTH: 0.412886
G1 F3000;_EXTRUDE_SET_SPEED
G1 X139.124 Y132.197 E.00669
G1 X139.775 Y132.202 E.01962
; Slow Down End
; LINE_WIDTH: 0.41999
G1 F12000
G1 X144.165 Y132.202 E.1349
G1 X144.629 Y132.579 F30000
G1 F12000
G1 X139.371 Y132.579 E.16155
G1 X139.371 Y133.192 E.01883
G1 X139.455 Y133.233 E.00287
G1 X139.508 Y133.387 E.00499
G1 X144.492 Y133.387 E.15314
G1 X144.545 Y133.233 E.00499
G1 X144.629 Y133.192 E.00287
G1 X144.629 Y132.639 E.01698
G1 X144.225 Y132.983 F30000
; LINE_WIDTH: 0.47313
G1 F12000
G1 X139.835 Y132.983 E.15391
G1 X145.035 Y129.232 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X145.035 Y131.981 E.07617
; Slow Down End
G1 X138.994 Y128.022 F30000
; LINE_WIDTH: 0.419686
G1 F12000
G1 X138.994 Y127 E.03137
G1 X145.006 Y127 E.18457
G2 X145.016 Y128.432 I29.577 J.511 E.04397
; Slow Down Start
; LINE_WIDTH: 0.414126
G1 F3000;_EXTRUDE_SET_SPEED
G1 X145.035 Y129.232 E.02421
G1 X144.876 Y129.047 E.00739
G2 X139.124 Y129.047 I-2.876 J1284.315 E.17399
G1 X138.965 Y129.232 E.00739
G2 X138.993 Y128.432 I-5.101 J-.578 E.02424
; Slow Down End
; LINE_WIDTH: 0.419052
G1 F12000
G1 X138.994 Y128.082 E.01073
G1 X144.629 Y128.022 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X144.629 Y127.377 E.01981
G1 X139.371 Y127.377 E.16155
G1 X139.371 Y128.666 E.03962
G1 X144.629 Y128.666 E.16155
G1 X144.629 Y128.082 E.01797
G1 X144.212 Y128.022 F30000
; LINE_WIDTH: 0.49912
G1 F12000
G1 X144.212 Y127.794 E.00848
G1 X139.788 Y127.794 E.16447
G1 X139.788 Y128.25 E.01696
G1 X144.212 Y128.25 E.16447
G1 X144.212 Y128.082 E.00625
; WIPE_START
G1 X144.212 Y128.25 E-.06388
G1 X142.38 Y128.25 E-.69612
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y125.719 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.011 Y125.147 E.02482
G1 X144.478 Y125.147
G1 X145.583 Y126.252 E.04799
G1 X145.183 Y126.385
G1 X143.945 Y125.147 E.05379
G1 X143.412 Y125.147
G1 X144.65 Y126.385 E.05379
G1 X144.116 Y126.385
G1 X142.878 Y125.147 E.05379
G1 X142.345 Y125.147
G1 X143.583 Y126.385 E.05379
G1 X143.05 Y126.385
G1 X141.812 Y125.147 E.05379
G1 X141.279 Y125.147
G1 X142.517 Y126.385 E.05379
G1 X141.983 Y126.385
G1 X140.745 Y125.147 E.05379
G1 X140.212 Y125.147
G1 X141.45 Y126.385 E.05379
G1 X140.917 Y126.385
G1 X139.679 Y125.147 E.05379
G1 X139.146 Y125.147
G1 X140.384 Y126.385 E.05379
G1 X139.85 Y126.385
G1 X138.612 Y125.147 E.05379
G1 X138.417 Y125.486
G1 X139.317 Y126.385 E.03909
G1 X138.784 Y126.385
G1 X138.417 Y126.019 E.01592
; WIPE_START
M204 S10000
G1 X138.784 Y126.385 E-.19689
G1 X139.317 Y126.385 E-.20264
G1 X138.646 Y125.715 E-.36048
; WIPE_END
G1 E-.04 F1800
G1 X141.545 Y129.435 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X139.916 Y129.435 E.05401
G1 X139.328 Y130.024 E.02763
G1 X139.328 Y129.652 E.01237
G1 X141.486 Y131.81 E.10127
G1 X143.114 Y131.81 E.05401
G1 X145.195 Y133.879 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.18942
G1 F15000
G1 X152.806 Y133.879 E.09086
G1 X152.966 Y132.041 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X152.965 Y129.292 E.07617
; Slow Down End
G1 X159.006 Y133.377 F30000
; LINE_WIDTH: 0.416824
G1 F12000
G1 X158.842 Y133.465 E.00566
G1 X158.802 Y133.764 E.00919
G1 X153.198 Y133.764 E.17077
G1 X153.158 Y133.465 E.00919
G1 X153.009 Y133.392 E.00504
G3 X152.966 Y132.041 I163.254 J-5.875 E.04117
; Slow Down Start
; LINE_WIDTH: 0.413928
G1 F3000;_EXTRUDE_SET_SPEED
G1 X153.124 Y132.197 E.00671
G2 X158.876 Y132.197 I2.874 J-851.8 E.17389
G1 X159.034 Y132.041 E.00671
G2 X159.01 Y132.493 I2.991 J.385 E.0137
; Slow Down End
; LINE_WIDTH: 0.41728
G1 F12000
G1 X159.006 Y133.317 E.02513
G1 X158.629 Y133.192 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X158.629 Y132.579 E.01882
G1 X153.371 Y132.579 E.16155
G1 X153.371 Y133.192 E.01883
G1 X153.455 Y133.233 E.00287
G1 X153.508 Y133.387 E.00499
G1 X158.492 Y133.387 E.15314
G1 X158.545 Y133.233 E.00499
G1 X158.575 Y133.218 E.00103
G1 X158.225 Y132.983 F30000
; LINE_WIDTH: 0.47313
G1 F12000
G1 X153.835 Y132.983 E.15391
G1 X159.035 Y129.232 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X159.035 Y131.981 E.07617
; Slow Down End
G1 X152.994 Y128.022 F30000
; LINE_WIDTH: 0.419686
G1 F12000
G1 X152.994 Y127 E.03137
G1 X159.006 Y127 E.18457
G2 X159.016 Y128.432 I29.577 J.511 E.04397
; Slow Down Start
; LINE_WIDTH: 0.414126
G1 F3000;_EXTRUDE_SET_SPEED
G1 X159.035 Y129.232 E.02421
G1 X158.876 Y129.047 E.00739
G2 X153.124 Y129.047 I-2.876 J1284.315 E.17399
G1 X152.965 Y129.232 E.00739
G2 X152.993 Y128.432 I-5.101 J-.578 E.02424
; Slow Down End
; LINE_WIDTH: 0.419052
G1 F12000
G1 X152.994 Y128.082 E.01073
G1 X158.629 Y128.022 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X158.629 Y127.377 E.01981
G1 X153.371 Y127.377 E.16155
G1 X153.371 Y128.666 E.03962
G1 X158.629 Y128.666 E.16155
G1 X158.629 Y128.082 E.01797
G1 X158.212 Y128.022 F30000
; LINE_WIDTH: 0.49912
G1 F12000
G1 X158.212 Y127.794 E.00848
G1 X153.788 Y127.794 E.16447
G1 X153.788 Y128.25 E.01696
G1 X158.212 Y128.25 E.16447
G1 X158.212 Y128.082 E.00625
; WIPE_START
G1 X158.212 Y128.25 E-.06388
G1 X156.38 Y128.25 E-.69612
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y125.854 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X158.876 Y125.147 E.0307
G1 X158.343 Y125.147
G1 X159.581 Y126.385 E.05379
G1 X159.048 Y126.385
G1 X157.81 Y125.147 E.05379
G1 X157.276 Y125.147
G1 X158.514 Y126.385 E.05379
G1 X157.981 Y126.385
G1 X156.743 Y125.147 E.05379
G1 X156.21 Y125.147
G1 X157.448 Y126.385 E.05379
G1 X156.915 Y126.385
G1 X155.677 Y125.147 E.05379
G1 X155.143 Y125.147
G1 X156.381 Y126.385 E.05379
G1 X155.848 Y126.385
G1 X154.61 Y125.147 E.05379
G1 X154.077 Y125.147
G1 X155.315 Y126.385 E.05379
G1 X154.781 Y126.385
G1 X153.544 Y125.147 E.05379
G1 X153.01 Y125.147
G1 X154.248 Y126.385 E.05379
G1 X153.715 Y126.385
G1 X152.477 Y125.147 E.05379
G1 X152.417 Y125.621
G1 X153.182 Y126.385 E.03321
; WIPE_START
M204 S10000
G1 X152.417 Y125.621 E-.41074
G1 X152.477 Y125.147 E-.18138
G1 X152.789 Y125.46 E-.16788
; WIPE_END
G1 E-.04 F1800
G1 X157.876 Y131.15 Z5.4 F30000
G1 X158.466 Y131.81 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X156.838 Y131.81 E.05401
G1 X154.463 Y129.435 E.1114
G1 X155.268 Y129.435 E.02671
G1 X153.328 Y131.376 E.09105
G1 X153.328 Y131.81 E.01439
G1 X154.522 Y131.81 E.03962
G1 X159.195 Y133.879 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.18942
G1 F15000
G1 X166.806 Y133.879 E.09086
G1 X166.994 Y132.202 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X166.994 Y133.392 E.03656
G1 X167.158 Y133.465 E.0055
G1 X167.198 Y133.764 E.00927
G1 X183.006 Y133.764 E.48573
G1 X183.006 Y132.202 E.04798
G1 X167.054 Y132.202 E.49014
G1 X167.371 Y132.579 F30000
G1 F12000
G1 X167.371 Y133.192 E.01882
G1 X167.455 Y133.233 E.00287
G1 X167.508 Y133.387 E.00499
G1 X182.629 Y133.387 E.46461
G1 X182.629 Y132.579 E.0248
G1 X167.431 Y132.579 E.46697
G1 X167.775 Y132.983 F30000
; LINE_WIDTH: 0.47312
G1 F12000
G1 X182.165 Y132.983 E.50446
G1 X181.494 Y131.81 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.866 Y131.81 E.05401
G1 X178.291 Y130.235 E.07388
G1 X177.496 Y130.235 E.02637
G1 X175.921 Y131.81 E.07388
G1 X172.19 Y131.81 E.12378
G1 X170.615 Y130.235 E.07387
G1 X169.82 Y130.235 E.02637
G1 X168.246 Y131.81 E.07388
G1 X166.95 Y131.81 E.04296
G1 X166.95 Y131.477 E.01105
G1 X183.006 Y128.422 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X183.006 Y127 E.04369
G1 X166.994 Y127 E.49198
G1 X166.994 Y129.843 E.08737
G1 X183.006 Y129.843 E.49198
G1 X183.006 Y128.482 E.04184
G1 X182.629 Y128.422 F30000
G1 F12000
G1 X182.629 Y127.377 E.0321
G1 X167.371 Y127.377 E.46881
G1 X167.371 Y129.466 E.0642
G1 X182.629 Y129.466 E.46881
G1 X182.629 Y128.482 E.03026
G1 X182.252 Y128.422 F30000
G1 F12000
G1 X182.252 Y127.754 E.02052
G1 X167.748 Y127.754 E.44564
G1 X167.748 Y129.089 E.04103
G1 X182.252 Y129.089 E.44564
G1 X182.252 Y128.482 E.01867
G1 X181.824 Y128.422 F30000
; LINE_WIDTH: 0.52205
G1 F12000
G1 X181.824 Y128.182 E.00935
G1 X168.176 Y128.182 E.53283
G1 X168.176 Y128.661 E.01871
G1 X181.824 Y128.661 E.53283
G1 X181.824 Y128.482 E.00701
; WIPE_START
G1 X181.824 Y128.661 E-.06824
G1 X180.003 Y128.661 E-.69176
; WIPE_END
G1 E-.04 F1800
G1 X183.583 Y125.857 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X182.873 Y125.147 E.03085
G1 X182.339 Y125.147
G1 X183.577 Y126.385 E.05379
G1 X183.044 Y126.385
G1 X181.806 Y125.147 E.05379
G1 X181.273 Y125.147
G1 X182.511 Y126.385 E.05379
G1 X181.978 Y126.385
G1 X180.74 Y125.147 E.05379
G1 X180.206 Y125.147
G1 X181.444 Y126.385 E.05379
G1 X180.911 Y126.385
G1 X179.673 Y125.147 E.05379
G1 X179.14 Y125.147
G1 X180.378 Y126.385 E.05379
G1 X179.845 Y126.385
G1 X178.607 Y125.147 E.05379
G1 X178.073 Y125.147
G1 X179.311 Y126.385 E.05379
G1 X178.778 Y126.385
G1 X177.54 Y125.147 E.05379
G1 X177.007 Y125.147
G1 X178.245 Y126.385 E.05379
G1 X177.712 Y126.385
G1 X176.474 Y125.147 E.05379
G1 X175.94 Y125.147
G1 X177.178 Y126.385 E.05379
G1 X176.645 Y126.385
G1 X175.407 Y125.147 E.05379
G1 X174.874 Y125.147
G1 X176.112 Y126.385 E.05379
G1 X175.579 Y126.385
G1 X174.341 Y125.147 E.05379
G1 X173.807 Y125.147
G1 X175.045 Y126.385 E.05379
G1 X174.512 Y126.385
G1 X173.274 Y125.147 E.05379
G1 X172.741 Y125.147
G1 X173.979 Y126.385 E.05379
G1 X173.446 Y126.385
G1 X172.208 Y125.147 E.05379
G1 X171.674 Y125.147
G1 X172.912 Y126.385 E.05379
G1 X172.379 Y126.385
G1 X171.141 Y125.147 E.05379
G1 X170.608 Y125.147
G1 X171.846 Y126.385 E.05379
G1 X171.312 Y126.385
G1 X170.075 Y125.147 E.05379
G1 X169.541 Y125.147
G1 X170.779 Y126.385 E.05379
G1 X170.246 Y126.385
G1 X169.008 Y125.147 E.05379
G1 X168.475 Y125.147
G1 X169.713 Y126.385 E.05379
G1 X169.179 Y126.385
G1 X167.942 Y125.147 E.05379
G1 X167.408 Y125.147
G1 X168.646 Y126.385 E.05379
G1 X168.113 Y126.385
G1 X166.875 Y125.147 E.05379
G1 X166.417 Y125.223
G1 X167.58 Y126.385 E.05051
G1 X167.046 Y126.385
G1 X166.417 Y125.756 E.02733
; CHANGE_LAYER
; Z_HEIGHT: 5.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
M204 S10000
G1 X167.046 Y126.385 E-.33803
G1 X167.58 Y126.385 E-.20264
G1 X167.172 Y125.977 E-.21933
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 26/32
; update layer progress
M73 L26
M991 S0 P25 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.4 I-.256 J-1.19 P1  F30000
G1 X131.398 Y133.676 Z5.4
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.602 Y133.676 E.22543
G1 X124.602 Y127.408 E.20793
G1 X131.398 Y127.408 E.22543
G1 X131.398 Y133.616 E.20594
; WIPE_START
G1 X129.398 Y133.634 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X137.03 Y133.608 Z5.6 F30000
G1 X138.602 Y133.602 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F15476.087
G1 X138.602 Y127.408 E.20548
G1 X145.398 Y127.408 E.22543
G1 X145.398 Y133.676 E.20793
G1 X138.602 Y133.676 E.22543
G1 X138.602 Y133.662 E.00047
; WIPE_START
G1 X138.602 Y131.662 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X146.157 Y132.749 Z5.6 F30000
G1 X152.602 Y133.676 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F15476.087
G1 X152.602 Y127.408 E.20793
G1 X159.398 Y127.408 E.22543
G1 X159.398 Y133.676 E.20793
G1 X152.662 Y133.676 E.22344
; WIPE_START
G1 X152.643 Y131.676 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X160.198 Y132.759 Z5.6 F30000
G1 X166.602 Y133.676 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F15476.087
G1 X166.602 Y127.408 E.20793
G1 X183.398 Y127.408 E.55715
G1 X183.398 Y133.676 E.20793
G1 X166.662 Y133.676 E.55516
; WIPE_START
G1 X166.643 Y131.676 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.017 Y131.986 Z5.6 F30000
G1 X117.398 Y133.676 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F15476.087
G1 X110.602 Y133.676 E.22543
G1 X110.602 Y127.408 E.20793
G1 X117.398 Y127.408 E.22543
G1 X117.398 Y133.616 E.20594
; WIPE_START
G1 X115.398 Y133.634 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.766 Y133.661 Z5.6 F30000
G1 X103.398 Y133.676 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F15476.087
G1 X96.602 Y133.676 E.22543
G1 X96.602 Y127.408 E.20793
G1 X103.398 Y127.408 E.22543
G1 X103.398 Y133.616 E.20594
; WIPE_START
G1 X101.398 Y133.634 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X93.766 Y133.661 Z5.6 F30000
M73 P91 R2
G1 X89.398 Y133.676 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F15476.087
G1 X72.602 Y133.676 E.55715
G1 X72.602 Y127.408 E.20793
G1 X89.398 Y127.408 E.55715
G1 X89.398 Y133.616 E.20594
; WIPE_START
G1 X87.398 Y133.623 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X95.03 Y133.561 Z5.6 F30000
G1 X138.21 Y133.21 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y125.74 E.22953
G1 X145.79 Y125.74 E.23291
G1 X145.79 Y133.21 E.22953
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y125.74 E.22953
G1 X159.79 Y125.74 E.23291
G1 X159.79 Y133.21 E.22953
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y125.74 E.22953
G1 X183.79 Y125.74 E.54018
G1 X183.79 Y134.068 E.2559
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y134.068 E3.42854
G1 X72.21 Y125.74 E.2559
G1 X89.79 Y125.74 E.54018
G1 X89.79 Y133.21 E.22953
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y125.74 E.22953
G1 X103.79 Y125.74 E.23291
G1 X103.79 Y133.21 E.22953
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y125.74 E.22953
G1 X117.79 Y125.74 E.23291
G1 X117.79 Y133.21 E.22953
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y125.74 E.22953
G1 X131.79 Y125.74 E.23291
G1 X131.79 Y133.21 E.22953
G1 X138.15 Y133.21 E.19542
M204 S10000
G1 X138.406 Y133.639 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.50911
G1 F13513.804
G1 X131.594 Y133.639 E.25877
; WIPE_START
G1 X133.594 Y133.639 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.278 Y132.666 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42016
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X131.028 Y131.917 E.05991
G1 X131.028 Y131.252 E.03756
G1 X129.816 Y132.464 E.09685
G1 X129.151 Y132.464 E.03756
G1 X131.028 Y130.587 E.14997
G1 X131.028 Y129.922 E.03756
G1 X128.486 Y132.464 E.20309
G1 X127.821 Y132.464 E.03756
G1 X131.028 Y129.257 E.25621
G1 X131.028 Y128.782 E.02684
G1 X130.838 Y128.782 E.01072
G1 X127.156 Y132.464 E.29417
G1 X126.491 Y132.464 E.03756
G1 X130.174 Y128.782 E.29417
G1 X129.509 Y128.782 E.03756
G1 X125.826 Y132.464 E.29417
G1 X125.162 Y132.464 E.03756
G1 X128.844 Y128.782 E.29417
G1 X128.179 Y128.782 E.03756
G1 X124.972 Y131.989 E.25621
G1 X124.972 Y131.324 E.03756
G1 X127.514 Y128.782 E.20309
G1 X126.849 Y128.782 E.03756
G1 X124.972 Y130.659 E.14997
G1 X124.972 Y129.994 E.03756
G1 X126.184 Y128.782 E.09685
G1 X125.519 Y128.782 E.03756
G1 X124.769 Y129.532 E.05991
G1 X125.042 Y127.848 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.51561
; LAYER_HEIGHT: 0.2
G1 F13327.975
G1 X125.042 Y128.32 E.01821
G1 X130.958 Y128.32 E.22788
G1 X130.958 Y127.848 E.01821
G1 X125.102 Y127.848 E.22557
G1 X125.002 Y132.885 F30000
; LINE_WIDTH: 0.43479
G1 F15000
G1 X125.002 Y133.277 E.01251
G1 X130.998 Y133.277 E.1915
G1 X130.998 Y132.885 E.01251
G1 X125.062 Y132.885 E.18958
G1 X124.406 Y133.639 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.50911
G1 F13513.804
G1 X117.594 Y133.639 E.25877
G1 X116.998 Y132.885 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43479
G1 F15000
G1 X111.002 Y132.885 E.1915
G1 X111.002 Y133.277 E.01251
G1 X116.998 Y133.277 E.1915
G1 X116.998 Y132.945 E.0106
G1 X115.541 Y132.666 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40054
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X117.028 Y132.051 E.08262
G1 X117.028 Y131.563 E.02504
G1 X114.853 Y132.464 E.12087
G1 X113.676 Y132.464 E.06044
G1 X117.028 Y131.075 E.18629
G1 X117.028 Y130.588 E.02504
G1 X112.498 Y132.464 E.25172
G1 X111.321 Y132.464 E.06044
G1 X117.028 Y130.1 E.31714
G1 X117.028 Y129.612 E.02504
G1 X110.972 Y132.121 E.33654
G1 X110.972 Y131.633 E.02504
G1 X117.028 Y129.125 E.33654
G1 X117.028 Y128.782 E.0176
G1 X116.679 Y128.782 E.01794
G1 X110.972 Y131.146 E.31713
G1 X110.972 Y130.658 E.02504
G1 X115.501 Y128.782 E.2517
G1 X114.324 Y128.782 E.06044
G1 X110.972 Y130.17 E.18628
G1 X110.972 Y129.683 E.02504
G1 X113.147 Y128.782 E.12086
G1 X111.969 Y128.782 E.06044
G1 X110.769 Y129.279 E.06669
; WIPE_START
G1 X111.969 Y128.782 E-.49364
G1 X112.67 Y128.782 E-.26636
; WIPE_END
G1 E-.04 F1800
G1 X110.406 Y133.639 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.50911
; LAYER_HEIGHT: 0.2
G1 F13513.804
G1 X103.594 Y133.639 E.25877
G1 X102.998 Y132.885 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43479
G1 F15000
G1 X97.002 Y132.885 E.1915
G1 X97.002 Y133.277 E.01251
G1 X102.998 Y133.277 E.1915
G1 X102.998 Y132.945 E.0106
G1 X102.278 Y132.666 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42016
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X103.028 Y131.917 E.05991
G1 X103.028 Y131.252 E.03756
G1 X101.816 Y132.464 E.09685
G1 X101.151 Y132.464 E.03756
G1 X103.028 Y130.587 E.14997
G1 X103.028 Y129.922 E.03756
G1 X100.486 Y132.464 E.20309
G1 X99.821 Y132.464 E.03756
G1 X103.028 Y129.257 E.25621
G1 X103.028 Y128.782 E.02684
G1 X102.838 Y128.782 E.01072
G1 X99.156 Y132.464 E.29417
G1 X98.491 Y132.464 E.03756
G1 X102.174 Y128.782 E.29417
G1 X101.509 Y128.782 E.03756
G1 X97.826 Y132.464 E.29417
G1 X97.162 Y132.464 E.03756
G1 X100.844 Y128.782 E.29417
G1 X100.179 Y128.782 E.03756
G1 X96.972 Y131.989 E.25621
G1 X96.972 Y131.324 E.03756
G1 X99.514 Y128.782 E.20309
G1 X98.849 Y128.782 E.03756
G1 X96.972 Y130.659 E.14997
G1 X96.972 Y129.994 E.03756
G1 X98.184 Y128.782 E.09685
G1 X97.519 Y128.782 E.03756
G1 X96.769 Y129.532 E.05991
; WIPE_START
G1 X97.519 Y128.782 E-.403
G1 X98.184 Y128.782 E-.25267
G1 X97.99 Y128.976 E-.10434
; WIPE_END
G1 E-.04 F1800
G1 X96.406 Y133.639 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.50911
; LAYER_HEIGHT: 0.2
G1 F13513.804
G1 X89.594 Y133.639 E.25877
; WIPE_START
G1 X91.594 Y133.639 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.006 Y127.8 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X72.994 Y127.8 E.49198
G1 X72.994 Y133.284 E.16851
G1 X89.006 Y133.284 E.49198
G1 X89.006 Y127.86 E.16667
G1 X88.629 Y128.177 F30000
G1 F12000
G1 X73.371 Y128.177 E.46881
G1 X73.371 Y132.907 E.14534
G1 X88.629 Y132.907 E.46881
G1 X88.629 Y128.237 E.1435
G1 X88.252 Y128.554 F30000
G1 F12000
G1 X73.748 Y128.554 E.44564
G1 X73.748 Y132.53 E.12217
G1 X88.252 Y132.53 E.44564
G1 X88.252 Y128.614 E.12032
G1 X87.875 Y128.931 F30000
G1 F12000
G1 X74.125 Y128.931 E.42247
G1 X74.125 Y132.153 E.099
G1 X87.875 Y132.153 E.42247
G1 X87.875 Y128.991 E.09715
G1 X87.498 Y129.308 F30000
G1 F12000
G1 X74.502 Y129.308 E.3993
G1 X74.502 Y131.776 E.07582
G1 X87.498 Y131.776 E.3993
G1 X87.498 Y129.368 E.07398
G1 X87.121 Y129.685 F30000
G1 F12000
G1 X74.879 Y129.685 E.37612
G1 X74.879 Y131.399 E.05265
G1 X87.121 Y131.399 E.37612
G1 X87.121 Y129.745 E.05081
G1 X86.743 Y131.022 F30000
G1 F12000
G1 X86.743 Y130.062 E.02948
G1 X75.257 Y130.062 E.35295
G1 X75.257 Y131.022 E.02948
G1 X86.683 Y131.022 E.35111
G1 X86.264 Y130.542 F30000
; Slow Down Start
; LINE_WIDTH: 0.62528
G1 F3000;_EXTRUDE_SET_SPEED
G1 X75.796 Y130.542 E.49673
; Slow Down End
; WIPE_START
G1 X77.796 Y130.542 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X85.119 Y128.39 Z5.6 F30000
G1 X89.22 Y127.185 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.583 Y126.823 E.01576
G1 X89.583 Y126.289
G1 X88.687 Y127.185 E.03893
G1 X88.153 Y127.185
G1 X89.391 Y125.947 E.05379
G1 X88.858 Y125.947
G1 X87.62 Y127.185 E.05379
G1 X87.087 Y127.185
G1 X88.325 Y125.947 E.05379
G1 X87.792 Y125.947
G1 X86.554 Y127.185 E.05379
G1 X86.02 Y127.185
G1 X87.258 Y125.947 E.05379
G1 X86.725 Y125.947
G1 X85.487 Y127.185 E.05379
G1 X84.954 Y127.185
G1 X86.192 Y125.947 E.05379
G1 X85.659 Y125.947
G1 X84.421 Y127.185 E.05379
G1 X83.887 Y127.185
G1 X85.125 Y125.947 E.05379
G1 X84.592 Y125.947
G1 X83.354 Y127.185 E.05379
G1 X82.821 Y127.185
G1 X84.059 Y125.947 E.05379
G1 X83.526 Y125.947
G1 X82.288 Y127.185 E.05379
G1 X81.754 Y127.185
G1 X82.992 Y125.947 E.05379
G1 X82.459 Y125.947
G1 X81.221 Y127.185 E.05379
G1 X80.688 Y127.185
G1 X81.926 Y125.947 E.05379
G1 X81.392 Y125.947
G1 X80.155 Y127.185 E.05379
G1 X79.621 Y127.185
G1 X80.859 Y125.947 E.05379
G1 X80.326 Y125.947
G1 X79.088 Y127.185 E.05379
G1 X78.555 Y127.185
G1 X79.793 Y125.947 E.05379
G1 X79.259 Y125.947
G1 X78.022 Y127.185 E.05379
G1 X77.488 Y127.185
G1 X78.726 Y125.947 E.05379
G1 X78.193 Y125.947
G1 X76.955 Y127.185 E.05379
G1 X76.422 Y127.185
G1 X77.66 Y125.947 E.05379
G1 X77.126 Y125.947
G1 X75.889 Y127.185 E.05379
G1 X75.355 Y127.185
G1 X76.593 Y125.947 E.05379
G1 X76.06 Y125.947
G1 X74.822 Y127.185 E.05379
G1 X74.289 Y127.185
G1 X75.527 Y125.947 E.05379
G1 X74.993 Y125.947
G1 X73.755 Y127.185 E.05379
G1 X73.222 Y127.185
G1 X74.46 Y125.947 E.05379
G1 X73.927 Y125.947
G1 X72.689 Y127.185 E.05379
G1 X72.417 Y126.924
G1 X73.394 Y125.947 E.04242
G1 X72.86 Y125.947
G1 X72.417 Y126.39 E.01925
; WIPE_START
M204 S10000
G1 X72.86 Y125.947 E-.23805
G1 X73.394 Y125.947 E-.20264
G1 X72.799 Y126.542 E-.31931
; WIPE_END
G1 E-.04 F1800
G1 X80.431 Y126.415 Z5.6 F30000
G1 X89.557 Y126.263 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.132814
G1 F15000
G1 X89.557 Y125.929 E.00245
; WIPE_START
G1 X89.557 Y126.263 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X97.136 Y127.159 Z5.6 F30000
G1 X102.958 Y127.848 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.51561
G1 F13327.975
G1 X97.042 Y127.848 E.22788
G1 X97.042 Y128.32 E.01821
G1 X102.958 Y128.32 E.22788
G1 X102.958 Y127.908 E.0159
; WIPE_START
G1 X102.958 Y128.32 E-.15683
G1 X101.371 Y128.32 E-.60317
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y126.687 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X103.085 Y127.185 E.02164
G1 X102.551 Y127.185
G1 X103.583 Y126.154 E.04481
G1 X103.256 Y125.947
G1 X102.018 Y127.185 E.05379
G1 X101.485 Y127.185
G1 X102.723 Y125.947 E.05379
G1 X102.19 Y125.947
G1 X100.952 Y127.185 E.05379
G1 X100.418 Y127.185
G1 X101.656 Y125.947 E.05379
G1 X101.123 Y125.947
G1 X99.885 Y127.185 E.05379
G1 X99.352 Y127.185
G1 X100.59 Y125.947 E.05379
G1 X100.056 Y125.947
G1 X98.819 Y127.185 E.05379
G1 X98.285 Y127.185
G1 X99.523 Y125.947 E.05379
G1 X98.99 Y125.947
G1 X97.752 Y127.185 E.05379
G1 X97.219 Y127.185
G1 X98.457 Y125.947 E.05379
G1 X97.923 Y125.947
G1 X96.686 Y127.185 E.05379
G1 X96.417 Y126.92
G1 X97.39 Y125.947 E.04227
G1 X96.857 Y125.947
G1 X96.417 Y126.387 E.0191
; WIPE_START
M204 S10000
G1 X96.857 Y125.947 E-.23622
G1 X97.39 Y125.947 E-.20264
G1 X96.793 Y126.545 E-.32114
; WIPE_END
G1 E-.04 F1800
G1 X104.409 Y127.037 Z5.6 F30000
G1 X116.958 Y127.848 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.51561
G1 F13327.975
G1 X111.042 Y127.848 E.22788
G1 X111.042 Y128.32 E.01821
G1 X116.958 Y128.32 E.22788
G1 X116.958 Y127.908 E.0159
; WIPE_START
G1 X116.958 Y128.32 E-.15683
G1 X115.371 Y128.32 E-.60317
; WIPE_END
G1 E-.04 F1800
G1 X117.583 Y126.552 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X116.949 Y127.185 E.02752
G1 X116.416 Y127.185
G1 X117.583 Y126.019 E.05069
G1 X117.121 Y125.947
G1 X115.883 Y127.185 E.05379
G1 X115.35 Y127.185
G1 X116.587 Y125.947 E.05379
G1 X116.054 Y125.947
G1 X114.816 Y127.185 E.05379
G1 X114.283 Y127.185
G1 X115.521 Y125.947 E.05379
G1 X114.988 Y125.947
G1 X113.75 Y127.185 E.05379
G1 X113.217 Y127.185
G1 X114.454 Y125.947 E.05379
G1 X113.921 Y125.947
G1 X112.683 Y127.185 E.05379
G1 X112.15 Y127.185
G1 X113.388 Y125.947 E.05379
G1 X112.855 Y125.947
G1 X111.617 Y127.185 E.05379
G1 X111.084 Y127.185
G1 X112.321 Y125.947 E.05379
G1 X111.788 Y125.947
G1 X110.55 Y127.185 E.05379
G1 X110.417 Y126.785
G1 X111.255 Y125.947 E.03639
; WIPE_START
M204 S10000
G1 X110.417 Y126.785 E-.45008
G1 X110.55 Y127.185 E-.1603
G1 X110.829 Y126.907 E-.14961
; WIPE_END
G1 E-.04 F1800
G1 X118.46 Y127.013 Z5.6 F30000
G1 X130.814 Y127.185 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X131.583 Y126.417 E.0334
G1 X131.519 Y125.947
G1 X130.281 Y127.185 E.05379
G1 X129.748 Y127.185
G1 X130.985 Y125.947 E.05379
G1 X130.452 Y125.947
G1 X129.214 Y127.185 E.05379
G1 X128.681 Y127.185
G1 X129.919 Y125.947 E.05379
M73 P92 R2
G1 X129.386 Y125.947
G1 X128.148 Y127.185 E.05379
G1 X127.615 Y127.185
G1 X128.852 Y125.947 E.05379
G1 X128.319 Y125.947
G1 X127.081 Y127.185 E.05379
G1 X126.548 Y127.185
G1 X127.786 Y125.947 E.05379
G1 X127.253 Y125.947
G1 X126.015 Y127.185 E.05379
G1 X125.481 Y127.185
G1 X126.719 Y125.947 E.05379
G1 X126.186 Y125.947
G1 X124.948 Y127.185 E.05379
G1 X124.417 Y127.183
G1 X125.653 Y125.947 E.05369
G1 X125.12 Y125.947
G1 X124.417 Y126.65 E.03051
; WIPE_START
M204 S10000
G1 X125.12 Y125.947 E-.37737
G1 X125.653 Y125.947 E-.20264
G1 X125.318 Y126.282 E-.17999
; WIPE_END
G1 E-.04 F1800
G1 X132.901 Y127.147 Z5.6 F30000
G1 X139.042 Y127.848 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.51561
G1 F13327.975
G1 X139.042 Y128.32 E.01821
G1 X144.958 Y128.32 E.22788
G1 X144.958 Y127.848 E.01821
G1 X139.102 Y127.848 E.22557
G1 X139.519 Y128.579 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40298
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X138.972 Y129.526 E.05682
G1 X138.972 Y130.432 E.04708
G1 X139.925 Y128.782 E.09903
G1 X140.448 Y128.782 E.02718
G1 X138.972 Y131.338 E.15339
G1 X138.972 Y132.244 E.04708
G1 X140.971 Y128.782 E.20776
G1 X141.494 Y128.782 E.02718
G1 X139.368 Y132.464 E.22095
G1 X139.891 Y132.464 E.02718
G1 X142.017 Y128.782 E.22095
G1 X142.54 Y128.782 E.02718
G1 X140.414 Y132.464 E.22095
G1 X140.937 Y132.464 E.02718
G1 X143.063 Y128.782 E.22095
G1 X143.586 Y128.782 E.02718
G1 X141.46 Y132.464 E.22095
G1 X141.983 Y132.464 E.02718
G1 X144.109 Y128.782 E.22095
G1 X144.632 Y128.782 E.02718
G1 X142.506 Y132.464 E.22095
G1 X143.029 Y132.464 E.02718
G1 X145.028 Y129.002 E.20775
G1 X145.028 Y129.908 E.04708
G1 X143.552 Y132.464 E.15339
G1 X144.075 Y132.464 E.02718
G1 X145.028 Y130.814 E.09903
G1 X145.028 Y131.72 E.04708
G1 X144.482 Y132.666 E.05681
; WIPE_START
G1 X145.028 Y131.72 E-.41545
G1 X145.028 Y130.814 E-.34426
G1 X145.028 Y130.814 E-.00029
; WIPE_END
G1 E-.04 F1800
G1 X145.594 Y133.639 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.50911
; LAYER_HEIGHT: 0.2
G1 F13513.804
G1 X152.406 Y133.639 E.25877
G1 X153.002 Y132.885 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43479
G1 F15000
G1 X153.002 Y133.277 E.01251
G1 X158.998 Y133.277 E.1915
G1 X158.998 Y132.885 E.01251
G1 X153.062 Y132.885 E.18958
G1 X155.298 Y132.666 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42266
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X159.028 Y132.009 E.21654
G1 X159.028 Y131.529 E.02744
G1 X153.724 Y132.464 E.30788
G1 X152.972 Y132.464 E.04301
G1 X152.972 Y132.117 E.01985
G1 X159.028 Y131.049 E.35156
G1 X159.028 Y130.569 E.02744
G1 X152.972 Y131.637 E.35156
G1 X152.972 Y131.157 E.02744
G1 X159.028 Y130.089 E.35156
G1 X159.028 Y129.609 E.02744
G1 X152.972 Y130.677 E.35156
G1 X152.972 Y130.197 E.02744
G1 X159.028 Y129.129 E.35156
G1 X159.028 Y128.782 E.01985
G1 X158.275 Y128.782 E.04304
G1 X152.972 Y129.717 E.30786
G1 X152.972 Y129.237 E.02744
G1 X156.702 Y128.579 E.21652
; WIPE_START
G1 X154.732 Y128.927 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y126.679 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.2
G1 F12000
M204 S2000
G1 X159.077 Y127.185 E.02198
G1 X158.543 Y127.185
G1 X159.583 Y126.146 E.04516
G1 X159.248 Y125.947
G1 X158.01 Y127.185 E.05379
G1 X157.477 Y127.185
G1 X158.715 Y125.947 E.05379
G1 X158.182 Y125.947
G1 X156.944 Y127.185 E.05379
G1 X156.41 Y127.185
G1 X157.648 Y125.947 E.05379
G1 X157.115 Y125.947
G1 X155.877 Y127.185 E.05379
G1 X155.344 Y127.185
G1 X156.582 Y125.947 E.05379
G1 X156.049 Y125.947
G1 X154.811 Y127.185 E.05379
G1 X154.277 Y127.185
G1 X155.515 Y125.947 E.05379
G1 X154.982 Y125.947
G1 X153.744 Y127.185 E.05379
G1 X153.211 Y127.185
G1 X154.449 Y125.947 E.05379
G1 X153.916 Y125.947
G1 X152.678 Y127.185 E.05379
G1 X152.417 Y126.912
G1 X153.382 Y125.947 E.04193
G1 X152.849 Y125.947
G1 X152.417 Y126.379 E.01876
; WIPE_START
M204 S10000
G1 X152.849 Y125.947 E-.23195
G1 X153.382 Y125.947 E-.20264
G1 X152.777 Y126.553 E-.32542
; WIPE_END
G1 E-.04 F1800
G1 X153.042 Y127.848 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.51561
G1 F13327.975
G1 X153.042 Y128.32 E.01821
G1 X158.958 Y128.32 E.22788
G1 X158.958 Y127.848 E.01821
G1 X153.102 Y127.848 E.22557
; WIPE_START
G1 X155.102 Y127.848 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X147.514 Y127.024 Z5.6 F30000
G1 X145.583 Y126.815 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.212 Y127.185 E.0161
G1 X144.679 Y127.185
G1 X145.583 Y126.281 E.03928
G1 X145.383 Y125.947
G1 X144.145 Y127.185 E.05379
G1 X143.612 Y127.185
G1 X144.85 Y125.947 E.05379
G1 X144.317 Y125.947
G1 X143.079 Y127.185 E.05379
G1 X142.546 Y127.185
G1 X143.784 Y125.947 E.05379
G1 X143.25 Y125.947
G1 X142.012 Y127.185 E.05379
G1 X141.479 Y127.185
G1 X142.717 Y125.947 E.05379
G1 X142.184 Y125.947
G1 X140.946 Y127.185 E.05379
G1 X140.413 Y127.185
G1 X141.651 Y125.947 E.05379
G1 X141.117 Y125.947
G1 X139.879 Y127.185 E.05379
G1 X139.346 Y127.185
G1 X140.584 Y125.947 E.05379
G1 X140.051 Y125.947
G1 X138.813 Y127.185 E.05379
G1 X138.417 Y127.048
G1 X139.518 Y125.947 E.04781
G1 X138.984 Y125.947
G1 X138.417 Y126.514 E.02463
; WIPE_START
M204 S10000
G1 X138.984 Y125.947 E-.30466
G1 X139.518 Y125.947 E-.20264
G1 X139.047 Y126.418 E-.25271
; WIPE_END
G1 E-.04 F1800
G1 X139.002 Y132.885 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43479
G1 F15000
G1 X139.002 Y133.277 E.01251
G1 X144.998 Y133.277 E.1915
G1 X144.998 Y132.885 E.01251
G1 X139.062 Y132.885 E.18958
; WIPE_START
G1 X141.062 Y132.885 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X148.688 Y133.195 Z5.6 F30000
G1 X159.594 Y133.639 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.50911
G1 F13513.804
G1 X166.406 Y133.639 E.25877
; WIPE_START
G1 X164.406 Y133.639 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X171.688 Y131.353 Z5.6 F30000
G1 X183.006 Y127.8 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X166.994 Y127.8 E.49198
G1 X166.994 Y133.284 E.16851
G1 X183.006 Y133.284 E.49198
G1 X183.006 Y127.86 E.16667
G1 X182.629 Y128.177 F30000
G1 F12000
G1 X167.371 Y128.177 E.46881
G1 X167.371 Y132.907 E.14534
G1 X182.629 Y132.907 E.46881
G1 X182.629 Y128.237 E.1435
G1 X182.252 Y128.554 F30000
G1 F12000
G1 X167.748 Y128.554 E.44564
G1 X167.748 Y132.53 E.12217
G1 X182.252 Y132.53 E.44564
G1 X182.252 Y128.614 E.12032
G1 X181.875 Y128.931 F30000
G1 F12000
G1 X168.125 Y128.931 E.42247
G1 X168.125 Y132.153 E.099
G1 X181.875 Y132.153 E.42247
G1 X181.875 Y128.991 E.09715
G1 X181.498 Y129.308 F30000
G1 F12000
G1 X168.502 Y129.308 E.3993
G1 X168.502 Y131.776 E.07582
G1 X181.498 Y131.776 E.3993
G1 X181.498 Y129.368 E.07398
G1 X181.121 Y129.685 F30000
G1 F12000
G1 X168.879 Y129.685 E.37612
G1 X168.879 Y131.399 E.05265
G1 X181.121 Y131.399 E.37612
G1 X181.121 Y129.745 E.05081
G1 X180.743 Y130.542 F30000
G1 F12000
G1 X180.743 Y130.062 E.01474
G1 X169.257 Y130.062 E.35295
G1 X169.257 Y131.022 E.02948
G1 X180.743 Y131.022 E.35295
G1 X180.743 Y130.602 E.0129
G1 X180.264 Y130.542 F30000
; Slow Down Start
; LINE_WIDTH: 0.62528
G1 F3000;_EXTRUDE_SET_SPEED
G1 X169.796 Y130.542 E.49673
; Slow Down End
; WIPE_START
G1 X171.796 Y130.542 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X179.049 Y128.163 Z5.6 F30000
G1 X183.583 Y126.676 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.073 Y127.185 E.02213
G1 X182.54 Y127.185
G1 X183.583 Y126.143 E.04531
G1 X183.245 Y125.947
G1 X182.007 Y127.185 E.05379
G1 X181.474 Y127.185
G1 X182.711 Y125.947 E.05379
G1 X182.178 Y125.947
G1 X180.94 Y127.185 E.05379
G1 X180.407 Y127.185
G1 X181.645 Y125.947 E.05379
G1 X181.112 Y125.947
G1 X179.874 Y127.185 E.05379
G1 X179.34 Y127.185
G1 X180.578 Y125.947 E.05379
G1 X180.045 Y125.947
G1 X178.807 Y127.185 E.05379
G1 X178.274 Y127.185
G1 X179.512 Y125.947 E.05379
G1 X178.979 Y125.947
G1 X177.741 Y127.185 E.05379
G1 X177.207 Y127.185
G1 X178.445 Y125.947 E.05379
G1 X177.912 Y125.947
G1 X176.674 Y127.185 E.05379
G1 X176.141 Y127.185
G1 X177.379 Y125.947 E.05379
G1 X176.846 Y125.947
G1 X175.608 Y127.185 E.05379
G1 X175.074 Y127.185
G1 X176.312 Y125.947 E.05379
G1 X175.779 Y125.947
G1 X174.541 Y127.185 E.05379
G1 X174.008 Y127.185
G1 X175.246 Y125.947 E.05379
G1 X174.713 Y125.947
G1 X173.475 Y127.185 E.05379
G1 X172.941 Y127.185
G1 X174.179 Y125.947 E.05379
G1 X173.646 Y125.947
G1 X172.408 Y127.185 E.05379
G1 X171.875 Y127.185
G1 X173.113 Y125.947 E.05379
G1 X172.58 Y125.947
G1 X171.342 Y127.185 E.05379
G1 X170.808 Y127.185
G1 X172.046 Y125.947 E.05379
G1 X171.513 Y125.947
G1 X170.275 Y127.185 E.05379
G1 X169.742 Y127.185
G1 X170.98 Y125.947 E.05379
G1 X170.447 Y125.947
G1 X169.209 Y127.185 E.05379
G1 X168.675 Y127.185
G1 X169.913 Y125.947 E.05379
G1 X169.38 Y125.947
G1 X168.142 Y127.185 E.05379
G1 X167.609 Y127.185
G1 X168.847 Y125.947 E.05379
G1 X168.313 Y125.947
G1 X167.076 Y127.185 E.05379
G1 X166.542 Y127.185
G1 X167.78 Y125.947 E.05379
G1 X167.247 Y125.947
G1 X166.417 Y126.777 E.03605
; CHANGE_LAYER
; Z_HEIGHT: 5.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
M204 S10000
G1 X167.247 Y125.947 E-.44581
G1 X167.78 Y125.947 E-.20264
G1 X167.573 Y126.155 E-.11155
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 27/32
; update layer progress
M73 L27
M991 S0 P26 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.6 I-.233 J-1.195 P1  F30000
G1 X131.398 Y133.197 Z5.6
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.602 Y133.197 E.22543
G1 X124.602 Y128.208 E.16549
G1 X131.398 Y128.208 E.22543
G1 X131.398 Y133.137 E.1635
; WIPE_START
G1 X129.398 Y133.154 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X137.03 Y133.19 Z5.8 F30000
G1 X138.602 Y133.197 Z5.8
G1 Z5.4
G1 E.8 F1800
G1 F15476.087
G1 X138.602 Y133.197 E.00001
G1 X138.602 Y128.208 E.16549
G1 X145.398 Y128.208 E.22543
G1 X145.398 Y133.197 E.16549
G1 X138.662 Y133.197 E.22343
; WIPE_START
G1 X138.602 Y133.197 E-.02288
G1 X138.602 Y131.257 E-.73712
; WIPE_END
G1 E-.04 F1800
G1 X146.162 Y132.304 Z5.8 F30000
G1 X152.602 Y133.197 Z5.8
G1 Z5.4
G1 E.8 F1800
G1 F15476.087
G1 X152.602 Y128.208 E.16549
G1 X159.398 Y128.208 E.22543
G1 X159.398 Y133.197 E.16549
G1 X152.662 Y133.197 E.22344
; WIPE_START
G1 X152.638 Y131.197 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X160.193 Y132.279 Z5.8 F30000
G1 X166.602 Y133.197 Z5.8
G1 Z5.4
G1 E.8 F1800
G1 F15476.087
G1 X166.602 Y128.208 E.16549
G1 X183.398 Y128.208 E.55715
G1 X183.398 Y133.197 E.16549
G1 X166.662 Y133.197 E.55516
; WIPE_START
G1 X166.638 Y131.197 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.012 Y131.507 Z5.8 F30000
G1 X117.398 Y133.197 Z5.8
G1 Z5.4
G1 E.8 F1800
G1 F15476.087
G1 X110.602 Y133.197 E.22543
G1 X110.602 Y128.208 E.16549
G1 X117.398 Y128.208 E.22543
G1 X117.398 Y133.137 E.1635
; WIPE_START
G1 X115.398 Y133.154 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.766 Y133.181 Z5.8 F30000
G1 X103.398 Y133.197 Z5.8
G1 Z5.4
G1 E.8 F1800
G1 F15476.087
G1 X96.602 Y133.197 E.22543
G1 X96.602 Y128.208 E.16549
G1 X103.398 Y128.208 E.22543
G1 X103.398 Y133.137 E.1635
; WIPE_START
G1 X101.398 Y133.154 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X93.766 Y133.181 Z5.8 F30000
G1 X89.398 Y133.197 Z5.8
G1 Z5.4
G1 E.8 F1800
G1 F15476.087
G1 X72.602 Y133.197 E.55715
G1 X72.602 Y128.208 E.16549
G1 X89.398 Y128.208 E.55715
G1 X89.398 Y133.137 E.1635
; WIPE_START
G1 X87.398 Y133.144 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X95.03 Y133.154 Z5.8 F30000
G1 X138.21 Y133.21 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y126.54 E.20495
G1 X145.79 Y126.54 E.23291
G1 X145.79 Y133.21 E.20495
G1 X152.21 Y133.21 E.19727
G1 X152.21 Y126.54 E.20495
G1 X159.79 Y126.54 E.23291
G1 X159.79 Y133.21 E.20495
G1 X166.21 Y133.21 E.19727
G1 X166.21 Y126.54 E.20495
G1 X183.79 Y126.54 E.54018
G1 X183.79 Y133.589 E.21659
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X72.21 Y133.589 E3.42854
G1 X72.21 Y126.54 E.21659
G1 X89.79 Y126.54 E.54018
G1 X89.79 Y133.21 E.20495
G1 X96.21 Y133.21 E.19727
G1 X96.21 Y126.54 E.20495
G1 X103.79 Y126.54 E.23291
G1 X103.79 Y133.21 E.20495
G1 X110.21 Y133.21 E.19727
G1 X110.21 Y126.54 E.20495
G1 X117.79 Y126.54 E.23291
G1 X117.79 Y133.21 E.20495
G1 X124.21 Y133.21 E.19727
G1 X124.21 Y126.54 E.20495
G1 X131.79 Y126.54 E.23291
G1 X131.79 Y133.21 E.20495
G1 X138.15 Y133.21 E.19542
; WIPE_START
M204 S10000
G1 X138.168 Y131.21 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X140.894 Y130.499 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.44851
G1 F15000
G1 X140.894 Y130.905 E.01341
G1 X143.106 Y130.905 E.07313
G1 X143.106 Y130.499 E.01341
G1 X140.954 Y130.499 E.07114
G1 X140.502 Y130.108 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X140.502 Y131.296 E.03651
G1 X143.498 Y131.296 E.09203
G1 X143.498 Y130.108 E.03651
G1 X140.562 Y130.108 E.09019
G1 X140.125 Y129.731 F30000
G1 F15000
G1 X140.125 Y131.673 E.05968
G1 X143.875 Y131.673 E.1152
G1 X143.875 Y129.731 E.05968
G1 X140.185 Y129.731 E.11336
G1 X139.748 Y129.354 F30000
G1 F15000
G1 X139.748 Y132.051 E.08286
G1 X144.252 Y132.051 E.13838
G1 X144.252 Y129.354 E.08286
G1 X139.808 Y129.354 E.13653
G1 X139.371 Y128.977 F30000
G1 F15000
G1 X139.371 Y132.428 E.10603
G1 X144.629 Y132.428 E.16155
G1 X144.629 Y128.977 E.10603
G1 X139.431 Y128.977 E.1597
G1 X138.994 Y128.6 F30000
G1 F15000
G1 X138.994 Y132.805 E.1292
M73 P92 R1
G1 X145.006 Y132.805 E.18472
G1 X145.006 Y128.6 E.1292
G1 X139.054 Y128.6 E.18288
; WIPE_START
G1 X141.054 Y128.6 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y127.318 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.012 Y126.747 E.02481
G1 X144.478 Y126.747
M73 P93 R1
G1 X145.583 Y127.852 E.04798
G1 X145.183 Y127.985
G1 X143.945 Y126.747 E.05379
G1 X143.412 Y126.747
G1 X144.65 Y127.985 E.05379
G1 X144.117 Y127.985
G1 X142.879 Y126.747 E.05379
G1 X142.345 Y126.747
G1 X143.583 Y127.985 E.05379
G1 X143.05 Y127.985
G1 X141.812 Y126.747 E.05379
G1 X141.279 Y126.747
G1 X142.517 Y127.985 E.05379
G1 X141.984 Y127.985
G1 X140.746 Y126.747 E.05379
G1 X140.212 Y126.747
G1 X141.45 Y127.985 E.05379
G1 X140.917 Y127.985
G1 X139.679 Y126.747 E.05379
G1 X139.146 Y126.747
G1 X140.384 Y127.985 E.05379
G1 X139.851 Y127.985
G1 X138.613 Y126.747 E.05379
G1 X138.417 Y127.085
G1 X139.317 Y127.985 E.0391
G1 X138.784 Y127.985
G1 X138.417 Y127.619 E.01593
; WIPE_START
M204 S10000
G1 X138.784 Y127.985 E-.19701
G1 X139.317 Y127.985 E-.20264
G1 X138.647 Y127.315 E-.36036
; WIPE_END
G1 E-.04 F1800
G1 X131.583 Y127.183 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X131.147 Y126.747 E.01893
G1 X130.614 Y126.747
G1 X131.583 Y127.716 E.0421
G1 X131.318 Y127.985
G1 X130.081 Y126.747 E.05379
G1 X129.547 Y126.747
G1 X130.785 Y127.985 E.05379
G1 X130.252 Y127.985
G1 X129.014 Y126.747 E.05379
G1 X128.481 Y126.747
G1 X129.719 Y127.985 E.05379
G1 X129.185 Y127.985
G1 X127.947 Y126.747 E.05379
G1 X127.414 Y126.747
G1 X128.652 Y127.985 E.05379
G1 X128.119 Y127.985
G1 X126.881 Y126.747 E.05379
G1 X126.348 Y126.747
G1 X127.586 Y127.985 E.05379
G1 X127.052 Y127.985
G1 X125.814 Y126.747 E.05379
G1 X125.281 Y126.747
G1 X126.519 Y127.985 E.05379
G1 X125.986 Y127.985
G1 X124.748 Y126.747 E.05379
G1 X124.417 Y126.95
G1 X125.453 Y127.985 E.04498
G1 X124.919 Y127.985
G1 X124.417 Y127.483 E.02181
; WIPE_START
M204 S10000
G1 X124.919 Y127.985 E-.26973
G1 X125.453 Y127.985 E-.20264
G1 X124.917 Y127.45 E-.28763
; WIPE_END
G1 E-.04 F1800
G1 X126.894 Y130.499 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.44851
G1 F15000
G1 X126.894 Y130.905 E.01341
G1 X129.106 Y130.905 E.07313
G1 X129.106 Y130.499 E.01341
G1 X126.954 Y130.499 E.07114
G1 X126.502 Y130.108 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X126.502 Y131.296 E.03651
G1 X129.498 Y131.296 E.09203
G1 X129.498 Y130.108 E.03651
G1 X126.562 Y130.108 E.09019
G1 X126.125 Y129.731 F30000
G1 F15000
G1 X126.125 Y131.673 E.05968
G1 X129.875 Y131.673 E.1152
G1 X129.875 Y129.731 E.05968
G1 X126.185 Y129.731 E.11336
G1 X125.748 Y129.354 F30000
G1 F15000
G1 X125.748 Y132.051 E.08286
G1 X130.252 Y132.051 E.13838
G1 X130.252 Y129.354 E.08286
G1 X125.808 Y129.354 E.13653
G1 X125.371 Y128.977 F30000
G1 F15000
G1 X125.371 Y132.428 E.10603
G1 X130.629 Y132.428 E.16155
G1 X130.629 Y128.977 E.10603
G1 X125.431 Y128.977 E.1597
G1 X124.994 Y128.6 F30000
G1 F15000
G1 X124.994 Y132.805 E.1292
G1 X131.006 Y132.805 E.18472
G1 X131.006 Y128.6 E.1292
G1 X125.054 Y128.6 E.18288
; WIPE_START
G1 X127.054 Y128.6 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X119.542 Y127.249 Z5.8 F30000
G1 X116.749 Y126.747 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X117.583 Y127.581 E.03622
G1 X117.454 Y127.985
G1 X116.216 Y126.747 E.05379
G1 X115.683 Y126.747
G1 X116.92 Y127.985 E.05379
G1 X116.387 Y127.985
G1 X115.149 Y126.747 E.05379
G1 X114.616 Y126.747
G1 X115.854 Y127.985 E.05379
G1 X115.321 Y127.985
G1 X114.083 Y126.747 E.05379
G1 X113.55 Y126.747
G1 X114.787 Y127.985 E.05379
G1 X114.254 Y127.985
G1 X113.016 Y126.747 E.05379
G1 X112.483 Y126.747
G1 X113.721 Y127.985 E.05379
G1 X113.188 Y127.985
G1 X111.95 Y126.747 E.05379
G1 X111.416 Y126.747
G1 X112.654 Y127.985 E.05379
G1 X112.121 Y127.985
G1 X110.883 Y126.747 E.05379
G1 X110.417 Y126.815
G1 X111.588 Y127.985 E.05086
G1 X111.055 Y127.985
G1 X110.417 Y127.348 E.02769
; WIPE_START
M204 S10000
G1 X111.055 Y127.985 E-.34244
G1 X111.588 Y127.985 E-.20264
G1 X111.188 Y127.585 E-.21493
; WIPE_END
G1 E-.04 F1800
G1 X115.106 Y130.499 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.44851
G1 F15000
G1 X112.894 Y130.499 E.07313
G1 X112.894 Y130.905 E.01341
G1 X115.106 Y130.905 E.07313
G1 X115.106 Y130.559 E.01142
G1 X115.498 Y130.108 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X112.502 Y130.108 E.09203
G1 X112.502 Y131.296 E.03651
G1 X115.498 Y131.296 E.09203
G1 X115.498 Y130.168 E.03467
G1 X115.875 Y129.731 F30000
G1 F15000
G1 X112.125 Y129.731 E.1152
G1 X112.125 Y131.673 E.05968
G1 X115.875 Y131.673 E.1152
G1 X115.875 Y129.791 E.05784
G1 X116.252 Y129.354 F30000
G1 F15000
G1 X111.748 Y129.354 E.13838
G1 X111.748 Y132.051 E.08286
G1 X116.252 Y132.051 E.13838
G1 X116.252 Y129.414 E.08101
G1 X116.629 Y128.977 F30000
G1 F15000
G1 X111.371 Y128.977 E.16155
G1 X111.371 Y132.428 E.10603
G1 X116.629 Y132.428 E.16155
G1 X116.629 Y129.037 E.10418
G1 X117.006 Y128.6 F30000
G1 F15000
G1 X110.994 Y128.6 E.18472
G1 X110.994 Y132.805 E.1292
G1 X117.006 Y132.805 E.18472
G1 X117.006 Y128.66 E.12736
; WIPE_START
G1 X117.006 Y130.66 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.583 Y128.883 Z5.8 F30000
G1 X103.583 Y127.446 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X102.884 Y126.747 E.03034
G1 X102.351 Y126.747
G1 X103.583 Y127.979 E.05352
G1 X103.056 Y127.985
G1 X101.818 Y126.747 E.05379
G1 X101.285 Y126.747
G1 X102.522 Y127.985 E.05379
G1 X101.989 Y127.985
G1 X100.751 Y126.747 E.05379
G1 X100.218 Y126.747
G1 X101.456 Y127.985 E.05379
G1 X100.923 Y127.985
G1 X99.685 Y126.747 E.05379
G1 X99.152 Y126.747
G1 X100.389 Y127.985 E.05379
G1 X99.856 Y127.985
G1 X98.618 Y126.747 E.05379
G1 X98.085 Y126.747
G1 X99.323 Y127.985 E.05379
G1 X98.79 Y127.985
G1 X97.552 Y126.747 E.05379
G1 X97.019 Y126.747
G1 X98.256 Y127.985 E.05379
G1 X97.723 Y127.985
G1 X96.485 Y126.747 E.05379
G1 X96.417 Y127.213
G1 X97.19 Y127.985 E.03357
; WIPE_START
M204 S10000
G1 X96.417 Y127.213 E-.41515
G1 X96.485 Y126.747 E-.17871
G1 X96.794 Y127.057 E-.16613
; WIPE_END
G1 E-.04 F1800
G1 X101.106 Y130.499 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.44851
G1 F15000
G1 X98.894 Y130.499 E.07313
G1 X98.894 Y130.905 E.01341
G1 X101.106 Y130.905 E.07313
G1 X101.106 Y130.559 E.01142
G1 X101.498 Y130.108 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X98.502 Y130.108 E.09203
G1 X98.502 Y131.296 E.03651
G1 X101.498 Y131.296 E.09203
G1 X101.498 Y130.168 E.03467
G1 X101.875 Y129.731 F30000
G1 F15000
G1 X98.125 Y129.731 E.1152
G1 X98.125 Y131.673 E.05968
G1 X101.875 Y131.673 E.1152
G1 X101.875 Y129.791 E.05784
G1 X102.252 Y129.354 F30000
G1 F15000
G1 X97.748 Y129.354 E.13838
G1 X97.748 Y132.051 E.08286
G1 X102.252 Y132.051 E.13838
G1 X102.252 Y129.414 E.08101
G1 X102.629 Y128.977 F30000
G1 F15000
G1 X97.371 Y128.977 E.16155
G1 X97.371 Y132.428 E.10603
G1 X102.629 Y132.428 E.16155
G1 X102.629 Y129.037 E.10418
G1 X103.006 Y128.6 F30000
G1 F15000
G1 X96.994 Y128.6 E.18472
G1 X96.994 Y132.805 E.1292
G1 X103.006 Y132.805 E.18472
G1 X103.006 Y128.66 E.12736
; WIPE_START
G1 X103.006 Y130.66 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X95.6 Y128.812 Z5.8 F30000
G1 X89.583 Y127.31 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.02 Y126.747 E.02446
G1 X88.486 Y126.747
G1 X89.583 Y127.844 E.04763
G1 X89.191 Y127.985
G1 X87.953 Y126.747 E.05379
G1 X87.42 Y126.747
G1 X88.658 Y127.985 E.05379
G1 X88.125 Y127.985
G1 X86.887 Y126.747 E.05379
G1 X86.353 Y126.747
G1 X87.591 Y127.985 E.05379
G1 X87.058 Y127.985
G1 X85.82 Y126.747 E.05379
G1 X85.287 Y126.747
G1 X86.525 Y127.985 E.05379
G1 X85.991 Y127.985
G1 X84.754 Y126.747 E.05379
G1 X84.22 Y126.747
G1 X85.458 Y127.985 E.05379
G1 X84.925 Y127.985
G1 X83.687 Y126.747 E.05379
G1 X83.154 Y126.747
G1 X84.392 Y127.985 E.05379
G1 X83.858 Y127.985
G1 X82.621 Y126.747 E.05379
G1 X82.087 Y126.747
G1 X83.325 Y127.985 E.05379
G1 X82.792 Y127.985
G1 X81.554 Y126.747 E.05379
G1 X81.021 Y126.747
G1 X82.259 Y127.985 E.05379
G1 X81.725 Y127.985
G1 X80.488 Y126.747 E.05379
G1 X79.954 Y126.747
G1 X81.192 Y127.985 E.05379
G1 X80.659 Y127.985
G1 X79.421 Y126.747 E.05379
G1 X78.888 Y126.747
G1 X80.126 Y127.985 E.05379
G1 X79.592 Y127.985
G1 X78.355 Y126.747 E.05379
G1 X77.821 Y126.747
G1 X79.059 Y127.985 E.05379
G1 X78.526 Y127.985
G1 X77.288 Y126.747 E.05379
G1 X76.755 Y126.747
G1 X77.993 Y127.985 E.05379
G1 X77.459 Y127.985
G1 X76.221 Y126.747 E.05379
G1 X75.688 Y126.747
G1 X76.926 Y127.985 E.05379
G1 X76.393 Y127.985
G1 X75.155 Y126.747 E.05379
G1 X74.622 Y126.747
G1 X75.86 Y127.985 E.05379
G1 X75.326 Y127.985
G1 X74.088 Y126.747 E.05379
G1 X73.555 Y126.747
G1 X74.793 Y127.985 E.05379
G1 X74.26 Y127.985
G1 X73.022 Y126.747 E.05379
G1 X72.489 Y126.747
G1 X73.727 Y127.985 E.05379
G1 X73.193 Y127.985
G1 X72.417 Y127.209 E.03372
; WIPE_START
M204 S10000
G1 X73.193 Y127.985 E-.41699
G1 X73.727 Y127.985 E-.20264
G1 X73.465 Y127.724 E-.14038
; WIPE_END
G1 E-.04 F1800
G1 X80.945 Y129.246 Z5.8 F30000
G1 X87.106 Y130.499 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.44851
G1 F15000
G1 X74.894 Y130.499 E.40363
G1 X74.894 Y130.905 E.01341
G1 X87.106 Y130.905 E.40363
G1 X87.106 Y130.559 E.01142
G1 X87.498 Y130.108 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X74.502 Y130.108 E.3993
G1 X74.502 Y131.296 E.03651
G1 X87.498 Y131.296 E.3993
G1 X87.498 Y130.168 E.03467
G1 X87.875 Y129.731 F30000
G1 F15000
G1 X74.125 Y129.731 E.42247
G1 X74.125 Y131.673 E.05968
G1 X87.875 Y131.673 E.42247
G1 X87.875 Y129.791 E.05784
G1 X88.252 Y129.354 F30000
G1 F15000
G1 X73.748 Y129.354 E.44564
G1 X73.748 Y132.051 E.08286
G1 X88.252 Y132.051 E.44564
G1 X88.252 Y129.414 E.08101
G1 X88.629 Y128.977 F30000
G1 F15000
G1 X73.371 Y128.977 E.46881
G1 X73.371 Y132.428 E.10603
G1 X88.629 Y132.428 E.46881
G1 X88.629 Y129.037 E.10418
G1 X89.006 Y128.6 F30000
G1 F15000
G1 X72.994 Y128.6 E.49198
G1 X72.994 Y132.805 E.1292
G1 X89.006 Y132.805 E.49198
G1 X89.006 Y128.66 E.12736
; WIPE_START
G1 X89.006 Y130.66 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X96.638 Y130.641 Z5.8 F30000
G1 X154.894 Y130.499 Z5.8
G1 Z5.4
G1 E.8 F1800
; LINE_WIDTH: 0.44851
G1 F15000
G1 X154.894 Y130.905 E.01341
G1 X157.106 Y130.905 E.07313
G1 X157.106 Y130.499 E.01341
G1 X154.954 Y130.499 E.07114
G1 X154.502 Y130.108 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X154.502 Y131.296 E.03651
G1 X157.498 Y131.296 E.09203
G1 X157.498 Y130.108 E.03651
G1 X154.562 Y130.108 E.09019
G1 X154.125 Y129.731 F30000
G1 F15000
G1 X154.125 Y131.673 E.05968
G1 X157.875 Y131.673 E.1152
G1 X157.875 Y129.731 E.05968
G1 X154.185 Y129.731 E.11336
G1 X153.748 Y129.354 F30000
G1 F15000
G1 X153.748 Y132.051 E.08286
G1 X158.252 Y132.051 E.13838
G1 X158.252 Y129.354 E.08286
G1 X153.808 Y129.354 E.13653
G1 X153.371 Y128.977 F30000
G1 F15000
G1 X153.371 Y132.428 E.10603
G1 X158.629 Y132.428 E.16155
G1 X158.629 Y128.977 E.10603
G1 X153.431 Y128.977 E.1597
G1 X152.994 Y128.6 F30000
G1 F15000
G1 X152.994 Y132.805 E.1292
G1 X159.006 Y132.805 E.18472
G1 X159.006 Y128.6 E.1292
G1 X153.054 Y128.6 E.18288
; WIPE_START
G1 X155.054 Y128.6 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y127.454 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X158.876 Y126.747 E.03069
G1 X158.343 Y126.747
G1 X159.581 Y127.985 E.05379
G1 X159.048 Y127.985
G1 X157.81 Y126.747 E.05379
G1 X157.277 Y126.747
G1 X158.515 Y127.985 E.05379
G1 X157.981 Y127.985
G1 X156.743 Y126.747 E.05379
G1 X156.21 Y126.747
G1 X157.448 Y127.985 E.05379
G1 X156.915 Y127.985
G1 X155.677 Y126.747 E.05379
G1 X155.144 Y126.747
G1 X156.381 Y127.985 E.05379
G1 X155.848 Y127.985
G1 X154.61 Y126.747 E.05379
G1 X154.077 Y126.747
G1 X155.315 Y127.985 E.05379
G1 X154.782 Y127.985
G1 X153.544 Y126.747 E.05379
G1 X153.011 Y126.747
G1 X154.248 Y127.985 E.05379
G1 X153.715 Y127.985
G1 X152.477 Y126.747 E.05379
G1 X152.417 Y127.221
G1 X153.182 Y127.985 E.03322
; WIPE_START
M204 S10000
G1 X152.417 Y127.221 E-.41087
G1 X152.477 Y126.747 E-.1813
G1 X152.79 Y127.06 E-.16783
; WIPE_END
G1 E-.04 F1800
G1 X160.254 Y128.654 Z5.8 F30000
G1 X168.894 Y130.499 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.44851
G1 F15000
G1 X168.894 Y130.905 E.01341
G1 X181.106 Y130.905 E.40363
G1 X181.106 Y130.499 E.01341
G1 X168.954 Y130.499 E.40165
G1 X168.502 Y130.108 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X168.502 Y131.296 E.03651
G1 X181.498 Y131.296 E.3993
G1 X181.498 Y130.108 E.03651
G1 X168.562 Y130.108 E.39745
G1 X168.125 Y129.731 F30000
G1 F15000
G1 X168.125 Y131.673 E.05968
G1 X181.875 Y131.673 E.42247
G1 X181.875 Y129.731 E.05968
G1 X168.185 Y129.731 E.42062
G1 X167.748 Y129.354 F30000
G1 F15000
G1 X167.748 Y132.051 E.08286
G1 X182.252 Y132.051 E.44564
G1 X182.252 Y129.354 E.08286
G1 X167.808 Y129.354 E.4438
G1 X167.371 Y128.977 F30000
G1 F15000
G1 X167.371 Y132.428 E.10603
G1 X182.629 Y132.428 E.46881
G1 X182.629 Y128.977 E.10603
G1 X167.431 Y128.977 E.46697
G1 X166.994 Y128.6 F30000
G1 F15000
G1 X166.994 Y132.805 E.1292
G1 X183.006 Y132.805 E.49198
G1 X183.006 Y128.6 E.1292
G1 X167.054 Y128.6 E.49014
; WIPE_START
G1 X169.054 Y128.6 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X176.663 Y128.001 Z5.8 F30000
G1 X183.583 Y127.457 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X182.873 Y126.747 E.03084
G1 X182.34 Y126.747
G1 X183.578 Y127.985 E.05379
G1 X183.044 Y127.985
G1 X181.806 Y126.747 E.05379
G1 X181.273 Y126.747
M73 P94 R1
G1 X182.511 Y127.985 E.05379
G1 X181.978 Y127.985
G1 X180.74 Y126.747 E.05379
G1 X180.207 Y126.747
G1 X181.445 Y127.985 E.05379
G1 X180.911 Y127.985
G1 X179.673 Y126.747 E.05379
G1 X179.14 Y126.747
G1 X180.378 Y127.985 E.05379
G1 X179.845 Y127.985
G1 X178.607 Y126.747 E.05379
G1 X178.074 Y126.747
G1 X179.312 Y127.985 E.05379
G1 X178.778 Y127.985
G1 X177.54 Y126.747 E.05379
G1 X177.007 Y126.747
G1 X178.245 Y127.985 E.05379
G1 X177.712 Y127.985
G1 X176.474 Y126.747 E.05379
G1 X175.941 Y126.747
G1 X177.179 Y127.985 E.05379
G1 X176.645 Y127.985
G1 X175.407 Y126.747 E.05379
G1 X174.874 Y126.747
G1 X176.112 Y127.985 E.05379
G1 X175.579 Y127.985
G1 X174.341 Y126.747 E.05379
G1 X173.808 Y126.747
G1 X175.045 Y127.985 E.05379
G1 X174.512 Y127.985
G1 X173.274 Y126.747 E.05379
G1 X172.741 Y126.747
G1 X173.979 Y127.985 E.05379
G1 X173.446 Y127.985
G1 X172.208 Y126.747 E.05379
G1 X171.675 Y126.747
G1 X172.912 Y127.985 E.05379
G1 X172.379 Y127.985
G1 X171.141 Y126.747 E.05379
G1 X170.608 Y126.747
G1 X171.846 Y127.985 E.05379
G1 X171.313 Y127.985
G1 X170.075 Y126.747 E.05379
G1 X169.542 Y126.747
G1 X170.779 Y127.985 E.05379
G1 X170.246 Y127.985
G1 X169.008 Y126.747 E.05379
G1 X168.475 Y126.747
G1 X169.713 Y127.985 E.05379
G1 X169.18 Y127.985
G1 X167.942 Y126.747 E.05379
G1 X167.409 Y126.747
G1 X168.646 Y127.985 E.05379
G1 X168.113 Y127.985
G1 X166.875 Y126.747 E.05379
G1 X166.417 Y126.823
G1 X167.58 Y127.985 E.05052
G1 X167.047 Y127.985
G1 X166.417 Y127.356 E.02734
; CHANGE_LAYER
; Z_HEIGHT: 5.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
M204 S10000
G1 X167.047 Y127.985 E-.33815
G1 X167.58 Y127.985 E-.20264
G1 X167.172 Y127.577 E-.21921
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 28/32
; update layer progress
M73 L28
M991 S0 P27 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.8 I-.146 J-1.208 P1  F30000
G1 X124.602 Y132.717 Z5.8
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.602 Y129.008 E.12305
G1 X131.398 Y129.008 E.22543
G1 X131.398 Y132.717 E.12305
G1 X124.662 Y132.717 E.22344
M204 S250
G1 X124.21 Y133.109 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X124.21 Y127.34 E.17728
G1 X131.79 Y127.34 E.23291
G1 X131.79 Y133.109 E.17728
G1 X124.27 Y133.109 E.23107
; WIPE_START
M204 S10000
G1 X124.249 Y131.109 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.834 Y131.959 Z6 F30000
G1 X138.602 Y132.717 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y129.008 E.12305
G1 X145.398 Y129.008 E.22543
G1 X145.398 Y132.717 E.12305
G1 X138.662 Y132.717 E.22344
M204 S250
G1 X138.21 Y133.109 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y127.34 E.17728
G1 X145.79 Y127.34 E.23291
G1 X145.79 Y133.109 E.17728
G1 X138.27 Y133.109 E.23107
; WIPE_START
M204 S10000
G1 X138.249 Y131.109 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.834 Y131.959 Z6 F30000
G1 X152.602 Y132.717 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X152.602 Y129.008 E.12305
G1 X159.398 Y129.008 E.22543
G1 X159.398 Y132.717 E.12305
G1 X152.662 Y132.717 E.22344
M204 S250
G1 X152.21 Y133.109 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X152.21 Y127.34 E.17728
G1 X159.79 Y127.34 E.23291
G1 X159.79 Y133.109 E.17728
G1 X152.27 Y133.109 E.23107
; WIPE_START
M204 S10000
G1 X152.249 Y131.109 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.834 Y131.959 Z6 F30000
G1 X166.602 Y132.717 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X166.602 Y129.008 E.12305
G1 X183.398 Y129.008 E.55715
G1 X183.398 Y132.717 E.12305
G1 X166.662 Y132.717 E.55516
M204 S250
G1 X166.21 Y133.109 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X166.21 Y127.34 E.17728
G1 X183.79 Y127.34 E.54018
G1 X183.79 Y133.109 E.17728
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X166.27 Y133.109 E.53834
; WIPE_START
M204 S10000
G1 X166.249 Y131.109 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X158.62 Y131.33 Z6 F30000
G1 X110.602 Y132.717 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y129.008 E.12305
G1 X117.398 Y129.008 E.22543
G1 X117.398 Y132.717 E.12305
G1 X110.662 Y132.717 E.22344
M204 S250
G1 X110.21 Y133.109 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X110.21 Y127.34 E.17728
G1 X117.79 Y127.34 E.23291
G1 X117.79 Y133.109 E.17728
G1 X110.27 Y133.109 E.23107
; WIPE_START
M204 S10000
G1 X110.249 Y131.109 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X102.669 Y132.002 Z6 F30000
G1 X96.602 Y132.717 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X96.602 Y129.008 E.12305
G1 X103.398 Y129.008 E.22543
G1 X103.398 Y132.717 E.12305
G1 X96.662 Y132.717 E.22344
M204 S250
G1 X96.21 Y133.109 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X96.21 Y127.34 E.17728
G1 X103.79 Y127.34 E.23291
G1 X103.79 Y133.109 E.17728
G1 X96.27 Y133.109 E.23107
; WIPE_START
M204 S10000
G1 X96.249 Y131.109 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.398 Y132.717 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y132.717 E.55715
G1 X72.602 Y129.008 E.12305
G1 X89.398 Y129.008 E.55715
G1 X89.398 Y132.657 E.12106
M204 S250
G1 X89.79 Y133.109 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y133.109 E.54018
G1 X72.21 Y127.34 E.17728
G1 X89.79 Y127.34 E.54018
G1 X89.79 Y133.049 E.17543
; WIPE_START
M204 S10000
G1 X87.79 Y133.056 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X87.803 Y130.603 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56293
G1 F12115.152
G1 X74.197 Y130.603 E.57656
G1 X74.197 Y131.123 E.02204
G1 X87.803 Y131.123 E.57656
G1 X87.803 Y130.663 E.01949
G1 X88.252 Y130.154 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X73.748 Y130.154 E.44564
G1 X73.748 Y131.571 E.04354
G1 X88.252 Y131.571 E.44564
G1 X88.252 Y130.214 E.0417
G1 X88.629 Y129.777 F30000
G1 F15000
G1 X73.371 Y129.777 E.46881
G1 X73.371 Y131.948 E.06671
G1 X88.629 Y131.948 E.46881
G1 X88.629 Y129.837 E.06487
G1 X89.006 Y129.4 F30000
G1 F15000
G1 X72.994 Y129.4 E.49198
G1 X72.994 Y132.325 E.08989
G1 X89.006 Y132.325 E.49198
G1 X89.006 Y129.46 E.08804
G1 X89.22 Y128.785 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.583 Y128.422 E.01577
G1 X89.583 Y127.889
G1 X88.686 Y128.785 E.03894
G1 X88.153 Y128.785
G1 X89.391 Y127.547 E.05379
G1 X88.858 Y127.547
G1 X87.62 Y128.785 E.05379
G1 X87.087 Y128.785
G1 X88.325 Y127.547 E.05379
G1 X87.791 Y127.547
G1 X86.553 Y128.785 E.05379
G1 X86.02 Y128.785
G1 X87.258 Y127.547 E.05379
G1 X86.725 Y127.547
G1 X85.487 Y128.785 E.05379
G1 X84.954 Y128.785
G1 X86.192 Y127.547 E.05379
G1 X85.658 Y127.547
G1 X84.42 Y128.785 E.05379
G1 X83.887 Y128.785
G1 X85.125 Y127.547 E.05379
G1 X84.592 Y127.547
G1 X83.354 Y128.785 E.05379
G1 X82.821 Y128.785
G1 X84.059 Y127.547 E.05379
G1 X83.525 Y127.547
G1 X82.287 Y128.785 E.05379
G1 X81.754 Y128.785
G1 X82.992 Y127.547 E.05379
G1 X82.459 Y127.547
G1 X81.221 Y128.785 E.05379
G1 X80.688 Y128.785
G1 X81.925 Y127.547 E.05379
G1 X81.392 Y127.547
G1 X80.154 Y128.785 E.05379
G1 X79.621 Y128.785
G1 X80.859 Y127.547 E.05379
G1 X80.326 Y127.547
G1 X79.088 Y128.785 E.05379
G1 X78.555 Y128.785
G1 X79.792 Y127.547 E.05379
G1 X79.259 Y127.547
G1 X78.021 Y128.785 E.05379
G1 X77.488 Y128.785
G1 X78.726 Y127.547 E.05379
G1 X78.193 Y127.547
G1 X76.955 Y128.785 E.05379
G1 X76.422 Y128.785
G1 X77.659 Y127.547 E.05379
G1 X77.126 Y127.547
G1 X75.888 Y128.785 E.05379
G1 X75.355 Y128.785
G1 X76.593 Y127.547 E.05379
G1 X76.06 Y127.547
G1 X74.822 Y128.785 E.05379
G1 X74.289 Y128.785
G1 X75.526 Y127.547 E.05379
G1 X74.993 Y127.547
G1 X73.755 Y128.785 E.05379
G1 X73.222 Y128.785
G1 X74.46 Y127.547 E.05379
G1 X73.927 Y127.547
G1 X72.689 Y128.785 E.05379
G1 X72.417 Y128.523
G1 X73.393 Y127.547 E.04241
G1 X72.86 Y127.547
G1 X72.417 Y127.99 E.01924
; WIPE_START
M204 S10000
G1 X72.86 Y127.547 E-.23793
G1 X73.393 Y127.547 E-.20264
G1 X72.799 Y128.142 E-.31943
; WIPE_END
G1 E-.04 F1800
G1 X80.43 Y128.015 Z6 F30000
G1 X89.556 Y127.863 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.133113
G1 F15000
G1 X89.556 Y127.529 E.00246
; WIPE_START
G1 X89.556 Y127.863 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X97.005 Y129.529 Z6 F30000
G1 X101.803 Y130.603 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.562925
G1 F12115.27
G1 X98.197 Y130.603 E.15282
G1 X98.197 Y131.123 E.02204
G1 X101.803 Y131.123 E.15282
G1 X101.803 Y130.663 E.01949
G1 X102.252 Y130.154 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X97.748 Y130.154 E.13838
G1 X97.748 Y131.571 E.04354
G1 X102.252 Y131.571 E.13838
G1 X102.252 Y130.214 E.0417
G1 X102.629 Y129.777 F30000
G1 F15000
G1 X97.371 Y129.777 E.16155
G1 X97.371 Y131.948 E.06671
G1 X102.629 Y131.948 E.16155
G1 X102.629 Y129.837 E.06487
G1 X103.006 Y129.4 F30000
G1 F15000
G1 X96.994 Y129.4 E.18472
G1 X96.994 Y132.325 E.08989
G1 X103.006 Y132.325 E.18472
G1 X103.006 Y129.46 E.08804
; WIPE_START
G1 X103.006 Y131.46 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y128.287 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X103.084 Y128.785 E.02165
G1 X102.551 Y128.785
G1 X103.583 Y127.754 E.04482
G1 X103.256 Y127.547
G1 X102.018 Y128.785 E.05379
G1 X101.485 Y128.785
G1 X102.723 Y127.547 E.05379
G1 X102.189 Y127.547
G1 X100.951 Y128.785 E.05379
G1 X100.418 Y128.785
G1 X101.656 Y127.547 E.05379
G1 X101.123 Y127.547
G1 X99.885 Y128.785 E.05379
G1 X99.352 Y128.785
G1 X100.59 Y127.547 E.05379
G1 X100.056 Y127.547
G1 X98.818 Y128.785 E.05379
G1 X98.285 Y128.785
G1 X99.523 Y127.547 E.05379
G1 X98.99 Y127.547
G1 X97.752 Y128.785 E.05379
G1 X97.219 Y128.785
G1 X98.456 Y127.547 E.05379
G1 X97.923 Y127.547
G1 X96.685 Y128.785 E.05379
G1 X96.417 Y128.52
G1 X97.39 Y127.547 E.04226
G1 X96.857 Y127.547
G1 X96.417 Y127.987 E.01909
; WIPE_START
M204 S10000
G1 X96.857 Y127.547 E-.2361
G1 X97.39 Y127.547 E-.20264
G1 X96.792 Y128.145 E-.32126
; WIPE_END
G1 E-.04 F1800
G1 X104.362 Y129.124 Z6 F30000
G1 X115.803 Y130.603 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.562925
G1 F12115.27
G1 X112.197 Y130.603 E.15282
G1 X112.197 Y131.123 E.02204
G1 X115.803 Y131.123 E.15282
G1 X115.803 Y130.663 E.01949
G1 X116.252 Y130.154 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X111.748 Y130.154 E.13838
G1 X111.748 Y131.571 E.04354
G1 X116.252 Y131.571 E.13838
G1 X116.252 Y130.214 E.0417
G1 X116.629 Y129.777 F30000
G1 F15000
G1 X111.371 Y129.777 E.16155
G1 X111.371 Y131.948 E.06671
G1 X116.629 Y131.948 E.16155
G1 X116.629 Y129.837 E.06487
G1 X117.006 Y129.4 F30000
G1 F15000
G1 X110.994 Y129.4 E.18472
G1 X110.994 Y132.325 E.08989
G1 X117.006 Y132.325 E.18472
G1 X117.006 Y129.46 E.08804
; WIPE_START
G1 X117.006 Y131.46 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X117.583 Y128.152 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X116.949 Y128.785 E.02753
G1 X116.416 Y128.785
G1 X117.583 Y127.619 E.0507
G1 X117.121 Y127.547
G1 X115.883 Y128.785 E.05379
G1 X115.349 Y128.785
G1 X116.587 Y127.547 E.05379
G1 X116.054 Y127.547
G1 X114.816 Y128.785 E.05379
G1 X114.283 Y128.785
G1 X115.521 Y127.547 E.05379
G1 X114.987 Y127.547
G1 X113.75 Y128.785 E.05379
G1 X113.216 Y128.785
G1 X114.454 Y127.547 E.05379
G1 X113.921 Y127.547
G1 X112.683 Y128.785 E.05379
G1 X112.15 Y128.785
G1 X113.388 Y127.547 E.05379
G1 X112.854 Y127.547
G1 X111.617 Y128.785 E.05379
G1 X111.083 Y128.785
G1 X112.321 Y127.547 E.05379
G1 X111.788 Y127.547
G1 X110.55 Y128.785 E.05379
G1 X110.417 Y128.385
G1 X111.255 Y127.547 E.03638
; WIPE_START
M204 S10000
G1 X110.417 Y128.385 E-.44996
G1 X110.55 Y128.785 E-.16036
G1 X110.829 Y128.507 E-.14969
; WIPE_END
G1 E-.04 F1800
G1 X118.391 Y129.538 Z6 F30000
G1 X126.197 Y130.603 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56292
G1 F12115.385
G1 X126.197 Y131.123 E.02204
G1 X129.803 Y131.123 E.15282
G1 X129.803 Y130.603 E.02204
G1 X126.257 Y130.603 E.15027
G1 X125.748 Y130.154 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X125.748 Y131.571 E.04354
G1 X130.252 Y131.571 E.13838
G1 X130.252 Y130.154 E.04354
G1 X125.808 Y130.154 E.13653
G1 X125.371 Y129.777 F30000
G1 F15000
G1 X125.371 Y131.948 E.06671
G1 X130.629 Y131.948 E.16155
G1 X130.629 Y129.777 E.06671
G1 X125.431 Y129.777 E.1597
G1 X124.994 Y129.4 F30000
G1 F15000
G1 X124.994 Y132.325 E.08989
G1 X131.006 Y132.325 E.18472
G1 X131.006 Y129.4 E.08989
G1 X125.054 Y129.4 E.18288
; WIPE_START
G1 X127.054 Y129.4 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.814 Y128.785 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X131.583 Y128.017 E.03341
G1 X131.518 Y127.547
G1 X130.281 Y128.785 E.05379
G1 X129.747 Y128.785
G1 X130.985 Y127.547 E.05379
G1 X130.452 Y127.547
G1 X129.214 Y128.785 E.05379
G1 X128.681 Y128.785
G1 X129.919 Y127.547 E.05379
G1 X129.385 Y127.547
G1 X128.148 Y128.785 E.05379
G1 X127.614 Y128.785
G1 X128.852 Y127.547 E.05379
G1 X128.319 Y127.547
G1 X127.081 Y128.785 E.05379
G1 X126.548 Y128.785
G1 X127.786 Y127.547 E.05379
G1 X127.252 Y127.547
G1 X126.015 Y128.785 E.05379
G1 X125.481 Y128.785
G1 X126.719 Y127.547 E.05379
G1 X126.186 Y127.547
G1 X124.948 Y128.785 E.05379
G1 X124.417 Y128.783
G1 X125.653 Y127.547 E.05368
M73 P95 R1
G1 X125.119 Y127.547
G1 X124.417 Y128.249 E.0305
; WIPE_START
M204 S10000
G1 X125.119 Y127.547 E-.37725
G1 X125.653 Y127.547 E-.20264
G1 X125.317 Y127.883 E-.18012
; WIPE_END
G1 E-.04 F1800
G1 X132.825 Y129.255 Z6 F30000
G1 X140.197 Y130.603 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56292
G1 F12115.385
G1 X140.197 Y131.123 E.02204
G1 X143.803 Y131.123 E.15282
G1 X143.803 Y130.603 E.02204
G1 X140.257 Y130.603 E.15027
G1 X139.748 Y130.154 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X139.748 Y131.571 E.04354
G1 X144.252 Y131.571 E.13838
G1 X144.252 Y130.154 E.04354
G1 X139.808 Y130.154 E.13653
G1 X139.371 Y129.777 F30000
G1 F15000
G1 X139.371 Y131.948 E.06671
G1 X144.629 Y131.948 E.16155
G1 X144.629 Y129.777 E.06671
G1 X139.431 Y129.777 E.1597
G1 X138.994 Y129.4 F30000
G1 F15000
G1 X138.994 Y132.325 E.08989
G1 X145.006 Y132.325 E.18472
G1 X145.006 Y129.4 E.08989
G1 X139.054 Y129.4 E.18288
; WIPE_START
G1 X141.054 Y129.4 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y128.414 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.212 Y128.785 E.01611
G1 X144.679 Y128.785
G1 X145.583 Y127.881 E.03929
G1 X145.383 Y127.547
G1 X144.145 Y128.785 E.05379
G1 X143.612 Y128.785
G1 X144.85 Y127.547 E.05379
G1 X144.317 Y127.547
G1 X143.079 Y128.785 E.05379
G1 X142.545 Y128.785
G1 X143.783 Y127.547 E.05379
G1 X143.25 Y127.547
G1 X142.012 Y128.785 E.05379
G1 X141.479 Y128.785
G1 X142.717 Y127.547 E.05379
G1 X142.184 Y127.547
G1 X140.946 Y128.785 E.05379
G1 X140.412 Y128.785
G1 X141.65 Y127.547 E.05379
G1 X141.117 Y127.547
G1 X139.879 Y128.785 E.05379
G1 X139.346 Y128.785
G1 X140.584 Y127.547 E.05379
G1 X140.051 Y127.547
G1 X138.813 Y128.785 E.05379
G1 X138.417 Y128.647
G1 X139.517 Y127.547 E.0478
G1 X138.984 Y127.547
G1 X138.417 Y128.114 E.02462
; WIPE_START
M204 S10000
G1 X138.984 Y127.547 E-.30452
G1 X139.517 Y127.547 E-.20264
G1 X139.047 Y128.018 E-.25284
; WIPE_END
G1 E-.04 F1800
G1 X146.571 Y129.301 Z6 F30000
G1 X154.197 Y130.603 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56292
G1 F12115.385
G1 X154.197 Y131.123 E.02204
G1 X157.803 Y131.123 E.15282
G1 X157.803 Y130.603 E.02204
G1 X154.257 Y130.603 E.15027
G1 X153.748 Y130.154 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X153.748 Y131.571 E.04354
G1 X158.252 Y131.571 E.13838
G1 X158.252 Y130.154 E.04354
G1 X153.808 Y130.154 E.13653
G1 X153.371 Y129.777 F30000
G1 F15000
G1 X153.371 Y131.948 E.06671
G1 X158.629 Y131.948 E.16155
G1 X158.629 Y129.777 E.06671
G1 X153.431 Y129.777 E.1597
G1 X152.994 Y129.4 F30000
G1 F15000
G1 X152.994 Y132.325 E.08989
G1 X159.006 Y132.325 E.18472
G1 X159.006 Y129.4 E.08989
G1 X153.054 Y129.4 E.18288
; WIPE_START
G1 X155.054 Y129.4 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y128.279 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X159.076 Y128.785 E.02199
G1 X158.543 Y128.785
G1 X159.583 Y127.746 E.04517
G1 X159.248 Y127.547
G1 X158.01 Y128.785 E.05379
G1 X157.477 Y128.785
G1 X158.715 Y127.547 E.05379
G1 X158.181 Y127.547
G1 X156.943 Y128.785 E.05379
G1 X156.41 Y128.785
G1 X157.648 Y127.547 E.05379
G1 X157.115 Y127.547
G1 X155.877 Y128.785 E.05379
G1 X155.344 Y128.785
G1 X156.582 Y127.547 E.05379
G1 X156.048 Y127.547
G1 X154.81 Y128.785 E.05379
G1 X154.277 Y128.785
G1 X155.515 Y127.547 E.05379
G1 X154.982 Y127.547
G1 X153.744 Y128.785 E.05379
G1 X153.211 Y128.785
G1 X154.449 Y127.547 E.05379
G1 X153.915 Y127.547
G1 X152.677 Y128.785 E.05379
G1 X152.417 Y128.512
G1 X153.382 Y127.547 E.04192
G1 X152.849 Y127.547
G1 X152.417 Y127.979 E.01874
; WIPE_START
M204 S10000
G1 X152.849 Y127.547 E-.23182
G1 X153.382 Y127.547 E-.20264
G1 X152.776 Y128.153 E-.32554
; WIPE_END
G1 E-.04 F1800
G1 X160.314 Y129.35 Z6 F30000
G1 X168.197 Y130.603 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.562925
G1 F12115.269
G1 X168.197 Y131.123 E.02203
G1 X181.803 Y131.123 E.57656
G1 X181.803 Y130.603 E.02204
G1 X168.257 Y130.603 E.57401
G1 X167.748 Y130.154 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X167.748 Y131.571 E.04354
G1 X182.252 Y131.571 E.44564
G1 X182.252 Y130.154 E.04354
G1 X167.808 Y130.154 E.4438
G1 X167.371 Y129.777 F30000
G1 F15000
G1 X167.371 Y131.948 E.06671
G1 X182.629 Y131.948 E.46881
G1 X182.629 Y129.777 E.06671
G1 X167.431 Y129.777 E.46697
G1 X166.994 Y129.4 F30000
G1 F15000
G1 X166.994 Y132.325 E.08989
G1 X183.006 Y132.325 E.49198
G1 X183.006 Y129.4 E.08989
G1 X167.054 Y129.4 E.49014
; WIPE_START
G1 X169.054 Y129.4 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X176.664 Y128.811 Z6 F30000
G1 X183.583 Y128.276 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.073 Y128.785 E.02214
G1 X182.54 Y128.785
G1 X183.583 Y127.743 E.04532
G1 X183.244 Y127.547
G1 X182.007 Y128.785 E.05379
G1 X181.473 Y128.785
G1 X182.711 Y127.547 E.05379
G1 X182.178 Y127.547
G1 X180.94 Y128.785 E.05379
G1 X180.407 Y128.785
G1 X181.645 Y127.547 E.05379
G1 X181.111 Y127.547
G1 X179.874 Y128.785 E.05379
G1 X179.34 Y128.785
G1 X180.578 Y127.547 E.05379
G1 X180.045 Y127.547
G1 X178.807 Y128.785 E.05379
G1 X178.274 Y128.785
G1 X179.512 Y127.547 E.05379
G1 X178.978 Y127.547
G1 X177.74 Y128.785 E.05379
G1 X177.207 Y128.785
G1 X178.445 Y127.547 E.05379
G1 X177.912 Y127.547
G1 X176.674 Y128.785 E.05379
G1 X176.141 Y128.785
G1 X177.379 Y127.547 E.05379
G1 X176.845 Y127.547
G1 X175.607 Y128.785 E.05379
G1 X175.074 Y128.785
G1 X176.312 Y127.547 E.05379
G1 X175.779 Y127.547
G1 X174.541 Y128.785 E.05379
G1 X174.008 Y128.785
G1 X175.246 Y127.547 E.05379
G1 X174.712 Y127.547
G1 X173.474 Y128.785 E.05379
G1 X172.941 Y128.785
G1 X174.179 Y127.547 E.05379
G1 X173.646 Y127.547
G1 X172.408 Y128.785 E.05379
G1 X171.875 Y128.785
G1 X173.113 Y127.547 E.05379
G1 X172.579 Y127.547
G1 X171.341 Y128.785 E.05379
G1 X170.808 Y128.785
G1 X172.046 Y127.547 E.05379
G1 X171.513 Y127.547
G1 X170.275 Y128.785 E.05379
G1 X169.742 Y128.785
G1 X170.98 Y127.547 E.05379
G1 X170.446 Y127.547
G1 X169.208 Y128.785 E.05379
G1 X168.675 Y128.785
G1 X169.913 Y127.547 E.05379
G1 X169.38 Y127.547
G1 X168.142 Y128.785 E.05379
G1 X167.609 Y128.785
G1 X168.846 Y127.547 E.05379
G1 X168.313 Y127.547
G1 X167.075 Y128.785 E.05379
G1 X166.542 Y128.785
G1 X167.78 Y127.547 E.05379
G1 X167.247 Y127.547
G1 X166.417 Y128.377 E.03604
; CHANGE_LAYER
; Z_HEIGHT: 5.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
M204 S10000
G1 X167.247 Y127.547 E-.44568
G1 X167.78 Y127.547 E-.20264
G1 X167.572 Y127.755 E-.11169
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 29/32
; update layer progress
M73 L29
M991 S0 P28 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6 I-1.189 J-.257 P1  F30000
G1 X166.602 Y132.238 Z6
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X166.602 Y129.808 E.08061
G1 X183.398 Y129.808 E.55715
G1 X183.398 Y132.238 E.08061
G1 X166.662 Y132.238 E.55516
M204 S250
G1 X166.21 Y132.63 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X166.21 Y128.14 E.13796
G1 X183.79 Y128.14 E.54018
G1 X183.79 Y132.63 E.13796
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X166.27 Y132.63 E.53834
; WIPE_START
M204 S10000
G1 X166.243 Y130.63 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X167.817 Y131.023 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55762
G1 F12240.14
G1 X182.123 Y131.023 E.60001
G1 X167.371 Y130.577 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X167.371 Y131.469 E.0274
G1 X182.629 Y131.469 E.46881
G1 X182.629 Y130.577 E.0274
G1 X167.431 Y130.577 E.46697
G1 X166.994 Y130.2 F30000
G1 F15000
G1 X166.994 Y131.846 E.05057
G1 X183.006 Y131.846 E.49198
G1 X183.006 Y130.2 E.05057
G1 X167.054 Y130.2 E.49014
; WIPE_START
G1 X169.054 Y130.2 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X176.663 Y129.601 Z6.2 F30000
G1 X183.583 Y129.057 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X182.873 Y128.347 E.03083
G1 X182.34 Y128.347
G1 X183.578 Y129.585 E.05379
G1 X183.045 Y129.585
G1 X181.807 Y128.347 E.05379
G1 X181.273 Y128.347
G1 X182.511 Y129.585 E.05379
G1 X181.978 Y129.585
G1 X180.74 Y128.347 E.05379
G1 X180.207 Y128.347
G1 X181.445 Y129.585 E.05379
G1 X180.912 Y129.585
G1 X179.674 Y128.347 E.05379
G1 X179.14 Y128.347
G1 X180.378 Y129.585 E.05379
G1 X179.845 Y129.585
G1 X178.607 Y128.347 E.05379
G1 X178.074 Y128.347
G1 X179.312 Y129.585 E.05379
G1 X178.779 Y129.585
G1 X177.541 Y128.347 E.05379
G1 X177.007 Y128.347
G1 X178.245 Y129.585 E.05379
G1 X177.712 Y129.585
G1 X176.474 Y128.347 E.05379
G1 X175.941 Y128.347
G1 X177.179 Y129.585 E.05379
G1 X176.645 Y129.585
G1 X175.408 Y128.347 E.05379
G1 X174.874 Y128.347
G1 X176.112 Y129.585 E.05379
G1 X175.579 Y129.585
G1 X174.341 Y128.347 E.05379
G1 X173.808 Y128.347
G1 X175.046 Y129.585 E.05379
G1 X174.512 Y129.585
G1 X173.275 Y128.347 E.05379
G1 X172.741 Y128.347
G1 X173.979 Y129.585 E.05379
G1 X173.446 Y129.585
G1 X172.208 Y128.347 E.05379
G1 X171.675 Y128.347
G1 X172.913 Y129.585 E.05379
G1 X172.379 Y129.585
G1 X171.142 Y128.347 E.05379
G1 X170.608 Y128.347
G1 X171.846 Y129.585 E.05379
G1 X171.313 Y129.585
G1 X170.075 Y128.347 E.05379
G1 X169.542 Y128.347
G1 X170.78 Y129.585 E.05379
G1 X170.246 Y129.585
G1 X169.009 Y128.347 E.05379
G1 X168.475 Y128.347
G1 X169.713 Y129.585 E.05379
G1 X169.18 Y129.585
G1 X167.942 Y128.347 E.05379
G1 X167.409 Y128.347
G1 X168.647 Y129.585 E.05379
G1 X168.113 Y129.585
G1 X166.875 Y128.347 E.05379
G1 X166.417 Y128.423
G1 X167.58 Y129.585 E.05053
G1 X167.047 Y129.585
G1 X166.417 Y128.956 E.02735
; WIPE_START
M204 S10000
G1 X167.047 Y129.585 E-.33828
G1 X167.58 Y129.585 E-.20264
G1 X167.172 Y129.178 E-.21909
; WIPE_END
G1 E-.04 F1800
G1 X159.703 Y130.746 Z6.2 F30000
G1 X152.602 Y132.238 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X152.602 Y129.808 E.08061
G1 X159.398 Y129.808 E.22543
G1 X159.398 Y132.238 E.08061
G1 X152.662 Y132.238 E.22344
M204 S250
G1 X152.21 Y132.63 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X152.21 Y128.14 E.13796
G1 X159.79 Y128.14 E.23291
G1 X159.79 Y132.63 E.13796
G1 X152.27 Y132.63 E.23107
; WIPE_START
M204 S10000
G1 X152.243 Y130.63 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X153.817 Y131.023 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55762
G1 F12240.14
G1 X158.123 Y131.023 E.18059
G1 X153.371 Y130.577 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X153.371 Y131.469 E.0274
G1 X158.629 Y131.469 E.16155
G1 X158.629 Y130.577 E.0274
G1 X153.431 Y130.577 E.1597
G1 X152.994 Y130.2 F30000
G1 F15000
G1 X152.994 Y131.846 E.05057
G1 X159.006 Y131.846 E.18472
G1 X159.006 Y130.2 E.05057
G1 X153.054 Y130.2 E.18288
; WIPE_START
G1 X155.054 Y130.2 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y129.053 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X158.877 Y128.347 E.03068
G1 X158.343 Y128.347
G1 X159.581 Y129.585 E.05379
G1 X159.048 Y129.585
G1 X157.81 Y128.347 E.05379
G1 X157.277 Y128.347
G1 X158.515 Y129.585 E.05379
G1 X157.981 Y129.585
G1 X156.744 Y128.347 E.05379
G1 X156.21 Y128.347
G1 X157.448 Y129.585 E.05379
G1 X156.915 Y129.585
G1 X155.677 Y128.347 E.05379
G1 X155.144 Y128.347
G1 X156.382 Y129.585 E.05379
G1 X155.848 Y129.585
G1 X154.611 Y128.347 E.05379
G1 X154.077 Y128.347
G1 X155.315 Y129.585 E.05379
G1 X154.782 Y129.585
G1 X153.544 Y128.347 E.05379
G1 X153.011 Y128.347
G1 X154.249 Y129.585 E.05379
G1 X153.715 Y129.585
G1 X152.478 Y128.347 E.05379
G1 X152.417 Y128.821
G1 X153.182 Y129.585 E.03323
; WIPE_START
M204 S10000
G1 X152.417 Y128.821 E-.41099
G1 X152.478 Y128.347 E-.18123
G1 X152.79 Y128.66 E-.16777
; WIPE_END
G1 E-.04 F1800
G1 X145.389 Y130.526 Z6.2 F30000
G1 X138.602 Y132.238 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y129.808 E.08061
G1 X145.398 Y129.808 E.22543
G1 X145.398 Y132.238 E.08061
G1 X138.662 Y132.238 E.22344
M204 S250
G1 X138.21 Y132.63 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y128.14 E.13796
G1 X145.79 Y128.14 E.23291
G1 X145.79 Y132.63 E.13796
G1 X138.27 Y132.63 E.23107
; WIPE_START
M204 S10000
G1 X138.243 Y130.63 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X139.817 Y131.023 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55762
G1 F12240.14
G1 X144.123 Y131.023 E.18059
G1 X139.371 Y130.577 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X139.371 Y131.469 E.0274
G1 X144.629 Y131.469 E.16155
G1 X144.629 Y130.577 E.0274
G1 X139.431 Y130.577 E.1597
G1 X138.994 Y130.2 F30000
G1 F15000
G1 X138.994 Y131.846 E.05057
G1 X145.006 Y131.846 E.18472
G1 X145.006 Y130.2 E.05057
G1 X139.054 Y130.2 E.18288
; WIPE_START
G1 X141.054 Y130.2 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y128.918 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.012 Y128.347 E.0248
G1 X144.479 Y128.347
G1 X145.583 Y129.451 E.04797
G1 X145.183 Y129.585
G1 X143.945 Y128.347 E.05379
G1 X143.412 Y128.347
G1 X144.65 Y129.585 E.05379
G1 X144.117 Y129.585
G1 X142.879 Y128.347 E.05379
G1 X142.346 Y128.347
G1 X143.584 Y129.585 E.05379
G1 X143.05 Y129.585
G1 X141.812 Y128.347 E.05379
G1 X141.279 Y128.347
G1 X142.517 Y129.585 E.05379
G1 X141.984 Y129.585
G1 X140.746 Y128.347 E.05379
G1 X140.213 Y128.347
G1 X141.451 Y129.585 E.05379
G1 X140.917 Y129.585
G1 X139.679 Y128.347 E.05379
G1 X139.146 Y128.347
G1 X140.384 Y129.585 E.05379
G1 X139.851 Y129.585
G1 X138.613 Y128.347 E.05379
G1 X138.417 Y128.685
G1 X139.317 Y129.585 E.03911
G1 X138.784 Y129.585
G1 X138.417 Y129.218 E.01594
; WIPE_START
M204 S10000
G1 X138.784 Y129.585 E-.19713
G1 X139.317 Y129.585 E-.20264
G1 X138.647 Y128.915 E-.36024
; WIPE_END
G1 E-.04 F1800
G1 X131.22 Y130.672 Z6.2 F30000
G1 X124.602 Y132.238 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.602 Y129.808 E.08061
G1 X131.398 Y129.808 E.22543
G1 X131.398 Y132.238 E.08061
G1 X124.662 Y132.238 E.22344
M204 S250
G1 X124.21 Y132.63 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X124.21 Y128.14 E.13796
G1 X131.79 Y128.14 E.23291
G1 X131.79 Y132.63 E.13796
G1 X124.27 Y132.63 E.23107
; WIPE_START
M204 S10000
G1 X124.243 Y130.63 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X125.817 Y131.023 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55762
G1 F12240.14
G1 X130.123 Y131.023 E.18059
G1 X125.371 Y130.577 F30000
; LINE_WIDTH: 0.41999
M73 P96 R1
G1 F15000
G1 X125.371 Y131.469 E.0274
G1 X130.629 Y131.469 E.16155
G1 X130.629 Y130.577 E.0274
G1 X125.431 Y130.577 E.1597
G1 X124.994 Y130.2 F30000
G1 F15000
G1 X124.994 Y131.846 E.05057
G1 X131.006 Y131.846 E.18472
G1 X131.006 Y130.2 E.05057
G1 X125.054 Y130.2 E.18288
; WIPE_START
G1 X127.054 Y130.2 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.583 Y128.783 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X131.147 Y128.347 E.01892
G1 X130.614 Y128.347
G1 X131.583 Y129.316 E.04209
G1 X131.319 Y129.585
G1 X130.081 Y128.347 E.05379
G1 X129.547 Y128.347
G1 X130.785 Y129.585 E.05379
G1 X130.252 Y129.585
G1 X129.014 Y128.347 E.05379
G1 X128.481 Y128.347
G1 X129.719 Y129.585 E.05379
G1 X129.186 Y129.585
G1 X127.948 Y128.347 E.05379
G1 X127.414 Y128.347
G1 X128.652 Y129.585 E.05379
G1 X128.119 Y129.585
G1 X126.881 Y128.347 E.05379
G1 X126.348 Y128.347
G1 X127.586 Y129.585 E.05379
G1 X127.053 Y129.585
G1 X125.815 Y128.347 E.05379
G1 X125.281 Y128.347
G1 X126.519 Y129.585 E.05379
G1 X125.986 Y129.585
G1 X124.748 Y128.347 E.05379
G1 X124.417 Y128.55
G1 X125.453 Y129.585 E.04499
G1 X124.92 Y129.585
G1 X124.417 Y129.083 E.02182
; WIPE_START
M204 S10000
G1 X124.92 Y129.585 E-.26985
G1 X125.453 Y129.585 E-.20264
G1 X124.918 Y129.05 E-.28752
; WIPE_END
G1 E-.04 F1800
G1 X117.468 Y130.709 Z6.2 F30000
G1 X110.602 Y132.238 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y129.808 E.08061
G1 X117.398 Y129.808 E.22543
G1 X117.398 Y132.238 E.08061
G1 X110.662 Y132.238 E.22344
M204 S250
G1 X110.21 Y132.63 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X110.21 Y128.14 E.13796
G1 X117.79 Y128.14 E.23291
G1 X117.79 Y132.63 E.13796
G1 X110.27 Y132.63 E.23107
; WIPE_START
M204 S10000
G1 X110.243 Y130.63 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X111.817 Y131.023 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55762
G1 F12240.14
G1 X116.123 Y131.023 E.18059
G1 X116.629 Y130.577 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X111.371 Y130.577 E.16155
G1 X111.371 Y131.469 E.0274
G1 X116.629 Y131.469 E.16155
G1 X116.629 Y130.637 E.02556
G1 X117.006 Y130.2 F30000
G1 F15000
G1 X110.994 Y130.2 E.18472
G1 X110.994 Y131.846 E.05057
G1 X117.006 Y131.846 E.18472
G1 X117.006 Y130.26 E.04873
; WIPE_START
G1 X117.006 Y131.846 E-.60265
G1 X116.592 Y131.846 E-.15735
; WIPE_END
G1 E-.04 F1800
G1 X116.749 Y128.347 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X117.583 Y129.181 E.03621
G1 X117.454 Y129.585
G1 X116.216 Y128.347 E.05379
G1 X115.683 Y128.347
G1 X116.921 Y129.585 E.05379
G1 X116.387 Y129.585
G1 X115.15 Y128.347 E.05379
G1 X114.616 Y128.347
G1 X115.854 Y129.585 E.05379
G1 X115.321 Y129.585
G1 X114.083 Y128.347 E.05379
G1 X113.55 Y128.347
G1 X114.788 Y129.585 E.05379
G1 X114.254 Y129.585
G1 X113.016 Y128.347 E.05379
G1 X112.483 Y128.347
G1 X113.721 Y129.585 E.05379
G1 X113.188 Y129.585
G1 X111.95 Y128.347 E.05379
G1 X111.417 Y128.347
G1 X112.655 Y129.585 E.05379
G1 X112.121 Y129.585
G1 X110.883 Y128.347 E.05379
G1 X110.417 Y128.415
G1 X111.588 Y129.585 E.05087
G1 X111.055 Y129.585
G1 X110.417 Y128.948 E.0277
; WIPE_START
M204 S10000
G1 X111.055 Y129.585 E-.34256
G1 X111.588 Y129.585 E-.20264
G1 X111.188 Y129.186 E-.2148
; WIPE_END
G1 E-.04 F1800
G1 X103.718 Y130.749 Z6.2 F30000
G1 X96.602 Y132.238 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X96.602 Y129.808 E.08061
G1 X103.398 Y129.808 E.22543
G1 X103.398 Y132.238 E.08061
G1 X96.662 Y132.238 E.22344
M204 S250
G1 X96.21 Y132.63 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X96.21 Y128.14 E.13796
G1 X103.79 Y128.14 E.23291
G1 X103.79 Y132.63 E.13796
G1 X96.27 Y132.63 E.23107
; WIPE_START
M204 S10000
G1 X96.243 Y130.63 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X97.817 Y131.023 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55762
G1 F12240.14
G1 X102.123 Y131.023 E.18059
G1 X102.629 Y130.577 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X97.371 Y130.577 E.16155
G1 X97.371 Y131.469 E.0274
G1 X102.629 Y131.469 E.16155
G1 X102.629 Y130.637 E.02556
G1 X103.006 Y130.2 F30000
G1 F15000
G1 X96.994 Y130.2 E.18472
G1 X96.994 Y131.846 E.05057
G1 X103.006 Y131.846 E.18472
G1 X103.006 Y130.26 E.04873
; WIPE_START
G1 X103.006 Y131.846 E-.60265
G1 X102.592 Y131.846 E-.15735
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y129.045 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X102.885 Y128.347 E.03033
G1 X102.351 Y128.347
G1 X103.583 Y129.579 E.05351
G1 X103.056 Y129.585
G1 X101.818 Y128.347 E.05379
G1 X101.285 Y128.347
G1 X102.523 Y129.585 E.05379
G1 X101.989 Y129.585
G1 X100.752 Y128.347 E.05379
G1 X100.218 Y128.347
G1 X101.456 Y129.585 E.05379
G1 X100.923 Y129.585
G1 X99.685 Y128.347 E.05379
G1 X99.152 Y128.347
G1 X100.39 Y129.585 E.05379
G1 X99.856 Y129.585
G1 X98.619 Y128.347 E.05379
G1 X98.085 Y128.347
G1 X99.323 Y129.585 E.05379
G1 X98.79 Y129.585
G1 X97.552 Y128.347 E.05379
G1 X97.019 Y128.347
G1 X98.257 Y129.585 E.05379
G1 X97.723 Y129.585
G1 X96.485 Y128.347 E.05379
G1 X96.417 Y128.813
G1 X97.19 Y129.585 E.03358
; WIPE_START
M204 S10000
G1 X96.417 Y128.813 E-.41527
G1 X96.485 Y128.347 E-.17864
G1 X96.795 Y128.656 E-.16609
; WIPE_END
G1 E-.04 F1800
G1 X89.925 Y131.983 Z6.2 F30000
G1 X89.398 Y132.238 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y132.238 E.55715
G1 X72.602 Y129.808 E.08061
G1 X89.398 Y129.808 E.55715
G1 X89.398 Y132.178 E.07862
M204 S250
G1 X89.79 Y132.63 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y132.63 E.54018
G1 X72.21 Y128.14 E.13796
G1 X89.79 Y128.14 E.54018
G1 X89.79 Y132.57 E.13612
; WIPE_START
M204 S10000
G1 X87.79 Y132.577 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.583 Y128.91 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X89.02 Y128.347 E.02445
G1 X88.487 Y128.347
G1 X89.583 Y129.443 E.04763
G1 X89.191 Y129.585
G1 X87.953 Y128.347 E.05379
G1 X87.42 Y128.347
G1 X88.658 Y129.585 E.05379
G1 X88.125 Y129.585
G1 X86.887 Y128.347 E.05379
G1 X86.354 Y128.347
G1 X87.592 Y129.585 E.05379
G1 X87.058 Y129.585
G1 X85.82 Y128.347 E.05379
G1 X85.287 Y128.347
G1 X86.525 Y129.585 E.05379
G1 X85.992 Y129.585
G1 X84.754 Y128.347 E.05379
G1 X84.221 Y128.347
G1 X85.458 Y129.585 E.05379
G1 X84.925 Y129.585
G1 X83.687 Y128.347 E.05379
G1 X83.154 Y128.347
G1 X84.392 Y129.585 E.05379
G1 X83.859 Y129.585
G1 X82.621 Y128.347 E.05379
G1 X82.088 Y128.347
G1 X83.325 Y129.585 E.05379
G1 X82.792 Y129.585
G1 X81.554 Y128.347 E.05379
G1 X81.021 Y128.347
G1 X82.259 Y129.585 E.05379
G1 X81.726 Y129.585
G1 X80.488 Y128.347 E.05379
G1 X79.955 Y128.347
G1 X81.192 Y129.585 E.05379
G1 X80.659 Y129.585
G1 X79.421 Y128.347 E.05379
G1 X78.888 Y128.347
G1 X80.126 Y129.585 E.05379
G1 X79.593 Y129.585
G1 X78.355 Y128.347 E.05379
G1 X77.821 Y128.347
G1 X79.059 Y129.585 E.05379
G1 X78.526 Y129.585
G1 X77.288 Y128.347 E.05379
G1 X76.755 Y128.347
G1 X77.993 Y129.585 E.05379
G1 X77.46 Y129.585
G1 X76.222 Y128.347 E.05379
G1 X75.688 Y128.347
G1 X76.926 Y129.585 E.05379
G1 X76.393 Y129.585
G1 X75.155 Y128.347 E.05379
G1 X74.622 Y128.347
G1 X75.86 Y129.585 E.05379
G1 X75.327 Y129.585
G1 X74.089 Y128.347 E.05379
M73 P96 R0
G1 X73.555 Y128.347
G1 X74.793 Y129.585 E.05379
G1 X74.26 Y129.585
G1 X73.022 Y128.347 E.05379
G1 X72.489 Y128.347
G1 X73.727 Y129.585 E.05379
G1 X73.194 Y129.585
G1 X72.417 Y128.809 E.03373
; WIPE_START
M204 S10000
G1 X73.194 Y129.585 E-.41711
G1 X73.727 Y129.585 E-.20264
G1 X73.466 Y129.324 E-.14025
; WIPE_END
G1 E-.04 F1800
G1 X73.817 Y131.023 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55762
G1 F12240.14
G1 X88.123 Y131.023 E.60001
G1 X88.629 Y130.577 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X73.371 Y130.577 E.46881
G1 X73.371 Y131.469 E.0274
G1 X88.629 Y131.469 E.46881
G1 X88.629 Y130.637 E.02556
G1 X89.006 Y130.2 F30000
G1 F15000
G1 X72.994 Y130.2 E.49198
G1 X72.994 Y131.846 E.05057
G1 X89.006 Y131.846 E.49198
G1 X89.006 Y130.26 E.04873
; CHANGE_LAYER
; Z_HEIGHT: 6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X89.006 Y131.846 E-.60265
G1 X88.592 Y131.846 E-.15735
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 30/32
; update layer progress
M73 L30
M991 S0 P29 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6.2 I.001 J1.217 P1  F30000
G1 X166.602 Y131.758 Z6.2
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X166.602 Y130.608 E.03817
G1 X183.398 Y130.608 E.55715
G1 X183.398 Y131.758 E.03817
G1 X166.662 Y131.758 E.55516
M204 S250
G1 X166.21 Y132.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X166.21 Y128.94 E.09865
G1 X183.79 Y128.94 E.54018
G1 X183.79 Y132.15 E.09865
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X166.27 Y132.15 E.53834
; WIPE_START
M204 S10000
G1 X166.233 Y130.151 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X166.991 Y130.997 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41468
G1 F15000
G1 X166.991 Y131.369 E.01126
G1 X183.009 Y131.369 E.48522
G1 X183.009 Y130.997 E.01126
G1 X167.051 Y130.997 E.4834
; WIPE_START
G1 X169.051 Y130.997 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X176.661 Y130.41 Z6.4 F30000
G1 X183.583 Y129.876 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X183.073 Y130.385 E.02215
G1 X182.54 Y130.385
G1 X183.583 Y129.342 E.04533
G1 X183.244 Y129.147
G1 X182.006 Y130.385 E.05379
G1 X181.473 Y130.385
G1 X182.711 Y129.147 E.05379
G1 X182.178 Y129.147
G1 X180.94 Y130.385 E.05379
G1 X180.407 Y130.385
G1 X181.644 Y129.147 E.05379
G1 X181.111 Y129.147
G1 X179.873 Y130.385 E.05379
G1 X179.34 Y130.385
G1 X180.578 Y129.147 E.05379
G1 X180.045 Y129.147
G1 X178.807 Y130.385 E.05379
G1 X178.274 Y130.385
G1 X179.511 Y129.147 E.05379
G1 X178.978 Y129.147
G1 X177.74 Y130.385 E.05379
G1 X177.207 Y130.385
G1 X178.445 Y129.147 E.05379
G1 X177.912 Y129.147
G1 X176.674 Y130.385 E.05379
G1 X176.14 Y130.385
G1 X177.378 Y129.147 E.05379
G1 X176.845 Y129.147
G1 X175.607 Y130.385 E.05379
G1 X175.074 Y130.385
G1 X176.312 Y129.147 E.05379
G1 X175.779 Y129.147
G1 X174.541 Y130.385 E.05379
G1 X174.007 Y130.385
G1 X175.245 Y129.147 E.05379
G1 X174.712 Y129.147
G1 X173.474 Y130.385 E.05379
G1 X172.941 Y130.385
G1 X174.179 Y129.147 E.05379
G1 X173.646 Y129.147
G1 X172.408 Y130.385 E.05379
G1 X171.874 Y130.385
G1 X173.112 Y129.147 E.05379
G1 X172.579 Y129.147
G1 X171.341 Y130.385 E.05379
G1 X170.808 Y130.385
G1 X172.046 Y129.147 E.05379
G1 X171.513 Y129.147
G1 X170.275 Y130.385 E.05379
G1 X169.741 Y130.385
G1 X170.979 Y129.147 E.05379
G1 X170.446 Y129.147
G1 X169.208 Y130.385 E.05379
G1 X168.675 Y130.385
G1 X169.913 Y129.147 E.05379
G1 X169.38 Y129.147
G1 X168.142 Y130.385 E.05379
G1 X167.608 Y130.385
G1 X168.846 Y129.147 E.05379
G1 X168.313 Y129.147
G1 X167.075 Y130.385 E.05379
G1 X166.542 Y130.385
G1 X167.78 Y129.147 E.05379
G1 X167.246 Y129.147
G1 X166.417 Y129.977 E.03603
; WIPE_START
M204 S10000
G1 X167.246 Y129.147 E-.44556
G1 X167.78 Y129.147 E-.20264
G1 X167.572 Y129.355 E-.1118
; WIPE_END
G1 E-.04 F1800
G1 X160.036 Y130.565 Z6.4 F30000
G1 X152.602 Y131.758 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X152.602 Y130.608 E.03817
G1 X159.398 Y130.608 E.22543
G1 X159.398 Y131.758 E.03817
G1 X152.662 Y131.758 E.22344
M204 S250
G1 X152.21 Y132.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X152.21 Y128.94 E.09865
G1 X159.79 Y128.94 E.23291
G1 X159.79 Y132.15 E.09865
G1 X152.27 Y132.15 E.23107
; WIPE_START
M204 S10000
G1 X152.233 Y130.151 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X152.991 Y130.997 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41468
G1 F15000
G1 X152.991 Y131.369 E.01126
G1 X159.009 Y131.369 E.18228
G1 X159.009 Y130.997 E.01126
G1 X153.051 Y130.997 E.18046
; WIPE_START
G1 X155.051 Y130.997 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X159.583 Y129.879 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X159.076 Y130.385 E.022
G1 X158.543 Y130.385
G1 X159.583 Y129.346 E.04518
G1 X159.248 Y129.147
G1 X158.01 Y130.385 E.05379
G1 X157.476 Y130.385
G1 X158.714 Y129.147 E.05379
G1 X158.181 Y129.147
G1 X156.943 Y130.385 E.05379
G1 X156.41 Y130.385
G1 X157.648 Y129.147 E.05379
G1 X157.115 Y129.147
G1 X155.877 Y130.385 E.05379
G1 X155.343 Y130.385
G1 X156.581 Y129.147 E.05379
G1 X156.048 Y129.147
G1 X154.81 Y130.385 E.05379
G1 X154.277 Y130.385
G1 X155.515 Y129.147 E.05379
G1 X154.982 Y129.147
G1 X153.744 Y130.385 E.05379
G1 X153.21 Y130.385
G1 X154.448 Y129.147 E.05379
G1 X153.915 Y129.147
G1 X152.677 Y130.385 E.05379
G1 X152.417 Y130.112
G1 X153.382 Y129.147 E.04191
G1 X152.849 Y129.147
G1 X152.417 Y129.579 E.01874
; WIPE_START
M204 S10000
G1 X152.849 Y129.147 E-.2317
G1 X153.382 Y129.147 E-.20264
G1 X152.776 Y129.753 E-.32567
; WIPE_END
G1 E-.04 F1800
G1 X145.219 Y130.822 Z6.4 F30000
G1 X138.602 Y131.758 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X138.602 Y130.608 E.03817
G1 X145.398 Y130.608 E.22543
G1 X145.398 Y131.758 E.03817
G1 X138.662 Y131.758 E.22344
M204 S250
G1 X138.21 Y132.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X138.21 Y128.94 E.09865
G1 X145.79 Y128.94 E.23291
G1 X145.79 Y132.15 E.09865
G1 X138.27 Y132.15 E.23107
; WIPE_START
M204 S10000
G1 X138.233 Y130.151 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.991 Y130.997 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41468
G1 F15000
G1 X138.991 Y131.369 E.01126
G1 X145.009 Y131.369 E.18228
G1 X145.009 Y130.997 E.01126
G1 X139.051 Y130.997 E.18046
; WIPE_START
G1 X141.051 Y130.997 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.583 Y130.014 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.212 Y130.385 E.01613
G1 X144.678 Y130.385
G1 X145.583 Y129.481 E.0393
M73 P97 R0
G1 X145.383 Y129.147
G1 X144.145 Y130.385 E.05379
G1 X143.612 Y130.385
G1 X144.85 Y129.147 E.05379
G1 X144.316 Y129.147
G1 X143.079 Y130.385 E.05379
G1 X142.545 Y130.385
G1 X143.783 Y129.147 E.05379
G1 X143.25 Y129.147
G1 X142.012 Y130.385 E.05379
G1 X141.479 Y130.385
G1 X142.717 Y129.147 E.05379
G1 X142.183 Y129.147
G1 X140.945 Y130.385 E.05379
G1 X140.412 Y130.385
G1 X141.65 Y129.147 E.05379
G1 X141.117 Y129.147
G1 X139.879 Y130.385 E.05379
G1 X139.346 Y130.385
G1 X140.584 Y129.147 E.05379
G1 X140.05 Y129.147
G1 X138.812 Y130.385 E.05379
G1 X138.417 Y130.247
G1 X139.517 Y129.147 E.04779
G1 X138.984 Y129.147
G1 X138.417 Y129.714 E.02461
; WIPE_START
M204 S10000
G1 X138.984 Y129.147 E-.3044
G1 X139.517 Y129.147 E-.20264
G1 X139.046 Y129.618 E-.25296
; WIPE_END
G1 E-.04 F1800
G1 X131.496 Y130.737 Z6.4 F30000
G1 X124.602 Y131.758 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.602 Y130.608 E.03817
G1 X131.398 Y130.608 E.22543
G1 X131.398 Y131.758 E.03817
G1 X124.662 Y131.758 E.22344
M204 S250
G1 X124.21 Y132.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X124.21 Y128.94 E.09865
G1 X131.79 Y128.94 E.23291
G1 X131.79 Y132.15 E.09865
G1 X124.27 Y132.15 E.23107
; WIPE_START
M204 S10000
G1 X124.233 Y130.151 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X124.991 Y130.997 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41468
G1 F15000
G1 X124.991 Y131.369 E.01126
G1 X131.009 Y131.369 E.18228
G1 X131.009 Y130.997 E.01126
G1 X125.051 Y130.997 E.18046
; WIPE_START
G1 X127.051 Y130.997 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.814 Y130.385 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X131.583 Y129.616 E.03342
G1 X131.518 Y129.147
G1 X130.28 Y130.385 E.05379
G1 X129.747 Y130.385
G1 X130.985 Y129.147 E.05379
G1 X130.452 Y129.147
G1 X129.214 Y130.385 E.05379
G1 X128.681 Y130.385
G1 X129.918 Y129.147 E.05379
G1 X129.385 Y129.147
G1 X128.147 Y130.385 E.05379
G1 X127.614 Y130.385
G1 X128.852 Y129.147 E.05379
G1 X128.319 Y129.147
G1 X127.081 Y130.385 E.05379
G1 X126.548 Y130.385
G1 X127.785 Y129.147 E.05379
G1 X127.252 Y129.147
G1 X126.014 Y130.385 E.05379
G1 X125.481 Y130.385
G1 X126.719 Y129.147 E.05379
G1 X126.186 Y129.147
G1 X124.948 Y130.385 E.05379
G1 X124.417 Y130.382
G1 X125.652 Y129.147 E.05367
G1 X125.119 Y129.147
G1 X124.417 Y129.849 E.03049
; WIPE_START
M204 S10000
G1 X125.119 Y129.147 E-.37712
G1 X125.652 Y129.147 E-.20264
G1 X125.317 Y129.483 E-.18024
; WIPE_END
G1 E-.04 F1800
G1 X117.774 Y130.649 Z6.4 F30000
G1 X110.602 Y131.758 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X110.602 Y130.608 E.03817
G1 X117.398 Y130.608 E.22543
G1 X117.398 Y131.758 E.03817
G1 X110.662 Y131.758 E.22344
M204 S250
G1 X110.21 Y132.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X110.21 Y128.94 E.09865
G1 X117.79 Y128.94 E.23291
G1 X117.79 Y132.15 E.09865
G1 X110.27 Y132.15 E.23107
; WIPE_START
M204 S10000
G1 X110.233 Y130.151 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X117.009 Y130.997 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.414685
G1 F15000
G1 X110.991 Y130.997 E.18228
G1 X110.991 Y131.369 E.01126
G1 X117.009 Y131.369 E.18228
G1 X117.009 Y131.057 E.00944
; WIPE_START
G1 X117.009 Y131.369 E-.11847
G1 X115.32 Y131.369 E-.64153
; WIPE_END
G1 E-.04 F1800
G1 X117.583 Y129.752 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X116.949 Y130.385 E.02754
G1 X116.416 Y130.385
G1 X117.583 Y129.218 E.05071
G1 X117.12 Y129.147
G1 X115.882 Y130.385 E.05379
G1 X115.349 Y130.385
G1 X116.587 Y129.147 E.05379
G1 X116.054 Y129.147
G1 X114.816 Y130.385 E.05379
G1 X114.283 Y130.385
G1 X115.521 Y129.147 E.05379
G1 X114.987 Y129.147
G1 X113.749 Y130.385 E.05379
G1 X113.216 Y130.385
G1 X114.454 Y129.147 E.05379
G1 X113.921 Y129.147
G1 X112.683 Y130.385 E.05379
G1 X112.15 Y130.385
G1 X113.387 Y129.147 E.05379
G1 X112.854 Y129.147
G1 X111.616 Y130.385 E.05379
G1 X111.083 Y130.385
G1 X112.321 Y129.147 E.05379
G1 X111.788 Y129.147
G1 X110.55 Y130.385 E.05379
G1 X110.417 Y129.984
G1 X111.254 Y129.147 E.03637
; WIPE_START
M204 S10000
G1 X110.417 Y129.984 E-.44983
G1 X110.55 Y130.385 E-.16041
G1 X110.828 Y130.107 E-.14976
; WIPE_END
G1 E-.03999 F1800
G1 X103.398 Y131.758 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X96.602 Y131.758 E.22543
G1 X96.602 Y130.608 E.03817
G1 X103.398 Y130.608 E.22543
G1 X103.398 Y131.698 E.03618
M204 S250
G1 X103.79 Y132.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X96.21 Y132.15 E.23291
G1 X96.21 Y128.94 E.09865
G1 X103.79 Y128.94 E.23291
G1 X103.79 Y132.09 E.0968
; WIPE_START
M204 S10000
G1 X101.79 Y132.106 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X103.009 Y130.997 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.414685
G1 F15000
G1 X96.991 Y130.997 E.18228
G1 X96.991 Y131.369 E.01126
G1 X103.009 Y131.369 E.18228
G1 X103.009 Y131.057 E.00944
; WIPE_START
G1 X103.009 Y131.369 E-.11847
G1 X101.32 Y131.369 E-.64153
; WIPE_END
G1 E-.04 F1800
G1 X103.583 Y129.887 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X103.084 Y130.385 E.02166
G1 X102.551 Y130.385
G1 X103.583 Y129.354 E.04483
G1 X103.256 Y129.147
G1 X102.018 Y130.385 E.05379
G1 X101.484 Y130.385
G1 X102.722 Y129.147 E.05379
G1 X102.189 Y129.147
G1 X100.951 Y130.385 E.05379
G1 X100.418 Y130.385
G1 X101.656 Y129.147 E.05379
G1 X101.123 Y129.147
G1 X99.885 Y130.385 E.05379
G1 X99.351 Y130.385
G1 X100.589 Y129.147 E.05379
G1 X100.056 Y129.147
G1 X98.818 Y130.385 E.05379
G1 X98.285 Y130.385
G1 X99.523 Y129.147 E.05379
G1 X98.99 Y129.147
G1 X97.752 Y130.385 E.05379
G1 X97.218 Y130.385
G1 X98.456 Y129.147 E.05379
G1 X97.923 Y129.147
G1 X96.685 Y130.385 E.05379
G1 X96.417 Y130.12
G1 X97.39 Y129.147 E.04225
G1 X96.856 Y129.147
G1 X96.417 Y129.587 E.01908
; WIPE_START
M204 S10000
G1 X96.856 Y129.147 E-.23597
G1 X97.39 Y129.147 E-.20264
G1 X96.792 Y129.745 E-.32139
; WIPE_END
G1 E-.04 F1800
G1 X89.427 Y131.75 Z6.4 F30000
G1 X89.398 Y131.758 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X72.602 Y131.758 E.55715
G1 X72.602 Y130.608 E.03817
G1 X89.398 Y130.608 E.55715
G1 X89.398 Y131.698 E.03618
M204 S250
G1 X89.79 Y132.15 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X72.21 Y132.15 E.54018
G1 X72.21 Y128.94 E.09865
G1 X89.79 Y128.94 E.54018
G1 X89.79 Y132.09 E.0968
; WIPE_START
M204 S10000
G1 X87.79 Y132.097 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.009 Y130.997 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41468
G1 F15000
G1 X72.991 Y130.997 E.48522
G1 X72.991 Y131.369 E.01126
G1 X89.009 Y131.369 E.48522
G1 X89.009 Y131.057 E.00944
G1 X89.22 Y130.385 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.583 Y130.022 E.01578
G1 X89.583 Y129.489
G1 X88.686 Y130.385 E.03895
G1 X88.153 Y130.385
G1 X89.391 Y129.147 E.05379
G1 X88.858 Y129.147
G1 X87.62 Y130.385 E.05379
G1 X87.086 Y130.385
G1 X88.324 Y129.147 E.05379
G1 X87.791 Y129.147
G1 X86.553 Y130.385 E.05379
G1 X86.02 Y130.385
G1 X87.258 Y129.147 E.05379
G1 X86.725 Y129.147
G1 X85.487 Y130.385 E.05379
G1 X84.953 Y130.385
G1 X86.191 Y129.147 E.05379
G1 X85.658 Y129.147
G1 X84.42 Y130.385 E.05379
G1 X83.887 Y130.385
G1 X85.125 Y129.147 E.05379
G1 X84.592 Y129.147
G1 X83.354 Y130.385 E.05379
G1 X82.82 Y130.385
G1 X84.058 Y129.147 E.05379
G1 X83.525 Y129.147
G1 X82.287 Y130.385 E.05379
G1 X81.754 Y130.385
G1 X82.992 Y129.147 E.05379
G1 X82.459 Y129.147
G1 X81.221 Y130.385 E.05379
G1 X80.687 Y130.385
G1 X81.925 Y129.147 E.05379
G1 X81.392 Y129.147
G1 X80.154 Y130.385 E.05379
G1 X79.621 Y130.385
G1 X80.859 Y129.147 E.05379
G1 X80.325 Y129.147
G1 X79.088 Y130.385 E.05379
G1 X78.554 Y130.385
G1 X79.792 Y129.147 E.05379
G1 X79.259 Y129.147
G1 X78.021 Y130.385 E.05379
G1 X77.488 Y130.385
G1 X78.726 Y129.147 E.05379
G1 X78.192 Y129.147
G1 X76.955 Y130.385 E.05379
G1 X76.421 Y130.385
G1 X77.659 Y129.147 E.05379
G1 X77.126 Y129.147
G1 X75.888 Y130.385 E.05379
G1 X75.355 Y130.385
G1 X76.593 Y129.147 E.05379
G1 X76.059 Y129.147
G1 X74.822 Y130.385 E.05379
G1 X74.288 Y130.385
G1 X75.526 Y129.147 E.05379
G1 X74.993 Y129.147
G1 X73.755 Y130.385 E.05379
G1 X73.222 Y130.385
G1 X74.46 Y129.147 E.05379
G1 X73.926 Y129.147
G1 X72.689 Y130.385 E.05379
G1 X72.417 Y130.123
G1 X73.393 Y129.147 E.0424
G1 X72.86 Y129.147
G1 X72.417 Y129.59 E.01923
; WIPE_START
M204 S10000
G1 X72.86 Y129.147 E-.23781
G1 X73.393 Y129.147 E-.20264
G1 X72.799 Y129.742 E-.31956
; WIPE_END
G1 E-.04 F1800
G1 X80.43 Y129.615 Z6.4 F30000
G1 X89.556 Y129.463 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.133367
G1 F15000
G1 X89.556 Y129.129 E.00246
; CHANGE_LAYER
; Z_HEIGHT: 6.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X89.556 Y129.463 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 31/32
; update layer progress
M73 L31
M991 S0 P30 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6.4 I-.035 J1.216 P1  F30000
G1 X166.21 Y131.671 Z6.4
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F10151
M204 S5000
G1 X166.21 Y129.74 E.05933
G1 X183.79 Y129.74 E.54018
G1 X183.79 Y131.671 E.05933
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X166.27 Y131.671 E.53834
M204 S10000
G1 X166.406 Y131.343 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30613
G1 F10151
G1 X183.594 Y131.343 E.36865
G1 X183.583 Y130.657 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F10151
M204 S2000
G1 X182.873 Y129.947 E.03082
G1 X182.34 Y129.947
G1 X183.578 Y131.185 E.05379
G1 X183.045 Y131.185
G1 X181.807 Y129.947 E.05379
G1 X181.274 Y129.947
G1 X182.512 Y131.185 E.05379
G1 X181.978 Y131.185
G1 X180.74 Y129.947 E.05379
G1 X180.207 Y129.947
G1 X181.445 Y131.185 E.05379
G1 X180.912 Y131.185
G1 X179.674 Y129.947 E.05379
G1 X179.141 Y129.947
G1 X180.379 Y131.185 E.05379
G1 X179.845 Y131.185
G1 X178.607 Y129.947 E.05379
G1 X178.074 Y129.947
G1 X179.312 Y131.185 E.05379
G1 X178.779 Y131.185
G1 X177.541 Y129.947 E.05379
G1 X177.008 Y129.947
G1 X178.245 Y131.185 E.05379
G1 X177.712 Y131.185
G1 X176.474 Y129.947 E.05379
G1 X175.941 Y129.947
G1 X177.179 Y131.185 E.05379
G1 X176.646 Y131.185
G1 X175.408 Y129.947 E.05379
G1 X174.875 Y129.947
G1 X176.112 Y131.185 E.05379
G1 X175.579 Y131.185
G1 X174.341 Y129.947 E.05379
G1 X173.808 Y129.947
G1 X175.046 Y131.185 E.05379
G1 X174.513 Y131.185
G1 X173.275 Y129.947 E.05379
G1 X172.742 Y129.947
G1 X173.979 Y131.185 E.05379
G1 X173.446 Y131.185
G1 X172.208 Y129.947 E.05379
G1 X171.675 Y129.947
G1 X172.913 Y131.185 E.05379
G1 X172.38 Y131.185
G1 X171.142 Y129.947 E.05379
G1 X170.609 Y129.947
G1 X171.846 Y131.185 E.05379
G1 X171.313 Y131.185
G1 X170.075 Y129.947 E.05379
G1 X169.542 Y129.947
G1 X170.78 Y131.185 E.05379
G1 X170.247 Y131.185
G1 X169.009 Y129.947 E.05379
G1 X168.475 Y129.947
G1 X169.713 Y131.185 E.05379
G1 X169.18 Y131.185
G1 X167.942 Y129.947 E.05379
G1 X167.409 Y129.947
G1 X168.647 Y131.185 E.05379
G1 X168.114 Y131.185
G1 X166.876 Y129.947 E.05379
G1 X166.417 Y130.022
G1 X167.58 Y131.185 E.05054
G1 X167.047 Y131.185
G1 X166.417 Y130.556 E.02736
; WIPE_START
G1 F12000
M204 S10000
G1 X167.047 Y131.185 E-.3384
G1 X167.58 Y131.185 E-.20264
G1 X167.173 Y130.778 E-.21896
; WIPE_END
G1 E-.04 F1800
G1 X159.79 Y131.671 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
G1 F10151
M204 S5000
G1 X152.21 Y131.671 E.23291
G1 X152.21 Y129.74 E.05933
G1 X159.79 Y129.74 E.23291
G1 X159.79 Y131.611 E.05749
M204 S10000
G1 X159.594 Y131.343 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30613
G1 F10151
G1 X152.406 Y131.343 E.15417
G1 X159.583 Y130.653 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F10151
M204 S2000
G1 X158.877 Y129.947 E.03067
G1 X158.344 Y129.947
G1 X159.581 Y131.185 E.05379
G1 X159.048 Y131.185
G1 X157.81 Y129.947 E.05379
G1 X157.277 Y129.947
G1 X158.515 Y131.185 E.05379
G1 X157.982 Y131.185
G1 X156.744 Y129.947 E.05379
G1 X156.211 Y129.947
G1 X157.448 Y131.185 E.05379
G1 X156.915 Y131.185
G1 X155.677 Y129.947 E.05379
G1 X155.144 Y129.947
G1 X156.382 Y131.185 E.05379
G1 X155.849 Y131.185
G1 X154.611 Y129.947 E.05379
G1 X154.078 Y129.947
G1 X155.315 Y131.185 E.05379
G1 X154.782 Y131.185
G1 X153.544 Y129.947 E.05379
G1 X153.011 Y129.947
G1 X154.249 Y131.185 E.05379
G1 X153.716 Y131.185
G1 X152.478 Y129.947 E.05379
G1 X152.417 Y130.42
G1 X153.182 Y131.185 E.03324
; WIPE_START
G1 F12000
M204 S10000
G1 X152.417 Y130.42 E-.41111
G1 X152.478 Y129.947 E-.18116
G1 X152.79 Y130.26 E-.16773
; WIPE_END
G1 E-.04 F1800
G1 X145.193 Y130.995 Z6.6 F30000
G1 X138.21 Y131.671 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
G1 F10151
M204 S5000
G1 X138.21 Y129.74 E.05933
G1 X145.79 Y129.74 E.23291
G1 X145.79 Y131.671 E.05933
G1 X138.27 Y131.671 E.23107
M204 S10000
G1 X138.406 Y131.343 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30613
G1 F10151
G1 X145.594 Y131.343 E.15417
G1 X145.583 Y130.518 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F10151
M204 S2000
G1 X145.012 Y129.947 E.02479
G1 X144.479 Y129.947
G1 X145.583 Y131.051 E.04796
G1 X145.184 Y131.185
G1 X143.946 Y129.947 E.05379
G1 X143.412 Y129.947
G1 X144.65 Y131.185 E.05379
G1 X144.117 Y131.185
G1 X142.879 Y129.947 E.05379
G1 X142.346 Y129.947
G1 X143.584 Y131.185 E.05379
G1 X143.051 Y131.185
G1 X141.813 Y129.947 E.05379
G1 X141.279 Y129.947
G1 X142.517 Y131.185 E.05379
G1 X141.984 Y131.185
G1 X140.746 Y129.947 E.05379
G1 X140.213 Y129.947
G1 X141.451 Y131.185 E.05379
G1 X140.917 Y131.185
G1 X139.68 Y129.947 E.05379
G1 X139.146 Y129.947
G1 X140.384 Y131.185 E.05379
G1 X139.851 Y131.185
G1 X138.613 Y129.947 E.05379
G1 X138.417 Y130.285
G1 X139.318 Y131.185 E.03912
G1 X138.784 Y131.185
G1 X138.417 Y130.818 E.01595
; WIPE_START
G1 F12000
M204 S10000
G1 X138.784 Y131.185 E-.19725
G1 X139.318 Y131.185 E-.20264
G1 X138.648 Y130.515 E-.36012
; WIPE_END
G1 E-.04 F1800
G1 X131.039 Y131.124 Z6.6 F30000
G1 X124.21 Y131.671 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
G1 F10151
M204 S5000
G1 X124.21 Y129.74 E.05933
M73 P98 R0
G1 X131.79 Y129.74 E.23291
G1 X131.79 Y131.671 E.05933
G1 X124.27 Y131.671 E.23107
M204 S10000
G1 X124.406 Y131.343 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30613
G1 F10151
G1 X131.594 Y131.343 E.15417
G1 X131.583 Y130.383 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F10151
M204 S2000
G1 X131.147 Y129.947 E.01891
G1 X130.614 Y129.947
G1 X131.583 Y130.916 E.04208
G1 X131.319 Y131.185
G1 X130.081 Y129.947 E.05379
G1 X129.548 Y129.947
G1 X130.786 Y131.185 E.05379
G1 X130.252 Y131.185
G1 X129.014 Y129.947 E.05379
G1 X128.481 Y129.947
G1 X129.719 Y131.185 E.05379
G1 X129.186 Y131.185
G1 X127.948 Y129.947 E.05379
G1 X127.415 Y129.947
G1 X128.653 Y131.185 E.05379
G1 X128.119 Y131.185
G1 X126.881 Y129.947 E.05379
G1 X126.348 Y129.947
G1 X127.586 Y131.185 E.05379
G1 X127.053 Y131.185
G1 X125.815 Y129.947 E.05379
G1 X125.282 Y129.947
G1 X126.52 Y131.185 E.05379
G1 X125.986 Y131.185
G1 X124.748 Y129.947 E.05379
G1 X124.417 Y130.15
G1 X125.453 Y131.185 E.045
G1 X124.92 Y131.185
G1 X124.417 Y130.683 E.02183
; WIPE_START
G1 F12000
M204 S10000
G1 X124.92 Y131.185 E-.26997
G1 X125.453 Y131.185 E-.20264
G1 X124.918 Y130.651 E-.28739
; WIPE_END
G1 E-.04 F1800
G1 X117.304 Y131.179 Z6.6 F30000
G1 X110.21 Y131.671 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
G1 F10151
M204 S5000
G1 X110.21 Y129.74 E.05933
G1 X117.79 Y129.74 E.23291
G1 X117.79 Y131.671 E.05933
G1 X110.27 Y131.671 E.23107
M204 S10000
G1 X110.406 Y131.343 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30613
G1 F10151
G1 X117.594 Y131.343 E.15417
; WIPE_START
G1 F15000
G1 X115.594 Y131.343 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X116.75 Y129.947 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F10151
M204 S2000
G1 X117.583 Y130.781 E.0362
G1 X117.454 Y131.185
G1 X116.216 Y129.947 E.05379
G1 X115.683 Y129.947
G1 X116.921 Y131.185 E.05379
G1 X116.388 Y131.185
G1 X115.15 Y129.947 E.05379
G1 X114.616 Y129.947
G1 X115.854 Y131.185 E.05379
G1 X115.321 Y131.185
G1 X114.083 Y129.947 E.05379
G1 X113.55 Y129.947
G1 X114.788 Y131.185 E.05379
G1 X114.255 Y131.185
G1 X113.017 Y129.947 E.05379
G1 X112.483 Y129.947
G1 X113.721 Y131.185 E.05379
G1 X113.188 Y131.185
G1 X111.95 Y129.947 E.05379
G1 X111.417 Y129.947
G1 X112.655 Y131.185 E.05379
G1 X112.122 Y131.185
G1 X110.884 Y129.947 E.05379
G1 X110.417 Y130.014
G1 X111.588 Y131.185 E.05088
G1 X111.055 Y131.185
G1 X110.417 Y130.548 E.02771
; WIPE_START
G1 F12000
M204 S10000
G1 X111.055 Y131.185 E-.34268
G1 X111.588 Y131.185 E-.20264
G1 X111.189 Y130.786 E-.21468
; WIPE_END
G1 E-.04 F1800
G1 X103.79 Y131.671 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
G1 F10151
M204 S5000
G1 X96.21 Y131.671 E.23291
G1 X96.21 Y129.74 E.05933
G1 X103.79 Y129.74 E.23291
G1 X103.79 Y131.611 E.05749
M204 S10000
G1 X103.594 Y131.343 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30613
G1 F10151
G1 X96.406 Y131.343 E.15417
G1 X103.583 Y130.645 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F10151
M204 S2000
G1 X102.885 Y129.947 E.03032
G1 X102.352 Y129.947
G1 X103.583 Y131.178 E.0535
G1 X103.056 Y131.185
G1 X101.818 Y129.947 E.05379
G1 X101.285 Y129.947
G1 X102.523 Y131.185 E.05379
G1 X101.99 Y131.185
G1 X100.752 Y129.947 E.05379
G1 X100.219 Y129.947
G1 X101.456 Y131.185 E.05379
G1 X100.923 Y131.185
G1 X99.685 Y129.947 E.05379
G1 X99.152 Y129.947
G1 X100.39 Y131.185 E.05379
G1 X99.857 Y131.185
G1 X98.619 Y129.947 E.05379
G1 X98.086 Y129.947
G1 X99.323 Y131.185 E.05379
G1 X98.79 Y131.185
G1 X97.552 Y129.947 E.05379
G1 X97.019 Y129.947
G1 X98.257 Y131.185 E.05379
G1 X97.724 Y131.185
G1 X96.486 Y129.947 E.05379
G1 X96.417 Y130.412
G1 X97.19 Y131.185 E.03359
; WIPE_START
G1 F12000
M204 S10000
G1 X96.417 Y130.412 E-.4154
G1 X96.486 Y129.947 E-.17856
G1 X96.795 Y130.256 E-.16604
; WIPE_END
G1 E-.04 F1800
G1 X89.79 Y131.671 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
G1 F10151
M204 S5000
G1 X72.21 Y131.671 E.54018
G1 X72.21 Y129.74 E.05933
G1 X89.79 Y129.74 E.54018
G1 X89.79 Y131.611 E.05749
M204 S10000
G1 X89.594 Y131.343 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30613
G1 F10151
G1 X72.406 Y131.343 E.36865
G1 X89.583 Y130.51 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F10151
M204 S2000
G1 X89.02 Y129.947 E.02444
G1 X88.487 Y129.947
G1 X89.583 Y131.043 E.04762
G1 X89.191 Y131.185
G1 X87.954 Y129.947 E.05379
G1 X87.42 Y129.947
G1 X88.658 Y131.185 E.05379
G1 X88.125 Y131.185
G1 X86.887 Y129.947 E.05379
G1 X86.354 Y129.947
G1 X87.592 Y131.185 E.05379
G1 X87.058 Y131.185
G1 X85.821 Y129.947 E.05379
G1 X85.287 Y129.947
G1 X86.525 Y131.185 E.05379
G1 X85.992 Y131.185
G1 X84.754 Y129.947 E.05379
G1 X84.221 Y129.947
G1 X85.459 Y131.185 E.05379
G1 X84.925 Y131.185
G1 X83.688 Y129.947 E.05379
G1 X83.154 Y129.947
G1 X84.392 Y131.185 E.05379
G1 X83.859 Y131.185
G1 X82.621 Y129.947 E.05379
G1 X82.088 Y129.947
G1 X83.326 Y131.185 E.05379
G1 X82.792 Y131.185
G1 X81.555 Y129.947 E.05379
G1 X81.021 Y129.947
G1 X82.259 Y131.185 E.05379
G1 X81.726 Y131.185
G1 X80.488 Y129.947 E.05379
G1 X79.955 Y129.947
G1 X81.193 Y131.185 E.05379
G1 X80.659 Y131.185
G1 X79.421 Y129.947 E.05379
G1 X78.888 Y129.947
G1 X80.126 Y131.185 E.05379
G1 X79.593 Y131.185
G1 X78.355 Y129.947 E.05379
G1 X77.822 Y129.947
G1 X79.06 Y131.185 E.05379
G1 X78.526 Y131.185
G1 X77.288 Y129.947 E.05379
G1 X76.755 Y129.947
G1 X77.993 Y131.185 E.05379
G1 X77.46 Y131.185
G1 X76.222 Y129.947 E.05379
G1 X75.689 Y129.947
G1 X76.927 Y131.185 E.05379
G1 X76.393 Y131.185
G1 X75.155 Y129.947 E.05379
G1 X74.622 Y129.947
G1 X75.86 Y131.185 E.05379
G1 X75.327 Y131.185
G1 X74.089 Y129.947 E.05379
G1 X73.556 Y129.947
G1 X74.794 Y131.185 E.05379
G1 X74.26 Y131.185
G1 X73.022 Y129.947 E.05379
G1 X72.489 Y129.947
G1 X73.727 Y131.185 E.05379
G1 X73.194 Y131.185
G1 X72.417 Y130.409 E.03374
; CHANGE_LAYER
; Z_HEIGHT: 6.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
M204 S10000
G1 X73.194 Y131.185 E-.41723
G1 X73.727 Y131.185 E-.20264
G1 X73.466 Y130.925 E-.14013
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 32/32
; update layer progress
M73 L32
M991 S0 P31 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6.6 I.005 J1.217 P1  F30000
G1 X166.21 Y130.54 Z6.6
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
G1 F4172
M204 S5000
G1 X183.79 Y130.54 E.54018
G1 X183.79 Y131.192 E.02002
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X166.21 Y131.192 E.54018
G1 X166.21 Y130.6 E.01818
M204 S10000
G1 X166.406 Y130.866 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30237
G1 F4172
G1 X183.594 Y130.866 E.36339
; WIPE_START
G1 F15000
G1 X181.594 Y130.866 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X173.962 Y130.98 Z6.8 F30000
G1 X159.79 Y131.192 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4172
M204 S5000
G1 X152.21 Y131.192 E.23291
G1 X152.21 Y130.54 E.02002
G1 X159.79 Y130.54 E.23291
G1 X159.79 Y131.132 E.01818
M204 S10000
G1 X159.594 Y130.866 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30237
G1 F4172
G1 X152.406 Y130.866 E.15197
; WIPE_START
G1 F15000
G1 X154.406 Y130.866 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X146.775 Y131.019 Z6.8 F30000
G1 X138.21 Y131.192 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4172
M204 S5000
G1 X138.21 Y130.54 E.02002
G1 X145.79 Y130.54 E.23291
G1 X145.79 Y131.192 E.02002
G1 X138.27 Y131.192 E.23107
M204 S10000
G1 X138.406 Y130.866 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30237
G1 F4172
G1 X145.594 Y130.866 E.15197
; WIPE_START
G1 F15000
G1 X143.594 Y130.866 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X135.963 Y130.994 Z6.8 F30000
G1 X124.21 Y131.192 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4172
M204 S5000
G1 X124.21 Y130.54 E.02002
G1 X131.79 Y130.54 E.23291
G1 X131.79 Y131.192 E.02002
G1 X124.27 Y131.192 E.23107
M204 S10000
G1 X124.406 Y130.866 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30237
G1 F4172
G1 X131.594 Y130.866 E.15197
; WIPE_START
G1 F15000
G1 X129.594 Y130.866 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X121.963 Y130.994 Z6.8 F30000
G1 X110.21 Y131.192 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4172
M204 S5000
G1 X110.21 Y130.54 E.02002
G1 X117.79 Y130.54 E.23291
G1 X117.79 Y131.192 E.02002
G1 X110.27 Y131.192 E.23107
M204 S10000
G1 X110.406 Y130.866 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30237
G1 F4172
G1 X117.594 Y130.866 E.15197
; WIPE_START
G1 F15000
G1 X115.594 Y130.866 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.964 Y130.655 Z6.8 F30000
G1 X103.79 Y130.54 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4172
M204 S5000
G1 X103.79 Y131.192 E.02002
G1 X96.21 Y131.192 E.23291
G1 X96.21 Y130.54 E.02002
G1 X103.73 Y130.54 E.23107
M204 S10000
G1 X103.594 Y130.866 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30237
G1 F4172
G1 X96.406 Y130.866 E.15197
; WIPE_START
G1 F15000
G1 X98.406 Y130.866 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X90.779 Y130.577 Z6.8 F30000
G1 X89.79 Y130.54 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4172
M204 S5000
G1 X89.79 Y131.192 E.02002
G1 X72.21 Y131.192 E.54018
G1 X72.21 Y130.54 E.02002
G1 X89.73 Y130.54 E.53834
M204 S10000
G1 X89.594 Y130.866 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.30237
G1 F4172
G1 X72.406 Y130.866 E.36339
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F15000
G1 X74.406 Y130.866 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z6.8 I1.217 J0 P1  F30000
M106 S0
M106 P2 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20240528 =====================
M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G1 E-0.8 F1800 ; retract
G1 Z6.9 F900 ; lower z a little
G1 X65 Y245 F12000 ; move to safe pos
G1 Y265 F3000

G1 X65 Y245 F12000
G1 Y265 F3000
M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

G1 X100 F12000 ; wipe
; pull back filament to AMS
M620 S255
G1 X20 Y50 F12000
G1 Y-3
T255
G1 X65 F12000
G1 Y265
G1 X100 F12000 ; wipe
M621 S255
M104 S0 ; turn off hotend

M622.1 S1 ; for prev firware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
    M400 ; wait all motion done
    M991 S0 P-1 ;end smooth timelapse at safe pos
    M400 S3 ;wait for last picture to be taken
M623; end of "timelapse_record_flag"

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z106.4 F600
    G1 Z104.4

M400 P100
M17 R ; restore z current

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0
;=====printer finish  sound=========
M17
M400 S1
M1006 S1
M1006 A0 B20 L100 C37 D20 M40 E42 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C46 D10 M80 E46 F10 N80
M1006 A44 B20 L100 C39 D20 M60 E48 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C48 D10 M60 E44 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10  N100
M1006 A49 B20 L100 C44 D20 M100 E41 F20 N100
M1006 A0 B20 L100 C0 D20 M60 E0 F20 N100
M1006 A0 B20 L100 C37 D20 M30 E37 F20 N60
M1006 W

M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power
M960 S5 P0 ; turn off logo lamp
M73 P100 R0
; EXECUTABLE_BLOCK_END

