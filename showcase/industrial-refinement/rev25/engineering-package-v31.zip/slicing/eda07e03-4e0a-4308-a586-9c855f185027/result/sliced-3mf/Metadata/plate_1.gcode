; HEADER_BLOCK_START
; BambuStudio 02.08.02.60
; model printing time: 22m 1s; total estimated time: 29m 17s
; total layer number: 33
; total filament length [mm] : 2119.88
; total filament volume [cm^3] : 5098.92
; total filament weight [g] : 6.42
; filament_density: 1.26
; filament_diameter: 1.75
; max_z_height: 6.60
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 70
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 1
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 0x0,18x0,18x28,0x28
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = auto_brim
; brim_width = 5
; chamber_temperatures = 0
; change_filament_gcode = ;=X1 20251031=\nM620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nG1 X70 F21000\nG1 Y245\nG1 Y265 F3000\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E-{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{else}\nM620.11 S0\n{endif}\nM400\nG1 X90 F3000\nG1 Y255 F4000\nG1 X100 F5000\nG1 X120 F15000\nG1 X20 Y50 F21000\nG1 Y-3\n{if toolchange_count == 2}\n; get travel path for change filament\nM620.1 X[travel_point_1_x] Y[travel_point_1_y] F21000 P0\nM620.1 X[travel_point_2_x] Y[travel_point_2_y] F21000 P1\nM620.1 X[travel_point_3_x] Y[travel_point_3_y] F21000 P2\n{endif}\nM620.1 E F{flush_volumetric_speeds[previous_extruder]/2.4053*60} T{flush_temperatures[previous_extruder]}\nT[next_extruder]\nM620.1 E F{flush_volumetric_speeds[next_extruder]/2.4053*60} T{flush_temperatures[next_extruder]}\n\n{if next_extruder < 255}\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM628 S1\nG92 E0\nG1 E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM400\nM629 S1\n{else}\nM620.11 S0\n{endif}\nG92 E0\n{if flush_length_1 > 1}\nM83\n; FLUSH_START\n; always use highest temperature to flush\nM400\n{if filament_type[next_extruder] == \"PETG\"}\nM109 S260\n{elsif filament_type[next_extruder] == \"PVA\"}\nM109 S210\n{else}\nM109 S{flush_temperatures[next_extruder]}\n{endif}\n{if flush_length_1 > 23.7}\nG1 E23.7 F{flush_volumetric_speeds[previous_extruder]/2.4053*60} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\n{else}\nG1 E{flush_length_1} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_4 > 1}\n\nG91\nG1 X3 F12000; move aside to extrude\nG90\nM83\n\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n; FLUSH_START\nM400\nM109 S[new_filament_temp]\nG1 E2 F{flush_volumetric_speeds[next_extruder]/2.4053*60} ;Compensate for filament spillage during waiting temperature\n; FLUSH_END\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM106 P1 S255\nM400 S3\n\nG1 X70 F5000\nG1 X90 F3000\nG1 Y255 F4000\nG1 X105 F5000\nG1 Y265 F5000\nG1 X70 F10000\nG1 X100 F5000\nG1 X70 F10000\nG1 X100 F5000\n\nG1 X70 F10000\nG1 X80 F15000\nG1 X60\nG1 X80\nG1 X60\nG1 X80 ; shake to put down garbage\nG1 X100 F5000\nG1 X165 F15000; wipe and shake\nG1 Y256 ; move Y to aside, prevent collision\nM400\nG1 Z{max_layer_z + 3.0} F3000\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\nM621 S[next_extruder]A\n
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; compatible_printers_condition = 
; complete_print_exhaust_fan_speed = 70
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.008
; counter_coef_3 = -0.041
; counter_limit_max = 0.033
; counter_limit_min = -0.035
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 10000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL X1C"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL X1C
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70
; elefant_foot_compensation = 0.15
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 1
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0
; eng_plate_temp_initial_layer = 0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 33
; extruder_clearance_height_to_lid = 90
; extruder_clearance_height_to_rod = 34
; extruder_clearance_max_radius = 68
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x2
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard,Direct Drive High Flow"
; fan_cooling_layer_time = 100
; fan_direction = left
; fan_max_speed = 100
; fan_min_speed = 100
; farthest_point_timelapse = 1
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 100
; filament_bridge_speed = 25
; filament_change_length = 5
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 0
; filament_cost = 19.99
; filament_density = 1.26
; filament_dev_ams_drying_ams_limitations = 1
; filament_dev_ams_drying_heat_distortion_temperature = 45
; filament_dev_ams_drying_temperature = 45
; filament_dev_ams_drying_time = 12
; filament_dev_chamber_drying_bed_temperature = 70
; filament_dev_chamber_drying_time = 12
; filament_dev_drying_cooling_temperature = 45
; filament_dev_drying_softening_temperature = 50
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = "; filament end gcode \n\n"
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = GFA00
; filament_is_mixed = 0
; filament_is_support = 0
; filament_long_retractions_when_cut = 1
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 21
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 50
; filament_overhang_3_4_speed = 30
; filament_overhang_4_4_speed = 10
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 10
; filament_prime_volume = 30
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 14
; filament_retraction_distances_when_cut = 18
; filament_scarf_gap = 0%
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Bambu PLA Basic @BBL X1C"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\nM142 P1 R35 S40\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = "Bambu Lab"
; filament_volume_map = 0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 0
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 
; hole_coef_1 = 0
; hole_coef_2 = -0.008
; hole_coef_3 = 0.23415
; hole_limit_max = 0.22
; hole_limit_min = 0.088
; hot_plate_temp = 55
; hot_plate_temp_initial_layer = 55
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 13.8
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = ;===== date: 20240528 =====================\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG1 E-0.8 F1800 ; retract\nG1 Z{max_layer_z + 0.5} F900 ; lower z a little\nG1 X65 Y245 F12000 ; move to safe pos\nG1 Y265 F3000\n\nG1 X65 Y245 F12000\nG1 Y265 F3000\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\nG1 X100 F12000 ; wipe\n; pull back filament to AMS\nM620 S255\nG1 X20 Y50 F12000\nG1 Y-3\nT255\nG1 X65 F12000\nG1 Y265\nG1 X100 F12000 ; wipe\nM621 S255\nM104 S0 ; turn off hotend\n\nM622.1 S1 ; for prev firware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n    M400 ; wait all motion done\n    M991 S0 P-1 ;end smooth timelapse at safe pos\n    M400 S3 ;wait for last picture to be taken\nM623; end of \"timelapse_record_flag\"\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 250}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z250 F600\n    G1 Z248\n{endif}\nM400 P100\nM17 R ; restore z current\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n;=====printer finish  sound=========\nM17\nM400 S1\nM1006 S1\nM1006 A0 B20 L100 C37 D20 M40 E42 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C46 D10 M80 E46 F10 N80\nM1006 A44 B20 L100 C39 D20 M60 E48 F20 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C39 D10 M60 E39 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A0 B10 L100 C48 D10 M60 E44 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10  N100\nM1006 A49 B20 L100 C44 D20 M100 E41 F20 N100\nM1006 A0 B20 L100 C0 D20 M60 E0 F20 N100\nM1006 A0 B20 L100 C37 D20 M30 E37 F20 N60\nM1006 W\n\nM17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power\nM960 S5 P0 ; turn off logo lamp\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 29
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 20000,20000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 9000,9000
; machine_max_acceleration_x = 20000,20000
; machine_max_acceleration_y = 20000,20000
; machine_max_acceleration_z = 500,500
; machine_max_force_Y = 0
; machine_max_jerk_e = 2.5,2.5
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_printed_mass = 0
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,500
; machine_max_speed_y = 500,500
; machine_max_speed_z = 20,20
; machine_min_extruding_rate = 0
; machine_min_travel_rate = 0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = ;===== machine: X1-0.4 ====================\n;===== date: 20251031 ==================\n;===== start printer sound ================\nM17\nM400 S1\nM1006 S1\nM1006 A0 B10 L100 C37 D10 M60 E37 F10 N60\nM1006 A0 B10 L100 C41 D10 M60 E41 F10 N60\nM1006 A0 B10 L100 C44 D10 M60 E44 F10 N60\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N60\nM1006 A46 B10 L100 C43 D10 M70 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A43 B10 L100 C0 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A41 B10 L100 C0 D10 M100 E41 F10 N100\nM1006 A44 B10 L100 C0 D10 M100 E44 F10 N100\nM1006 A49 B10 L100 C0 D10 M100 E49 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A48 B10 L100 C44 D10 M60 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A44 B10 L100 C0 D10 M90 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M60 E0 F10 N100\nM1006 A46 B10 L100 C43 D10 M60 E39 F10 N100\nM1006 W\n;===== turn on the HB fan =================\nM104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle\n;===== reset machine status =================\nM290 X40 Y40 Z2.6666666\nG91\nM17 Z0.4 ; lower the z-motor current\nG380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed\nG380 S2 Z-25 F300 ;\nG1 Z5 F300;\nG90\nM17 X1.2 Y1.2 Z0.75 ; reset motor current to default\nM960 S5 P1 ; turn on logo lamp\nG90\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 5\nM221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem\nG29.1 Z{+0.0} ; clear z-trim value first\nM204 S10000 ; init ACC set to 10m/s^2\n\n;===== heatbed preheat ====================\nM1002 gcode_claim_action:54\nM140 S[bed_temperature_initial_layer_single] ;set bed temp\nM190 S[bed_temperature_initial_layer_single] ;wait for bed temp\n\n{if scan_first_layer}\n;=========register first layer scan=====\nM977 S1 P60\n{endif}\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\n;===== prepare print temperature and material ==========\nM104 S[nozzle_temperature_initial_layer] ;set extruder temp\nG91\nG0 Z10 F1200\nG90\nG28 X\nM975 S1 ; turn on\nG1 X60 F12000\nG1 Y245\nG1 Y265 F3000\nM620 M\nM620 S[initial_no_support_extruder]A   ; switch material if AMS exist\n    M109 S[nozzle_temperature_initial_layer]\n    G1 X120 F12000\n\n    G1 X20 Y50 F12000\n    G1 Y-3\n    T[initial_no_support_extruder]\n    G1 X54 F12000\n    G1 Y265\n    M400\nM621 S[initial_no_support_extruder]A\nM620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T{flush_temperatures[initial_no_support_extruder]}\n\nM412 S1 ; ===turn on filament runout detection===\n\nM109 S250 ;set nozzle to common flush temp\nM106 P1 S0\nG92 E0\nG1 E50 F200\nM400\nM104 S[nozzle_temperature_initial_layer]\nG92 E0\nG1 E50 F200\nM400\nM106 P1 S255\nG92 E0\nG1 E5 F300\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20} ; drop nozzle temp, make filament shink a bit\nG92 E0\nG1 E-0.5 F300\n\nG1 X70 F9000\nG1 X76 F15000\nG1 X65 F15000\nG1 X76 F15000\nG1 X65 F15000; shake to put down garbage\nG1 X80 F6000\nG1 X95 F15000\nG1 X80 F15000\nG1 X165 F15000; wipe and shake\nM400\nM106 P1 S0\n;===== prepare print temperature and material end =====\n\n\n;===== wipe nozzle ===============================\nM1002 gcode_claim_action : 14\nM975 S1\nM106 S255\nG1 X65 Y230 F18000\nG1 Y264 F6000\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20}\nG1 X100 F18000 ; first wipe mouth\n\nG0 X135 Y253 F20000  ; move to exposed steel surface edge\nG28 Z P0 T300; home z with low precision,permit 300deg temperature\nG29.2 S0 ; turn off ABL\nG0 Z5 F20000\n\nG1 X60 Y265\nG92 E0\nG1 E-0.5 F300 ; retrack more\nG1 X100 F5000; second wipe mouth\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X100 F5000\nG1 X70 F15000\nG1 X90 F5000\nG0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle\nM104 S140 ; set temp down to heatbed acceptable\nM106 S255 ; turn on fan (G28 has turn off fan)\n\nM221 S; push soft endstop status\nM221 Z0 ;turn off Z axis endstop\nG0 Z0.5 F20000\nG0 X125 Y259.5 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y262.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y260.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.5\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 Z0.5 F20000\nG0 X125 Y261.0\nG0 Z-1.01\nG0 X131 F211\nG0 X124\nG0 X128\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\nG2 I0.5 J0 F300\n\nM109 S140 ; wait nozzle temp down to heatbed acceptable\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\nG2 I0.5 J0 F3000\n\nM221 R; pop softend status\nG1 Z10 F1200\nM400\nG1 Z10\nG1 F30000\nG1 X128 Y128\nG29.2 S1 ; turn on ABL\n;G28 ; home again after hard wipe mouth\nM106 S0 ; turn off fan , too noisy\n;===== wipe nozzle end ================================\n\n;===== check scanner clarity ===========================\nG1 X128 Y128 F24000\nG28 Z P0\nM972 S5 P0\nG1 X230 Y15 F24000\n;===== check scanner clarity end =======================\n\n;===== bed leveling ==================================\nM1002 judge_flag g29_before_print_flag\nM622 J1\n\n    M1002 gcode_claim_action : 1\n    G29 A X{first_layer_print_min[0]} Y{first_layer_print_min[1]} I{first_layer_print_size[0]} J{first_layer_print_size[1]}\n    M400\n    M500 ; save cali data\n\nM623\n;===== bed leveling end ================================\n\n;===== home after wipe mouth============================\nM1002 judge_flag g29_before_print_flag\nM622 J0\n\n    M1002 gcode_claim_action : 13\n    G28\n\nM623\n;===== home after wipe mouth end =======================\n\nM975 S1 ; turn on vibration supression\n\n;=============turn on fans to prevent PLA jamming=================\n{if filament_type[initial_no_support_extruder]==\"PLA\"}\n    {if (bed_temperature[initial_no_support_extruder] >45)||(bed_temperature_initial_layer[initial_no_support_extruder] >45)}\n    M106 P3 S180\n    {endif};Prevent PLA from jamming\n    M142 P1 R35 S40\n{endif}\nM106 P2 S100 ; turn on big fan ,to cool down toolhead\n\nM104 S{nozzle_temperature_initial_layer[initial_no_support_extruder]} ; set extrude temp earlier, to reduce wait time\n\n;===== mech mode fast check============================\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q1 A7 B30 C80  H15 K0\nM974 Q1 S2 P0\n\nG1 X128 Y128 Z10 F20000\nM400 P200\nM970.3 Q0 A7 B30 C90 Q0 H15 K0\nM974 Q0 S2 P0\n\nM975 S1\nG1 F30000\nG1 X230 Y15\nG28 X ; re-home XY\n;===== mech mode fast check============================\n\n{if scan_first_layer}\n;start heatbed  scan====================================\nM976 S2 P1\nG90\nG1 X128 Y128 F20000\nM976 S3 P2  ;register void printing detection\n{endif}\n\n;===== nozzle load line ===============================\nM975 S1\nG90\nM83\nT1000\nG1 X18.0 Y1.0 Z0.8 F18000;Move to start position\nM109 S{nozzle_temperature[initial_no_support_extruder]}\nG1 Z0.2\nG0 E2 F300\nG0 X240 E15 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nG0 Y11 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\nG0 X239.5\nG0 E0.2\nG0 Y1.5 E0.700\nG0 X231 E0.700 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM400\n\n;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==\n;curr_bed_type={curr_bed_type}\n{if curr_bed_type==\"Textured PEI Plate\"}\nG29.1 Z{-0.04} ; for Textured PEI Plate\n{endif}\n\n;===== draw extrinsic para cali paint =================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M1002 gcode_claim_action : 8\n\n    T1000\n\n    G0 F1200.0 X231 Y12   Z0.2 E0.577\n    G0 F1200.0 X226 Y12   Z0.2 E0.275\n    G0 F1200.0 X226 Y1.5  Z0.2 E0.577\n    G0 F1200.0 X220 Y1.5  Z0.2 E0.330\n    G0 F1200.0 X220 Y8    Z0.2 E0.358\n    G0 F1200.0 X210 Y8    Z0.2 E0.549\n    G0 F1200.0 X210 Y1.5  Z0.2 E0.357\n\n    G0 X48.0 E11.9 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X48.0 Y12 E0.772 F1200.0\n    G0 X45.0 E0.22 F1200.0\n    G0 X35.0 Y6.0 E0.86 F1200.0\n\n    ;=========== extruder cali extrusion ==================\n    T1000\n    M83\n    {if default_acceleration > 0}\n        {if outer_wall_acceleration > 0}\n            M204 S[outer_wall_acceleration]\n        {else}\n            M204 S[default_acceleration]\n        {endif}\n    {endif}\n    G0 X35.000 Y6.000 Z0.300 F30000 E0\n    G1 F1500.000 E0.800\n    M106 S0 ; turn off fan\n    G0 X185.000 E9.35441 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G0 X187 Z0\n    G1 F1500.000 E-0.800\n    G0 Z1\n    G0 X180 Z0.3 F18000\n\n    M900 L1000.0 M1.0\n    M900 K0.040\n    G0 X45.000 F30000\n    G0 Y8.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.020\n    G0 X45.000 F30000\n    G0 Y10.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n    M400\n\n    G0 X45.000 F30000\n    M900 K0.000\n    G0 X45.000 F30000\n    G0 Y12.000 F30000\n    G1 F1500.000 E0.800\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 F1500.000 E-0.800\n    G1 X183 Z0.15 F30000\n    G1 X185\n    G1 Z1.0\n    G0 Y6.000 F30000 ; move y to clear pos\n    G1 Z0.3\n\n    G0 X45.000 F30000 ; move to start point\n\nM623 ; end of \"draw extrinsic para cali paint\"\n\n\nM1002 judge_flag extrude_cali_flag\nM622 J0\n    G0 X231 Y1.5 F30000\n    G0 X18 E14.3 F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nM623\n\nM104 S140\n\n\n;=========== laser and rgb calibration ===========\nM400\nM18 E\nM500 R\n\nM973 S3 P14\n\nG1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nT1100\nG1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos\nM400 P100\nM960 S1 P1\nM400 P100\nM973 S6 P0; use auto exposure for horizontal laser by xcam\nM960 S0 P0\n\nG1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos\nM960 S2 P1\nM400 P100\nM973 S6 P1; use auto exposure for vertical laser by xcam\nM960 S0 P0\n\n;=========== handeye calibration ======================\nM1002 judge_flag extrude_cali_flag\nM622 J1\n\n    M973 S3 P1 ; camera start stream\n    M400 P500\n    M973 S1\n    G0 F6000 X228.500 Y4.750 Z0.000\n    M960 S0 P1\n    M973 S1\n    M400 P800\n    M971 S6 P0\n    M973 S2 P0\n    M400 P500\n    G0 Z0.000 F12000\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P200\n    M971 S5 P1\n    M973 S2 P1\n    M400 P500\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P3\n    G0 Z0.500 F12000\n    M960 S0 P0\n    M960 S2 P1\n    G0 X228.5 Y6.75\n    M400 P200\n    M971 S5 P4\n    M973 S2 P0\n    M400 P500\n    M960 S0 P0\n    M960 S1 P1\n    G0 X215.00 Y4.750\n    M400 P500\n    M971 S5 P2\n    M963 S1\n    M400 P1500\n    M964\n    T1100\n    G1 Z3 F3000\n\n    M400\n    M500 ; save cali data\n\n    M104 S{nozzle_temperature[initial_no_support_extruder]} ; rise nozzle temp now ,to reduce temp waiting time.\n\n    T1100\n    M400 P400\n    M960 S0 P0\n    G0 F30000.000 Y10.000 X65.000 Z0.000\n    M400 P400\n    M960 S1 P1\n    M400 P50\n\n    M969 S1 N3 A2000\n    G0 F360.000 X181.000 Z0.000\n    M980.3 A70.000 B{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60/4} C5.000 D{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*60} E5.000 F175.000 H1.000 I0.000 J0.020 K0.040\n    M400 P100\n    G0 F20000\n    G0 Z1 ; rise nozzle up\n    T1000 ; change to nozzle space\n    G0 X45.000 Y4.000 F30000 ; move to test line pos\n    M969 S0 ; turn off scanning\n    M960 S0 P0\n\n\n    G1 Z2 F20000\n    T1000\n    G0 X45.000 Y4.000 F30000 E0\n    M109 S{nozzle_temperature[initial_no_support_extruder]}\n    G0 Z0.3\n    G1 F1500.000 E3.600\n    G1 X65.000 E1.24726 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X70.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X75.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X80.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X85.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X90.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X95.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X100.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X105.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X110.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X115.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X120.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X125.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X130.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X135.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n\n    ; see if extrude cali success, if not ,use default value\n    M1002 judge_last_extrude_cali_success\n    M622 J0\n        M400\n        M900 K0.02 M{outer_wall_volumetric_speed/(1.75*1.75/4*3.14)*0.02}\n    M623\n\n    G1 X140.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X145.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X150.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X155.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X160.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X165.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X170.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X175.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X180.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X185.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X190.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X195.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X200.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X205.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X210.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X215.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    G1 X220.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)/ 4 * 60}\n    G1 X225.000 E0.31181 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\n    M973 S4\n\nM623\n\n;========turn off light and wait extrude temperature =============\nM1002 gcode_claim_action : 0\nM973 S4 ; turn off scanner\nM400 ; wait all motion done before implement the emprical L parameters\n;M900 L500.0 ; Empirical parameters\nM109 S[nozzle_temperature_initial_layer]\nM960 S1 P0 ; turn off laser\nM960 S2 P0 ; turn off laser\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off big fan\nM106 P3 S0 ; turn off chamber fan\n\nM975 S1 ; turn on mech mode supression\nG90\nM83\nT1000\n;===== purge line to wipe the nozzle ============================\nG1 E{-retraction_length[initial_no_support_extruder]} F1800\nG1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position\nG1 E{retraction_length[initial_no_support_extruder]} F1800\nM109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]}\nG1 Z0.2\nG0 X239 E15 F{outer_wall_volumetric_speed/(0.3*0.5)    * 60}\nG0 Y12 E0.7 F{outer_wall_volumetric_speed/(0.3*0.5)/4* 60}\n
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 28
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.2
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = hardened_steel
; nozzle_volume = 107
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 50%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab X1 Carbon 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab P1S 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL X1C
; printable_area = 0x0,256x0,256x256,0x256
; printable_height = 250
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab X1 Carbon
; printer_notes = 
; printer_settings_id = Bambu Lab X1 Carbon 0.4 nozzle
; printer_structure = corexy
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 249
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 1
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 4
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 150
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 15%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45
; supertack_plate_temp_initial_layer = 45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = tree(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45
; template_custom_gcode = 
; textured_plate_temp = 55
; textured_plate_temp_initial_layer = 55
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;========Date 20250206========\n; SKIPPABLE_START\n; SKIPTYPE: timelapse\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n{if timelapse_type == 0} ; timelapse without wipe tower\nM971 S11 C10 O0\nM1004 S5 P1  ; external shutter\n{elsif timelapse_type == 1} ; timelapse with wipe tower\nG92 E0\nG1 X65 Y245 F20000 ; move to safe pos\nG17\nG2 Z{layer_z} I0.86 J0.86 P1 F20000\nG1 Y265 F3000\nM400\nM1004 S5 P1  ; external shutter\nM400 P300\nM971 S11 C10 O0\nG92 E0\nG1 X100 F5000\nG1 Y255 F20000\n{endif}\nM623\n; SKIPPABLE_END\n
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 500
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab P1S 0.4 nozzle";"Bambu Lab P1P 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle";"Bambu Lab A1 0.4 nozzle";"Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R29
M201 X20000 Y20000 Z500 E5000
M203 X500 Y500 Z20 E30
M204 P20000 R5000 T20000
M205 X9.00 Y9.00 Z3.00 E2.50
M106 S0
M106 P2 S0
; FEATURE: Custom
;===== machine: X1-0.4 ====================
;===== date: 20251031 ==================
;===== start printer sound ================
M17
M400 S1
M1006 S1
M1006 A0 B10 L100 C37 D10 M60 E37 F10 N60
M1006 A0 B10 L100 C41 D10 M60 E41 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A46 B10 L100 C43 D10 M70 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A43 B10 L100 C0 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A41 B10 L100 C0 D10 M100 E41 F10 N100
M1006 A44 B10 L100 C0 D10 M100 E44 F10 N100
M1006 A49 B10 L100 C0 D10 M100 E49 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A48 B10 L100 C44 D10 M60 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A44 B10 L100 C0 D10 M90 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N100
M1006 A46 B10 L100 C43 D10 M60 E39 F10 N100
M1006 W
;===== turn on the HB fan =================
M104 S75 ;set extruder temp to turn on the HB fan and prevent filament oozing from nozzle
;===== reset machine status =================
M290 X40 Y40 Z2.6666666
G91
M17 Z0.4 ; lower the z-motor current
G380 S2 Z30 F300 ; G380 is same as G38; lower the hotbed , to prevent the nozzle is below the hotbed
G380 S2 Z-25 F300 ;
G1 Z5 F300;
G90
M17 X1.2 Y1.2 Z0.75 ; reset motor current to default
M960 S5 P1 ; turn on logo lamp
G90
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 5
M221 X0 Y0 Z0 ; turn off soft endstop to prevent protential logic problem
G29.1 Z0 ; clear z-trim value first
M204 S10000 ; init ACC set to 10m/s^2

;===== heatbed preheat ====================
M1002 gcode_claim_action:54
M140 S35 ;set bed temp
M190 S35 ;wait for bed temp


;=========register first layer scan=====
M977 S1 P60


;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

;===== prepare print temperature and material ==========
M104 S220 ;set extruder temp
G91
G0 Z10 F1200
G90
G28 X
M975 S1 ; turn on
G1 X60 F12000
G1 Y245
G1 Y265 F3000
M620 M
M620 S0A   ; switch material if AMS exist
    M109 S220
    G1 X120 F12000

    G1 X20 Y50 F12000
    G1 Y-3
    T0
    G1 X54 F12000
    G1 Y265
    M400
M621 S0A
M620.1 E F523.843 T240

M412 S1 ; ===turn on filament runout detection===

M109 S250 ;set nozzle to common flush temp
M106 P1 S0
G92 E0
M73 P2 R28
G1 E50 F200
M400
M104 S220
G92 E0
M73 P16 R24
G1 E50 F200
M400
M106 P1 S255
G92 E0
G1 E5 F300
M109 S200 ; drop nozzle temp, make filament shink a bit
G92 E0
M73 P17 R24
G1 E-0.5 F300

M73 P18 R23
G1 X70 F9000
G1 X76 F15000
G1 X65 F15000
G1 X76 F15000
G1 X65 F15000; shake to put down garbage
G1 X80 F6000
G1 X95 F15000
G1 X80 F15000
G1 X165 F15000; wipe and shake
M400
M106 P1 S0
;===== prepare print temperature and material end =====


;===== wipe nozzle ===============================
M1002 gcode_claim_action : 14
M975 S1
M106 S255
G1 X65 Y230 F18000
G1 Y264 F6000
M109 S200
G1 X100 F18000 ; first wipe mouth

G0 X135 Y253 F20000  ; move to exposed steel surface edge
G28 Z P0 T300; home z with low precision,permit 300deg temperature
G29.2 S0 ; turn off ABL
G0 Z5 F20000

G1 X60 Y265
G92 E0
G1 E-0.5 F300 ; retrack more
G1 X100 F5000; second wipe mouth
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X100 F5000
G1 X70 F15000
G1 X90 F5000
G0 X128 Y261 Z-1.5 F20000  ; move to exposed steel surface and stop the nozzle
M104 S140 ; set temp down to heatbed acceptable
M106 S255 ; turn on fan (G28 has turn off fan)

M221 S; push soft endstop status
M221 Z0 ;turn off Z axis endstop
G0 Z0.5 F20000
G0 X125 Y259.5 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y262.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y260.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.5
G0 Z-1.01
G0 X131 F211
G0 X124
G0 Z0.5 F20000
G0 X125 Y261.0
G0 Z-1.01
G0 X131 F211
G0 X124
G0 X128
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300
G2 I0.5 J0 F300

M109 S140 ; wait nozzle temp down to heatbed acceptable
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000
M73 P19 R23
G2 I0.5 J0 F3000
G2 I0.5 J0 F3000

M221 R; pop softend status
G1 Z10 F1200
M400
G1 Z10
G1 F30000
G1 X128 Y128
G29.2 S1 ; turn on ABL
;G28 ; home again after hard wipe mouth
M106 S0 ; turn off fan , too noisy
;===== wipe nozzle end ================================

;===== check scanner clarity ===========================
G1 X128 Y128 F24000
G28 Z P0
M972 S5 P0
G1 X230 Y15 F24000
;===== check scanner clarity end =======================

;===== bed leveling ==================================
M1002 judge_flag g29_before_print_flag
M622 J1

    M1002 gcode_claim_action : 1
    G29 A X73 Y116.25 I110 J23.5
    M400
    M500 ; save cali data

M623
;===== bed leveling end ================================

;===== home after wipe mouth============================
M1002 judge_flag g29_before_print_flag
M622 J0

    M1002 gcode_claim_action : 13
    G28

M623
;===== home after wipe mouth end =======================

M975 S1 ; turn on vibration supression

;=============turn on fans to prevent PLA jamming=================

    ;Prevent PLA from jamming
    M142 P1 R35 S40

M106 P2 S100 ; turn on big fan ,to cool down toolhead

M104 S220 ; set extrude temp earlier, to reduce wait time

;===== mech mode fast check============================
G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q1 A7 B30 C80  H15 K0
M974 Q1 S2 P0

G1 X128 Y128 Z10 F20000
M400 P200
M970.3 Q0 A7 B30 C90 Q0 H15 K0
M974 Q0 S2 P0

M975 S1
G1 F30000
G1 X230 Y15
G28 X ; re-home XY
;===== mech mode fast check============================


;start heatbed  scan====================================
M976 S2 P1
G90
G1 X128 Y128 F20000
M976 S3 P2  ;register void printing detection


;===== nozzle load line ===============================
M975 S1
G90
M83
T1000
G1 X18.0 Y1.0 Z0.8 F18000;Move to start position
M109 S220
G1 Z0.2
G0 E2 F300
G0 X240 E15 F6033.27
G0 Y11 E0.700 F1508.32
G0 X239.5
G0 E0.2
G0 Y1.5 E0.700
G0 X231 E0.700 F6033.27
M400

;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==
;curr_bed_type=Cool Plate


;===== draw extrinsic para cali paint =================
M1002 judge_flag extrude_cali_flag
M622 J1

    M1002 gcode_claim_action : 8

    T1000

    G0 F1200.0 X231 Y12   Z0.2 E0.577
    G0 F1200.0 X226 Y12   Z0.2 E0.275
    G0 F1200.0 X226 Y1.5  Z0.2 E0.577
    G0 F1200.0 X220 Y1.5  Z0.2 E0.330
    G0 F1200.0 X220 Y8    Z0.2 E0.358
    G0 F1200.0 X210 Y8    Z0.2 E0.549
    G0 F1200.0 X210 Y1.5  Z0.2 E0.357

    G0 X48.0 E11.9 F6033.27
    G0 X48.0 Y12 E0.772 F1200.0
    G0 X45.0 E0.22 F1200.0
    G0 X35.0 Y6.0 E0.86 F1200.0

    ;=========== extruder cali extrusion ==================
    T1000
    M83
    
        
            M204 S5000
        
    
    G0 X35.000 Y6.000 Z0.300 F30000 E0
    G1 F1500.000 E0.800
    M106 S0 ; turn off fan
    G0 X185.000 E9.35441 F6033.27
    G0 X187 Z0
    G1 F1500.000 E-0.800
    G0 Z1
    G0 X180 Z0.3 F18000

    M900 L1000.0 M1.0
    M900 K0.040
    G0 X45.000 F30000
    G0 Y8.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
M73 P20 R23
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.020
    G0 X45.000 F30000
    G0 Y10.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
M73 P21 R23
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
M73 P21 R22
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3
    M400

    G0 X45.000 F30000
    M900 K0.000
    G0 X45.000 F30000
    G0 Y12.000 F30000
    G1 F1500.000 E0.800
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27
    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F6033.27
    G1 F1500.000 E-0.800
    G1 X183 Z0.15 F30000
    G1 X185
    G1 Z1.0
    G0 Y6.000 F30000 ; move y to clear pos
    G1 Z0.3

    G0 X45.000 F30000 ; move to start point

M623 ; end of "draw extrinsic para cali paint"


M1002 judge_flag extrude_cali_flag
M622 J0
    G0 X231 Y1.5 F30000
    G0 X18 E14.3 F6033.27
M623

M104 S140


;=========== laser and rgb calibration ===========
M400
M18 E
M500 R

M973 S3 P14

G1 X120 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
T1100
G1 X235.0 Y1.0 Z0.3 F18000.0;Move to first extrude line pos
M400 P100
M960 S1 P1
M400 P100
M973 S6 P0; use auto exposure for horizontal laser by xcam
M960 S0 P0

G1 X240.0 Y6.0 Z0.3 F18000.0;Move to vertical extrude line pos
M960 S2 P1
M400 P100
M973 S6 P1; use auto exposure for vertical laser by xcam
M960 S0 P0

;=========== handeye calibration ======================
M1002 judge_flag extrude_cali_flag
M622 J1

    M973 S3 P1 ; camera start stream
    M400 P500
    M973 S1
    G0 F6000 X228.500 Y4.750 Z0.000
    M960 S0 P1
    M973 S1
    M400 P800
    M971 S6 P0
    M973 S2 P0
    M400 P500
    G0 Z0.000 F12000
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P200
    M971 S5 P1
    M973 S2 P1
    M400 P500
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P3
    G0 Z0.500 F12000
    M960 S0 P0
    M960 S2 P1
    G0 X228.5 Y6.75
    M400 P200
    M971 S5 P4
    M973 S2 P0
    M400 P500
    M960 S0 P0
    M960 S1 P1
    G0 X215.00 Y4.750
    M400 P500
    M971 S5 P2
    M963 S1
    M400 P1500
    M964
    T1100
    G1 Z3 F3000

    M400
    M500 ; save cali data

    M104 S220 ; rise nozzle temp now ,to reduce temp waiting time.

    T1100
    M400 P400
    M960 S0 P0
    G0 F30000.000 Y10.000 X65.000 Z0.000
    M400 P400
    M960 S1 P1
    M400 P50

    M969 S1 N3 A2000
    G0 F360.000 X181.000 Z0.000
    M980.3 A70.000 B94.1106 C5.000 D376.442 E5.000 F175.000 H1.000 I0.000 J0.020 K0.040
    M400 P100
    G0 F20000
    G0 Z1 ; rise nozzle up
    T1000 ; change to nozzle space
    G0 X45.000 Y4.000 F30000 ; move to test line pos
    M969 S0 ; turn off scanning
    M960 S0 P0


    G1 Z2 F20000
    T1000
    G0 X45.000 Y4.000 F30000 E0
    M109 S220
    G0 Z0.3
    G1 F1500.000 E3.600
    G1 X65.000 E1.24726 F1508.32
    G1 X70.000 E0.31181 F1508.32
    G1 X75.000 E0.31181 F6033.27
    G1 X80.000 E0.31181 F1508.32
    G1 X85.000 E0.31181 F6033.27
M73 P22 R22
    G1 X90.000 E0.31181 F1508.32
    G1 X95.000 E0.31181 F6033.27
    G1 X100.000 E0.31181 F1508.32
    G1 X105.000 E0.31181 F6033.27
    G1 X110.000 E0.31181 F1508.32
    G1 X115.000 E0.31181 F6033.27
    G1 X120.000 E0.31181 F1508.32
    G1 X125.000 E0.31181 F6033.27
    G1 X130.000 E0.31181 F1508.32
    G1 X135.000 E0.31181 F6033.27

    ; see if extrude cali success, if not ,use default value
    M1002 judge_last_extrude_cali_success
    M622 J0
        M400
        M900 K0.02 M0.125481
    M623

    G1 X140.000 E0.31181 F1508.32
    G1 X145.000 E0.31181 F6033.27
    G1 X150.000 E0.31181 F1508.32
    G1 X155.000 E0.31181 F6033.27
    G1 X160.000 E0.31181 F1508.32
    G1 X165.000 E0.31181 F6033.27
    G1 X170.000 E0.31181 F1508.32
    G1 X175.000 E0.31181 F6033.27
    G1 X180.000 E0.31181 F1508.32
    G1 X185.000 E0.31181 F6033.27
    G1 X190.000 E0.31181 F1508.32
    G1 X195.000 E0.31181 F6033.27
    G1 X200.000 E0.31181 F1508.32
    G1 X205.000 E0.31181 F6033.27
    G1 X210.000 E0.31181 F1508.32
    G1 X215.000 E0.31181 F6033.27
    G1 X220.000 E0.31181 F1508.32
    G1 X225.000 E0.31181 F6033.27
    M973 S4

M623

;========turn off light and wait extrude temperature =============
M1002 gcode_claim_action : 0
M973 S4 ; turn off scanner
M400 ; wait all motion done before implement the emprical L parameters
;M900 L500.0 ; Empirical parameters
M109 S220
M960 S1 P0 ; turn off laser
M960 S2 P0 ; turn off laser
M106 S0 ; turn off fan
M106 P2 S0 ; turn off big fan
M106 P3 S0 ; turn off chamber fan

M975 S1 ; turn on mech mode supression
G90
M83
T1000
;===== purge line to wipe the nozzle ============================
G1 E-0.8 F1800
G1 X18.0 Y2.5 Z0.8 F18000.0;Move to start position
G1 E0.8 F1800
M109 S220
G1 Z0.2
G0 X239 E15 F6033.27
G0 Y12 E0.7 F1508.32
; MACHINE_START_GCODE_END
; filament start gcode

M142 P1 R35 S40
;VT0 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/33
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
M106 P2 S0
; OBJECT_ID: 15
G1 X182.75 Y115.026 F30000
M204 S6000
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X182.75 Y115.457 E.01604
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.25 Y115.457 E4.07846
G1 X73.25 Y115.026 E.01604
G1 X182.69 Y115.026 E4.07622
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X182.75 Y115.457 E-.16522
G1 X181.185 Y115.457 E-.59479
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/33
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S255
M106 P2 S178
; open powerlost recovery
M1003 S1
M976 S1 P1 ; scan model before printing 2nd layer
M400 P100
G1 E.8
; OBJECT_ID: 15
G1 E-.8
M204 S10000
G1 X182.398 Y115.11 Z.6 F30000
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F7145.013
G1 X182.398 Y115.524 E.01376
G1 F2040
G1 X182.398 Y115.876 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X73.602 Y115.876 E3.60896
G1 F2040
G1 X73.602 Y115.524 E.01167
G1 F7145.013
G1 X73.602 Y115.11 E.01376
G1 F15000.251
G1 X74.002 Y115.11 E.01327
G1 F15476.087
G1 X74.402 Y115.11 E.01327
G1 X182.338 Y115.11 E3.58043
M204 S250
G1 X182.79 Y114.945 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F9731.098
M204 S5000
G1 X182.79 Y115.538 E.01821
G1 F1800
G1 X182.79 Y115.907 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y116.268 E.01199
G1 F600
G1 X73.21 Y116.268 E3.63497
G1 X73.21 Y115.907 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y115.538 E.01134
G1 F4975.379
G1 X73.21 Y114.945 E.01821
G1 F2760
M73 P23 R22
G1 X73.21 Y114.717 E.007
G1 F1320
M73 P24 R22
G1 X182.79 Y114.717 E3.36709
G1 F2730.831
G1 X182.79 Y114.885 E.00516
M204 S10000
G1 X182.194 Y115.493 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.40262
G1 F15000
G1 X73.806 Y115.493 E3.17698
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X75.806 Y115.493 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/33
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z.8 I.006 J1.217 P1  F30000
G1 X182.398 Y114.965 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y115.496 E.0176
G1 F14655.771
G1 X182.398 Y115.896 E.01327
G1 F6907.886
G1 X182.398 Y116.296 E.01327
G1 F2040
G1 X182.398 Y116.648 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X73.602 Y116.648 E3.60896
G1 F2040
G1 X73.602 Y116.296 E.01167
G1 F6907.886
G1 X73.602 Y115.896 E.01327
G1 F14655.771
G1 X73.602 Y115.496 E.01327
G1 F15476.087
G1 X73.602 Y114.965 E.0176
G1 X182.338 Y114.965 E3.60697
M204 S250
G1 X182.79 Y114.573 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F10200
M204 S5000
G1 X182.79 Y114.676 E.00317
G1 F12000
G1 X182.79 Y115.076 E.01229
G1 X182.79 Y115.509 E.0133
G1 X182.79 Y115.909 E.01229
G1 F6459.938
G1 X182.79 Y116.309 E.01229
G1 F1800
G1 X182.79 Y116.678 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y117.04 E.01199
G1 F600
G1 X73.21 Y117.04 E3.63497
G1 X73.21 Y116.678 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y116.309 E.01134
G1 F6459.938
G1 X73.21 Y115.909 E.01229
G1 F12000
G1 X73.21 Y115.509 E.01229
G1 X73.21 Y115.076 E.0133
G1 F10281.682
M73 P25 R21
G1 X73.21 Y114.676 E.01229
G1 F4026.067
G1 X73.21 Y114.573 E.00317
G1 F2880
G1 X182.73 Y114.573 E3.36524
M204 S10000
G1 X182.234 Y115.372 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y115.372 E3.99314
G1 X73.935 Y115.824 E.01668
G1 X182.065 Y115.824 E3.98688
G1 X182.065 Y116.277 E.01668
G1 X73.766 Y116.277 E3.99314
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X75.766 Y116.277 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 4/33
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1 I.016 J1.217 P1  F30000
G1 X182.398 Y114.886 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y115.867 E.03256
G1 X182.398 Y116.267 E.01327
G1 F14655.771
G1 X182.398 Y116.667 E.01327
G1 F6907.886
G1 X182.398 Y117.067 E.01327
G1 F2040
G1 X182.398 Y117.419 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X165.728 Y117.419 E.55297
G1 X165.652 Y117.364 E.0031
G1 F960
G1 X165.535 Y117.287 E.00465
M73 P26 R21
G1 F1920
G1 X165.414 Y117.216 E.00467
G1 F2760
G1 X165.29 Y117.15 E.00465
G1 F4339.209
G1 X165.163 Y117.091 E.00466
G1 F5152.019
G1 X165.105 Y117.067 E.00206
G1 F11200.05
G1 X164.766 Y116.951 E.01191
G1 F15476.087
G1 X164.492 Y116.891 E.0093
G2 X162.895 Y117.067 I-.492 J2.86 E.05401
G1 X162.843 Y117.088 E.00186
G1 F4485.813
G1 X162.716 Y117.147 E.00465
G1 F2880
G1 X162.592 Y117.212 E.00464
G1 F2040
G1 X162.47 Y117.284 E.00466
G1 F1080
G1 X162.353 Y117.36 E.00464
G1 F600
G1 X162.272 Y117.419 E.00334
G1 X147.728 Y117.419 E.48245
G1 X147.652 Y117.364 E.0031
G1 F960
G1 X147.535 Y117.287 E.00465
G1 F1920
G1 X147.414 Y117.216 E.00467
G1 F2760
M73 P27 R21
G1 X147.29 Y117.15 E.00466
G1 F4335.465
G1 X147.163 Y117.091 E.00465
G1 F5149.457
G1 X147.105 Y117.067 E.00207
G1 F11197.097
G1 X146.766 Y116.951 E.01191
G1 F15476.087
G1 X146.492 Y116.891 E.0093
G2 X144.895 Y117.067 I-.492 J2.86 E.054
G1 X144.843 Y117.088 E.00186
G1 F4479.797
G1 X144.716 Y117.147 E.00464
G1 F2880
G1 X144.591 Y117.212 E.00466
G1 F2040
G1 X144.471 Y117.283 E.00465
G1 F1080
G1 X144.353 Y117.36 E.00465
G1 F600
G1 X144.272 Y117.419 E.00333
G1 X129.728 Y117.419 E.48245
G1 X129.652 Y117.364 E.0031
G1 F960
G1 X129.535 Y117.287 E.00465
G1 F1920
G1 X129.414 Y117.216 E.00467
G1 F2760
G1 X129.29 Y117.15 E.00466
G1 F4335.465
G1 X129.163 Y117.091 E.00465
G1 F5149.457
G1 X129.105 Y117.067 E.00207
G1 F11197.097
G1 X128.766 Y116.951 E.01191
G1 F15476.087
G1 X128.492 Y116.891 E.0093
G2 X126.895 Y117.067 I-.492 J2.86 E.05401
M73 P28 R21
G1 X126.843 Y117.088 E.00186
G1 F4487.979
G1 X126.715 Y117.148 E.00466
G1 F2880
G1 X126.591 Y117.213 E.00466
G1 F2040
G1 X126.471 Y117.283 E.00464
M73 P28 R20
G1 F1080
G1 X126.353 Y117.36 E.00466
G1 F600
G1 X126.272 Y117.419 E.00333
G1 X111.728 Y117.419 E.48245
G1 X111.652 Y117.364 E.0031
G1 F960
G1 X111.535 Y117.287 E.00465
G1 F1920
G1 X111.414 Y117.216 E.00466
G1 F2760
G1 X111.29 Y117.15 E.00465
G1 F4335.692
G1 X111.163 Y117.091 E.00465
G1 F5151.17
G1 X111.105 Y117.067 E.00207
G1 F11196.069
G1 X110.766 Y116.951 E.0119
G1 F15476.087
G1 X110.492 Y116.891 E.0093
G2 X108.895 Y117.067 I-.492 J2.86 E.05401
G1 X108.843 Y117.088 E.00185
G1 F4486.328
G1 X108.716 Y117.147 E.00466
G1 F2880
G1 X108.591 Y117.213 E.00465
G1 F2040
G1 X108.471 Y117.283 E.00465
G1 F1080
G1 X108.353 Y117.36 E.00464
G1 F600
G1 X108.272 Y117.419 E.00334
G1 X93.728 Y117.419 E.48245
G1 X93.652 Y117.364 E.00311
G1 F960
G1 X93.535 Y117.287 E.00464
G1 F1920
G1 X93.414 Y117.216 E.00468
G1 F2760
G1 X93.29 Y117.15 E.00464
G1 F4334.061
G1 X93.163 Y117.091 E.00465
G1 F5150.986
G1 X93.105 Y117.067 E.00208
G1 F11196.812
G1 X92.766 Y116.951 E.0119
G1 F15476.087
G1 X92.492 Y116.891 E.0093
G2 X90.895 Y117.067 I-.492 J2.86 E.05401
G1 X90.843 Y117.088 E.00185
G1 F4486.328
G1 X90.716 Y117.147 E.00466
G1 F2880
G1 X90.591 Y117.213 E.00465
G1 F2040
G1 X90.471 Y117.283 E.00465
G1 F1080
G1 X90.353 Y117.36 E.00464
G1 F600
G1 X90.272 Y117.419 E.00334
G1 X73.602 Y117.419 E.55297
G1 F2040
G1 X73.602 Y117.067 E.01167
G1 F6907.886
G1 X73.602 Y116.667 E.01327
G1 F14655.771
G1 X73.602 Y116.267 E.01327
G1 F15476.087
G1 X73.602 Y115.867 E.01327
G1 X73.602 Y114.886 E.03256
G1 X182.338 Y114.886 E3.60697
M204 S250
G1 X182.79 Y114.494 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y114.532 E.00119
G1 X182.79 Y116.281 E.05373
G1 X182.79 Y116.681 E.01229
G1 F6459.938
G1 X182.79 Y117.081 E.01229
G1 F1800
G1 X182.79 Y117.45 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y117.811 E.01199
G1 F600
G1 X165.592 Y117.811 E.5705
G2 X165.005 Y117.45 I-1.597 J1.937 E.02294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X164.893 Y117.404 E.0037
G1 X164.779 Y117.364 E.00373
G1 F840
G1 X164.662 Y117.329 E.00373
G1 F1200
G1 X164.545 Y117.3 E.00372
G1 F1560
G1 X164.425 Y117.276 E.00374
G1 F1800
G1 X164.305 Y117.259 E.00373
G1 F2040
G1 X164.184 Y117.247 E.00374
G1 F2160
G2 X163.821 Y117.246 I-.185 J2.818 E.01117
G1 F2040
G1 X163.7 Y117.258 E.00374
G1 F1800
G1 X163.58 Y117.275 E.00372
G1 F1560
G1 X163.461 Y117.299 E.00373
G1 F1200
G1 X163.343 Y117.328 E.00374
G1 F840
G1 X163.226 Y117.362 E.00373
G1 F600
G1 X163.112 Y117.402 E.00373
G1 X162.999 Y117.448 E.00374
G1 X162.995 Y117.45 E.00013
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X162.408 Y117.811 I1.13 J2.492 E.02293
G1 X147.592 Y117.811 E.4915
G2 X147.005 Y117.45 I-1.597 J1.936 E.02294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X146.893 Y117.404 E.0037
G1 X146.779 Y117.364 E.00373
G1 F840
G1 X146.662 Y117.329 E.00373
G1 F1200
G1 X146.545 Y117.3 E.00372
G1 F1560
G1 X146.425 Y117.276 E.00374
G1 F1800
G1 X146.305 Y117.259 E.00373
G1 F2040
G1 X146.185 Y117.247 E.00373
G1 F2160
G2 X145.821 Y117.246 I-.185 J2.817 E.01118
G1 F2040
G1 X145.7 Y117.258 E.00374
G1 F1800
G1 X145.58 Y117.275 E.00372
G1 F1560
G1 X145.461 Y117.299 E.00373
G1 F1200
G1 X145.343 Y117.328 E.00374
G1 F840
G1 X145.226 Y117.362 E.00373
G1 F600
G1 X145.112 Y117.402 E.00373
G1 X144.999 Y117.448 E.00374
G1 X144.995 Y117.45 E.00012
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X144.408 Y117.811 I1.129 J2.491 E.02293
G1 X129.592 Y117.811 E.4915
G2 X129.005 Y117.45 I-1.597 J1.936 E.02294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X128.893 Y117.404 E.0037
G1 X128.779 Y117.364 E.00373
G1 F840
G1 X128.662 Y117.329 E.00373
G1 F1200
G1 X128.545 Y117.3 E.00372
G1 F1560
G1 X128.425 Y117.276 E.00374
G1 F1800
G1 X128.305 Y117.259 E.00373
G1 F2040
M73 P29 R20
G1 X128.184 Y117.247 E.00374
G1 F2160
G2 X127.821 Y117.246 I-.185 J2.818 E.01117
G1 F2040
G1 X127.7 Y117.258 E.00374
G1 F1800
G1 X127.58 Y117.275 E.00372
G1 F1560
G1 X127.461 Y117.299 E.00373
G1 F1200
G1 X127.343 Y117.328 E.00374
G1 F840
G1 X127.226 Y117.362 E.00373
G1 F600
G1 X127.112 Y117.402 E.00373
G1 X126.999 Y117.448 E.00373
G1 X126.995 Y117.45 E.00013
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X126.409 Y117.811 I1.129 J2.491 E.02293
G1 X111.592 Y117.811 E.4915
G2 X111.005 Y117.45 I-1.597 J1.937 E.02294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X110.893 Y117.404 E.0037
G1 X110.779 Y117.364 E.00374
G1 F840
G1 X110.662 Y117.329 E.00373
G1 F1200
G1 X110.545 Y117.3 E.00372
G1 F1560
G1 X110.426 Y117.276 E.00373
G1 F1800
G1 X110.305 Y117.259 E.00373
G1 F2040
G1 X110.185 Y117.247 E.00373
G1 F2160
G2 X109.821 Y117.246 I-.185 J2.817 E.01118
G1 F2040
G1 X109.7 Y117.258 E.00374
G1 F1800
G1 X109.58 Y117.275 E.00372
G1 F1560
G1 X109.461 Y117.299 E.00373
G1 F1200
G1 X109.343 Y117.328 E.00373
G1 F840
G1 X109.227 Y117.362 E.00373
G1 F600
G1 X109.112 Y117.402 E.00374
G1 X108.999 Y117.448 E.00373
G1 X108.995 Y117.45 E.00013
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X108.409 Y117.811 I1.129 J2.49 E.02293
G1 X93.592 Y117.811 E.4915
G2 X93.005 Y117.45 I-1.598 J1.938 E.02294
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X92.893 Y117.404 E.0037
G1 X92.779 Y117.364 E.00374
G1 F840
G1 X92.662 Y117.329 E.00373
G1 F1200
G1 X92.545 Y117.3 E.00372
G1 F1560
G1 X92.425 Y117.276 E.00374
G1 F1800
G1 X92.305 Y117.259 E.00373
G1 F2040
G1 X92.184 Y117.247 E.00374
G1 F2160
G2 X91.821 Y117.246 I-.185 J2.818 E.01117
G1 F2040
G1 X91.7 Y117.258 E.00374
G1 F1800
G1 X91.58 Y117.275 E.00372
G1 F1560
G1 X91.461 Y117.299 E.00373
G1 F1200
G1 X91.343 Y117.328 E.00373
G1 F840
G1 X91.227 Y117.362 E.00373
G1 F600
G1 X91.112 Y117.402 E.00374
G1 X90.999 Y117.448 E.00373
G1 X90.995 Y117.45 E.00013
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X90.409 Y117.811 I1.129 J2.49 E.02293
G1 X73.21 Y117.811 E.57051
G1 X73.21 Y117.45 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y117.081 E.01134
G1 F6459.938
G1 X73.21 Y116.681 E.01229
G1 F12000
G1 X73.21 Y116.281 E.01229
G1 X73.21 Y114.532 E.05373
G1 X73.21 Y114.494 E.00119
G1 X182.73 Y114.494 E3.36524
; WIPE_START
M204 S10000
G1 X182.79 Y114.532 E-.02711
G1 X182.79 Y116.281 E-.66442
G1 X182.79 Y116.461 E-.06848
; WIPE_END
G1 E-.04 F1800
G1 X182.234 Y116.143 Z1.2 F30000
G1 Z.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X165.274 Y116.143 E.62534
G1 X165.159 Y116.208 E.00489
G2 X164.786 Y116.596 I.413 J.77 E.02015
G1 X182.065 Y116.596 E.63709
G1 X182.065 Y117.048 E.01668
G1 X165.436 Y117.048 E.61311
G1 X163.038 Y116.143 F30000
G1 F3000
G1 X147.274 Y116.143 E.58121
G1 X147.159 Y116.208 E.00488
G2 X146.786 Y116.596 I.412 J.769 E.02015
G1 X163.214 Y116.596 E.60571
G1 X163.224 Y116.617 E.00086
G2 X162.24 Y117.048 I.746 J3.041 E.03982
G1 X147.436 Y117.048 E.54582
G1 X145.038 Y116.143 F30000
G1 F3000
G1 X129.274 Y116.143 E.58121
G1 X129.159 Y116.208 E.00488
G2 X128.786 Y116.596 I.412 J.769 E.02015
G1 X145.214 Y116.596 E.60571
G1 X145.224 Y116.617 E.00086
G2 X144.24 Y117.048 I.745 J3.04 E.03982
G1 X129.436 Y117.048 E.54582
G1 X127.038 Y116.143 F30000
G1 F3000
G1 X111.274 Y116.143 E.58121
G1 X111.159 Y116.208 E.00488
G2 X110.786 Y116.596 I.413 J.77 E.02015
G1 X127.214 Y116.596 E.60572
G1 X127.224 Y116.617 E.00086
G2 X126.264 Y117.033 I.738 J3.015 E.03876
G1 X126.24 Y117.048 E.00106
G1 X111.436 Y117.048 E.54582
G1 X109.038 Y116.143 F30000
G1 F3000
G1 X93.274 Y116.143 E.58121
G1 X93.159 Y116.208 E.00488
G2 X92.786 Y116.596 I.413 J.77 E.02015
G1 X109.214 Y116.596 E.60572
G1 X109.224 Y116.617 E.00086
G2 X108.264 Y117.033 I.738 J3.016 E.03876
G1 X108.24 Y117.048 E.00106
G1 X93.436 Y117.048 E.54582
G1 X92.62 Y115.669 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.446553
G1 F15000
G3 X91.377 Y115.667 I.294 J-475.964 E.04088
G3 X91.801 Y116.078 I-.614 J1.057 E.0196
G1 X92.212 Y116.084 E.01352
G1 X92.434 Y115.803 E.01178
G1 X92.571 Y115.704 E.00556
G1 X110.62 Y115.669 F30000
G1 F15000
G3 X109.377 Y115.667 I.294 J-475.904 E.04088
G3 X109.801 Y116.078 I-.614 J1.057 E.0196
G1 X110.212 Y116.084 E.01352
G1 X110.434 Y115.803 E.01178
G1 X110.571 Y115.704 E.00557
G1 X128.212 Y116.084 F30000
; LINE_WIDTH: 0.446605
G1 F15000
G1 X128.434 Y115.803 E.01179
G1 X128.62 Y115.669 E.00753
G3 X127.377 Y115.667 I.306 J-480.318 E.04088
G3 X127.801 Y116.078 I-.614 J1.057 E.0196
G1 X128.152 Y116.083 E.01155
G1 X128.428 Y116.493 F30000
; LINE_WIDTH: 0.42101
G1 F15000
G1 X128.662 Y116.121 E.01353
G1 X129.078 Y115.823 E.01577
G1 X129.625 Y115.659 E.0176
G1 X144.309 Y115.655 E.45239
G1 X144.855 Y115.791 E.01735
G1 X145.284 Y116.071 E.01578
G1 X145.483 Y116.299 E.00931
G1 X145.57 Y116.493 E.00655
G3 X146.428 Y116.493 I.429 J3.328 E.02651
G1 X146.662 Y116.121 E.01353
G1 X147.078 Y115.823 E.01577
G1 X147.625 Y115.659 E.0176
G1 X162.309 Y115.655 E.45239
G1 X162.855 Y115.791 E.01735
G1 X163.284 Y116.071 E.01578
G1 X163.483 Y116.299 E.00931
G1 X163.57 Y116.493 E.00655
G3 X164.427 Y116.493 I.427 J3.293 E.02648
G1 X164.662 Y116.12 E.01357
G1 X165.078 Y115.823 E.01576
G1 X165.626 Y115.659 E.01761
G1 X182.006 Y115.655 E.50467
G1 X182.006 Y115.278 E.01163
G1 X165.625 Y115.279 E.50467
G2 X162.309 Y115.278 I-1.908 J745.403 E.10218
G1 X147.625 Y115.279 E.4524
G2 X144.309 Y115.278 I-1.908 J745.147 E.10218
G1 X129.625 Y115.279 E.4524
G2 X126.309 Y115.278 I-1.908 J745.142 E.10217
G1 X111.626 Y115.279 E.45239
G2 X108.309 Y115.278 I-1.907 J751.287 E.10218
G1 X93.626 Y115.279 E.45239
G2 X90.309 Y115.278 I-1.907 J751.287 E.10218
G1 X73.994 Y115.278 E.50265
G1 X73.994 Y115.655 E.01163
G1 X90.309 Y115.655 E.50265
G1 X90.855 Y115.791 E.01734
G1 X91.284 Y116.071 E.01578
G1 X91.483 Y116.299 E.00931
G1 X91.57 Y116.493 E.00655
G3 X92.428 Y116.493 I.429 J3.328 E.02651
G1 X92.662 Y116.121 E.01353
G1 X93.078 Y115.823 E.01578
G1 X93.626 Y115.659 E.01761
G1 X108.309 Y115.655 E.45239
G1 X108.855 Y115.791 E.01734
G1 X109.284 Y116.071 E.01578
G1 X109.483 Y116.299 E.00931
G1 X109.57 Y116.493 E.00655
G3 X110.428 Y116.493 I.428 J3.327 E.02651
G1 X110.662 Y116.121 E.01353
G1 X111.078 Y115.823 E.01578
G1 X111.626 Y115.659 E.01761
G1 X126.309 Y115.655 E.45238
G1 X126.855 Y115.791 E.01734
G1 X127.284 Y116.071 E.01578
G1 X127.483 Y116.298 E.00931
G1 X127.57 Y116.493 E.00656
G3 X128.368 Y116.488 I.416 J3.092 E.02466
G1 X145.377 Y115.667 F30000
; LINE_WIDTH: 0.446661
G1 F15000
G3 X145.801 Y116.078 I-.614 J1.057 E.01961
G1 X146.212 Y116.084 E.01353
G1 X146.434 Y115.803 E.01179
G1 X146.62 Y115.669 E.00753
G3 X145.437 Y115.667 I.099 J-340.355 E.03891
G1 X163.377 Y115.667 F30000
; LINE_WIDTH: 0.446684
G1 F15000
G3 X163.801 Y116.078 I-.614 J1.057 E.01961
G1 X164.212 Y116.084 E.01352
G1 X164.434 Y115.802 E.01182
G1 X164.62 Y115.669 E.00751
G3 X163.437 Y115.667 I.099 J-337.552 E.03891
G1 X91.038 Y116.143 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
M73 P30 R20
G1 F3000
G1 X73.935 Y116.143 E.63059
G1 X73.935 Y116.596 E.01668
G1 X91.214 Y116.596 E.6371
G1 X91.224 Y116.617 E.00086
G2 X90.264 Y117.033 I.738 J3.016 E.03876
G1 X90.24 Y117.048 E.00106
G1 X73.766 Y117.048 E.60743
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X75.766 Y117.048 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/33
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.2 I.025 J1.217 P1  F30000
G1 X182.398 Y114.853 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y116.639 E.05922
G1 X182.398 Y117.039 E.01327
G1 F14655.771
G1 X182.398 Y117.439 E.01327
G1 F6907.886
G1 X182.398 Y117.839 E.01327
G1 F2040
G1 X182.398 Y118.191 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.449 Y118.191 E.52906
G1 F720
G1 X166.351 Y118.048 E.00572
G1 F1567.674
G1 X166.27 Y117.941 E.00446
G1 F2734.771
G1 X166.184 Y117.839 E.00444
G1 F2853.949
G1 X166.176 Y117.83 E.00039
G1 F6285.832
G1 X165.986 Y117.634 E.00904
G1 F11399.569
G1 X165.765 Y117.446 E.00961
G1 F15476.087
G1 X165.535 Y117.288 E.00927
G2 X162.472 Y117.284 I-1.535 J2.464 E.10706
G1 X162.248 Y117.437 E.00899
G1 F11970.353
G1 X162.024 Y117.624 E.00967
G1 F6683.318
G1 X161.816 Y117.839 E.00992
G1 F2849.448
G1 X161.738 Y117.932 E.00404
G1 F1748.894
G1 X161.656 Y118.039 E.00449
G1 F840
G1 X161.551 Y118.191 E.00611
G1 F600
G1 X148.449 Y118.191 E.43462
G1 F720
G1 X148.351 Y118.048 E.00573
G1 F1565.842
G1 X148.27 Y117.941 E.00445
G1 F2732.211
G1 X148.184 Y117.839 E.00444
G1 F2851.335
G1 X148.176 Y117.83 E.00039
G1 F6281.951
G1 X147.986 Y117.634 E.00904
G1 F11392.035
G1 X147.765 Y117.447 E.00961
G1 F15476.087
G1 X147.534 Y117.289 E.00927
G2 X144.473 Y117.285 I-1.534 J2.473 E.10696
G1 X144.248 Y117.437 E.00899
G1 F11970.339
G1 X144.024 Y117.624 E.00967
G1 F6682.652
G1 X143.816 Y117.839 E.00992
G1 F2849.513
G1 X143.738 Y117.932 E.00404
G1 F1748.894
G1 X143.656 Y118.039 E.00449
G1 F840
G1 X143.551 Y118.191 E.00611
G1 F600
G1 X130.449 Y118.191 E.43462
G1 F720
G1 X130.351 Y118.048 E.00573
G1 F1565.842
G1 X130.27 Y117.941 E.00445
G1 F2732.211
G1 X130.184 Y117.839 E.00444
G1 F2851.335
G1 X130.176 Y117.83 E.00039
G1 F6281.951
G1 X129.986 Y117.634 E.00904
G1 F11392.035
G1 X129.765 Y117.447 E.00961
G1 F15476.087
G1 X129.534 Y117.289 E.00927
G2 X126.472 Y117.285 I-1.534 J2.473 E.10696
G1 X126.248 Y117.437 E.00898
G1 F11970.994
G1 X126.024 Y117.624 E.00967
G1 F6683.023
G1 X125.816 Y117.839 E.00992
G1 F2849.685
G1 X125.738 Y117.932 E.00404
G1 F1748.987
G1 X125.656 Y118.039 E.00449
G1 F840
G1 X125.551 Y118.191 E.0061
G1 F600
G1 X112.449 Y118.191 E.43462
G1 F720
G1 X112.351 Y118.048 E.00573
G1 F1565.842
G1 X112.27 Y117.941 E.00445
G1 F2732.211
G1 X112.184 Y117.839 E.00444
G1 F2851.335
G1 X112.176 Y117.83 E.00039
G1 F8706.836
G1 X111.876 Y117.535 E.01396
G1 F14148.37
G1 X111.661 Y117.371 E.00896
G1 F15476.087
G1 X111.413 Y117.216 E.00969
G2 X108.472 Y117.284 I-1.413 J2.537 E.10236
G1 X108.248 Y117.437 E.00898
G1 F11970.994
G1 X108.024 Y117.624 E.00967
G1 F6683.023
G1 X107.816 Y117.839 E.00992
G1 F2849.685
G1 X107.738 Y117.932 E.00404
G1 F1748.987
G1 X107.656 Y118.039 E.00449
G1 F840
G1 X107.551 Y118.191 E.0061
G1 F600
G1 X94.449 Y118.191 E.43462
G1 F720
G1 X94.351 Y118.048 E.00572
G1 F1567.674
G1 X94.27 Y117.941 E.00446
G1 F2734.771
G1 X94.184 Y117.839 E.00444
G1 F2853.949
G1 X94.176 Y117.83 E.00039
G1 F8711.404
G1 X93.876 Y117.535 E.01396
G1 F14154.194
G1 X93.661 Y117.371 E.00896
G1 F15476.087
G1 X93.413 Y117.216 E.00969
G2 X90.472 Y117.284 I-1.413 J2.537 E.10236
G1 X90.248 Y117.437 E.00898
G1 F11973.203
G1 X90.024 Y117.624 E.00967
G1 F6685.229
G1 X89.816 Y117.839 E.00992
G1 F2850.839
G1 X89.738 Y117.932 E.00404
G1 F1751.019
G1 X89.656 Y118.039 E.0045
G1 F840
G1 X89.551 Y118.191 E.0061
G1 F600
G1 X73.602 Y118.191 E.52905
G1 F2040
G1 X73.602 Y117.839 E.01167
G1 F6907.886
G1 X73.602 Y117.439 E.01327
G1 F14655.771
G1 X73.602 Y117.039 E.01327
G1 F15476.087
G1 X73.602 Y116.639 E.01327
G1 X73.602 Y114.853 E.05922
G1 X182.338 Y114.853 E3.60697
M204 S250
G1 X182.79 Y114.461 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y117.052 E.07961
G1 X182.79 Y117.452 E.01229
G1 F6459.938
G1 X182.79 Y117.852 E.01229
G1 F1800
G1 X182.79 Y118.221 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y118.583 E.01199
G1 F600
G1 X166.222 Y118.583 E.54959
G2 X165.99 Y118.221 I-3.014 J1.68 E.01426
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X165.963 Y118.186 E.00136
G1 X165.882 Y118.089 E.00389
G1 F1299.122
G1 X165.799 Y118 E.00374
G1 F2188.469
G1 X165.718 Y117.92 E.00348
G1 F3190.458
G1 X165.642 Y117.852 E.00314
G1 F8755.869
G1 X165.328 Y117.62 E.01201
G1 F12000
G1 X164.891 Y117.409 E.0149
G2 X162.89 Y117.503 I-.891 J2.366 E.06328
G1 X162.677 Y117.617 E.00743
G1 F8748.662
G1 X162.358 Y117.852 E.01218
G1 F3127.399
G1 X162.291 Y117.911 E.00274
G1 F2253.844
G1 X162.21 Y117.991 E.0035
G1 F1345.69
G1 X162.122 Y118.084 E.00395
G1 F600
G1 X162.044 Y118.178 E.00374
G1 X162.01 Y118.221 E.00169
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X161.778 Y118.583 I2.875 J2.102 E.01426
G1 X148.222 Y118.583 E.44968
G2 X147.99 Y118.221 I-3.014 J1.68 E.01426
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X147.963 Y118.186 E.00136
G1 X147.882 Y118.089 E.00389
G1 F1299.122
G1 X147.799 Y118 E.00374
G1 F2188.469
G1 X147.718 Y117.92 E.00348
G1 F3190.458
G1 X147.642 Y117.852 E.00314
G1 F8755.727
G1 X147.328 Y117.62 E.01201
G1 F12000
G1 X146.891 Y117.409 E.0149
G2 X144.89 Y117.503 I-.891 J2.366 E.06328
G1 X144.677 Y117.617 E.00743
G1 F8748.411
G1 X144.358 Y117.852 E.01218
G1 F3127.248
G1 X144.291 Y117.911 E.00274
G1 F2253.649
G1 X144.21 Y117.991 E.00349
G1 F1346.524
G1 X144.122 Y118.084 E.00395
G1 F600
G1 X144.044 Y118.178 E.00374
G1 X144.01 Y118.221 E.00169
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X143.778 Y118.583 I2.875 J2.102 E.01426
G1 X130.222 Y118.583 E.44968
G2 X129.99 Y118.221 I-3.014 J1.68 E.01426
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X129.963 Y118.186 E.00136
G1 X129.882 Y118.089 E.00389
G1 F1299.122
G1 X129.799 Y118 E.00374
G1 F2188.469
G1 X129.718 Y117.92 E.00348
G1 F3190.458
G1 X129.642 Y117.852 E.00314
G1 F8755.727
G1 X129.328 Y117.62 E.01201
G1 F12000
G1 X128.891 Y117.409 E.0149
G2 X126.89 Y117.503 I-.891 J2.366 E.06328
G1 X126.677 Y117.617 E.00743
G1 F8748.15
G1 X126.358 Y117.852 E.01218
G1 F3127.241
G1 X126.291 Y117.911 E.00274
G1 F2253.583
G1 X126.21 Y117.991 E.00349
G1 F1346.474
G1 X126.122 Y118.084 E.00395
G1 F600
G1 X126.044 Y118.178 E.00374
G1 X126.01 Y118.221 E.00169
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X125.778 Y118.583 I2.876 J2.103 E.01426
G1 X112.222 Y118.583 E.44968
G2 X111.99 Y118.221 I-3.014 J1.68 E.01426
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X111.963 Y118.186 E.00136
G1 X111.882 Y118.089 E.00389
G1 F1299.122
G1 X111.799 Y118 E.00374
G1 F2188.469
G1 X111.718 Y117.92 E.00348
G1 F3190.458
G1 X111.642 Y117.852 E.00314
G1 F6577.165
G1 X111.437 Y117.693 E.00797
G1 F11056.933
G1 X111.223 Y117.558 E.00779
G1 F12000
G1 X110.794 Y117.37 E.01438
G2 X108.889 Y117.5 I-.794 J2.382 E.06018
G1 X108.677 Y117.617 E.00744
G1 F8748.15
G1 X108.358 Y117.852 E.01218
G1 F3127.241
G1 X108.291 Y117.911 E.00274
G1 F2253.583
G1 X108.21 Y117.991 E.00349
G1 F1346.474
G1 X108.122 Y118.084 E.00395
G1 F600
G1 X108.044 Y118.178 E.00374
G1 X108.01 Y118.221 E.00169
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X107.778 Y118.583 I2.876 J2.103 E.01426
G1 X94.222 Y118.583 E.44968
G2 X93.99 Y118.221 I-3.01 J1.677 E.01426
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X93.963 Y118.186 E.00136
G1 X93.882 Y118.089 E.00389
G1 F1299.122
G1 X93.799 Y118 E.00374
G1 F2188.469
G1 X93.718 Y117.92 E.00348
G1 F3190.458
G1 X93.642 Y117.852 E.00314
G1 F6577.165
G1 X93.437 Y117.693 E.00797
G1 F11056.763
G1 X93.223 Y117.558 E.00779
G1 F12000
G1 X92.794 Y117.37 E.01438
G2 X90.889 Y117.5 I-.794 J2.382 E.06018
G1 X90.677 Y117.617 E.00744
G1 F8748.544
G1 X90.358 Y117.852 E.01218
G1 F3127.476
G1 X90.291 Y117.911 E.00274
G1 F2253.91
G1 X90.21 Y117.991 E.0035
G1 F1345.74
G1 X90.122 Y118.084 E.00395
G1 F600
G1 X90.044 Y118.178 E.00374
G1 X90.01 Y118.221 E.00169
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X89.778 Y118.583 I2.88 J2.105 E.01426
G1 X73.21 Y118.583 E.54959
G1 X73.21 Y118.221 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y117.852 E.01134
G1 F6459.938
G1 X73.21 Y117.452 E.01229
G1 F12000
G1 X73.21 Y117.052 E.01229
G1 X73.21 Y114.461 E.07961
G1 X182.73 Y114.461 E3.36524
; WIPE_START
M204 S10000
M73 P31 R20
G1 X182.776 Y116.461 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.213 Y116.177 Z1.4 F30000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.584 Y116.177 E.05401
G1 X178.609 Y115.202 E.04574
G1 X177.178 Y115.202 E.04748
G1 X176.203 Y116.177 E.04574
G1 X171.909 Y116.177 E.14245
G1 X170.933 Y115.202 E.04574
G1 X169.502 Y115.202 E.04748
G1 X168.527 Y116.177 E.04574
G1 X164.233 Y116.177 E.14245
G1 X163.257 Y115.202 E.04574
G1 X161.826 Y115.202 E.04748
G1 X160.851 Y116.177 E.04574
G1 X156.557 Y116.177 E.14245
G1 X155.581 Y115.202 E.04574
G1 X154.15 Y115.202 E.04748
G1 X153.175 Y116.177 E.04574
G1 X148.881 Y116.177 E.14245
G1 X147.906 Y115.202 E.04574
G1 X146.474 Y115.202 E.04748
G1 X145.499 Y116.177 E.04574
G1 X141.205 Y116.177 E.14245
G1 X140.23 Y115.202 E.04574
G1 X138.798 Y115.202 E.04748
G1 X137.823 Y116.177 E.04574
G1 X133.529 Y116.177 E.14245
G1 X132.554 Y115.202 E.04574
G1 X131.122 Y115.202 E.04748
G1 X130.147 Y116.177 E.04574
G1 X125.853 Y116.177 E.14245
G1 X124.878 Y115.202 E.04574
G1 X123.446 Y115.202 E.04748
G1 X122.471 Y116.177 E.04574
G1 X118.177 Y116.177 E.14245
G1 X117.202 Y115.202 E.04574
G1 X115.77 Y115.202 E.04748
G1 X114.795 Y116.177 E.04574
G1 X110.501 Y116.177 E.14245
G1 X109.526 Y115.202 E.04574
G1 X108.094 Y115.202 E.04748
G1 X107.119 Y116.177 E.04574
G1 X102.825 Y116.177 E.14245
G1 X101.85 Y115.202 E.04574
G1 X100.418 Y115.202 E.04748
G1 X99.443 Y116.177 E.04574
G1 X95.149 Y116.177 E.14245
G1 X94.174 Y115.202 E.04574
G1 X92.743 Y115.202 E.04748
G1 X91.767 Y116.177 E.04574
G1 X87.473 Y116.177 E.14245
G1 X86.498 Y115.202 E.04574
G1 X85.067 Y115.202 E.04748
G1 X84.091 Y116.177 E.04574
G1 X79.797 Y116.177 E.14245
G1 X78.822 Y115.202 E.04574
G1 X77.391 Y115.202 E.04748
G1 X76.416 Y116.177 E.04574
G1 X74.787 Y116.177 E.05401
G1 X73.923 Y116.498 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X89.488 Y116.498 E.43123
G1 X91.594 Y116.525 F30000
G1 F15000
G1 X92.347 Y116.524 E.02087
G1 X91.594 Y116.525 F30000
; LINE_WIDTH: 0.3609
G1 F15000
G3 X89.917 Y116.534 I-1.188 J-60.814 E.04346
G1 X90.351 Y116.757 E.01265
G1 X90.465 Y116.876 E.00427
G1 X91.129 Y116.607 E.01857
G1 X91.535 Y116.535 E.01067
G1 X94.398 Y116.5 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X107.488 Y116.498 E.36265
G1 X94.398 Y116.5 F30000
; LINE_WIDTH: 0.357594
G1 F15000
G3 X92.407 Y116.525 I-1.29 J-23.773 E.05108
G1 X92.865 Y116.607 E.01193
G1 X93.529 Y116.879 E.01839
G1 X93.633 Y116.771 E.00384
G1 X93.934 Y116.592 E.00898
G1 X94.34 Y116.512 E.01061
G1 X109.594 Y116.525 F30000
; LINE_WIDTH: 0.3609
G1 F15000
G3 X107.917 Y116.534 I-1.188 J-60.814 E.04346
G1 X108.351 Y116.757 E.01265
G1 X108.465 Y116.876 E.00427
G1 X109.129 Y116.607 E.01857
G1 X109.535 Y116.535 E.01067
G1 X109.594 Y116.525 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X110.347 Y116.524 E.02087
G1 X112.398 Y116.5 F30000
G1 F15000
G1 X125.488 Y116.498 E.36265
G1 X112.398 Y116.5 F30000
; LINE_WIDTH: 0.357592
G1 F15000
G3 X110.407 Y116.525 I-1.29 J-23.787 E.05108
G1 X110.865 Y116.607 E.01192
G1 X111.529 Y116.879 E.0184
G1 X111.633 Y116.771 E.00384
G1 X111.934 Y116.592 E.00898
G1 X112.34 Y116.512 E.01061
G1 X126.465 Y116.876 F30000
; LINE_WIDTH: 0.361138
G1 F15000
G1 X127.129 Y116.607 E.01858
G1 X127.594 Y116.525 E.01224
G3 X125.917 Y116.534 I-1.188 J-60.812 E.0435
G1 X126.351 Y116.757 E.01266
G1 X126.423 Y116.833 E.00271
G1 X127.594 Y116.525 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X128.354 Y116.524 E.02107
G1 X129.526 Y116.88 F30000
; LINE_WIDTH: 0.36168
G1 F15000
G1 X129.633 Y116.77 E.00398
G1 X129.934 Y116.591 E.0091
G1 X130.399 Y116.5 E.01229
G3 X128.414 Y116.526 I-1.258 J-20.75 E.05157
G1 X129.145 Y116.698 E.01949
G1 X129.472 Y116.854 E.00943
G1 X130.399 Y116.5 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X143.488 Y116.498 E.36264
G1 X143.917 Y116.535 F30000
; LINE_WIDTH: 0.361101
G1 F15000
G1 X144.352 Y116.758 E.01266
G1 X144.465 Y116.876 E.00425
G1 X145.129 Y116.607 E.01858
G1 X145.594 Y116.525 E.01224
G3 X143.977 Y116.536 I-1.353 J-77.579 E.04191
G1 X145.594 Y116.525 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X146.354 Y116.524 E.02107
G1 X146.414 Y116.526 F30000
; LINE_WIDTH: 0.361454
G1 F15000
G1 X147.145 Y116.698 E.01948
G1 X147.526 Y116.88 E.01098
G1 X147.633 Y116.77 E.00398
G1 X147.934 Y116.591 E.0091
G1 X148.399 Y116.5 E.01228
G3 X146.474 Y116.527 I-1.237 J-20.218 E.04997
G1 X148.399 Y116.5 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X161.488 Y116.498 E.36264
G1 X161.917 Y116.535 F30000
; LINE_WIDTH: 0.361101
G1 F15000
G1 X162.352 Y116.758 E.01266
G1 X162.465 Y116.876 E.00425
G1 X163.129 Y116.607 E.01858
G1 X163.594 Y116.525 E.01224
G3 X161.977 Y116.536 I-1.353 J-77.647 E.04191
G1 X163.594 Y116.525 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X164.354 Y116.524 E.02107
G1 X164.414 Y116.526 F30000
; LINE_WIDTH: 0.36146
G1 F15000
G1 X165.144 Y116.698 E.01947
G1 X165.526 Y116.88 E.01099
G1 X165.633 Y116.77 E.00398
G1 X165.934 Y116.591 E.00909
G1 X166.399 Y116.5 E.01228
G3 X164.474 Y116.527 I-1.237 J-20.221 E.04997
G1 X166.399 Y116.5 F30000
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y116.498 E.43272
G1 X182.234 Y116.915 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.047 Y116.915 E.59685
G2 X165.806 Y117.075 I.636 J1.219 E.01068
G3 X166.187 Y117.367 I-.991 J1.682 E.01774
G1 X182.065 Y117.367 E.58545
G1 X182.065 Y117.82 E.01668
G1 X166.38 Y117.82 E.57833
; WIPE_START
G1 X168.38 Y117.82 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.4 I.178 J-1.204 P1  F30000
G1 X162.272 Y116.915 Z1.4
G1 Z1
G1 E.8 F1800
G1 F3000
G1 X148.047 Y116.915 E.52449
G2 X147.806 Y117.075 I.636 J1.219 E.01068
G3 X148.187 Y117.367 I-.991 J1.682 E.01774
G1 X161.812 Y117.367 E.50239
G2 X161.408 Y117.82 I4.004 J3.984 E.02238
G1 X148.38 Y117.82 E.48036
; WIPE_START
G1 X150.38 Y117.82 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.4 I.178 J-1.204 P1  F30000
G1 X144.272 Y116.915 Z1.4
G1 Z1
G1 E.8 F1800
G1 F3000
G1 X130.047 Y116.915 E.52449
G2 X129.806 Y117.075 I.636 J1.219 E.01068
G3 X130.187 Y117.367 I-.991 J1.682 E.01774
G1 X143.812 Y117.367 E.50239
G2 X143.408 Y117.82 I4.004 J3.984 E.02238
G1 X130.38 Y117.82 E.48036
; WIPE_START
G1 X132.38 Y117.82 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.4 I.178 J-1.204 P1  F30000
G1 X126.272 Y116.915 Z1.4
G1 Z1
G1 E.8 F1800
G1 F3000
G1 X112.047 Y116.915 E.52449
G2 X111.806 Y117.075 I.639 J1.223 E.01068
G3 X112.187 Y117.367 I-.991 J1.682 E.01773
G1 X125.812 Y117.367 E.50239
G2 X125.408 Y117.82 I4.004 J3.983 E.02238
G1 X112.38 Y117.82 E.48036
; WIPE_START
G1 X114.38 Y117.82 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.4 I.178 J-1.204 P1  F30000
G1 X108.272 Y116.915 Z1.4
G1 Z1
G1 E.8 F1800
G1 F3000
G1 X94.047 Y116.915 E.52449
G2 X93.806 Y117.075 I.639 J1.224 E.01068
G3 X94.187 Y117.367 I-.991 J1.682 E.01773
G1 X107.812 Y117.367 E.50239
G2 X107.408 Y117.82 I4.004 J3.983 E.02238
G1 X94.38 Y117.82 E.48036
; WIPE_START
G1 X96.38 Y117.82 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.4 I.178 J-1.204 P1  F30000
G1 X90.272 Y116.915 Z1.4
G1 Z1
G1 E.8 F1800
G1 F3000
G1 X73.935 Y116.915 E.60236
G1 X73.935 Y117.367 E.01668
G1 X89.812 Y117.367 E.5854
G2 X89.408 Y117.82 I4 J3.98 E.02238
G1 X73.766 Y117.82 E.57675
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X75.766 Y117.82 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 6/33
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.4 I.034 J1.216 P1  F30000
G1 X182.398 Y114.852 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y117.41 E.08486
G1 X182.398 Y117.81 E.01327
G1 F14655.771
G1 X182.398 Y118.21 E.01327
G1 F6907.886
G1 X182.398 Y118.61 E.01327
G1 F2040
G1 X182.398 Y118.962 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.794 Y118.962 E.5176
G1 F960
G1 X166.74 Y118.792 E.00592
G1 F1961.78
G1 X166.69 Y118.661 E.00465
G1 F2452.862
G1 X166.668 Y118.61 E.00183
G1 F9512.011
G1 X166.43 Y118.164 E.01678
G1 F15476.087
G1 X166.174 Y117.83 E.01395
G2 X162.025 Y117.625 I-2.174 J1.923 E.15355
G1 X161.738 Y117.932 E.01395
G1 F15397.582
G1 X161.499 Y118.278 E.01395
G1 F7088.86
G1 X161.332 Y118.61 E.01233
G1 F2395.603
G1 X161.312 Y118.655 E.00164
G1 F1958.985
G1 X161.262 Y118.786 E.00464
G1 F960
G1 X161.205 Y118.962 E.00613
G1 F600
G1 X148.794 Y118.962 E.41169
G1 F960
G1 X148.74 Y118.792 E.00592
G1 F1963.669
G1 X148.69 Y118.661 E.00466
G1 F2452.951
G1 X148.668 Y118.61 E.00182
G1 F9513.023
G1 X148.43 Y118.164 E.01679
G1 F15476.087
G1 X148.173 Y117.831 E.01395
G2 X144.027 Y117.627 I-2.173 J1.929 E.15335
G1 X143.738 Y117.932 E.01394
G1 F15397.838
G1 X143.499 Y118.278 E.01395
G1 F7087.841
G1 X143.332 Y118.61 E.01232
G1 F2395.799
G1 X143.312 Y118.655 E.00163
G1 F1961.236
G1 X143.262 Y118.786 E.00465
G1 F960
G1 X143.205 Y118.962 E.00613
G1 F600
G1 X130.794 Y118.962 E.41169
G1 F960
G1 X130.74 Y118.792 E.00592
G1 F1963.669
G1 X130.69 Y118.661 E.00466
G1 F2452.951
G1 X130.668 Y118.61 E.00182
G1 F9513.023
M73 P31 R19
G1 X130.43 Y118.164 E.01679
G1 F15476.087
G1 X130.173 Y117.831 E.01395
G2 X126.027 Y117.627 I-2.173 J1.929 E.15335
G1 X125.738 Y117.932 E.01394
G1 F15403.971
G1 X125.499 Y118.278 E.01395
G1 F7092.497
G1 X125.332 Y118.61 E.01232
G1 F2398.381
G1 X125.312 Y118.655 E.00162
G1 F1964.887
G1 X125.262 Y118.787 E.00467
G1 F960
G1 X125.205 Y118.962 E.00612
G1 F600
G1 X112.794 Y118.962 E.41169
G1 F960
G1 X112.74 Y118.792 E.00593
G1 F1960.767
G1 X112.69 Y118.661 E.00465
G1 F2451.891
G1 X112.668 Y118.61 E.00183
G1 F9510.598
G1 X112.43 Y118.164 E.01679
G1 F15476.087
G1 X112.174 Y117.829 E.01396
G2 X108.025 Y117.625 I-2.174 J1.922 E.1536
G1 X107.738 Y117.932 E.01395
G1 F15403.971
G1 X107.499 Y118.278 E.01395
G1 F7092.497
G1 X107.332 Y118.61 E.01232
G1 F2398.381
G1 X107.312 Y118.655 E.00162
G1 F1964.887
G1 X107.262 Y118.787 E.00467
G1 F960
G1 X107.205 Y118.962 E.00612
G1 F600
G1 X94.794 Y118.962 E.41169
G1 F960
G1 X94.74 Y118.792 E.00593
G1 F1961.563
G1 X94.69 Y118.661 E.00465
G1 F2452.066
G1 X94.668 Y118.61 E.00183
G1 F9507.961
G1 X94.43 Y118.164 E.01678
G1 F15476.087
G1 X94.174 Y117.829 E.01397
G2 X90.025 Y117.625 I-2.174 J1.922 E.1536
G1 X89.738 Y117.932 E.01395
M73 P32 R19
G1 F15398.596
G1 X89.499 Y118.278 E.01394
G1 F7091.771
G1 X89.332 Y118.61 E.01233
G1 F2396.464
G1 X89.312 Y118.655 E.00164
G1 F1960.293
G1 X89.262 Y118.786 E.00465
G1 F960
G1 X89.205 Y118.962 E.00613
G1 F600
G1 X73.602 Y118.962 E.51759
G1 F2040
G1 X73.602 Y118.61 E.01167
G1 F6907.886
G1 X73.602 Y118.21 E.01327
G1 F14655.771
G1 X73.602 Y117.81 E.01327
G1 F15476.087
G1 X73.602 Y117.41 E.01327
G1 X73.602 Y114.852 E.08486
G1 X182.338 Y114.852 E3.60697
M204 S250
G1 X182.79 Y114.46 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y117.824 E.10336
G1 X182.79 Y118.224 E.01229
G1 F6459.938
G1 X182.79 Y118.624 E.01229
G1 F1800
G1 X182.79 Y118.993 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y119.354 E.01199
G1 F600
G1 X166.478 Y119.354 E.5411
G2 X166.392 Y118.993 I-3.69 J.683 E.01233
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X166.369 Y118.921 E.0023
G1 F1080
G1 X166.327 Y118.808 E.00373
G1 F1969.841
G1 X166.278 Y118.697 E.00373
G1 F2713.259
G1 X166.242 Y118.624 E.0025
G1 F6231.616
G1 X166.102 Y118.378 E.0087
G1 F12000
G1 X165.879 Y118.09 E.01118
G2 X162.124 Y118.087 I-1.879 J1.67 E.1303
G1 X161.901 Y118.374 E.01117
G1 F6508.482
G1 X161.758 Y118.624 E.00884
G1 F2849.639
G1 X161.724 Y118.692 E.00233
G1 F2132.05
G1 X161.675 Y118.803 E.00374
G1 F1200
G1 X161.632 Y118.917 E.00373
G1 F600
G1 X161.608 Y118.993 E.00246
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X161.522 Y119.354 I3.659 J1.058 E.01233
G1 X148.478 Y119.354 E.43269
G2 X148.392 Y118.993 I-3.695 J.684 E.01233
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X148.369 Y118.921 E.0023
G1 F1080
G1 X148.327 Y118.808 E.00373
G1 F1969.764
G1 X148.278 Y118.697 E.00373
G1 F2713.168
G1 X148.242 Y118.624 E.0025
G1 F6231.683
G1 X148.102 Y118.378 E.0087
G1 F12000
G1 X147.879 Y118.09 E.01118
G2 X144.124 Y118.087 I-1.879 J1.67 E.1303
G1 X143.901 Y118.374 E.01117
G1 F6506.635
G1 X143.758 Y118.624 E.00884
G1 F2848.455
G1 X143.724 Y118.692 E.00234
G1 F2130.555
G1 X143.675 Y118.803 E.00373
G1 F1200
G1 X143.632 Y118.917 E.00373
G1 F600
G1 X143.608 Y118.993 E.00246
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X143.522 Y119.354 I3.659 J1.058 E.01233
G1 X130.478 Y119.354 E.43269
G2 X130.392 Y118.993 I-3.695 J.684 E.01233
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X130.369 Y118.921 E.0023
G1 F1080
G1 X130.327 Y118.808 E.00373
G1 F1969.764
G1 X130.278 Y118.697 E.00373
G1 F2713.168
G1 X130.242 Y118.624 E.0025
G1 F6231.683
G1 X130.102 Y118.378 E.0087
G1 F12000
G1 X129.879 Y118.09 E.01118
G2 X126.124 Y118.087 I-1.879 J1.67 E.13029
G1 X125.901 Y118.374 E.01118
G1 F6507.19
G1 X125.758 Y118.624 E.00884
G1 F2848.545
G1 X125.724 Y118.692 E.00234
G1 F2130.555
G1 X125.675 Y118.803 E.00373
G1 F1200
G1 X125.632 Y118.917 E.00373
G1 F600
G1 X125.608 Y118.993 E.00245
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X125.522 Y119.354 I3.665 J1.059 E.01233
G1 X112.478 Y119.354 E.43269
G2 X112.392 Y118.993 I-3.691 J.684 E.01233
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X112.369 Y118.921 E.0023
G1 F1080
G1 X112.327 Y118.808 E.00373
G1 F1969.642
G1 X112.278 Y118.697 E.00373
G1 F2713.114
G1 X112.242 Y118.624 E.0025
G1 F6231.397
G1 X112.102 Y118.378 E.0087
G1 F12000
G1 X111.879 Y118.09 E.01118
G2 X108.124 Y118.087 I-1.879 J1.67 E.13029
G1 X107.901 Y118.374 E.01118
G1 F6507.19
G1 X107.758 Y118.624 E.00884
G1 F2848.545
G1 X107.724 Y118.692 E.00234
G1 F2130.555
G1 X107.675 Y118.803 E.00373
G1 F1200
G1 X107.632 Y118.917 E.00373
G1 F600
G1 X107.608 Y118.993 E.00245
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X107.522 Y119.354 I3.665 J1.059 E.01233
G1 X94.478 Y119.354 E.43269
G2 X94.392 Y118.993 I-3.693 J.684 E.01233
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X94.369 Y118.921 E.0023
G1 F1080
G1 X94.327 Y118.808 E.00373
G1 F1969.642
G1 X94.278 Y118.697 E.00373
G1 F2713.114
G1 X94.242 Y118.624 E.0025
G1 F6231.602
G1 X94.102 Y118.378 E.0087
G1 F12000
G1 X93.879 Y118.09 E.01118
G2 X90.124 Y118.087 I-1.879 J1.67 E.13029
G1 X89.901 Y118.374 E.01118
G1 F6508.824
G1 X89.758 Y118.624 E.00884
G1 F2849.639
G1 X89.724 Y118.692 E.00233
G1 F2132.05
G1 X89.675 Y118.803 E.00374
G1 F1200
G1 X89.632 Y118.917 E.00373
G1 F600
G1 X89.608 Y118.993 E.00246
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X89.522 Y119.354 I3.663 J1.059 E.01233
G1 X73.21 Y119.354 E.5411
G1 X73.21 Y118.993 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y118.624 E.01134
G1 F6459.938
G1 X73.21 Y118.224 E.01229
G1 F12000
G1 X73.21 Y117.824 E.01229
G1 X73.21 Y114.46 E.10336
G1 X182.73 Y114.46 E3.36524
; WIPE_START
M204 S10000
G1 X182.766 Y116.46 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.234 Y117.686 Z1.6 F30000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.489 Y117.686 E.58054
G3 X166.797 Y118.139 I-2.389 J1.958 E.02021
G1 X182.065 Y118.139 E.56293
G1 X182.065 Y118.591 E.01668
G1 X166.831 Y118.591 E.5617
G1 X166.265 Y117.351 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.426915
G1 F15000
G1 X166.538 Y117.311 E.00865
; LINE_WIDTH: 0.383182
G3 X166.838 Y117.27 I.385 J1.691 E.00842
G1 X182.017 Y117.269 E.42085
; WIPE_START
G1 X180.017 Y117.269 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X172.386 Y117.443 Z1.6 F30000
G1 X161.737 Y117.686 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X148.489 Y117.686 E.48847
G3 X148.797 Y118.139 I-2.389 J1.957 E.02021
G1 X161.203 Y118.139 E.45741
G2 X161.009 Y118.536 I1.219 J.841 E.01634
G1 X160.988 Y118.591 E.00219
G1 X148.831 Y118.591 E.44827
G1 X148.265 Y117.351 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.426915
G1 F15000
G1 X148.538 Y117.311 E.00865
; LINE_WIDTH: 0.383242
G3 X148.838 Y117.27 I.385 J1.691 E.00842
G1 X161.133 Y117.269 E.34095
; LINE_WIDTH: 0.399075
G1 X161.394 Y117.307 E.00766
; LINE_WIDTH: 0.431385
G1 X161.655 Y117.345 E.00835
; WIPE_START
G1 X161.394 Y117.307 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X153.763 Y117.471 Z1.6 F30000
G1 X143.737 Y117.686 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X130.489 Y117.686 E.48847
G3 X130.797 Y118.139 I-2.389 J1.957 E.02021
G1 X143.203 Y118.139 E.45741
G2 X143.009 Y118.536 I1.219 J.841 E.01635
G1 X142.988 Y118.591 E.00219
G1 X130.831 Y118.591 E.44827
G1 X130.265 Y117.351 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.426915
G1 F15000
G1 X130.538 Y117.311 E.00865
; LINE_WIDTH: 0.383242
G3 X130.838 Y117.27 I.385 J1.691 E.00842
G1 X143.133 Y117.269 E.34095
; LINE_WIDTH: 0.39908
G1 X143.394 Y117.307 E.00766
; LINE_WIDTH: 0.4314
G1 X143.655 Y117.345 E.00835
; WIPE_START
G1 X143.394 Y117.307 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X135.763 Y117.471 Z1.6 F30000
G1 X125.737 Y117.686 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X112.486 Y117.687 E.4886
G3 X112.797 Y118.139 I-1.389 J1.29 E.02031
G1 X125.203 Y118.139 E.45741
G2 X124.988 Y118.591 I1.393 J.937 E.01853
G1 X112.831 Y118.591 E.44827
G1 X112.279 Y117.359 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.439005
G1 F15000
G1 X112.545 Y117.315 E.00871
; LINE_WIDTH: 0.383321
G3 X112.838 Y117.27 I.359 J1.354 E.00824
G1 X125.133 Y117.269 E.34103
; LINE_WIDTH: 0.399095
G1 X125.394 Y117.307 E.00766
; LINE_WIDTH: 0.431445
G1 X125.655 Y117.345 E.00835
; WIPE_START
G1 X125.394 Y117.307 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X117.763 Y117.471 Z1.6 F30000
G1 X107.737 Y117.686 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X94.486 Y117.687 E.48859
G3 X94.797 Y118.139 I-1.389 J1.291 E.02031
G1 X107.203 Y118.139 E.45741
G2 X106.988 Y118.591 I1.393 J.937 E.01853
G1 X94.831 Y118.591 E.44827
G1 X94.279 Y117.359 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43899
G1 F15000
G1 X94.545 Y117.315 E.00871
; LINE_WIDTH: 0.383321
G3 X94.838 Y117.27 I.359 J1.354 E.00824
G1 X107.133 Y117.269 E.34103
; LINE_WIDTH: 0.399085
G1 X107.394 Y117.307 E.00766
; LINE_WIDTH: 0.431415
G1 X107.655 Y117.345 E.00835
; WIPE_START
G1 X107.394 Y117.307 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X99.763 Y117.471 Z1.6 F30000
G1 X89.737 Y117.686 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
M73 P33 R19
G1 X73.935 Y117.686 E.58264
G1 X73.935 Y118.139 E.01668
G1 X89.203 Y118.139 E.56293
G2 X89.009 Y118.536 I1.219 J.84 E.01635
G1 X88.988 Y118.591 E.00218
G1 X73.766 Y118.591 E.56128
G1 X73.923 Y117.269 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X89.133 Y117.269 E.4214
; LINE_WIDTH: 0.399075
G1 X89.394 Y117.307 E.00766
; LINE_WIDTH: 0.431385
G1 X89.655 Y117.345 E.00835
G1 X74.016 Y116.948 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X75.644 Y116.948 E.05401
G1 X77.392 Y115.2 E.082
G1 X78.821 Y115.2 E.04739
G1 X80.568 Y116.948 E.082
G1 X83.32 Y116.948 E.09127
G1 X85.068 Y115.2 E.082
G1 X86.497 Y115.2 E.04739
G1 X88.244 Y116.948 E.082
G1 X90.205 Y116.948 E.06503
G1 X90.236 Y117.029 E.00287
G3 X91.382 Y116.563 I1.999 J3.269 E.04123
G1 X92.744 Y115.2 E.06391
G1 X94.172 Y115.2 E.04739
G1 X95.92 Y116.948 E.082
G1 X98.672 Y116.948 E.09127
G1 X100.42 Y115.2 E.082
G1 X101.848 Y115.2 E.04739
G1 X103.596 Y116.948 E.082
G1 X106.348 Y116.948 E.09127
G1 X108.096 Y115.2 E.082
G1 X109.524 Y115.2 E.04739
G1 X110.974 Y116.65 E.06803
G3 X111.768 Y117.032 I-1.891 J4.955 E.02924
G1 X111.799 Y116.948 E.00294
G1 X114.024 Y116.948 E.07382
G1 X115.772 Y115.2 E.082
G1 X117.2 Y115.2 E.04739
G1 X118.948 Y116.948 E.082
G1 X121.7 Y116.948 E.09127
G1 X123.448 Y115.2 E.082
G1 X124.876 Y115.2 E.04739
G1 X126.529 Y116.853 E.07752
G3 X129.47 Y116.854 I1.469 J2.9 E.10123
G1 X131.124 Y115.2 E.07759
G1 X132.552 Y115.2 E.04739
G1 X134.3 Y116.948 E.082
G1 X137.052 Y116.948 E.09127
G1 X138.8 Y115.2 E.082
G1 X140.228 Y115.2 E.04739
G1 X141.976 Y116.948 E.082
G1 X144.205 Y116.948 E.07393
G1 X144.234 Y117.024 E.00268
G3 X145.026 Y116.65 I5.445 J10.517 E.02907
G1 X146.476 Y115.2 E.06801
G1 X147.904 Y115.2 E.04739
G1 X149.652 Y116.948 E.082
G1 X152.404 Y116.948 E.09127
G1 X154.152 Y115.2 E.082
G1 X155.58 Y115.2 E.04739
G1 X157.328 Y116.948 E.082
G1 X160.08 Y116.948 E.09127
G1 X161.828 Y115.2 E.082
G1 X163.256 Y115.2 E.04739
G1 X164.618 Y116.562 E.06389
G3 X165.765 Y117.029 I-.856 J3.744 E.04125
G1 X165.795 Y116.948 E.00288
G1 X167.756 Y116.948 E.06502
G1 X169.504 Y115.2 E.082
G1 X170.932 Y115.2 E.04739
G1 X172.68 Y116.948 E.082
G1 X175.432 Y116.948 E.09127
G1 X177.179 Y115.2 E.082
G1 X178.608 Y115.2 E.04739
G1 X180.356 Y116.948 E.082
G1 X181.984 Y116.948 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X180.356 Y116.948 E-.61876
G1 X180.093 Y116.685 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/33
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.6 I.758 J.952 P1  F30000
G1 X182.398 Y114.852 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X182.398 Y118.182 E.11045
G1 X182.398 Y118.582 E.01327
G1 F14655.771
G1 X182.398 Y118.982 E.01327
G1 F6907.886
G1 X182.398 Y119.382 E.01327
G1 F2040
G1 X182.398 Y119.733 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.908 Y119.733 E.51384
G1 F1440
G1 X166.889 Y119.476 E.00856
G1 F2205.211
G1 X166.878 Y119.382 E.00315
G1 F8315.659
G1 X166.783 Y118.925 E.01547
G1 F14030.602
G1 X166.688 Y118.654 E.00953
G1 F15476.087
G1 X166.582 Y118.432 E.00817
G2 X161.382 Y118.504 I-2.582 J1.326 E.2138
G1 X161.219 Y118.92 E.01483
G1 F8311.501
G1 X161.122 Y119.382 E.01564
G1 F2155.25
G1 X161.111 Y119.47 E.00296
G1 F1440
G1 X161.092 Y119.733 E.00875
G1 F600
G1 X148.908 Y119.733 E.40419
G1 F1440
G1 X148.889 Y119.476 E.00856
G1 F2205.134
G1 X148.878 Y119.382 E.00315
G1 F8315.641
G1 X148.783 Y118.925 E.01547
G1 F14030.579
G1 X148.688 Y118.654 E.00953
G1 F15476.087
G1 X148.582 Y118.432 E.00816
G2 X143.382 Y118.504 I-2.582 J1.326 E.2138
G1 X143.219 Y118.92 E.01483
G1 F8311.501
G1 X143.122 Y119.382 E.01564
G1 F2155.25
G1 X143.111 Y119.47 E.00296
G1 F1440
G1 X143.092 Y119.733 E.00875
G1 F600
G1 X130.908 Y119.733 E.40419
G1 F1440
G1 X130.889 Y119.476 E.00856
G1 F2205.134
G1 X130.878 Y119.382 E.00315
G1 F8315.641
G1 X130.783 Y118.925 E.01547
G1 F14030.505
G1 X130.688 Y118.654 E.00953
G1 F15476.087
G1 X130.582 Y118.432 E.00816
G2 X125.382 Y118.504 I-2.582 J1.326 E.2138
G1 X125.219 Y118.92 E.01483
G1 F8309.758
G1 X125.122 Y119.382 E.01564
G1 F2155.26
G1 X125.111 Y119.47 E.00296
G1 F1440
G1 X125.092 Y119.733 E.00875
G1 F600
G1 X112.908 Y119.733 E.40419
G1 F1440
G1 X112.889 Y119.476 E.00856
G1 F2205.378
G1 X112.878 Y119.382 E.00315
G1 F8317.309
G1 X112.783 Y118.925 E.01547
G1 F14031.112
G1 X112.688 Y118.654 E.00953
G1 F15476.087
G1 X112.582 Y118.432 E.00816
G2 X107.382 Y118.504 I-2.582 J1.326 E.2138
G1 X107.219 Y118.92 E.01485
G1 F8305.073
G1 X107.122 Y119.382 E.01563
G1 F2155.26
G1 X107.111 Y119.47 E.00296
G1 F1440
G1 X107.092 Y119.733 E.00875
G1 F600
G1 X94.908 Y119.733 E.40419
G1 F1440
G1 X94.889 Y119.476 E.00856
G1 F2205.123
G1 X94.878 Y119.382 E.00315
G1 F8315.656
G1 X94.783 Y118.925 E.01547
G1 F14030.312
G1 X94.688 Y118.654 E.00953
G1 F15476.087
G1 X94.582 Y118.432 E.00816
G2 X89.382 Y118.504 I-2.582 J1.326 E.2138
G1 X89.219 Y118.92 E.01484
G1 F8310.096
G1 X89.122 Y119.382 E.01564
G1 F2155.26
G1 X89.111 Y119.47 E.00296
G1 F1440
G1 X89.092 Y119.733 E.00875
G1 F600
G1 X73.602 Y119.733 E.51384
G1 F2040
G1 X73.602 Y119.382 E.01167
G1 F6907.886
G1 X73.602 Y118.982 E.01327
G1 F14655.771
G1 X73.602 Y118.582 E.01327
G1 F15476.087
G1 X73.602 Y118.182 E.01327
G1 X73.602 Y114.852 E.11045
G1 X182.338 Y114.852 E3.60697
M204 S250
G1 X182.79 Y114.46 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y118.595 E.12706
G1 X182.79 Y118.995 E.01229
G1 F6459.938
G1 X182.79 Y119.395 E.01229
G1 F1800
G1 X182.79 Y119.764 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y120.126 E.01199
G1 F600
G1 X166.509 Y120.126 E.54006
G1 X166.508 Y119.764 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X166.507 Y119.633 E.00401
G1 F1292.31
G1 X166.499 Y119.513 E.00371
G1 F2229.428
G1 X166.485 Y119.395 E.00365
G1 F2253.674
G1 X166.484 Y119.392 E.00008
G1 F6727.262
G1 X166.407 Y119.037 E.01119
G1 F12000
G1 X166.234 Y118.606 E.01425
G2 X161.733 Y118.674 I-2.234 J1.145 E.17155
G1 X161.595 Y119.032 E.01181
G1 F6758.312
G1 X161.515 Y119.395 E.01141
G1 F2206.996
G1 X161.502 Y119.508 E.0035
G1 F1308.588
G1 X161.493 Y119.631 E.00378
G1 F600
G1 X161.492 Y119.764 E.00409
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X161.491 Y120.126 E.01199
G1 X148.509 Y120.126 E.43062
G1 X148.508 Y119.764 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X148.507 Y119.633 E.00401
G1 F1292.31
G1 X148.499 Y119.513 E.00371
G1 F2229.35
G1 X148.485 Y119.395 E.00365
G1 F2253.674
G1 X148.484 Y119.392 E.00008
G1 F6727.263
G1 X148.407 Y119.037 E.01119
G1 F12000
G1 X148.234 Y118.606 E.01424
G2 X143.733 Y118.674 I-2.234 J1.145 E.17155
G1 X143.595 Y119.032 E.01181
G1 F6758.312
G1 X143.515 Y119.395 E.01141
G1 F2206.996
G1 X143.502 Y119.508 E.0035
G1 F1308.588
G1 X143.493 Y119.631 E.00378
G1 F600
G1 X143.492 Y119.764 E.00409
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X143.491 Y120.126 E.01199
G1 X130.509 Y120.126 E.43062
G1 X130.508 Y119.764 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X130.507 Y119.633 E.00401
G1 F1292.31
G1 X130.499 Y119.513 E.00371
G1 F2229.35
G1 X130.485 Y119.395 E.00365
G1 F2253.674
G1 X130.484 Y119.392 E.00008
G1 F6727.263
G1 X130.407 Y119.037 E.01119
G1 F12000
G1 X130.234 Y118.606 E.01425
G2 X125.733 Y118.674 I-2.234 J1.145 E.17155
G1 X125.595 Y119.032 E.01181
G1 F6758.026
G1 X125.515 Y119.395 E.01141
G1 F2207.007
G1 X125.502 Y119.508 E.0035
G1 F1308.588
G1 X125.493 Y119.631 E.00378
G1 F600
G1 X125.492 Y119.764 E.00409
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X125.491 Y120.126 E.01199
G1 X112.509 Y120.126 E.43062
G1 X112.508 Y119.764 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X112.507 Y119.633 E.00401
G1 F1292.31
G1 X112.499 Y119.513 E.00371
G1 F2229.329
G1 X112.485 Y119.395 E.00365
G1 F2253.574
G1 X112.484 Y119.392 E.00008
G1 F6727.275
G1 X112.407 Y119.037 E.01119
G1 F12000
G1 X112.234 Y118.606 E.01424
G2 X107.733 Y118.674 I-2.234 J1.145 E.17155
G1 X107.595 Y119.032 E.01181
M73 P34 R19
G1 F6757.012
G1 X107.515 Y119.395 E.01141
G1 F2207.007
G1 X107.502 Y119.508 E.0035
G1 F1308.588
G1 X107.493 Y119.631 E.00378
G1 F600
G1 X107.492 Y119.764 E.00409
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X107.491 Y120.126 E.01199
G1 X94.509 Y120.126 E.43062
G1 X94.508 Y119.764 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X94.507 Y119.633 E.00401
G1 F1292.31
G1 X94.499 Y119.513 E.00371
G1 F2229.339
G1 X94.485 Y119.395 E.00365
G1 F2253.674
G1 X94.484 Y119.392 E.00008
G1 F6727.262
G1 X94.407 Y119.037 E.01119
G1 F12000
G1 X94.234 Y118.606 E.01424
G2 X89.733 Y118.674 I-2.234 J1.145 E.17155
G1 X89.595 Y119.032 E.01181
G1 F6757.84
G1 X89.515 Y119.395 E.01141
G1 F2207.007
G1 X89.502 Y119.508 E.0035
G1 F1308.588
G1 X89.493 Y119.631 E.00378
G1 F600
G1 X89.492 Y119.764 E.00409
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X89.491 Y120.126 E.01199
G1 X73.21 Y120.126 E.54006
G1 X73.21 Y119.764 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y119.395 E.01134
G1 F6459.938
G1 X73.21 Y118.995 E.01229
G1 F12000
G1 X73.21 Y118.595 E.01229
G1 X73.21 Y114.46 E.12706
G1 X182.73 Y114.46 E3.36524
; WIPE_START
M204 S10000
G1 X182.759 Y116.46 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.05 Y117.014 Z1.8 F30000
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.05 Y117.72 E.02342
G1 X181.127 Y117.72 E.0306
G1 X178.608 Y115.2 E.11819
G1 X177.179 Y115.2 E.04739
G1 X174.66 Y117.72 E.11819
G1 X173.451 Y117.72 E.0401
G1 X170.932 Y115.2 E.11819
G1 X169.504 Y115.2 E.04739
G1 X166.984 Y117.72 E.11819
G1 X166.537 Y117.718 E.01482
G2 X164.617 Y116.561 I-2.551 J2.064 E.07589
G1 X163.256 Y115.2 E.06385
G1 X161.828 Y115.2 E.04739
G1 X159.308 Y117.72 E.11819
G1 X158.099 Y117.72 E.0401
G1 X155.58 Y115.2 E.11819
G1 X154.152 Y115.2 E.04739
G1 X151.632 Y117.72 E.11819
G1 X150.424 Y117.72 E.0401
G1 X147.904 Y115.2 E.11819
G1 X146.476 Y115.2 E.04739
G1 X145.007 Y116.669 E.0689
G2 X143.461 Y117.72 I.932 J3.033 E.06293
G1 X142.748 Y117.72 E.02368
G1 X140.228 Y115.2 E.11819
G1 X138.8 Y115.2 E.04739
G1 X136.28 Y117.72 E.11819
G1 X135.072 Y117.72 E.0401
G1 X132.552 Y115.2 E.11819
G1 X131.124 Y115.2 E.04739
G1 X129.47 Y116.854 E.0776
G2 X126.53 Y116.854 I-1.47 J2.925 E.10112
G1 X124.876 Y115.2 E.07759
G1 X123.448 Y115.2 E.04739
G1 X120.928 Y117.72 E.11819
G1 X119.72 Y117.72 E.0401
G1 X117.2 Y115.2 E.11819
G1 X115.772 Y115.2 E.04739
G1 X113.252 Y117.72 E.11819
G1 X112.537 Y117.718 E.02372
G2 X110.977 Y116.653 I-2.748 J2.352 E.06339
G1 X109.524 Y115.2 E.06816
G1 X108.096 Y115.2 E.04739
G1 X105.576 Y117.72 E.11819
G1 X104.368 Y117.72 E.0401
G1 X101.848 Y115.2 E.11819
G1 X100.42 Y115.2 E.04739
G1 X97.901 Y117.72 E.11819
G1 X96.692 Y117.72 E.04009
G1 X94.172 Y115.2 E.11819
G1 X92.744 Y115.2 E.04739
G1 X91.383 Y116.561 E.06384
G2 X89.461 Y117.72 I.724 J3.374 E.07581
G1 X89.016 Y117.72 E.01478
G1 X86.497 Y115.2 E.11819
G1 X85.068 Y115.2 E.04739
G1 X82.549 Y117.72 E.11819
G1 X81.34 Y117.72 E.04009
G1 X78.821 Y115.2 E.11819
G1 X77.392 Y115.2 E.04739
G1 X74.873 Y117.72 E.11819
G1 X73.95 Y117.72 E.0306
G1 X73.95 Y117.014 E.02342
G1 X73.923 Y118.041 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.971 Y118.041 E.41691
G1 X89.174 Y118.061 E.00565
G1 X89.231 Y118.457 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y118.457 E.56398
G1 X73.935 Y118.91 E.01668
G1 X88.878 Y118.91 E.55097
G2 X88.798 Y119.362 I1.667 J.53 E.01699
G1 X73.766 Y119.362 E.55426
; WIPE_START
G1 X75.766 Y119.362 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.083 J1.214 P1  F30000
G1 X94.771 Y118.066 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X95 Y118.042 E.00641
G1 X106.971 Y118.041 E.33165
G1 X107.174 Y118.061 E.00565
G1 X107.231 Y118.457 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X94.964 Y118.457 E.45231
G3 X95.122 Y118.91 I-3.446 J1.457 E.01768
G1 X106.878 Y118.91 E.43347
G2 X106.798 Y119.362 I1.667 J.53 E.01699
G1 X95.032 Y119.362 E.43383
; WIPE_START
G1 X97.032 Y119.362 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.1 J1.213 P1  F30000
G1 X112.771 Y118.066 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X113.001 Y118.042 E.00641
G1 X124.971 Y118.041 E.33165
G1 X125.174 Y118.061 E.00565
G1 X125.231 Y118.457 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X112.964 Y118.457 E.45231
G3 X113.122 Y118.91 I-3.452 J1.459 E.01768
G1 X124.878 Y118.91 E.43347
G2 X124.798 Y119.362 I1.667 J.53 E.01699
G1 X113.032 Y119.362 E.43383
; WIPE_START
G1 X115.032 Y119.362 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.1 J1.213 P1  F30000
G1 X130.771 Y118.066 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X131 Y118.042 E.00641
G1 X142.971 Y118.041 E.33165
G1 X143.174 Y118.061 E.00565
G1 X143.231 Y118.457 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X130.964 Y118.457 E.45231
G3 X131.122 Y118.91 I-3.446 J1.456 E.01768
G1 X142.878 Y118.91 E.43347
G2 X142.798 Y119.362 I1.668 J.53 E.01699
G1 X131.032 Y119.362 E.43383
; WIPE_START
G1 X133.032 Y119.362 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.1 J1.213 P1  F30000
G1 X148.771 Y118.066 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X149 Y118.042 E.00641
G1 X160.971 Y118.041 E.33165
G1 X161.174 Y118.061 E.00565
G1 X161.231 Y118.457 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X148.964 Y118.457 E.45231
G3 X149.122 Y118.91 I-3.45 J1.458 E.01768
G1 X160.878 Y118.91 E.43347
G2 X160.798 Y119.362 I1.668 J.53 E.01699
G1 X149.032 Y119.362 E.43383
; WIPE_START
G1 X151.032 Y119.362 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z1.8 I.1 J1.213 P1  F30000
G1 X166.771 Y118.066 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X167 Y118.042 E.00641
G1 X182.017 Y118.041 E.41604
G1 X182.234 Y118.457 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X166.964 Y118.458 E.56304
G3 X167.122 Y118.91 I-3.45 J1.458 E.01768
G1 X182.065 Y118.91 E.55096
G1 X182.065 Y119.362 E.01668
G1 X167.032 Y119.362 E.55429
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X169.032 Y119.362 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/33
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z1.8 I.389 J1.153 P1  F30000
G1 X182.398 Y114.852 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y118.953 E.13604
G1 X182.398 Y119.353 E.01327
G1 F14655.771
G1 X182.398 Y119.753 E.01327
G1 F6907.886
G1 X182.398 Y120.153 E.01327
G1 F2040
G1 X182.398 Y120.505 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.902 Y120.505 E.51403
G1 F2040
G1 X166.902 Y120.153 E.01167
G1 F6907.886
G1 X166.896 Y119.753 E.01327
G1 F11434.178
G1 X166.891 Y119.502 E.00833
G1 F15476.087
G1 X166.809 Y119.063 E.01481
G2 X166.347 Y118.042 I-3.161 J.817 E.03736
G2 X161.22 Y118.919 I-2.346 J1.711 E.21379
G1 X161.127 Y119.338 E.01426
G1 F15024.288
G1 X161.098 Y119.741 E.0134
G1 F7099.857
G1 X161.098 Y120.153 E.01367
G1 F2040
G1 X161.098 Y120.505 E.01167
G1 F600
G1 X148.902 Y120.505 E.40456
G1 F2040
G1 X148.902 Y120.153 E.01167
G1 F6907.886
G1 X148.896 Y119.753 E.01327
G1 F11434.381
G1 X148.891 Y119.502 E.00833
G1 F15476.087
G1 X148.809 Y119.063 E.01481
G2 X148.347 Y118.042 I-3.161 J.817 E.03736
G2 X143.22 Y118.919 I-2.346 J1.711 E.21379
G1 X143.127 Y119.338 E.01426
G1 F15024.288
G1 X143.098 Y119.741 E.0134
G1 F7099.857
G1 X143.098 Y120.153 E.01367
G1 F2040
G1 X143.098 Y120.505 E.01167
G1 F600
G1 X130.902 Y120.505 E.40456
G1 F2040
G1 X130.902 Y120.153 E.01167
G1 F6907.886
G1 X130.896 Y119.753 E.01327
G1 F11434.381
G1 X130.891 Y119.502 E.00833
G1 F15476.087
G1 X130.809 Y119.063 E.01481
G2 X130.347 Y118.042 I-3.161 J.817 E.03736
G2 X125.222 Y118.919 I-2.343 J1.718 E.21354
G1 X125.127 Y119.338 E.01425
G1 F15024.074
G1 X125.098 Y119.741 E.0134
G1 F7100.017
G1 X125.098 Y120.153 E.01367
G1 F2040
G1 X125.098 Y120.505 E.01167
G1 F600
G1 X112.902 Y120.505 E.40456
G1 F2040
G1 X112.902 Y120.153 E.01167
G1 F6907.886
G1 X112.896 Y119.753 E.01327
G1 F11433.367
G1 X112.891 Y119.502 E.00833
G1 F15476.087
G1 X112.809 Y119.063 E.01482
G2 X112.347 Y118.042 I-3.161 J.817 E.03736
G2 X107.222 Y118.919 I-2.343 J1.718 E.21354
G1 X107.127 Y119.338 E.01425
G1 F15024.074
G1 X107.098 Y119.741 E.0134
G1 F7100.017
G1 X107.098 Y120.153 E.01367
M73 P35 R19
G1 F2040
G1 X107.098 Y120.505 E.01167
G1 F600
G1 X94.902 Y120.505 E.40456
G1 F2040
G1 X94.902 Y120.153 E.01167
G1 F6907.886
G1 X94.896 Y119.753 E.01327
G1 F11434.175
G1 X94.891 Y119.502 E.00833
G1 F15476.087
G1 X94.809 Y119.063 E.01481
G2 X94.347 Y118.042 I-3.161 J.817 E.03736
G2 X89.222 Y118.919 I-2.343 J1.718 E.21354
G1 X89.127 Y119.338 E.01425
G1 F15024.074
G1 X89.098 Y119.741 E.0134
G1 F7100.017
G1 X89.098 Y120.153 E.01367
G1 F2040
G1 X89.098 Y120.505 E.01167
G1 F600
G1 X73.602 Y120.505 E.51403
G1 F2040
G1 X73.602 Y120.153 E.01167
G1 F6907.886
G1 X73.602 Y119.753 E.01327
G1 F14655.771
G1 X73.602 Y119.353 E.01327
G1 F15476.087
G1 X73.602 Y118.953 E.01327
G1 X73.602 Y114.852 E.13604
G1 X182.338 Y114.852 E3.60697
M204 S250
G1 X182.79 Y114.46 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y119.367 E.15076
G1 X182.79 Y119.767 E.01229
G1 F6459.938
G1 X182.79 Y120.167 E.01229
G1 F1800
G1 X182.79 Y120.536 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y120.897 E.01199
G1 F600
M73 P35 R18
G1 X166.51 Y120.897 E.54004
G1 X166.51 Y120.536 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y120.167 E.01134
G1 F6785.404
G1 X166.51 Y119.745 E.01294
G1 F12000
G1 X166.481 Y119.393 E.01086
G2 X166.278 Y118.696 I-3.034 J.503 E.02235
G2 X161.537 Y119.268 I-2.278 J1.056 E.19392
G1 X161.49 Y119.747 E.01478
G1 F6761.2
G1 X161.49 Y120.167 E.01289
G1 F1800
G1 X161.49 Y120.536 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y120.897 E.01199
G1 X148.51 Y120.897 E.43057
G1 X148.51 Y120.536 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y120.167 E.01134
G1 F6785.404
G1 X148.51 Y119.745 E.01294
G1 F12000
G1 X148.481 Y119.393 E.01086
G2 X148.278 Y118.696 I-3.034 J.503 E.02235
G2 X143.537 Y119.268 I-2.278 J1.056 E.19392
G1 X143.49 Y119.747 E.01478
G1 F6761.2
G1 X143.49 Y120.167 E.01289
G1 F1800
G1 X143.49 Y120.536 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y120.897 E.01199
G1 X130.51 Y120.897 E.43057
G1 X130.51 Y120.536 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y120.167 E.01134
G1 F6785.404
G1 X130.51 Y119.745 E.01294
G1 F12000
G1 X130.481 Y119.393 E.01086
G2 X130.278 Y118.696 I-3.034 J.503 E.02235
G2 X125.537 Y119.268 I-2.278 J1.056 E.19392
G1 X125.49 Y119.747 E.01478
G1 F6761.2
G1 X125.49 Y120.167 E.01289
G1 F1800
G1 X125.49 Y120.536 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y120.897 E.01199
G1 X112.51 Y120.897 E.43057
G1 X112.51 Y120.536 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y120.167 E.01134
G1 F6785.56
G1 X112.51 Y119.745 E.01294
G1 F12000
G1 X112.481 Y119.393 E.01086
G2 X112.278 Y118.696 I-3.034 J.503 E.02235
G2 X107.537 Y119.268 I-2.278 J1.056 E.19392
G1 X107.49 Y119.747 E.01478
G1 F6761.2
G1 X107.49 Y120.167 E.01289
G1 F1800
G1 X107.49 Y120.536 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y120.897 E.01199
G1 X94.51 Y120.897 E.43057
G1 X94.51 Y120.536 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y120.167 E.01134
G1 F6785.404
G1 X94.51 Y119.745 E.01294
G1 F12000
G1 X94.481 Y119.393 E.01086
G2 X94.278 Y118.696 I-3.034 J.503 E.02235
G2 X89.537 Y119.268 I-2.278 J1.056 E.19392
G1 X89.49 Y119.747 E.01478
G1 F6761.2
G1 X89.49 Y120.167 E.01289
G1 F1800
G1 X89.49 Y120.536 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y120.897 E.01199
G1 X73.21 Y120.897 E.54004
G1 X73.21 Y120.536 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y120.167 E.01134
G1 F6459.938
G1 X73.21 Y119.767 E.01229
G1 F12000
G1 X73.21 Y119.367 E.01229
G1 X73.21 Y114.46 E.15076
G1 X182.73 Y114.46 E3.36524
; WIPE_START
M204 S10000
G1 X182.754 Y116.46 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.077 Y118.812 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X167.251 Y118.814 E.41077
G1 X167.105 Y118.77 E.00422
G2 X166.686 Y117.923 I-4.161 J1.533 E.02622
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G2 X166.008 Y117.185 I-2.431 J1.554 E.0279
G1 X165.432 Y116.819 E.01892
G2 X164.673 Y116.563 I-1.412 J2.932 E.02223
; Slow Down End
G1 X163.735 Y116.505 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X163.13 Y116.603 E.017
G1 X162.414 Y116.907 E.02153
G1 X161.848 Y117.3 E.01911
G1 X161.39 Y117.803 E.01884
G1 X161.313 Y117.923 E.00394
; Slow Down End
G1 F12000
G1 X161.104 Y118.253 E.01082
G1 X160.899 Y118.756 E.01507
G1 X160.747 Y118.814 E.00451
G1 X149.137 Y118.812 E.32165
G1 X149.062 Y120.134 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X160.767 Y120.134 E.43158
G1 X160.769 Y119.681 E.01668
G1 X149.227 Y119.681 E.42559
G2 X149.184 Y119.229 I-1.5 J-.088 E.01682
G1 X160.982 Y119.229 E.43498
; WIPE_START
G1 X158.982 Y119.229 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I-.135 J1.209 P1  F30000
G1 X167.062 Y120.134 Z2
G1 Z1.6
G1 E.8 F1800
G1 F3000
G1 X182.065 Y120.134 E.55319
G1 X182.065 Y119.681 E.01668
G1 X167.227 Y119.681 E.54711
G2 X167.184 Y119.229 I-1.5 J-.088 E.01682
G1 X182.234 Y119.229 E.55492
; WIPE_START
G1 X180.234 Y119.229 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X172.626 Y118.622 Z2 F30000
G1 X146.615 Y116.549 Z2
G1 Z1.6
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G3 X147.432 Y116.819 I-.681 J3.424 E.02389
G1 X148.008 Y117.186 E.01892
G3 X148.698 Y117.923 I-2.018 J2.581 E.0281
; Slow Down End
G1 F12000
G3 X148.842 Y118.163 I-.673 J.565 E.00778
; WIPE_START
G1 X148.698 Y117.923 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.714 Y116.506 Z2 F30000
G1 Z1.6
G1 E.8 F1800
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X145.13 Y116.603 E.01643
G1 X144.414 Y116.907 E.02153
G1 X143.848 Y117.3 E.01911
G1 X143.389 Y117.804 E.01886
G1 X143.313 Y117.923 E.00392
; Slow Down End
G1 F12000
G1 X143.104 Y118.253 E.01082
G1 X142.899 Y118.756 E.01506
G1 X142.747 Y118.814 E.00451
M73 P36 R18
G1 X131.251 Y118.812 E.31851
G1 X131.103 Y118.766 E.00428
G2 X130.686 Y117.923 I-4.139 J1.526 E.02611
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G2 X130.008 Y117.186 I-2.431 J1.553 E.02789
G1 X129.432 Y116.819 E.01892
G2 X128.673 Y116.563 I-1.41 J2.927 E.02223
; Slow Down End
G1 X127.702 Y116.507 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X127.13 Y116.603 E.01607
G1 X126.414 Y116.907 E.02153
G1 X125.848 Y117.3 E.0191
G1 X125.39 Y117.803 E.01883
G1 X125.313 Y117.923 E.00395
; Slow Down End
G1 F12000
G1 X125.104 Y118.253 E.01082
G1 X124.899 Y118.756 E.01507
G1 X124.747 Y118.814 E.00451
G1 X113.251 Y118.812 E.31851
G1 X113.103 Y118.766 E.00428
G2 X112.686 Y117.923 I-4.141 J1.527 E.02611
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G2 X112.008 Y117.186 I-2.431 J1.554 E.02789
G1 X111.432 Y116.819 E.01893
G2 X110.673 Y116.563 I-1.41 J2.928 E.02224
; Slow Down End
G1 X109.714 Y116.506 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X109.13 Y116.603 E.01643
G1 X108.414 Y116.907 E.02153
G1 X107.848 Y117.301 E.01911
G1 X107.39 Y117.803 E.01884
G1 X107.313 Y117.923 E.00394
; Slow Down End
G1 F12000
G1 X107.104 Y118.253 E.01082
G1 X106.899 Y118.756 E.01507
G1 X106.747 Y118.814 E.00451
G1 X95.251 Y118.812 E.31851
G1 X95.103 Y118.766 E.00428
G1 X95.033 Y118.569 E.00578
G1 X94.742 Y117.996 E.01782
G1 X94.686 Y117.923 E.00255
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G2 X94.008 Y117.186 I-2.432 J1.554 E.02788
G1 X93.432 Y116.819 E.01893
G2 X92.673 Y116.563 I-1.41 J2.927 E.02223
; Slow Down End
; WIPE_START
G1 X92.952 Y116.633 E-.10919
G1 X93.432 Y116.819 E-.19552
G1 X94.008 Y117.186 E-.25966
G1 X94.382 Y117.528 E-.19265
G1 X94.387 Y117.534 E-.00298
; WIPE_END
G1 E-.04 F1800
G1 X89.176 Y118.13 Z2 F30000
G1 Z1.6
G1 E.8 F1800
G1 F12000
G1 X89.319 Y117.923 E.00697
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X89.484 Y117.684 E.00807
G1 X89.848 Y117.301 E.01463
G1 X90.414 Y116.907 E.01912
G1 X91.13 Y116.603 E.02152
G1 X91.34 Y116.566 E.00593
; Slow Down End
; WIPE_START
G1 X91.13 Y116.603 E-.08132
G1 X90.414 Y116.907 E-.2952
G1 X89.848 Y117.301 E-.26222
G1 X89.628 Y117.532 E-.12127
; WIPE_END
G1 E-.04 F1800
G1 X88.918 Y118.814 Z2 F30000
G1 Z1.6
G1 E.8 F1800
G1 F12000
G1 X74.124 Y118.812 E.40989
G1 X73.972 Y118.763 E.00442
G1 X73.965 Y118.695 E.00191
G1 X73.965 Y116.352 E.06491
G1 X73.977 Y115.227 F30000
; Slow Down Start
; LINE_WIDTH: 0.385948
G1 F3000;_EXTRUDE_SET_SPEED
G1 X181.876 Y115.227 E3.01604
G1 X182 Y115.25 E.00353
G1 X182.035 Y115.399 E.00428
G1 X182.035 Y117.4 E.05594
; Slow Down End
; WIPE_START
G1 X182.035 Y115.4 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X174.439 Y116.145 Z2 F30000
G1 X142.982 Y119.229 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X131.184 Y119.229 E.43498
G3 X131.227 Y119.681 I-1.458 J.364 E.01682
G1 X142.769 Y119.681 E.42559
G1 X142.767 Y120.134 E.01668
G1 X131.062 Y120.134 E.43158
; WIPE_START
G1 X133.062 Y120.134 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I.135 J-1.209 P1  F30000
G1 X124.982 Y119.229 Z2
G1 Z1.6
G1 E.8 F1800
G1 F3000
G1 X113.184 Y119.229 E.43499
G3 X113.227 Y119.681 I-1.458 J.364 E.01682
G1 X124.769 Y119.681 E.42559
G1 X124.767 Y120.134 E.01668
G1 X113.062 Y120.134 E.43158
; WIPE_START
G1 X115.062 Y120.134 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I.135 J-1.209 P1  F30000
G1 X106.982 Y119.229 Z2
G1 Z1.6
G1 E.8 F1800
G1 F3000
G1 X95.184 Y119.229 E.43498
G3 X95.227 Y119.681 I-1.458 J.364 E.01682
G1 X106.769 Y119.681 E.42559
G1 X106.767 Y120.134 E.01668
G1 X95.062 Y120.134 E.43158
; WIPE_START
G1 X97.062 Y120.134 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2 I.135 J-1.209 P1  F30000
G1 X88.982 Y119.229 Z2
G1 Z1.6
G1 E.8 F1800
G1 F3000
G1 X73.935 Y119.229 E.55478
G1 X73.935 Y119.681 E.01668
G1 X88.769 Y119.681 E.54694
G1 X88.767 Y120.134 E.01668
G1 X73.766 Y120.134 E.55311
G1 X75.73 Y118.491 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X74.327 Y118.491 E.04651
G1 X74.327 Y118.265 E.0075
G1 X76.99 Y115.602 E.12491
G1 X79.222 Y115.602 E.07404
G1 X82.111 Y118.491 E.13552
G1 X81.777 Y118.491 E.01108
G1 X84.666 Y115.602 E.13552
G1 X86.898 Y115.602 E.07404
G1 X89.004 Y117.708 E.09879
G1 X89.102 Y117.576 E.00546
G3 X91.812 Y116.132 I2.889 J2.159 E.10521
G1 X92.342 Y115.602 E.02486
G1 X94.574 Y115.602 E.07404
G1 X97.463 Y118.491 E.13552
G1 X97.129 Y118.491 E.01108
G1 X100.018 Y115.602 E.13552
G1 X102.25 Y115.602 E.07404
G1 X105.139 Y118.491 E.13552
G1 X104.805 Y118.491 E.01108
G1 X107.694 Y115.602 E.13552
G1 X109.926 Y115.602 E.07404
G1 X110.499 Y116.159 E.0265
G3 X113.1 Y117.872 I-.528 J3.633 E.10669
G1 X115.37 Y115.602 E.10648
G1 X117.602 Y115.602 E.07404
G1 X120.491 Y118.491 E.13552
G1 X120.157 Y118.491 E.01108
G1 X123.046 Y115.602 E.13552
G1 X125.278 Y115.602 E.07404
G1 X126.251 Y116.576 E.04566
G3 X128.402 Y116.146 I1.775 J3.282 E.07385
G1 X128.195 Y116.463 E.01257
G1 X128.499 Y116.159 E.01427
G3 X129.748 Y116.576 I-.484 J3.53 E.04394
G1 X130.722 Y115.602 E.04567
G1 X132.954 Y115.602 E.07404
G1 X135.843 Y118.491 E.13552
G1 X135.509 Y118.491 E.01108
G1 X138.398 Y115.602 E.13552
G1 X140.63 Y115.602 E.07404
G1 X142.9 Y117.872 E.10648
G3 X145.522 Y116.154 I3.181 J1.996 E.10725
G1 X146.074 Y115.602 E.02591
G1 X148.306 Y115.602 E.07404
G1 X151.195 Y118.491 E.13552
G1 X150.861 Y118.491 E.01108
G1 X153.75 Y115.602 E.13552
G1 X155.982 Y115.602 E.07404
G1 X158.871 Y118.491 E.13552
G1 X158.537 Y118.491 E.01108
G1 X161.426 Y115.602 E.13552
G1 X163.658 Y115.602 E.07404
G1 X164.166 Y116.11 E.02383
G1 X164.259 Y116.104 E.00309
G1 X164.234 Y116.178 E.00258
G1 X164.357 Y116.301 E.00578
G1 X164.499 Y116.159 E.00669
G3 X166.994 Y117.709 I-.533 J3.64 E.10024
G1 X169.102 Y115.602 E.09886
G1 X171.334 Y115.602 E.07404
G1 X174.223 Y118.491 E.13552
G1 X173.889 Y118.491 E.01108
G1 X176.778 Y115.602 E.13552
G1 X179.01 Y115.602 E.07404
G1 X181.899 Y118.491 E.13552
G1 X181.565 Y118.491 E.01108
G1 X182.05 Y118.006 E.02275
G1 X182.05 Y118.439 E.01435
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X182.05 Y118.006 E-.16434
G1 X181.565 Y118.491 E-.26062
G1 X181.899 Y118.491 E-.12689
G1 X181.511 Y118.104 E-.20815
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 9/33
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2 I1.174 J.321 P1  F30000
G1 X182.398 Y114.859 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X182.398 Y119.724 E.16139
G1 X182.398 Y120.124 E.01327
G1 F14655.771
G1 X182.398 Y120.524 E.01327
G1 F6907.886
G1 X182.398 Y120.924 E.01327
G1 F2040
G1 X182.398 Y121.276 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.902 Y121.276 E.51403
G1 F2040
G1 X166.902 Y120.924 E.01167
G1 F6907.886
G1 X166.899 Y120.524 E.01327
G1 F14655.771
G1 X166.895 Y120.125 E.01327
G1 F15476.087
G1 X166.891 Y119.725 E.01327
G1 X166.889 Y119.475 E.00828
G2 X161.098 Y119.743 I-2.889 J.281 E.29272
G1 X161.098 Y120.124 E.01266
G1 F14655.771
G1 X161.098 Y120.524 E.01327
G1 F6907.886
G1 X161.098 Y120.924 E.01327
G1 F2040
G1 X161.098 Y121.276 E.01167
G1 F600
G1 X148.902 Y121.276 E.40456
G1 F2040
G1 X148.902 Y120.924 E.01167
G1 F6907.886
G1 X148.899 Y120.524 E.01327
G1 F14655.771
G1 X148.895 Y120.125 E.01327
G1 F15476.087
G1 X148.891 Y119.725 E.01327
G1 X148.889 Y119.475 E.00828
G2 X143.098 Y119.743 I-2.889 J.281 E.29272
G1 X143.098 Y120.124 E.01266
G1 F14655.771
G1 X143.098 Y120.524 E.01327
G1 F6907.886
G1 X143.098 Y120.924 E.01327
G1 F2040
G1 X143.098 Y121.276 E.01167
G1 F600
G1 X130.902 Y121.276 E.40456
G1 F2040
G1 X130.902 Y120.924 E.01167
G1 F6907.886
G1 X130.899 Y120.524 E.01327
G1 F14655.771
G1 X130.895 Y120.125 E.01327
G1 F15476.087
G1 X130.891 Y119.725 E.01327
G1 X130.889 Y119.475 E.00828
G2 X125.098 Y119.743 I-2.889 J.281 E.29272
G1 X125.098 Y120.124 E.01266
G1 F14655.771
G1 X125.098 Y120.524 E.01327
G1 F6907.886
G1 X125.098 Y120.924 E.01327
G1 F2040
G1 X125.098 Y121.276 E.01167
G1 F600
G1 X112.902 Y121.276 E.40456
G1 F2040
G1 X112.902 Y120.924 E.01167
G1 F6907.886
G1 X112.899 Y120.524 E.01327
G1 F14655.771
G1 X112.895 Y120.125 E.01327
G1 F15476.087
G1 X112.891 Y119.725 E.01327
G1 X112.889 Y119.475 E.00829
G2 X107.098 Y119.743 I-2.889 J.281 E.29271
G1 X107.098 Y120.124 E.01266
G1 F14655.771
G1 X107.098 Y120.524 E.01327
G1 F6907.886
G1 X107.098 Y120.924 E.01327
G1 F2040
G1 X107.098 Y121.276 E.01167
G1 F600
G1 X94.902 Y121.276 E.40456
G1 F2040
G1 X94.902 Y120.924 E.01167
G1 F6907.886
G1 X94.899 Y120.524 E.01327
G1 F14655.771
G1 X94.895 Y120.125 E.01327
G1 F15476.087
G1 X94.891 Y119.725 E.01327
G1 X94.889 Y119.475 E.00828
G2 X89.098 Y119.743 I-2.889 J.281 E.29272
G1 X89.098 Y120.124 E.01266
G1 F14655.771
G1 X89.098 Y120.524 E.01327
G1 F6907.886
G1 X89.098 Y120.924 E.01327
G1 F2040
G1 X89.098 Y121.276 E.01167
G1 F600
G1 X73.602 Y121.276 E.51403
G1 F2040
G1 X73.602 Y120.924 E.01167
G1 F6907.886
G1 X73.602 Y120.524 E.01327
G1 F14655.771
G1 X73.602 Y120.124 E.01327
G1 F15476.087
G1 X73.602 Y119.724 E.01327
G1 X73.602 Y114.859 E.16139
G1 X182.338 Y114.859 E3.60697
M204 S250
G1 X182.79 Y114.467 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y120.138 E.17425
G1 X182.79 Y120.538 E.01229
G1 F6459.938
G1 X182.79 Y120.938 E.01229
G1 F1800
G1 X182.79 Y121.307 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y121.668 E.01199
G1 F600
M73 P37 R18
G1 X166.51 Y121.668 E.54004
G1 X166.51 Y121.307 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y120.938 E.01134
G1 F6459.938
G1 X166.507 Y120.538 E.01229
G1 F12000
G1 X166.504 Y120.138 E.01229
G1 X166.499 Y119.512 E.01923
G2 X161.49 Y119.748 I-2.498 J.243 E.23463
G1 X161.49 Y120.138 E.01199
G1 X161.49 Y120.538 E.01229
G1 F6459.938
G1 X161.49 Y120.938 E.01229
G1 F1800
G1 X161.49 Y121.307 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y121.668 E.01199
G1 X148.51 Y121.668 E.43057
G1 X148.51 Y121.307 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y120.938 E.01134
G1 F6459.938
G1 X148.507 Y120.538 E.01229
G1 F12000
G1 X148.504 Y120.138 E.01229
G1 X148.499 Y119.512 E.01923
G2 X143.49 Y119.748 I-2.498 J.243 E.23463
G1 X143.49 Y120.138 E.01199
G1 X143.49 Y120.538 E.01229
G1 F6459.938
G1 X143.49 Y120.938 E.01229
G1 F1800
G1 X143.49 Y121.307 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y121.668 E.01199
G1 X130.51 Y121.668 E.43057
G1 X130.51 Y121.307 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y120.938 E.01134
G1 F6459.938
G1 X130.507 Y120.538 E.01229
G1 F12000
G1 X130.504 Y120.138 E.01229
G1 X130.499 Y119.512 E.01923
G2 X125.49 Y119.748 I-2.498 J.243 E.23463
G1 X125.49 Y120.138 E.01199
G1 X125.49 Y120.538 E.01229
G1 F6459.938
G1 X125.49 Y120.938 E.01229
G1 F1800
G1 X125.49 Y121.307 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y121.668 E.01199
G1 X112.51 Y121.668 E.43057
G1 X112.51 Y121.307 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y120.938 E.01134
G1 F6459.938
G1 X112.507 Y120.538 E.01229
G1 F12000
G1 X112.504 Y120.138 E.01229
G1 X112.499 Y119.512 E.01923
G2 X107.49 Y119.748 I-2.499 J.243 E.23463
G1 X107.49 Y120.138 E.01199
G1 X107.49 Y120.538 E.01229
G1 F6459.938
G1 X107.49 Y120.938 E.01229
G1 F1800
G1 X107.49 Y121.307 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y121.668 E.01199
G1 X94.51 Y121.668 E.43057
G1 X94.51 Y121.307 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y120.938 E.01134
G1 F6459.938
G1 X94.507 Y120.538 E.01229
G1 F12000
G1 X94.504 Y120.138 E.01229
G1 X94.499 Y119.512 E.01923
G2 X89.49 Y119.748 I-2.498 J.243 E.23463
G1 X89.49 Y120.138 E.01199
G1 X89.49 Y120.538 E.01229
G1 F6459.938
G1 X89.49 Y120.938 E.01229
G1 F1800
G1 X89.49 Y121.307 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y121.668 E.01199
G1 X73.21 Y121.668 E.54004
G1 X73.21 Y121.307 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y120.938 E.01134
G1 F6459.938
G1 X73.21 Y120.538 E.01229
G1 F12000
G1 X73.21 Y120.138 E.01229
G1 X73.21 Y114.467 E.17425
G1 X182.73 Y114.467 E3.36524
; WIPE_START
M204 S10000
G1 X182.751 Y116.467 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.496 Y117.901 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40776
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X182.028 Y117.368 E.04007
G1 X182.028 Y116.721 E.03444
G1 X180.954 Y117.794 E.08079
G1 X180.631 Y117.471 E.02436
G1 X182.028 Y116.073 E.10515
G1 X182.028 Y115.426 E.03444
G1 X178.309 Y119.145 E.27982
G1 X177.662 Y119.145 E.03444
G1 X181.578 Y115.229 E.29465
G1 X180.931 Y115.229 E.03444
G1 X177.015 Y119.145 E.29465
G1 X176.367 Y119.145 E.03444
G1 X179.584 Y115.928 E.24201
G1 X179.26 Y115.605 E.02436
G1 X175.72 Y119.145 E.26637
G1 X175.073 Y119.145 E.03444
G1 X178.673 Y115.544 E.27093
G1 X178.026 Y115.544 E.03444
G1 X174.425 Y119.145 E.27093
G1 X173.778 Y119.145 E.03444
G1 X177.378 Y115.544 E.27093
G1 X177.189 Y115.544 E.01006
G1 X177.169 Y115.229 E.01681
G1 X177.046 Y115.229 E.00654
G1 X173.88 Y118.396 E.23828
G1 X173.556 Y118.072 E.02436
G1 X176.399 Y115.229 E.21393
G1 X175.752 Y115.229 E.03444
G1 X173.232 Y117.748 E.18957
G1 X172.909 Y117.425 E.02436
G1 X175.104 Y115.229 E.16521
G1 X174.457 Y115.229 E.03444
G1 X170.541 Y119.145 E.29465
G1 X169.894 Y119.145 E.03444
G1 X173.81 Y115.229 E.29465
G1 X173.162 Y115.229 E.03444
G1 X169.246 Y119.145 E.29465
G1 X168.599 Y119.145 E.03444
G1 X171.861 Y115.882 E.24549
G1 X171.547 Y115.568 E.02364
G1 X171.529 Y115.567 E.00097
G1 X167.951 Y119.145 E.2692
G1 X167.304 Y119.145 E.03444
G1 X170.905 Y115.544 E.27093
G1 X170.257 Y115.544 E.03444
G1 X167.099 Y118.703 E.23767
G2 X166.903 Y118.252 I-3.305 J1.168 E.0262
G1 X169.61 Y115.544 E.20372
G1 X169.553 Y115.544 E.00306
G1 X169.532 Y115.229 E.01681
G1 X169.278 Y115.229 E.01354
G1 X166.657 Y117.849 E.19719
G2 X166.363 Y117.497 I-1.492 J.946 E.02452
G1 X168.631 Y115.229 E.17064
G1 X167.983 Y115.229 E.03444
G1 X166.025 Y117.187 E.14734
G2 X165.639 Y116.926 I-1.161 J1.301 E.02488
G1 X167.336 Y115.229 E.1277
G1 X166.688 Y115.229 E.03444
G1 X165.204 Y116.713 E.11167
G1 X164.725 Y116.544 E.02701
G1 X166.244 Y115.026 E.11423
G1 X164.357 Y116.301 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
G1 X164.234 Y116.178 E.00578
G1 X162.066 Y115.191 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X164.249 Y115.191 E.06049
G1 X164.485 Y115.379 F30000
; Slow Down Start
; LINE_WIDTH: 0.412132
G1 F3000;_EXTRUDE_SET_SPEED
G1 X164.309 Y115.191 E.00774
G1 X164.663 Y115.248 E.01076
G1 X165.435 Y115.248 E.02325
G1 X165.064 Y115.619 E.0158
G1 X164.404 Y115.619 E.01987
G1 X164.466 Y115.435 E.00584
; Slow Down End
; WIPE_START
G1 X164.404 Y115.619 E-.07382
G1 X165.064 Y115.619 E-.25095
G1 X165.435 Y115.248 E-.19951
G1 X164.815 Y115.248 E-.23573
; WIPE_END
G1 E-.04 F1800
G1 X167.212 Y119.584 Z2.2 F30000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y119.584 E.41017
G1 X182.234 Y120 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X167.235 Y120 E.55304
G1 X167.235 Y120.453 E.01668
G1 X182.065 Y120.453 E.54679
G1 X182.065 Y120.905 E.01668
G1 X167.066 Y120.905 E.55304
; WIPE_START
G1 X169.066 Y120.905 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I.135 J-1.209 P1  F30000
G1 X160.934 Y120 Z2.2
G1 Z1.8
G1 E.8 F1800
G1 F3000
G1 X149.235 Y120 E.43137
G1 X149.235 Y120.453 E.01668
G1 X160.765 Y120.453 E.42511
G1 X160.765 Y120.905 E.01668
G1 X149.066 Y120.905 E.43137
G1 X149.212 Y119.584 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.728 Y119.584 E.31904
G1 X160.384 Y119.169 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.41051
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X160.93 Y118.624 E.04158
G3 X162.864 Y116.689 I3.091 J1.156 E.15214
M73 P38 R18
G1 X163.996 Y115.544 E.08679
G1 X163.358 Y115.544 E.0344
G1 X159.757 Y119.145 E.27459
G1 X159.106 Y119.145 E.03512
G1 X162.707 Y115.544 E.27459
G1 X162.055 Y115.544 E.03512
G1 X158.73 Y118.869 E.25357
G1 X158.795 Y118.663 E.01166
G1 X158.54 Y118.408 E.01943
G1 X161.715 Y115.229 E.24228
G1 X161.068 Y115.229 E.03488
G1 X158.214 Y118.082 E.21762
G1 X157.889 Y117.757 E.02483
G1 X160.417 Y115.229 E.19279
G1 X159.766 Y115.229 E.03512
G1 X157.563 Y117.431 E.16795
G1 X157.426 Y117.294 E.01047
G1 X155.575 Y119.145 E.14116
G1 X155.198 Y119.145 E.02031
G1 X159.114 Y115.229 E.29864
G1 X158.463 Y115.229 E.03512
G1 X154.547 Y119.145 E.29864
G1 X153.896 Y119.145 E.03512
G1 X157.812 Y115.229 E.29864
G1 X157.666 Y115.229 E.00788
G1 X156.534 Y115.89 E.07065
G1 X156.516 Y115.874 E.00132
G1 X153.245 Y119.145 E.24947
G1 X152.593 Y119.145 E.03512
G1 X156.166 Y115.572 E.2725
G1 X156.135 Y115.544 E.00227
G1 X155.543 Y115.544 E.03192
G1 X151.942 Y119.145 E.27459
G1 X151.291 Y119.145 E.03512
G1 X154.891 Y115.544 E.27459
G1 X154.24 Y115.544 E.03512
G1 X151.12 Y118.664 E.23793
G1 X150.795 Y118.338 E.02483
G1 X153.904 Y115.229 E.23715
G1 X153.253 Y115.229 E.03512
G1 X150.469 Y118.013 E.21231
G1 X150.143 Y117.687 E.02483
G1 X152.602 Y115.229 E.18748
G1 X151.95 Y115.229 E.03512
G1 X149.268 Y117.912 E.20459
G1 X148.866 Y118.143 E.025
G1 X148.666 Y117.862 E.01859
G1 X151.299 Y115.229 E.2008
G1 X150.648 Y115.229 E.03512
G1 X148.371 Y117.506 E.17363
G2 X148.032 Y117.193 I-1.893 J1.712 E.02489
G1 X149.943 Y115.282 E.14574
G1 X148.869 Y115.915 E.06724
G1 X148.763 Y115.811 E.00801
G1 X147.645 Y116.93 E.08529
G2 X147.209 Y116.714 I-1.245 J1.975 E.02627
G1 X148.379 Y115.544 E.08925
G1 X147.728 Y115.544 E.03512
G1 X146.568 Y116.704 E.08843
G1 X145.37 Y116.753 F30000
; LINE_WIDTH: 0.40834
G1 F3000
G1 X145.826 Y116.298 E.03437
G1 X146.286 Y115.229 E.06208
G1 X146.246 Y115.229 E.00211
G1 X144.743 Y116.731 E.11338
G2 X143.068 Y118.304 I1.311 J3.075 E.12513
G3 X142.724 Y118.75 I-.942 J-.369 E.03049
G1 X142.397 Y118.429 E.02446
G1 X145.598 Y115.229 E.24152
G1 X144.95 Y115.229 E.03459
G1 X142.07 Y118.109 E.2173
G1 X141.93 Y117.971 E.01045
G1 X140.757 Y119.145 E.08854
G1 X140.386 Y119.145 E.01981
G1 X144.301 Y115.229 E.29549
G1 X143.653 Y115.229 E.03459
G1 X139.737 Y119.145 E.29549
G1 X139.089 Y119.145 E.03459
G1 X143.005 Y115.229 E.29549
G1 X142.357 Y115.229 E.03459
G1 X138.441 Y119.145 E.29549
G1 X137.793 Y119.145 E.03459
G1 X141.128 Y115.81 E.25165
G1 X140.728 Y115.562 E.02512
G1 X137.145 Y119.145 E.27038
G1 X136.496 Y119.145 E.03459
G1 X140.097 Y115.544 E.2717
G1 X139.449 Y115.544 E.03459
G1 X135.848 Y119.145 E.2717
G1 X135.566 Y119.145 E.01507
G1 X135.738 Y118.633 E.02879
G1 X135.725 Y118.62 E.00099
G1 X138.801 Y115.544 E.23212
G1 X138.644 Y115.544 E.00837
G1 X138.624 Y115.229 E.01686
G1 X138.468 Y115.229 E.00831
G1 X135.4 Y118.296 E.23146
G1 X135.076 Y117.972 E.02446
G1 X137.82 Y115.229 E.207
G1 X137.171 Y115.229 E.03459
G1 X134.752 Y117.648 E.18254
G1 X134.685 Y117.58 E.0051
G1 X133.12 Y119.145 E.11805
G1 X132.607 Y119.145 E.02737
G1 X136.523 Y115.229 E.29549
G1 X135.875 Y115.229 E.03459
G1 X131.959 Y119.145 E.29549
G1 X131.311 Y119.145 E.03459
G1 X135.227 Y115.229 E.29549
G1 X134.579 Y115.229 E.03459
G1 X131.1 Y118.707 E.26249
G2 X130.904 Y118.255 I-3.268 J1.144 E.02633
G1 X133.384 Y115.776 E.18708
G1 X133.056 Y115.544 E.02142
G1 X132.967 Y115.544 E.00474
G1 X130.659 Y117.852 E.17415
G2 X130.364 Y117.498 I-1.495 J.946 E.02463
G1 X132.319 Y115.544 E.14747
G1 X131.671 Y115.544 E.03459
G1 X130.027 Y117.188 E.12406
G1 X130.008 Y117.173 E.00125
G2 X129.64 Y116.927 I-1.099 J1.243 E.02374
G1 X131.022 Y115.544 E.10432
G1 X131.007 Y115.544 E.00082
G1 X130.987 Y115.229 E.01686
G1 X130.689 Y115.229 E.01587
G1 X129.205 Y116.713 E.11201
G1 X128.726 Y116.544 E.02712
G1 X130.244 Y115.026 E.11456
G1 X131.338 Y115.191 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
; LAYER_HEIGHT: 0.2
G1 F12000
G1 X133.127 Y115.191 E.04956
; LINE_WIDTH: 0.405547
G1 X133.237 Y115.222 E.00336
; LINE_WIDTH: 0.4508
G1 X133.346 Y115.253 E.00378
; LINE_WIDTH: 0.496054
G1 X133.456 Y115.284 E.0042
G1 X133.962 Y118.909 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X133.609 Y119.262 E.01656
G1 X134.738 Y119.262 E.03745
G1 X135.247 Y118.749 E.02399
G1 X134.685 Y118.186 E.02637
G1 X134.101 Y118.77 E.0274
G1 X131.212 Y119.584 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.728 Y119.584 E.31904
G1 X142.934 Y120 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X131.235 Y120 E.43137
G1 X131.235 Y120.453 E.01668
G1 X142.765 Y120.453 E.42511
G1 X142.765 Y120.905 E.01668
G1 X131.066 Y120.905 E.43137
; WIPE_START
G1 X133.066 Y120.905 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I.717 J-.983 P1  F30000
G1 X127.37 Y116.753 Z2.2
G1 Z1.8
G1 E.8 F1800
; LINE_WIDTH: 0.40834
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X127.726 Y116.397 E.02687
G1 X128.489 Y115.229 E.07445
G1 X128.246 Y115.229 E.01298
G1 X126.743 Y116.731 E.11338
G2 X124.983 Y118.492 I1.3 J3.06 E.13614
G1 X124.706 Y118.768 E.02089
G1 X123.998 Y119.145 E.0428
G1 X123.682 Y119.145 E.01687
G1 X127.598 Y115.229 E.29549
G1 X126.95 Y115.229 E.03459
G1 X123.034 Y119.145 E.29549
G1 X122.386 Y119.145 E.03459
G1 X125.771 Y115.759 E.2555
G1 X125.315 Y115.567 E.02641
G1 X121.737 Y119.145 E.26998
G1 X121.089 Y119.145 E.03459
G1 X124.69 Y115.544 E.2717
G1 X124.042 Y115.544 E.03459
G1 X120.441 Y119.145 E.2717
G1 X120.131 Y119.145 E.01654
G1 X120.329 Y118.608 E.03053
G1 X123.393 Y115.544 E.2312
G1 X123.189 Y115.544 E.01089
G1 X123.169 Y115.229 E.01686
G1 X123.06 Y115.229 E.0058
G1 X120.021 Y118.268 E.22937
G1 X119.697 Y117.944 E.02446
G1 X122.412 Y115.229 E.20491
G1 X121.764 Y115.229 E.03459
G1 X119.373 Y117.62 E.18046
G1 X119.281 Y117.529 E.00689
G1 X117.666 Y119.145 E.12192
G1 X117.2 Y119.145 E.02485
G1 X121.116 Y115.229 E.29549
G1 X120.468 Y115.229 E.03459
G1 X116.552 Y119.145 E.29549
G1 X115.904 Y119.145 E.03459
G1 X119.82 Y115.229 E.29549
G1 X119.171 Y115.229 E.03459
G1 X115.255 Y119.145 E.29549
G1 X114.607 Y119.145 E.03459
G1 X118.012 Y115.74 E.2569
G1 X117.62 Y115.544 E.0234
G1 X117.56 Y115.544 E.0032
G1 X113.959 Y119.145 E.2717
G1 X113.311 Y119.145 E.03459
G1 X116.911 Y115.544 E.2717
G1 X116.263 Y115.544 E.03459
G1 X113.1 Y118.707 E.23869
G1 X113.09 Y118.672 E.00197
G2 X112.904 Y118.255 I-3.782 J1.429 E.02436
G1 X115.615 Y115.544 E.20454
G1 X115.553 Y115.544 E.00334
G1 X115.532 Y115.229 E.01686
G1 X115.282 Y115.229 E.01335
G1 X112.659 Y117.852 E.19794
G2 X112.364 Y117.498 I-1.493 J.945 E.02463
G1 X114.634 Y115.229 E.17126
G1 X113.986 Y115.229 E.03459
G1 X112.026 Y117.188 E.14785
G2 X111.64 Y116.927 I-1.163 J1.303 E.02498
G1 X113.338 Y115.229 E.12811
G1 X112.689 Y115.229 E.03459
G1 X111.205 Y116.713 E.11201
G1 X110.726 Y116.544 E.02712
G1 X112.244 Y115.026 E.11456
G1 X110.491 Y116.167 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
G1 X110.364 Y116.04 E.00595
G1 X109.37 Y116.753 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40834
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X109.818 Y116.305 E.03382
G1 X110.083 Y115.544 E.04298
G1 X109.931 Y115.544 E.00812
M73 P38 R17
G1 X108.731 Y116.736 E.09025
G2 X106.983 Y118.492 I1.303 J3.044 E.13546
G1 X106.707 Y118.768 E.02088
G1 X105.998 Y119.145 E.0428
G1 X105.682 Y119.145 E.01687
G1 X109.283 Y115.544 E.2717
G1 X108.634 Y115.544 E.03459
G1 X105.034 Y119.145 E.2717
G1 X104.694 Y119.145 E.0181
G1 X104.901 Y118.63 E.02961
G1 X108.301 Y115.229 E.25662
G1 X107.653 Y115.229 E.03459
G1 X104.641 Y118.241 E.22728
G1 X104.317 Y117.917 E.02446
G1 X107.005 Y115.229 E.20283
G1 X106.357 Y115.229 E.03459
G1 X103.993 Y117.593 E.17837
G1 X103.878 Y117.478 E.00867
G1 X102.211 Y119.145 E.12578
G1 X101.793 Y119.145 E.02233
G1 X105.709 Y115.229 E.29549
G1 X105.061 Y115.229 E.03459
G1 X101.145 Y119.145 E.29549
G1 X100.496 Y119.145 E.03459
G1 X104.412 Y115.229 E.29549
G1 X104.341 Y115.229 E.00383
G1 X102.98 Y116.084 E.08575
G1 X102.944 Y116.049 E.00268
G1 X99.848 Y119.145 E.23363
G1 X99.2 Y119.145 E.03459
G1 X102.62 Y115.725 E.25808
G1 X102.572 Y115.676 E.00364
G1 X102.152 Y115.544 E.02347
G1 X98.552 Y119.145 E.2717
G1 X97.904 Y119.145 E.03459
G1 X101.504 Y115.544 E.2717
G1 X100.856 Y115.544 E.03459
G1 X97.255 Y119.145 E.2717
G1 X97.051 Y119.145 E.01091
G1 X97.28 Y118.556 E.03372
G1 X97.238 Y118.514 E.00317
G1 X100.208 Y115.544 E.22409
G1 X100.098 Y115.544 E.00586
G1 X100.078 Y115.229 E.01686
G1 X99.875 Y115.229 E.01083
G1 X96.914 Y118.19 E.22342
G1 X96.59 Y117.866 E.02446
G1 X99.227 Y115.229 E.19897
G1 X98.579 Y115.229 E.03459
G1 X95.601 Y118.206 E.22467
G1 X95.065 Y118.549 E.03397
G1 X94.904 Y118.255 E.01789
G1 X97.93 Y115.229 E.22834
G1 X97.282 Y115.229 E.03459
G1 X94.659 Y117.852 E.19794
G1 X94.557 Y117.709 E.00939
G2 X94.364 Y117.498 I-5.784 J5.108 E.01521
G1 X96.508 Y115.355 E.16176
G1 X95.324 Y116.104 E.07478
G1 X95.217 Y115.997 E.00805
G1 X94.027 Y117.188 E.08985
G2 X93.64 Y116.927 I-1.163 J1.303 E.02498
G1 X94.885 Y115.681 E.09397
G1 X94.539 Y115.544 E.01989
G1 X94.374 Y115.544 E.00878
G1 X93.205 Y116.713 E.08822
G1 X92.726 Y116.544 E.02712
G1 X93.928 Y115.342 E.09076
G1 X93.027 Y115.53 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.59218
; LAYER_HEIGHT: 0.2
G1 F11469.978
G1 X93.22 Y115.337 E.01223
G1 X93.627 Y115.191 E.01934
; LINE_WIDTH: 0.38292
G1 F12000
G1 X94.522 Y115.191 E.02479
G1 X95.098 Y115.346 F30000
; LINE_WIDTH: 0.373679
G1 F12000
G1 X94.582 Y115.191 E.01454
G2 X95.98 Y115.228 I.969 J-10.264 E.03773
G1 X95.393 Y115.599 E.01871
G1 X95.144 Y115.385 E.00885
G1 X95.34 Y118.882 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X95.161 Y118.996 E.00705
G1 X95.213 Y119.262 E.009
G1 X96.358 Y119.262 E.03797
G2 X96.779 Y118.661 I-.473 J-.78 E.02507
G1 X96.353 Y118.234 E.02001
G1 X95.755 Y118.616 E.02352
G1 X95.212 Y119.584 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.728 Y119.584 E.31904
G1 X106.934 Y120 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X95.235 Y120 E.43137
G1 X95.235 Y120.453 E.01668
G1 X106.765 Y120.453 E.42511
G1 X106.765 Y120.905 E.01668
G1 X95.066 Y120.905 E.43137
; WIPE_START
G1 X97.066 Y120.905 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I.674 J-1.013 P1  F30000
G1 X90.984 Y116.861 Z2.2
G1 Z1.8
G1 E.8 F1800
; LINE_WIDTH: 0.40804
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X92.617 Y115.229 E.12301
G1 X91.969 Y115.229 E.03451
G1 X89.15 Y118.047 E.21236
G3 X88.799 Y117.751 I.713 J-1.2 E.0246
G1 X91.321 Y115.229 E.19001
G1 X90.673 Y115.229 E.03451
G1 X88.475 Y117.427 E.16561
G1 X88.336 Y117.288 E.01049
G1 X86.479 Y119.145 E.13993
G1 X86.11 Y119.145 E.01968
G1 X90.025 Y115.229 E.29506
G1 X89.378 Y115.229 E.03451
G1 X85.462 Y119.145 E.29506
G1 X84.814 Y119.145 E.03451
G1 X88.73 Y115.229 E.29506
G1 X88.568 Y115.229 E.00862
G1 X87.437 Y115.874 E.06935
G1 X84.166 Y119.145 E.24648
G1 X83.518 Y119.145 E.03451
G1 X87.084 Y115.579 E.26863
G1 X87.041 Y115.544 E.00295
G1 X86.471 Y115.544 E.03036
G1 X82.871 Y119.145 E.2713
G1 X82.223 Y119.145 E.03451
G1 X85.824 Y115.544 E.2713
G1 X85.176 Y115.544 E.03451
G1 X82.046 Y118.674 E.23581
G1 X81.722 Y118.35 E.0244
G1 X84.843 Y115.229 E.23516
G1 X84.196 Y115.229 E.03451
G1 X81.398 Y118.026 E.21075
G1 X81.075 Y117.702 E.0244
G1 X83.548 Y115.229 E.18635
G1 X82.9 Y115.229 E.03451
G1 X80.751 Y117.378 E.16195
G1 X80.68 Y117.307 E.00534
G1 X78.842 Y119.145 E.13846
G1 X78.336 Y119.145 E.02695
G1 X82.252 Y115.229 E.29506
G1 X81.604 Y115.229 E.03451
G1 X77.689 Y119.145 E.29506
G1 X77.041 Y119.145 E.03451
G1 X80.957 Y115.229 E.29506
G1 X79.782 Y115.907 E.07226
G1 X79.704 Y115.834 E.00571
G1 X76.393 Y119.145 E.24949
G1 X75.745 Y119.145 E.03451
G1 X79.346 Y115.544 E.2713
G1 X78.698 Y115.544 E.03451
G1 X75.097 Y119.145 E.2713
G1 X74.45 Y119.145 E.03451
G1 X78.05 Y115.544 E.2713
G1 X77.403 Y115.544 E.03451
G1 X74.429 Y118.517 E.22403
G1 X73.972 Y118.542 E.02442
G1 X73.972 Y118.327 E.01146
G1 X77.07 Y115.229 E.23345
G1 X76.422 Y115.229 E.03451
G1 X73.972 Y117.679 E.18464
G1 X73.972 Y117.032 E.03451
G1 X75.775 Y115.229 E.13584
G1 X75.127 Y115.229 E.03451
G1 X73.769 Y116.586 E.10229
G1 X73.976 Y115.233 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38371
; LAYER_HEIGHT: 0.2
G1 F12000
G1 X74.558 Y115.233 E.01616
G1 X74.156 Y115.635 E.01578
G1 X73.976 Y115.635 E.005
G1 X73.976 Y115.293 E.00949
G1 X77.697 Y115.191 F30000
; LINE_WIDTH: 0.38292
G1 F12000
G1 X79.486 Y115.191 E.04956
; LINE_WIDTH: 0.403423
G1 X79.562 Y115.217 E.00238
; LINE_WIDTH: 0.444428
G1 X79.639 Y115.243 E.00265
; LINE_WIDTH: 0.485433
G1 X79.715 Y115.269 E.00292
; LINE_WIDTH: 0.526438
G1 X79.792 Y115.295 E.00319
G1 X81.006 Y119.262 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X81.517 Y118.751 E.024
G1 X85.334 Y115.191 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X87.122 Y115.191 E.04956
; LINE_WIDTH: 0.40194
G1 X87.201 Y115.216 E.00242
; LINE_WIDTH: 0.43998
G1 X87.28 Y115.241 E.00267
; LINE_WIDTH: 0.47802
G1 X87.359 Y115.266 E.00293
; LINE_WIDTH: 0.51606
G1 X87.438 Y115.291 E.00319
M73 P39 R17
G1 X88.934 Y120 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y120 E.55304
G1 X73.935 Y120.453 E.01668
G1 X88.765 Y120.453 E.54679
G1 X88.765 Y120.905 E.01668
G1 X73.766 Y120.905 E.55304
G1 X73.923 Y119.584 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.728 Y119.584 E.41017
; WIPE_START
G1 X86.728 Y119.584 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X93.996 Y117.253 Z2.2 F30000
G1 X100.43 Y115.191 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
G1 F12000
G1 X102.201 Y115.191 E.04907
G1 X102.746 Y115.327 F30000
; LINE_WIDTH: 0.368195
G1 F12000
G1 X102.261 Y115.194 E.01333
G2 X103.62 Y115.225 I.931 J-11.276 E.03607
G1 X103.035 Y115.592 E.01832
G1 X102.79 Y115.367 E.00882
G1 X102.908 Y119.054 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.7 Y119.262 E.00976
G1 X104.034 Y119.262 E.04425
G2 X104.435 Y118.64 I-.526 J-.779 E.02523
G1 X103.878 Y118.084 E.0261
G1 X103.564 Y118.398 E.01474
G1 X108.703 Y115.191 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X110.34 Y115.191 E.04535
G1 X111.435 Y115.248 F30000
; LINE_WIDTH: 0.410442
G1 F12000
G1 X110.753 Y115.248 E.02045
G1 X110.4 Y115.191 E.01071
G1 X110.575 Y115.38 E.00773
G1 X110.492 Y115.619 E.00759
G1 X111.064 Y115.619 E.01715
G1 X111.393 Y115.291 E.01393
G1 X115.884 Y115.191 F30000
; LINE_WIDTH: 0.38292
G1 F12000
G1 X117.673 Y115.191 E.04956
; LINE_WIDTH: 0.40756
G1 X117.851 Y115.23 E.00543
; LINE_WIDTH: 0.45684
G1 X118.03 Y115.269 E.00617
G1 X119.386 Y119.262 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X119.774 Y118.874 E.01822
G1 X123.521 Y115.191 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X125.309 Y115.191 E.04956
; LINE_WIDTH: 0.40388
G1 X125.495 Y115.227 E.00556
; LINE_WIDTH: 0.4458
G1 X125.68 Y115.263 E.0062
G1 X128.96 Y115.235 F30000
; LINE_WIDTH: 0.38697
G1 F12000
G1 X129.468 Y115.235 E.01425
G1 X129.07 Y115.633 E.0158
G1 X128.699 Y115.633 E.01038
G1 X128.927 Y115.285 E.01166
; WIPE_START
G1 X128.699 Y115.633 E-.17012
G1 X129.07 Y115.633 E-.15146
G1 X129.468 Y115.235 E-.23047
G1 X128.96 Y115.235 E-.20795
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.2 I-.93 J-.785 P1  F30000
G1 X124.934 Y120 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X113.235 Y120 E.43137
G1 X113.235 Y120.453 E.01668
G1 X124.765 Y120.453 E.42511
G1 X124.765 Y120.905 E.01668
G1 X113.066 Y120.905 E.43137
G1 X113.212 Y119.584 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.728 Y119.584 E.31904
; WIPE_START
G1 X122.728 Y119.584 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.096 Y117.592 Z2.2 F30000
G1 X138.975 Y115.191 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
G1 F12000
G1 X140.764 Y115.191 E.04956
; LINE_WIDTH: 0.40309
G1 X140.876 Y115.22 E.00341
; LINE_WIDTH: 0.44343
G1 X140.989 Y115.249 E.00379
; LINE_WIDTH: 0.48377
G1 X141.101 Y115.278 E.00417
G1 X141.571 Y118.937 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X141.245 Y119.262 E.01526
G1 X142.414 Y119.262 E.03875
G1 X142.523 Y119.153 E.00513
G1 X141.933 Y118.575 E.0274
G1 X141.571 Y118.937 E.017
G1 X147.605 Y115.192 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X148.582 Y115.191 E.02707
; LINE_WIDTH: 0.40387
G1 X148.658 Y115.217 E.00236
; LINE_WIDTH: 0.44577
G1 X148.733 Y115.244 E.00264
; LINE_WIDTH: 0.48767
G1 X148.809 Y115.27 E.00291
; LINE_WIDTH: 0.52957
G1 X148.885 Y115.297 E.00319
G1 X147.605 Y115.192 F30000
; LINE_WIDTH: 0.405221
G1 F12000
G1 X147.527 Y115.219 E.00243
G1 X147.064 Y115.619 E.01807
G1 X146.564 Y115.619 E.01475
G1 X146.724 Y115.248 E.01193
G2 X147.545 Y115.197 I.132 J-4.515 E.02431
G1 X149.027 Y118.544 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X149.017 Y118.55 E.00038
G3 X149.213 Y119.262 I-3.201 J1.262 E.02455
G1 X150.089 Y119.262 E.02907
G1 X150.601 Y118.751 E.02399
G1 X149.895 Y118.045 E.03312
G1 X149.349 Y118.359 E.0209
G1 X154.43 Y115.191 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X156.218 Y115.191 E.04956
; LINE_WIDTH: 0.402413
G1 X156.296 Y115.216 E.0024
; LINE_WIDTH: 0.441398
G1 X156.374 Y115.241 E.00267
; LINE_WIDTH: 0.480383
G1 X156.453 Y115.267 E.00293
; LINE_WIDTH: 0.519368
G1 X156.531 Y115.292 E.00319
G1 X156.137 Y119.262 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X157.765 Y119.262 E.05401
G1 X158.277 Y118.751 E.024
G1 X157.426 Y117.9 E.03992
G1 X157.126 Y118.2 E.01409
G1 X169.884 Y115.191 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G3 X171.651 Y115.205 I.577 J38.343 E.04897
; LINE_WIDTH: 0.407153
G1 X171.725 Y115.231 E.00233
; LINE_WIDTH: 0.455618
G1 X171.8 Y115.257 E.00264
; LINE_WIDTH: 0.504083
G1 X171.874 Y115.283 E.00296
; LINE_WIDTH: 0.552548
G1 X171.948 Y115.31 E.00327
G1 X177.521 Y115.191 F30000
; LINE_WIDTH: 0.38292
G1 F12000
G3 X179.303 Y115.195 I.576 J131.634 E.04937
; LINE_WIDTH: 0.405043
G1 X179.378 Y115.222 E.00235
; LINE_WIDTH: 0.449288
G1 X179.453 Y115.248 E.00264
; LINE_WIDTH: 0.493533
G1 X179.528 Y115.275 E.00293
; LINE_WIDTH: 0.537778
G1 X179.604 Y115.301 E.00321
G1 X181.042 Y119.262 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.05 Y119.262 E.03343
G1 X182.05 Y118.642 E.02058
G1 X181.535 Y118.127 E.02416
G1 X182.05 Y117.937 E.0182
G1 X182.05 Y118.006 E.00228
G1 X180.793 Y119.262 E.05894
G1 X179.165 Y119.262 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X180.793 Y119.262 E-.61876
G1 X181.056 Y119 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/33
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.2 I1.156 J.379 P1  F30000
G1 X182.398 Y114.905 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X182.398 Y120.496 E.18545
G1 X182.398 Y120.896 E.01327
G1 F14655.771
G1 X182.398 Y121.296 E.01327
G1 F6907.886
G1 X182.398 Y121.696 E.01327
G1 F2040
G1 X182.398 Y122.048 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.902 Y122.048 E.51403
G1 F2040
G1 X166.902 Y121.696 E.01167
G1 F6907.886
G1 X166.901 Y121.296 E.01327
G1 F14655.771
G1 X166.901 Y120.896 E.01327
G1 F15476.087
G1 X166.9 Y120.496 E.01327
G1 X166.899 Y119.612 E.02932
G2 X161.098 Y119.743 I-2.899 J.14 E.2975
G1 X161.098 Y120.496 E.02497
G1 X161.098 Y120.896 E.01327
G1 F14655.771
G1 X161.098 Y121.296 E.01327
G1 F6907.886
G1 X161.098 Y121.696 E.01327
G1 F2040
G1 X161.098 Y122.048 E.01167
G1 F600
G1 X148.902 Y122.048 E.40456
G1 F2040
G1 X148.902 Y121.696 E.01167
G1 F6907.886
G1 X148.901 Y121.296 E.01327
G1 F14655.771
G1 X148.901 Y120.896 E.01327
G1 F15476.087
G1 X148.9 Y120.496 E.01327
G1 X148.899 Y119.612 E.02932
G2 X143.098 Y119.743 I-2.899 J.14 E.2975
G1 X143.098 Y120.496 E.02497
G1 X143.098 Y120.896 E.01327
G1 F14655.771
G1 X143.098 Y121.296 E.01327
G1 F6907.886
G1 X143.098 Y121.696 E.01327
G1 F2040
G1 X143.098 Y122.048 E.01167
G1 F600
G1 X130.902 Y122.048 E.40456
G1 F2040
G1 X130.902 Y121.696 E.01167
G1 F6907.886
G1 X130.901 Y121.296 E.01327
G1 F14655.771
G1 X130.901 Y120.896 E.01327
G1 F15476.087
G1 X130.9 Y120.496 E.01327
G1 X130.899 Y119.612 E.02932
G2 X125.098 Y119.743 I-2.899 J.14 E.29749
G1 X125.098 Y120.496 E.02498
G1 X125.098 Y120.896 E.01327
G1 F14655.771
G1 X125.098 Y121.296 E.01327
G1 F6907.886
G1 X125.098 Y121.696 E.01327
G1 F2040
G1 X125.098 Y122.048 E.01167
G1 F600
G1 X112.902 Y122.048 E.40456
G1 F2040
G1 X112.902 Y121.696 E.01167
G1 F6907.886
G1 X112.901 Y121.296 E.01327
G1 F14655.771
G1 X112.901 Y120.896 E.01327
G1 F15476.087
G1 X112.9 Y120.496 E.01327
G1 X112.899 Y119.612 E.02932
G2 X107.098 Y119.743 I-2.899 J.14 E.29749
G1 X107.098 Y120.496 E.02498
G1 X107.098 Y120.896 E.01327
G1 F14655.771
G1 X107.098 Y121.296 E.01327
G1 F6907.886
G1 X107.098 Y121.696 E.01327
G1 F2040
G1 X107.098 Y122.048 E.01167
G1 F600
G1 X94.902 Y122.048 E.40456
G1 F2040
G1 X94.902 Y121.696 E.01167
G1 F6907.886
G1 X94.901 Y121.296 E.01327
G1 F14655.771
G1 X94.901 Y120.896 E.01327
G1 F15476.087
G1 X94.9 Y120.496 E.01327
G1 X94.899 Y119.612 E.02932
G2 X89.098 Y119.743 I-2.899 J.14 E.29749
G1 X89.098 Y120.496 E.02498
G1 X89.098 Y120.896 E.01327
G1 F14655.771
G1 X89.098 Y121.296 E.01327
G1 F6907.886
G1 X89.098 Y121.696 E.01327
G1 F2040
G1 X89.098 Y122.048 E.01167
G1 F600
G1 X73.602 Y122.048 E.51403
G1 F2040
G1 X73.602 Y121.696 E.01167
G1 F6907.886
G1 X73.602 Y121.296 E.01327
G1 F14655.771
G1 X73.602 Y120.896 E.01327
G1 F15476.087
G1 X73.602 Y120.496 E.01327
G1 X73.602 Y114.905 E.18545
G1 X182.338 Y114.905 E3.60697
M204 S250
G1 X182.79 Y114.513 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y120.909 E.19654
G1 X182.79 Y121.309 E.01229
G1 F6459.938
G1 X182.79 Y121.709 E.01229
G1 F1800
G1 X182.79 Y122.078 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y122.44 E.01199
G1 F600
G1 X166.51 Y122.44 E.54004
G1 X166.51 Y122.078 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y121.709 E.01134
G1 F6459.938
G1 X166.509 Y121.309 E.01229
G1 F12000
G1 X166.509 Y120.909 E.01229
G1 X166.507 Y119.631 E.03929
G2 X161.49 Y119.748 I-2.507 J.121 E.23844
G1 X161.49 Y120.909 E.0357
G1 X161.49 Y121.309 E.01229
G1 F6459.938
G1 X161.49 Y121.709 E.01229
G1 F1800
G1 X161.49 Y122.078 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y122.44 E.01199
G1 X148.51 Y122.44 E.43057
G1 X148.51 Y122.078 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y121.709 E.01134
G1 F6459.938
G1 X148.509 Y121.309 E.01229
G1 F12000
G1 X148.509 Y120.909 E.01229
G1 X148.507 Y119.631 E.03929
G2 X143.49 Y119.748 I-2.507 J.121 E.23844
G1 X143.49 Y120.909 E.0357
G1 X143.49 Y121.309 E.01229
G1 F6459.938
G1 X143.49 Y121.709 E.01229
G1 F1800
G1 X143.49 Y122.078 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y122.44 E.01199
G1 X130.51 Y122.44 E.43057
G1 X130.51 Y122.078 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y121.709 E.01134
G1 F6459.938
G1 X130.509 Y121.309 E.01229
G1 F12000
G1 X130.509 Y120.909 E.01229
G1 X130.507 Y119.631 E.03929
G2 X125.49 Y119.748 I-2.507 J.121 E.23844
G1 X125.49 Y120.909 E.0357
G1 X125.49 Y121.309 E.01229
G1 F6459.938
G1 X125.49 Y121.709 E.01229
G1 F1800
G1 X125.49 Y122.078 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y122.44 E.01199
G1 X112.51 Y122.44 E.43057
G1 X112.51 Y122.078 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y121.709 E.01134
G1 F6459.938
G1 X112.509 Y121.309 E.01229
G1 F12000
G1 X112.509 Y120.909 E.01229
G1 X112.507 Y119.631 E.03929
G2 X107.49 Y119.748 I-2.507 J.121 E.23844
G1 X107.49 Y120.909 E.0357
G1 X107.49 Y121.309 E.01229
G1 F6459.938
G1 X107.49 Y121.709 E.01229
G1 F1800
G1 X107.49 Y122.078 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y122.44 E.01199
G1 X94.51 Y122.44 E.43057
G1 X94.51 Y122.078 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y121.709 E.01134
G1 F6459.938
G1 X94.509 Y121.309 E.01229
G1 F12000
G1 X94.509 Y120.909 E.01229
G1 X94.507 Y119.631 E.03929
G2 X89.49 Y119.748 I-2.507 J.121 E.23844
G1 X89.49 Y120.909 E.0357
G1 X89.49 Y121.309 E.01229
G1 F6459.938
G1 X89.49 Y121.709 E.01229
G1 F1800
G1 X89.49 Y122.078 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y122.44 E.01199
G1 X73.21 Y122.44 E.54004
G1 X73.21 Y122.078 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y121.709 E.01134
G1 F6459.938
G1 X73.21 Y121.309 E.01229
G1 F12000
G1 X73.21 Y120.909 E.01229
M73 P40 R17
G1 X73.21 Y114.513 E.19654
G1 X182.73 Y114.513 E3.36524
; WIPE_START
M204 S10000
G1 X182.749 Y116.513 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.234 Y120.772 Z2.4 F30000
G1 Z2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X167.229 Y120.772 E.55328
G1 X167.231 Y121.224 E.01668
G1 X182.065 Y121.224 E.54694
G1 X182.065 Y121.677 E.01668
G1 X167.064 Y121.677 E.55311
G1 X167.215 Y120.355 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y120.355 E.4101
G1 X167.108 Y117.984 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X166.729 Y117.984 E.01256
G3 X167.192 Y119.136 I-2.924 J1.845 E.04143
G1 X168.09 Y120.034 E.0421
G1 X172.346 Y120.034 E.14119
G1 X174.396 Y117.984 E.09617
G1 X173.715 Y117.984 E.02257
G1 X175.766 Y120.034 E.09617
G1 X180.022 Y120.034 E.14119
G1 X182.05 Y118.006 E.09513
G1 X182.05 Y118.642 E.0211
G1 X181.391 Y117.984 E.03088
G1 X179.763 Y117.984 E.05401
G1 X164.879 Y116.575 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G3 X166.474 Y117.592 I-.849 J3.092 E.05901
G1 X182.006 Y117.592 E.47723
G1 X182.006 Y115.297 E.0705
G1 X73.994 Y115.297 E3.31882
G1 X73.994 Y117.592 E.0705
G1 X89.526 Y117.592 E.47722
G3 X91.62 Y116.479 I2.505 J2.186 E.07451
G1 X92.381 Y116.479 E.02339
G3 X94.474 Y117.592 I-.41 J3.297 E.0745
G1 X107.526 Y117.592 E.40101
G3 X109.62 Y116.479 I2.505 J2.186 E.07451
G1 X110.381 Y116.479 E.02339
G3 X112.474 Y117.592 I-.41 J3.297 E.0745
G1 X125.526 Y117.592 E.40101
G3 X127.62 Y116.479 I2.505 J2.186 E.07451
G1 X128.381 Y116.479 E.02339
G3 X130.474 Y117.592 I-.41 J3.297 E.0745
G1 X143.526 Y117.592 E.40101
G3 X145.62 Y116.479 I2.505 J2.186 E.07451
G1 X146.381 Y116.479 E.02339
G3 X148.474 Y117.592 I-.41 J3.297 E.0745
G1 X161.526 Y117.592 E.40101
G3 X163.62 Y116.479 I2.505 J2.186 E.07451
G1 X164.381 Y116.479 E.02339
G1 X164.82 Y116.563 E.01376
G1 X146.926 Y116.198 F30000
; LINE_WIDTH: 0.421503
G1 F12000
G3 X148.634 Y117.215 I-.884 J3.429 E.06219
G1 X161.366 Y117.215 E.39275
G1 X161.663 Y116.919 E.01293
G3 X163.62 Y116.089 I2.446 J3.043 E.06642
G1 X164.381 Y116.089 E.02348
G3 X166.337 Y116.919 I-.49 J3.874 E.0664
G1 X166.634 Y117.215 E.01294
G1 X181.629 Y117.215 E.46257
G1 X181.629 Y115.674 E.04752
G1 X164.976 Y115.674 E.51372
G3 X163.024 Y115.674 I-.977 J-38.082 E.06025
G1 X146.976 Y115.674 E.49505
G3 X145.024 Y115.674 I-.977 J-38.082 E.06025
G1 X128.976 Y115.674 E.49505
G3 X127.024 Y115.674 I-.977 J-38.082 E.06025
G1 X110.976 Y115.674 E.49505
G3 X109.024 Y115.674 I-.977 J-38.082 E.06025
G1 X92.976 Y115.674 E.49505
G3 X91.024 Y115.674 I-.977 J-38.082 E.06025
G1 X74.371 Y115.674 E.51372
G1 X74.371 Y117.215 E.04752
G1 X89.365 Y117.215 E.46257
G1 X89.663 Y116.919 E.01293
G3 X91.62 Y116.089 I2.446 J3.043 E.06642
G1 X92.381 Y116.089 E.02348
G3 X94.337 Y116.919 I-.49 J3.874 E.06639
G1 X94.634 Y117.215 E.01294
G1 X107.366 Y117.215 E.39275
G1 X107.663 Y116.919 E.01293
G3 X109.62 Y116.089 I2.446 J3.043 E.06642
G1 X110.381 Y116.089 E.02348
G3 X112.337 Y116.919 I-.49 J3.874 E.06639
G1 X112.634 Y117.215 E.01294
G1 X125.366 Y117.215 E.39275
G1 X125.663 Y116.919 E.01292
G3 X127.62 Y116.089 I2.446 J3.043 E.06642
G1 X128.381 Y116.089 E.02348
G3 X130.337 Y116.919 I-.49 J3.874 E.0664
G1 X130.634 Y117.215 E.01294
G1 X143.366 Y117.215 E.39275
G1 X143.663 Y116.919 E.01292
G3 X145.62 Y116.089 I2.446 J3.043 E.06642
G1 X146.381 Y116.089 E.02348
G1 X146.867 Y116.186 E.01529
G1 X181.252 Y116.444 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X181.252 Y116.051 E.01208
G1 X165.642 Y116.051 E.47962
G1 X166.194 Y116.349 E.01927
G1 X166.68 Y116.719 E.01874
G1 X166.794 Y116.838 E.00508
G1 X181.252 Y116.838 E.44422
G1 X181.252 Y116.504 E.01024
G1 X166.961 Y116.444 F30000
; LINE_WIDTH: 0.45206
G1 F12000
G1 X180.799 Y116.444 E.46133
G1 X162.358 Y116.051 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X147.642 Y116.051 E.45214
G1 X148.194 Y116.349 E.01927
G1 X148.68 Y116.719 E.01874
G1 X148.794 Y116.838 E.00508
G1 X161.205 Y116.838 E.38135
G1 X161.441 Y116.614 E.00997
G3 X162.304 Y116.079 I2.413 J2.927 E.03131
G1 X148.961 Y116.444 F30000
; LINE_WIDTH: 0.45206
G1 F12000
G1 X160.979 Y116.444 E.40066
G1 X144.358 Y116.051 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X129.642 Y116.051 E.45214
G1 X130.194 Y116.349 E.01927
G1 X130.68 Y116.719 E.01874
G1 X130.794 Y116.838 E.00508
G1 X143.205 Y116.838 E.38135
G1 X143.441 Y116.614 E.00997
G3 X144.304 Y116.079 I2.414 J2.928 E.03131
G1 X130.961 Y116.444 F30000
; LINE_WIDTH: 0.45205
G1 F12000
G1 X142.979 Y116.444 E.40065
G1 X126.358 Y116.051 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X111.642 Y116.051 E.45214
G1 X112.195 Y116.349 E.01928
G1 X112.68 Y116.719 E.01873
G1 X112.794 Y116.838 E.00508
G1 X125.205 Y116.838 E.38135
G1 X125.441 Y116.614 E.00997
G3 X126.304 Y116.079 I2.413 J2.928 E.03131
G1 X112.961 Y116.444 F30000
; LINE_WIDTH: 0.45205
G1 F12000
G1 X124.979 Y116.444 E.40065
G1 X108.358 Y116.051 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X93.642 Y116.051 E.45214
G1 X94.195 Y116.349 E.01928
G1 X94.68 Y116.719 E.01873
G1 X94.794 Y116.838 E.00508
G1 X107.205 Y116.838 E.38135
G1 X107.441 Y116.614 E.00997
G3 X108.304 Y116.079 I2.413 J2.928 E.03131
G1 X94.961 Y116.444 F30000
; LINE_WIDTH: 0.45206
G1 F12000
G1 X106.979 Y116.444 E.40066
G1 X90.358 Y116.051 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X74.748 Y116.051 E.47962
G1 X74.748 Y116.838 E.02416
G1 X89.205 Y116.838 E.44422
G1 X89.441 Y116.614 E.00997
G3 X90.304 Y116.079 I2.413 J2.928 E.03131
G1 X75.141 Y116.444 F30000
; LINE_WIDTH: 0.45206
G1 F12000
G1 X88.979 Y116.444 E.46133
G1 X88.941 Y120.772 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y120.772 E.55328
G1 X73.935 Y121.224 E.01668
G1 X88.769 Y121.224 E.54694
G1 X88.767 Y121.677 E.01668
G1 X73.766 Y121.677 E.55311
G1 X73.923 Y120.355 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.725 Y120.355 E.41011
; WIPE_START
G1 X86.725 Y120.355 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I-.191 J1.202 P1  F30000
G1 X95.064 Y121.677 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X106.767 Y121.677 E.43151
G1 X106.769 Y121.224 E.01668
G1 X95.231 Y121.224 E.42542
G1 X95.229 Y120.772 E.01668
G1 X106.941 Y120.772 E.43184
; WIPE_START
G1 X104.941 Y120.772 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I-.135 J1.209 P1  F30000
G1 X113.064 Y121.677 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X124.767 Y121.677 E.43151
G1 X124.769 Y121.224 E.01668
G1 X113.231 Y121.224 E.42542
G1 X113.229 Y120.772 E.01668
G1 X124.941 Y120.772 E.43184
; WIPE_START
G1 X122.941 Y120.772 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I-.135 J1.209 P1  F30000
G1 X131.064 Y121.677 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X142.767 Y121.677 E.4315
G1 X142.769 Y121.224 E.01668
G1 X131.231 Y121.224 E.42542
G1 X131.229 Y120.772 E.01668
G1 X142.941 Y120.772 E.43184
; WIPE_START
G1 X140.941 Y120.772 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.4 I-.135 J1.209 P1  F30000
G1 X149.064 Y121.677 Z2.4
G1 Z2
G1 E.8 F1800
G1 F3000
G1 X160.767 Y121.677 E.4315
G1 X160.769 Y121.224 E.01668
G1 X149.231 Y121.224 E.42542
G1 X149.229 Y120.772 E.01668
G1 X160.941 Y120.772 E.43184
G1 X149.215 Y120.355 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.725 Y120.355 E.31891
G1 X149.006 Y118.515 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X149.24 Y120.034 I-3.174 J1.266 E.05143
G1 X149.318 Y120.034 E.00258
G1 X151.368 Y117.984 E.09617
G1 X150.688 Y117.984 E.02257
G1 X152.738 Y120.034 E.09617
G1 X156.994 Y120.034 E.14119
G1 X159.044 Y117.984 E.09617
G1 X158.364 Y117.984 E.02257
G1 X160.414 Y120.034 E.09617
G1 X160.76 Y120.034 E.01149
G3 X160.903 Y118.768 I4.441 J-.138 E.04242
; WIPE_START
G1 X160.763 Y119.446 E-.26322
G1 X160.76 Y120.034 E-.22344
G1 X160.414 Y120.034 E-.13161
G1 X160.15 Y119.77 E-.14174
; WIPE_END
G1 E-.04 F1800
G1 X152.518 Y119.843 Z2.4 F30000
G1 X132.338 Y120.034 Z2.4
G1 Z2
G1 E.8 F1800
G1 F15476.087
G1 X133.966 Y120.034 E.05401
G1 X136.016 Y117.984 E.09617
G1 X135.336 Y117.984 E.02257
G1 X137.386 Y120.034 E.09617
G1 X141.642 Y120.034 E.14119
G1 X142.901 Y118.775 E.05905
G3 X143.174 Y118.146 I3.945 J1.342 E.02277
G1 X143.012 Y117.984 E.00763
G1 X141.383 Y117.984 E.05401
G1 X131.215 Y120.355 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.725 Y120.355 E.31891
; WIPE_START
G1 X140.725 Y120.355 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X133.124 Y119.665 Z2.4 F30000
G1 X114.617 Y117.984 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
M73 P41 R17
G1 F15476.087
G1 X112.988 Y117.984 E.05401
G1 X112.826 Y118.146 E.0076
G3 X113.099 Y118.775 I-4.127 J2.163 E.02277
G1 X114.358 Y120.034 E.05906
G1 X118.614 Y120.034 E.14119
G1 X120.664 Y117.984 E.09617
G1 X119.984 Y117.984 E.02257
G1 X122.034 Y120.034 E.09617
G1 X123.662 Y120.034 E.05401
G1 X113.215 Y120.355 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.725 Y120.355 E.31891
; WIPE_START
G1 X122.725 Y120.355 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X115.093 Y120.355 Z2.4 F30000
G1 X95.215 Y120.355 Z2.4
G1 Z2
G1 E.8 F1800
G1 F15000
G1 X106.725 Y120.355 E.31891
G1 X95.096 Y118.767 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X95.24 Y120.034 I-4.294 J1.129 E.04243
G1 X95.586 Y120.034 E.01148
G1 X97.636 Y117.984 E.09617
G1 X96.956 Y117.984 E.02257
G1 X99.006 Y120.034 E.09617
G1 X103.262 Y120.034 E.14119
G1 X105.312 Y117.984 E.09617
G1 X104.632 Y117.984 E.02257
G1 X106.682 Y120.034 E.09617
G1 X106.76 Y120.034 E.00259
G3 X106.993 Y118.515 I3.409 J-.254 E.05142
; WIPE_START
G1 X106.809 Y119.127 E-.24306
G1 X106.76 Y120.034 E-.34497
G1 X106.682 Y120.034 E-.02964
G1 X106.417 Y119.769 E-.14233
; WIPE_END
G1 E-.04 F1800
G1 X98.798 Y119.318 Z2.4 F30000
G1 X76.237 Y117.984 Z2.4
G1 Z2
G1 E.8 F1800
G1 F15476.087
G1 X74.609 Y117.984 E.05401
G1 X73.95 Y118.642 E.03088
G1 X73.95 Y118.006 E.0211
G1 X75.978 Y120.034 E.09513
G1 X80.234 Y120.034 E.14119
G1 X82.284 Y117.984 E.09617
G1 X81.604 Y117.984 E.02257
G1 X83.654 Y120.034 E.09617
G1 X87.91 Y120.034 E.14119
G1 X88.808 Y119.136 E.04211
G3 X89.271 Y117.984 I3.384 J.691 E.04143
G1 X88.892 Y117.984 E.01257
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X89.271 Y117.984 E-.14401
G1 X88.989 Y118.524 E-.23158
G1 X88.808 Y119.136 E-.24263
G1 X88.544 Y119.4 E-.14179
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 11/33
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.4 I.057 J1.216 P1  F30000
G1 X182.398 Y115.003 Z2.4
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X182.398 Y121.267 E.20781
G1 X182.398 Y121.667 E.01327
G1 F14655.771
G1 X182.398 Y122.067 E.01327
G1 F6907.886
G1 X182.398 Y122.467 E.01327
G1 F2040
G1 X182.398 Y122.819 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.902 Y122.819 E.51403
G1 F2040
G1 X166.902 Y122.467 E.01167
G1 F6907.886
G1 X166.902 Y122.067 E.01327
G1 F14655.771
G1 X166.902 Y121.667 E.01327
G1 F15476.087
G1 X166.902 Y121.267 E.01327
G1 X166.902 Y119.743 E.05056
G2 X161.098 Y119.743 I-2.902 J.014 E.30152
G1 X161.098 Y121.267 E.05056
G1 X161.098 Y121.667 E.01327
G1 F14655.771
G1 X161.098 Y122.067 E.01327
G1 F6907.886
G1 X161.098 Y122.467 E.01327
G1 F2040
G1 X161.098 Y122.819 E.01167
G1 F600
G1 X148.902 Y122.819 E.40456
G1 F2040
G1 X148.902 Y122.467 E.01167
G1 F6907.886
G1 X148.902 Y122.067 E.01327
G1 F14655.771
G1 X148.902 Y121.667 E.01327
G1 F15476.087
G1 X148.902 Y121.267 E.01327
G1 X148.902 Y119.743 E.05056
G2 X143.098 Y119.743 I-2.902 J.014 E.30152
G1 X143.098 Y121.267 E.05056
G1 X143.098 Y121.667 E.01327
G1 F14655.771
G1 X143.098 Y122.067 E.01327
G1 F6907.886
G1 X143.098 Y122.467 E.01327
G1 F2040
G1 X143.098 Y122.819 E.01167
G1 F600
G1 X130.902 Y122.819 E.40456
G1 F2040
G1 X130.902 Y122.467 E.01167
G1 F6907.886
G1 X130.902 Y122.067 E.01327
G1 F14655.771
G1 X130.902 Y121.667 E.01327
G1 F15476.087
G1 X130.902 Y121.267 E.01327
G1 X130.902 Y119.743 E.05056
G2 X125.098 Y119.743 I-2.902 J.014 E.3015
G1 X125.098 Y121.267 E.05057
G1 X125.098 Y121.667 E.01327
G1 F14655.771
G1 X125.098 Y122.067 E.01327
G1 F6907.886
G1 X125.098 Y122.467 E.01327
G1 F2040
G1 X125.098 Y122.819 E.01167
G1 F600
G1 X112.902 Y122.819 E.40456
G1 F2040
G1 X112.902 Y122.467 E.01167
G1 F6907.886
G1 X112.902 Y122.067 E.01327
G1 F14655.771
G1 X112.902 Y121.667 E.01327
G1 F15476.087
G1 X112.902 Y121.267 E.01327
G1 X112.902 Y119.743 E.05056
G2 X107.098 Y119.743 I-2.902 J.014 E.3015
G1 X107.098 Y121.267 E.05057
G1 X107.098 Y121.667 E.01327
G1 F14655.771
G1 X107.098 Y122.067 E.01327
G1 F6907.886
G1 X107.098 Y122.467 E.01327
G1 F2040
G1 X107.098 Y122.819 E.01167
G1 F600
G1 X94.902 Y122.819 E.40456
G1 F2040
G1 X94.902 Y122.467 E.01167
G1 F6907.886
G1 X94.902 Y122.067 E.01327
G1 F14655.771
G1 X94.902 Y121.667 E.01327
G1 F15476.087
G1 X94.902 Y121.267 E.01327
G1 X94.902 Y119.743 E.05056
G2 X89.098 Y119.743 I-2.902 J.014 E.3015
G1 X89.098 Y121.267 E.05057
G1 X89.098 Y121.667 E.01327
G1 F14655.771
G1 X89.098 Y122.067 E.01327
G1 F6907.886
G1 X89.098 Y122.467 E.01327
G1 F2040
G1 X89.098 Y122.819 E.01167
G1 F600
G1 X73.602 Y122.819 E.51403
G1 F2040
G1 X73.602 Y122.467 E.01167
G1 F6907.886
G1 X73.602 Y122.067 E.01327
G1 F14655.771
G1 X73.602 Y121.667 E.01327
G1 F15476.087
G1 X73.602 Y121.267 E.01327
G1 X73.602 Y115.003 E.20781
G1 X182.338 Y115.003 E3.60697
M204 S250
G1 X182.79 Y114.611 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y121.681 E.21725
G1 X182.79 Y122.081 E.01229
G1 F6459.938
G1 X182.79 Y122.481 E.01229
G1 F1800
G1 X182.79 Y122.85 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y123.211 E.01199
G1 F600
G1 X166.51 Y123.211 E.54004
G1 X166.51 Y122.85 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y122.481 E.01134
G1 F6459.938
G1 X166.51 Y122.081 E.01229
G1 F12000
G1 X166.51 Y121.681 E.01229
G1 X166.51 Y119.748 E.0594
G2 X161.49 Y119.748 I-2.51 J.009 E.24176
G1 X161.49 Y121.681 E.0594
G1 X161.49 Y122.081 E.01229
G1 F6459.938
G1 X161.49 Y122.481 E.01229
G1 F1800
G1 X161.49 Y122.85 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y123.211 E.01199
G1 X148.51 Y123.211 E.43057
G1 X148.51 Y122.85 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y122.481 E.01134
G1 F6459.938
G1 X148.51 Y122.081 E.01229
G1 F12000
G1 X148.51 Y121.681 E.01229
G1 X148.51 Y119.748 E.0594
G2 X143.49 Y119.748 I-2.51 J.009 E.24176
G1 X143.49 Y121.681 E.0594
G1 X143.49 Y122.081 E.01229
G1 F6459.938
G1 X143.49 Y122.481 E.01229
G1 F1800
G1 X143.49 Y122.85 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y123.211 E.01199
G1 X130.51 Y123.211 E.43057
G1 X130.51 Y122.85 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y122.481 E.01134
G1 F6459.938
G1 X130.51 Y122.081 E.01229
G1 F12000
G1 X130.51 Y121.681 E.01229
G1 X130.51 Y119.748 E.0594
G2 X125.49 Y119.748 I-2.51 J.009 E.24176
G1 X125.49 Y121.681 E.0594
G1 X125.49 Y122.081 E.01229
G1 F6459.938
G1 X125.49 Y122.481 E.01229
G1 F1800
G1 X125.49 Y122.85 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y123.211 E.01199
G1 X112.51 Y123.211 E.43057
G1 X112.51 Y122.85 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y122.481 E.01134
G1 F6459.938
G1 X112.51 Y122.081 E.01229
G1 F12000
G1 X112.51 Y121.681 E.01229
G1 X112.51 Y119.748 E.0594
G2 X107.49 Y119.748 I-2.51 J.009 E.24176
G1 X107.49 Y121.681 E.0594
G1 X107.49 Y122.081 E.01229
G1 F6459.938
G1 X107.49 Y122.481 E.01229
G1 F1800
G1 X107.49 Y122.85 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y123.211 E.01199
G1 X94.51 Y123.211 E.43057
G1 X94.51 Y122.85 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y122.481 E.01134
G1 F6459.938
G1 X94.51 Y122.081 E.01229
G1 F12000
G1 X94.51 Y121.681 E.01229
G1 X94.51 Y119.748 E.0594
G2 X89.49 Y119.748 I-2.51 J.009 E.24176
G1 X89.49 Y121.681 E.0594
G1 X89.49 Y122.081 E.01229
G1 F6459.938
G1 X89.49 Y122.481 E.01229
G1 F1800
G1 X89.49 Y122.85 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y123.211 E.01199
G1 X73.21 Y123.211 E.54004
G1 X73.21 Y122.85 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y122.481 E.01134
G1 F6459.938
G1 X73.21 Y122.081 E.01229
G1 F12000
G1 X73.21 Y121.681 E.01229
M73 P42 R16
G1 X73.21 Y114.611 E.21725
G1 X182.73 Y114.611 E3.36524
; WIPE_START
M204 S10000
G1 X182.747 Y116.611 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X179.672 Y118.755 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X181.301 Y118.755 E.05401
G1 X179.25 Y120.805 E.09618
G1 X176.537 Y120.805 E.09
G1 X174.487 Y118.755 E.09618
G1 X173.625 Y118.755 E.0286
G1 X171.574 Y120.805 E.09618
G1 X168.861 Y120.805 E.09
G1 X167.184 Y119.128 E.07867
G2 X167.09 Y118.755 I-1.217 J.109 E.01282
G1 X168.332 Y118.755 E.04122
G1 X167.222 Y121.127 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y121.127 E.4099
G1 X182.234 Y121.543 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X167.234 Y121.543 E.55309
G1 X167.234 Y121.996 E.01668
G1 X182.065 Y121.996 E.54682
G1 X182.065 Y122.448 E.01668
G1 X167.065 Y122.448 E.55306
; WIPE_START
G1 X169.065 Y122.448 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.6 I.135 J-1.209 P1  F30000
G1 X160.936 Y121.543 Z2.6
G1 Z2.2
G1 E.8 F1800
G1 F3000
G1 X149.234 Y121.543 E.43146
G1 X149.234 Y121.996 E.01668
G1 X160.766 Y121.996 E.42517
G1 X160.765 Y122.448 E.01668
G1 X149.065 Y122.448 E.43139
G1 X149.222 Y121.127 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.718 Y121.127 E.3185
G1 X159.556 Y120.805 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X160.752 Y120.805 E.03965
G1 X160.752 Y120.372 E.01437
G1 X159.135 Y118.755 E.07587
G1 X158.273 Y118.755 E.0286
G1 X156.222 Y120.805 E.09618
G1 X153.509 Y120.805 E.09
G1 X151.459 Y118.755 E.09618
G1 X150.597 Y118.755 E.0286
G1 X149.248 Y120.104 E.06329
G1 X149.248 Y120.805 E.02326
G1 X150.176 Y120.805 E.03075
; WIPE_START
G1 X149.248 Y120.805 E-.35231
G1 X149.248 Y120.104 E-.26645
G1 X149.511 Y119.841 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X142.936 Y121.543 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X131.234 Y121.543 E.43146
G1 X131.234 Y121.996 E.01668
G1 X142.766 Y121.996 E.42517
G1 X142.765 Y122.448 E.01668
G1 X131.065 Y122.448 E.43139
G1 X131.222 Y121.127 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.718 Y121.127 E.3185
G1 X141.301 Y118.755 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X142.91 Y118.755 E.05339
G1 X140.871 Y120.805 E.09593
G1 X138.157 Y120.805 E.09
G1 X136.107 Y118.755 E.09618
G1 X135.245 Y118.755 E.0286
G1 X133.195 Y120.805 E.09618
G1 X131.566 Y120.805 E.05401
; WIPE_START
G1 X133.195 Y120.805 E-.61876
G1 X133.457 Y120.543 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X125.877 Y121.433 Z2.6 F30000
G1 X124.936 Y121.543 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X113.234 Y121.543 E.43146
G1 X113.234 Y121.996 E.01668
G1 X124.766 Y121.996 E.42517
G1 X124.765 Y122.448 E.01668
G1 X113.065 Y122.448 E.43139
G1 X113.222 Y121.127 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.718 Y121.127 E.3185
G1 X124.434 Y120.805 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X122.805 Y120.805 E.05401
G1 X120.755 Y118.755 E.09618
G1 X119.893 Y118.755 E.0286
G1 X117.843 Y120.805 E.09618
G1 X115.129 Y120.805 E.09
G1 X113.09 Y118.755 E.09593
G1 X114.699 Y118.755 E.05339
; WIPE_START
G1 X113.09 Y118.755 E-.61157
G1 X113.365 Y119.032 E-.14844
; WIPE_END
G1 E-.04 F1800
G1 X106.936 Y121.543 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X95.234 Y121.543 E.43146
G1 X95.234 Y121.996 E.01668
G1 X106.766 Y121.996 E.42517
G1 X106.765 Y122.448 E.01668
G1 X95.065 Y122.448 E.43139
G1 X95.222 Y121.127 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.718 Y121.127 E.3185
G1 X105.824 Y120.805 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X106.752 Y120.805 E.03076
G1 X106.752 Y120.104 E.02326
G1 X105.403 Y118.755 E.06329
G1 X104.541 Y118.755 E.0286
G1 X102.491 Y120.805 E.09618
G1 X99.778 Y120.805 E.09
G1 X97.727 Y118.755 E.09618
G1 X96.865 Y118.755 E.0286
G1 X95.248 Y120.372 E.07586
G1 X95.248 Y120.805 E.01437
G1 X96.444 Y120.805 E.03965
; WIPE_START
G1 X95.248 Y120.805 E-.45417
G1 X95.248 Y120.372 E-.16459
G1 X95.511 Y120.109 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X88.936 Y121.543 Z2.6 F30000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y121.543 E.55309
G1 X73.935 Y121.996 E.01668
G1 X88.766 Y121.996 E.54682
G1 X88.765 Y122.448 E.01668
G1 X73.766 Y122.448 E.55306
G1 X73.923 Y121.126 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.718 Y121.127 E.40991
G1 X87.667 Y118.755 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.91 Y118.755 E.04122
G2 X88.816 Y119.128 I1.134 J.485 E.01282
G1 X87.139 Y120.805 E.07867
G1 X84.426 Y120.805 E.09
G1 X82.375 Y118.755 E.09618
G1 X81.513 Y118.755 E.0286
G1 X79.463 Y120.805 E.09618
G1 X76.75 Y120.805 E.09
G1 X74.699 Y118.755 E.09618
G1 X76.328 Y118.755 E.05401
; WIPE_START
G1 X74.699 Y118.755 E-.61876
G1 X74.962 Y119.018 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X82.593 Y118.884 Z2.6 F30000
G1 X161.598 Y117.496 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G3 X163.243 Y116.545 I2.397 J2.249 E.05924
G1 X163.989 Y116.457 E.02308
G1 X164.779 Y116.55 E.02443
G3 X166.968 Y118.363 I-.753 J3.137 E.09043
G1 X182.006 Y118.363 E.46206
G1 X182.006 Y115.395 E.09121
G1 X73.994 Y115.395 E3.31882
G1 X73.994 Y118.363 E.09121
G1 X89.032 Y118.363 E.46205
G1 X89.276 Y117.9 E.01608
G3 X91.243 Y116.545 I2.792 J1.949 E.075
G1 X91.989 Y116.457 E.02308
G1 X92.779 Y116.551 E.02444
G3 X94.968 Y118.363 I-.753 J3.137 E.09042
G1 X107.032 Y118.363 E.37067
G1 X107.276 Y117.9 E.01608
G3 X109.243 Y116.545 I2.792 J1.949 E.07501
G1 X109.989 Y116.457 E.02308
G1 X110.779 Y116.551 E.02444
G3 X112.968 Y118.363 I-.753 J3.137 E.09042
G1 X125.032 Y118.363 E.37067
G1 X125.276 Y117.9 E.01608
G3 X127.243 Y116.545 I2.792 J1.949 E.075
G1 X127.989 Y116.457 E.02308
G1 X128.779 Y116.55 E.02443
G3 X130.968 Y118.363 I-.753 J3.137 E.09043
G1 X143.032 Y118.363 E.37067
G1 X143.276 Y117.9 E.01608
G3 X145.243 Y116.545 I2.792 J1.949 E.07501
G1 X145.989 Y116.457 E.02308
G1 X146.779 Y116.55 E.02443
G3 X148.968 Y118.363 I-.753 J3.137 E.09043
G1 X161.032 Y118.363 E.37067
G1 X161.276 Y117.9 E.01608
G1 X161.561 Y117.543 E.01404
G1 X161.051 Y117.572 F30000
; LINE_WIDTH: 0.419649
G1 F12000
G3 X163.166 Y116.168 I3.069 J2.329 E.07942
G1 X163.947 Y116.099 E.02406
G1 X164.827 Y116.169 E.02709
G3 X166.998 Y117.633 I-.94 J3.736 E.08204
G1 X167.196 Y117.986 E.0124
G1 X181.629 Y117.986 E.44308
G1 X181.629 Y115.772 E.06797
G1 X165.449 Y115.772 E.4967
G3 X164.101 Y115.756 I-.488 J-15.541 E.04139
G3 X162.576 Y115.772 I-1.004 J-22.845 E.04682
G1 X147.449 Y115.772 E.46439
G3 X146.101 Y115.756 I-.488 J-15.541 E.04139
G3 X144.576 Y115.772 I-1.004 J-22.849 E.04683
G1 X129.449 Y115.772 E.46439
G3 X128.101 Y115.756 I-.488 J-15.541 E.04139
G3 X126.576 Y115.772 I-1.004 J-22.849 E.04683
G1 X111.449 Y115.772 E.46439
G3 X110.101 Y115.756 I-.488 J-15.54 E.04139
G3 X108.576 Y115.772 I-1.004 J-22.844 E.04682
G1 X93.449 Y115.772 E.4644
G3 X92.101 Y115.756 I-.488 J-15.546 E.04138
G3 X90.576 Y115.772 I-1.004 J-22.832 E.04682
G1 X74.371 Y115.772 E.49748
G1 X74.371 Y117.986 E.06797
G1 X88.804 Y117.986 E.44307
G3 X91.166 Y116.168 I3.209 J1.725 E.09428
G1 X91.947 Y116.099 E.02406
G1 X92.827 Y116.169 E.0271
G3 X94.998 Y117.633 I-.94 J3.736 E.08203
G1 X95.196 Y117.986 E.0124
G1 X106.804 Y117.986 E.35636
G3 X109.166 Y116.168 I3.209 J1.726 E.09428
G1 X109.947 Y116.099 E.02406
G1 X110.827 Y116.169 E.0271
G3 X112.998 Y117.633 I-.94 J3.736 E.08203
G1 X113.196 Y117.986 E.0124
G1 X124.804 Y117.986 E.35636
G3 X127.166 Y116.168 I3.209 J1.725 E.09428
G1 X127.947 Y116.099 E.02406
G1 X128.827 Y116.169 E.02709
G3 X130.998 Y117.633 I-.94 J3.736 E.08204
G1 X131.196 Y117.986 E.0124
G1 X142.804 Y117.986 E.35636
G3 X145.166 Y116.168 I3.208 J1.725 E.09428
G1 X145.947 Y116.099 E.02406
G1 X146.827 Y116.169 E.02709
G3 X148.998 Y117.633 I-.94 J3.736 E.08204
G1 X149.196 Y117.986 E.0124
G1 X160.804 Y117.986 E.35636
G1 X161.02 Y117.623 E.01296
G1 X165.832 Y116.149 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X166.488 Y116.558 E.02375
G3 X167.423 Y117.609 I-2.743 J3.384 E.04341
G1 X181.252 Y117.609 E.4249
G1 X181.252 Y116.149 E.04486
G1 X165.892 Y116.149 E.47194
M73 P43 R16
G1 X167.02 Y116.526 F30000
G1 F12000
G3 X167.633 Y117.232 I-2.491 J2.782 E.0288
G1 X180.875 Y117.232 E.40688
G1 X180.875 Y116.526 E.02169
G1 X167.08 Y116.526 E.42386
G1 X167.812 Y116.879 F30000
; LINE_WIDTH: 0.37175
G1 F12000
G1 X180.462 Y116.879 E.33894
G1 X162.167 Y116.149 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X147.832 Y116.149 E.44045
G1 X148.488 Y116.558 E.02375
G3 X149.423 Y117.609 I-2.743 J3.384 E.04341
G1 X160.577 Y117.609 E.3427
G1 X160.991 Y117.044 E.02153
G3 X162.114 Y116.177 I3.309 J3.125 E.04378
G1 X160.98 Y116.526 F30000
G1 F12000
G1 X149.02 Y116.526 E.3675
G3 X149.633 Y117.232 I-2.491 J2.782 E.0288
G1 X160.367 Y117.232 E.32983
G3 X160.938 Y116.568 I2.907 J1.923 E.02696
G1 X149.812 Y116.879 F30000
; LINE_WIDTH: 0.37174
G1 F12000
G1 X160.128 Y116.879 E.27639
G1 X144.167 Y116.149 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X129.832 Y116.149 E.44045
G1 X130.488 Y116.558 E.02375
G3 X131.423 Y117.609 I-2.743 J3.384 E.04341
G1 X142.577 Y117.609 E.3427
G1 X142.991 Y117.044 E.02153
G3 X144.114 Y116.177 I3.308 J3.124 E.04378
G1 X142.98 Y116.526 F30000
G1 F12000
G1 X131.02 Y116.526 E.3675
G3 X131.633 Y117.232 I-2.491 J2.782 E.0288
G1 X142.367 Y117.232 E.32983
G3 X142.938 Y116.568 I2.907 J1.923 E.02696
G1 X131.812 Y116.879 F30000
; LINE_WIDTH: 0.37174
G1 F12000
G1 X142.128 Y116.879 E.27639
G1 X126.167 Y116.149 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X111.832 Y116.149 E.44046
G1 X112.488 Y116.559 E.02375
G3 X113.423 Y117.609 I-2.743 J3.384 E.04341
G1 X124.577 Y117.609 E.3427
G1 X124.991 Y117.044 E.02152
G3 X126.114 Y116.177 I3.309 J3.125 E.04378
G1 X124.98 Y116.526 F30000
G1 F12000
G1 X113.02 Y116.526 E.3675
G3 X113.633 Y117.232 I-2.491 J2.782 E.0288
G1 X124.367 Y117.232 E.32983
G3 X124.938 Y116.568 I2.907 J1.923 E.02696
G1 X113.812 Y116.879 F30000
; LINE_WIDTH: 0.37176
G1 F12000
G1 X124.128 Y116.879 E.27641
G1 X108.167 Y116.149 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X93.833 Y116.149 E.44045
G1 X94.488 Y116.559 E.02375
G3 X95.423 Y117.609 I-2.743 J3.384 E.04341
G1 X106.577 Y117.609 E.3427
G1 X106.991 Y117.044 E.02153
G3 X108.114 Y116.177 I3.309 J3.125 E.04378
G1 X106.98 Y116.526 F30000
G1 F12000
G1 X95.02 Y116.526 E.3675
G3 X95.633 Y117.232 I-2.491 J2.782 E.0288
G1 X106.367 Y117.232 E.32983
G3 X106.938 Y116.568 I2.906 J1.922 E.02696
G1 X95.812 Y116.879 F30000
; LINE_WIDTH: 0.37177
G1 F12000
G1 X106.128 Y116.879 E.27642
G1 X90.167 Y116.149 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X74.748 Y116.149 E.47377
G1 X74.748 Y117.609 E.04486
G1 X88.577 Y117.609 E.42489
G1 X88.991 Y117.044 E.02152
G3 X90.114 Y116.177 I3.309 J3.125 E.04378
G1 X88.98 Y116.526 F30000
G1 F12000
G1 X75.125 Y116.526 E.42571
G1 X75.125 Y117.232 E.02169
G1 X88.367 Y117.232 E.40688
G3 X88.938 Y116.568 I2.905 J1.921 E.02696
G1 X75.478 Y116.879 F30000
; LINE_WIDTH: 0.37177
G1 F12000
G1 X88.128 Y116.879 E.33897
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X86.128 Y116.879 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/33
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.6 I.022 J1.217 P1  F30000
G1 X182.398 Y115.175 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y122.039 E.2277
G1 X182.398 Y122.439 E.01327
G1 F14655.771
G1 X182.398 Y122.839 E.01327
G1 F6907.886
G1 X182.398 Y123.239 E.01327
G1 F2040
G1 X182.398 Y123.591 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.902 Y123.591 E.51403
G1 F2040
G1 X166.902 Y123.239 E.01167
G1 F6907.886
G1 X166.902 Y122.839 E.01327
G1 F14655.771
G1 X166.902 Y122.439 E.01327
G1 F15476.087
G1 X166.902 Y122.039 E.01327
G1 X166.902 Y119.743 E.07615
G2 X161.098 Y119.743 I-2.902 J.014 E.30151
G1 X161.098 Y122.039 E.07615
G1 X161.098 Y122.439 E.01327
G1 F14655.771
G1 X161.098 Y122.839 E.01327
G1 F6907.886
G1 X161.098 Y123.239 E.01327
G1 F2040
G1 X161.098 Y123.591 E.01167
G1 F600
G1 X148.902 Y123.591 E.40456
G1 F2040
G1 X148.902 Y123.239 E.01167
G1 F6907.886
G1 X148.902 Y122.839 E.01327
G1 F14655.771
G1 X148.902 Y122.439 E.01327
G1 F15476.087
G1 X148.902 Y122.039 E.01327
G1 X148.902 Y119.743 E.07615
G2 X143.098 Y119.743 I-2.902 J.014 E.30151
G1 X143.098 Y122.039 E.07615
G1 X143.098 Y122.439 E.01327
G1 F14655.771
G1 X143.098 Y122.839 E.01327
G1 F6907.886
G1 X143.098 Y123.239 E.01327
G1 F2040
G1 X143.098 Y123.591 E.01167
G1 F600
G1 X130.902 Y123.591 E.40456
G1 F2040
G1 X130.902 Y123.239 E.01167
G1 F6907.886
G1 X130.902 Y122.839 E.01327
G1 F14655.771
G1 X130.902 Y122.439 E.01327
G1 F15476.087
G1 X130.902 Y122.039 E.01327
G1 X130.902 Y119.743 E.07615
G2 X125.098 Y119.743 I-2.902 J.014 E.30151
G1 X125.098 Y122.039 E.07615
G1 X125.098 Y122.439 E.01327
G1 F14655.771
G1 X125.098 Y122.839 E.01327
G1 F6907.886
G1 X125.098 Y123.239 E.01327
G1 F2040
G1 X125.098 Y123.591 E.01167
G1 F600
G1 X112.902 Y123.591 E.40456
G1 F2040
G1 X112.902 Y123.239 E.01167
G1 F6907.886
G1 X112.902 Y122.839 E.01327
G1 F14655.771
G1 X112.902 Y122.439 E.01327
G1 F15476.087
G1 X112.902 Y122.039 E.01327
G1 X112.902 Y119.743 E.07615
G2 X107.098 Y119.743 I-2.902 J.014 E.30151
G1 X107.098 Y122.039 E.07615
G1 X107.098 Y122.439 E.01327
G1 F14655.771
G1 X107.098 Y122.839 E.01327
G1 F6907.886
G1 X107.098 Y123.239 E.01327
G1 F2040
G1 X107.098 Y123.591 E.01167
G1 F600
G1 X94.902 Y123.591 E.40456
G1 F2040
G1 X94.902 Y123.239 E.01167
G1 F6907.886
G1 X94.902 Y122.839 E.01327
G1 F14655.771
G1 X94.902 Y122.439 E.01327
G1 F15476.087
G1 X94.902 Y122.039 E.01327
G1 X94.902 Y119.743 E.07615
G2 X89.098 Y119.743 I-2.902 J.014 E.30151
G1 X89.098 Y122.039 E.07615
G1 X89.098 Y122.439 E.01327
G1 F14655.771
G1 X89.098 Y122.839 E.01327
G1 F6907.886
G1 X89.098 Y123.239 E.01327
G1 F2040
G1 X89.098 Y123.591 E.01167
G1 F600
G1 X73.602 Y123.591 E.51403
G1 F2040
G1 X73.602 Y123.239 E.01167
G1 F6907.886
G1 X73.602 Y122.839 E.01327
G1 F14655.771
G1 X73.602 Y122.439 E.01327
G1 F15476.087
G1 X73.602 Y122.039 E.01327
G1 X73.602 Y115.175 E.2277
G1 X182.338 Y115.175 E3.60697
M204 S250
G1 X182.79 Y114.782 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y122.452 E.23567
G1 X182.79 Y122.852 E.01229
G1 F6459.938
G1 X182.79 Y123.252 E.01229
G1 F1800
G1 X182.79 Y123.621 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y123.983 E.01199
G1 F600
G1 X166.51 Y123.983 E.54004
G1 X166.51 Y123.621 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y123.252 E.01134
G1 F6459.938
G1 X166.51 Y122.852 E.01229
G1 F12000
G1 X166.51 Y122.452 E.01229
G1 X166.51 Y119.748 E.0831
G2 X161.49 Y119.748 I-2.51 J.009 E.24176
G1 X161.49 Y122.452 E.0831
G1 X161.49 Y122.852 E.01229
G1 F6459.938
G1 X161.49 Y123.252 E.01229
G1 F1800
G1 X161.49 Y123.621 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y123.983 E.01199
G1 X148.51 Y123.983 E.43057
G1 X148.51 Y123.621 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y123.252 E.01134
G1 F6459.938
G1 X148.51 Y122.852 E.01229
G1 F12000
G1 X148.51 Y122.452 E.01229
G1 X148.51 Y119.748 E.0831
G2 X143.49 Y119.748 I-2.51 J.009 E.24176
G1 X143.49 Y122.452 E.0831
G1 X143.49 Y122.852 E.01229
G1 F6459.938
G1 X143.49 Y123.252 E.01229
G1 F1800
G1 X143.49 Y123.621 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y123.983 E.01199
G1 X130.51 Y123.983 E.43057
G1 X130.51 Y123.621 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y123.252 E.01134
G1 F6459.938
G1 X130.51 Y122.852 E.01229
G1 F12000
G1 X130.51 Y122.452 E.01229
G1 X130.51 Y119.748 E.0831
G2 X125.49 Y119.748 I-2.51 J.009 E.24176
G1 X125.49 Y122.452 E.0831
G1 X125.49 Y122.852 E.01229
G1 F6459.938
G1 X125.49 Y123.252 E.01229
G1 F1800
G1 X125.49 Y123.621 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y123.983 E.01199
G1 X112.51 Y123.983 E.43057
G1 X112.51 Y123.621 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y123.252 E.01134
G1 F6459.938
G1 X112.51 Y122.852 E.01229
G1 F12000
G1 X112.51 Y122.452 E.01229
G1 X112.51 Y119.748 E.0831
G2 X107.49 Y119.748 I-2.51 J.009 E.24176
G1 X107.49 Y122.452 E.0831
G1 X107.49 Y122.852 E.01229
G1 F6459.938
G1 X107.49 Y123.252 E.01229
G1 F1800
G1 X107.49 Y123.621 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y123.983 E.01199
G1 X94.51 Y123.983 E.43057
G1 X94.51 Y123.621 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y123.252 E.01134
G1 F6459.938
G1 X94.51 Y122.852 E.01229
G1 F12000
G1 X94.51 Y122.452 E.01229
G1 X94.51 Y119.748 E.0831
G2 X89.49 Y119.748 I-2.51 J.009 E.24176
G1 X89.49 Y122.452 E.0831
G1 X89.49 Y122.852 E.01229
G1 F6459.938
G1 X89.49 Y123.252 E.01229
G1 F1800
G1 X89.49 Y123.621 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y123.983 E.01199
G1 X73.21 Y123.983 E.54004
G1 X73.21 Y123.621 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y123.252 E.01134
G1 F6459.938
G1 X73.21 Y122.852 E.01229
G1 F12000
G1 X73.21 Y122.452 E.01229
M73 P44 R16
G1 X73.21 Y114.782 E.23567
G1 X182.73 Y114.782 E3.36524
; WIPE_START
M204 S10000
G1 X182.746 Y116.782 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.006 Y117.351 Z2.8 F30000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y115.567 E.05482
G1 X73.994 Y115.567 E3.31882
G1 X73.994 Y119.134 E.10963
G1 X88.724 Y119.135 E.45259
G1 X88.771 Y119.1 E.0018
G1 X88.976 Y118.447 E.02102
G1 X89.236 Y117.957 E.01705
G1 X89.544 Y117.556 E.01552
G1 X90.11 Y117.053 E.02328
G3 X94.255 Y117.35 I1.887 J2.745 E.13791
G1 X94.742 Y117.925 E.02315
G1 X95.101 Y118.641 E.02463
G1 X95.22 Y119.135 E.01558
G1 X106.724 Y119.134 E.35348
G1 X106.771 Y119.1 E.00179
G1 X106.976 Y118.447 E.02102
G1 X107.236 Y117.957 E.01705
G1 X107.543 Y117.556 E.01552
G1 X108.11 Y117.053 E.02328
G3 X112.255 Y117.35 I1.887 J2.745 E.13792
G1 X112.742 Y117.925 E.02314
G1 X113.101 Y118.641 E.02463
G1 X113.22 Y119.135 E.01558
G1 X124.724 Y119.134 E.35347
G1 X124.771 Y119.1 E.0018
G1 X124.976 Y118.447 E.02102
G1 X125.236 Y117.957 E.01705
G1 X125.543 Y117.556 E.01552
G1 X126.11 Y117.053 E.02328
G3 X130.255 Y117.35 I1.887 J2.745 E.13791
G1 X130.742 Y117.925 E.02315
G1 X131.101 Y118.641 E.02463
G1 X131.22 Y119.135 E.01558
G1 X142.724 Y119.134 E.35347
G1 X142.771 Y119.1 E.0018
G1 X142.976 Y118.447 E.02102
G1 X143.236 Y117.957 E.01705
G1 X143.543 Y117.556 E.01552
G1 X144.109 Y117.053 E.02328
G3 X148.255 Y117.35 I1.887 J2.744 E.13792
G1 X148.742 Y117.925 E.02315
G1 X149.101 Y118.641 E.02463
G1 X149.22 Y119.135 E.01558
G1 X160.724 Y119.134 E.35347
G1 X160.771 Y119.1 E.0018
G1 X160.976 Y118.447 E.02102
G1 X161.236 Y117.957 E.01705
G1 X161.544 Y117.556 E.01552
G1 X162.109 Y117.053 E.02327
G3 X166.255 Y117.35 I1.887 J2.745 E.13791
G1 X166.742 Y117.925 E.02315
G1 X167.101 Y118.641 E.02463
G1 X167.22 Y119.135 E.01558
G1 X182.006 Y119.134 E.45433
G1 X182.006 Y117.411 E.05297
G1 X181.629 Y117.351 F30000
G1 F12000
G1 X181.629 Y115.944 E.04323
G1 X165.134 Y115.944 E.50682
; LINE_WIDTH: 0.444832
G1 X165.022 Y115.968 E.00375
; LINE_WIDTH: 0.494514
G1 X164.91 Y115.993 E.00422
; LINE_WIDTH: 0.544197
G1 X164.799 Y116.018 E.00468
; LINE_WIDTH: 0.593879
G1 F11434.613
G1 X164.687 Y116.043 E.00515
G1 X164.809 Y116.1 E.00606
; LINE_WIDTH: 0.544197
G1 F12000
G1 X164.931 Y116.158 E.00551
; LINE_WIDTH: 0.494514
G1 X165.053 Y116.215 E.00496
; LINE_WIDTH: 0.420165
G2 X165.666 Y116.479 I3.578 J-7.467 E.02051
G3 X166.543 Y117.106 I-1.606 J3.173 E.03329
G1 X167.03 Y117.681 E.02316
G1 X167.44 Y118.475 E.02744
G1 X167.52 Y118.757 E.00904
G1 X181.629 Y118.757 E.43371
G1 X181.629 Y117.411 E.0414
G1 X181.252 Y117.351 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X181.252 Y116.321 E.03164
G1 X166.14 Y116.321 E.46432
G1 X166.702 Y116.737 E.02147
G1 X167.318 Y117.438 E.02867
G1 X167.804 Y118.38 E.03258
G1 X181.252 Y118.38 E.41321
G1 X181.252 Y117.411 E.0298
G1 X180.875 Y117.351 F30000
G1 F12000
G1 X180.875 Y116.698 E.02006
G1 X167.185 Y116.698 E.42063
G1 X167.605 Y117.194 E.01999
G3 X168.048 Y118.003 I-5.108 J3.32 E.02836
G1 X180.875 Y118.003 E.39412
G1 X180.875 Y117.411 E.01821
G1 X180.454 Y117.351 F30000
; LINE_WIDTH: 0.50714
G1 F12000
G1 X180.454 Y117.118 E.00878
G1 X168.055 Y117.118 E.46904
G1 X168.31 Y117.583 E.02003
G1 X180.454 Y117.583 E.4594
G1 X180.454 Y117.411 E.00651
G1 X163.359 Y116.038 F30000
; LINE_WIDTH: 0.59604
G1 F11389.934
G1 X163.665 Y116.025 E.01377
; LINE_WIDTH: 0.576169
G1 F11814.384
G3 X164.585 Y116.035 I.401 J5.787 E.04002
; LINE_WIDTH: 0.61025
G1 F11104.648
G1 X164.627 Y116.038 E.00196
G1 X149.44 Y118.475 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X149.03 Y117.681 E.02743
G1 X148.543 Y117.106 E.02315
G2 X147.666 Y116.479 I-2.484 J2.545 E.03327
; LINE_WIDTH: 0.444832
G1 X147.543 Y116.427 E.00436
; LINE_WIDTH: 0.494514
G1 X147.42 Y116.376 E.0049
; LINE_WIDTH: 0.544197
G1 X147.298 Y116.324 E.00544
; LINE_WIDTH: 0.593879
G1 F11434.613
G1 X147.175 Y116.272 E.00597
; LINE_WIDTH: 0.465635
G1 F12000
G1 X146.687 Y116.043 E.01859
G1 X147.134 Y115.944 E.01579
; LINE_WIDTH: 0.443632
G1 X151.068 Y115.944 E.12844
; LINE_WIDTH: 0.490914
G1 X155.001 Y115.944 E.1436
; LINE_WIDTH: 0.538197
G1 X158.935 Y115.944 E.15875
; LINE_WIDTH: 0.577479
G1 F11785.433
G1 X162.868 Y115.944 E.17134
G1 X163.359 Y116.038 E.02179
; LINE_WIDTH: 0.585479
G1 F11611.646
G1 X163.349 Y116.043 E.00051
; LINE_WIDTH: 0.538197
G1 F12000
G1 X163.339 Y116.048 E.00046
; LINE_WIDTH: 0.490914
G1 X163.328 Y116.053 E.00042
; LINE_WIDTH: 0.502535
G3 X162.827 Y116.271 I-3.566 J-7.494 E.02047
; LINE_WIDTH: 0.41999
G2 X161.859 Y116.771 I1.133 J3.385 E.03362
G1 X161.219 Y117.354 E.02659
G2 X160.552 Y118.552 I2.46 J2.155 E.04244
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.483 Y118.757 E.00667
G1 X149.52 Y118.757 E.33685
G1 X149.461 Y118.552 E.00658
; Slow Down End
G1 F12000
G1 X149.456 Y118.532 E.00062
G1 X149.804 Y118.38 F30000
G1 F12000
G1 X160.206 Y118.38 E.31964
G3 X160.919 Y117.125 I3.886 J1.378 E.04459
G1 X161.608 Y116.489 E.0288
G1 X161.86 Y116.321 E.0093
G1 X148.14 Y116.321 E.42154
G1 X148.702 Y116.737 E.02147
G1 X149.318 Y117.438 E.02867
G1 X149.783 Y118.324 E.03076
G1 X150.048 Y118.003 F30000
G1 F12000
G1 X159.941 Y118.003 E.30397
G1 X160.241 Y117.42 E.02015
G1 X160.62 Y116.896 E.01986
G1 X160.807 Y116.698 E.00838
G1 X149.185 Y116.698 E.35708
G1 X149.605 Y117.194 E.01999
G3 X150.021 Y117.949 I-4.766 J3.117 E.02652
G1 X150.31 Y117.583 F30000
; LINE_WIDTH: 0.50713
G1 F12000
G1 X159.675 Y117.583 E.35426
G1 X159.936 Y117.118 E.02015
G1 X150.055 Y117.118 E.37378
G1 X150.281 Y117.53 E.01776
G1 X145.359 Y116.038 F30000
; LINE_WIDTH: 0.59604
G1 F11389.934
G1 X145.665 Y116.025 E.01377
; LINE_WIDTH: 0.576169
G1 F11814.384
G3 X146.585 Y116.035 I.401 J5.787 E.04002
; LINE_WIDTH: 0.61025
G1 F11104.648
G1 X146.627 Y116.038 E.00196
G1 X131.44 Y118.475 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.03 Y117.681 E.02743
G1 X130.543 Y117.106 E.02315
G2 X129.666 Y116.479 I-2.484 J2.545 E.03327
; LINE_WIDTH: 0.444832
G1 X129.543 Y116.427 E.00436
; LINE_WIDTH: 0.494514
G1 X129.42 Y116.376 E.0049
; LINE_WIDTH: 0.544197
G1 X129.298 Y116.324 E.00544
; LINE_WIDTH: 0.593879
G1 F11434.613
G1 X129.175 Y116.272 E.00597
; LINE_WIDTH: 0.465635
G1 F12000
G1 X128.687 Y116.043 E.01859
G1 X129.134 Y115.944 E.01579
; LINE_WIDTH: 0.443632
G1 X133.068 Y115.944 E.12844
; LINE_WIDTH: 0.490914
G1 X137.001 Y115.944 E.1436
; LINE_WIDTH: 0.538197
G1 X140.935 Y115.944 E.15875
; LINE_WIDTH: 0.577479
G1 F11785.433
G1 X144.868 Y115.944 E.17134
G1 X145.359 Y116.038 E.02179
; LINE_WIDTH: 0.585479
G1 F11611.646
G1 X145.349 Y116.043 E.00051
; LINE_WIDTH: 0.538197
G1 F12000
G1 X145.339 Y116.048 E.00046
; LINE_WIDTH: 0.490914
G1 X145.328 Y116.053 E.00042
; LINE_WIDTH: 0.502535
G3 X144.827 Y116.271 I-3.566 J-7.494 E.02047
; LINE_WIDTH: 0.41999
G2 X143.859 Y116.771 I1.133 J3.385 E.03362
G1 X143.219 Y117.354 E.0266
G2 X142.552 Y118.552 I2.46 J2.155 E.04243
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.483 Y118.757 E.00667
G1 X131.52 Y118.757 E.33685
G1 X131.461 Y118.552 E.00658
; Slow Down End
G1 F12000
G1 X131.456 Y118.532 E.00062
G1 X131.804 Y118.38 F30000
G1 F12000
G1 X142.206 Y118.38 E.31964
G3 X142.919 Y117.125 I3.886 J1.378 E.04458
G1 X143.608 Y116.489 E.02881
G1 X143.86 Y116.321 E.0093
G1 X130.14 Y116.321 E.42154
G1 X130.702 Y116.737 E.02147
G1 X131.318 Y117.438 E.02867
G1 X131.783 Y118.324 E.03076
G1 X132.048 Y118.003 F30000
G1 F12000
G1 X141.941 Y118.003 E.30397
G1 X142.241 Y117.42 E.02015
G1 X142.619 Y116.897 E.01985
G1 X142.807 Y116.698 E.00839
G1 X131.185 Y116.698 E.35708
G1 X131.605 Y117.194 E.01999
G3 X132.021 Y117.949 I-4.766 J3.117 E.02652
G1 X132.31 Y117.583 F30000
; LINE_WIDTH: 0.507135
G1 F12000
G1 X141.675 Y117.583 E.35427
G1 X141.936 Y117.118 E.02015
G1 X132.055 Y117.118 E.37378
G1 X132.281 Y117.53 E.01776
G1 X127.359 Y116.038 F30000
; LINE_WIDTH: 0.59604
G1 F11389.934
G1 X127.665 Y116.025 E.01377
; LINE_WIDTH: 0.576169
G1 F11814.382
G3 X128.585 Y116.035 I.401 J5.787 E.04002
; LINE_WIDTH: 0.61025
G1 F11104.648
G1 X128.627 Y116.038 E.00196
G1 X113.52 Y118.757 F30000
; Slow Down Start
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.461 Y118.552 E.00658
; Slow Down End
G1 F12000
G1 X113.44 Y118.475 E.00246
G1 X113.03 Y117.681 E.02743
G1 X112.543 Y117.106 E.02314
G2 X111.666 Y116.479 I-2.484 J2.545 E.03327
; LINE_WIDTH: 0.444829
G1 X111.543 Y116.427 E.00436
; LINE_WIDTH: 0.494507
G1 X111.421 Y116.376 E.0049
; LINE_WIDTH: 0.544184
G1 X111.298 Y116.324 E.00544
; LINE_WIDTH: 0.593862
G1 F11434.976
G1 X111.175 Y116.272 E.00597
; LINE_WIDTH: 0.465633
G1 F12000
G1 X110.687 Y116.043 E.01859
G1 X111.134 Y115.944 E.0158
; LINE_WIDTH: 0.443632
G1 X115.068 Y115.944 E.12844
; LINE_WIDTH: 0.490914
G1 X119.001 Y115.944 E.14359
; LINE_WIDTH: 0.538197
G1 X122.935 Y115.944 E.15875
; LINE_WIDTH: 0.577478
G1 F11785.437
G1 X126.868 Y115.944 E.17134
G1 X127.359 Y116.038 E.02179
; LINE_WIDTH: 0.585479
G1 F11611.646
G1 X127.349 Y116.043 E.00051
; LINE_WIDTH: 0.538197
G1 F12000
G1 X127.339 Y116.048 E.00046
; LINE_WIDTH: 0.490914
G1 X127.328 Y116.053 E.00042
; LINE_WIDTH: 0.502534
G3 X126.827 Y116.271 I-3.602 J-7.578 E.02047
; LINE_WIDTH: 0.41999
G2 X125.859 Y116.771 I1.133 J3.385 E.03361
G1 X125.219 Y117.354 E.0266
G2 X124.552 Y118.552 I2.46 J2.155 E.04243
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.483 Y118.757 E.00667
; Slow Down End
G1 F12000
G1 X113.58 Y118.757 E.33501
G1 X113.804 Y118.38 F30000
G1 F12000
G1 X124.206 Y118.38 E.31964
G3 X124.919 Y117.125 I3.887 J1.379 E.04458
G1 X125.608 Y116.489 E.02882
G1 X125.86 Y116.321 E.0093
G1 X112.14 Y116.321 E.42154
G1 X112.702 Y116.737 E.02148
G1 X113.318 Y117.438 E.02867
G1 X113.783 Y118.324 E.03076
G1 X114.048 Y118.003 F30000
G1 F12000
G1 X123.941 Y118.003 E.30397
G1 X124.241 Y117.42 E.02016
G1 X124.62 Y116.897 E.01985
G1 X124.807 Y116.698 E.00839
G1 X113.185 Y116.698 E.35708
G1 X113.605 Y117.194 E.01999
G3 X114.021 Y117.949 I-4.769 J3.119 E.02652
G1 X114.31 Y117.583 F30000
; LINE_WIDTH: 0.507135
G1 F12000
G1 X123.675 Y117.583 E.35427
G1 X123.936 Y117.118 E.02015
G1 X114.055 Y117.118 E.37378
G1 X114.281 Y117.53 E.01776
G1 X109.359 Y116.038 F30000
; LINE_WIDTH: 0.59604
G1 F11389.934
G1 X109.665 Y116.025 E.01377
; LINE_WIDTH: 0.576169
G1 F11814.382
G3 X110.585 Y116.035 I.401 J5.787 E.04002
; LINE_WIDTH: 0.61024
G1 F11104.844
G1 X110.627 Y116.038 E.00196
G1 X95.44 Y118.475 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X95.03 Y117.681 E.02743
G1 X94.543 Y117.106 E.02315
G2 X93.666 Y116.479 I-2.483 J2.545 E.03327
; LINE_WIDTH: 0.444829
G1 X93.543 Y116.427 E.00436
; LINE_WIDTH: 0.494507
G1 X93.421 Y116.376 E.0049
; LINE_WIDTH: 0.544184
G1 X93.298 Y116.324 E.00543
; LINE_WIDTH: 0.593862
G1 F11434.976
G1 X93.175 Y116.272 E.00597
; LINE_WIDTH: 0.465633
G1 F12000
G1 X92.687 Y116.043 E.01859
G1 X93.134 Y115.944 E.0158
; LINE_WIDTH: 0.443632
G1 X97.068 Y115.944 E.12844
; LINE_WIDTH: 0.490914
G1 X101.001 Y115.944 E.14359
; LINE_WIDTH: 0.538197
G1 X104.935 Y115.944 E.15875
; LINE_WIDTH: 0.577478
G1 F11785.447
G1 X108.868 Y115.944 E.17134
G1 X109.359 Y116.038 E.02179
; LINE_WIDTH: 0.585479
G1 F11611.646
G1 X109.349 Y116.043 E.00051
; LINE_WIDTH: 0.538197
G1 F12000
G1 X109.339 Y116.048 E.00046
; LINE_WIDTH: 0.490914
G1 X109.328 Y116.053 E.00042
; LINE_WIDTH: 0.502523
G3 X108.827 Y116.271 I-3.561 J-7.483 E.02047
; LINE_WIDTH: 0.41999
G2 X107.859 Y116.771 I1.133 J3.384 E.03361
G1 X107.219 Y117.354 E.0266
G2 X106.552 Y118.552 I2.46 J2.155 E.04243
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.483 Y118.757 E.00667
G1 X95.52 Y118.757 E.33685
G1 X95.461 Y118.552 E.00658
; Slow Down End
G1 F12000
G1 X95.456 Y118.532 E.00062
G1 X95.804 Y118.38 F30000
G1 F12000
G1 X106.206 Y118.38 E.31964
G3 X106.919 Y117.125 I3.887 J1.379 E.04458
G1 X107.608 Y116.489 E.02882
G1 X107.86 Y116.321 E.0093
G1 X94.14 Y116.321 E.42154
G1 X94.702 Y116.737 E.02147
G1 X95.318 Y117.438 E.02867
G1 X95.783 Y118.324 E.03076
G1 X96.048 Y118.003 F30000
G1 F12000
G1 X105.941 Y118.003 E.30397
G1 X106.241 Y117.42 E.02016
G1 X106.62 Y116.897 E.01985
G1 X106.807 Y116.698 E.00839
G1 X95.185 Y116.698 E.35708
G1 X95.605 Y117.194 E.01999
G3 X96.021 Y117.949 I-4.764 J3.117 E.02652
G1 X96.31 Y117.583 F30000
; LINE_WIDTH: 0.507135
G1 F12000
G1 X105.675 Y117.583 E.35427
G1 X105.936 Y117.118 E.02015
G1 X96.055 Y117.118 E.37378
G1 X96.281 Y117.53 E.01776
G1 X91.359 Y116.038 F30000
; LINE_WIDTH: 0.59604
G1 F11389.934
G1 X91.665 Y116.025 E.01377
; LINE_WIDTH: 0.576169
G1 F11814.38
G3 X92.585 Y116.035 I.401 J5.787 E.04002
; LINE_WIDTH: 0.61024
G1 F11104.844
G1 X92.627 Y116.038 E.00196
G1 X74.371 Y118.552 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X74.371 Y115.944 E.08013
; LINE_WIDTH: 0.443632
G1 X78.495 Y115.944 E.13467
; LINE_WIDTH: 0.490914
G1 X82.62 Y115.944 E.15056
; LINE_WIDTH: 0.538197
G1 X86.744 Y115.944 E.16645
; LINE_WIDTH: 0.577809
G1 F11778.161
G1 X90.868 Y115.944 E.17976
G1 X91.359 Y116.038 E.0218
; LINE_WIDTH: 0.585479
G1 F11611.646
G1 X91.349 Y116.043 E.00051
; LINE_WIDTH: 0.538197
G1 F12000
G1 X91.339 Y116.048 E.00046
; LINE_WIDTH: 0.490914
G1 X91.328 Y116.053 E.00042
; LINE_WIDTH: 0.502534
G3 X90.827 Y116.271 I-3.603 J-7.579 E.02047
; LINE_WIDTH: 0.41999
G2 X89.859 Y116.771 I1.133 J3.384 E.03361
G1 X89.219 Y117.354 E.0266
G2 X88.552 Y118.552 I2.46 J2.155 E.04244
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.483 Y118.757 E.00667
G1 X74.371 Y118.757 E.43361
; Slow Down End
G1 F12000
G1 X74.371 Y118.612 E.00448
G1 X74.748 Y118.38 F30000
G1 F12000
G1 X88.206 Y118.38 E.41351
G3 X88.919 Y117.125 I3.887 J1.378 E.04459
G1 X89.608 Y116.489 E.02881
G1 X89.86 Y116.321 E.00929
G1 X74.748 Y116.321 E.46432
G1 X74.748 Y118.32 E.06144
G1 X75.125 Y118.003 F30000
G1 F12000
G1 X87.941 Y118.003 E.39377
G1 X88.241 Y117.42 E.02016
G1 X88.62 Y116.896 E.01986
G1 X88.807 Y116.698 E.00838
G1 X75.125 Y116.698 E.42038
G1 X75.125 Y117.943 E.03827
G1 X75.546 Y117.583 F30000
; LINE_WIDTH: 0.50714
G1 F12000
G1 X87.675 Y117.583 E.45881
G1 X87.936 Y117.118 E.02015
G1 X75.546 Y117.118 E.4687
G1 X75.546 Y117.523 E.01529
G1 X73.923 Y121.898 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.718 Y121.898 E.40991
G1 X88.935 Y122.315 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y122.315 E.55308
G1 X73.935 Y122.767 E.01668
G1 X88.765 Y122.767 E.54681
G1 X88.765 Y123.22 E.01668
G1 X73.766 Y123.22 E.55305
G1 X86.789 Y119.527 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.418 Y119.527 E.05401
G1 X86.367 Y121.577 E.09618
G1 X85.197 Y121.577 E.03882
G1 X83.147 Y119.527 E.09618
G1 X80.742 Y119.527 E.07978
G1 X78.691 Y121.577 E.09618
G1 X77.521 Y121.577 E.03882
G1 X75.471 Y119.527 E.09618
G1 X73.95 Y119.527 E.05044
G1 X73.95 Y119.634 E.00358
; WIPE_START
G1 X73.95 Y119.527 E-.04098
G1 X75.471 Y119.527 E-.57779
G1 X75.734 Y119.789 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X83.322 Y120.611 Z2.8 F30000
G1 X95.222 Y121.898 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.718 Y121.898 E.31849
G1 X106.595 Y121.577 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X106.751 Y121.577 E.00517
G1 X106.753 Y120.104 E.04884
G1 X106.175 Y119.527 E.02711
G1 X103.77 Y119.527 E.07978
G1 X101.719 Y121.577 E.09618
G1 X100.549 Y121.577 E.03882
G1 X98.499 Y119.527 E.09618
G1 X96.094 Y119.527 E.07978
G1 X95.248 Y120.373 E.03969
G1 X95.249 Y121.577 E.03995
G1 X95.673 Y121.577 E.01406
G1 X95.065 Y123.22 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X106.765 Y123.22 E.43139
G1 X106.765 Y122.767 E.01668
G1 X95.235 Y122.767 E.42516
G1 X95.234 Y122.315 E.01668
G1 X106.935 Y122.315 E.43144
; WIPE_START
G1 X104.935 Y122.315 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I-.135 J1.209 P1  F30000
G1 X113.065 Y123.22 Z2.8
G1 Z2.4
G1 E.8 F1800
G1 F3000
G1 X124.765 Y123.22 E.43139
G1 X124.765 Y122.767 E.01668
G1 X113.235 Y122.767 E.42516
G1 X113.234 Y122.315 E.01668
G1 X124.935 Y122.315 E.43144
G1 X121.949 Y121.577 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X123.577 Y121.577 E.05401
G1 X121.527 Y119.527 E.09618
G1 X119.122 Y119.527 E.07978
G1 X117.071 Y121.577 E.09618
G1 X115.901 Y121.577 E.03882
G1 X113.851 Y119.527 E.09618
G1 X113.24 Y119.527 E.02026
G3 X113.248 Y120.544 I-4.231 J.542 E.03382
G1 X113.222 Y121.898 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.718 Y121.898 E.31849
; WIPE_START
G1 X122.718 Y121.898 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I-.19 J1.202 P1  F30000
G1 X131.065 Y123.22 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X142.765 Y123.22 E.43139
G1 X142.765 Y122.767 E.01668
G1 X131.235 Y122.767 E.42516
G1 X131.234 Y122.315 E.01668
G1 X142.936 Y122.315 E.43144
G1 X142.752 Y120.544 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
M73 P45 R16
G1 F15476.087
G3 X142.76 Y119.527 I4.241 J-.476 E.03382
G1 X142.149 Y119.527 E.02026
G1 X140.099 Y121.577 E.09618
G1 X138.929 Y121.577 E.03882
G1 X136.878 Y119.527 E.09618
G1 X134.473 Y119.527 E.07978
G1 X132.423 Y121.577 E.09618
G1 X134.051 Y121.577 E.05401
G1 X131.222 Y121.898 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.718 Y121.898 E.31849
; WIPE_START
G1 X140.718 Y121.898 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I-.19 J1.202 P1  F30000
G1 X149.065 Y123.22 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X160.765 Y123.22 E.43139
G1 X160.765 Y122.767 E.01668
G1 X149.235 Y122.767 E.42516
G1 X149.234 Y122.315 E.01668
G1 X160.936 Y122.315 E.43144
G1 X160.327 Y121.577 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X160.751 Y121.577 E.01407
G1 X160.752 Y120.373 E.03995
G1 X159.906 Y119.527 E.03969
G1 X157.501 Y119.527 E.07978
G1 X155.451 Y121.577 E.09618
G1 X154.281 Y121.577 E.03882
G1 X152.23 Y119.527 E.09618
G1 X149.825 Y119.527 E.07978
G1 X149.247 Y120.104 E.02711
G1 X149.249 Y121.577 E.04884
G1 X149.405 Y121.577 E.00517
G1 X149.222 Y121.898 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.718 Y121.898 E.31849
; WIPE_START
G1 X158.718 Y121.898 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z2.8 I-.19 J1.202 P1  F30000
G1 X167.065 Y123.22 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X182.065 Y123.22 E.55305
G1 X182.065 Y122.767 E.01668
G1 X167.235 Y122.767 E.54681
G1 X167.234 Y122.315 E.01668
G1 X182.234 Y122.315 E.55308
G1 X182.05 Y119.634 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.05 Y119.527 E.00358
G1 X180.529 Y119.527 E.05044
G1 X178.479 Y121.577 E.09618
G1 X177.309 Y121.577 E.03882
G1 X175.258 Y119.527 E.09618
G1 X172.853 Y119.527 E.07978
G1 X170.803 Y121.577 E.09618
G1 X169.633 Y121.577 E.03882
G1 X167.582 Y119.527 E.09618
G1 X169.211 Y119.527 E.05401
G1 X167.222 Y121.898 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y121.898 E.40989
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X180.017 Y121.898 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/33
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z2.8 I-.164 J-1.206 P1  F30000
G1 X73.21 Y136.42 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
M204 S5000
G1 X182.79 Y136.42 E3.63497
G1 X182.79 Y137.134 E.02371
G1 X73.21 Y137.134 E3.63497
G1 X73.21 Y136.48 E.02172
M204 S10000
G1 X73.406 Y136.777 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.36562
G1 F15000
G1 X182.594 Y136.777 E2.8712
; WIPE_START
G1 X180.594 Y136.777 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3 I.422 J-1.141 P1  F30000
G1 X127.109 Y116.988 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X125.098 Y119.738 I.913 J2.778 E.12065
G1 X125.098 Y122.81 E.10191
G1 X125.098 Y123.21 E.01327
G1 F14655.771
G1 X125.098 Y123.61 E.01327
G1 F6907.886
G1 X125.098 Y124.01 E.01327
G1 F2040
G1 X125.098 Y124.362 E.01167
G1 F600
G1 X112.902 Y124.362 E.40456
G1 F2040
G1 X112.902 Y124.01 E.01167
G1 F6907.886
G1 X112.902 Y123.61 E.01327
G1 F14655.771
G1 X112.902 Y123.21 E.01327
G1 F15476.087
G1 X112.902 Y122.81 E.01327
G1 X112.902 Y119.739 E.10189
G2 X110.891 Y116.988 I-2.928 J.03 E.12063
G1 X110.926 Y116.785 E.00684
G1 X127.074 Y116.785 E.53567
G1 X127.099 Y116.929 E.00484
; WIPE_START
G1 X126.674 Y117.169 E-.18553
G1 X126.233 Y117.448 E-.19823
G1 X125.925 Y117.721 E-.15632
G1 X125.621 Y118.089 E-.18142
G1 X125.57 Y118.176 E-.03851
; WIPE_END
G1 E-.04 F1800
G1 X133.189 Y117.713 Z3 F30000
G1 X145.109 Y116.988 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G2 X143.098 Y119.738 I.913 J2.778 E.12065
G1 X143.098 Y122.81 E.10191
G1 X143.098 Y123.21 E.01327
G1 F14655.771
G1 X143.098 Y123.61 E.01327
G1 F6907.886
G1 X143.098 Y124.01 E.01327
G1 F2040
G1 X143.098 Y124.362 E.01167
G1 F600
G1 X130.902 Y124.362 E.40456
G1 F2040
G1 X130.902 Y124.01 E.01167
G1 F6907.886
G1 X130.902 Y123.61 E.01327
G1 F14655.771
G1 X130.902 Y123.21 E.01327
G1 F15476.087
G1 X130.902 Y122.81 E.01327
G1 X130.902 Y119.739 E.10189
G2 X128.891 Y116.988 I-2.928 J.03 E.12063
M73 P45 R15
G1 X128.926 Y116.785 E.00684
G1 X145.074 Y116.785 E.53567
G1 X145.099 Y116.929 E.00484
; WIPE_START
G1 X144.674 Y117.169 E-.18549
G1 X144.233 Y117.448 E-.19826
G1 X143.925 Y117.721 E-.15631
G1 X143.621 Y118.089 E-.18152
G1 X143.57 Y118.176 E-.03842
; WIPE_END
G1 E-.04 F1800
G1 X151.189 Y117.713 Z3 F30000
G1 X163.109 Y116.988 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G2 X161.098 Y119.738 I.913 J2.778 E.12065
G1 X161.098 Y122.81 E.10191
G1 X161.098 Y123.21 E.01327
G1 F14655.771
G1 X161.098 Y123.61 E.01327
G1 F6907.886
G1 X161.098 Y124.01 E.01327
G1 F2040
G1 X161.098 Y124.362 E.01167
G1 F600
G1 X148.902 Y124.362 E.40456
G1 F2040
G1 X148.902 Y124.01 E.01167
G1 F6907.886
M73 P46 R15
G1 X148.902 Y123.61 E.01327
G1 F14655.771
G1 X148.902 Y123.21 E.01327
G1 F15476.087
G1 X148.902 Y122.81 E.01327
G1 X148.902 Y119.739 E.10189
G2 X146.891 Y116.988 I-2.928 J.03 E.12063
G1 X146.926 Y116.785 E.00684
G1 X163.074 Y116.785 E.53567
G1 X163.099 Y116.929 E.00484
; WIPE_START
G1 X162.674 Y117.169 E-.18554
G1 X162.233 Y117.448 E-.19823
G1 X161.925 Y117.721 E-.15631
G1 X161.621 Y118.089 E-.18153
G1 X161.57 Y118.176 E-.0384
; WIPE_END
G1 E-.04 F1800
G1 X169.186 Y117.668 Z3 F30000
G1 X182.398 Y116.785 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G1 X182.398 Y122.81 E.19988
G1 X182.398 Y123.21 E.01327
G1 F14655.771
G1 X182.398 Y123.61 E.01327
G1 F6907.886
G1 X182.398 Y124.01 E.01327
G1 F2040
G1 X182.398 Y124.362 E.01167
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F600
G1 X166.902 Y124.362 E.51403
G1 F2040
G1 X166.902 Y124.01 E.01167
G1 F6907.886
G1 X166.902 Y123.61 E.01327
G1 F14655.771
G1 X166.902 Y123.21 E.01327
G1 F15476.087
G1 X166.902 Y122.81 E.01327
G1 X166.902 Y119.739 E.10189
G2 X164.891 Y116.988 I-2.928 J.03 E.12063
G1 X164.926 Y116.785 E.00684
G1 X182.338 Y116.785 E.57759
; WIPE_START
G1 X182.358 Y118.785 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X174.728 Y118.597 Z3 F30000
G1 X109.109 Y116.988 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G2 X107.098 Y119.738 I.913 J2.778 E.12065
G1 X107.098 Y122.81 E.10191
G1 X107.098 Y123.21 E.01327
G1 F14655.771
G1 X107.098 Y123.61 E.01327
G1 F6907.886
G1 X107.098 Y124.01 E.01327
G1 F2040
G1 X107.098 Y124.362 E.01167
G1 F600
G1 X94.902 Y124.362 E.40456
G1 F2040
G1 X94.902 Y124.01 E.01167
G1 F6907.886
G1 X94.902 Y123.61 E.01327
G1 F14655.771
G1 X94.902 Y123.21 E.01327
G1 F15476.087
G1 X94.902 Y122.81 E.01327
G1 X94.902 Y119.739 E.10189
G2 X92.891 Y116.988 I-2.928 J.03 E.12063
G1 X92.926 Y116.785 E.00684
G1 X109.074 Y116.785 E.53567
G1 X109.099 Y116.929 E.00484
; WIPE_START
G1 X108.674 Y117.169 E-.18549
G1 X108.233 Y117.448 E-.19826
G1 X107.925 Y117.721 E-.15632
G1 X107.621 Y118.089 E-.18141
G1 X107.57 Y118.176 E-.03852
; WIPE_END
G1 E-.04 F1800
G1 X99.958 Y117.627 Z3 F30000
G1 X91.109 Y116.988 Z3
G1 Z2.6
G1 E.8 F1800
G1 F15476.087
G2 X89.098 Y119.738 I.913 J2.778 E.12065
G1 X89.098 Y122.81 E.10191
G1 X89.098 Y123.21 E.01327
G1 F14655.771
G1 X89.098 Y123.61 E.01327
G1 F6907.886
G1 X89.098 Y124.01 E.01327
G1 F2040
G1 X89.098 Y124.362 E.01167
M73 P47 R15
G1 F600
G1 X73.602 Y124.362 E.51403
G1 F2040
G1 X73.602 Y124.01 E.01167
G1 F6907.886
G1 X73.602 Y123.61 E.01327
G1 F14655.771
G1 X73.602 Y123.21 E.01327
G1 F15476.087
G1 X73.602 Y122.81 E.01327
G1 X73.602 Y116.785 E.19988
G1 X77.55 Y116.785 E.13097
G1 X91.074 Y116.785 E.44861
G1 X91.099 Y116.929 E.00484
; WIPE_START
G1 X90.674 Y117.169 E-.18553
G1 X90.233 Y117.448 E-.19823
G1 X89.925 Y117.721 E-.15631
G1 X89.621 Y118.089 E-.18153
G1 X89.57 Y118.176 E-.03841
; WIPE_END
G1 E-.04 F1800
G1 X97.199 Y117.929 Z3 F30000
G1 X182.79 Y115.148 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y123.224 E.24815
G1 X182.79 Y123.624 E.01229
G1 F6459.938
G1 X182.79 Y124.024 E.01229
G1 F1800
G1 X182.79 Y124.393 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y124.754 E.01199
G1 F600
G1 X166.51 Y124.754 E.54004
G1 X166.51 Y124.393 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y124.024 E.01134
G1 F6459.938
G1 X166.51 Y123.624 E.01229
G1 F12000
G1 X166.51 Y123.224 E.01229
G1 X166.51 Y119.746 E.10686
G2 X161.49 Y119.746 I-2.51 J.01 E.24166
G1 X161.49 Y123.224 E.10686
G1 X161.49 Y123.624 E.01229
G1 F6459.938
G1 X161.49 Y124.024 E.01229
G1 F1800
G1 X161.49 Y124.393 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y124.754 E.01199
G1 X148.51 Y124.754 E.43057
G1 X148.51 Y124.393 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y124.024 E.01134
G1 F6459.938
G1 X148.51 Y123.624 E.01229
G1 F12000
G1 X148.51 Y123.224 E.01229
G1 X148.51 Y119.746 E.10686
G2 X143.49 Y119.746 I-2.51 J.01 E.24166
G1 X143.49 Y123.224 E.10686
G1 X143.49 Y123.624 E.01229
G1 F6459.938
G1 X143.49 Y124.024 E.01229
G1 F1800
G1 X143.49 Y124.393 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y124.754 E.01199
G1 X130.51 Y124.754 E.43057
G1 X130.51 Y124.393 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y124.024 E.01134
G1 F6459.938
G1 X130.51 Y123.624 E.01229
G1 F12000
G1 X130.51 Y123.224 E.01229
G1 X130.51 Y119.746 E.10686
G2 X125.49 Y119.746 I-2.51 J.01 E.24166
G1 X125.49 Y123.224 E.10686
G1 X125.49 Y123.624 E.01229
G1 F6459.938
G1 X125.49 Y124.024 E.01229
G1 F1800
G1 X125.49 Y124.393 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y124.754 E.01199
G1 X112.51 Y124.754 E.43057
G1 X112.51 Y124.393 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y124.024 E.01134
G1 F6459.938
G1 X112.51 Y123.624 E.01229
G1 F12000
G1 X112.51 Y123.224 E.01229
G1 X112.51 Y119.746 E.10686
G2 X107.49 Y119.746 I-2.51 J.01 E.24166
G1 X107.49 Y123.224 E.10686
G1 X107.49 Y123.624 E.01229
G1 F6459.938
G1 X107.49 Y124.024 E.01229
G1 F1800
G1 X107.49 Y124.393 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y124.754 E.01199
G1 X94.51 Y124.754 E.43057
G1 X94.51 Y124.393 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y124.024 E.01134
G1 F6459.938
G1 X94.51 Y123.624 E.01229
G1 F12000
G1 X94.51 Y123.224 E.01229
G1 X94.51 Y119.746 E.10686
G2 X89.49 Y119.746 I-2.51 J.01 E.24166
G1 X89.49 Y123.224 E.10686
G1 X89.49 Y123.624 E.01229
G1 F6459.938
G1 X89.49 Y124.024 E.01229
G1 F1800
G1 X89.49 Y124.393 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y124.754 E.01199
G1 X73.21 Y124.754 E.54004
G1 X73.21 Y124.393 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y124.024 E.01134
G1 F6459.938
G1 X73.21 Y123.624 E.01229
G1 F12000
G1 X73.21 Y123.224 E.01229
G1 X73.21 Y115.148 E.24815
G1 X182.73 Y115.148 E3.36524
M204 S10000
G1 X182.583 Y115.792 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.146 Y115.355 E.01897
G1 X181.613 Y115.355
G1 X182.583 Y116.325 E.04215
G1 X182.286 Y116.562
G1 X181.08 Y115.355 E.05245
G1 X180.546 Y115.355
G1 X181.753 Y116.562 E.05245
G1 X181.22 Y116.562
G1 X180.013 Y115.355 E.05245
G1 X179.48 Y115.355
G1 X180.687 Y116.562 E.05245
G1 X180.153 Y116.562
G1 X178.946 Y115.355 E.05245
G1 X178.413 Y115.355
G1 X179.62 Y116.562 E.05245
G1 X179.087 Y116.562
G1 X177.88 Y115.355 E.05245
G1 X177.347 Y115.355
G1 X178.554 Y116.562 E.05245
G1 X178.02 Y116.562
G1 X176.813 Y115.355 E.05245
G1 X176.28 Y115.355
G1 X177.487 Y116.562 E.05245
G1 X176.954 Y116.562
G1 X175.747 Y115.355 E.05245
G1 X175.214 Y115.355
G1 X176.421 Y116.562 E.05245
G1 X175.887 Y116.562
G1 X174.68 Y115.355 E.05245
G1 X174.147 Y115.355
G1 X175.354 Y116.562 E.05245
G1 X174.821 Y116.562
G1 X173.614 Y115.355 E.05245
G1 X173.081 Y115.355
G1 X174.288 Y116.562 E.05245
G1 X173.754 Y116.562
G1 X172.547 Y115.355 E.05245
G1 X172.014 Y115.355
G1 X173.221 Y116.562 E.05245
G1 X172.688 Y116.562
G1 X171.481 Y115.355 E.05245
G1 X170.948 Y115.355
G1 X172.155 Y116.562 E.05245
G1 X171.621 Y116.562
G1 X170.414 Y115.355 E.05245
G1 X169.881 Y115.355
G1 X171.088 Y116.562 E.05245
G1 X170.555 Y116.562
G1 X169.348 Y115.355 E.05245
G1 X168.815 Y115.355
G1 X170.022 Y116.562 E.05245
G1 X169.488 Y116.562
G1 X168.281 Y115.355 E.05245
G1 X167.748 Y115.355
G1 X168.955 Y116.562 E.05245
G1 X168.422 Y116.562
G1 X167.215 Y115.355 E.05245
G1 X166.682 Y115.355
G1 X167.888 Y116.562 E.05245
G1 X167.355 Y116.562
G1 X166.148 Y115.355 E.05245
G1 X165.615 Y115.355
G1 X166.822 Y116.562 E.05245
G1 X166.289 Y116.562
G1 X165.082 Y115.355 E.05245
G1 X164.549 Y115.355
G1 X165.755 Y116.562 E.05245
G1 X165.222 Y116.562
G1 X164.015 Y115.355 E.05245
G1 X163.482 Y115.355
G1 X164.689 Y116.562 E.05245
G1 X164.156 Y116.562
G1 X162.949 Y115.355 E.05245
G1 X162.415 Y115.355
G1 X163.622 Y116.562 E.05245
G1 X163.089 Y116.562
G1 X161.882 Y115.355 E.05245
G1 X161.349 Y115.355
G1 X162.556 Y116.562 E.05245
G1 X162.023 Y116.562
G1 X160.816 Y115.355 E.05245
G1 X160.282 Y115.355
G1 X161.489 Y116.562 E.05245
G1 X160.956 Y116.562
G1 X159.749 Y115.355 E.05245
G1 X159.216 Y115.355
G1 X160.423 Y116.562 E.05245
G1 X159.89 Y116.562
G1 X158.683 Y115.355 E.05245
G1 X158.149 Y115.355
G1 X159.356 Y116.562 E.05245
G1 X158.823 Y116.562
G1 X157.616 Y115.355 E.05245
G1 X157.083 Y115.355
G1 X158.29 Y116.562 E.05245
G1 X157.757 Y116.562
G1 X156.55 Y115.355 E.05245
G1 X156.016 Y115.355
M73 P48 R15
G1 X157.223 Y116.562 E.05245
G1 X156.69 Y116.562
G1 X155.483 Y115.355 E.05245
G1 X154.95 Y115.355
G1 X156.157 Y116.562 E.05245
G1 X155.624 Y116.562
G1 X154.417 Y115.355 E.05245
G1 X153.883 Y115.355
G1 X155.09 Y116.562 E.05245
G1 X154.557 Y116.562
G1 X153.35 Y115.355 E.05245
G1 X152.817 Y115.355
G1 X154.024 Y116.562 E.05245
G1 X153.491 Y116.562
G1 X152.284 Y115.355 E.05245
G1 X151.75 Y115.355
G1 X152.957 Y116.562 E.05245
G1 X152.424 Y116.562
G1 X151.217 Y115.355 E.05245
G1 X150.684 Y115.355
G1 X151.891 Y116.562 E.05245
G1 X151.357 Y116.562
G1 X150.151 Y115.355 E.05245
G1 X149.617 Y115.355
G1 X150.824 Y116.562 E.05245
G1 X150.291 Y116.562
G1 X149.084 Y115.355 E.05245
G1 X148.551 Y115.355
G1 X149.758 Y116.562 E.05245
G1 X149.224 Y116.562
G1 X148.018 Y115.355 E.05245
G1 X147.484 Y115.355
G1 X148.691 Y116.562 E.05245
G1 X148.158 Y116.562
G1 X146.951 Y115.355 E.05245
G1 X146.418 Y115.355
G1 X147.625 Y116.562 E.05245
G1 X147.091 Y116.562
G1 X145.885 Y115.355 E.05245
G1 X145.351 Y115.355
G1 X146.558 Y116.562 E.05245
G1 X146.025 Y116.562
G1 X144.818 Y115.355 E.05245
G1 X144.285 Y115.355
G1 X145.492 Y116.562 E.05245
G1 X144.958 Y116.562
G1 X143.751 Y115.355 E.05245
G1 X143.218 Y115.355
G1 X144.425 Y116.562 E.05245
G1 X143.892 Y116.562
G1 X142.685 Y115.355 E.05245
G1 X142.152 Y115.355
G1 X143.359 Y116.562 E.05245
G1 X142.825 Y116.562
G1 X141.618 Y115.355 E.05245
G1 X141.085 Y115.355
G1 X142.292 Y116.562 E.05245
G1 X141.759 Y116.562
G1 X140.552 Y115.355 E.05245
G1 X140.019 Y115.355
G1 X141.226 Y116.562 E.05245
G1 X140.692 Y116.562
G1 X139.485 Y115.355 E.05245
G1 X138.952 Y115.355
G1 X140.159 Y116.562 E.05245
G1 X139.626 Y116.562
G1 X138.419 Y115.355 E.05245
G1 X137.886 Y115.355
G1 X139.093 Y116.562 E.05245
G1 X138.559 Y116.562
G1 X137.352 Y115.355 E.05245
G1 X136.819 Y115.355
G1 X138.026 Y116.562 E.05245
G1 X137.493 Y116.562
G1 X136.286 Y115.355 E.05245
G1 X135.753 Y115.355
G1 X136.96 Y116.562 E.05245
G1 X136.426 Y116.562
G1 X135.219 Y115.355 E.05245
G1 X134.686 Y115.355
G1 X135.893 Y116.562 E.05245
G1 X135.36 Y116.562
G1 X134.153 Y115.355 E.05245
G1 X133.62 Y115.355
G1 X134.827 Y116.562 E.05245
G1 X134.293 Y116.562
G1 X133.086 Y115.355 E.05245
G1 X132.553 Y115.355
G1 X133.76 Y116.562 E.05245
G1 X133.227 Y116.562
G1 X132.02 Y115.355 E.05245
G1 X131.487 Y115.355
G1 X132.693 Y116.562 E.05245
G1 X132.16 Y116.562
G1 X130.953 Y115.355 E.05245
G1 X130.42 Y115.355
G1 X131.627 Y116.562 E.05245
G1 X131.094 Y116.562
G1 X129.887 Y115.355 E.05245
G1 X129.354 Y115.355
G1 X130.56 Y116.562 E.05245
G1 X130.027 Y116.562
G1 X128.82 Y115.355 E.05245
G1 X128.287 Y115.355
G1 X129.494 Y116.562 E.05245
G1 X128.961 Y116.562
G1 X127.754 Y115.355 E.05245
G1 X127.22 Y115.355
G1 X128.427 Y116.562 E.05245
G1 X127.894 Y116.562
G1 X126.687 Y115.355 E.05245
G1 X126.154 Y115.355
G1 X127.361 Y116.562 E.05245
G1 X126.828 Y116.562
G1 X125.621 Y115.355 E.05245
G1 X125.087 Y115.355
G1 X126.294 Y116.562 E.05245
G1 X125.761 Y116.562
G1 X124.554 Y115.355 E.05245
G1 X124.021 Y115.355
G1 X125.228 Y116.562 E.05245
G1 X124.695 Y116.562
G1 X123.488 Y115.355 E.05245
G1 X122.954 Y115.355
G1 X124.161 Y116.562 E.05245
G1 X123.628 Y116.562
G1 X122.421 Y115.355 E.05245
G1 X121.888 Y115.355
G1 X123.095 Y116.562 E.05245
G1 X122.562 Y116.562
G1 X121.355 Y115.355 E.05245
G1 X120.821 Y115.355
G1 X122.028 Y116.562 E.05245
G1 X121.495 Y116.562
G1 X120.288 Y115.355 E.05245
G1 X119.755 Y115.355
G1 X120.962 Y116.562 E.05245
G1 X120.429 Y116.562
G1 X119.222 Y115.355 E.05245
G1 X118.688 Y115.355
G1 X119.895 Y116.562 E.05245
G1 X119.362 Y116.562
G1 X118.155 Y115.355 E.05245
G1 X117.622 Y115.355
G1 X118.829 Y116.562 E.05245
G1 X118.296 Y116.562
G1 X117.089 Y115.355 E.05245
G1 X116.555 Y115.355
G1 X117.762 Y116.562 E.05245
G1 X117.229 Y116.562
G1 X116.022 Y115.355 E.05245
G1 X115.489 Y115.355
G1 X116.696 Y116.562 E.05245
G1 X116.163 Y116.562
G1 X114.956 Y115.355 E.05245
G1 X114.422 Y115.355
G1 X115.629 Y116.562 E.05245
G1 X115.096 Y116.562
G1 X113.889 Y115.355 E.05245
G1 X113.356 Y115.355
G1 X114.563 Y116.562 E.05245
G1 X114.029 Y116.562
G1 X112.823 Y115.355 E.05245
G1 X112.289 Y115.355
G1 X113.496 Y116.562 E.05245
G1 X112.963 Y116.562
G1 X111.756 Y115.355 E.05245
G1 X111.223 Y115.355
G1 X112.43 Y116.562 E.05245
G1 X111.896 Y116.562
G1 X110.69 Y115.355 E.05245
G1 X110.156 Y115.355
G1 X111.363 Y116.562 E.05245
G1 X110.83 Y116.562
G1 X109.623 Y115.355 E.05245
G1 X109.09 Y115.355
G1 X110.297 Y116.562 E.05245
G1 X109.763 Y116.562
G1 X108.556 Y115.355 E.05245
G1 X108.023 Y115.355
G1 X109.23 Y116.562 E.05245
G1 X108.697 Y116.562
G1 X107.49 Y115.355 E.05245
G1 X106.957 Y115.355
G1 X108.164 Y116.562 E.05245
G1 X107.63 Y116.562
G1 X106.423 Y115.355 E.05245
G1 X105.89 Y115.355
G1 X107.097 Y116.562 E.05245
G1 X106.564 Y116.562
G1 X105.357 Y115.355 E.05245
G1 X104.824 Y115.355
G1 X106.031 Y116.562 E.05245
G1 X105.497 Y116.562
G1 X104.29 Y115.355 E.05245
G1 X103.757 Y115.355
G1 X104.964 Y116.562 E.05245
G1 X104.431 Y116.562
G1 X103.224 Y115.355 E.05245
G1 X102.691 Y115.355
G1 X103.898 Y116.562 E.05245
G1 X103.364 Y116.562
G1 X102.157 Y115.355 E.05245
G1 X101.624 Y115.355
G1 X102.831 Y116.562 E.05245
G1 X102.298 Y116.562
G1 X101.091 Y115.355 E.05245
G1 X100.558 Y115.355
G1 X101.765 Y116.562 E.05245
G1 X101.231 Y116.562
G1 X100.024 Y115.355 E.05245
G1 X99.491 Y115.355
G1 X100.698 Y116.562 E.05245
G1 X100.165 Y116.562
G1 X98.958 Y115.355 E.05245
G1 X98.425 Y115.355
G1 X99.632 Y116.562 E.05245
G1 X99.098 Y116.562
G1 X97.891 Y115.355 E.05245
G1 X97.358 Y115.355
G1 X98.565 Y116.562 E.05245
G1 X98.032 Y116.562
G1 X96.825 Y115.355 E.05245
G1 X96.292 Y115.355
G1 X97.498 Y116.562 E.05245
G1 X96.965 Y116.562
G1 X95.758 Y115.355 E.05245
G1 X95.225 Y115.355
G1 X96.432 Y116.562 E.05245
G1 X95.899 Y116.562
G1 X94.692 Y115.355 E.05245
G1 X94.159 Y115.355
G1 X95.365 Y116.562 E.05245
G1 X94.832 Y116.562
G1 X93.625 Y115.355 E.05245
G1 X93.092 Y115.355
G1 X94.299 Y116.562 E.05245
G1 X93.766 Y116.562
G1 X92.559 Y115.355 E.05245
G1 X92.025 Y115.355
G1 X93.232 Y116.562 E.05245
G1 X92.699 Y116.562
G1 X91.492 Y115.355 E.05245
G1 X90.959 Y115.355
G1 X92.166 Y116.562 E.05245
G1 X91.633 Y116.562
G1 X90.426 Y115.355 E.05245
G1 X89.892 Y115.355
G1 X91.099 Y116.562 E.05245
G1 X90.566 Y116.562
G1 X89.359 Y115.355 E.05245
G1 X88.826 Y115.355
G1 X90.033 Y116.562 E.05245
G1 X89.5 Y116.562
G1 X88.293 Y115.355 E.05245
G1 X87.759 Y115.355
G1 X88.966 Y116.562 E.05245
G1 X88.433 Y116.562
G1 X87.226 Y115.355 E.05245
G1 X86.693 Y115.355
G1 X87.9 Y116.562 E.05245
G1 X87.367 Y116.562
G1 X86.16 Y115.355 E.05245
G1 X85.626 Y115.355
G1 X86.833 Y116.562 E.05245
G1 X86.3 Y116.562
G1 X85.093 Y115.355 E.05245
G1 X84.56 Y115.355
G1 X85.767 Y116.562 E.05245
G1 X85.234 Y116.562
G1 X84.027 Y115.355 E.05245
G1 X83.493 Y115.355
G1 X84.7 Y116.562 E.05245
G1 X84.167 Y116.562
G1 X82.96 Y115.355 E.05245
G1 X82.427 Y115.355
G1 X83.634 Y116.562 E.05245
G1 X83.101 Y116.562
G1 X81.894 Y115.355 E.05245
G1 X81.36 Y115.355
G1 X82.567 Y116.562 E.05245
G1 X82.034 Y116.562
G1 X80.827 Y115.355 E.05245
G1 X80.294 Y115.355
G1 X81.501 Y116.562 E.05245
G1 X80.968 Y116.562
G1 X79.761 Y115.355 E.05245
G1 X79.227 Y115.355
G1 X80.434 Y116.562 E.05245
G1 X79.901 Y116.562
G1 X78.694 Y115.355 E.05245
G1 X78.161 Y115.355
G1 X79.368 Y116.562 E.05245
G1 X78.834 Y116.562
G1 X77.628 Y115.355 E.05245
G1 X77.094 Y115.355
G1 X78.301 Y116.562 E.05245
G1 X77.768 Y116.562
G1 X76.561 Y115.355 E.05245
G1 X76.028 Y115.355
G1 X77.235 Y116.562 E.05245
G1 X76.701 Y116.562
G1 X75.495 Y115.355 E.05245
G1 X74.961 Y115.355
G1 X76.168 Y116.562 E.05245
G1 X75.635 Y116.562
G1 X74.428 Y115.355 E.05245
G1 X73.895 Y115.355
G1 X75.102 Y116.562 E.05245
G1 X74.568 Y116.562
G1 X73.417 Y115.411 E.05002
G1 X73.417 Y115.944
G1 X74.035 Y116.562 E.02685
; WIPE_START
M204 S10000
G1 X73.417 Y115.944 E-.33199
G1 X73.417 Y115.411 E-.20264
G1 X73.837 Y115.831 E-.22537
; WIPE_END
G1 E-.04 F1800
G1 X73.994 Y119.323 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X73.994 Y117.177 E.06595
G1 X89.315 Y117.177 E.47074
G1 X89.861 Y117.199 E.01682
G1 X89.895 Y117.242 E.00169
G1 X89.521 Y117.581 E.01553
G1 X89.151 Y118.098 E.01953
G1 X88.85 Y118.789 E.02314
G1 X88.736 Y119.323 E.01679
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.713 Y119.906 E.01792
G1 X73.994 Y119.906 E.45226
; Slow Down End
G1 F12000
G1 X73.994 Y119.383 E.01607
G1 X89.075 Y117.554 F30000
G1 F12000
G1 X88.805 Y117.948 E.01466
G1 X88.504 Y118.638 E.02314
G1 X88.373 Y119.182 E.01721
G1 X88.364 Y119.323 E.00433
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.351 Y119.529 E.00634
G1 X74.371 Y119.529 E.42954
G1 X74.371 Y119.323 E.00632
; Slow Down End
G1 F12000
G1 X74.371 Y117.554 E.05436
G1 X89.015 Y117.554 E.44994
G1 X88.401 Y117.931 F30000
G1 F12000
G1 X74.748 Y117.931 E.4195
G1 X74.748 Y119.152 E.03751
G1 X87.998 Y119.152 E.40713
G1 X88.102 Y118.661 E.0154
G1 X88.378 Y117.986 E.02241
G1 X87.791 Y118.33 F30000
; LINE_WIDTH: 0.464815
G1 F12000
G1 X75.148 Y118.33 E.43467
G1 X75.148 Y118.752 E.0145
G1 X87.673 Y118.752 E.4306
G1 X87.775 Y118.388 E.013
G1 X90.3 Y117.122 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.110202
G1 F15000
G1 X90.479 Y116.988 E.00122
G1 X91.331 Y117.12 F30000
; LINE_WIDTH: 0.467307
G1 F14844.966
G1 X91.509 Y116.867 E.0107
; LINE_WIDTH: 0.493616
G1 F13978.4
G1 X91.52 Y116.851 E.00072
; LINE_WIDTH: 0.521848
G1 F13154.399
G1 X91.532 Y116.835 E.00077
; LINE_WIDTH: 0.511664
G1 F13440.17
G1 X92.037 Y116.817 E.01931
G1 X92.468 Y116.835 E.01648
G1 X92.479 Y116.85 E.00071
; LINE_WIDTH: 0.495967
G1 F13905.865
G1 X92.49 Y116.865 E.00069
; LINE_WIDTH: 0.468186
G1 F14814.253
G1 X92.67 Y117.121 E.01083
G1 X93.528 Y116.988 F30000
; LINE_WIDTH: 0.112883
G1 F15000
G1 X93.724 Y117.138 E.00141
G1 X95.263 Y119.297 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X95.151 Y118.789 E.01598
G1 X94.825 Y118.057 E.02464
G1 X94.369 Y117.462 E.02302
G1 X94.128 Y117.244 E.00998
G1 X94.175 Y117.177 E.00252
G1 X107.237 Y117.177 E.40133
G1 X107.861 Y117.198 E.01917
G1 X107.892 Y117.237 E.00154
G2 X107.412 Y117.713 I26.081 J26.773 E.02076
G1 X107.018 Y118.351 E.02303
G2 X106.736 Y119.323 I4.005 J1.69 E.03117
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.713 Y119.906 E.01792
G1 X95.287 Y119.906 E.35109
G1 X95.265 Y119.357 E.01687
; Slow Down End
G1 X95.627 Y119.183 F30000
G1 F12000
G1 X95.496 Y118.639 E.01721
M73 P48 R14
G1 X95.193 Y117.945 E.02325
G1 X94.914 Y117.554 E.01476
G1 X107.067 Y117.554 E.37341
G1 X106.697 Y118.153 E.02163
G2 X106.364 Y119.323 I3.481 J1.624 E.03754
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.351 Y119.529 E.00634
G1 X95.649 Y119.529 E.32881
G1 X95.636 Y119.323 E.00634
; Slow Down End
G1 F12000
G1 X95.631 Y119.243 E.00246
G1 X96.002 Y119.152 F30000
G1 F12000
G1 X105.998 Y119.152 E.30717
G3 X106.391 Y117.931 I4.549 J.791 E.03954
G1 X95.599 Y117.931 E.33162
G1 X95.842 Y118.488 E.01867
G1 X95.993 Y119.093 E.01915
G1 X96.327 Y118.752 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X105.673 Y118.752 E.32128
G1 X105.789 Y118.33 E.01505
G1 X96.209 Y118.33 E.32937
G1 X96.311 Y118.695 E.013
G1 X97.642 Y120.298 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X99.27 Y120.298 E.05401
G1 X101.32 Y122.348 E.09618
G1 X100.948 Y122.348 E.01236
G1 X102.998 Y120.298 E.09618
G1 X104.627 Y120.298 E.05401
G1 X106.934 Y123.086 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X95.235 Y123.086 E.43137
G1 X95.235 Y123.539 E.01668
G1 X106.765 Y123.539 E.42511
G1 X106.765 Y123.991 E.01668
G1 X95.066 Y123.991 E.43137
G1 X95.223 Y122.669 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.717 Y122.669 E.31844
; WIPE_START
G1 X104.717 Y122.669 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X108.3 Y117.122 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.110213
G1 F15000
G1 X108.479 Y116.988 E.00122
G1 X109.331 Y117.12 F30000
; LINE_WIDTH: 0.467328
G1 F14844.215
G1 X109.509 Y116.867 E.0107
; LINE_WIDTH: 0.493634
G1 F13977.842
G1 X109.52 Y116.851 E.00072
; LINE_WIDTH: 0.521856
G1 F13154.179
G1 X109.532 Y116.835 E.00077
; LINE_WIDTH: 0.511665
G1 F13440.161
G1 X110.037 Y116.817 E.01931
G1 X110.468 Y116.835 E.01648
G1 X110.479 Y116.85 E.00071
; LINE_WIDTH: 0.495967
G1 F13905.865
G1 X110.49 Y116.865 E.00069
; LINE_WIDTH: 0.468186
G1 F14814.253
G1 X110.67 Y117.121 E.01083
G1 X111.528 Y116.988 F30000
; LINE_WIDTH: 0.112903
G1 F15000
G1 X111.724 Y117.138 E.00141
; WIPE_START
G1 X111.528 Y116.988 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X113.287 Y119.906 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.264 Y119.323 E.01792
; Slow Down End
G1 F12000
G1 X113.151 Y118.789 E.01676
G1 X112.825 Y118.057 E.02464
G1 X112.369 Y117.462 E.02302
G1 X112.128 Y117.244 E.00997
G1 X112.175 Y117.177 E.00252
G1 X125.237 Y117.177 E.40133
G1 X125.861 Y117.198 E.01917
G1 X125.892 Y117.237 E.00154
G2 X125.412 Y117.713 I26.115 J26.807 E.02076
G1 X125.018 Y118.351 E.02303
G2 X124.736 Y119.323 I4.005 J1.69 E.03117
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.713 Y119.906 E.01792
; Slow Down End
G1 F12000
G1 X113.347 Y119.906 E.34925
G1 X113.649 Y119.529 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.636 Y119.323 E.00634
; Slow Down End
G1 F12000
G1 X113.627 Y119.183 E.00431
G1 X113.496 Y118.639 E.01721
G1 X113.193 Y117.945 E.02325
G1 X112.914 Y117.554 E.01476
G1 X125.067 Y117.554 E.37341
G1 X124.697 Y118.153 E.02163
G2 X124.364 Y119.323 I3.48 J1.624 E.03754
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.351 Y119.529 E.00634
; Slow Down End
G1 F12000
G1 X113.709 Y119.529 E.32697
G1 X114.002 Y119.152 F30000
G1 F12000
G1 X123.998 Y119.152 E.30717
G3 X124.391 Y117.931 I4.549 J.791 E.03954
G1 X113.599 Y117.931 E.33162
G1 X113.842 Y118.488 E.01867
G1 X113.993 Y119.093 E.01915
G1 X114.327 Y118.752 F30000
; LINE_WIDTH: 0.464815
G1 F12000
G1 X123.673 Y118.752 E.32129
G1 X123.789 Y118.33 E.01505
G1 X114.209 Y118.33 E.32937
G1 X114.311 Y118.695 E.013
G1 X113.25 Y120.555 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
M73 P49 R14
G1 F15476.087
G1 X113.25 Y120.298 E.00851
G1 X114.622 Y120.298 E.0455
G1 X116.672 Y122.348 E.09618
G1 X116.3 Y122.348 E.01236
G1 X118.35 Y120.298 E.09618
G1 X122.298 Y120.298 E.13096
G1 X124.348 Y122.348 E.09618
G1 X123.976 Y122.348 E.01236
G1 X124.75 Y121.574 E.03631
G1 X124.75 Y120.298 E.04234
G1 X124.398 Y120.298 E.01167
G1 X124.934 Y123.086 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X113.235 Y123.086 E.43137
G1 X113.235 Y123.539 E.01668
G1 X124.765 Y123.539 E.42511
G1 X124.765 Y123.991 E.01668
G1 X113.066 Y123.991 E.43137
G1 X113.223 Y122.669 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.717 Y122.669 E.31844
; WIPE_START
G1 X122.717 Y122.669 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X126.3 Y117.122 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.110208
G1 F15000
G1 X126.479 Y116.988 E.00122
G1 X127.331 Y117.12 F30000
; LINE_WIDTH: 0.467235
G1 F14847.457
G1 X127.509 Y116.867 E.0107
; LINE_WIDTH: 0.493554
G1 F13980.316
G1 X127.52 Y116.851 E.00073
; LINE_WIDTH: 0.521831
G1 F13154.845
G1 X127.532 Y116.835 E.00077
; LINE_WIDTH: 0.511664
G1 F13440.187
G1 X128.037 Y116.817 E.01931
G1 X128.468 Y116.835 E.01648
G1 X128.479 Y116.85 E.00071
; LINE_WIDTH: 0.495863
G1 F13909.034
G1 X128.49 Y116.865 E.00069
; LINE_WIDTH: 0.468066
G1 F14818.445
G1 X128.67 Y117.121 E.01082
G1 X129.528 Y116.988 F30000
; LINE_WIDTH: 0.112898
G1 F15000
G1 X129.724 Y117.139 E.00141
G1 X131.263 Y119.297 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.151 Y118.789 E.01598
G1 X130.825 Y118.056 E.02465
G1 X130.369 Y117.462 E.02302
G1 X130.128 Y117.244 E.00997
G1 X130.176 Y117.177 E.00252
G1 X143.237 Y117.177 E.40133
G1 X143.861 Y117.198 E.01918
G1 X143.892 Y117.237 E.00154
G2 X143.412 Y117.713 I26.366 J27.058 E.02077
G1 X143.018 Y118.351 E.02302
G2 X142.736 Y119.323 I4.004 J1.69 E.03117
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.713 Y119.906 E.01792
G1 X131.287 Y119.906 E.35109
G1 X131.265 Y119.357 E.01688
; Slow Down End
G1 X131.627 Y119.183 F30000
G1 F12000
G1 X131.496 Y118.639 E.01721
G1 X131.193 Y117.945 E.02326
G1 X130.914 Y117.554 E.01476
G1 X143.067 Y117.554 E.37341
G1 X142.698 Y118.153 E.02163
G2 X142.364 Y119.323 I3.48 J1.624 E.03754
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.351 Y119.529 E.00634
G1 X131.649 Y119.529 E.32881
G1 X131.636 Y119.323 E.00634
; Slow Down End
G1 F12000
G1 X131.631 Y119.243 E.00246
G1 X132.002 Y119.152 F30000
G1 F12000
G1 X141.998 Y119.152 E.30717
G3 X142.391 Y117.931 I4.55 J.791 E.03954
G1 X131.599 Y117.931 E.33162
G1 X131.842 Y118.488 E.01867
G1 X131.993 Y119.093 E.01915
G1 X132.327 Y118.752 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X141.673 Y118.752 E.32128
G1 X141.789 Y118.33 E.01505
G1 X132.209 Y118.33 E.32937
G1 X132.311 Y118.695 E.013
G1 X131.602 Y120.298 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.25 Y120.298 E.01167
G1 X131.25 Y121.574 E.04234
G1 X132.024 Y122.348 E.0363
G1 X131.652 Y122.348 E.01236
G1 X133.702 Y120.298 E.09618
G1 X137.65 Y120.298 E.13096
G1 X139.7 Y122.348 E.09618
G1 X139.328 Y122.348 E.01236
G1 X141.378 Y120.298 E.09618
G1 X142.75 Y120.298 E.0455
G1 X142.75 Y120.555 E.00851
G1 X142.934 Y123.086 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X131.235 Y123.086 E.43137
G1 X131.235 Y123.539 E.01668
G1 X142.765 Y123.539 E.42511
G1 X142.765 Y123.991 E.01668
G1 X131.066 Y123.991 E.43137
G1 X131.223 Y122.669 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.717 Y122.669 E.31844
; WIPE_START
G1 X140.717 Y122.669 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X144.3 Y117.122 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.110207
G1 F15000
G1 X144.479 Y116.988 E.00122
G1 X145.331 Y117.12 F30000
; LINE_WIDTH: 0.467255
G1 F14846.764
G1 X145.509 Y116.867 E.0107
; LINE_WIDTH: 0.493569
G1 F13979.836
G1 X145.52 Y116.851 E.00073
; LINE_WIDTH: 0.521838
G1 F13154.651
G1 X145.532 Y116.835 E.00077
; LINE_WIDTH: 0.511676
G1 F13439.848
G1 X146.037 Y116.817 E.01931
G1 X146.468 Y116.835 E.01648
G1 X146.479 Y116.85 E.00071
; LINE_WIDTH: 0.495883
G1 F13908.445
G1 X146.49 Y116.865 E.00069
; LINE_WIDTH: 0.468074
G1 F14818.161
G1 X146.67 Y117.121 E.01082
G1 X147.528 Y116.988 F30000
; LINE_WIDTH: 0.112923
G1 F15000
G1 X147.725 Y117.139 E.00141
G1 X149.263 Y119.297 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X149.151 Y118.789 E.01598
G1 X148.825 Y118.056 E.02465
G1 X148.369 Y117.462 E.02302
G1 X148.128 Y117.244 E.00997
G1 X148.176 Y117.177 E.00252
G1 X161.237 Y117.177 E.40133
G1 X161.861 Y117.198 E.01917
G1 X161.892 Y117.237 E.00154
G2 X161.412 Y117.713 I26.093 J26.784 E.02076
G1 X161.018 Y118.351 E.02302
G2 X160.736 Y119.323 I4.003 J1.689 E.03117
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.713 Y119.906 E.01792
G1 X149.287 Y119.906 E.35109
G1 X149.265 Y119.357 E.01688
; Slow Down End
G1 X149.627 Y119.183 F30000
G1 F12000
G1 X149.496 Y118.639 E.01721
G1 X149.193 Y117.945 E.02326
G1 X148.914 Y117.554 E.01476
G1 X161.067 Y117.554 E.37341
G1 X160.698 Y118.153 E.02163
G2 X160.364 Y119.323 I3.48 J1.624 E.03754
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.351 Y119.529 E.00634
G1 X149.649 Y119.529 E.32881
G1 X149.636 Y119.323 E.00634
; Slow Down End
G1 F12000
G1 X149.631 Y119.243 E.00246
G1 X150.002 Y119.152 F30000
G1 F12000
G1 X159.998 Y119.152 E.30717
G3 X160.391 Y117.931 I4.55 J.791 E.03954
G1 X149.599 Y117.931 E.33162
G1 X149.842 Y118.488 E.01867
G1 X149.993 Y119.093 E.01915
G1 X150.327 Y118.752 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X159.673 Y118.752 E.32128
G1 X159.789 Y118.33 E.01505
G1 X150.209 Y118.33 E.32937
G1 X150.311 Y118.695 E.013
G1 X151.373 Y120.298 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X153.002 Y120.298 E.05401
G1 X155.052 Y122.348 E.09618
G1 X154.68 Y122.348 E.01236
G1 X156.73 Y120.298 E.09618
G1 X158.358 Y120.298 E.05401
G1 X160.934 Y123.086 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X149.235 Y123.086 E.43137
G1 X149.235 Y123.539 E.01668
G1 X160.765 Y123.539 E.42511
G1 X160.765 Y123.991 E.01668
G1 X149.066 Y123.991 E.43137
G1 X149.223 Y122.669 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.717 Y122.669 E.31844
; WIPE_START
G1 X158.717 Y122.669 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X162.3 Y117.122 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.110215
G1 F15000
G1 X162.479 Y116.988 E.00122
G1 X163.331 Y117.12 F30000
; LINE_WIDTH: 0.467273
G1 F14846.128
G1 X163.509 Y116.867 E.0107
; LINE_WIDTH: 0.493603
G1 F13978.809
G1 X163.52 Y116.851 E.00072
; LINE_WIDTH: 0.52184
G1 F13154.613
G1 X163.532 Y116.835 E.00077
; LINE_WIDTH: 0.511673
G1 F13439.92
G1 X164.037 Y116.817 E.01931
G1 X164.468 Y116.835 E.01648
G1 X164.479 Y116.85 E.00071
; LINE_WIDTH: 0.495863
G1 F13909.042
G1 X164.49 Y116.865 E.00069
; LINE_WIDTH: 0.468052
G1 F14818.923
G1 X164.67 Y117.121 E.01082
G1 X165.528 Y116.988 F30000
; LINE_WIDTH: 0.112906
G1 F15000
G1 X165.725 Y117.139 E.00141
; WIPE_START
G1 X165.528 Y116.988 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X167.25 Y120.823 Z3 F30000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.25 Y120.298 E.01741
G1 X168.354 Y120.298 E.0366
G1 X170.404 Y122.348 E.09618
G1 X170.032 Y122.348 E.01236
G1 X172.082 Y120.298 E.09618
G1 X176.03 Y120.298 E.13096
G1 X178.08 Y122.348 E.09618
G1 X177.707 Y122.348 E.01236
G1 X179.758 Y120.298 E.09618
G1 X181.386 Y120.298 E.05401
G1 X182.006 Y118.541 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y117.177 E.04193
G1 X166.175 Y117.177 E.48642
G1 X166.12 Y117.255 E.00295
G1 X166.481 Y117.583 E.01498
G1 X166.826 Y118.058 E.01805
G1 X167.151 Y118.789 E.02458
G1 X167.263 Y119.297 E.01598
G1 X167.287 Y119.906 E.01872
G1 X182.006 Y119.906 E.45226
G1 X182.006 Y118.601 E.04008
G1 X181.629 Y118.541 F30000
G1 F12000
G1 X181.629 Y117.554 E.03034
G1 X166.926 Y117.554 E.45177
G1 X167.192 Y117.943 E.01448
G1 X167.496 Y118.638 E.02334
G1 X167.627 Y119.183 E.01721
G1 X167.649 Y119.529 E.01064
G1 X181.629 Y119.529 E.42954
G1 X181.629 Y118.601 E.0285
G1 X181.252 Y118.541 F30000
G1 F12000
G1 X181.252 Y117.931 E.01876
G1 X167.599 Y117.931 E.41951
G1 X167.842 Y118.488 E.01866
G1 X168.002 Y119.152 E.02099
G1 X181.252 Y119.152 E.40713
G1 X181.252 Y118.601 E.01691
G1 X180.852 Y118.541 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X180.852 Y118.33 E.00725
G1 X168.209 Y118.33 E.43467
G1 X168.327 Y118.752 E.01507
G1 X180.852 Y118.752 E.43059
G1 X180.852 Y118.601 E.00519
G1 X182.234 Y123.086 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X167.235 Y123.086 E.55304
G1 X167.235 Y123.539 E.01668
G1 X182.065 Y123.539 E.54679
G1 X182.065 Y123.991 E.01668
G1 X167.066 Y123.991 E.55304
G1 X167.223 Y122.669 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y122.669 E.40987
; WIPE_START
G1 X180.017 Y122.669 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X172.384 Y122.704 Z3 F30000
G1 X88.934 Y123.086 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y123.086 E.55304
G1 X73.935 Y123.539 E.01668
G1 X88.765 Y123.539 E.54679
G1 X88.765 Y123.991 E.01668
G1 X73.766 Y123.991 E.55304
G1 X73.923 Y122.669 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.717 Y122.669 E.40987
G1 X74.614 Y120.298 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X76.242 Y120.298 E.05401
G1 X78.293 Y122.348 E.09618
G1 X77.92 Y122.348 E.01236
G1 X79.97 Y120.298 E.09618
G1 X83.918 Y120.298 E.13096
G1 X85.968 Y122.348 E.09618
G1 X85.596 Y122.348 E.01236
G1 X87.646 Y120.298 E.09618
G1 X88.75 Y120.298 E.0366
G1 X88.75 Y120.823 E.01741
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X88.75 Y120.298 E-.19947
G1 X87.646 Y120.298 E-.4193
G1 X87.383 Y120.561 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/33
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3 I-.207 J1.199 P1  F30000
G1 X182.398 Y136.952 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X73.602 Y136.952 E3.60896
G1 X73.602 Y136.392 E.01855
G1 X73.602 Y136.357 E.00116
G1 X182.398 Y136.357 E3.60896
G1 X182.398 Y136.392 E.00116
G1 X182.398 Y136.892 E.01656
M204 S250
G1 X182.79 Y137.175 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F3735.119
M204 S5000
G1 X182.79 Y137.344 E.00517
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F2040
G1 X73.21 Y137.344 E3.36709
G1 F3735.119
G1 X73.21 Y137.175 E.00517
G1 F9783.043
G1 X73.21 Y136.775 E.01229
G1 F6410.623
G1 X73.21 Y136.379 E.01219
G1 F1800
G1 X73.21 Y136.01 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X73.21 Y135.965 E.00148
G1 X182.79 Y135.965 E3.63497
G1 X182.79 Y136.01 E.00148
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y136.379 E.01134
G1 F6459.938
G1 X182.79 Y136.779 E.01229
G1 F12000
G1 X182.79 Y137.115 E.01035
M204 S10000
G1 X182.194 Y136.654 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.23013
G1 F15000
G1 X73.806 Y136.654 E1.6535
; WIPE_START
G1 X75.806 Y136.654 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.2 I.432 J1.138 P1  F30000
G1 X126.078 Y117.556 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X125.825 Y117.828 E.01231
G2 X125.098 Y119.738 I2.198 J1.93 E.06923
G1 X125.098 Y123.582 E.12751
G1 X125.098 Y123.982 E.01327
G1 F14655.771
G1 X125.098 Y124.382 E.01327
G1 F6907.886
G1 X125.098 Y124.782 E.01327
G1 F2040
G1 X125.098 Y125.133 E.01167
G1 F600
G1 X112.902 Y125.133 E.40456
G1 F2040
G1 X112.902 Y124.782 E.01167
G1 F6907.886
G1 X112.902 Y124.382 E.01327
G1 F14655.771
G1 X112.902 Y123.982 E.01327
G1 F15476.087
G1 X112.902 Y123.582 E.01327
G1 X112.902 Y119.739 E.12746
G2 X111.922 Y117.556 I-3.052 J.059 E.08157
G1 X126.018 Y117.556 E.46758
; WIPE_START
G1 X125.825 Y117.828 E-.12663
G1 X125.626 Y118.081 E-.12237
G1 X125.499 Y118.277 E-.08842
G1 X125.293 Y118.704 E-.18026
G1 X125.17 Y119.11 E-.16127
G1 X125.13 Y119.319 E-.08105
; WIPE_END
G1 E-.04 F1800
G1 X117.538 Y118.534 Z3.2 F30000
G1 X108.078 Y117.556 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G1 X107.825 Y117.828 E.01231
G2 X107.098 Y119.738 I2.198 J1.93 E.06923
G1 X107.098 Y123.582 E.12751
G1 X107.098 Y123.982 E.01327
G1 F14655.771
G1 X107.098 Y124.382 E.01327
G1 F6907.886
G1 X107.098 Y124.782 E.01327
G1 F2040
G1 X107.098 Y125.133 E.01167
G1 F600
G1 X94.902 Y125.133 E.40456
G1 F2040
G1 X94.902 Y124.782 E.01167
G1 F6907.886
G1 X94.902 Y124.382 E.01327
G1 F14655.771
G1 X94.902 Y123.982 E.01327
G1 F15476.087
G1 X94.902 Y123.582 E.01327
G1 X94.902 Y119.739 E.12746
G2 X93.922 Y117.556 I-3.052 J.059 E.08157
G1 X108.018 Y117.556 E.46758
; WIPE_START
G1 X107.825 Y117.828 E-.12663
G1 X107.626 Y118.081 E-.12237
G1 X107.499 Y118.277 E-.08842
G1 X107.293 Y118.704 E-.18026
G1 X107.17 Y119.11 E-.16128
G1 X107.13 Y119.319 E-.08104
; WIPE_END
G1 E-.04 F1800
G1 X99.538 Y118.534 Z3.2 F30000
G1 X90.078 Y117.556 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G2 X89.098 Y119.738 I2.06 J2.236 E.08152
G1 X89.098 Y123.582 E.12752
G1 X89.098 Y123.982 E.01327
G1 F14655.771
G1 X89.098 Y124.382 E.01327
G1 F6907.886
G1 X89.098 Y124.782 E.01327
G1 F2040
G1 X89.098 Y125.133 E.01167
G1 F600
M73 P50 R14
G1 X73.602 Y125.133 E.51403
G1 F2040
G1 X73.602 Y124.782 E.01167
G1 F6907.886
G1 X73.602 Y124.382 E.01327
G1 F14655.771
G1 X73.602 Y123.982 E.01327
G1 F15476.087
G1 X73.602 Y123.582 E.01327
G1 X73.602 Y117.556 E.19988
G1 X78.544 Y117.556 E.16394
G1 X90.018 Y117.556 E.3806
; WIPE_START
G1 X89.825 Y117.828 E-.12663
G1 X89.626 Y118.081 E-.12234
G1 X89.365 Y118.534 E-.19849
G1 X89.218 Y118.922 E-.15762
G1 X89.17 Y119.11 E-.07385
G1 X89.13 Y119.319 E-.08108
; WIPE_END
G1 E-.04 F1800
G1 X96.759 Y119.075 Z3.2 F30000
G1 X144.078 Y117.556 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G1 X143.825 Y117.828 E.01231
G2 X143.098 Y119.738 I2.198 J1.93 E.06924
G1 X143.098 Y123.582 E.12752
G1 X143.098 Y123.982 E.01327
G1 F14655.771
G1 X143.098 Y124.382 E.01327
G1 F6907.886
G1 X143.098 Y124.782 E.01327
G1 F2040
G1 X143.098 Y125.133 E.01167
G1 F600
G1 X130.902 Y125.133 E.40456
G1 F2040
G1 X130.902 Y124.782 E.01167
G1 F6907.886
G1 X130.902 Y124.382 E.01327
G1 F14655.771
G1 X130.902 Y123.982 E.01327
G1 F15476.087
G1 X130.902 Y123.582 E.01327
G1 X130.902 Y119.739 E.12746
G2 X129.922 Y117.556 I-3.052 J.059 E.08157
G1 X144.018 Y117.556 E.46758
; WIPE_START
G1 X143.825 Y117.828 E-.12657
G1 X143.626 Y118.081 E-.12242
G1 X143.499 Y118.277 E-.08844
G1 X143.293 Y118.704 E-.1802
G1 X143.17 Y119.11 E-.16131
G1 X143.13 Y119.319 E-.08105
; WIPE_END
G1 E-.04 F1800
G1 X150.73 Y118.612 Z3.2 F30000
G1 X162.078 Y117.556 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G1 X161.825 Y117.828 E.01231
G2 X161.098 Y119.738 I2.198 J1.93 E.06924
G1 X161.098 Y123.582 E.12752
G1 X161.098 Y123.982 E.01327
G1 F14655.771
G1 X161.098 Y124.382 E.01327
G1 F6907.886
G1 X161.098 Y124.782 E.01327
G1 F2040
G1 X161.098 Y125.133 E.01167
G1 F600
G1 X148.902 Y125.133 E.40456
G1 F2040
G1 X148.902 Y124.782 E.01167
G1 F6907.886
G1 X148.902 Y124.382 E.01327
G1 F14655.771
G1 X148.902 Y123.982 E.01327
G1 F15476.087
G1 X148.902 Y123.582 E.01327
G1 X148.902 Y119.739 E.12746
G2 X147.922 Y117.556 I-3.052 J.059 E.08157
G1 X162.018 Y117.556 E.46758
; WIPE_START
G1 X161.825 Y117.828 E-.12657
G1 X161.626 Y118.081 E-.12242
G1 X161.499 Y118.277 E-.08844
G1 X161.293 Y118.704 E-.18022
G1 X161.17 Y119.11 E-.16133
G1 X161.13 Y119.319 E-.08102
; WIPE_END
G1 E-.04 F1800
G1 X168.737 Y118.689 Z3.2 F30000
G1 X182.398 Y117.556 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F15476.087
G1 X182.398 Y123.582 E.19988
G1 X182.398 Y123.982 E.01327
G1 F14655.771
G1 X182.398 Y124.382 E.01327
G1 F6907.886
G1 X182.398 Y124.782 E.01327
G1 F2040
G1 X182.398 Y125.133 E.01167
G1 F600
G1 X166.902 Y125.133 E.51403
G1 F2040
G1 X166.902 Y124.782 E.01167
G1 F6907.886
G1 X166.902 Y124.382 E.01327
G1 F14655.771
G1 X166.902 Y123.982 E.01327
G1 F15476.087
G1 X166.902 Y123.582 E.01327
G1 X166.902 Y119.739 E.12746
G2 X165.922 Y117.556 I-3.052 J.059 E.08157
G1 X182.338 Y117.556 E.54455
; WIPE_START
G1 X182.358 Y119.556 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y115.917 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y123.995 E.24822
G1 X182.79 Y124.395 E.01229
G1 F6459.938
G1 X182.79 Y124.795 E.01229
G1 F1800
G1 X182.79 Y125.164 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y125.526 E.01199
G1 F600
G1 X166.51 Y125.526 E.54004
G1 X166.51 Y125.164 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
M73 P51 R14
G1 X166.51 Y124.795 E.01134
G1 F6459.938
G1 X166.51 Y124.395 E.01229
G1 F12000
G1 X166.51 Y123.995 E.01229
G1 X166.51 Y119.746 E.13055
G2 X161.49 Y119.746 I-2.51 J.01 E.24166
G1 X161.49 Y123.995 E.13057
G1 X161.49 Y124.395 E.01229
G1 F6459.938
G1 X161.49 Y124.795 E.01229
G1 F1800
G1 X161.49 Y125.164 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y125.526 E.01199
G1 X148.51 Y125.526 E.43057
G1 X148.51 Y125.164 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y124.795 E.01134
G1 F6459.938
G1 X148.51 Y124.395 E.01229
G1 F12000
G1 X148.51 Y123.995 E.01229
G1 X148.51 Y119.746 E.13055
G2 X143.49 Y119.746 I-2.51 J.01 E.24166
G1 X143.49 Y123.995 E.13057
G1 X143.49 Y124.395 E.01229
G1 F6459.938
G1 X143.49 Y124.795 E.01229
G1 F1800
G1 X143.49 Y125.164 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y125.526 E.01199
G1 X130.51 Y125.526 E.43057
G1 X130.51 Y125.164 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y124.795 E.01134
G1 F6459.938
G1 X130.51 Y124.395 E.01229
G1 F12000
G1 X130.51 Y123.995 E.01229
G1 X130.51 Y119.746 E.13055
G2 X125.49 Y119.746 I-2.51 J.01 E.24166
G1 X125.49 Y123.995 E.13057
G1 X125.49 Y124.395 E.01229
G1 F6459.938
G1 X125.49 Y124.795 E.01229
G1 F1800
G1 X125.49 Y125.164 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y125.526 E.01199
G1 X112.51 Y125.526 E.43057
G1 X112.51 Y125.164 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y124.795 E.01134
G1 F6459.938
G1 X112.51 Y124.395 E.01229
G1 F12000
G1 X112.51 Y123.995 E.01229
G1 X112.51 Y119.746 E.13055
G2 X107.49 Y119.746 I-2.51 J.01 E.24166
G1 X107.49 Y123.995 E.13057
G1 X107.49 Y124.395 E.01229
G1 F6459.938
G1 X107.49 Y124.795 E.01229
G1 F1800
G1 X107.49 Y125.164 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y125.526 E.01199
G1 X94.51 Y125.526 E.43057
G1 X94.51 Y125.164 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y124.795 E.01134
G1 F6459.938
G1 X94.51 Y124.395 E.01229
G1 F12000
G1 X94.51 Y123.995 E.01229
G1 X94.51 Y119.746 E.13055
G2 X89.49 Y119.746 I-2.51 J.01 E.24166
G1 X89.49 Y123.995 E.13057
G1 X89.49 Y124.395 E.01229
G1 F6459.938
G1 X89.49 Y124.795 E.01229
G1 F1800
G1 X89.49 Y125.164 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y125.526 E.01199
G1 X73.21 Y125.526 E.54004
G1 X73.21 Y125.164 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y124.795 E.01134
G1 F6459.938
G1 X73.21 Y124.395 E.01229
G1 F12000
G1 X73.21 Y123.995 E.01229
G1 X73.21 Y115.917 E.24822
G1 X182.73 Y115.917 E3.36524
; WIPE_START
M204 S10000
G1 X182.745 Y117.917 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.727 Y117.334 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.583 Y116.478 E.0372
G1 X182.403 Y116.124
G1 X181.193 Y117.334 E.05255
G1 X180.66 Y117.334
G1 X181.869 Y116.124 E.05255
G1 X181.336 Y116.124
G1 X180.127 Y117.334 E.05255
G1 X179.593 Y117.334
G1 X180.803 Y116.124 E.05255
G1 X180.27 Y116.124
G1 X179.06 Y117.334 E.05255
G1 X178.527 Y117.334
G1 X179.736 Y116.124 E.05255
G1 X179.203 Y116.124
G1 X177.994 Y117.334 E.05255
G1 X177.46 Y117.334
G1 X178.67 Y116.124 E.05255
G1 X178.137 Y116.124
G1 X176.927 Y117.334 E.05255
G1 X176.394 Y117.334
G1 X177.603 Y116.124 E.05255
G1 X177.07 Y116.124
G1 X175.861 Y117.334 E.05255
G1 X175.327 Y117.334
G1 X176.537 Y116.124 E.05255
G1 X176.004 Y116.124
G1 X174.794 Y117.334 E.05255
G1 X174.261 Y117.334
G1 X175.47 Y116.124 E.05255
G1 X174.937 Y116.124
G1 X173.728 Y117.334 E.05255
G1 X173.194 Y117.334
G1 X174.404 Y116.124 E.05255
G1 X173.87 Y116.124
G1 X172.661 Y117.334 E.05255
G1 X172.128 Y117.334
G1 X173.337 Y116.124 E.05255
G1 X172.804 Y116.124
G1 X171.595 Y117.334 E.05255
G1 X171.061 Y117.334
G1 X172.271 Y116.124 E.05255
G1 X171.737 Y116.124
G1 X170.528 Y117.334 E.05255
G1 X169.995 Y117.334
G1 X171.204 Y116.124 E.05255
G1 X170.671 Y116.124
G1 X169.462 Y117.334 E.05255
G1 X168.928 Y117.334
G1 X170.138 Y116.124 E.05255
G1 X169.604 Y116.124
G1 X168.395 Y117.334 E.05255
G1 X167.862 Y117.334
G1 X169.071 Y116.124 E.05255
G1 X168.538 Y116.124
G1 X167.329 Y117.334 E.05255
G1 X166.795 Y117.334
G1 X168.005 Y116.124 E.05255
G1 X167.471 Y116.124
G1 X166.262 Y117.334 E.05255
G1 X165.729 Y117.334
G1 X166.938 Y116.124 E.05255
G1 X166.405 Y116.124
G1 X165.21 Y117.319 E.05193
G1 X164.833 Y117.163
G1 X165.872 Y116.124 E.04515
G1 X165.338 Y116.124
G1 X164.4 Y117.063 E.04078
G1 X163.892 Y117.037
G1 X164.805 Y116.124 E.03966
G1 X164.272 Y116.124
G1 X163.258 Y117.138 E.04406
G1 X162.529 Y117.334
G1 X163.739 Y116.124 E.05255
G1 X163.205 Y116.124
G1 X161.996 Y117.334 E.05255
G1 X161.463 Y117.334
G1 X162.672 Y116.124 E.05255
G1 X162.139 Y116.124
G1 X160.929 Y117.334 E.05255
G1 X160.396 Y117.334
G1 X161.606 Y116.124 E.05255
G1 X161.072 Y116.124
G1 X159.863 Y117.334 E.05255
G1 X159.33 Y117.334
G1 X160.539 Y116.124 E.05255
G1 X160.006 Y116.124
G1 X158.796 Y117.334 E.05255
G1 X158.263 Y117.334
G1 X159.473 Y116.124 E.05255
G1 X158.939 Y116.124
G1 X157.73 Y117.334 E.05255
G1 X157.197 Y117.334
G1 X158.406 Y116.124 E.05255
G1 X157.873 Y116.124
G1 X156.663 Y117.334 E.05255
G1 X156.13 Y117.334
G1 X157.34 Y116.124 E.05255
G1 X156.806 Y116.124
G1 X155.597 Y117.334 E.05255
G1 X155.064 Y117.334
G1 X156.273 Y116.124 E.05255
G1 X155.74 Y116.124
G1 X154.53 Y117.334 E.05255
G1 X153.997 Y117.334
G1 X155.206 Y116.124 E.05255
G1 X154.673 Y116.124
G1 X153.464 Y117.334 E.05255
G1 X152.931 Y117.334
G1 X154.14 Y116.124 E.05255
G1 X153.607 Y116.124
G1 X152.397 Y117.334 E.05255
G1 X151.864 Y117.334
G1 X153.073 Y116.124 E.05255
G1 X152.54 Y116.124
G1 X151.331 Y117.334 E.05255
G1 X150.798 Y117.334
G1 X152.007 Y116.124 E.05255
G1 X151.474 Y116.124
G1 X150.264 Y117.334 E.05255
G1 X149.731 Y117.334
G1 X150.94 Y116.124 E.05255
G1 X150.407 Y116.124
G1 X149.198 Y117.334 E.05255
G1 X148.665 Y117.334
G1 X149.874 Y116.124 E.05255
G1 X149.341 Y116.124
G1 X148.131 Y117.334 E.05255
G1 X147.598 Y117.334
G1 X148.807 Y116.124 E.05255
G1 X148.274 Y116.124
G1 X147.122 Y117.276 E.05006
G1 X146.731 Y117.134
G1 X147.741 Y116.124 E.04387
G1 X147.208 Y116.124
G1 X146.284 Y117.048 E.04014
G1 X145.754 Y117.044
G1 X146.674 Y116.124 E.03998
G1 X146.141 Y116.124
G1 X145.067 Y117.198 E.04667
G1 X144.399 Y117.334
G1 X145.608 Y116.124 E.05255
G1 X145.075 Y116.124
G1 X143.865 Y117.334 E.05255
G1 X143.332 Y117.334
G1 X144.541 Y116.124 E.05255
G1 X144.008 Y116.124
G1 X142.799 Y117.334 E.05255
G1 X142.265 Y117.334
G1 X143.475 Y116.124 E.05255
G1 X142.942 Y116.124
G1 X141.732 Y117.334 E.05255
G1 X141.199 Y117.334
G1 X142.408 Y116.124 E.05255
G1 X141.875 Y116.124
G1 X140.666 Y117.334 E.05255
G1 X140.132 Y117.334
G1 X141.342 Y116.124 E.05255
G1 X140.809 Y116.124
G1 X139.599 Y117.334 E.05255
G1 X139.066 Y117.334
G1 X140.275 Y116.124 E.05255
G1 X139.742 Y116.124
G1 X138.533 Y117.334 E.05255
G1 X137.999 Y117.334
G1 X139.209 Y116.124 E.05255
G1 X138.675 Y116.124
G1 X137.466 Y117.334 E.05255
G1 X136.933 Y117.334
G1 X138.142 Y116.124 E.05255
G1 X137.609 Y116.124
M73 P52 R14
G1 X136.4 Y117.334 E.05255
G1 X135.866 Y117.334
G1 X137.076 Y116.124 E.05255
G1 X136.542 Y116.124
G1 X135.333 Y117.334 E.05255
G1 X134.8 Y117.334
G1 X136.009 Y116.124 E.05255
G1 X135.476 Y116.124
G1 X134.267 Y117.334 E.05255
G1 X133.733 Y117.334
G1 X134.943 Y116.124 E.05255
G1 X134.409 Y116.124
G1 X133.2 Y117.334 E.05255
G1 X132.667 Y117.334
G1 X133.876 Y116.124 E.05255
G1 X133.343 Y116.124
G1 X132.134 Y117.334 E.05255
G1 X131.6 Y117.334
G1 X132.81 Y116.124 E.05255
G1 X132.276 Y116.124
G1 X131.067 Y117.334 E.05255
G1 X130.534 Y117.334
G1 X131.743 Y116.124 E.05255
G1 X131.21 Y116.124
G1 X130.001 Y117.334 E.05255
G1 X129.467 Y117.334
G1 X130.677 Y116.124 E.05255
G1 X130.143 Y116.124
G1 X129.031 Y117.237 E.04833
G1 X128.627 Y117.108
G1 X129.61 Y116.124 E.04274
G1 X129.077 Y116.124
G1 X128.163 Y117.038 E.03971
G1 X127.606 Y117.062
G1 X128.544 Y116.124 E.04075
G1 X128.01 Y116.124
G1 X126.841 Y117.293 E.0508
G1 X126.268 Y117.334
G1 X127.477 Y116.124 E.05255
G1 X126.944 Y116.124
G1 X125.734 Y117.334 E.05255
G1 X125.201 Y117.334
G1 X126.411 Y116.124 E.05255
G1 X125.877 Y116.124
G1 X124.668 Y117.334 E.05255
G1 X124.135 Y117.334
G1 X125.344 Y116.124 E.05255
G1 X124.811 Y116.124
G1 X123.601 Y117.334 E.05255
G1 X123.068 Y117.334
G1 X124.278 Y116.124 E.05255
G1 X123.744 Y116.124
G1 X122.535 Y117.334 E.05255
G1 X122.002 Y117.334
G1 X123.211 Y116.124 E.05255
G1 X122.678 Y116.124
G1 X121.468 Y117.334 E.05255
G1 X120.935 Y117.334
G1 X122.145 Y116.124 E.05255
G1 X121.611 Y116.124
G1 X120.402 Y117.334 E.05255
G1 X119.869 Y117.334
G1 X121.078 Y116.124 E.05255
G1 X120.545 Y116.124
G1 X119.335 Y117.334 E.05255
G1 X118.802 Y117.334
G1 X120.011 Y116.124 E.05255
G1 X119.478 Y116.124
G1 X118.269 Y117.334 E.05255
G1 X117.736 Y117.334
G1 X118.945 Y116.124 E.05255
G1 X118.412 Y116.124
G1 X117.202 Y117.334 E.05255
G1 X116.669 Y117.334
G1 X117.878 Y116.124 E.05255
G1 X117.345 Y116.124
G1 X116.136 Y117.334 E.05255
G1 X115.603 Y117.334
G1 X116.812 Y116.124 E.05255
G1 X116.279 Y116.124
G1 X115.069 Y117.334 E.05255
G1 X114.536 Y117.334
G1 X115.745 Y116.124 E.05255
G1 X115.212 Y116.124
G1 X114.003 Y117.334 E.05255
G1 X113.47 Y117.334
G1 X114.679 Y116.124 E.05255
G1 X114.146 Y116.124
G1 X112.936 Y117.334 E.05255
G1 X112.403 Y117.334
G1 X113.612 Y116.124 E.05255
G1 X113.079 Y116.124
G1 X111.87 Y117.334 E.05255
G1 X111.337 Y117.334
G1 X112.546 Y116.124 E.05255
G1 X112.013 Y116.124
G1 X110.937 Y117.2 E.04673
G1 X110.519 Y117.084
G1 X111.479 Y116.124 E.04172
G1 X110.946 Y116.124
G1 X110.037 Y117.033 E.03949
G1 X109.446 Y117.091
G1 X110.413 Y116.124 E.04199
G1 X109.88 Y116.124
G1 X108.67 Y117.334 E.05255
G1 X108.137 Y117.334
G1 X109.346 Y116.124 E.05255
G1 X108.813 Y116.124
G1 X107.604 Y117.334 E.05255
G1 X107.07 Y117.334
G1 X108.28 Y116.124 E.05255
G1 X107.747 Y116.124
G1 X106.537 Y117.334 E.05255
G1 X106.004 Y117.334
G1 X107.213 Y116.124 E.05255
G1 X106.68 Y116.124
M73 P52 R13
G1 X105.471 Y117.334 E.05255
G1 X104.937 Y117.334
G1 X106.147 Y116.124 E.05255
G1 X105.614 Y116.124
G1 X104.404 Y117.334 E.05255
G1 X103.871 Y117.334
G1 X105.08 Y116.124 E.05255
G1 X104.547 Y116.124
G1 X103.338 Y117.334 E.05255
G1 X102.804 Y117.334
G1 X104.014 Y116.124 E.05255
G1 X103.48 Y116.124
G1 X102.271 Y117.334 E.05255
G1 X101.738 Y117.334
G1 X102.947 Y116.124 E.05255
G1 X102.414 Y116.124
G1 X101.205 Y117.334 E.05255
G1 X100.671 Y117.334
G1 X101.881 Y116.124 E.05255
G1 X101.347 Y116.124
G1 X100.138 Y117.334 E.05255
G1 X99.605 Y117.334
G1 X100.814 Y116.124 E.05255
G1 X100.281 Y116.124
G1 X99.072 Y117.334 E.05255
G1 X98.538 Y117.334
G1 X99.748 Y116.124 E.05255
G1 X99.214 Y116.124
G1 X98.005 Y117.334 E.05255
G1 X97.472 Y117.334
G1 X98.681 Y116.124 E.05255
G1 X98.148 Y116.124
G1 X96.939 Y117.334 E.05255
G1 X96.405 Y117.334
G1 X97.615 Y116.124 E.05255
G1 X97.081 Y116.124
G1 X95.872 Y117.334 E.05255
G1 X95.339 Y117.334
G1 X96.548 Y116.124 E.05255
G1 X96.015 Y116.124
G1 X94.806 Y117.334 E.05255
G1 X94.272 Y117.334
G1 X95.482 Y116.124 E.05255
G1 X94.948 Y116.124
G1 X93.739 Y117.334 E.05255
G1 X93.217 Y117.323
G1 X94.415 Y116.124 E.05208
G1 X93.882 Y116.124
G1 X92.84 Y117.166 E.04526
G1 X92.409 Y117.064
G1 X93.349 Y116.124 E.04084
G1 X92.815 Y116.124
G1 X91.903 Y117.037 E.03965
G1 X91.272 Y117.134
G1 X92.282 Y116.124 E.0439
G1 X91.749 Y116.124
G1 X90.539 Y117.334 E.05255
G1 X90.006 Y117.334
G1 X91.216 Y116.124 E.05255
G1 X90.682 Y116.124
G1 X89.473 Y117.334 E.05255
G1 X88.94 Y117.334
G1 X90.149 Y116.124 E.05255
G1 X89.616 Y116.124
G1 X88.406 Y117.334 E.05255
G1 X87.873 Y117.334
G1 X89.083 Y116.124 E.05255
G1 X88.549 Y116.124
G1 X87.34 Y117.334 E.05255
G1 X86.807 Y117.334
G1 X88.016 Y116.124 E.05255
G1 X87.483 Y116.124
G1 X86.273 Y117.334 E.05255
G1 X85.74 Y117.334
G1 X86.949 Y116.124 E.05255
G1 X86.416 Y116.124
G1 X85.207 Y117.334 E.05255
G1 X84.674 Y117.334
G1 X85.883 Y116.124 E.05255
G1 X85.35 Y116.124
G1 X84.14 Y117.334 E.05255
G1 X83.607 Y117.334
G1 X84.816 Y116.124 E.05255
G1 X84.283 Y116.124
G1 X83.074 Y117.334 E.05255
G1 X82.541 Y117.334
G1 X83.75 Y116.124 E.05255
G1 X83.217 Y116.124
G1 X82.007 Y117.334 E.05255
G1 X81.474 Y117.334
G1 X82.683 Y116.124 E.05255
G1 X82.15 Y116.124
G1 X80.941 Y117.334 E.05255
G1 X80.408 Y117.334
G1 X81.617 Y116.124 E.05255
G1 X81.084 Y116.124
G1 X79.874 Y117.334 E.05255
G1 X79.341 Y117.334
G1 X80.55 Y116.124 E.05255
G1 X80.017 Y116.124
G1 X78.808 Y117.334 E.05255
G1 X78.275 Y117.334
G1 X79.484 Y116.124 E.05255
G1 X78.951 Y116.124
G1 X77.741 Y117.334 E.05255
G1 X77.208 Y117.334
G1 X78.417 Y116.124 E.05255
G1 X77.884 Y116.124
G1 X76.675 Y117.334 E.05255
G1 X76.142 Y117.334
G1 X77.351 Y116.124 E.05255
G1 X76.818 Y116.124
G1 X75.608 Y117.334 E.05255
G1 X75.075 Y117.334
G1 X76.284 Y116.124 E.05255
G1 X75.751 Y116.124
G1 X74.542 Y117.334 E.05255
G1 X74.009 Y117.334
G1 X75.218 Y116.124 E.05255
G1 X74.685 Y116.124
G1 X73.475 Y117.334 E.05255
G1 X73.417 Y116.858
G1 X74.151 Y116.124 E.03189
; WIPE_START
M204 S10000
G1 X73.417 Y116.858 E-.39442
G1 X73.475 Y117.334 E-.18198
G1 X73.817 Y116.992 E-.18361
; WIPE_END
G1 E-.04 F1800
G1 X81.449 Y116.99 Z3.2 F30000
G1 X163.821 Y116.965 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.104518
G1 F15000
G1 X163.622 Y117.063 E.00111
G1 X163.908 Y117.052 F30000
; LINE_WIDTH: 0.134113
G1 F15000
G1 X163.692 Y116.971 E.00171
G1 X145.685 Y116.975 F30000
; LINE_WIDTH: 0.120794
G1 F15000
G1 X145.465 Y117.089 E.00157
G1 X145.769 Y117.059 F30000
; LINE_WIDTH: 0.138349
G1 F15000
G1 X145.549 Y116.984 E.00181
G1 X127.537 Y116.993 F30000
; LINE_WIDTH: 0.126526
G1 F15000
G1 X127.294 Y117.129 E.00189
G1 X127.62 Y117.077 F30000
; LINE_WIDTH: 0.126067
G1 F15000
G1 X127.396 Y117.006 E.0016
G1 X110.441 Y117.006 F30000
; LINE_WIDTH: 0.0928195
G1 F15000
G1 X110.272 Y117.065 E.00073
G1 X110.493 Y117.081 F30000
; LINE_WIDTH: 0.0949503
G1 F15000
G1 X110.338 Y116.999 E.00075
G1 X109.378 Y117.023 F30000
; LINE_WIDTH: 0.101442
G1 F15000
G2 X109.112 Y117.184 I3.493 J6.072 E.00149
G1 X109.46 Y117.105 F30000
; LINE_WIDTH: 0.124774
G1 F15000
G1 X109.231 Y117.04 E.00159
G1 X92.387 Y117.064 F30000
; LINE_WIDTH: 0.110648
G1 F15000
G1 X92.223 Y116.983 E.00101
G1 X91.204 Y117.067 F30000
; LINE_WIDTH: 0.137897
G1 F15000
G1 X90.899 Y117.264 E.00281
G1 X90.657 Y117.379 F30000
; LINE_WIDTH: 0.126021
G1 F15000
G2 X90.546 Y117.411 I-.021 J.137 E.0008
G1 X90.385 Y117.549 E.00144
; WIPE_START
G1 X90.546 Y117.411 E-.49333
G1 X90.657 Y117.379 E-.26667
; WIPE_END
G1 E-.04 F1800
G1 X93.345 Y117.379 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.125656
G1 F15000
G3 X93.453 Y117.41 I.02 J.134 E.00078
G1 X93.613 Y117.548 E.00142
; WIPE_START
G1 X93.453 Y117.41 E-.4969
G1 X93.345 Y117.379 E-.2631
; WIPE_END
G1 E-.04 F1800
G1 X95.281 Y120.094 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X95.263 Y119.292 E.02467
G1 X95.152 Y118.792 E.01572
G1 X94.928 Y118.24 E.01831
G1 X94.739 Y117.948 E.01067
G1 X107.25 Y117.948 E.38441
G2 X106.837 Y118.83 I2.472 J1.695 E.03004
G1 X106.715 Y119.518 E.02149
G1 X106.714 Y120.094 E.01771
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.713 Y120.677 E.01791
G1 X95.294 Y120.677 E.35085
; Slow Down End
G1 F12000
G1 X95.282 Y120.154 E.01607
G1 X95.665 Y120.094 F30000
G1 F12000
G1 X95.639 Y119.264 E.02552
G2 X95.369 Y118.325 I-2.994 J.351 E.03015
G1 X106.621 Y118.325 E.34574
G1 X106.466 Y118.762 E.01424
G1 X106.337 Y119.518 E.02356
G1 X106.337 Y120.094 E.01773
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.336 Y120.3 E.00632
G1 X95.671 Y120.3 E.3277
; Slow Down End
G1 F12000
G1 X95.667 Y120.154 E.00448
G1 X96.048 Y119.923 F30000
G1 F12000
G1 X105.96 Y119.923 E.30455
G1 X105.969 Y119.394 E.01628
G1 X106.094 Y118.702 E.02158
G1 X95.907 Y118.702 E.31299
G1 X96.015 Y119.237 E.01675
G1 X96.045 Y119.863 E.01927
G1 X96.436 Y119.524 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X105.561 Y119.524 E.31369
G1 X105.615 Y119.102 E.01462
G1 X96.398 Y119.102 E.31687
G1 X96.431 Y119.464 E.0125
G1 X95.223 Y123.441 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.719 Y123.441 E.31851
G1 X106.936 Y123.858 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X95.235 Y123.858 E.43144
G1 X95.235 Y124.31 E.01668
G1 X106.766 Y124.31 E.42516
G1 X106.765 Y124.763 E.01668
G1 X95.066 Y124.763 E.43139
; WIPE_START
G1 X97.066 Y124.763 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.2 I.135 J-1.209 P1  F30000
G1 X88.934 Y123.858 Z3.2
G1 Z2.8
G1 E.8 F1800
G1 F3000
G1 X73.935 Y123.858 E.55304
G1 X73.935 Y124.31 E.01668
G1 X88.765 Y124.31 E.54679
G1 X88.765 Y124.763 E.01668
G1 X73.766 Y124.763 E.55304
G1 X73.923 Y123.441 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.717 Y123.441 E.40987
G1 X88.503 Y121.069 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X86.875 Y121.069 E.05401
G1 X84.825 Y123.12 E.09618
G1 X86.74 Y123.12 E.06354
G1 X84.69 Y121.069 E.09618
G1 X79.199 Y121.069 E.18214
G1 X77.149 Y123.12 E.09618
G1 X79.064 Y123.12 E.06354
G1 X77.014 Y121.069 E.09618
G1 X75.385 Y121.069 E.05401
G1 X73.994 Y120.094 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X73.994 Y117.948 E.06595
G1 X89.258 Y117.948 E.46901
G2 X89.075 Y118.236 I1.401 J1.096 E.01049
G1 X88.847 Y118.795 E.01856
G2 X88.706 Y120.094 I4.387 J1.135 E.04029
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.706 Y120.677 E.01791
G1 X73.994 Y120.677 E.45204
; Slow Down End
G1 F12000
G1 X73.994 Y120.154 E.01607
G1 X74.371 Y120.094 F30000
G1 F12000
G1 X74.371 Y118.325 E.05436
G1 X88.631 Y118.325 E.43816
G1 X88.498 Y118.653 E.01088
G2 X88.329 Y119.73 I3.459 J1.095 E.03362
G1 X88.329 Y120.094 E.0112
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.329 Y120.3 E.00632
G1 X74.371 Y120.3 E.42887
; Slow Down End
G1 F12000
G1 X74.371 Y120.154 E.00448
G1 X74.748 Y119.923 F30000
G1 F12000
G1 X87.952 Y119.923 E.4057
G3 X88.093 Y118.702 I4.668 J-.079 E.03787
G1 X74.748 Y118.702 E.41003
G1 X74.748 Y119.863 E.03567
G1 X75.148 Y119.524 F30000
; LINE_WIDTH: 0.464815
G1 F12000
G1 X87.564 Y119.524 E.42685
G1 X87.602 Y119.102 E.01456
G1 X75.148 Y119.102 E.42817
G1 X75.148 Y119.464 E.01244
; WIPE_START
G1 X75.148 Y119.102 E-.13752
G1 X76.786 Y119.102 E-.62248
; WIPE_END
G1 E-.04 F1800
G1 X84.398 Y119.655 Z3.2 F30000
G1 X103.855 Y121.069 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.227 Y121.069 E.05401
G1 X100.176 Y123.12 E.09618
G1 X102.092 Y123.12 E.06354
G1 X100.042 Y121.069 E.09618
G1 X98.413 Y121.069 E.05401
; WIPE_START
G1 X100.042 Y121.069 E-.61876
G1 X100.304 Y121.332 E-.14125
; WIPE_END
G1 E-.04 F1800
G1 X107.217 Y118.096 Z3.2 F30000
G1 X108.385 Y117.549 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.126017
G1 F15000
G1 X108.548 Y117.409 E.00146
G1 X108.657 Y117.38 E.00076
; WIPE_START
G1 X108.548 Y117.409 E-.26016
G1 X108.385 Y117.549 E-.49984
; WIPE_END
G1 E-.04 F1800
G1 X111.345 Y117.379 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.125656
G1 F15000
G3 X111.453 Y117.41 I.02 J.134 E.00078
G1 X111.613 Y117.548 E.00142
; WIPE_START
G1 X111.453 Y117.41 E-.4969
G1 X111.345 Y117.379 E-.2631
; WIPE_END
G1 E-.04 F1800
G1 X113.281 Y120.094 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X113.263 Y119.292 E.02467
G1 X113.152 Y118.792 E.01572
G1 X112.928 Y118.24 E.01831
G1 X112.739 Y117.948 E.01066
G1 X125.25 Y117.948 E.38441
G2 X124.837 Y118.83 I2.472 J1.695 E.03004
G1 X124.715 Y119.518 E.02148
G1 X124.714 Y120.094 E.01771
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.713 Y120.677 E.01791
G1 X113.294 Y120.677 E.35085
; Slow Down End
G1 F12000
G1 X113.282 Y120.154 E.01607
G1 X113.671 Y120.3 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.665 Y120.094 E.00633
; Slow Down End
G1 F12000
G1 X113.639 Y119.264 E.02552
G2 X113.369 Y118.325 I-2.994 J.351 E.03015
G1 X124.621 Y118.325 E.34574
G1 X124.466 Y118.762 E.01424
G1 X124.337 Y119.518 E.02355
G1 X124.337 Y120.094 E.01773
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.336 Y120.3 E.00632
; Slow Down End
G1 F12000
G1 X113.731 Y120.3 E.32586
G1 X114.048 Y119.923 F30000
G1 F12000
G1 X123.96 Y119.923 E.30455
G1 X123.969 Y119.394 E.01628
G1 X124.094 Y118.702 E.02158
G1 X113.907 Y118.702 E.31299
G1 X114.015 Y119.237 E.01675
G1 X114.045 Y119.863 E.01927
G1 X114.436 Y119.524 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X123.561 Y119.524 E.31369
G1 X123.615 Y119.102 E.01462
G1 X114.398 Y119.102 E.31687
G1 X114.431 Y119.464 E.0125
G1 X113.223 Y123.441 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.719 Y123.441 E.31851
M73 P53 R13
G1 X124.936 Y123.858 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X113.235 Y123.858 E.43144
G1 X113.235 Y124.31 E.01668
G1 X124.766 Y124.31 E.42516
G1 X124.765 Y124.763 E.01668
G1 X113.066 Y124.763 E.43139
G1 X121.576 Y123.12 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X123.204 Y123.12 E.05401
G1 X124.755 Y121.569 E.07275
G1 X124.753 Y122.753 E.03929
G1 X123.069 Y121.069 E.079
G1 X117.579 Y121.069 E.18214
G1 X115.528 Y123.12 E.09618
G1 X117.444 Y123.12 E.06354
G1 X115.393 Y121.069 E.09618
G1 X113.765 Y121.069 E.05401
; WIPE_START
G1 X115.393 Y121.069 E-.61876
G1 X115.656 Y121.332 E-.14125
; WIPE_END
G1 E-.04 F1800
G1 X122.854 Y118.794 Z3.2 F30000
G1 X126.385 Y117.549 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.126017
G1 F15000
G1 X126.548 Y117.409 E.00146
G1 X126.657 Y117.38 E.00076
; WIPE_START
G1 X126.548 Y117.409 E-.26016
G1 X126.385 Y117.549 E-.49984
; WIPE_END
G1 E-.04 F1800
G1 X129.345 Y117.379 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.12568
G1 F15000
G3 X129.453 Y117.41 I.019 J.136 E.00078
G1 X129.613 Y117.548 E.00142
; WIPE_START
G1 X129.453 Y117.41 E-.49644
G1 X129.345 Y117.379 E-.26356
; WIPE_END
G1 E-.04 F1800
G1 X131.294 Y120.677 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.281 Y120.094 E.01792
; Slow Down End
G1 F12000
G1 X131.263 Y119.292 E.02468
G1 X131.152 Y118.792 E.01572
G1 X130.927 Y118.24 E.01832
G1 X130.739 Y117.948 E.01066
G1 X143.25 Y117.948 E.38441
G2 X142.837 Y118.83 I2.472 J1.696 E.03004
G1 X142.715 Y119.518 E.02149
G1 X142.714 Y120.094 E.01771
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.713 Y120.677 E.01791
; Slow Down End
G1 F12000
G1 X131.354 Y120.677 E.34901
G1 X131.665 Y120.094 F30000
G1 F12000
G1 X131.639 Y119.264 E.02552
G2 X131.369 Y118.325 I-2.995 J.351 E.03014
G1 X142.621 Y118.325 E.34574
G1 X142.466 Y118.762 E.01424
G1 X142.337 Y119.518 E.02355
G1 X142.337 Y120.094 E.01773
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.336 Y120.3 E.00632
G1 X131.671 Y120.3 E.3277
; Slow Down End
G1 F12000
G1 X131.667 Y120.154 E.00448
G1 X132.048 Y119.923 F30000
G1 F12000
G1 X141.96 Y119.923 E.30455
G1 X141.969 Y119.394 E.01628
G1 X142.094 Y118.702 E.02158
G1 X131.907 Y118.702 E.31299
G1 X132.015 Y119.237 E.01675
G1 X132.045 Y119.863 E.01927
G1 X132.436 Y119.524 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X141.561 Y119.524 E.31369
G1 X141.615 Y119.102 E.01462
G1 X132.398 Y119.102 E.31687
G1 X132.431 Y119.464 E.0125
G1 X131.223 Y123.441 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.719 Y123.441 E.31851
G1 X142.936 Y123.858 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X131.235 Y123.858 E.43144
G1 X131.235 Y124.31 E.01668
G1 X142.766 Y124.31 E.42516
G1 X142.765 Y124.763 E.01668
G1 X131.066 Y124.763 E.43139
G1 X142.235 Y121.069 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X140.607 Y121.069 E.05401
G1 X138.556 Y123.12 E.09618
G1 X140.472 Y123.12 E.06354
G1 X138.421 Y121.069 E.09618
G1 X132.931 Y121.069 E.18214
G1 X131.25 Y122.75 E.07882
G1 X131.25 Y121.574 E.03899
G1 X132.796 Y123.12 E.07249
G1 X134.424 Y123.12 E.05401
; WIPE_START
G1 X132.796 Y123.12 E-.61876
G1 X132.533 Y122.857 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X139.499 Y119.737 Z3.2 F30000
G1 X144.385 Y117.549 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.126016
G1 F15000
G1 X144.548 Y117.409 E.00146
G1 X144.657 Y117.38 E.00076
; WIPE_START
G1 X144.548 Y117.409 E-.26013
G1 X144.385 Y117.549 E-.49987
; WIPE_END
G1 E-.04 F1800
G1 X147.345 Y117.38 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.125674
G1 F15000
G3 X147.453 Y117.41 I.02 J.133 E.00078
G1 X147.613 Y117.548 E.00142
; WIPE_START
G1 X147.453 Y117.41 E-.49669
G1 X147.345 Y117.38 E-.26331
; WIPE_END
G1 E-.04 F1800
G1 X149.281 Y120.094 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X149.263 Y119.292 E.02468
G1 X149.152 Y118.792 E.01572
G1 X148.927 Y118.24 E.01832
G1 X148.739 Y117.948 E.01066
G1 X161.25 Y117.948 E.38441
G2 X160.837 Y118.83 I2.472 J1.696 E.03004
G1 X160.715 Y119.518 E.02149
G1 X160.714 Y120.094 E.01771
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.713 Y120.677 E.01791
G1 X149.294 Y120.677 E.35085
; Slow Down End
G1 F12000
G1 X149.282 Y120.154 E.01607
G1 X149.665 Y120.094 F30000
G1 F12000
G1 X149.639 Y119.264 E.02552
G2 X149.369 Y118.325 I-2.995 J.351 E.03014
G1 X160.621 Y118.325 E.34574
G1 X160.466 Y118.762 E.01424
G1 X160.337 Y119.518 E.02355
G1 X160.337 Y120.094 E.01773
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.336 Y120.3 E.00632
G1 X149.671 Y120.3 E.3277
; Slow Down End
G1 F12000
G1 X149.667 Y120.154 E.00448
G1 X150.048 Y119.923 F30000
G1 F12000
G1 X159.96 Y119.923 E.30455
G1 X159.969 Y119.394 E.01628
G1 X160.094 Y118.702 E.02158
G1 X149.907 Y118.702 E.31299
G1 X150.015 Y119.237 E.01675
G1 X150.045 Y119.863 E.01927
G1 X150.436 Y119.524 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X159.561 Y119.524 E.3137
G1 X159.615 Y119.102 E.01462
G1 X150.398 Y119.102 E.31687
G1 X150.431 Y119.464 E.0125
G1 X149.223 Y123.441 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.719 Y123.441 E.31851
G1 X160.936 Y123.858 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X149.235 Y123.858 E.43144
G1 X149.235 Y124.31 E.01668
G1 X160.766 Y124.31 E.42516
G1 X160.765 Y124.763 E.01668
G1 X149.066 Y124.763 E.43139
G1 X157.587 Y121.069 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X155.958 Y121.069 E.05401
G1 X153.908 Y123.12 E.09618
G1 X155.824 Y123.12 E.06354
G1 X153.773 Y121.069 E.09618
G1 X152.145 Y121.069 E.05401
; WIPE_START
G1 X153.773 Y121.069 E-.61876
G1 X154.036 Y121.332 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X160.988 Y118.182 Z3.2 F30000
G1 X162.385 Y117.549 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.126016
G1 F15000
G1 X162.548 Y117.409 E.00146
G1 X162.657 Y117.38 E.00076
; WIPE_START
G1 X162.548 Y117.409 E-.26013
G1 X162.385 Y117.549 E-.49987
; WIPE_END
G1 E-.04 F1800
G1 X165.345 Y117.379 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; LINE_WIDTH: 0.125651
G1 F15000
G3 X165.453 Y117.41 I.02 J.135 E.00078
G1 X165.613 Y117.548 E.00142
; WIPE_START
G1 X165.453 Y117.41 E-.49687
G1 X165.345 Y117.379 E-.26313
; WIPE_END
G1 E-.04 F1800
G1 X167.223 Y123.441 Z3.2 F30000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y123.441 E.40987
G1 X182.234 Y123.858 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X167.235 Y123.858 E.55304
G1 X167.235 Y124.31 E.01668
G1 X182.065 Y124.31 E.54679
G1 X182.065 Y124.763 E.01668
G1 X167.066 Y124.763 E.55304
G1 X180.615 Y121.069 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X178.986 Y121.069 E.05401
G1 X176.936 Y123.12 E.09618
G1 X178.851 Y123.12 E.06354
G1 X176.801 Y121.069 E.09618
G1 X171.31 Y121.069 E.18214
G1 X169.26 Y123.12 E.09618
G1 X171.175 Y123.12 E.06354
G1 X169.125 Y121.069 E.09618
G1 X167.497 Y121.069 E.05401
G1 X182.006 Y119.313 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y117.948 E.04193
G1 X166.739 Y117.948 E.46909
G1 X166.927 Y118.24 E.01066
G1 X167.152 Y118.792 E.01832
G1 X167.263 Y119.292 E.01572
G1 X167.294 Y120.677 E.04259
G1 X182.006 Y120.677 E.45204
G1 X182.006 Y119.373 E.04008
G1 X181.629 Y119.313 F30000
G1 F12000
G1 X181.629 Y118.325 E.03034
G1 X167.369 Y118.325 E.43814
G3 X167.639 Y119.264 I-2.724 J1.29 E.03014
G1 X167.671 Y120.3 E.03185
G1 X181.629 Y120.3 E.42887
G1 X181.629 Y119.373 E.0285
G1 X181.252 Y119.313 F30000
G1 F12000
G1 X181.252 Y118.702 E.01876
G1 X167.907 Y118.702 E.41003
G1 X168.015 Y119.237 E.01675
G1 X168.048 Y119.923 E.02112
G1 X181.252 Y119.923 E.4057
G1 X181.252 Y119.373 E.01691
G1 X180.852 Y119.313 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X180.852 Y119.102 E.00725
G1 X168.398 Y119.102 E.42816
G1 X168.436 Y119.524 E.01456
G1 X180.852 Y119.524 E.42684
G1 X180.852 Y119.373 E.00519
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X180.852 Y119.524 E-.05736
G1 X179.003 Y119.524 E-.70264
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 15/33
; update layer progress
M73 L15
M991 S0 P14 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.2 I-1.195 J.231 P1  F30000
G1 X182.398 Y137.069 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X73.602 Y137.069 E3.60896
G1 X73.602 Y135.938 E.03753
G1 X73.602 Y135.903 E.00116
G1 X182.398 Y135.903 E3.60896
G1 X182.398 Y135.938 E.00116
G1 X182.398 Y137.009 E.03554
M204 S250
G1 X182.79 Y137.385 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6851.344
M204 S5000
G1 X182.79 Y137.461 E.00236
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 F5700
G1 X73.21 Y137.461 E3.36709
G1 F6851.344
G1 X73.21 Y137.385 E.00236
G1 F12000
G1 X73.21 Y136.985 E.01229
G1 X73.21 Y136.724 E.008
G1 X73.21 Y136.324 E.01229
G1 F6459.938
G1 X73.21 Y135.924 E.01229
G1 F1800
G1 X73.21 Y135.555 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X73.21 Y135.511 E.00148
G1 X182.79 Y135.511 E3.63497
G1 X182.79 Y135.555 E.00148
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y135.924 E.01134
G1 F6459.938
G1 X182.79 Y136.324 E.01229
G1 F12000
G1 X182.79 Y136.724 E.01229
G1 X182.79 Y137.325 E.01845
; WIPE_START
M204 S10000
G1 X182.79 Y137.461 E-.05194
G1 X180.927 Y137.461 E-.70806
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.4 I.013 J-1.217 P1  F30000
G1 X73.995 Y136.296 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42264
G1 F15000
G1 X73.995 Y136.676 E.01175
G1 X182.005 Y136.676 E3.34206
G1 X182.005 Y136.296 E.01175
G1 X74.055 Y136.296 E3.3402
; WIPE_START
G1 X76.055 Y136.296 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.4 I.416 J1.144 P1  F30000
G1 X125.465 Y118.328 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X125.351 Y118.565 E.00873
G2 X125.098 Y119.743 I2.677 J1.192 E.04028
G1 X125.098 Y124.353 E.15292
G1 X125.098 Y124.753 E.01327
G1 F14655.771
G1 X125.098 Y125.153 E.01327
G1 F6907.886
G1 X125.098 Y125.553 E.01327
G1 F2040
G1 X125.098 Y125.905 E.01167
G1 F600
G1 X112.902 Y125.905 E.40456
G1 F2040
G1 X112.902 Y125.553 E.01167
G1 F6907.886
G1 X112.902 Y125.153 E.01327
G1 F14655.771
G1 X112.902 Y124.753 E.01327
G1 F15476.087
G1 X112.902 Y124.353 E.01327
G1 X112.902 Y119.743 E.15293
G2 X112.536 Y118.328 I-3.092 J.045 E.04895
G1 X125.405 Y118.328 E.42691
; WIPE_START
G1 X125.351 Y118.565 E-.09238
G1 X125.218 Y118.924 E-.14569
G1 X125.15 Y119.2 E-.1079
G1 X125.098 Y119.743 E-.20743
G1 X125.098 Y120.287 E-.2066
; WIPE_END
G1 E-.04 F1800
G1 X117.512 Y119.444 Z3.4 F30000
G1 X107.465 Y118.328 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X107.351 Y118.565 E.00873
G2 X107.098 Y119.743 I2.677 J1.192 E.04028
G1 X107.098 Y124.353 E.15292
G1 X107.098 Y124.753 E.01327
G1 F14655.771
G1 X107.098 Y125.153 E.01327
G1 F6907.886
G1 X107.098 Y125.553 E.01327
G1 F2040
G1 X107.098 Y125.905 E.01167
G1 F600
G1 X94.902 Y125.905 E.40456
G1 F2040
G1 X94.902 Y125.553 E.01167
G1 F6907.886
G1 X94.902 Y125.153 E.01327
G1 F14655.771
G1 X94.902 Y124.753 E.01327
G1 F15476.087
G1 X94.902 Y124.353 E.01327
G1 X94.902 Y119.743 E.15293
G2 X94.536 Y118.328 I-3.092 J.045 E.04895
G1 X107.405 Y118.328 E.42691
; WIPE_START
G1 X107.351 Y118.565 E-.09238
G1 X107.218 Y118.924 E-.14569
G1 X107.15 Y119.2 E-.1079
G1 X107.098 Y119.743 E-.20743
G1 X107.098 Y120.287 E-.2066
; WIPE_END
G1 E-.04 F1800
G1 X99.512 Y119.444 Z3.4 F30000
G1 X89.465 Y118.328 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G2 X89.098 Y119.743 I2.708 J1.458 E.04898
G1 X89.098 Y124.353 E.15292
M73 P54 R13
G1 X89.098 Y124.753 E.01327
G1 F14655.771
G1 X89.098 Y125.153 E.01327
G1 F6907.886
G1 X89.098 Y125.553 E.01327
G1 F2040
G1 X89.098 Y125.905 E.01167
G1 F600
G1 X73.602 Y125.905 E.51403
G1 F2040
G1 X73.602 Y125.553 E.01167
G1 F6907.886
G1 X73.602 Y125.153 E.01327
G1 F14655.771
G1 X73.602 Y124.753 E.01327
G1 F15476.087
G1 X73.602 Y124.353 E.01327
G1 X73.602 Y118.328 E.19988
G1 X81.364 Y118.328 E.25747
G1 X89.405 Y118.328 E.26675
; WIPE_START
G1 X89.263 Y118.785 E-.182
G1 X89.181 Y119.06 E-.10908
G1 X89.122 Y119.379 E-.12347
G1 X89.098 Y119.743 E-.13851
G1 X89.098 Y120.288 E-.20694
; WIPE_END
G1 E-.04 F1800
G1 X96.725 Y120.013 Z3.4 F30000
G1 X143.465 Y118.328 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X143.351 Y118.565 E.00873
G2 X143.098 Y119.743 I2.676 J1.192 E.04028
G1 X143.098 Y124.353 E.15292
G1 X143.098 Y124.753 E.01327
G1 F14655.771
G1 X143.098 Y125.153 E.01327
G1 F6907.886
G1 X143.098 Y125.553 E.01327
G1 F2040
G1 X143.098 Y125.905 E.01167
G1 F600
G1 X130.902 Y125.905 E.40456
G1 F2040
G1 X130.902 Y125.553 E.01167
G1 F6907.886
G1 X130.902 Y125.153 E.01327
G1 F14655.771
G1 X130.902 Y124.753 E.01327
G1 F15476.087
G1 X130.902 Y124.353 E.01327
G1 X130.902 Y119.743 E.15293
G2 X130.536 Y118.328 I-3.092 J.045 E.04895
G1 X143.405 Y118.328 E.42691
; WIPE_START
G1 X143.351 Y118.565 E-.09239
G1 X143.218 Y118.924 E-.14574
G1 X143.15 Y119.2 E-.10787
G1 X143.098 Y119.743 E-.20741
G1 X143.098 Y120.287 E-.20659
; WIPE_END
G1 E-.04 F1800
G1 X150.687 Y119.477 Z3.4 F30000
G1 X161.465 Y118.328 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X161.351 Y118.565 E.00872
G2 X161.098 Y119.743 I2.676 J1.192 E.04028
G1 X161.098 Y124.353 E.15292
G1 X161.098 Y124.753 E.01327
G1 F14655.771
G1 X161.098 Y125.153 E.01327
G1 F6907.886
G1 X161.098 Y125.553 E.01327
G1 F2040
G1 X161.098 Y125.905 E.01167
G1 F600
G1 X148.902 Y125.905 E.40456
G1 F2040
G1 X148.902 Y125.553 E.01167
G1 F6907.886
G1 X148.902 Y125.153 E.01327
G1 F14655.771
G1 X148.902 Y124.753 E.01327
G1 F15476.087
G1 X148.902 Y124.353 E.01327
G1 X148.902 Y119.743 E.15293
G2 X148.536 Y118.328 I-3.093 J.045 E.04895
G1 X161.405 Y118.328 E.42691
; WIPE_START
G1 X161.351 Y118.565 E-.09235
G1 X161.218 Y118.924 E-.14583
G1 X161.15 Y119.2 E-.10781
G1 X161.098 Y119.743 E-.20741
G1 X161.098 Y120.287 E-.20659
; WIPE_END
G1 E-.04 F1800
G1 X168.698 Y119.588 Z3.4 F30000
G1 X182.398 Y118.328 Z3.4
G1 Z3
G1 E.8 F1800
G1 F15476.087
G1 X182.398 Y124.353 E.19988
G1 X182.398 Y124.753 E.01327
G1 F14655.771
G1 X182.398 Y125.153 E.01327
G1 F6907.886
G1 X182.398 Y125.553 E.01327
G1 F2040
G1 X182.398 Y125.905 E.01167
G1 F600
G1 X166.902 Y125.905 E.51403
G1 F2040
G1 X166.902 Y125.553 E.01167
G1 F6907.886
G1 X166.902 Y125.153 E.01327
G1 F14655.771
G1 X166.902 Y124.753 E.01327
G1 F15476.087
G1 X166.902 Y124.353 E.01327
G1 X166.902 Y119.743 E.15293
G2 X166.536 Y118.328 I-3.093 J.045 E.04895
G1 X182.338 Y118.328 E.52419
; WIPE_START
G1 X182.358 Y120.327 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y116.688 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y124.767 E.24822
G1 X182.79 Y125.167 E.01229
G1 F6459.938
G1 X182.79 Y125.567 E.01229
G1 F1800
G1 X182.79 Y125.936 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X182.79 Y126.297 E.01199
G1 X166.51 Y126.297 E.54004
G1 X166.51 Y125.936 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y125.567 E.01134
G1 F6459.938
G1 X166.51 Y125.167 E.01229
G1 F12000
G1 X166.51 Y124.767 E.01229
G1 X166.51 Y119.748 E.15422
G2 X161.49 Y119.748 I-2.51 J.003 E.24211
G1 X161.49 Y124.767 E.15422
G1 X161.49 Y125.167 E.01229
G1 F6459.938
G1 X161.49 Y125.567 E.01229
G1 F1800
G1 X161.49 Y125.936 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y126.297 E.01199
G1 X148.51 Y126.297 E.43057
G1 X148.51 Y125.936 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y125.567 E.01134
G1 F6459.938
G1 X148.51 Y125.167 E.01229
G1 F12000
G1 X148.51 Y124.767 E.01229
G1 X148.51 Y119.748 E.15422
G2 X143.49 Y119.748 I-2.51 J.003 E.24211
G1 X143.49 Y124.767 E.15422
G1 X143.49 Y125.167 E.01229
G1 F6459.938
G1 X143.49 Y125.567 E.01229
G1 F1800
G1 X143.49 Y125.936 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y126.297 E.01199
G1 X130.51 Y126.297 E.43057
G1 X130.51 Y125.936 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y125.567 E.01134
G1 F6459.938
G1 X130.51 Y125.167 E.01229
G1 F12000
G1 X130.51 Y124.767 E.01229
G1 X130.51 Y119.748 E.15422
G2 X125.49 Y119.748 I-2.51 J.003 E.24211
G1 X125.49 Y124.767 E.15422
G1 X125.49 Y125.167 E.01229
G1 F6459.938
G1 X125.49 Y125.567 E.01229
G1 F1800
G1 X125.49 Y125.936 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y126.297 E.01199
G1 X112.51 Y126.297 E.43057
G1 X112.51 Y125.936 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y125.567 E.01134
G1 F6459.938
G1 X112.51 Y125.167 E.01229
G1 F12000
G1 X112.51 Y124.767 E.01229
G1 X112.51 Y119.748 E.15422
G2 X107.49 Y119.748 I-2.51 J.003 E.24211
G1 X107.49 Y124.767 E.15422
G1 X107.49 Y125.167 E.01229
G1 F6459.938
G1 X107.49 Y125.567 E.01229
G1 F1800
G1 X107.49 Y125.936 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y126.297 E.01199
M73 P55 R13
G1 X94.51 Y126.297 E.43057
G1 X94.51 Y125.936 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y125.567 E.01134
G1 F6459.938
G1 X94.51 Y125.167 E.01229
G1 F12000
G1 X94.51 Y124.767 E.01229
G1 X94.51 Y119.748 E.15422
G2 X89.49 Y119.748 I-2.51 J.003 E.24211
G1 X89.49 Y124.767 E.15422
G1 X89.49 Y125.167 E.01229
G1 F6459.938
G1 X89.49 Y125.567 E.01229
G1 F1800
G1 X89.49 Y125.936 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y126.297 E.01199
G1 X73.21 Y126.297 E.54004
G1 X73.21 Y125.936 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y125.567 E.01134
G1 F6459.938
G1 X73.21 Y125.167 E.01229
G1 F12000
G1 X73.21 Y124.767 E.01229
G1 X73.21 Y116.688 E.24822
G1 X78.544 Y116.688 E.1639
G1 X182.73 Y116.688 E3.20134
M204 S10000
G1 X182.583 Y117.392 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.087 Y116.896 E.02155
G1 X181.553 Y116.896
G1 X182.583 Y117.925 E.04472
G1 X182.23 Y118.105
G1 X181.02 Y116.896 E.05255
G1 X180.487 Y116.896
G1 X181.696 Y118.105 E.05255
G1 X181.163 Y118.105
G1 X179.954 Y116.896 E.05255
G1 X179.42 Y116.896
G1 X180.63 Y118.105 E.05255
G1 X180.096 Y118.105
G1 X178.887 Y116.896 E.05255
G1 X178.354 Y116.896
G1 X179.563 Y118.105 E.05255
G1 X179.03 Y118.105
G1 X177.821 Y116.896 E.05255
G1 X177.287 Y116.896
G1 X178.497 Y118.105 E.05255
G1 X177.963 Y118.105
G1 X176.754 Y116.896 E.05255
G1 X176.221 Y116.896
G1 X177.43 Y118.105 E.05255
G1 X176.897 Y118.105
G1 X175.688 Y116.896 E.05255
G1 X175.154 Y116.896
G1 X176.364 Y118.105 E.05255
G1 X175.83 Y118.105
G1 X174.621 Y116.896 E.05255
G1 X174.088 Y116.896
G1 X175.297 Y118.105 E.05255
G1 X174.764 Y118.105
G1 X173.555 Y116.896 E.05255
G1 X173.021 Y116.896
G1 X174.231 Y118.105 E.05255
G1 X173.697 Y118.105
G1 X172.488 Y116.896 E.05255
G1 X171.955 Y116.896
G1 X173.164 Y118.105 E.05255
G1 X172.631 Y118.105
G1 X171.422 Y116.896 E.05255
G1 X170.888 Y116.896
G1 X172.098 Y118.105 E.05255
G1 X171.564 Y118.105
G1 X170.355 Y116.896 E.05255
G1 X169.822 Y116.896
G1 X171.031 Y118.105 E.05255
G1 X170.498 Y118.105
G1 X169.289 Y116.896 E.05255
G1 X168.755 Y116.896
G1 X169.965 Y118.105 E.05255
G1 X169.431 Y118.105
G1 X168.222 Y116.896 E.05255
G1 X167.689 Y116.896
G1 X168.898 Y118.105 E.05255
G1 X168.365 Y118.105
G1 X167.156 Y116.896 E.05255
G1 X166.622 Y116.896
G1 X167.832 Y118.105 E.05255
G1 X167.298 Y118.105
G1 X166.089 Y116.896 E.05255
G1 X165.556 Y116.896
G1 X166.765 Y118.105 E.05255
G1 X166.232 Y118.105
G1 X165.022 Y116.896 E.05255
; WIPE_START
M204 S10000
G1 X166.232 Y118.105 E-.64989
G1 X166.522 Y118.105 E-.11011
; WIPE_END
G1 E-.04 F1800
G1 X161.823 Y116.896 Z3.4 F30000
G1 Z3
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X162.447 Y117.52 E.02713
G1 X162.152 Y117.758
G1 X161.29 Y116.896 E.03747
G1 X160.756 Y116.896
G1 X161.894 Y118.033 E.04944
G1 X161.432 Y118.105
G1 X160.223 Y116.896 E.05255
G1 X159.69 Y116.896
G1 X160.899 Y118.105 E.05255
G1 X160.366 Y118.105
G1 X159.157 Y116.896 E.05255
G1 X158.623 Y116.896
G1 X159.833 Y118.105 E.05255
M73 P55 R12
G1 X159.299 Y118.105
G1 X158.09 Y116.896 E.05255
G1 X157.557 Y116.896
G1 X158.766 Y118.105 E.05255
G1 X158.233 Y118.105
G1 X157.024 Y116.896 E.05255
G1 X156.49 Y116.896
G1 X157.7 Y118.105 E.05255
G1 X157.166 Y118.105
G1 X155.957 Y116.896 E.05255
G1 X155.424 Y116.896
G1 X156.633 Y118.105 E.05255
G1 X156.1 Y118.105
G1 X154.891 Y116.896 E.05255
G1 X154.357 Y116.896
G1 X155.567 Y118.105 E.05255
G1 X155.033 Y118.105
G1 X153.824 Y116.896 E.05255
G1 X153.291 Y116.896
G1 X154.5 Y118.105 E.05255
G1 X153.967 Y118.105
G1 X152.758 Y116.896 E.05255
G1 X152.224 Y116.896
G1 X153.434 Y118.105 E.05255
G1 X152.9 Y118.105
G1 X151.691 Y116.896 E.05255
G1 X151.158 Y116.896
G1 X152.367 Y118.105 E.05255
G1 X151.834 Y118.105
G1 X150.625 Y116.896 E.05255
G1 X150.091 Y116.896
G1 X151.301 Y118.105 E.05255
G1 X150.767 Y118.105
G1 X149.558 Y116.896 E.05255
G1 X149.025 Y116.896
G1 X150.234 Y118.105 E.05255
G1 X149.701 Y118.105
G1 X148.491 Y116.896 E.05255
G1 X147.958 Y116.896
G1 X149.168 Y118.105 E.05255
G1 X148.634 Y118.105
G1 X147.425 Y116.896 E.05255
; WIPE_START
M204 S10000
G1 X148.634 Y118.105 E-.64989
G1 X148.924 Y118.105 E-.11011
; WIPE_END
G1 E-.04 F1800
G1 X156.541 Y117.619 Z3.4 F30000
G1 X163.107 Y117.2 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.411345
G1 F15000
G1 X162.941 Y117.063 E.00647
G1 X162.754 Y117.063 E.00562
; LINE_WIDTH: 0.43199
G1 X162.676 Y117.08 E.00251
; LINE_WIDTH: 0.46417
G1 F14955.49
G1 X162.599 Y117.096 E.00272
; LINE_WIDTH: 0.45996
G1 F15000
G1 X162.607 Y117.133 E.00129
; LINE_WIDTH: 0.419403
G1 X162.615 Y117.17 E.00116
; LINE_WIDTH: 0.378846
G1 X162.624 Y117.207 E.00104
; LINE_WIDTH: 0.338289
G1 X162.632 Y117.244 E.00091
; LINE_WIDTH: 0.295611
G1 X162.643 Y117.284 E.00086
; LINE_WIDTH: 0.250811
G1 X162.638 Y117.315 E.00052
; LINE_WIDTH: 0.21329
G1 X162.636 Y117.331 E.00023
; LINE_WIDTH: 0.175967
G1 X162.619 Y117.37 E.00046
; LINE_WIDTH: 0.127603
G1 X162.602 Y117.408 E.00029
; LINE_WIDTH: 0.0962547
G1 X162.537 Y117.459 E.00036
; WIPE_START
G1 X162.602 Y117.408 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X154.974 Y117.143 Z3.4 F30000
G1 X147.339 Y116.877 Z3.4
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.245611
G1 F15000
G1 X147.281 Y116.924 E.00122
; LINE_WIDTH: 0.294271
G1 X147.223 Y116.97 E.00152
; LINE_WIDTH: 0.342931
G1 X147.166 Y117.017 E.00181
; LINE_WIDTH: 0.39159
G1 X147.108 Y117.063 E.00211
; LINE_WIDTH: 0.396847
G1 X147.3 Y117.183 E.00652
; LINE_WIDTH: 0.358724
G1 X147.492 Y117.302 E.00582
; LINE_WIDTH: 0.320602
G1 X147.684 Y117.422 E.00512
G1 X147.662 Y117.625 F30000
; LINE_WIDTH: 0.277779
G1 F15000
G1 X147.021 Y116.877 E.01886
; WIPE_START
G1 X147.662 Y117.625 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X148.268 Y118.124 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.194304
G1 F15000
G1 X147.891 Y117.727 E.00676
G1 X147.583 Y117.451 E.0051
; LINE_WIDTH: 0.24202
G1 X147.476 Y117.364 E.00224
; LINE_WIDTH: 0.269661
G1 X147.367 Y117.28 E.00254
G1 X147.221 Y117.342 E.00292
; WIPE_START
G1 X147.367 Y117.28 E-.40643
G1 X147.476 Y117.364 E-.35357
; WIPE_END
G1 E-.04 F1800
G1 X144.225 Y116.896 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X144.696 Y117.366 E.02045
G1 X144.372 Y117.575
G1 X143.692 Y116.896 E.02952
G1 X143.159 Y116.896
G1 X144.086 Y117.823 E.04028
G1 X143.833 Y118.103
G1 X142.626 Y116.896 E.05246
G1 X142.092 Y116.896
G1 X143.302 Y118.105 E.05255
G1 X142.768 Y118.105
G1 X141.559 Y116.896 E.05255
G1 X141.026 Y116.896
G1 X142.235 Y118.105 E.05255
G1 X141.702 Y118.105
G1 X140.493 Y116.896 E.05255
G1 X139.959 Y116.896
G1 X141.169 Y118.105 E.05255
G1 X140.635 Y118.105
G1 X139.426 Y116.896 E.05255
G1 X138.893 Y116.896
G1 X140.102 Y118.105 E.05255
G1 X139.569 Y118.105
G1 X138.36 Y116.896 E.05255
G1 X137.826 Y116.896
G1 X139.036 Y118.105 E.05255
G1 X138.502 Y118.105
G1 X137.293 Y116.896 E.05255
G1 X136.76 Y116.896
G1 X137.969 Y118.105 E.05255
G1 X137.436 Y118.105
G1 X136.227 Y116.896 E.05255
G1 X135.693 Y116.896
G1 X136.903 Y118.105 E.05255
G1 X136.369 Y118.105
G1 X135.16 Y116.896 E.05255
G1 X134.627 Y116.896
G1 X135.836 Y118.105 E.05255
G1 X135.303 Y118.105
G1 X134.094 Y116.896 E.05255
G1 X133.56 Y116.896
G1 X134.77 Y118.105 E.05255
G1 X134.236 Y118.105
G1 X133.027 Y116.896 E.05255
G1 X132.494 Y116.896
G1 X133.703 Y118.105 E.05255
G1 X133.17 Y118.105
G1 X131.961 Y116.896 E.05255
G1 X131.427 Y116.896
G1 X132.637 Y118.105 E.05255
G1 X132.103 Y118.105
G1 X130.894 Y116.896 E.05255
G1 X130.361 Y116.896
G1 X131.57 Y118.105 E.05255
G1 X131.037 Y118.105
G1 X129.827 Y116.896 E.05255
G1 X129.294 Y116.896
G1 X130.504 Y118.105 E.05255
; WIPE_START
M204 S10000
G1 X129.294 Y116.896 E-.64989
G1 X129.584 Y116.896 E-.11011
; WIPE_END
G1 E-.04 F1800
G1 X129.232 Y116.877 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.238309
G1 F15000
G1 X129.161 Y116.924 E.00134
; LINE_WIDTH: 0.272394
G1 X129.091 Y116.97 E.00158
; LINE_WIDTH: 0.306478
G1 X129.021 Y117.017 E.00181
; LINE_WIDTH: 0.318929
G2 X129.042 Y117.107 I.05 J.036 E.00236
G1 X129.419 Y117.287 E.0094
G1 X130.205 Y118.124 F30000
; LINE_WIDTH: 0.10192
G1 F15000
G1 X129.856 Y117.758 E.00243
G1 X129.557 Y117.49 E.00193
; LINE_WIDTH: 0.148314
G1 X129.452 Y117.405 E.00116
; LINE_WIDTH: 0.185199
G1 X129.334 Y117.314 E.00173
G3 X129.308 Y117.267 I.017 J-.04 E.00068
; LINE_WIDTH: 0.163121
G1 X128.977 Y116.877 E.00501
; WIPE_START
G1 X129.308 Y117.267 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X126.095 Y116.896 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X126.613 Y117.414 E.02252
G1 X126.298 Y117.632
G1 X125.561 Y116.896 E.03201
G1 X125.028 Y116.896
G1 X126.021 Y117.889 E.04316
G1 X125.704 Y118.105
G1 X124.495 Y116.896 E.05255
G1 X123.962 Y116.896
G1 X125.171 Y118.105 E.05255
G1 X124.638 Y118.105
G1 X123.428 Y116.896 E.05255
G1 X122.895 Y116.896
G1 X124.104 Y118.105 E.05255
G1 X123.571 Y118.105
G1 X122.362 Y116.896 E.05255
G1 X121.829 Y116.896
M73 P56 R12
G1 X123.038 Y118.105 E.05255
G1 X122.505 Y118.105
G1 X121.295 Y116.896 E.05255
G1 X120.762 Y116.896
G1 X121.971 Y118.105 E.05255
G1 X121.438 Y118.105
G1 X120.229 Y116.896 E.05255
G1 X119.696 Y116.896
G1 X120.905 Y118.105 E.05255
G1 X120.372 Y118.105
G1 X119.162 Y116.896 E.05255
G1 X118.629 Y116.896
G1 X119.838 Y118.105 E.05255
G1 X119.305 Y118.105
G1 X118.096 Y116.896 E.05255
G1 X117.563 Y116.896
G1 X118.772 Y118.105 E.05255
G1 X118.239 Y118.105
G1 X117.029 Y116.896 E.05255
G1 X116.496 Y116.896
G1 X117.705 Y118.105 E.05255
G1 X117.172 Y118.105
G1 X115.963 Y116.896 E.05255
G1 X115.43 Y116.896
G1 X116.639 Y118.105 E.05255
G1 X116.106 Y118.105
G1 X114.896 Y116.896 E.05255
G1 X114.363 Y116.896
G1 X115.572 Y118.105 E.05255
G1 X115.039 Y118.105
G1 X113.83 Y116.896 E.05255
G1 X113.296 Y116.896
G1 X114.506 Y118.105 E.05255
G1 X113.973 Y118.105
G1 X112.763 Y116.896 E.05255
G1 X112.23 Y116.896
G1 X113.439 Y118.105 E.05255
G1 X112.906 Y118.105
G1 X111.697 Y116.896 E.05255
G1 X111.163 Y116.896
G1 X112.373 Y118.105 E.05255
; WIPE_START
M204 S10000
G1 X111.163 Y116.896 E-.6499
G1 X111.453 Y116.896 E-.11011
; WIPE_END
G1 E-.04 F1800
G1 X113.292 Y120.866 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G2 X113.288 Y119.563 I-126.18 J-.326 E.04003
G1 X113.126 Y118.72 E.0264
G1 X124.883 Y118.72 E.36126
G2 X124.796 Y118.985 I1.423 J.61 E.00859
G1 X124.709 Y119.597 E.01898
G1 X124.708 Y120.866 E.039
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.708 Y121.449 E.01791
G1 X113.292 Y121.449 E.35078
; Slow Down End
G1 F12000
G1 X113.292 Y120.926 E.01607
G1 X113.669 Y120.866 F30000
G1 F12000
G1 X113.668 Y119.595 E.03905
G1 X113.591 Y119.097 E.01549
G1 X124.399 Y119.097 E.3321
G1 X124.332 Y119.596 E.01549
G1 X124.331 Y120.866 E.03901
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.331 Y121.072 E.00632
G1 X113.669 Y121.072 E.32762
; Slow Down End
G1 F12000
G1 X113.669 Y120.926 E.00448
G1 X114.046 Y120.695 F30000
G1 F12000
G1 X123.954 Y120.695 E.30446
G1 X123.964 Y119.474 E.03751
G1 X114.035 Y119.474 E.30509
G3 X114.046 Y120.635 I-34.547 J.903 E.03567
G1 X114.445 Y120.295 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X123.555 Y120.295 E.3132
G1 X123.555 Y119.873 E.0145
G1 X114.445 Y119.873 E.31322
G1 X114.445 Y120.235 E.01244
G1 X113.223 Y124.213 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.717 Y124.213 E.31847
G1 X124.935 Y124.629 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X113.235 Y124.629 E.43141
G1 X113.235 Y125.081 E.01668
G1 X124.765 Y125.081 E.42513
G1 X124.765 Y125.534 E.01668
G1 X113.065 Y125.534 E.43137
; WIPE_START
G1 X115.065 Y125.534 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.4 I.135 J-1.209 P1  F30000
G1 X106.935 Y124.629 Z3.4
G1 Z3
G1 E.8 F1800
G1 F3000
G1 X95.235 Y124.629 E.43141
G1 X95.235 Y125.081 E.01668
G1 X106.765 Y125.081 E.42513
G1 X106.765 Y125.534 E.01668
G1 X95.065 Y125.534 E.43137
G1 X95.223 Y124.213 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.717 Y124.213 E.31847
G1 X104.492 Y123.891 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X102.863 Y123.891 E.05401
G1 X100.813 Y121.841 E.09618
G1 X101.455 Y121.841 E.02131
G1 X99.405 Y123.891 E.09618
G1 X97.777 Y123.891 E.05401
G1 X95.292 Y120.866 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G2 X95.288 Y119.563 I-126.18 J-.326 E.04003
G1 X95.126 Y118.72 E.0264
G1 X106.883 Y118.72 E.36126
G2 X106.796 Y118.985 I1.423 J.61 E.00859
G1 X106.709 Y119.597 E.01898
G1 X106.708 Y120.866 E.039
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.708 Y121.449 E.01791
G1 X95.292 Y121.449 E.35078
; Slow Down End
G1 F12000
G1 X95.292 Y120.926 E.01607
G1 X95.669 Y120.866 F30000
G1 F12000
G1 X95.668 Y119.595 E.03905
G1 X95.591 Y119.097 E.01549
G1 X106.399 Y119.097 E.3321
G1 X106.332 Y119.596 E.01549
G1 X106.331 Y120.866 E.03901
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.331 Y121.072 E.00632
G1 X95.669 Y121.072 E.32762
; Slow Down End
G1 F12000
G1 X95.669 Y120.926 E.00448
G1 X96.046 Y120.695 F30000
G1 F12000
G1 X105.954 Y120.695 E.30446
G1 X105.964 Y119.474 E.03751
G1 X96.035 Y119.474 E.30509
G3 X96.046 Y120.635 I-34.547 J.903 E.03567
G1 X96.445 Y120.295 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X105.555 Y120.295 E.3132
G1 X105.555 Y119.873 E.0145
G1 X96.445 Y119.873 E.31322
G1 X96.445 Y120.235 E.01244
; WIPE_START
G1 X96.445 Y119.873 E-.13752
G1 X98.083 Y119.873 E-.62248
; WIPE_END
G1 E-.04 F1800
G1 X90.962 Y117.126 Z3.4 F30000
G1 X90.366 Y116.896 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X90.789 Y117.318 E.01835
G1 X90.453 Y117.516
G1 X89.833 Y116.896 E.02694
G1 X89.3 Y116.896
G1 X90.157 Y117.753 E.03726
G1 X89.899 Y118.028
G1 X88.767 Y116.896 E.0492
G1 X88.233 Y116.896
G1 X89.443 Y118.105 E.05255
G1 X88.909 Y118.105
G1 X87.7 Y116.896 E.05255
G1 X87.167 Y116.896
G1 X88.376 Y118.105 E.05255
G1 X87.843 Y118.105
G1 X86.634 Y116.896 E.05255
G1 X86.1 Y116.896
G1 X87.31 Y118.105 E.05255
G1 X86.776 Y118.105
G1 X85.567 Y116.896 E.05255
G1 X85.034 Y116.896
G1 X86.243 Y118.105 E.05255
G1 X85.71 Y118.105
G1 X84.501 Y116.896 E.05255
G1 X83.967 Y116.896
G1 X85.177 Y118.105 E.05255
G1 X84.643 Y118.105
G1 X83.434 Y116.896 E.05255
G1 X82.901 Y116.896
G1 X84.11 Y118.105 E.05255
G1 X83.577 Y118.105
G1 X82.368 Y116.896 E.05255
G1 X81.834 Y116.896
G1 X83.044 Y118.105 E.05255
G1 X82.51 Y118.105
G1 X81.301 Y116.896 E.05255
G1 X80.768 Y116.896
G1 X81.977 Y118.105 E.05255
G1 X81.444 Y118.105
G1 X80.235 Y116.896 E.05255
G1 X79.701 Y116.896
G1 X80.911 Y118.105 E.05255
G1 X80.377 Y118.105
G1 X79.168 Y116.896 E.05255
G1 X78.635 Y116.896
G1 X79.844 Y118.105 E.05255
G1 X79.311 Y118.105
G1 X78.102 Y116.896 E.05255
G1 X77.568 Y116.896
G1 X78.778 Y118.105 E.05255
G1 X78.244 Y118.105
G1 X77.035 Y116.896 E.05255
G1 X76.502 Y116.896
G1 X77.711 Y118.105 E.05255
G1 X77.178 Y118.105
G1 X75.968 Y116.896 E.05255
G1 X75.435 Y116.896
G1 X76.645 Y118.105 E.05255
G1 X76.111 Y118.105
G1 X74.902 Y116.896 E.05255
G1 X74.369 Y116.896
G1 X75.578 Y118.105 E.05255
G1 X75.045 Y118.105
G1 X73.835 Y116.896 E.05255
G1 X73.417 Y117.011
G1 X74.512 Y118.105 E.04754
G1 X73.978 Y118.105
G1 X73.417 Y117.544 E.02437
; WIPE_START
M204 S10000
G1 X73.978 Y118.105 E-.30141
G1 X74.512 Y118.105 E-.20264
G1 X74.035 Y117.629 E-.25595
; WIPE_END
G1 E-.04 F1800
G1 X73.994 Y120.866 Z3.4 F30000
G1 Z3
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X73.994 Y118.72 E.06595
G1 X88.89 Y118.72 E.45771
G2 X88.709 Y119.594 I2.338 J.941 E.02757
G1 X88.708 Y120.866 E.0391
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.708 Y121.449 E.01791
G1 X73.994 Y121.449 E.45211
; Slow Down End
G1 F12000
G1 X73.994 Y120.926 E.01607
G1 X74.371 Y120.866 F30000
G1 F12000
G1 X74.371 Y119.097 E.05436
G1 X88.388 Y119.097 E.43069
G1 X88.332 Y119.593 E.01536
G1 X88.331 Y120.866 E.0391
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.331 Y121.072 E.00632
G1 X74.371 Y121.072 E.42894
; Slow Down End
G1 F12000
G1 X74.371 Y120.926 E.00448
G1 X74.748 Y120.695 F30000
G1 F12000
G1 X87.954 Y120.695 E.40578
G1 X87.963 Y119.474 E.03751
G1 X74.748 Y119.474 E.40603
G1 X74.748 Y120.635 E.03567
G1 X75.148 Y120.295 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X87.555 Y120.295 E.42655
G1 X87.555 Y119.873 E.0145
G1 X75.148 Y119.873 E.42656
G1 X75.148 Y120.235 E.01244
G1 X73.923 Y124.212 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.718 Y124.212 E.40989
G1 X88.935 Y124.629 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y124.629 E.55306
G1 X73.935 Y125.081 E.01668
G1 X88.765 Y125.081 E.54679
G1 X88.765 Y125.534 E.01668
G1 X73.766 Y125.534 E.55304
G1 X88.751 Y123.502 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.751 Y123.891 E.0129
G1 X87.511 Y123.891 E.04111
G1 X85.461 Y121.841 E.09618
G1 X86.103 Y121.841 E.02131
G1 X84.053 Y123.891 E.09618
G1 X79.835 Y123.891 E.13991
G1 X77.785 Y121.841 E.09618
G1 X78.427 Y121.841 E.02131
G1 X76.377 Y123.891 E.09618
G1 X74.749 Y123.891 E.05401
; WIPE_START
G1 X76.377 Y123.891 E-.61876
G1 X76.64 Y123.628 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X84.102 Y122.024 Z3.4 F30000
G1 X107.964 Y116.896 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X108.532 Y117.464 E.02469
G1 X108.227 Y117.692
G1 X107.431 Y116.896 E.03458
G1 X106.897 Y116.896
G1 X107.96 Y117.958 E.04618
G1 X107.573 Y118.105
G1 X106.364 Y116.896 E.05255
G1 X105.831 Y116.896
G1 X107.04 Y118.105 E.05255
G1 X106.507 Y118.105
G1 X105.298 Y116.896 E.05255
G1 X104.764 Y116.896
G1 X105.974 Y118.105 E.05255
G1 X105.44 Y118.105
G1 X104.231 Y116.896 E.05255
G1 X103.698 Y116.896
G1 X104.907 Y118.105 E.05255
G1 X104.374 Y118.105
G1 X103.165 Y116.896 E.05255
G1 X102.631 Y116.896
G1 X103.841 Y118.105 E.05255
G1 X103.307 Y118.105
G1 X102.098 Y116.896 E.05255
G1 X101.565 Y116.896
G1 X102.774 Y118.105 E.05255
G1 X102.241 Y118.105
G1 X101.032 Y116.896 E.05255
G1 X100.498 Y116.896
G1 X101.708 Y118.105 E.05255
G1 X101.174 Y118.105
G1 X99.965 Y116.896 E.05255
G1 X99.432 Y116.896
G1 X100.641 Y118.105 E.05255
G1 X100.108 Y118.105
G1 X98.899 Y116.896 E.05255
G1 X98.365 Y116.896
G1 X99.575 Y118.105 E.05255
G1 X99.041 Y118.105
G1 X97.832 Y116.896 E.05255
G1 X97.299 Y116.896
G1 X98.508 Y118.105 E.05255
G1 X97.975 Y118.105
G1 X96.766 Y116.896 E.05255
G1 X96.232 Y116.896
G1 X97.442 Y118.105 E.05255
G1 X96.908 Y118.105
G1 X95.699 Y116.896 E.05255
G1 X95.166 Y116.896
G1 X96.375 Y118.105 E.05255
G1 X95.842 Y118.105
G1 X94.632 Y116.896 E.05255
G1 X94.099 Y116.896
G1 X95.309 Y118.105 E.05255
G1 X94.775 Y118.105
G1 X93.566 Y116.896 E.05255
; WIPE_START
M204 S10000
G1 X94.775 Y118.105 E-.64989
G1 X95.065 Y118.105 E-.11011
; WIPE_END
G1 E-.04 F1800
G1 X102.682 Y117.614 Z3.4 F30000
G1 X109.107 Y117.2 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.413214
G1 F15000
G1 X108.941 Y117.063 E.00651
G2 X108.68 Y117.071 I-.094 J1.321 E.00789
; LINE_WIDTH: 0.408893
G1 X108.682 Y117.103 E.00098
; LINE_WIDTH: 0.365584
G1 X108.684 Y117.136 E.00086
; LINE_WIDTH: 0.322276
G1 X108.686 Y117.169 E.00074
; LINE_WIDTH: 0.278967
G1 X108.688 Y117.201 E.00063
; LINE_WIDTH: 0.235658
G1 X108.69 Y117.234 E.00051
; LINE_WIDTH: 0.192349
G1 X108.692 Y117.267 E.0004
; LINE_WIDTH: 0.158222
G1 X108.717 Y117.317 E.00052
; LINE_WIDTH: 0.121497
G3 X108.67 Y117.368 I-.128 J-.07 E.00045
; LINE_WIDTH: 0.0952723
G1 X108.608 Y117.416 E.00034
G1 X94.336 Y118.124 F30000
; LINE_WIDTH: 0.293885
G1 F15000
G1 X93.926 Y117.692 E.01218
G1 X93.61 Y117.409 E.00867
; LINE_WIDTH: 0.343075
G1 X93.501 Y117.32 E.00344
; LINE_WIDTH: 0.371482
G1 X93.417 Y117.256 E.00284
; LINE_WIDTH: 0.360531
G1 X93.39 Y117.269 E.00077
; LINE_WIDTH: 0.311203
G1 X93.364 Y117.282 E.00065
; LINE_WIDTH: 0.265207
G1 X93.221 Y117.342 E.0028
; WIPE_START
G1 X93.364 Y117.282 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X100.827 Y118.878 Z3.4 F30000
G1 X124.262 Y123.891 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X124.751 Y123.891 E.0162
G1 X124.751 Y122.751 E.03781
G1 X123.841 Y121.841 E.04271
G1 X124.483 Y121.841 E.02131
G1 X122.433 Y123.891 E.09618
G1 X118.215 Y123.891 E.13991
G1 X116.165 Y121.841 E.09618
G1 X116.807 Y121.841 E.02131
G1 X114.757 Y123.891 E.09618
G1 X113.249 Y123.891 E.05001
G1 X113.249 Y123.77 E.004
; WIPE_START
G1 X113.249 Y123.891 E-.04584
G1 X114.757 Y123.891 E-.57292
G1 X115.02 Y123.628 E-.14124
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.4 I-.144 J1.208 P1  F30000
G1 X131.065 Y125.534 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X142.765 Y125.534 E.43137
G1 X142.765 Y125.081 E.01668
G1 X131.235 Y125.081 E.42513
G1 X131.235 Y124.629 E.01668
G1 X142.935 Y124.629 E.43141
G1 X142.751 Y123.771 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X142.751 Y123.891 E.004
G1 X141.243 Y123.891 E.05001
G1 X139.193 Y121.841 E.09618
G1 X139.835 Y121.841 E.02131
G1 X137.785 Y123.891 E.09618
G1 X133.567 Y123.891 E.13991
G1 X131.517 Y121.841 E.09618
G1 X132.159 Y121.841 E.02131
G1 X131.249 Y122.751 E.04271
G1 X131.249 Y123.891 E.03781
G1 X131.738 Y123.891 E.0162
G1 X131.223 Y124.213 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.717 Y124.213 E.31847
; WIPE_START
G1 X140.717 Y124.213 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.4 I-.19 J1.202 P1  F30000
G1 X149.065 Y125.534 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X160.765 Y125.534 E.43137
G1 X160.765 Y125.081 E.01668
G1 X149.235 Y125.081 E.42513
G1 X149.235 Y124.629 E.01668
G1 X160.935 Y124.629 E.43141
G1 X158.223 Y123.891 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X156.595 Y123.891 E.05401
G1 X154.545 Y121.841 E.09618
G1 X155.187 Y121.841 E.02131
G1 X153.137 Y123.891 E.09618
G1 X151.508 Y123.891 E.05401
G1 X149.223 Y124.213 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.717 Y124.213 E.31847
; WIPE_START
G1 X158.717 Y124.213 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.4 I-.19 J1.202 P1  F30000
G1 X167.065 Y125.534 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X182.065 Y125.534 E.55304
G1 X182.065 Y125.081 E.01668
G1 X167.235 Y125.081 E.54679
G1 X167.235 Y124.629 E.01668
G1 X182.234 Y124.629 E.55306
G1 X181.251 Y123.891 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.623 Y123.891 E.05401
G1 X177.573 Y121.841 E.09618
G1 X178.215 Y121.841 E.02131
G1 X176.165 Y123.891 E.09618
G1 X171.947 Y123.891 E.13991
G1 X169.897 Y121.841 E.09618
G1 X170.539 Y121.841 E.02131
G1 X168.489 Y123.891 E.09618
G1 X167.249 Y123.891 E.04111
G1 X167.249 Y123.502 E.0129
G1 X167.223 Y124.213 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y124.212 E.40988
G1 X182.006 Y120.084 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y118.72 E.04193
G1 X167.126 Y118.72 E.45722
G1 X167.288 Y119.563 E.0264
G3 X167.292 Y121.449 I-182.951 J1.299 E.05794
G1 X182.006 Y121.449 E.45211
G1 X182.006 Y120.144 E.04008
G1 X181.629 Y120.084 F30000
G1 F12000
G1 X181.629 Y119.097 E.03034
G1 X167.591 Y119.097 E.43134
G1 X167.668 Y119.595 E.01549
G1 X167.669 Y121.072 E.04538
G1 X181.629 Y121.072 E.42894
G1 X181.629 Y120.144 E.0285
G1 X181.252 Y120.084 F30000
G1 F12000
G1 X181.252 Y119.474 E.01876
G1 X168.035 Y119.474 E.40611
G3 X168.046 Y120.695 I-36.333 J.935 E.03752
G1 X181.252 Y120.695 E.40578
G1 X181.252 Y120.144 E.01691
G1 X180.852 Y120.084 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X180.852 Y119.873 E.00725
G1 X168.445 Y119.873 E.42656
G1 X168.445 Y120.295 E.0145
M73 P57 R12
G1 X180.852 Y120.295 E.42655
G1 X180.852 Y120.144 E.00519
; WIPE_START
G1 X180.852 Y120.295 E-.05736
G1 X179.003 Y120.295 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X171.372 Y120.442 Z3.4 F30000
G1 X149.292 Y120.866 Z3.4
G1 Z3
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G2 X149.288 Y119.563 I-126.505 J-.324 E.04003
G1 X149.126 Y118.72 E.0264
G1 X160.883 Y118.72 E.36126
G2 X160.796 Y118.985 I1.418 J.609 E.00859
G1 X160.709 Y119.596 E.01897
G1 X160.708 Y120.866 E.039
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.708 Y121.449 E.01791
G1 X149.292 Y121.449 E.35078
; Slow Down End
G1 F12000
G1 X149.292 Y120.926 E.01607
G1 X149.669 Y120.866 F30000
G1 F12000
G1 X149.668 Y119.595 E.03906
G1 X149.591 Y119.097 E.01549
G1 X160.399 Y119.097 E.3321
G1 X160.332 Y119.596 E.01549
G1 X160.331 Y120.866 E.03901
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.331 Y121.072 E.00632
G1 X149.669 Y121.072 E.32762
; Slow Down End
G1 F12000
G1 X149.669 Y120.926 E.00448
G1 X150.046 Y120.695 F30000
G1 F12000
G1 X159.954 Y120.695 E.30446
G1 X159.964 Y119.474 E.03751
G1 X150.035 Y119.474 E.30509
G3 X150.046 Y120.635 I-34.549 J.903 E.03567
G1 X150.445 Y120.295 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X159.555 Y120.295 E.3132
G1 X159.555 Y119.873 E.0145
G1 X150.445 Y119.873 E.31321
G1 X150.445 Y120.235 E.01244
; WIPE_START
G1 X150.445 Y119.873 E-.13753
G1 X152.083 Y119.873 E-.62247
; WIPE_END
G1 E-.04 F1800
G1 X144.472 Y120.45 Z3.4 F30000
G1 X131.292 Y121.449 Z3.4
G1 Z3
G1 E.8 F1800
; Slow Down Start
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.292 Y120.866 E.01791
; Slow Down End
G1 F12000
G2 X131.288 Y119.563 I-126.505 J-.324 E.04003
G1 X131.126 Y118.72 E.0264
G1 X142.883 Y118.72 E.36125
G2 X142.796 Y118.985 I1.419 J.609 E.00859
G1 X142.709 Y119.597 E.01897
G1 X142.708 Y120.866 E.039
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.708 Y121.449 E.01791
; Slow Down End
G1 F12000
G1 X131.352 Y121.449 E.34894
G1 X131.669 Y120.866 F30000
G1 F12000
G1 X131.668 Y119.595 E.03906
G1 X131.591 Y119.097 E.01549
G1 X142.399 Y119.097 E.3321
G1 X142.332 Y119.596 E.01549
G1 X142.331 Y120.866 E.03901
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.331 Y121.072 E.00632
G1 X131.669 Y121.072 E.32762
; Slow Down End
G1 F12000
G1 X131.669 Y120.926 E.00448
G1 X132.046 Y120.695 F30000
G1 F12000
G1 X141.954 Y120.695 E.30446
G1 X141.964 Y119.474 E.03751
G1 X132.035 Y119.474 E.30509
G3 X132.046 Y120.635 I-34.548 J.903 E.03567
G1 X132.445 Y120.295 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X141.555 Y120.295 E.3132
G1 X141.555 Y119.873 E.0145
G1 X132.445 Y119.873 E.31321
G1 X132.445 Y120.235 E.01244
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X132.445 Y119.873 E-.13753
G1 X134.083 Y119.873 E-.62247
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 16/33
; update layer progress
M73 L16
M991 S0 P15 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.4 I-.409 J1.146 P1  F30000
G1 X182.398 Y137.131 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X73.602 Y137.131 E3.60896
G1 X73.602 Y135.483 E.05466
G1 X73.602 Y135.448 E.00116
G1 X182.398 Y135.448 E3.60896
G1 X182.398 Y135.483 E.00116
G1 X182.398 Y137.071 E.05267
M204 S250
G1 X182.79 Y137.502 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y137.523 E.00064
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y137.523 E3.36709
G1 X73.21 Y137.502 E.00064
G1 X73.21 Y136.27 E.03788
G1 X73.21 Y135.87 E.01229
G1 F6459.938
G1 X73.21 Y135.47 E.01229
G1 F1800
G1 X73.21 Y135.101 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X73.21 Y135.056 E.00148
G1 X182.79 Y135.056 E3.63497
G1 X182.79 Y135.101 E.00148
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y135.47 E.01134
G1 F6459.938
G1 X182.79 Y135.87 E.01229
G1 F12000
G1 X182.79 Y136.27 E.01229
G1 X182.79 Y137.442 E.03603
; WIPE_START
M204 S10000
G1 X182.79 Y137.523 E-.03067
G1 X180.871 Y137.523 E-.72933
; WIPE_END
G1 E-.04 F1800
G1 X173.239 Y137.403 Z3.6 F30000
G1 X73.994 Y135.84 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X73.994 Y136.739 E.02761
G1 X182.006 Y136.739 E3.31882
G1 X182.006 Y135.84 E.02761
G1 X74.054 Y135.84 E3.31697
G1 X74.443 Y136.29 F30000
; LINE_WIDTH: 0.56446
G1 F12079.611
G1 X181.497 Y136.29 E4.54964
; WIPE_START
G1 X179.497 Y136.29 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.6 I.367 J-1.16 P1  F30000
G1 X125.167 Y119.099 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X125.123 Y119.37 E.00911
G2 X125.098 Y119.743 I2.702 J.369 E.01241
G1 X125.098 Y125.124 E.17851
G1 X125.098 Y125.524 E.01327
G1 F14655.771
G1 X125.098 Y125.924 E.01327
G1 F6907.886
G1 X125.098 Y126.324 E.01327
G1 F2040
G1 X125.098 Y126.676 E.01167
G1 F600
G1 X112.902 Y126.676 E.40456
G1 F2040
G1 X112.902 Y126.324 E.01167
G1 F6907.886
G1 X112.902 Y125.924 E.01327
G1 F14655.771
G1 X112.902 Y125.524 E.01327
G1 F15476.087
G1 X112.902 Y125.124 E.01327
G1 X112.902 Y119.743 E.17852
G2 X112.835 Y119.099 I-3.677 J.059 E.0215
G1 X125.107 Y119.099 E.40708
; WIPE_START
G1 X125.123 Y119.37 E-.10327
G1 X125.098 Y119.743 E-.14202
G1 X125.098 Y121.098 E-.51471
; WIPE_END
G1 E-.04 F1800
G1 X126.974 Y117.46 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X126.88 Y117.504 E.00319
G2 X125.49 Y119.748 I1.124 J2.248 E.08538
G1 X125.49 Y125.538 E.17792
G1 X125.49 Y125.938 E.01229
G1 F6459.938
G1 X125.49 Y126.338 E.01229
G1 F1800
G1 X125.49 Y126.707 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y127.068 E.01199
G1 X112.51 Y127.068 E.43057
G1 X112.51 Y126.707 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y126.338 E.01134
G1 F6459.938
G1 X112.51 Y125.938 E.01229
G1 F12000
G1 X112.51 Y125.538 E.01229
G1 X112.51 Y119.748 E.17792
G2 X111.026 Y117.46 I-2.524 J.012 E.08852
G1 X126.914 Y117.46 E.48819
; WIPE_START
M204 S10000
G1 X126.88 Y117.504 E-.02118
G1 X126.571 Y117.686 E-.13623
G1 X126.288 Y117.915 E-.13842
G1 X126.119 Y118.089 E-.09208
G1 X125.898 Y118.378 E-.13818
G1 X125.714 Y118.715 E-.14607
G1 X125.633 Y118.932 E-.08784
; WIPE_END
G1 E-.04 F1800
G1 X118.001 Y119.001 Z3.6 F30000
G1 X107.167 Y119.099 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X107.123 Y119.37 E.00911
G2 X107.098 Y119.743 I2.702 J.369 E.01241
M73 P58 R12
G1 X107.098 Y125.124 E.17851
G1 X107.098 Y125.524 E.01327
G1 F14655.771
G1 X107.098 Y125.924 E.01327
G1 F6907.886
G1 X107.098 Y126.324 E.01327
G1 F2040
G1 X107.098 Y126.676 E.01167
G1 F600
G1 X94.902 Y126.676 E.40456
G1 F2040
G1 X94.902 Y126.324 E.01167
G1 F6907.886
G1 X94.902 Y125.924 E.01327
G1 F14655.771
G1 X94.902 Y125.524 E.01327
G1 F15476.087
G1 X94.902 Y125.124 E.01327
G1 X94.902 Y119.743 E.17852
G2 X94.835 Y119.099 I-3.677 J.059 E.0215
G1 X107.107 Y119.099 E.40708
; WIPE_START
G1 X107.123 Y119.37 E-.10327
G1 X107.098 Y119.743 E-.14202
G1 X107.098 Y121.098 E-.51471
; WIPE_END
G1 E-.04 F1800
G1 X108.88 Y117.504 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X107.49 Y119.748 I1.124 J2.248 E.08538
G1 X107.49 Y125.538 E.17792
G1 X107.49 Y125.938 E.01229
G1 F6459.938
G1 X107.49 Y126.338 E.01229
G1 F1800
G1 X107.49 Y126.707 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y127.068 E.01199
G1 X94.51 Y127.068 E.43057
G1 X94.51 Y126.707 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y126.338 E.01134
G1 F6459.938
G1 X94.51 Y125.938 E.01229
G1 F12000
G1 X94.51 Y125.538 E.01229
G1 X94.51 Y119.748 E.17792
G2 X93.026 Y117.46 I-2.524 J.012 E.08852
G1 X108.974 Y117.46 E.49003
G1 X108.934 Y117.478 E.00135
; WIPE_START
M204 S10000
G1 X108.571 Y117.686 E-.15894
G1 X108.288 Y117.915 E-.13842
G1 X108.119 Y118.089 E-.09208
G1 X107.898 Y118.378 E-.13818
G1 X107.714 Y118.715 E-.14607
G1 X107.634 Y118.928 E-.08631
; WIPE_END
G1 E-.04 F1800
G1 X100.002 Y118.999 Z3.6 F30000
G1 X89.167 Y119.099 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X89.098 Y119.743 I3.811 J.731 E.02151
G1 X89.098 Y125.124 E.17851
G1 X89.098 Y125.524 E.01327
G1 F14655.771
G1 X89.098 Y125.924 E.01327
G1 F6907.886
G1 X89.098 Y126.324 E.01327
G1 F2040
G1 X89.098 Y126.676 E.01167
G1 F600
G1 X73.602 Y126.676 E.51403
G1 F2040
G1 X73.602 Y126.324 E.01167
G1 F6907.886
G1 X73.602 Y125.924 E.01327
G1 F14655.771
G1 X73.602 Y125.524 E.01327
G1 F15476.087
G1 X73.602 Y125.124 E.01327
G1 X73.602 Y119.099 E.19988
G1 X83.92 Y119.099 E.34226
G1 X89.107 Y119.099 E.17205
; WIPE_START
G1 X89.123 Y119.37 E-.10328
G1 X89.098 Y119.743 E-.14202
G1 X89.098 Y121.098 E-.51471
; WIPE_END
G1 E-.04 F1800
G1 X90.88 Y117.504 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X89.49 Y119.748 I1.124 J2.248 E.08538
G1 X89.49 Y125.538 E.17792
G1 X89.49 Y125.938 E.01229
G1 F6685.538
G1 X89.49 Y126.338 E.01229
G1 F1920
G1 X89.49 Y126.707 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y127.068 E.01199
G1 X73.21 Y127.068 E.54004
G1 X73.21 Y126.707 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1920
G1 X73.21 Y126.338 E.01134
G1 F6685.538
G1 X73.21 Y125.938 E.01229
G1 F12000
G1 X73.21 Y125.538 E.01229
G1 X73.21 Y117.46 E.24822
G1 X90.974 Y117.46 E.54583
G1 X90.934 Y117.478 E.00135
; WIPE_START
M204 S10000
G1 X90.571 Y117.686 E-.15894
G1 X90.288 Y117.915 E-.13841
G1 X90.119 Y118.089 E-.09208
G1 X89.898 Y118.378 E-.13819
G1 X89.714 Y118.715 E-.14607
G1 X89.634 Y118.928 E-.08631
; WIPE_END
G1 E-.04 F1800
G1 X97.266 Y118.959 Z3.6 F30000
G1 X130.835 Y119.099 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X143.166 Y119.099 E.40907
G1 X143.123 Y119.37 E.00911
G2 X143.098 Y119.743 I2.699 J.368 E.01241
G1 X143.098 Y125.124 E.17851
G1 X143.098 Y125.524 E.01327
G1 F14655.771
G1 X143.098 Y125.924 E.01327
G1 F6907.886
G1 X143.098 Y126.324 E.01327
G1 F2040
G1 X143.098 Y126.676 E.01167
G1 F600
G1 X130.902 Y126.676 E.40456
G1 F2040
G1 X130.902 Y126.324 E.01167
G1 F6907.886
G1 X130.902 Y125.924 E.01327
G1 F14655.771
G1 X130.902 Y125.524 E.01327
G1 F15476.087
G1 X130.902 Y125.124 E.01327
G1 X130.902 Y119.743 E.17852
G2 X130.846 Y119.158 I-3.681 J.06 E.01951
; WIPE_START
G1 X132.846 Y119.148 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X129.026 Y117.46 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X144.974 Y117.46 E.49003
G1 X144.88 Y117.504 E.00319
G2 X143.49 Y119.748 I1.124 J2.248 E.08538
G1 X143.49 Y125.538 E.17792
G1 X143.49 Y125.938 E.01229
G1 F6459.938
G1 X143.49 Y126.338 E.01229
G1 F1800
G1 X143.49 Y126.707 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y127.068 E.01199
G1 X130.51 Y127.068 E.43057
G1 X130.51 Y126.707 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y126.338 E.01134
G1 F6459.938
G1 X130.51 Y125.938 E.01229
G1 F12000
G1 X130.51 Y125.538 E.01229
G1 X130.51 Y119.748 E.17792
G2 X129.08 Y117.485 I-2.524 J.012 E.08668
; WIPE_START
M204 S10000
G1 X131.08 Y117.482 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.702 Y117.892 Z3.6 F30000
G1 X161.167 Y119.099 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X161.123 Y119.37 E.00911
G2 X161.098 Y119.743 I2.699 J.368 E.01241
G1 X161.098 Y125.124 E.17851
G1 X161.098 Y125.524 E.01327
G1 F14655.771
G1 X161.098 Y125.924 E.01327
G1 F6907.886
G1 X161.098 Y126.324 E.01327
G1 F2040
G1 X161.098 Y126.676 E.01167
G1 F600
G1 X148.902 Y126.676 E.40456
G1 F2040
G1 X148.902 Y126.324 E.01167
G1 F6907.886
G1 X148.902 Y125.924 E.01327
G1 F14655.771
G1 X148.902 Y125.524 E.01327
G1 F15476.087
G1 X148.902 Y125.124 E.01327
G1 X148.902 Y119.743 E.17852
G2 X148.835 Y119.099 I-3.681 J.06 E.0215
G1 X161.107 Y119.099 E.40708
; WIPE_START
G1 X161.123 Y119.37 E-.10327
G1 X161.098 Y119.743 E-.14203
G1 X161.098 Y121.098 E-.5147
; WIPE_END
G1 E-.04 F1800
G1 X162.88 Y117.504 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X161.49 Y119.748 I1.124 J2.248 E.08538
G1 X161.49 Y125.538 E.17792
G1 X161.49 Y125.938 E.01229
G1 F6459.938
G1 X161.49 Y126.338 E.01229
G1 F1800
G1 X161.49 Y126.707 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y127.068 E.01199
G1 X148.51 Y127.068 E.43057
G1 X148.51 Y126.707 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y126.338 E.01134
G1 F6459.938
G1 X148.51 Y125.938 E.01229
G1 F12000
G1 X148.51 Y125.538 E.01229
G1 X148.51 Y119.748 E.17792
G2 X147.026 Y117.46 I-2.524 J.012 E.08852
G1 X162.974 Y117.46 E.49003
G1 X162.934 Y117.478 E.00135
; WIPE_START
M204 S10000
G1 X162.571 Y117.686 E-.15894
G1 X162.288 Y117.915 E-.13842
G1 X162.041 Y118.181 E-.13808
G1 X161.898 Y118.378 E-.09219
G1 X161.714 Y118.715 E-.14607
G1 X161.634 Y118.928 E-.08631
; WIPE_END
G1 E-.04 F1800
G1 X169.266 Y118.991 Z3.6 F30000
G1 X182.398 Y119.099 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y125.124 E.19988
G1 X182.398 Y125.524 E.01327
G1 F14655.771
G1 X182.398 Y125.924 E.01327
G1 F6907.886
G1 X182.398 Y126.324 E.01327
G1 F2040
G1 X182.398 Y126.676 E.01167
G1 F600
G1 X166.902 Y126.676 E.51403
G1 F2040
G1 X166.902 Y126.324 E.01167
G1 F6907.886
G1 X166.902 Y125.924 E.01327
G1 F14655.771
G1 X166.902 Y125.524 E.01327
G1 F15476.087
M73 P59 R12
G1 X166.902 Y125.124 E.01327
G1 X166.902 Y119.743 E.17852
G2 X166.835 Y119.099 I-3.681 J.06 E.0215
G1 X182.338 Y119.099 E.51427
; WIPE_START
G1 X182.358 Y121.099 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y117.46 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
M73 P59 R11
G1 F12000
M204 S5000
G1 X182.79 Y125.538 E.24822
G1 X182.79 Y125.938 E.01229
G1 F6685.538
G1 X182.79 Y126.338 E.01229
G1 F1920
G1 X182.79 Y126.707 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y127.068 E.01199
G1 F600
G1 X166.51 Y127.068 E.54004
G1 X166.51 Y126.707 E.01199
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1920
G1 X166.51 Y126.338 E.01134
G1 F6685.538
G1 X166.51 Y125.938 E.01229
G1 F12000
G1 X166.51 Y125.538 E.01229
G1 X166.51 Y119.748 E.17792
G2 X165.026 Y117.46 I-2.524 J.012 E.08852
G1 X182.73 Y117.46 E.54399
; WIPE_START
M204 S10000
G1 X182.745 Y119.46 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.783 Y118.877 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.583 Y118.077 E.03473
G1 X182.46 Y117.667
G1 X181.25 Y118.877 E.05255
G1 X180.717 Y118.877
G1 X181.926 Y117.667 E.05255
G1 X181.393 Y117.667
G1 X180.184 Y118.877 E.05255
G1 X179.65 Y118.877
G1 X180.86 Y117.667 E.05255
G1 X180.326 Y117.667
G1 X179.117 Y118.877 E.05255
G1 X178.584 Y118.877
G1 X179.793 Y117.667 E.05255
G1 X179.26 Y117.667
G1 X178.051 Y118.877 E.05255
G1 X177.517 Y118.877
G1 X178.727 Y117.667 E.05255
G1 X178.193 Y117.667
G1 X176.984 Y118.877 E.05255
G1 X176.451 Y118.877
G1 X177.66 Y117.667 E.05255
G1 X177.127 Y117.667
G1 X175.918 Y118.877 E.05255
G1 X175.384 Y118.877
G1 X176.594 Y117.667 E.05255
G1 X176.06 Y117.667
G1 X174.851 Y118.877 E.05255
G1 X174.318 Y118.877
G1 X175.527 Y117.667 E.05255
G1 X174.994 Y117.667
G1 X173.785 Y118.877 E.05255
G1 X173.251 Y118.877
G1 X174.461 Y117.667 E.05255
G1 X173.927 Y117.667
G1 X172.718 Y118.877 E.05255
G1 X172.185 Y118.877
G1 X173.394 Y117.667 E.05255
G1 X172.861 Y117.667
G1 X171.652 Y118.877 E.05255
G1 X171.118 Y118.877
G1 X172.328 Y117.667 E.05255
G1 X171.794 Y117.667
G1 X170.585 Y118.877 E.05255
G1 X170.052 Y118.877
G1 X171.261 Y117.667 E.05255
G1 X170.728 Y117.667
G1 X169.519 Y118.877 E.05255
G1 X168.985 Y118.877
G1 X170.195 Y117.667 E.05255
G1 X169.661 Y117.667
G1 X168.452 Y118.877 E.05255
G1 X167.919 Y118.877
G1 X169.128 Y117.667 E.05255
G1 X168.595 Y117.667
G1 X167.385 Y118.877 E.05255
G1 X166.852 Y118.877
G1 X168.062 Y117.667 E.05255
G1 X167.528 Y117.667
G1 X166.503 Y118.693 E.04457
G1 X166.322 Y118.34
G1 X166.995 Y117.667 E.02924
; WIPE_START
M204 S10000
G1 X166.322 Y118.34 E-.36155
G1 X166.503 Y118.693 E-.15059
G1 X166.964 Y118.232 E-.24786
; WIPE_END
G1 E-.04 F1800
G1 X166.831 Y118.855 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.125566
G1 F15000
G1 X166.607 Y118.855 E.0015
G1 X166.534 Y118.824 E.00053
; WIPE_START
G1 X166.607 Y118.855 E-.19927
G1 X166.831 Y118.855 E-.56073
; WIPE_END
G1 E-.04 F1800
G1 X167.25 Y123.501 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.25 Y124.663 E.03853
G1 X167.717 Y124.663 E.01549
G1 X169.768 Y122.612 E.09618
G1 X170.668 Y122.612 E.02987
G1 X172.718 Y124.663 E.09618
G1 X175.393 Y124.663 E.08873
G1 X177.443 Y122.612 E.09618
G1 X178.344 Y122.612 E.02987
G1 X180.394 Y124.663 E.09618
G1 X182.023 Y124.663 E.05401
G1 X182.234 Y125.4 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X167.235 Y125.4 E.55304
G1 X167.235 Y125.853 E.01668
G1 X182.065 Y125.853 E.54679
G1 X182.065 Y126.305 E.01668
G1 X167.066 Y126.305 E.55304
G1 X167.223 Y124.984 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y124.984 E.40987
G1 X182.006 Y120.856 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y119.491 E.04193
G1 X167.275 Y119.491 E.45263
G1 X167.294 Y119.737 E.00758
G1 X167.294 Y122.22 E.0763
G1 X182.006 Y122.22 E.45204
G1 X182.006 Y120.916 E.04008
G1 X181.629 Y120.856 F30000
G1 F12000
G1 X181.629 Y119.868 E.03034
G1 X167.671 Y119.868 E.42887
G1 X167.671 Y121.843 E.06068
G1 X181.629 Y121.843 E.42887
G1 X181.629 Y120.916 E.0285
G1 X181.252 Y120.856 F30000
G1 F12000
G1 X181.252 Y120.245 E.01876
G1 X168.048 Y120.245 E.4057
G1 X168.048 Y121.466 E.03751
G1 X181.252 Y121.466 E.4057
G1 X181.252 Y120.916 E.01691
G1 X180.852 Y120.856 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X180.852 Y120.645 E.00725
G1 X168.448 Y120.645 E.42644
G1 X168.448 Y121.067 E.0145
G1 X180.852 Y121.067 E.42644
G1 X180.852 Y120.916 E.00519
; WIPE_START
G1 X180.852 Y121.067 E-.05736
G1 X179.003 Y121.067 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X171.427 Y120.146 Z3.6 F30000
G1 X160.986 Y118.877 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X162.196 Y117.667 E.05255
G1 X161.662 Y117.667
G1 X160.453 Y118.877 E.05255
G1 X159.92 Y118.877
G1 X161.129 Y117.667 E.05255
G1 X160.596 Y117.667
G1 X159.387 Y118.877 E.05255
G1 X158.853 Y118.877
G1 X160.063 Y117.667 E.05255
G1 X159.529 Y117.667
G1 X158.32 Y118.877 E.05255
G1 X157.787 Y118.877
G1 X158.996 Y117.667 E.05255
G1 X158.463 Y117.667
G1 X157.254 Y118.877 E.05255
G1 X156.72 Y118.877
G1 X157.93 Y117.667 E.05255
G1 X157.396 Y117.667
G1 X156.187 Y118.877 E.05255
G1 X155.654 Y118.877
G1 X156.863 Y117.667 E.05255
G1 X156.33 Y117.667
G1 X155.121 Y118.877 E.05255
G1 X154.587 Y118.877
G1 X155.797 Y117.667 E.05255
G1 X155.263 Y117.667
G1 X154.054 Y118.877 E.05255
G1 X153.521 Y118.877
G1 X154.73 Y117.667 E.05255
G1 X154.197 Y117.667
G1 X152.988 Y118.877 E.05255
G1 X152.454 Y118.877
G1 X153.664 Y117.667 E.05255
G1 X153.13 Y117.667
G1 X151.921 Y118.877 E.05255
G1 X151.388 Y118.877
G1 X152.597 Y117.667 E.05255
G1 X152.064 Y117.667
G1 X150.855 Y118.877 E.05255
G1 X150.321 Y118.877
G1 X151.531 Y117.667 E.05255
G1 X150.997 Y117.667
G1 X149.788 Y118.877 E.05255
G1 X149.255 Y118.877
G1 X150.464 Y117.667 E.05255
G1 X149.931 Y117.667
G1 X148.721 Y118.877 E.05255
G1 X148.461 Y118.604
G1 X149.398 Y117.667 E.04069
G1 X148.864 Y117.667
G1 X148.272 Y118.259 E.02573
M204 S10000
G1 X148.174 Y117.648 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.17289
G1 F15000
G1 X148.149 Y118.116 E.00496
; WIPE_START
G1 X148.174 Y117.648 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X149.294 Y119.737 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X149.275 Y119.491 E.00758
G1 X160.722 Y119.491 E.35172
G1 X160.706 Y119.736 E.00755
G1 X160.706 Y121.637 E.05841
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.706 Y122.22 E.01791
G1 X149.294 Y122.22 E.35064
G1 X149.294 Y121.637 E.01791
; Slow Down End
G1 F12000
G1 X149.294 Y119.797 E.05654
G1 X149.671 Y119.868 F30000
G1 F12000
G1 X160.329 Y119.868 E.32747
G1 X160.329 Y121.637 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.329 Y121.843 E.00632
G1 X149.671 Y121.843 E.32747
G1 X149.671 Y121.637 E.00632
; Slow Down End
G1 F12000
G1 X149.671 Y119.928 E.05252
G1 X150.048 Y120.245 F30000
G1 F12000
G1 X150.048 Y121.466 E.03751
G1 X159.952 Y121.466 E.3043
G1 X159.952 Y120.245 E.03751
G1 X150.108 Y120.245 E.30245
G1 X150.448 Y120.645 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X150.448 Y121.067 E.0145
G1 X159.552 Y121.067 E.31299
G1 X159.552 Y120.645 E.0145
G1 X150.508 Y120.645 E.31093
G1 X149.268 Y122.612 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X149.25 Y124.222 E.05342
G1 X149.69 Y124.663 E.02064
G1 X152.365 Y124.663 E.08873
G1 X154.416 Y122.612 E.09618
G1 X155.316 Y122.612 E.02987
G1 X157.366 Y124.663 E.09618
G1 X160.041 Y124.663 E.08873
G1 X160.75 Y123.954 E.03323
G1 X160.75 Y122.612 E.04451
G1 X160.463 Y122.612 E.0095
G1 X160.934 Y125.4 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X149.235 Y125.4 E.43137
G1 X149.235 Y125.853 E.01668
G1 X160.765 Y125.853 E.42511
G1 X160.765 Y126.305 E.01668
G1 X149.066 Y126.305 E.43137
G1 X149.223 Y124.984 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.717 Y124.984 E.31844
; WIPE_START
G1 X158.717 Y124.984 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.6 I-.032 J-1.217 P1  F30000
G1 X142.934 Y125.4 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X131.235 Y125.4 E.43137
G1 X131.235 Y125.853 E.01668
G1 X142.765 Y125.853 E.42511
G1 X142.765 Y126.305 E.01668
G1 X131.066 Y126.305 E.43137
G1 X131.223 Y124.984 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.717 Y124.984 E.31844
; WIPE_START
G1 X140.717 Y124.984 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X143.893 Y118.043 Z3.6 F30000
G1 X144.065 Y117.667 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X142.856 Y118.877 E.05255
G1 X142.322 Y118.877
G1 X143.532 Y117.667 E.05255
G1 X142.998 Y117.667
G1 X141.789 Y118.877 E.05255
G1 X141.256 Y118.877
G1 X142.465 Y117.667 E.05255
G1 X141.932 Y117.667
G1 X140.723 Y118.877 E.05255
G1 X140.189 Y118.877
G1 X141.399 Y117.667 E.05255
G1 X140.865 Y117.667
G1 X139.656 Y118.877 E.05255
G1 X139.123 Y118.877
G1 X140.332 Y117.667 E.05255
G1 X139.799 Y117.667
G1 X138.59 Y118.877 E.05255
G1 X138.056 Y118.877
G1 X139.266 Y117.667 E.05255
G1 X138.732 Y117.667
G1 X137.523 Y118.877 E.05255
G1 X136.99 Y118.877
G1 X138.199 Y117.667 E.05255
G1 X137.666 Y117.667
G1 X136.457 Y118.877 E.05255
G1 X135.923 Y118.877
G1 X137.133 Y117.667 E.05255
G1 X136.599 Y117.667
G1 X135.39 Y118.877 E.05255
G1 X134.857 Y118.877
G1 X136.066 Y117.667 E.05255
G1 X135.533 Y117.667
G1 X134.324 Y118.877 E.05255
G1 X133.79 Y118.877
G1 X135 Y117.667 E.05255
G1 X134.466 Y117.667
G1 X133.257 Y118.877 E.05255
G1 X132.724 Y118.877
G1 X133.933 Y117.667 E.05255
G1 X133.4 Y117.667
G1 X132.19 Y118.877 E.05255
G1 X131.657 Y118.877
G1 X132.867 Y117.667 E.05255
G1 X132.333 Y117.667
G1 X131.124 Y118.877 E.05255
G1 X130.591 Y118.877
G1 X131.8 Y117.667 E.05255
G1 X131.267 Y117.667
G1 X130.419 Y118.515 E.03682
G1 X130.218 Y118.182
G1 X130.734 Y117.667 E.02238
; WIPE_START
M204 S10000
G1 X130.218 Y118.182 E-.27681
G1 X130.419 Y118.515 E-.14757
G1 X131.044 Y117.89 E-.33562
; WIPE_END
G1 E-.04 F1800
G1 X138.671 Y118.178 Z3.6 F30000
G1 X143.66 Y118.366 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.105389
G1 F15000
G1 X143.572 Y118.484 E.00075
; LINE_WIDTH: 0.135644
G1 X143.527 Y118.547 E.00059
; LINE_WIDTH: 0.172658
G2 X143.287 Y118.895 I9.367 J6.713 E.00448
; WIPE_START
G1 X143.527 Y118.547 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X135.93 Y119.286 Z3.6 F30000
G1 X131.294 Y119.737 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
M73 P60 R11
G1 X131.275 Y119.491 E.00758
G1 X142.722 Y119.491 E.35172
G1 X142.706 Y119.736 E.00755
G1 X142.706 Y121.637 E.05841
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.706 Y122.22 E.01791
G1 X131.294 Y122.22 E.35064
G1 X131.294 Y121.637 E.01791
; Slow Down End
G1 F12000
G1 X131.294 Y119.797 E.05654
G1 X131.671 Y121.843 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.671 Y121.637 E.00632
; Slow Down End
G1 F12000
G1 X131.671 Y119.868 E.05436
G1 X142.329 Y119.868 E.32747
G1 X142.329 Y121.637 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.329 Y121.843 E.00632
; Slow Down End
G1 F12000
G1 X131.731 Y121.843 E.32563
G1 X132.048 Y121.466 F30000
G1 F12000
G1 X141.952 Y121.466 E.3043
G1 X141.952 Y120.245 E.03751
G1 X132.048 Y120.245 E.3043
G1 X132.048 Y121.406 E.03567
G1 X132.448 Y121.067 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X141.552 Y121.067 E.31299
G1 X141.552 Y120.645 E.0145
G1 X132.448 Y120.645 E.31299
G1 X132.448 Y121.007 E.01244
G1 X131.25 Y124.378 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X131.25 Y122.75 E.05401
G1 X131.388 Y122.612 E.00645
G1 X132.288 Y122.612 E.02987
G1 X134.339 Y124.663 E.09618
G1 X137.013 Y124.663 E.08873
G1 X139.064 Y122.612 E.09618
G1 X139.964 Y122.612 E.02987
G1 X142.014 Y124.663 E.09618
G1 X142.75 Y124.663 E.02439
G1 X142.75 Y123.769 E.02963
; WIPE_START
G1 X142.75 Y124.663 E-.33937
G1 X142.014 Y124.663 E-.27939
G1 X141.752 Y124.4 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X134.729 Y121.411 Z3.6 F30000
G1 X125.934 Y117.667 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X124.725 Y118.877 E.05255
G1 X124.192 Y118.877
G1 X125.401 Y117.667 E.05255
G1 X124.868 Y117.667
G1 X123.658 Y118.877 E.05255
G1 X123.125 Y118.877
G1 X124.334 Y117.667 E.05255
G1 X123.801 Y117.667
G1 X122.592 Y118.877 E.05255
G1 X122.059 Y118.877
G1 X123.268 Y117.667 E.05255
G1 X122.735 Y117.667
G1 X121.525 Y118.877 E.05255
G1 X120.992 Y118.877
G1 X122.201 Y117.667 E.05255
G1 X121.668 Y117.667
G1 X120.459 Y118.877 E.05255
G1 X119.926 Y118.877
G1 X121.135 Y117.667 E.05255
G1 X120.602 Y117.667
G1 X119.392 Y118.877 E.05255
G1 X118.859 Y118.877
G1 X120.068 Y117.667 E.05255
G1 X119.535 Y117.667
G1 X118.326 Y118.877 E.05255
G1 X117.793 Y118.877
G1 X119.002 Y117.667 E.05255
G1 X118.469 Y117.667
G1 X117.259 Y118.877 E.05255
G1 X116.726 Y118.877
G1 X117.935 Y117.667 E.05255
G1 X117.402 Y117.667
G1 X116.193 Y118.877 E.05255
G1 X115.66 Y118.877
G1 X116.869 Y117.667 E.05255
G1 X116.336 Y117.667
G1 X115.126 Y118.877 E.05255
G1 X114.593 Y118.877
G1 X115.802 Y117.667 E.05255
G1 X115.269 Y117.667
G1 X114.06 Y118.877 E.05255
G1 X113.526 Y118.877
G1 X114.736 Y117.667 E.05255
G1 X114.203 Y117.667
G1 X112.993 Y118.877 E.05255
G1 X112.543 Y118.794
G1 X113.669 Y117.667 E.04896
G1 X113.136 Y117.667
G1 X112.374 Y118.429 E.03311
G1 X112.163 Y118.107
G1 X112.603 Y117.667 E.0191
; WIPE_START
M204 S10000
G1 X112.163 Y118.107 E-.23616
G1 X112.374 Y118.429 E-.14641
G1 X113.076 Y117.727 E-.37743
; WIPE_END
G1 E-.04 F1800
G1 X120.709 Y117.681 Z3.6 F30000
G1 X126.245 Y117.648 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.0973533
G1 F15000
G1 X125.781 Y118.144 E.00301
; LINE_WIDTH: 0.135922
G1 X125.696 Y118.247 E.00101
; LINE_WIDTH: 0.163701
G1 X125.612 Y118.353 E.00133
; LINE_WIDTH: 0.1985
G1 X125.529 Y118.463 E.00175
; LINE_WIDTH: 0.230704
G1 X125.484 Y118.526 E.00119
; LINE_WIDTH: 0.268377
G2 X125.229 Y118.895 I10.843 J7.763 E.00825
; WIPE_START
G1 X125.484 Y118.526 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.6 I-1.213 J-.097 P1  F30000
G1 X124.934 Y125.4 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X113.235 Y125.4 E.43137
G1 X113.235 Y125.853 E.01668
G1 X124.765 Y125.853 E.42511
G1 X124.765 Y126.305 E.01668
G1 X113.066 Y126.305 E.43137
G1 X113.223 Y124.984 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.717 Y124.984 E.31844
G1 X113.25 Y123.769 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X113.25 Y124.663 E.02963
G1 X113.986 Y124.663 E.02439
G1 X116.036 Y122.612 E.09618
G1 X116.936 Y122.612 E.02987
G1 X118.987 Y124.663 E.09618
G1 X121.661 Y124.663 E.08873
G1 X123.712 Y122.612 E.09618
G1 X124.612 Y122.612 E.02987
G1 X124.75 Y122.75 E.00645
G1 X124.75 Y124.378 E.05401
G1 X113.294 Y119.737 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X113.275 Y119.491 E.00758
G1 X124.722 Y119.491 E.35172
G1 X124.706 Y119.736 E.00755
G1 X124.706 Y121.637 E.05841
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.706 Y122.22 E.01791
G1 X113.294 Y122.22 E.35064
G1 X113.294 Y121.637 E.01791
; Slow Down End
G1 F12000
G1 X113.294 Y119.797 E.05654
G1 X113.671 Y119.868 F30000
G1 F12000
G1 X124.329 Y119.868 E.32747
G1 X124.329 Y121.637 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.329 Y121.843 E.00632
G1 X113.671 Y121.843 E.32747
G1 X113.671 Y121.637 E.00632
; Slow Down End
G1 F12000
G1 X113.671 Y119.928 E.05252
G1 X114.048 Y120.245 F30000
G1 F12000
G1 X114.048 Y121.466 E.03751
G1 X123.952 Y121.466 E.3043
G1 X123.952 Y120.245 E.03751
G1 X114.108 Y120.245 E.30245
G1 X114.448 Y120.645 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X114.448 Y121.067 E.0145
G1 X123.552 Y121.067 E.31299
G1 X123.552 Y120.645 E.0145
G1 X114.508 Y120.645 E.31093
; WIPE_START
G1 X116.508 Y120.645 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.007 Y119.231 Z3.6 F30000
G1 X107.127 Y118.877 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X107.7 Y118.304 E.02489
G1 X107.803 Y117.667
G1 X106.594 Y118.877 E.05255
G1 X106.061 Y118.877
G1 X107.27 Y117.667 E.05255
G1 X106.737 Y117.667
G1 X105.528 Y118.877 E.05255
G1 X104.994 Y118.877
G1 X106.204 Y117.667 E.05255
G1 X105.67 Y117.667
G1 X104.461 Y118.877 E.05255
G1 X103.928 Y118.877
G1 X105.137 Y117.667 E.05255
G1 X104.604 Y117.667
G1 X103.395 Y118.877 E.05255
G1 X102.861 Y118.877
G1 X104.071 Y117.667 E.05255
G1 X103.537 Y117.667
G1 X102.328 Y118.877 E.05255
G1 X101.795 Y118.877
G1 X103.004 Y117.667 E.05255
G1 X102.471 Y117.667
G1 X101.262 Y118.877 E.05255
G1 X100.728 Y118.877
G1 X101.938 Y117.667 E.05255
G1 X101.404 Y117.667
G1 X100.195 Y118.877 E.05255
G1 X99.662 Y118.877
G1 X100.871 Y117.667 E.05255
G1 X100.338 Y117.667
G1 X99.129 Y118.877 E.05255
G1 X98.595 Y118.877
G1 X99.805 Y117.667 E.05255
G1 X99.271 Y117.667
G1 X98.062 Y118.877 E.05255
G1 X97.529 Y118.877
G1 X98.738 Y117.667 E.05255
G1 X98.205 Y117.667
G1 X96.995 Y118.877 E.05255
G1 X96.462 Y118.877
G1 X97.672 Y117.667 E.05255
G1 X97.138 Y117.667
G1 X95.929 Y118.877 E.05255
G1 X95.396 Y118.877
G1 X96.605 Y117.667 E.05255
G1 X96.072 Y117.667
G1 X94.862 Y118.877 E.05255
G1 X94.506 Y118.7
G1 X95.539 Y117.667 E.04487
G1 X95.005 Y117.667
G1 X94.326 Y118.346 E.02951
G1 X94.106 Y118.033
G1 X94.472 Y117.667 E.01591
M204 S10000
G1 X94.408 Y118.531 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0959675
G1 F15000
G1 X94.416 Y118.48 E.00023
G1 X94.366 Y118.414 E.00036
; WIPE_START
G1 X94.416 Y118.48 E-.46477
G1 X94.408 Y118.531 E-.29523
; WIPE_END
G1 E-.04 F1800
G1 X95.294 Y119.737 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X95.275 Y119.491 E.00758
G1 X106.722 Y119.491 E.35172
G1 X106.706 Y119.736 E.00755
G1 X106.706 Y121.637 E.05841
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.706 Y122.22 E.01791
G1 X95.294 Y122.22 E.35064
G1 X95.294 Y121.637 E.01791
; Slow Down End
G1 F12000
G1 X95.294 Y119.797 E.05654
G1 X95.671 Y119.868 F30000
G1 F12000
G1 X106.329 Y119.868 E.32747
G1 X106.329 Y121.637 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.329 Y121.843 E.00632
G1 X95.671 Y121.843 E.32747
G1 X95.671 Y121.637 E.00632
; Slow Down End
G1 F12000
G1 X95.671 Y119.928 E.05252
G1 X96.048 Y120.245 F30000
G1 F12000
G1 X96.048 Y121.466 E.03751
G1 X105.952 Y121.466 E.3043
G1 X105.952 Y120.245 E.03751
G1 X96.108 Y120.245 E.30245
G1 X96.448 Y120.645 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X96.448 Y121.067 E.0145
G1 X105.552 Y121.067 E.31299
G1 X105.552 Y120.645 E.0145
G1 X96.508 Y120.645 E.31093
G1 X95.537 Y122.612 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X95.25 Y122.612 E.0095
G1 X95.25 Y123.954 E.04451
G1 X95.959 Y124.663 E.03323
G1 X98.634 Y124.663 E.08873
G1 X100.684 Y122.612 E.09618
G1 X101.584 Y122.612 E.02987
G1 X103.635 Y124.663 E.09618
G1 X106.31 Y124.663 E.08873
G1 X106.75 Y124.222 E.02065
G1 X106.732 Y122.612 E.05342
G1 X106.934 Y125.4 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X95.235 Y125.4 E.43137
G1 X95.235 Y125.853 E.01668
G1 X106.765 Y125.853 E.42511
G1 X106.765 Y126.305 E.01668
G1 X95.066 Y126.305 E.43137
G1 X95.223 Y124.984 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.717 Y124.984 E.31844
; WIPE_START
G1 X104.717 Y124.984 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.6 I-.032 J-1.217 P1  F30000
G1 X88.934 Y125.4 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4954
G1 F3000
G1 X73.935 Y125.4 E.55304
G1 X73.935 Y125.853 E.01668
G1 X88.765 Y125.853 E.54679
G1 X88.765 Y126.305 E.01668
G1 X73.766 Y126.305 E.55304
G1 X73.923 Y124.984 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.717 Y124.984 E.40987
; WIPE_START
G1 X86.717 Y124.984 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X88.997 Y118.877 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X90.206 Y117.667 E.05255
G1 X89.673 Y117.667
G1 X88.463 Y118.877 E.05255
G1 X87.93 Y118.877
G1 X89.139 Y117.667 E.05255
G1 X88.606 Y117.667
G1 X87.397 Y118.877 E.05255
G1 X86.864 Y118.877
G1 X88.073 Y117.667 E.05255
G1 X87.54 Y117.667
G1 X86.33 Y118.877 E.05255
G1 X85.797 Y118.877
G1 X87.006 Y117.667 E.05255
G1 X86.473 Y117.667
G1 X85.264 Y118.877 E.05255
G1 X84.731 Y118.877
G1 X85.94 Y117.667 E.05255
G1 X85.407 Y117.667
G1 X84.197 Y118.877 E.05255
G1 X83.664 Y118.877
G1 X84.873 Y117.667 E.05255
G1 X84.34 Y117.667
G1 X83.131 Y118.877 E.05255
G1 X82.598 Y118.877
G1 X83.807 Y117.667 E.05255
G1 X83.274 Y117.667
G1 X82.064 Y118.877 E.05255
G1 X81.531 Y118.877
G1 X82.74 Y117.667 E.05255
G1 X82.207 Y117.667
G1 X80.998 Y118.877 E.05255
G1 X80.465 Y118.877
G1 X81.674 Y117.667 E.05255
G1 X81.141 Y117.667
G1 X79.931 Y118.877 E.05255
G1 X79.398 Y118.877
G1 X80.607 Y117.667 E.05255
G1 X80.074 Y117.667
G1 X78.865 Y118.877 E.05255
G1 X78.331 Y118.877
G1 X79.541 Y117.667 E.05255
G1 X79.008 Y117.667
G1 X77.798 Y118.877 E.05255
G1 X77.265 Y118.877
G1 X78.474 Y117.667 E.05255
G1 X77.941 Y117.667
G1 X76.732 Y118.877 E.05255
G1 X76.198 Y118.877
G1 X77.408 Y117.667 E.05255
G1 X76.875 Y117.667
G1 X75.665 Y118.877 E.05255
G1 X75.132 Y118.877
G1 X76.341 Y117.667 E.05255
G1 X75.808 Y117.667
G1 X74.599 Y118.877 E.05255
G1 X74.065 Y118.877
G1 X75.275 Y117.667 E.05255
G1 X74.741 Y117.667
G1 X73.532 Y118.877 E.05255
G1 X73.417 Y118.458
G1 X74.208 Y117.667 E.03437
; WIPE_START
M204 S10000
G1 X73.417 Y118.458 E-.425
G1 X73.532 Y118.877 E-.1649
G1 X73.849 Y118.56 E-.1701
; WIPE_END
G1 E-.04 F1800
G1 X73.994 Y119.491 Z3.6 F30000
G1 Z3.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.722 Y119.491 E.45253
G1 X88.706 Y119.736 E.00755
G1 X88.706 Y121.637 E.05841
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.706 Y122.22 E.01791
G1 X73.994 Y122.22 E.45204
G1 X73.994 Y121.637 E.01791
; Slow Down End
G1 F12000
G1 X73.994 Y119.551 E.0641
G1 X74.371 Y119.868 F30000
G1 F12000
G1 X88.329 Y119.868 E.42887
G1 X88.329 Y121.637 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.329 Y121.843 E.00632
G1 X74.371 Y121.843 E.42887
G1 X74.371 Y121.637 E.00632
; Slow Down End
G1 F12000
G1 X74.371 Y119.928 E.05252
G1 X74.748 Y120.245 F30000
G1 F12000
G1 X74.748 Y121.466 E.03751
G1 X87.952 Y121.466 E.4057
G1 X87.952 Y120.245 E.03751
G1 X74.808 Y120.245 E.40385
G1 X75.148 Y120.645 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X75.148 Y121.067 E.0145
G1 X87.552 Y121.067 E.42644
G1 X87.552 Y120.645 E.0145
G1 X75.208 Y120.645 E.42438
G1 X73.977 Y124.663 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X75.606 Y124.663 E.05401
G1 X77.656 Y122.612 E.09618
G1 X78.557 Y122.612 E.02987
G1 X80.607 Y124.663 E.09618
G1 X83.282 Y124.663 E.08873
G1 X85.332 Y122.612 E.09618
G1 X86.232 Y122.612 E.02987
G1 X88.283 Y124.663 E.09618
G1 X88.75 Y124.663 E.01549
G1 X88.75 Y123.501 E.03853
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X88.75 Y124.663 E-.44133
G1 X88.283 Y124.663 E-.17743
G1 X88.02 Y124.4 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 17/33
; update layer progress
M73 L17
M991 S0 P16 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.6 I1.184 J.282 P1  F30000
G1 X89.098 Y119.87 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X89.098 Y125.896 E.19987
G1 X89.098 Y126.296 E.01327
G1 F13999.876
G1 X89.098 Y126.696 E.01327
G1 F6459.938
G1 X89.098 Y127.096 E.01327
G1 F1800
G1 X89.098 Y127.478 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X89.098 Y127.634 E.00515
G1 X73.602 Y127.634 E.51403
G1 X73.602 Y127.478 E.00515
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X73.602 Y127.096 E.01269
G1 F6459.938
G1 X73.602 Y126.696 E.01327
G1 F13999.876
G1 X73.602 Y126.296 E.01327
G1 F15476.087
G1 X73.602 Y125.896 E.01327
G1 X73.602 Y119.87 E.19988
G1 X89.038 Y119.87 E.51204
; WIPE_START
G1 X89.058 Y121.87 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X90.003 Y118.231 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X89.49 Y119.748 I2.044 J1.536 E.05003
G1 X89.49 Y126.309 E.20162
G1 X89.49 Y126.709 E.01229
G1 F6459.938
G1 X89.49 Y127.109 E.01229
G1 F1800
M73 P61 R11
G1 X89.49 Y127.478 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X89.49 Y128.026 E.01816
G1 X73.21 Y128.026 E.54004
G1 X73.21 Y127.478 E.01816
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y127.109 E.01134
G1 F6459.938
G1 X73.21 Y126.709 E.01229
G1 F12000
G1 X73.21 Y126.309 E.01229
G1 X73.21 Y118.231 E.24822
G1 X83.92 Y118.231 E.32908
G1 X89.943 Y118.231 E.18506
; WIPE_START
M204 S10000
G1 X89.775 Y118.587 E-.14953
G1 X89.631 Y118.921 E-.13821
G1 X89.536 Y119.272 E-.13827
G1 X89.49 Y119.748 E-.18143
G1 X89.49 Y120.149 E-.15257
; WIPE_END
G1 E-.04 F1800
G1 X89.364 Y119.092 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X88.71 Y118.439 E.02841
G1 X88.176 Y118.439
G1 X89.29 Y119.553 E.04841
G1 X88.853 Y119.648
G1 X87.643 Y118.439 E.05255
G1 X87.11 Y118.439
G1 X88.319 Y119.648 E.05255
G1 X87.786 Y119.648
G1 X86.577 Y118.439 E.05255
G1 X86.043 Y118.439
G1 X87.253 Y119.648 E.05255
G1 X86.72 Y119.648
G1 X85.51 Y118.439 E.05255
G1 X84.977 Y118.439
G1 X86.186 Y119.648 E.05255
G1 X85.653 Y119.648
G1 X84.444 Y118.439 E.05255
G1 X83.91 Y118.439
G1 X85.12 Y119.648 E.05255
G1 X84.586 Y119.648
G1 X83.377 Y118.439 E.05255
G1 X82.844 Y118.439
G1 X84.053 Y119.648 E.05255
G1 X83.52 Y119.648
G1 X82.311 Y118.439 E.05255
G1 X81.777 Y118.439
G1 X82.987 Y119.648 E.05255
G1 X82.453 Y119.648
G1 X81.244 Y118.439 E.05255
G1 X80.711 Y118.439
G1 X81.92 Y119.648 E.05255
G1 X81.387 Y119.648
G1 X80.178 Y118.439 E.05255
G1 X79.644 Y118.439
G1 X80.854 Y119.648 E.05255
G1 X80.32 Y119.648
G1 X79.111 Y118.439 E.05255
G1 X78.578 Y118.439
G1 X79.787 Y119.648 E.05255
G1 X79.254 Y119.648
G1 X78.045 Y118.439 E.05255
G1 X77.511 Y118.439
G1 X78.721 Y119.648 E.05255
G1 X78.187 Y119.648
G1 X76.978 Y118.439 E.05255
G1 X76.445 Y118.439
G1 X77.654 Y119.648 E.05255
G1 X77.121 Y119.648
G1 X75.912 Y118.439 E.05255
G1 X75.378 Y118.439
G1 X76.588 Y119.648 E.05255
G1 X76.054 Y119.648
G1 X74.845 Y118.439 E.05255
G1 X74.312 Y118.439
G1 X75.521 Y119.648 E.05255
G1 X74.988 Y119.648
G1 X73.779 Y118.439 E.05255
G1 X73.417 Y118.611
G1 X74.455 Y119.648 E.04507
G1 X73.921 Y119.648
G1 X73.417 Y119.144 E.0219
M204 S10000
G1 X89.369 Y119.124 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.143003
G1 F15000
G1 X89.302 Y119.226 E.00099
G1 X89.333 Y119.328 E.00087
G1 X89.328 Y118.42 F30000
; LINE_WIDTH: 0.0981983
G1 F15000
G1 X89.438 Y118.9 E.00222
G1 X89.338 Y118.42 F30000
; LINE_WIDTH: 0.270786
G1 F15000
G1 X89.434 Y118.896 E.00903
; WIPE_START
G1 X89.338 Y118.42 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X88.706 Y121.627 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y120.263 E.04193
G1 X73.994 Y120.263 E.45204
G1 X73.994 Y122.992 E.08386
G1 X88.706 Y122.992 E.45204
G1 X88.706 Y121.687 E.04008
G1 X88.329 Y121.627 F30000
G1 F12000
G1 X88.329 Y120.64 E.03034
G1 X74.371 Y120.64 E.42887
G1 X74.371 Y122.615 E.06068
G1 X88.329 Y122.615 E.42887
G1 X88.329 Y121.687 E.0285
G1 X87.952 Y121.627 F30000
G1 F12000
G1 X87.952 Y121.017 E.01876
G1 X74.748 Y121.017 E.4057
G1 X74.748 Y122.237 E.03751
G1 X87.952 Y122.237 E.4057
G1 X87.952 Y121.687 E.01691
G1 X87.552 Y121.627 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X87.552 Y121.416 E.00725
G1 X75.148 Y121.416 E.42644
G1 X75.148 Y121.838 E.0145
G1 X87.552 Y121.838 E.42644
G1 X87.552 Y121.687 E.00519
G1 X76.463 Y125.434 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X74.834 Y125.434 E.05401
G1 X76.885 Y123.384 E.09618
G1 X79.328 Y123.384 E.08105
G1 X81.378 Y125.434 E.09618
G1 X82.51 Y125.434 E.03755
G1 X84.561 Y123.384 E.09618
G1 X87.004 Y123.384 E.08105
G1 X88.75 Y125.129 E.0819
G1 X88.75 Y125.434 E.0101
G1 X87.426 Y125.434 E.04391
G1 X73.923 Y125.755 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X88.717 Y125.755 E.40987
G1 X73.766 Y126.075 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.44702
G1 F3000
G1 X88.765 Y126.075 E.4939
G1 X88.765 Y126.479 E.01331
G1 X73.935 Y126.479 E.48832
G1 X73.935 Y126.883 E.01331
G1 X88.765 Y126.883 E.48832
G1 X88.765 Y127.287 E.01331
G1 X73.766 Y127.287 E.4939
; WIPE_START
G1 X75.766 Y127.287 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I.28 J1.184 P1  F30000
G1 X107.098 Y119.87 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X107.098 Y125.896 E.19987
G1 X107.098 Y126.296 E.01327
G1 F13999.876
G1 X107.098 Y126.696 E.01327
G1 F6459.938
G1 X107.098 Y127.096 E.01327
G1 F1800
G1 X107.098 Y127.478 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X107.098 Y127.634 E.00515
G1 X94.902 Y127.634 E.40456
G1 X94.902 Y127.478 E.00515
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X94.902 Y127.096 E.01269
G1 F6459.938
G1 X94.902 Y126.696 E.01327
G1 F13999.876
G1 X94.902 Y126.296 E.01327
G1 F15476.087
G1 X94.902 Y125.896 E.01327
G1 X94.902 Y119.87 E.19988
G1 X106.824 Y119.87 E.39546
G1 X107.038 Y119.87 E.0071
; WIPE_START
G1 X107.058 Y121.87 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.967 Y118.278 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X107.49 Y119.745 I2.092 J1.491 E.04814
G1 X107.49 Y126.309 E.20169
G1 X107.49 Y126.709 E.01229
G1 F6459.938
G1 X107.49 Y127.109 E.01229
G1 F1800
G1 X107.49 Y127.478 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X107.49 Y128.026 E.01816
G1 X94.51 Y128.026 E.43057
G1 X94.51 Y127.478 E.01816
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y127.109 E.01134
G1 F6459.938
G1 X94.51 Y126.709 E.01229
G1 F12000
G1 X94.51 Y126.309 E.01229
G1 X94.51 Y119.748 E.20162
G2 X93.998 Y118.231 I-2.556 J.019 E.05003
G1 X108.002 Y118.231 E.43031
M204 S10000
G1 X107.391 Y118.989 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X106.84 Y118.439 E.02394
G1 X106.307 Y118.439
G1 X107.302 Y119.434 E.04323
G1 X106.983 Y119.648
G1 X105.774 Y118.439 E.05255
G1 X105.241 Y118.439
G1 X106.45 Y119.648 E.05255
G1 X105.917 Y119.648
G1 X104.707 Y118.439 E.05255
G1 X104.174 Y118.439
G1 X105.384 Y119.648 E.05255
G1 X104.85 Y119.648
G1 X103.641 Y118.439 E.05255
G1 X103.108 Y118.439
G1 X104.317 Y119.648 E.05255
G1 X103.784 Y119.648
G1 X102.574 Y118.439 E.05255
G1 X102.041 Y118.439
G1 X103.251 Y119.648 E.05255
G1 X102.717 Y119.648
G1 X101.508 Y118.439 E.05255
G1 X100.975 Y118.439
G1 X102.184 Y119.648 E.05255
G1 X101.651 Y119.648
G1 X100.441 Y118.439 E.05255
G1 X99.908 Y118.439
G1 X101.117 Y119.648 E.05255
G1 X100.584 Y119.648
G1 X99.375 Y118.439 E.05255
G1 X98.842 Y118.439
G1 X100.051 Y119.648 E.05255
G1 X99.518 Y119.648
G1 X98.308 Y118.439 E.05255
G1 X97.775 Y118.439
G1 X98.984 Y119.648 E.05255
G1 X98.451 Y119.648
G1 X97.242 Y118.439 E.05255
G1 X96.709 Y118.439
G1 X97.918 Y119.648 E.05255
G1 X97.385 Y119.648
G1 X96.175 Y118.439 E.05255
G1 X95.642 Y118.439
G1 X96.851 Y119.648 E.05255
G1 X96.318 Y119.648
G1 X95.109 Y118.439 E.05255
G1 X94.576 Y118.439
G1 X95.785 Y119.648 E.05255
G1 X95.252 Y119.648
G1 X94.614 Y119.011 E.0277
; WIPE_START
M204 S10000
G1 X95.252 Y119.648 E-.34251
G1 X95.785 Y119.648 E-.20264
G1 X95.385 Y119.248 E-.21486
; WIPE_END
G1 E-.04 F1800
G1 X102.999 Y118.723 Z3.8 F30000
G1 X107.395 Y118.42 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.137576
G1 F15000
G1 X107.472 Y118.803 E.00301
G1 X94.828 Y119.667 F30000
; LINE_WIDTH: 0.15577
G1 F15000
G1 X94.689 Y119.371 E.003
G1 X94.682 Y118.943 F30000
; LINE_WIDTH: 0.114413
G1 F15000
G2 X94.476 Y118.631 I-8.913 J5.686 E.00218
G1 X94.679 Y118.945 F30000
; LINE_WIDTH: 0.17583
G1 F15000
G1 X94.48 Y118.628 E.00406
; WIPE_START
G1 X94.679 Y118.945 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X96.308 Y123.384 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X95.25 Y123.384 E.03509
G1 X95.25 Y123.954 E.01892
G1 X96.73 Y125.434 E.06942
G1 X97.862 Y125.434 E.03755
G1 X99.912 Y123.384 E.09618
G1 X102.356 Y123.384 E.08105
G1 X104.406 Y125.434 E.09618
G1 X105.538 Y125.434 E.03755
G1 X106.75 Y124.222 E.05684
G1 X106.75 Y123.384 E.02782
G1 X105.96 Y123.384 E.02619
G1 X106.706 Y121.627 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.706 Y120.263 E.04193
G1 X95.294 Y120.263 E.35064
G1 X95.294 Y122.992 E.08386
G1 X106.706 Y122.992 E.35064
G1 X106.706 Y121.687 E.04008
G1 X106.329 Y121.627 F30000
G1 F12000
G1 X106.329 Y120.64 E.03034
G1 X95.671 Y120.64 E.32747
G1 X95.671 Y122.615 E.06068
G1 X106.329 Y122.615 E.32747
G1 X106.329 Y121.687 E.0285
G1 X105.952 Y121.627 F30000
G1 F12000
G1 X105.952 Y121.017 E.01876
G1 X96.048 Y121.017 E.3043
G1 X96.048 Y122.237 E.03751
G1 X105.952 Y122.237 E.3043
G1 X105.952 Y121.687 E.01691
G1 X105.552 Y121.627 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X105.552 Y121.416 E.00725
G1 X96.448 Y121.416 E.31299
G1 X96.448 Y121.838 E.0145
G1 X105.552 Y121.838 E.31299
G1 X105.552 Y121.687 E.00519
G1 X95.223 Y125.755 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X106.717 Y125.755 E.31844
G1 X95.066 Y126.075 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.44702
G1 F3000
G1 X106.765 Y126.075 E.38524
G1 X106.765 Y126.479 E.01331
G1 X95.235 Y126.479 E.37965
G1 X95.235 Y126.883 E.01331
G1 X106.765 Y126.883 E.37965
G1 X106.765 Y127.287 E.01331
G1 X95.066 Y127.287 E.38524
; WIPE_START
G1 X97.066 Y127.287 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I.311 J1.176 P1  F30000
G1 X125.098 Y119.87 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X125.098 Y125.896 E.19987
G1 X125.098 Y126.296 E.01327
G1 F13999.876
G1 X125.098 Y126.696 E.01327
G1 F6459.938
G1 X125.098 Y127.096 E.01327
G1 F1800
G1 X125.098 Y127.478 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X125.098 Y127.634 E.00515
G1 X112.902 Y127.634 E.40456
G1 X112.902 Y127.478 E.00515
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X112.902 Y127.096 E.01269
G1 F6459.938
G1 X112.902 Y126.696 E.01327
G1 F13999.876
G1 X112.902 Y126.296 E.01327
G1 F15476.087
G1 X112.902 Y125.896 E.01327
G1 X112.902 Y119.87 E.19988
G1 X124.824 Y119.87 E.39546
G1 X125.038 Y119.87 E.0071
; WIPE_START
G1 X125.058 Y121.87 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X126.003 Y118.231 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X125.967 Y118.278 E.00182
G2 X125.49 Y119.745 I2.092 J1.491 E.04814
G1 X125.49 Y126.309 E.20169
G1 X125.49 Y126.709 E.01229
G1 F6459.938
G1 X125.49 Y127.109 E.01229
G1 F1800
G1 X125.49 Y127.478 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X125.49 Y128.026 E.01816
G1 X112.51 Y128.026 E.43057
G1 X112.51 Y127.478 E.01816
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y127.109 E.01134
G1 F6459.938
G1 X112.51 Y126.709 E.01229
G1 F12000
G1 X112.51 Y126.309 E.01229
G1 X112.51 Y119.748 E.20162
G2 X111.998 Y118.231 I-2.556 J.019 E.05003
G1 X125.943 Y118.231 E.42849
M204 S10000
G1 X124.971 Y118.439 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X125.423 Y118.89 E.01962
G1 X125.318 Y119.318
G1 X124.438 Y118.439 E.03823
G1 X123.905 Y118.439
G1 X125.114 Y119.648 E.05255
G1 X124.581 Y119.648
G1 X123.371 Y118.439 E.05255
G1 X122.838 Y118.439
G1 X124.048 Y119.648 E.05255
M73 P62 R11
G1 X123.514 Y119.648
G1 X122.305 Y118.439 E.05255
G1 X121.772 Y118.439
G1 X122.981 Y119.648 E.05255
G1 X122.448 Y119.648
G1 X121.238 Y118.439 E.05255
G1 X120.705 Y118.439
G1 X121.915 Y119.648 E.05255
G1 X121.381 Y119.648
G1 X120.172 Y118.439 E.05255
G1 X119.639 Y118.439
G1 X120.848 Y119.648 E.05255
G1 X120.315 Y119.648
G1 X119.105 Y118.439 E.05255
G1 X118.572 Y118.439
G1 X119.781 Y119.648 E.05255
G1 X119.248 Y119.648
G1 X118.039 Y118.439 E.05255
G1 X117.506 Y118.439
G1 X118.715 Y119.648 E.05255
G1 X118.182 Y119.648
G1 X116.972 Y118.439 E.05255
G1 X116.439 Y118.439
G1 X117.648 Y119.648 E.05255
G1 X117.115 Y119.648
G1 X115.906 Y118.439 E.05255
G1 X115.373 Y118.439
G1 X116.582 Y119.648 E.05255
G1 X116.049 Y119.648
G1 X114.839 Y118.439 E.05255
G1 X114.306 Y118.439
G1 X115.515 Y119.648 E.05255
G1 X114.982 Y119.648
G1 X113.773 Y118.439 E.05255
G1 X113.24 Y118.439
G1 X114.449 Y119.648 E.05255
G1 X113.916 Y119.648
G1 X112.706 Y118.439 E.05255
G1 X112.552 Y118.817
G1 X113.382 Y119.648 E.03609
M204 S10000
G1 X112.889 Y119.667 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.166987
G1 F15000
G1 X112.664 Y119.216 E.0051
G1 X112.882 Y119.667 F30000
; LINE_WIDTH: 0.259991
G1 F15000
G1 X112.668 Y119.213 E.00887
G1 X125.243 Y119.393 F30000
; LINE_WIDTH: 0.125893
G1 F15000
G3 X125.267 Y119.667 I-.328 J.167 E.0019
; WIPE_START
G1 X125.276 Y119.486 E-.49104
G1 X125.243 Y119.393 E-.26896
; WIPE_END
G1 E-.04 F1800
G1 X124.706 Y122.992 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.706 Y120.263 E.08386
G1 X113.294 Y120.263 E.35064
G1 X113.294 Y122.992 E.08386
G1 X124.646 Y122.992 E.3488
G1 X124.329 Y122.615 F30000
G1 F12000
G1 X124.329 Y120.64 E.06068
G1 X113.671 Y120.64 E.32747
G1 X113.671 Y122.615 E.06068
G1 X124.269 Y122.615 E.32563
G1 X123.952 Y122.237 F30000
G1 F12000
G1 X123.952 Y121.017 E.03751
G1 X114.048 Y121.017 E.3043
G1 X114.048 Y122.237 E.03751
G1 X123.892 Y122.237 E.30245
G1 X123.552 Y121.838 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X123.552 Y121.416 E.0145
G1 X114.448 Y121.416 E.31299
G1 X114.448 Y121.838 E.0145
G1 X123.492 Y121.838 E.31093
G1 X114.842 Y125.434 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X113.25 Y125.398 E.05283
G1 X115.264 Y123.384 E.09448
G1 X117.708 Y123.384 E.08105
G1 X119.758 Y125.434 E.09618
G1 X120.89 Y125.434 E.03755
G1 X122.94 Y123.384 E.09618
G1 X124.569 Y123.384 E.05401
G1 X113.223 Y125.755 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X124.717 Y125.755 E.31844
G1 X113.066 Y126.075 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.44702
G1 F3000
G1 X124.765 Y126.075 E.38524
G1 X124.765 Y126.479 E.01331
G1 X113.235 Y126.479 E.37965
G1 X113.235 Y126.883 E.01331
G1 X124.765 Y126.883 E.37965
G1 X124.765 Y127.287 E.01331
G1 X113.066 Y127.287 E.38524
; WIPE_START
G1 X115.066 Y127.287 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I.311 J1.176 P1  F30000
G1 X143.098 Y119.87 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X143.098 Y125.896 E.19987
G1 X143.098 Y126.296 E.01327
G1 F13999.876
G1 X143.098 Y126.696 E.01327
G1 F6459.938
G1 X143.098 Y127.096 E.01327
G1 F1800
G1 X143.098 Y127.478 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X143.098 Y127.634 E.00515
G1 X130.902 Y127.634 E.40456
G1 X130.902 Y127.478 E.00515
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X130.902 Y127.096 E.01269
G1 F6459.938
G1 X130.902 Y126.696 E.01327
G1 F13999.876
G1 X130.902 Y126.296 E.01327
G1 F15476.087
G1 X130.902 Y125.896 E.01327
G1 X130.902 Y119.87 E.19988
G1 X142.824 Y119.87 E.39546
G1 X143.038 Y119.87 E.0071
; WIPE_START
G1 X143.058 Y121.87 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X144.002 Y118.231 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X143.967 Y118.278 E.00182
G2 X143.49 Y119.745 I2.092 J1.491 E.04814
G1 X143.49 Y126.309 E.20169
G1 X143.49 Y126.709 E.01229
G1 F6459.938
G1 X143.49 Y127.109 E.01229
G1 F1800
G1 X143.49 Y127.478 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X143.49 Y128.026 E.01816
G1 X130.51 Y128.026 E.43057
G1 X130.51 Y127.478 E.01816
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y127.109 E.01134
G1 F6459.938
G1 X130.51 Y126.709 E.01229
G1 F12000
G1 X130.51 Y126.309 E.01229
G1 X130.51 Y119.748 E.20162
G2 X129.998 Y118.231 I-2.557 J.019 E.05003
G1 X143.942 Y118.231 E.42849
M204 S10000
G1 X143.102 Y118.439 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X143.457 Y118.794 E.01543
G1 X143.338 Y119.208
G1 X142.569 Y118.439 E.03342
G1 X142.035 Y118.439
G1 X143.245 Y119.648 E.05255
G1 X142.712 Y119.648
G1 X141.502 Y118.439 E.05255
G1 X140.969 Y118.439
G1 X142.178 Y119.648 E.05255
G1 X141.645 Y119.648
G1 X140.436 Y118.439 E.05255
G1 X139.902 Y118.439
G1 X141.112 Y119.648 E.05255
G1 X140.579 Y119.648
G1 X139.369 Y118.439 E.05255
G1 X138.836 Y118.439
G1 X140.045 Y119.648 E.05255
G1 X139.512 Y119.648
G1 X138.303 Y118.439 E.05255
G1 X137.769 Y118.439
G1 X138.979 Y119.648 E.05255
G1 X138.445 Y119.648
G1 X137.236 Y118.439 E.05255
G1 X136.703 Y118.439
G1 X137.912 Y119.648 E.05255
G1 X137.379 Y119.648
G1 X136.17 Y118.439 E.05255
G1 X135.636 Y118.439
G1 X136.846 Y119.648 E.05255
M73 P62 R10
G1 X136.312 Y119.648
G1 X135.103 Y118.439 E.05255
G1 X134.57 Y118.439
G1 X135.779 Y119.648 E.05255
G1 X135.246 Y119.648
G1 X134.037 Y118.439 E.05255
G1 X133.503 Y118.439
G1 X134.713 Y119.648 E.05255
G1 X134.179 Y119.648
G1 X132.97 Y118.439 E.05255
G1 X132.437 Y118.439
G1 X133.646 Y119.648 E.05255
G1 X133.113 Y119.648
G1 X131.904 Y118.439 E.05255
G1 X131.37 Y118.439
G1 X132.58 Y119.648 E.05255
G1 X132.046 Y119.648
G1 X130.837 Y118.439 E.05255
G1 X130.46 Y118.595
G1 X131.513 Y119.648 E.04576
M204 S10000
G1 X130.975 Y119.667 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.105214
G1 F15000
G2 X130.622 Y119.048 I-39.408 J22.058 E.00362
G1 X130.955 Y119.667 F30000
; LINE_WIDTH: 0.183516
G1 F15000
G1 X130.626 Y119.046 E.00806
G1 X130.944 Y119.667 F30000
; LINE_WIDTH: 0.26951
G1 F15000
G1 X130.631 Y119.043 E.0129
G1 X130.934 Y119.667 F30000
; LINE_WIDTH: 0.367233
G1 F15000
G2 X130.644 Y119.045 I-27.595 J12.508 E.01813
; WIPE_START
G1 X130.934 Y119.667 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.431 Y123.384 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X133.06 Y123.384 E.05401
G1 X135.11 Y125.434 E.09618
G1 X136.242 Y125.434 E.03755
G1 X138.292 Y123.384 E.09618
G1 X140.736 Y123.384 E.08105
G1 X142.75 Y125.398 E.09449
G1 X141.158 Y125.434 E.05283
G1 X142.706 Y121.627 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.706 Y120.263 E.04193
G1 X131.294 Y120.263 E.35064
G1 X131.294 Y122.992 E.08386
G1 X142.706 Y122.992 E.35064
G1 X142.706 Y121.687 E.04008
G1 X142.329 Y121.627 F30000
G1 F12000
G1 X142.329 Y120.64 E.03034
G1 X131.671 Y120.64 E.32747
G1 X131.671 Y122.615 E.06068
G1 X142.329 Y122.615 E.32747
G1 X142.329 Y121.687 E.0285
G1 X141.952 Y121.627 F30000
G1 F12000
G1 X141.952 Y121.017 E.01876
G1 X132.048 Y121.017 E.3043
G1 X132.048 Y122.237 E.03751
G1 X141.952 Y122.237 E.3043
G1 X141.952 Y121.687 E.01691
G1 X141.552 Y121.627 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X141.552 Y121.416 E.00725
G1 X132.448 Y121.416 E.31299
G1 X132.448 Y121.838 E.0145
G1 X141.552 Y121.838 E.31299
G1 X141.552 Y121.687 E.00519
G1 X131.223 Y125.755 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X142.717 Y125.755 E.31844
G1 X131.066 Y126.075 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.44702
G1 F3000
G1 X142.765 Y126.075 E.38524
G1 X142.765 Y126.479 E.01331
G1 X131.235 Y126.479 E.37965
G1 X131.235 Y126.883 E.01331
G1 X142.765 Y126.883 E.37965
G1 X142.765 Y127.287 E.01331
G1 X131.066 Y127.287 E.38524
; WIPE_START
G1 X133.066 Y127.287 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I.311 J1.176 P1  F30000
G1 X161.098 Y119.87 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X161.098 Y125.896 E.19987
G1 X161.098 Y126.296 E.01327
G1 F13999.876
G1 X161.098 Y126.696 E.01327
G1 F6459.938
G1 X161.098 Y127.096 E.01327
G1 F1800
G1 X161.098 Y127.478 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X161.098 Y127.634 E.00515
G1 X148.902 Y127.634 E.40456
G1 X148.902 Y127.478 E.00515
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X148.902 Y127.096 E.01269
G1 F6459.938
G1 X148.902 Y126.696 E.01327
G1 F13999.876
G1 X148.902 Y126.296 E.01327
G1 F15476.087
G1 X148.902 Y125.896 E.01327
G1 X148.902 Y119.87 E.19988
G1 X160.824 Y119.87 E.39546
G1 X161.038 Y119.87 E.0071
; WIPE_START
G1 X161.058 Y121.87 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X162.002 Y118.231 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X161.967 Y118.278 E.00182
G2 X161.49 Y119.745 I2.092 J1.491 E.04814
G1 X161.49 Y126.309 E.20169
G1 X161.49 Y126.709 E.01229
G1 F6459.938
G1 X161.49 Y127.109 E.01229
G1 F1800
G1 X161.49 Y127.478 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X161.49 Y128.026 E.01816
G1 X148.51 Y128.026 E.43057
G1 X148.51 Y127.478 E.01816
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y127.109 E.01134
G1 F6459.938
G1 X148.51 Y126.709 E.01229
G1 F12000
G1 X148.51 Y126.309 E.01229
G1 X148.51 Y119.748 E.20162
G2 X147.998 Y118.231 I-2.557 J.019 E.05003
G1 X161.942 Y118.231 E.42849
; WIPE_START
M204 S10000
G1 X161.967 Y118.278 E-.02011
G1 X161.775 Y118.587 E-.13814
G1 X161.631 Y118.921 E-.13822
G1 X161.536 Y119.272 E-.13826
G1 X161.49 Y119.745 E-.18057
G1 X161.49 Y120.126 E-.14471
; WIPE_END
G1 E-.04 F1800
G1 X161.361 Y119.101 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X160.699 Y118.439 E.02876
G1 X160.166 Y118.439
G1 X161.288 Y119.56 E.04874
G1 X160.842 Y119.648
G1 X159.633 Y118.439 E.05255
G1 X159.1 Y118.439
G1 X160.309 Y119.648 E.05255
G1 X159.776 Y119.648
G1 X158.566 Y118.439 E.05255
G1 X158.033 Y118.439
G1 X159.243 Y119.648 E.05255
G1 X158.709 Y119.648
G1 X157.5 Y118.439 E.05255
G1 X156.967 Y118.439
G1 X158.176 Y119.648 E.05255
G1 X157.643 Y119.648
G1 X156.433 Y118.439 E.05255
G1 X155.9 Y118.439
G1 X157.11 Y119.648 E.05255
G1 X156.576 Y119.648
G1 X155.367 Y118.439 E.05255
G1 X154.834 Y118.439
G1 X156.043 Y119.648 E.05255
G1 X155.51 Y119.648
G1 X154.3 Y118.439 E.05255
G1 X153.767 Y118.439
G1 X154.976 Y119.648 E.05255
G1 X154.443 Y119.648
G1 X153.234 Y118.439 E.05255
G1 X152.701 Y118.439
G1 X153.91 Y119.648 E.05255
G1 X153.377 Y119.648
G1 X152.167 Y118.439 E.05255
G1 X151.634 Y118.439
G1 X152.843 Y119.648 E.05255
G1 X152.31 Y119.648
G1 X151.101 Y118.439 E.05255
G1 X150.568 Y118.439
G1 X151.777 Y119.648 E.05255
G1 X151.244 Y119.648
G1 X150.034 Y118.439 E.05255
G1 X149.501 Y118.439
G1 X150.71 Y119.648 E.05255
G1 X150.177 Y119.648
G1 X148.968 Y118.439 E.05255
G1 X148.435 Y118.439
G1 X149.644 Y119.648 E.05255
M73 P63 R10
G1 X149.111 Y119.648
G1 X148.66 Y119.197 E.01958
; WIPE_START
M204 S10000
G1 X149.111 Y119.648 E-.24209
G1 X149.644 Y119.648 E-.20264
G1 X149.057 Y119.061 E-.31527
; WIPE_END
G1 E-.04 F1800
G1 X156.679 Y118.663 Z3.8 F30000
G1 X161.324 Y118.42 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.10815
G1 F15000
G1 X161.436 Y118.908 E.00266
G1 X161.333 Y118.42 F30000
; LINE_WIDTH: 0.281268
G1 F15000
G1 X161.431 Y118.904 E.00959
G1 X148.728 Y119.13 F30000
; LINE_WIDTH: 0.134504
G1 F15000
G1 X148.568 Y118.861 E.00234
; WIPE_START
G1 X148.728 Y119.13 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X150.04 Y123.384 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X149.25 Y123.384 E.02619
G1 X149.25 Y124.222 E.02782
G1 X150.462 Y125.434 E.05683
G1 X151.594 Y125.434 E.03755
G1 X153.644 Y123.384 E.09618
G1 X156.088 Y123.384 E.08105
G1 X158.138 Y125.434 E.09618
G1 X159.27 Y125.434 E.03755
G1 X160.75 Y123.954 E.06942
G1 X160.75 Y123.384 E.01892
G1 X159.692 Y123.384 E.03509
G1 X160.706 Y121.627 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.706 Y120.263 E.04193
G1 X149.294 Y120.263 E.35064
G1 X149.294 Y122.992 E.08386
G1 X160.706 Y122.992 E.35064
G1 X160.706 Y121.687 E.04008
G1 X160.329 Y121.627 F30000
G1 F12000
G1 X160.329 Y120.64 E.03034
G1 X149.671 Y120.64 E.32747
G1 X149.671 Y122.615 E.06068
G1 X160.329 Y122.615 E.32747
G1 X160.329 Y121.687 E.0285
G1 X159.952 Y121.627 F30000
G1 F12000
G1 X159.952 Y121.017 E.01876
G1 X150.048 Y121.017 E.3043
G1 X150.048 Y122.237 E.03751
G1 X159.952 Y122.237 E.3043
G1 X159.952 Y121.687 E.01691
G1 X159.552 Y121.627 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X159.552 Y121.416 E.00725
G1 X150.448 Y121.416 E.31299
G1 X150.448 Y121.838 E.0145
G1 X159.552 Y121.838 E.31299
G1 X159.552 Y121.687 E.00519
G1 X149.223 Y125.755 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X160.717 Y125.755 E.31844
G1 X149.066 Y126.075 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.44702
G1 F3000
G1 X160.765 Y126.075 E.38524
G1 X160.765 Y126.479 E.01331
G1 X149.235 Y126.479 E.37965
G1 X149.235 Y126.883 E.01331
G1 X160.765 Y126.883 E.37965
G1 X160.765 Y127.287 E.01331
G1 X149.066 Y127.287 E.38524
; WIPE_START
G1 X151.066 Y127.287 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I.28 J1.184 P1  F30000
G1 X182.398 Y119.87 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y125.896 E.19988
G1 X182.398 Y126.296 E.01327
G1 F13999.876
G1 X182.398 Y126.696 E.01327
G1 F6459.938
G1 X182.398 Y127.096 E.01327
G1 F1800
G1 X182.398 Y127.478 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X182.398 Y127.634 E.00515
G1 F600
G1 X166.902 Y127.634 E.51403
G1 X166.902 Y127.478 E.00515
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X166.902 Y127.096 E.01269
G1 F6459.938
G1 X166.902 Y126.696 E.01327
G1 F13999.876
G1 X166.902 Y126.296 E.01327
G1 F15476.087
G1 X166.902 Y125.896 E.01327
G1 X166.902 Y119.87 E.19988
G1 X182.338 Y119.87 E.51204
; WIPE_START
G1 X182.358 Y121.87 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y118.231 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y126.309 E.24822
G1 X182.79 Y126.709 E.01229
G1 F6459.938
G1 X182.79 Y127.109 E.01229
G1 F1800
G1 X182.79 Y127.478 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y128.026 E.01816
G1 F600
G1 X166.51 Y128.026 E.54004
G1 X166.51 Y127.478 E.01816
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X166.51 Y127.109 E.01134
G1 F6459.938
G1 X166.51 Y126.709 E.01229
G1 F12000
G1 X166.51 Y126.309 E.01229
G1 X166.51 Y119.748 E.20162
G2 X165.998 Y118.231 I-2.557 J.019 E.05003
G1 X182.73 Y118.231 E.51414
M204 S10000
G1 X182.583 Y118.991 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.03 Y118.439 E.02402
G1 X181.497 Y118.439
G1 X182.583 Y119.525 E.0472
G1 X182.173 Y119.648
G1 X180.963 Y118.439 E.05255
G1 X180.43 Y118.439
G1 X181.639 Y119.648 E.05255
G1 X181.106 Y119.648
G1 X179.897 Y118.439 E.05255
G1 X179.364 Y118.439
G1 X180.573 Y119.648 E.05255
G1 X180.04 Y119.648
G1 X178.83 Y118.439 E.05255
G1 X178.297 Y118.439
G1 X179.506 Y119.648 E.05255
G1 X178.973 Y119.648
G1 X177.764 Y118.439 E.05255
G1 X177.23 Y118.439
G1 X178.44 Y119.648 E.05255
G1 X177.907 Y119.648
G1 X176.697 Y118.439 E.05255
G1 X176.164 Y118.439
G1 X177.373 Y119.648 E.05255
G1 X176.84 Y119.648
G1 X175.631 Y118.439 E.05255
G1 X175.097 Y118.439
G1 X176.307 Y119.648 E.05255
G1 X175.774 Y119.648
G1 X174.564 Y118.439 E.05255
G1 X174.031 Y118.439
G1 X175.24 Y119.648 E.05255
G1 X174.707 Y119.648
G1 X173.498 Y118.439 E.05255
G1 X172.964 Y118.439
G1 X174.174 Y119.648 E.05255
G1 X173.64 Y119.648
G1 X172.431 Y118.439 E.05255
G1 X171.898 Y118.439
G1 X173.107 Y119.648 E.05255
G1 X172.574 Y119.648
G1 X171.365 Y118.439 E.05255
G1 X170.831 Y118.439
G1 X172.041 Y119.648 E.05255
G1 X171.507 Y119.648
G1 X170.298 Y118.439 E.05255
G1 X169.765 Y118.439
G1 X170.974 Y119.648 E.05255
G1 X170.441 Y119.648
G1 X169.232 Y118.439 E.05255
G1 X168.698 Y118.439
G1 X169.908 Y119.648 E.05255
G1 X169.374 Y119.648
G1 X168.165 Y118.439 E.05255
G1 X167.632 Y118.439
G1 X168.841 Y119.648 E.05255
G1 X168.308 Y119.648
G1 X167.099 Y118.439 E.05255
G1 X166.565 Y118.439
G1 X167.775 Y119.648 E.05255
G1 X167.241 Y119.648
G1 X166.618 Y119.025 E.02708
M204 S10000
G1 X166.824 Y119.667 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.147266
G1 F15000
G1 X166.69 Y119.383 E.00267
G1 X166.688 Y118.955 F30000
; LINE_WIDTH: 0.108572
G1 F15000
G2 X166.483 Y118.65 I-12.805 J8.335 E.00197
G1 X166.684 Y118.959 F30000
; LINE_WIDTH: 0.168181
G1 F15000
G1 X166.487 Y118.647 E.00376
; WIPE_START
G1 X166.684 Y118.959 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X168.574 Y125.434 Z3.8 F30000
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.25 Y125.434 E.04391
G1 X167.25 Y125.129 E.0101
G1 X168.996 Y123.384 E.0819
G1 X171.439 Y123.384 E.08105
G1 X173.49 Y125.434 E.09618
G1 X174.622 Y125.434 E.03755
G1 X176.672 Y123.384 E.09618
G1 X179.115 Y123.384 E.08105
G1 X181.166 Y125.434 E.09618
G1 X179.537 Y125.434 E.05401
G1 X182.006 Y121.627 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y120.263 E.04193
G1 X167.294 Y120.263 E.45204
G1 X167.294 Y122.992 E.08386
G1 X182.006 Y122.992 E.45204
G1 X182.006 Y121.687 E.04008
G1 X181.629 Y121.627 F30000
G1 F12000
G1 X181.629 Y120.64 E.03034
G1 X167.671 Y120.64 E.42887
G1 X167.671 Y122.615 E.06068
G1 X181.629 Y122.615 E.42887
G1 X181.629 Y121.687 E.0285
G1 X181.252 Y121.627 F30000
G1 F12000
G1 X181.252 Y121.017 E.01876
G1 X168.048 Y121.017 E.4057
G1 X168.048 Y122.237 E.03751
G1 X181.252 Y122.237 E.4057
G1 X181.252 Y121.687 E.01691
G1 X180.852 Y121.627 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X180.852 Y121.416 E.00725
G1 X168.448 Y121.416 E.42645
G1 X168.448 Y121.838 E.0145
G1 X180.852 Y121.838 E.42645
G1 X180.852 Y121.687 E.00519
G1 X167.223 Y125.755 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F15000
G1 X182.017 Y125.755 E.40987
G1 X167.066 Y126.075 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.44702
G1 F3000
G1 X182.065 Y126.075 E.4939
G1 X182.065 Y126.479 E.01331
G1 X167.235 Y126.479 E.48832
G1 X167.235 Y126.883 E.01331
G1 X182.065 Y126.883 E.48832
G1 X182.065 Y127.287 E.01331
G1 X167.066 Y127.287 E.4939
; WIPE_START
G1 X169.066 Y127.287 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z3.8 I-.724 J.978 P1  F30000
G1 X182.398 Y137.148 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X73.602 Y137.148 E3.60896
G1 X73.602 Y135.029 E.0703
G1 X73.602 Y134.994 E.00116
G1 X182.398 Y134.994 E3.60896
G1 X182.398 Y135.029 E.00116
G1 X182.398 Y137.088 E.06831
M204 S250
G1 X182.79 Y137.54 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.21 Y137.54 E3.36709
G1 X73.21 Y135.815 E.053
G1 X73.21 Y135.415 E.01229
G1 F6459.938
G1 X73.21 Y135.015 E.01229
G1 F1800
G1 X73.21 Y134.646 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X73.21 Y134.602 E.00148
G1 X182.79 Y134.602 E3.63497
G1 X182.79 Y134.646 E.00148
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y135.015 E.01134
G1 F6459.938
G1 X182.79 Y135.415 E.01229
G1 F12000
G1 X182.79 Y135.815 E.01229
G1 X182.79 Y137.48 E.05116
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X180.79 Y137.481 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X173.158 Y137.398 Z3.8 F30000
G1 X75.294 Y136.33 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X76.923 Y136.33 E.05401
G1 X77.392 Y136.8 E.02202
G1 X78.821 Y136.8 E.04738
G1 X79.29 Y136.33 E.02202
G1 X84.599 Y136.33 E.1761
G1 X85.068 Y136.8 E.02202
G1 X86.496 Y136.8 E.04739
G1 X86.966 Y136.33 E.02202
G1 X92.274 Y136.33 E.1761
G1 X92.744 Y136.8 E.02202
G1 X94.172 Y136.8 E.04739
G1 X94.642 Y136.33 E.02202
G1 X99.95 Y136.33 E.1761
G1 X100.42 Y136.8 E.02202
G1 X101.848 Y136.8 E.04739
G1 X102.318 Y136.33 E.02202
G1 X107.626 Y136.33 E.1761
G1 X108.096 Y136.8 E.02202
G1 X109.524 Y136.8 E.04739
G1 X109.994 Y136.33 E.02202
G1 X115.302 Y136.33 E.1761
G1 X115.772 Y136.8 E.02202
G1 X117.2 Y136.8 E.04739
G1 X117.67 Y136.33 E.02202
G1 X122.978 Y136.33 E.1761
G1 X123.448 Y136.8 E.02202
G1 X124.876 Y136.8 E.04739
G1 X125.346 Y136.33 E.02202
G1 X130.654 Y136.33 E.1761
G1 X131.124 Y136.8 E.02202
G1 X132.552 Y136.8 E.04739
G1 X133.022 Y136.33 E.02202
G1 X138.33 Y136.33 E.1761
G1 X138.8 Y136.8 E.02202
G1 X140.228 Y136.8 E.04739
G1 X140.698 Y136.33 E.02202
G1 X146.006 Y136.33 E.17609
G1 X146.476 Y136.8 E.02202
G1 X147.904 Y136.8 E.04739
G1 X148.374 Y136.33 E.02202
G1 X153.682 Y136.33 E.1761
G1 X154.152 Y136.8 E.02202
G1 X155.58 Y136.8 E.04739
G1 X156.05 Y136.33 E.02202
G1 X161.358 Y136.33 E.17609
G1 X161.828 Y136.8 E.02202
G1 X163.256 Y136.8 E.04739
G1 X163.725 Y136.33 E.02202
G1 X169.034 Y136.33 E.1761
G1 X169.504 Y136.8 E.02202
G1 X170.932 Y136.8 E.04739
G1 X171.401 Y136.33 E.02202
G1 X176.71 Y136.33 E.17609
G1 X177.179 Y136.8 E.02202
G1 X178.608 Y136.8 E.04739
G1 X179.077 Y136.33 E.02202
G1 X180.706 Y136.33 E.05401
G1 X74.038 Y135.43 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.5077
G1 F13554.799
G1 X74.038 Y135.894 E.0176
G1 X181.962 Y135.894 E4.08748
G1 X181.962 Y135.43 E.0176
G1 X74.098 Y135.43 E4.08521
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F13554.799
G1 X76.098 Y135.43 E-.76
; WIPE_END
M73 P64 R10
G1 E-.04 F1800
; layer num/total_layer_count: 18/33
; update layer progress
M73 L18
M991 S0 P17 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z3.8 I-.02 J1.217 P1  F30000
G1 X182.398 Y137.148 Z3.8
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X73.602 Y137.148 E3.60896
G1 X73.602 Y134.574 E.08538
G1 X73.602 Y134.539 E.00116
G1 X182.398 Y134.539 E3.60896
G1 X182.398 Y134.574 E.00116
G1 X182.398 Y137.088 E.08339
M204 S250
G1 X182.79 Y137.54 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.21 Y137.54 E3.36709
G1 X73.21 Y135.361 E.06697
G1 X73.21 Y134.961 E.01229
G1 F6459.938
G1 X73.21 Y134.561 E.01229
G1 F1800
G1 X73.21 Y134.192 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X73.21 Y134.147 E.00148
G1 X182.79 Y134.147 E3.63497
G1 X182.79 Y134.192 E.00148
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y134.561 E.01134
G1 F6459.938
G1 X182.79 Y134.961 E.01229
G1 F12000
G1 X182.79 Y135.361 E.01229
G1 X182.79 Y137.48 E.06513
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X180.79 Y137.481 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.16 Y135.876 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.532 Y135.876 E.05401
G1 X178.608 Y136.8 E.04335
G1 X177.179 Y136.8 E.04739
G1 X176.255 Y135.876 E.04335
G1 X171.856 Y135.876 E.14594
G1 X170.932 Y136.8 E.04335
G1 X169.504 Y136.8 E.04739
G1 X168.58 Y135.876 E.04335
G1 X164.18 Y135.876 E.14594
G1 X163.256 Y136.8 E.04335
G1 X161.828 Y136.8 E.04739
G1 X160.904 Y135.876 E.04335
G1 X156.504 Y135.876 E.14594
G1 X155.58 Y136.8 E.04335
G1 X154.152 Y136.8 E.04739
G1 X153.228 Y135.876 E.04335
G1 X148.828 Y135.876 E.14594
G1 X147.904 Y136.8 E.04335
G1 X146.476 Y136.8 E.04739
G1 X145.552 Y135.876 E.04335
G1 X141.152 Y135.876 E.14594
G1 X140.228 Y136.8 E.04335
G1 X138.8 Y136.8 E.04739
G1 X137.876 Y135.876 E.04335
G1 X133.476 Y135.876 E.14594
G1 X132.552 Y136.8 E.04335
G1 X131.124 Y136.8 E.04739
G1 X130.2 Y135.876 E.04335
G1 X125.8 Y135.876 E.14594
G1 X124.876 Y136.8 E.04335
G1 X123.448 Y136.8 E.04739
G1 X122.524 Y135.876 E.04335
G1 X118.124 Y135.876 E.14594
G1 X117.2 Y136.8 E.04335
G1 X115.772 Y136.8 E.04739
G1 X114.848 Y135.876 E.04335
G1 X110.448 Y135.876 E.14594
G1 X109.524 Y136.8 E.04335
G1 X108.096 Y136.8 E.04739
G1 X107.172 Y135.876 E.04335
G1 X102.772 Y135.876 E.14594
G1 X101.848 Y136.8 E.04335
G1 X100.42 Y136.8 E.04739
G1 X99.496 Y135.876 E.04335
G1 X95.096 Y135.876 E.14594
G1 X94.172 Y136.8 E.04335
G1 X92.744 Y136.8 E.04739
G1 X91.82 Y135.876 E.04335
G1 X87.42 Y135.876 E.14594
G1 X86.496 Y136.8 E.04335
G1 X85.068 Y136.8 E.04739
G1 X84.144 Y135.876 E.04335
G1 X79.745 Y135.876 E.14594
G1 X78.821 Y136.8 E.04335
G1 X77.392 Y136.8 E.04738
G1 X76.468 Y135.876 E.04335
G1 X74.84 Y135.876 E.05401
G1 X74.038 Y134.975 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.5077
G1 F13554.799
G1 X74.038 Y135.44 E.0176
G1 X181.962 Y135.44 E4.08748
G1 X181.962 Y134.975 E.0176
G1 X74.098 Y134.975 E4.08521
; WIPE_START
G1 X76.098 Y134.975 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.163 J1.206 P1  F30000
G1 X182.398 Y120.642 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y126.853 E.20604
G1 X182.398 Y127.253 E.01327
G1 F14331.075
G1 X182.398 Y127.653 E.01327
G1 F6685.538
G1 X182.398 Y128.053 E.01327
G1 F1920
G1 X182.398 Y128.436 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X182.398 Y128.884 E.01486
G1 F600
G1 X166.899 Y128.884 E.51412
G2 X166.902 Y128.436 I-9.714 J-.287 E.01486
; FEATURE: Inner wall
M73 P65 R10
G1 F1920
M204 S10000
G1 X166.902 Y128.053 E.01269
G1 F6685.538
G1 X166.902 Y127.653 E.01327
G1 F14331.075
G1 X166.902 Y127.253 E.01327
G1 F15476.087
G1 X166.902 Y126.853 E.01327
G1 X166.902 Y120.642 E.20604
G1 X182.338 Y120.642 E.51204
; WIPE_START
G1 X182.357 Y122.642 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y119.003 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y127.267 E.25393
G1 X182.79 Y127.667 E.01229
G1 F6685.538
G1 X182.79 Y128.067 E.01229
G1 F1920
G1 X182.79 Y128.436 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y129.276 E.02786
G1 F600
G1 X166.454 Y129.276 E.54191
G2 X166.51 Y128.436 I-3.474 J-.655 E.02799
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1920
G1 X166.51 Y128.067 E.01134
G1 F6685.538
G1 X166.51 Y127.667 E.01229
G1 F12000
G1 X166.51 Y127.267 E.01229
G1 X166.51 Y119.748 E.23104
G2 X166.396 Y119.003 I-2.545 J.009 E.02325
G1 X182.73 Y119.003 E.50191
M204 S10000
G1 X182.583 Y119.677 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.84 Y120.419 E.03225
G1 X181.307 Y120.419
G1 X182.516 Y119.21 E.05255
G1 X181.983 Y119.21
G1 X180.774 Y120.419 E.05255
G1 X180.241 Y120.419
G1 X181.45 Y119.21 E.05255
G1 X180.917 Y119.21
G1 X179.707 Y120.419 E.05255
G1 X179.174 Y120.419
G1 X180.383 Y119.21 E.05255
G1 X179.85 Y119.21
G1 X178.641 Y120.419 E.05255
G1 X178.108 Y120.419
G1 X179.317 Y119.21 E.05255
G1 X178.784 Y119.21
G1 X177.574 Y120.419 E.05255
G1 X177.041 Y120.419
G1 X178.25 Y119.21 E.05255
G1 X177.717 Y119.21
G1 X176.508 Y120.419 E.05255
G1 X175.975 Y120.419
G1 X177.184 Y119.21 E.05255
G1 X176.651 Y119.21
G1 X175.441 Y120.419 E.05255
G1 X174.908 Y120.419
G1 X176.117 Y119.21 E.05255
G1 X175.584 Y119.21
G1 X174.375 Y120.419 E.05255
G1 X173.842 Y120.419
G1 X175.051 Y119.21 E.05255
G1 X174.518 Y119.21
G1 X173.308 Y120.419 E.05255
G1 X172.775 Y120.419
G1 X173.984 Y119.21 E.05255
G1 X173.451 Y119.21
G1 X172.242 Y120.419 E.05255
G1 X171.708 Y120.419
G1 X172.918 Y119.21 E.05255
G1 X172.385 Y119.21
G1 X171.175 Y120.419 E.05255
G1 X170.642 Y120.419
G1 X171.851 Y119.21 E.05255
G1 X171.318 Y119.21
G1 X170.109 Y120.419 E.05255
G1 X169.575 Y120.419
G1 X170.785 Y119.21 E.05255
G1 X170.252 Y119.21
G1 X169.042 Y120.419 E.05255
G1 X168.509 Y120.419
G1 X169.718 Y119.21 E.05255
G1 X169.185 Y119.21
G1 X167.976 Y120.419 E.05255
G1 X167.442 Y120.419
G1 X168.652 Y119.21 E.05255
G1 X168.118 Y119.21
G1 X166.909 Y120.419 E.05255
G1 X166.717 Y120.078
G1 X167.585 Y119.21 E.03771
G1 X167.052 Y119.21
G1 X166.71 Y119.553 E.01488
M204 S10000
G1 X166.784 Y119.744 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.108985
G1 F15000
G1 X166.692 Y119.535 E.00123
; WIPE_START
G1 X166.784 Y119.744 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X167.314 Y126.619 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.464
G1 F14961.528
G1 X181.924 Y126.619 E.5013
G1 X182.234 Y127.021 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42472
G1 F3000
M73 P65 R9
G1 X167.233 Y127.021 E.46672
G1 X167.233 Y127.403 E.01188
G1 X182.065 Y127.403 E.46144
G1 X182.065 Y127.784 E.01188
G1 X167.233 Y127.784 E.46145
G1 X167.233 Y128.166 E.01188
G1 X182.065 Y128.166 E.46145
G1 X182.065 Y128.548 E.01188
G1 X167.063 Y128.548 E.46673
; WIPE_START
G1 X169.063 Y128.548 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.393 J1.152 P1  F30000
G1 X181.948 Y124.155 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.05 Y124.155 E.00336
G1 X182.05 Y125.682 E.05065
G1 X181.526 Y126.205 E.02455
G1 X181.937 Y126.205 E.01363
M73 P66 R9
G1 X179.887 Y124.155 E.09618
G1 X175.901 Y124.155 E.13223
G1 X173.85 Y126.205 E.09618
G1 X174.261 Y126.205 E.01363
G1 X172.211 Y124.155 E.09618
G1 X168.225 Y124.155 E.13223
G1 X167.249 Y125.131 E.04578
G1 X167.248 Y126.205 E.03564
G1 X167.802 Y126.205 E.01838
G1 X182.006 Y122.398 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y121.034 E.04193
G1 X167.294 Y121.034 E.45204
G1 X167.293 Y123.763 E.08386
G1 X182.006 Y123.763 E.45207
G1 X182.006 Y122.458 E.04008
G1 X181.629 Y122.398 F30000
G1 F12000
G1 X181.629 Y121.411 E.03034
G1 X167.671 Y121.411 E.42888
G1 X167.67 Y123.386 E.06068
G1 X181.629 Y123.386 E.4289
G1 X181.629 Y122.458 E.0285
G1 X181.252 Y122.398 F30000
G1 F12000
G1 X181.252 Y121.788 E.01876
G1 X168.048 Y121.788 E.40571
G1 X168.047 Y123.009 E.03751
G1 X181.252 Y123.009 E.40572
G1 X181.252 Y122.458 E.01691
G1 X180.852 Y122.398 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X180.852 Y122.188 E.00725
G1 X168.447 Y122.188 E.42646
G1 X168.447 Y122.609 E.0145
G1 X180.852 Y122.609 E.42646
G1 X180.852 Y122.458 E.00519
; WIPE_START
G1 X180.852 Y122.609 E-.05736
G1 X179.003 Y122.609 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X171.416 Y121.776 Z4 F30000
G1 X161.098 Y120.642 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X161.098 Y126.853 E.20604
G1 X161.098 Y127.253 E.01327
G1 F13999.876
G1 X161.098 Y127.653 E.01327
G1 F6459.938
G1 X161.098 Y128.053 E.01327
G1 F1800
G1 X161.098 Y128.436 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X161.101 Y128.884 I9.158 J.161 E.01486
G1 X148.899 Y128.884 E.40476
G2 X148.902 Y128.436 I-9.713 J-.287 E.01486
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X148.902 Y128.053 E.01269
G1 F6459.938
G1 X148.902 Y127.653 E.01327
G1 F13999.876
G1 X148.902 Y127.253 E.01327
G1 F15476.087
G1 X148.902 Y126.853 E.01327
G1 X148.902 Y120.642 E.20605
G1 X157.789 Y120.642 E.29478
G1 X161.038 Y120.642 E.10779
; WIPE_START
G1 X161.057 Y122.642 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X161.604 Y119.003 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X161.49 Y119.748 I2.428 J.754 E.02325
G1 X161.49 Y127.267 E.23104
G1 X161.49 Y127.667 E.01229
G1 F6459.938
G1 X161.49 Y128.067 E.01229
G1 F1800
G1 X161.49 Y128.436 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G2 X161.546 Y129.276 I3.509 J.187 E.02799
G1 X148.454 Y129.276 E.43431
G2 X148.51 Y128.436 I-3.474 J-.655 E.02799
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X148.51 Y128.067 E.01134
G1 F6459.938
G1 X148.51 Y127.667 E.01229
G1 F12000
G1 X148.51 Y127.267 E.01229
G1 X148.51 Y119.748 E.23104
G2 X148.396 Y119.003 I-2.546 J.01 E.02325
G1 X160.824 Y119.003 E.38188
G1 X161.544 Y119.003 E.02214
; WIPE_START
M204 S10000
G1 X161.516 Y119.392 E-.14851
G1 X161.49 Y119.748 E-.13535
G1 X161.49 Y121.001 E-.47614
; WIPE_END
G1 E-.04 F1800
G1 X160.51 Y120.419 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X161.285 Y119.644 E.03367
G1 X161.186 Y119.21
G1 X159.977 Y120.419 E.05255
G1 X159.444 Y120.419
G1 X160.653 Y119.21 E.05255
G1 X160.12 Y119.21
G1 X158.91 Y120.419 E.05255
G1 X158.377 Y120.419
G1 X159.586 Y119.21 E.05255
G1 X159.053 Y119.21
G1 X157.844 Y120.419 E.05255
G1 X157.311 Y120.419
G1 X158.52 Y119.21 E.05255
G1 X157.987 Y119.21
G1 X156.777 Y120.419 E.05255
G1 X156.244 Y120.419
G1 X157.453 Y119.21 E.05255
G1 X156.92 Y119.21
G1 X155.711 Y120.419 E.05255
G1 X155.177 Y120.419
G1 X156.387 Y119.21 E.05255
G1 X155.854 Y119.21
G1 X154.644 Y120.419 E.05255
G1 X154.111 Y120.419
G1 X155.32 Y119.21 E.05255
G1 X154.787 Y119.21
G1 X153.578 Y120.419 E.05255
G1 X153.044 Y120.419
G1 X154.254 Y119.21 E.05255
G1 X153.721 Y119.21
G1 X152.511 Y120.419 E.05255
G1 X151.978 Y120.419
G1 X153.187 Y119.21 E.05255
G1 X152.654 Y119.21
G1 X151.445 Y120.419 E.05255
G1 X150.911 Y120.419
G1 X152.121 Y119.21 E.05255
G1 X151.588 Y119.21
G1 X150.378 Y120.419 E.05255
G1 X149.845 Y120.419
G1 X151.054 Y119.21 E.05255
G1 X150.521 Y119.21
G1 X149.312 Y120.419 E.05255
G1 X148.778 Y120.419
G1 X149.988 Y119.21 E.05255
G1 X149.454 Y119.21
G1 X148.717 Y119.947 E.03203
M204 S10000
G1 X148.894 Y119.191 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.112845
G1 F15000
G1 X148.7 Y119.698 E.00309
G1 X148.885 Y119.191 F30000
; LINE_WIDTH: 0.23474
G1 F15000
G1 X148.706 Y119.692 E.00832
; WIPE_START
G1 X148.885 Y119.191 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X149.314 Y126.619 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.46399
G1 F14961.884
G1 X160.626 Y126.619 E.38814
G1 X160.937 Y127.021 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X149.233 Y127.021 E.36417
G1 X149.233 Y127.403 E.01188
G1 X160.767 Y127.403 E.3589
G1 X160.767 Y127.784 E.01188
G1 X149.233 Y127.784 E.35891
G1 X149.233 Y128.166 E.01188
G1 X160.768 Y128.166 E.35891
G1 X160.768 Y128.548 E.01188
G1 X149.063 Y128.548 E.3642
; WIPE_START
G1 X151.063 Y128.548 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.356 J1.164 P1  F30000
G1 X160.752 Y125.581 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X160.751 Y124.155 E.0473
G1 X160.549 Y124.155 E.00671
G1 X158.498 Y126.205 E.09618
G1 X158.909 Y126.205 E.01363
G1 X156.859 Y124.155 E.09618
G1 X152.873 Y124.155 E.13223
G1 X150.822 Y126.205 E.09618
G1 X151.233 Y126.205 E.01363
G1 X149.249 Y124.221 E.09308
G1 X149.249 Y124.155 E.00219
G1 X150.811 Y124.155 E.05182
G1 X160.707 Y122.398 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.707 Y123.18 E.02403
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.707 Y123.763 E.01791
G1 X149.293 Y123.763 E.35071
G1 X149.293 Y123.18 E.01791
; Slow Down End
G1 F12000
G1 X149.294 Y121.034 E.06595
G1 X160.706 Y121.034 E.35065
G1 X160.707 Y122.338 E.04007
G1 X160.329 Y122.398 F30000
G1 F12000
G1 X160.33 Y123.18 E.02403
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.33 Y123.386 E.00632
G1 X149.67 Y123.386 E.32753
G1 X149.67 Y123.18 E.00632
; Slow Down End
G1 F12000
G1 X149.671 Y121.411 E.05436
G1 X160.329 Y121.411 E.32749
G1 X160.329 Y122.338 E.02849
G1 X159.952 Y122.398 F30000
G1 F12000
G1 X159.952 Y121.788 E.01875
G1 X150.048 Y121.788 E.30432
G1 X150.047 Y123.009 E.03751
G1 X159.953 Y123.009 E.30435
G1 X159.952 Y122.458 E.01692
G1 X159.553 Y122.398 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X159.553 Y122.188 E.00725
G1 X150.447 Y122.188 E.31303
G1 X150.447 Y122.609 E.0145
G1 X159.553 Y122.609 E.31304
G1 X159.553 Y122.458 E.00519
; WIPE_START
G1 X159.553 Y122.609 E-.05739
G1 X157.704 Y122.609 E-.70261
; WIPE_END
G1 E-.04 F1800
G1 X150.14 Y121.59 Z4 F30000
G1 X143.098 Y120.642 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X143.098 Y126.853 E.20604
G1 X143.098 Y127.253 E.01327
G1 F13999.876
G1 X143.098 Y127.653 E.01327
G1 F6459.938
G1 X143.098 Y128.053 E.01327
G1 F1800
G1 X143.098 Y128.436 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X143.101 Y128.884 I9.158 J.161 E.01486
G1 X130.899 Y128.884 E.40476
G2 X130.902 Y128.436 I-9.713 J-.287 E.01486
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X130.902 Y128.053 E.01269
G1 F6459.938
G1 X130.902 Y127.653 E.01327
G1 F13999.876
G1 X130.902 Y127.253 E.01327
G1 F15476.087
G1 X130.902 Y126.853 E.01327
G1 X130.902 Y120.642 E.20605
G1 X139.789 Y120.642 E.29478
G1 X143.038 Y120.642 E.10779
; WIPE_START
G1 X143.057 Y122.642 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X143.604 Y119.003 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X143.49 Y119.748 I2.428 J.754 E.02325
G1 X143.49 Y127.267 E.23104
G1 X143.49 Y127.667 E.01229
G1 F6459.938
G1 X143.49 Y128.067 E.01229
G1 F1800
G1 X143.49 Y128.436 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G2 X143.546 Y129.276 I3.509 J.187 E.02799
G1 X130.454 Y129.276 E.43431
G2 X130.51 Y128.436 I-3.474 J-.655 E.02799
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X130.51 Y128.067 E.01134
G1 F6459.938
G1 X130.51 Y127.667 E.01229
G1 F12000
G1 X130.51 Y127.267 E.01229
G1 X130.51 Y119.748 E.23104
G2 X130.396 Y119.003 I-2.545 J.009 E.02325
G1 X142.824 Y119.003 E.38188
G1 X143.544 Y119.003 E.02214
; WIPE_START
M204 S10000
G1 X143.516 Y119.392 E-.14851
G1 X143.49 Y119.748 E-.13535
G1 X143.49 Y121.001 E-.47614
; WIPE_END
G1 E-.04 F1800
G1 X143.283 Y120.049 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X142.913 Y120.419 E.01608
G1 X142.379 Y120.419
G1 X143.294 Y119.505 E.03974
G1 X143.055 Y119.21
G1 X141.846 Y120.419 E.05255
G1 X141.313 Y120.419
G1 X142.522 Y119.21 E.05255
G1 X141.989 Y119.21
G1 X140.78 Y120.419 E.05255
G1 X140.246 Y120.419
G1 X141.456 Y119.21 E.05255
G1 X140.922 Y119.21
G1 X139.713 Y120.419 E.05255
G1 X139.18 Y120.419
G1 X140.389 Y119.21 E.05255
G1 X139.856 Y119.21
G1 X138.646 Y120.419 E.05255
G1 X138.113 Y120.419
G1 X139.323 Y119.21 E.05255
G1 X138.789 Y119.21
G1 X137.58 Y120.419 E.05255
G1 X137.047 Y120.419
G1 X138.256 Y119.21 E.05255
G1 X137.723 Y119.21
G1 X136.513 Y120.419 E.05255
G1 X135.98 Y120.419
G1 X137.19 Y119.21 E.05255
G1 X136.656 Y119.21
G1 X135.447 Y120.419 E.05255
G1 X134.914 Y120.419
G1 X136.123 Y119.21 E.05255
G1 X135.59 Y119.21
G1 X134.38 Y120.419 E.05255
G1 X133.847 Y120.419
G1 X135.057 Y119.21 E.05255
G1 X134.523 Y119.21
G1 X133.314 Y120.419 E.05255
G1 X132.781 Y120.419
G1 X133.99 Y119.21 E.05255
G1 X133.457 Y119.21
G1 X132.247 Y120.419 E.05255
G1 X131.714 Y120.419
G1 X132.923 Y119.21 E.05255
G1 X132.39 Y119.21
G1 X131.181 Y120.419 E.05255
G1 X130.717 Y120.35
G1 X131.857 Y119.21 E.04952
G1 X131.324 Y119.21
G1 X130.717 Y119.816 E.02635
M204 S10000
G1 X130.832 Y119.191 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.121847
G1 F15000
G1 X130.694 Y119.573 E.00261
; WIPE_START
G1 X130.832 Y119.191 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X131.294 Y121.034 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.706 Y121.034 E.35065
G1 X142.707 Y123.18 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.707 Y123.763 E.01791
G1 X131.293 Y123.763 E.35071
G1 X131.293 Y123.18 E.01791
; Slow Down End
G1 F12000
G1 X131.294 Y121.094 E.0641
G1 X131.67 Y123.386 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.67 Y123.18 E.00632
; Slow Down End
G1 F12000
G1 X131.671 Y121.411 E.05436
G1 X142.329 Y121.411 E.32749
G1 X142.33 Y123.18 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.33 Y123.386 E.00632
; Slow Down End
G1 F12000
G1 X131.73 Y123.386 E.32569
G1 X132.047 Y123.009 F30000
G1 F12000
M73 P67 R9
G1 X141.953 Y123.009 E.30435
G1 X141.952 Y121.788 E.03751
G1 X132.048 Y121.788 E.30432
G1 X132.047 Y122.949 E.03567
G1 X132.447 Y122.609 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X141.553 Y122.609 E.31304
G1 X141.553 Y122.188 E.0145
G1 X132.447 Y122.188 E.31303
G1 X132.447 Y122.549 E.01244
G1 X131.314 Y126.619 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.46399
G1 F14961.884
G1 X142.626 Y126.619 E.38814
G1 X142.937 Y127.021 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X131.233 Y127.021 E.36417
G1 X131.233 Y127.403 E.01188
G1 X142.767 Y127.403 E.3589
G1 X142.767 Y127.784 E.01188
G1 X131.233 Y127.784 E.35891
G1 X131.233 Y128.166 E.01188
G1 X142.768 Y128.166 E.35891
G1 X142.768 Y128.548 E.01188
G1 X131.063 Y128.548 E.3642
; WIPE_START
G1 X133.063 Y128.548 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.311 J1.177 P1  F30000
G1 X141.929 Y126.205 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X142.752 Y126.205 E.02728
G1 X142.751 Y125.4 E.02673
G1 X141.507 Y124.155 E.05838
G1 X137.521 Y124.155 E.13223
G1 X135.471 Y126.205 E.09618
G1 X135.881 Y126.205 E.01363
G1 X133.831 Y124.155 E.09618
G1 X132.203 Y124.155 E.05401
; WIPE_START
G1 X133.831 Y124.155 E-.61876
G1 X134.094 Y124.418 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X127.056 Y121.464 Z4 F30000
G1 X125.098 Y120.642 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X125.098 Y126.853 E.20604
G1 X125.098 Y127.253 E.01327
G1 F13999.876
G1 X125.098 Y127.653 E.01327
G1 F6459.938
G1 X125.098 Y128.053 E.01327
G1 F1800
G1 X125.098 Y128.436 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X125.101 Y128.884 I9.1 J.161 E.01486
G1 X112.899 Y128.884 E.40476
G2 X112.902 Y128.436 I-9.395 J-.287 E.01486
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X112.902 Y128.053 E.01269
G1 F6459.938
G1 X112.902 Y127.653 E.01327
G1 F13999.876
G1 X112.902 Y127.253 E.01327
G1 F15476.087
G1 X112.902 Y126.853 E.01327
G1 X112.902 Y120.642 E.20605
G1 X121.789 Y120.642 E.29478
G1 X125.038 Y120.642 E.10779
; WIPE_START
G1 X125.057 Y122.642 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X125.604 Y119.003 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X125.49 Y119.748 I2.428 J.754 E.02325
G1 X125.49 Y127.267 E.23104
G1 X125.49 Y127.667 E.01229
G1 F6459.938
G1 X125.49 Y128.067 E.01229
G1 F1800
G1 X125.49 Y128.436 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G2 X125.546 Y129.276 I3.511 J.186 E.02799
G1 X112.454 Y129.276 E.43431
G2 X112.51 Y128.436 I-3.448 J-.653 E.02799
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X112.51 Y128.067 E.01134
G1 F6459.938
G1 X112.51 Y127.667 E.01229
G1 F12000
G1 X112.51 Y127.267 E.01229
G1 X112.51 Y119.748 E.23104
G2 X112.396 Y119.003 I-2.555 J.011 E.02324
G1 X124.824 Y119.003 E.38188
G1 X125.544 Y119.003 E.02214
M204 S10000
G1 X125.283 Y119.919 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X124.782 Y120.419 E.02176
G1 X124.249 Y120.419
G1 X125.311 Y119.357 E.04616
G1 X124.925 Y119.21
G1 X123.715 Y120.419 E.05255
G1 X123.182 Y120.419
G1 X124.391 Y119.21 E.05255
G1 X123.858 Y119.21
G1 X122.649 Y120.419 E.05255
G1 X122.116 Y120.419
G1 X123.325 Y119.21 E.05255
G1 X122.792 Y119.21
G1 X121.582 Y120.419 E.05255
G1 X121.049 Y120.419
G1 X122.258 Y119.21 E.05255
G1 X121.725 Y119.21
G1 X120.516 Y120.419 E.05255
G1 X119.982 Y120.419
G1 X121.192 Y119.21 E.05255
G1 X120.659 Y119.21
G1 X119.449 Y120.419 E.05255
G1 X118.916 Y120.419
G1 X120.125 Y119.21 E.05255
G1 X119.592 Y119.21
G1 X118.383 Y120.419 E.05255
G1 X117.849 Y120.419
G1 X119.059 Y119.21 E.05255
G1 X118.526 Y119.21
G1 X117.316 Y120.419 E.05255
G1 X116.783 Y120.419
G1 X117.992 Y119.21 E.05255
G1 X117.459 Y119.21
G1 X116.25 Y120.419 E.05255
G1 X115.716 Y120.419
G1 X116.926 Y119.21 E.05255
G1 X116.392 Y119.21
G1 X115.183 Y120.419 E.05255
G1 X114.65 Y120.419
G1 X115.859 Y119.21 E.05255
G1 X115.326 Y119.21
G1 X114.117 Y120.419 E.05255
G1 X113.583 Y120.419
G1 X114.793 Y119.21 E.05255
G1 X114.259 Y119.21
G1 X113.05 Y120.419 E.05255
G1 X112.717 Y120.219
G1 X113.726 Y119.21 E.04384
G1 X113.193 Y119.21
G1 X112.716 Y119.687 E.02073
M204 S10000
G1 X112.788 Y119.881 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.105788
G1 F15000
G1 X112.697 Y119.668 E.00119
; WIPE_START
G1 X112.788 Y119.881 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X113.294 Y121.034 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.706 Y121.034 E.35065
G1 X124.707 Y123.18 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.707 Y123.763 E.01791
G1 X113.293 Y123.763 E.35071
G1 X113.293 Y123.18 E.01791
; Slow Down End
G1 F12000
G1 X113.294 Y121.094 E.0641
G1 X113.671 Y121.411 F30000
G1 F12000
G1 X124.329 Y121.411 E.32749
G1 X124.33 Y123.18 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.33 Y123.386 E.00632
G1 X113.67 Y123.386 E.32753
G1 X113.67 Y123.18 E.00632
; Slow Down End
G1 F12000
G1 X113.671 Y121.471 E.05252
G1 X114.048 Y121.788 F30000
G1 F12000
G1 X114.047 Y123.009 E.03751
G1 X123.953 Y123.009 E.30435
G1 X123.952 Y121.788 E.03751
G1 X114.108 Y121.788 E.30248
G1 X114.447 Y122.188 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X114.447 Y122.609 E.0145
G1 X123.553 Y122.609 E.31305
G1 X123.553 Y122.188 E.0145
G1 X114.507 Y122.188 E.31097
G1 X113.314 Y126.619 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.464
G1 F14961.528
G1 X124.626 Y126.619 E.38815
G1 X124.937 Y127.021 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X113.233 Y127.021 E.36417
G1 X113.233 Y127.403 E.01188
G1 X124.767 Y127.403 E.3589
G1 X124.767 Y127.784 E.01188
G1 X113.233 Y127.784 E.35891
G1 X113.232 Y128.166 E.01188
G1 X124.768 Y128.166 E.35892
G1 X124.768 Y128.548 E.01188
G1 X113.063 Y128.548 E.36421
; WIPE_START
G1 X115.063 Y128.548 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.547 J1.087 P1  F30000
G1 X123.797 Y124.155 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X122.169 Y124.155 E.05401
G1 X120.119 Y126.205 E.09618
G1 X120.529 Y126.205 E.01363
G1 X118.479 Y124.155 E.09618
G1 X114.493 Y124.155 E.13223
G1 X113.249 Y125.4 E.05838
G1 X113.248 Y126.205 E.02673
G1 X114.071 Y126.205 E.02728
; WIPE_START
G1 X113.248 Y126.205 E-.31252
G1 X113.249 Y125.4 E-.30625
G1 X113.511 Y125.137 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X107.261 Y120.756 Z4 F30000
G1 X107.098 Y120.642 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X107.098 Y126.853 E.20604
G1 X107.098 Y127.253 E.01327
G1 F13999.876
G1 X107.098 Y127.653 E.01327
G1 F6459.938
G1 X107.098 Y128.053 E.01327
G1 F1800
G1 X107.098 Y128.436 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X107.101 Y128.884 I9.1 J.161 E.01486
G1 X94.899 Y128.884 E.40476
G2 X94.902 Y128.436 I-9.395 J-.287 E.01486
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X94.902 Y128.053 E.01269
G1 F6459.938
G1 X94.902 Y127.653 E.01327
G1 F13999.876
G1 X94.902 Y127.253 E.01327
G1 F15476.087
G1 X94.902 Y126.853 E.01327
G1 X94.902 Y120.642 E.20605
G1 X103.789 Y120.642 E.29478
G1 X107.038 Y120.642 E.10779
; WIPE_START
G1 X107.057 Y122.642 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.604 Y119.003 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X107.49 Y119.748 I2.428 J.754 E.02325
G1 X107.49 Y127.267 E.23104
G1 X107.49 Y127.667 E.01229
G1 F6459.938
G1 X107.49 Y128.067 E.01229
G1 F1800
G1 X107.49 Y128.436 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G2 X107.546 Y129.276 I3.511 J.186 E.02799
G1 X94.454 Y129.276 E.43431
G2 X94.51 Y128.436 I-3.448 J-.653 E.02799
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X94.51 Y128.067 E.01134
G1 F6459.938
G1 X94.51 Y127.667 E.01229
G1 F12000
G1 X94.51 Y127.267 E.01229
G1 X94.51 Y119.748 E.23104
G2 X94.396 Y119.003 I-2.556 J.011 E.02324
G1 X106.824 Y119.003 E.38188
G1 X107.544 Y119.003 E.02214
M204 S10000
G1 X107.283 Y119.788 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X106.651 Y120.419 E.02745
G1 X106.118 Y120.419
G1 X107.327 Y119.21 E.05255
G1 X106.794 Y119.21
G1 X105.585 Y120.419 E.05255
G1 X105.051 Y120.419
G1 X106.261 Y119.21 E.05255
G1 X105.727 Y119.21
G1 X104.518 Y120.419 E.05255
G1 X103.985 Y120.419
G1 X105.194 Y119.21 E.05255
G1 X104.661 Y119.21
G1 X103.451 Y120.419 E.05255
G1 X102.918 Y120.419
G1 X104.128 Y119.21 E.05255
G1 X103.594 Y119.21
G1 X102.385 Y120.419 E.05255
G1 X101.852 Y120.419
G1 X103.061 Y119.21 E.05255
G1 X102.528 Y119.21
G1 X101.318 Y120.419 E.05255
G1 X100.785 Y120.419
G1 X101.995 Y119.21 E.05255
G1 X101.461 Y119.21
G1 X100.252 Y120.419 E.05255
G1 X99.719 Y120.419
G1 X100.928 Y119.21 E.05255
G1 X100.395 Y119.21
G1 X99.185 Y120.419 E.05255
G1 X98.652 Y120.419
G1 X99.862 Y119.21 E.05255
G1 X99.328 Y119.21
G1 X98.119 Y120.419 E.05255
G1 X97.586 Y120.419
G1 X98.795 Y119.21 E.05255
G1 X98.262 Y119.21
G1 X97.052 Y120.419 E.05255
G1 X96.519 Y120.419
G1 X97.728 Y119.21 E.05255
G1 X97.195 Y119.21
G1 X95.986 Y120.419 E.05255
G1 X95.453 Y120.419
G1 X96.662 Y119.21 E.05255
G1 X96.129 Y119.21
G1 X94.919 Y120.419 E.05255
G1 X94.717 Y120.088
G1 X95.595 Y119.21 E.03816
G1 X95.062 Y119.21
G1 X94.71 Y119.562 E.0153
M204 S10000
G1 X94.785 Y119.754 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.101688
G1 F15000
G1 X94.692 Y119.544 E.0011
G1 X94.783 Y119.635 F30000
; LINE_WIDTH: 0.121454
G1 F15000
G1 X94.699 Y119.84 E.00142
; WIPE_START
G1 X94.783 Y119.635 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X95.314 Y126.619 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.464
G1 F14961.528
G1 X106.626 Y126.619 E.38815
G1 X106.937 Y127.021 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X95.233 Y127.021 E.36417
G1 X95.233 Y127.403 E.01188
G1 X106.767 Y127.403 E.3589
G1 X106.767 Y127.784 E.01188
G1 X95.233 Y127.784 E.35891
G1 X95.232 Y128.166 E.01188
G1 X106.768 Y128.166 E.35892
G1 X106.768 Y128.548 E.01188
G1 X95.063 Y128.548 E.36421
; WIPE_START
G1 X97.063 Y128.548 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.579 J1.071 P1  F30000
G1 X105.189 Y124.155 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X106.751 Y124.155 E.05183
G1 X106.751 Y124.221 E.00219
G1 X104.767 Y126.205 E.09309
G1 X105.178 Y126.205 E.01363
G1 X103.127 Y124.155 E.09618
G1 X99.141 Y124.155 E.13223
G1 X97.091 Y126.205 E.09618
G1 X97.502 Y126.205 E.01363
G1 X95.451 Y124.155 E.09618
G1 X95.249 Y124.155 E.00671
G1 X95.249 Y125.581 E.04731
G1 X106.707 Y122.398 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.707 Y123.18 E.02403
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.707 Y123.763 E.01791
G1 X95.293 Y123.763 E.35071
G1 X95.293 Y123.18 E.01791
; Slow Down End
G1 F12000
G1 X95.294 Y121.034 E.06595
G1 X106.706 Y121.034 E.35065
G1 X106.707 Y122.338 E.04007
G1 X106.329 Y122.398 F30000
G1 F12000
G1 X106.33 Y123.18 E.02403
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.33 Y123.386 E.00632
G1 X95.67 Y123.386 E.32753
G1 X95.67 Y123.18 E.00632
; Slow Down End
G1 F12000
G1 X95.671 Y121.411 E.05436
G1 X106.329 Y121.411 E.32749
G1 X106.329 Y122.338 E.02849
G1 X105.952 Y122.398 F30000
G1 F12000
G1 X105.952 Y121.788 E.01875
G1 X96.048 Y121.788 E.30432
G1 X96.047 Y123.009 E.03751
G1 X105.953 Y123.009 E.30435
G1 X105.952 Y122.458 E.01692
M73 P68 R9
G1 X105.553 Y122.398 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X105.553 Y122.188 E.00725
G1 X96.447 Y122.188 E.31304
G1 X96.447 Y122.609 E.0145
G1 X105.553 Y122.609 E.31305
G1 X105.553 Y122.458 E.00519
; WIPE_START
G1 X105.553 Y122.609 E-.05739
G1 X103.704 Y122.609 E-.70261
; WIPE_END
G1 E-.04 F1800
G1 X96.14 Y121.59 Z4 F30000
G1 X89.098 Y120.642 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.098 Y126.853 E.20604
G1 X89.098 Y127.253 E.01327
G1 F14331.075
G1 X89.098 Y127.653 E.01327
G1 F6685.538
G1 X89.098 Y128.053 E.01327
G1 F1920
G1 X89.098 Y128.436 E.01269
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X89.101 Y128.884 I9.1 J.161 E.01486
G1 X73.602 Y128.884 E.51413
G1 X73.602 Y128.436 E.01486
; FEATURE: Inner wall
G1 F1920
M204 S10000
G1 X73.602 Y128.053 E.01269
G1 F6685.538
G1 X73.602 Y127.653 E.01327
G1 F14331.075
G1 X73.602 Y127.253 E.01327
G1 F15476.087
G1 X73.602 Y126.853 E.01327
G1 X73.602 Y120.642 E.20604
G1 X89.038 Y120.642 E.51204
; WIPE_START
G1 X89.057 Y122.642 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.604 Y119.003 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G2 X89.49 Y119.748 I2.428 J.754 E.02325
G1 X89.49 Y127.267 E.23104
G1 X89.49 Y127.667 E.01229
G1 F6685.538
G1 X89.49 Y128.067 E.01229
G1 F1920
G1 X89.49 Y128.436 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G2 X89.546 Y129.276 I3.511 J.186 E.02799
G1 X73.21 Y129.276 E.54191
G1 X73.21 Y128.436 E.02786
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1920
G1 X73.21 Y128.067 E.01134
G1 F6685.538
G1 X73.21 Y127.667 E.01229
G1 F12000
G1 X73.21 Y127.267 E.01229
G1 X73.21 Y119.003 E.25393
G1 X89.462 Y119.003 E.49939
G1 X89.544 Y119.003 E.00252
M204 S10000
G1 X89.285 Y119.655 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X88.52 Y120.419 E.03322
G1 X87.987 Y120.419
G1 X89.196 Y119.21 E.05255
G1 X88.663 Y119.21
G1 X87.454 Y120.419 E.05255
G1 X86.921 Y120.419
G1 X88.13 Y119.21 E.05255
G1 X87.597 Y119.21
G1 X86.387 Y120.419 E.05255
G1 X85.854 Y120.419
G1 X87.063 Y119.21 E.05255
G1 X86.53 Y119.21
G1 X85.321 Y120.419 E.05255
G1 X84.787 Y120.419
G1 X85.997 Y119.21 E.05255
G1 X85.464 Y119.21
G1 X84.254 Y120.419 E.05255
G1 X83.721 Y120.419
G1 X84.93 Y119.21 E.05255
G1 X84.397 Y119.21
G1 X83.188 Y120.419 E.05255
G1 X82.654 Y120.419
G1 X83.864 Y119.21 E.05255
G1 X83.331 Y119.21
G1 X82.121 Y120.419 E.05255
G1 X81.588 Y120.419
G1 X82.797 Y119.21 E.05255
G1 X82.264 Y119.21
G1 X81.055 Y120.419 E.05255
G1 X80.521 Y120.419
G1 X81.731 Y119.21 E.05255
G1 X81.197 Y119.21
G1 X79.988 Y120.419 E.05255
G1 X79.455 Y120.419
G1 X80.664 Y119.21 E.05255
G1 X80.131 Y119.21
G1 X78.922 Y120.419 E.05255
G1 X78.388 Y120.419
G1 X79.598 Y119.21 E.05255
G1 X79.064 Y119.21
G1 X77.855 Y120.419 E.05255
G1 X77.322 Y120.419
G1 X78.531 Y119.21 E.05255
G1 X77.998 Y119.21
G1 X76.789 Y120.419 E.05255
G1 X76.255 Y120.419
G1 X77.465 Y119.21 E.05255
G1 X76.931 Y119.21
G1 X75.722 Y120.419 E.05255
G1 X75.189 Y120.419
G1 X76.398 Y119.21 E.05255
G1 X75.865 Y119.21
G1 X74.656 Y120.419 E.05255
G1 X74.122 Y120.419
G1 X75.332 Y119.21 E.05255
G1 X74.798 Y119.21
G1 X73.589 Y120.419 E.05255
G1 X73.417 Y120.058
G1 X74.265 Y119.21 E.03684
; WIPE_START
M204 S10000
G1 X73.417 Y120.058 E-.45558
G1 X73.589 Y120.419 E-.1521
G1 X73.873 Y120.136 E-.15232
; WIPE_END
G1 E-.04 F1800
G1 X73.994 Y121.034 Z4 F30000
G1 Z3.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y121.034 E.45204
G1 X88.707 Y123.18 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.707 Y123.763 E.01791
G1 X73.994 Y123.763 E.45208
G1 X73.994 Y123.18 E.01791
; Slow Down End
G1 F12000
G1 X73.994 Y121.094 E.0641
G1 X74.371 Y121.411 F30000
G1 F12000
G1 X88.329 Y121.411 E.42888
G1 X88.33 Y123.18 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.33 Y123.386 E.00632
G1 X74.371 Y123.386 E.4289
G1 X74.371 Y123.18 E.00632
; Slow Down End
G1 F12000
G1 X74.371 Y121.471 E.05252
G1 X74.748 Y121.788 F30000
G1 F12000
G1 X74.748 Y123.009 E.03751
G1 X87.953 Y123.009 E.40572
G1 X87.952 Y121.788 E.03751
G1 X74.808 Y121.788 E.40387
G1 X75.148 Y122.188 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X75.148 Y122.609 E.0145
G1 X87.553 Y122.609 E.42647
G1 X87.553 Y122.188 E.0145
G1 X75.208 Y122.188 E.4244
G1 X74.016 Y126.619 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.464
G1 F14961.528
G1 X88.626 Y126.619 E.50131
G1 X88.937 Y127.021 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42472
G1 F3000
G1 X73.935 Y127.021 E.46672
G1 X73.935 Y127.403 E.01188
G1 X88.767 Y127.403 E.46145
G1 X88.767 Y127.784 E.01188
G1 X73.935 Y127.784 E.46145
G1 X73.935 Y128.166 E.01188
G1 X88.768 Y128.166 E.46146
G1 X88.768 Y128.548 E.01188
G1 X73.766 Y128.548 E.46674
; WIPE_START
G1 X75.766 Y128.548 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4 I.225 J1.196 P1  F30000
G1 X88.198 Y126.205 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.752 Y126.205 E.01838
G1 X88.751 Y125.131 E.03563
G1 X87.775 Y124.155 E.04579
G1 X83.789 Y124.155 E.13223
G1 X81.739 Y126.205 E.09618
G1 X82.15 Y126.205 E.01363
G1 X80.099 Y124.155 E.09618
G1 X76.113 Y124.155 E.13223
G1 X74.063 Y126.205 E.09618
G1 X74.474 Y126.205 E.01363
G1 X73.95 Y125.682 E.02455
G1 X73.95 Y124.155 E.05065
G1 X74.052 Y124.155 E.00336
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X73.95 Y124.155 E-.03854
G1 X73.95 Y125.682 E-.58022
G1 X74.213 Y125.945 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 19/33
; update layer progress
M73 L19
M991 S0 P18 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4 I-.125 J1.21 P1  F30000
G1 X182.398 Y137.148 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X73.602 Y137.148 E3.60896
G1 X73.602 Y134.119 E.10046
G1 X73.602 Y134.085 E.00116
G1 X182.398 Y134.085 E3.60896
G1 X182.398 Y134.119 E.00116
G1 X182.398 Y137.088 E.09847
M204 S250
G1 X182.79 Y137.54 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.21 Y137.54 E3.36709
G1 X73.21 Y134.906 E.08094
G1 X73.21 Y134.506 E.01229
G1 F6459.938
G1 X73.21 Y134.106 E.01229
G1 F1800
G1 X73.21 Y133.737 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X73.21 Y133.692 E.00148
G1 X182.79 Y133.692 E3.63497
G1 X182.79 Y133.737 E.00148
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y134.106 E.01134
G1 F6459.938
G1 X182.79 Y134.506 E.01229
G1 F12000
G1 X182.79 Y134.906 E.01229
G1 X182.79 Y137.48 E.07909
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X180.79 Y137.481 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.032 Y136.782 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X74.028 Y136.782 E2.9923
; Slow Down End
G1 X74.038 Y134.52 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.507705
G1 F13554.655
G1 X74.038 Y134.985 E.0176
G1 X181.962 Y134.985 E4.08752
G1 X181.962 Y134.52 E.0176
G1 X74.098 Y134.52 E4.08525
G1 X74.385 Y135.421 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X76.014 Y135.421 E.05401
G1 X77.007 Y136.415 E.04663
G1 X79.205 Y136.415 E.0729
G1 X80.199 Y135.421 E.04663
G1 X83.689 Y135.421 E.11578
G1 X84.683 Y136.415 E.04663
G1 X86.881 Y136.415 E.0729
G1 X87.875 Y135.421 E.04663
G1 X91.365 Y135.421 E.11578
G1 X92.359 Y136.415 E.04663
G1 X94.557 Y136.415 E.0729
G1 X95.551 Y135.421 E.04663
G1 X99.041 Y135.421 E.11578
G1 X100.035 Y136.415 E.04663
G1 X102.233 Y136.415 E.0729
G1 X103.227 Y135.421 E.04663
G1 X106.717 Y135.421 E.11578
G1 X107.711 Y136.415 E.04663
G1 X109.909 Y136.415 E.0729
G1 X110.903 Y135.421 E.04663
G1 X114.393 Y135.421 E.11578
G1 X115.387 Y136.415 E.04663
G1 X117.585 Y136.415 E.0729
G1 X118.579 Y135.421 E.04663
G1 X122.069 Y135.421 E.11578
G1 X123.063 Y136.415 E.04663
G1 X125.261 Y136.415 E.0729
G1 X126.255 Y135.421 E.04663
G1 X129.745 Y135.421 E.11578
G1 X130.739 Y136.415 E.04663
G1 X132.937 Y136.415 E.0729
G1 X133.931 Y135.421 E.04663
G1 X137.421 Y135.421 E.11578
G1 X138.415 Y136.415 E.04663
G1 X140.613 Y136.415 E.0729
G1 X141.607 Y135.421 E.04663
G1 X145.097 Y135.421 E.11578
G1 X146.091 Y136.415 E.04663
G1 X148.289 Y136.415 E.0729
G1 X149.283 Y135.421 E.04663
G1 X152.773 Y135.421 E.11578
G1 X153.767 Y136.415 E.04663
G1 X155.965 Y136.415 E.0729
G1 X156.959 Y135.421 E.04663
G1 X160.449 Y135.421 E.11578
G1 X161.443 Y136.415 E.04663
G1 X163.641 Y136.415 E.0729
G1 X164.635 Y135.421 E.04663
G1 X168.125 Y135.421 E.11578
G1 X169.119 Y136.415 E.04663
G1 X171.317 Y136.415 E.0729
G1 X172.311 Y135.421 E.04663
G1 X175.801 Y135.421 E.11578
G1 X176.795 Y136.415 E.04663
G1 X178.993 Y136.415 E.0729
G1 X179.986 Y135.421 E.04663
G1 X181.615 Y135.421 E.05401
; WIPE_START
G1 X179.986 Y135.421 E-.61876
G1 X179.724 Y135.684 E-.14124
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I1.196 J.224 P1  F30000
G1 X182.398 Y121.413 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X182.398 Y128.103 E.22192
G1 X182.398 Y128.503 E.01327
G1 F13999.876
G1 X182.398 Y128.903 E.01327
G1 F6459.938
G1 X182.398 Y129.303 E.01327
G1 F1800
G1 X182.398 Y129.686 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
M73 P69 R8
G1 X182.398 Y130.134 E.01486
G1 F600
G1 X166.561 Y130.134 E.52534
G2 X166.747 Y129.686 I-3.918 J-1.886 E.01609
; FEATURE: Inner wall
M204 S10000
G1 X166.781 Y129.58 E.00369
G1 F1430.247
G1 X166.818 Y129.445 E.00466
G1 F2503.265
G1 X166.846 Y129.319 E.00427
G1 F2655.558
G1 X166.848 Y129.303 E.00052
G1 F6051.43
G1 X166.889 Y129.029 E.00918
G1 F10742.09
G1 X166.902 Y128.757 E.00904
G1 F15476.087
G1 X166.902 Y128.357 E.01327
G1 X166.902 Y121.413 E.23034
G1 X182.338 Y121.413 E.51204
; WIPE_START
G1 X182.356 Y123.413 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y119.774 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y128.517 E.26864
G1 X182.79 Y128.917 E.01229
G1 F6459.938
G1 X182.79 Y129.317 E.01229
G1 F1800
G1 X182.79 Y129.686 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y130.526 E.02786
G1 F600
G1 X165.773 Y130.526 E.56448
G2 X166.329 Y129.686 I-1.882 J-1.849 E.03362
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X166.368 Y129.583 E.00337
G1 F1295.195
G1 X166.405 Y129.468 E.00372
G1 F2258.541
G1 X166.437 Y129.351 E.00374
G1 F2582.345
G1 X166.445 Y129.317 E.00107
G1 F6737.327
G1 X166.498 Y128.992 E.01013
G1 F10985.317
G1 X166.51 Y128.752 E.00736
G1 F12000
G1 X166.51 Y128.352 E.01229
G1 X166.51 Y119.774 E.26359
G1 X182.73 Y119.774 E.4984
M204 S10000
G1 X182.583 Y120.591 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.973 Y119.981 E.0265
G1 X181.44 Y119.981
G1 X182.583 Y121.124 E.04967
G1 X182.116 Y121.191
G1 X180.906 Y119.981 E.05255
G1 X180.373 Y119.981
G1 X181.582 Y121.191 E.05255
G1 X181.049 Y121.191
G1 X179.84 Y119.981 E.05255
G1 X179.307 Y119.981
G1 X180.516 Y121.191 E.05255
G1 X179.983 Y121.191
G1 X178.773 Y119.981 E.05255
G1 X178.24 Y119.981
G1 X179.449 Y121.191 E.05255
G1 X178.916 Y121.191
G1 X177.707 Y119.981 E.05255
G1 X177.174 Y119.981
G1 X178.383 Y121.191 E.05255
G1 X177.85 Y121.191
G1 X176.64 Y119.981 E.05255
G1 X176.107 Y119.981
G1 X177.316 Y121.191 E.05255
G1 X176.783 Y121.191
G1 X175.574 Y119.981 E.05255
G1 X175.041 Y119.981
G1 X176.25 Y121.191 E.05255
G1 X175.717 Y121.191
G1 X174.507 Y119.981 E.05255
G1 X173.974 Y119.981
G1 X175.183 Y121.191 E.05255
G1 X174.65 Y121.191
G1 X173.441 Y119.981 E.05255
G1 X172.908 Y119.981
G1 X174.117 Y121.191 E.05255
G1 X173.584 Y121.191
G1 X172.374 Y119.981 E.05255
G1 X171.841 Y119.981
G1 X173.05 Y121.191 E.05255
G1 X172.517 Y121.191
G1 X171.308 Y119.981 E.05255
G1 X170.774 Y119.981
G1 X171.984 Y121.191 E.05255
G1 X171.451 Y121.191
G1 X170.241 Y119.981 E.05255
G1 X169.708 Y119.981
G1 X170.917 Y121.191 E.05255
G1 X170.384 Y121.191
G1 X169.175 Y119.981 E.05255
G1 X168.641 Y119.981
G1 X169.851 Y121.191 E.05255
G1 X169.318 Y121.191
G1 X168.108 Y119.981 E.05255
G1 X167.575 Y119.981
G1 X168.784 Y121.191 E.05255
G1 X168.251 Y121.191
G1 X167.042 Y119.981 E.05255
G1 X166.717 Y120.19
G1 X167.718 Y121.191 E.04347
G1 X167.184 Y121.191
G1 X166.717 Y120.724 E.0203
; WIPE_START
M204 S10000
G1 X167.184 Y121.191 E-.25101
G1 X167.718 Y121.191 E-.20264
G1 X167.148 Y120.621 E-.30635
; WIPE_END
G1 E-.04 F1800
G1 X167.248 Y126.759 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.249 Y125.131 E.05401
G1 X167.453 Y124.927 E.00959
G1 X172.982 Y124.927 E.18341
G1 X175.033 Y126.977 E.09618
G1 X173.079 Y126.977 E.06481
G1 X175.129 Y124.927 E.09618
G1 X180.658 Y124.927 E.18341
G1 X182.05 Y126.318 E.06528
G1 X182.05 Y125.682 E.0211
G1 X180.755 Y126.977 E.06074
M73 P70 R8
G1 X179.127 Y126.977 E.05401
G1 X182.234 Y128.271 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X167.232 Y128.271 E.46679
G1 X167.232 Y128.653 E.01188
G1 X182.065 Y128.653 E.46152
G1 X182.065 Y129.034 E.01188
G1 X167.22 Y129.034 E.46191
G3 X167.163 Y129.416 I-1.991 J-.1 E.01203
G1 X182.065 Y129.416 E.46367
G1 X182.065 Y129.798 E.01188
G1 X166.879 Y129.798 E.47249
; WIPE_START
G1 X168.879 Y129.798 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I1.021 J-.662 P1  F30000
G1 X167.328 Y127.405 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.492745
G1 F14005.448
G1 X167.328 Y127.855 E.01649
G1 X181.97 Y127.855 E.53669
G1 X181.97 Y127.405 E.01649
G1 X167.388 Y127.405 E.53449
G1 X182.006 Y124.534 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y121.805 E.08386
G1 X167.294 Y121.805 E.45205
G1 X167.293 Y124.534 E.08386
G1 X181.946 Y124.534 E.45024
G1 X181.629 Y123.17 F30000
G1 F12000
G1 X181.629 Y122.182 E.03034
G1 X167.671 Y122.182 E.42888
G1 X167.67 Y124.157 E.06068
G1 X181.629 Y124.157 E.4289
G1 X181.629 Y123.23 E.0285
G1 X181.252 Y123.17 F30000
G1 F12000
G1 X181.252 Y122.56 E.01876
G1 X168.048 Y122.56 E.40571
G1 X168.047 Y123.78 E.03751
G1 X181.252 Y123.78 E.40573
G1 X181.252 Y123.23 E.01691
G1 X180.852 Y123.17 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X180.852 Y122.959 E.00725
G1 X168.447 Y122.959 E.42647
G1 X168.447 Y123.381 E.0145
G1 X180.852 Y123.381 E.42647
G1 X180.852 Y123.23 E.00519
; WIPE_START
G1 X180.852 Y123.381 E-.05736
G1 X179.003 Y123.381 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X171.531 Y124.938 Z4.2 F30000
G1 X148.747 Y129.686 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F600
G1 X148.781 Y129.58 E.0037
G1 F1428.925
G1 X148.818 Y129.445 E.00465
G1 F2500.806
G1 X148.846 Y129.319 E.00427
G1 F2653.026
G1 X148.848 Y129.303 E.00052
G1 F6047.651
G1 X148.889 Y129.029 E.00918
G1 F10737.054
G1 X148.902 Y128.757 E.00904
G1 F15476.087
G1 X148.902 Y128.357 E.01327
G1 X148.902 Y121.413 E.23034
G1 X161.098 Y121.413 E.40456
G1 X161.098 Y128.357 E.23033
G1 X161.098 Y128.757 E.01327
G1 F10602.721
G1 X161.099 Y128.82 E.0021
G2 X161.151 Y129.303 I3.044 J-.081 E.01613
G1 F2586.809
G1 X161.178 Y129.428 E.00425
G1 F1499.076
G1 X161.217 Y129.573 E.00497
G1 F600
G1 X161.253 Y129.686 E.00392
; FEATURE: Overhang wall

M204 S5000
G2 X161.438 Y130.134 I4.404 J-1.55 E.01607
G1 X148.561 Y130.134 E.42714
G2 X148.726 Y129.742 I-3.91 J-1.883 E.0141
M204 S250
G1 X147.952 Y130.324 F30000
G1 F600
M204 S5000
G2 X148.329 Y129.686 I-2.061 J-1.647 E.02467
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X148.368 Y129.583 E.00337
G1 F1296.924
G1 X148.405 Y129.468 E.00373
G1 F2258.507
G1 X148.437 Y129.351 E.00373
G1 F2582.194
G1 X148.445 Y129.317 E.00107
G1 F6737.108
G1 X148.498 Y128.992 E.01013
G1 F10985.037
G1 X148.51 Y128.752 E.00736
G1 F12000
G1 X148.51 Y128.352 E.01229
G1 X148.51 Y119.774 E.26359
G1 X157.789 Y119.774 E.28511
G1 X161.49 Y119.774 E.11373
G1 X161.49 Y128.352 E.26359
G1 X161.49 Y128.752 E.01229
G1 F10890.838
G1 X161.501 Y128.987 E.00722
G1 F6733.827
G1 X161.555 Y129.317 E.01027
G1 F2536.596
G1 X161.559 Y129.336 E.0006
G1 F2353.576
G1 X161.593 Y129.463 E.00403
G1 F1300.874
G1 X161.631 Y129.579 E.00375
G1 F600
G1 X161.671 Y129.686 E.00352
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X161.673 Y129.692 E.00022
G2 X162.227 Y130.526 I2.342 J-.955 E.03342
G1 X147.773 Y130.526 E.47946
G2 X147.914 Y130.37 I-1.882 J-1.849 E.00696
; WIPE_START
M204 S10000
G1 X148.099 Y130.126 E-.11657
G1 X148.222 Y129.917 E-.09217
G1 X148.329 Y129.686 E-.09671
G1 X148.368 Y129.583 E-.04169
G1 X148.405 Y129.468 E-.04614
G1 X148.437 Y129.351 E-.04611
G1 X148.445 Y129.317 E-.01318
G1 X148.498 Y128.992 E-.12523
G1 X148.51 Y128.752 E-.09104
G1 X148.51 Y128.512 E-.09116
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-1.17 J.336 P1  F30000
G1 X148.879 Y129.798 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X160.94 Y129.798 E.37526
G1 X160.877 Y129.585 E.0069
G3 X160.837 Y129.416 I.866 J-.297 E.00542
G1 X149.163 Y129.416 E.36323
G2 X149.22 Y129.034 I-1.937 J-.482 E.01203
G1 X160.784 Y129.034 E.35983
G3 X160.765 Y128.653 I2.628 J-.324 E.01191
G1 X149.232 Y128.653 E.35884
G1 X149.232 Y128.271 E.01188
G1 X160.934 Y128.271 E.36411
G1 X160.706 Y123.17 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.706 Y121.805 E.04193
G1 X149.294 Y121.805 E.35065
G1 X149.293 Y124.534 E.08386
G1 X160.706 Y124.534 E.35068
G1 X160.706 Y123.23 E.04008
G1 X160.329 Y123.17 F30000
G1 F12000
G1 X160.329 Y122.182 E.03034
G1 X149.671 Y122.182 E.32748
G1 X149.67 Y124.157 E.06068
G1 X160.329 Y124.157 E.32751
G1 X160.329 Y123.23 E.0285
G1 X159.952 Y123.17 F30000
G1 F12000
G1 X159.952 Y122.56 E.01876
G1 X150.048 Y122.56 E.30431
G1 X150.047 Y123.78 E.03751
G1 X159.952 Y123.78 E.30433
G1 X159.952 Y123.23 E.01691
G1 X159.552 Y123.17 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X159.552 Y122.959 E.00725
G1 X150.447 Y122.959 E.31302
G1 X150.447 Y123.381 E.0145
G1 X159.552 Y123.381 E.31303
G1 X159.552 Y123.23 E.00519
; WIPE_START
G1 X159.552 Y123.381 E-.05736
G1 X157.703 Y123.381 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X161.283 Y120.622 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X160.643 Y119.981 E.02781
G1 X160.109 Y119.981
G1 X161.283 Y121.155 E.05099
G1 X160.785 Y121.191
G1 X159.576 Y119.981 E.05255
G1 X159.043 Y119.981
G1 X160.252 Y121.191 E.05255
G1 X159.719 Y121.191
G1 X158.51 Y119.981 E.05255
G1 X157.976 Y119.981
G1 X159.186 Y121.191 E.05255
G1 X158.652 Y121.191
G1 X157.443 Y119.981 E.05255
G1 X156.91 Y119.981
G1 X158.119 Y121.191 E.05255
G1 X157.586 Y121.191
G1 X156.377 Y119.981 E.05255
G1 X155.843 Y119.981
G1 X157.053 Y121.191 E.05255
G1 X156.519 Y121.191
G1 X155.31 Y119.981 E.05255
G1 X154.777 Y119.981
G1 X155.986 Y121.191 E.05255
G1 X155.453 Y121.191
G1 X154.243 Y119.981 E.05255
G1 X153.71 Y119.981
G1 X154.92 Y121.191 E.05255
G1 X154.386 Y121.191
G1 X153.177 Y119.981 E.05255
G1 X152.644 Y119.981
G1 X153.853 Y121.191 E.05255
G1 X153.32 Y121.191
G1 X152.11 Y119.981 E.05255
G1 X151.577 Y119.981
G1 X152.787 Y121.191 E.05255
G1 X152.253 Y121.191
G1 X151.044 Y119.981 E.05255
G1 X150.511 Y119.981
G1 X151.72 Y121.191 E.05255
G1 X151.187 Y121.191
G1 X149.977 Y119.981 E.05255
G1 X149.444 Y119.981
G1 X150.653 Y121.191 E.05255
G1 X150.12 Y121.191
G1 X148.911 Y119.981 E.05255
G1 X148.717 Y120.321
G1 X149.587 Y121.191 E.03779
; WIPE_START
M204 S10000
G1 X148.717 Y120.321 E-.46732
G1 X148.911 Y119.981 E-.14858
G1 X149.179 Y120.25 E-.14411
; WIPE_END
G1 E-.04 F1800
G1 X149.248 Y125.849 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X149.249 Y124.927 E.03061
G1 X149.954 Y124.927 E.02341
G1 X152.005 Y126.977 E.09618
G1 X150.051 Y126.977 E.06481
G1 X152.101 Y124.927 E.09618
G1 X157.63 Y124.927 E.18341
G1 X159.681 Y126.977 E.09618
G1 X157.727 Y126.977 E.06481
G1 X159.777 Y124.927 E.09618
G1 X160.75 Y124.927 E.03226
G1 X160.75 Y125.582 E.02176
G1 X149.328 Y127.405 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.492745
G1 F14005.448
G1 X149.328 Y127.855 E.01649
G1 X160.67 Y127.855 E.41573
G1 X160.67 Y127.405 E.01649
G1 X149.388 Y127.405 E.41353
; WIPE_START
G1 X151.388 Y127.405 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-.134 J-1.21 P1  F30000
G1 X130.747 Y129.686 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F600
G1 X130.781 Y129.58 E.00369
G1 F1431.38
G1 X130.818 Y129.444 E.00466
G1 F2503.476
G1 X130.846 Y129.319 E.00427
G1 F2656.065
G1 X130.848 Y129.303 E.00053
G1 F6052.217
G1 X130.889 Y129.029 E.00918
G1 F10743.138
G1 X130.902 Y128.757 E.00904
G1 F15476.087
G1 X130.902 Y128.357 E.01327
G1 X130.902 Y121.413 E.23034
G1 X143.098 Y121.413 E.40456
G1 X143.098 Y128.357 E.23033
G1 X143.098 Y128.757 E.01327
G1 F10602.67
G1 X143.099 Y128.82 E.0021
G2 X143.151 Y129.303 I3.044 J-.081 E.01613
G1 F2586.784
G1 X143.178 Y129.428 E.00425
G1 F1499.057
G1 X143.217 Y129.573 E.00497
G1 F600
G1 X143.253 Y129.686 E.00392
; FEATURE: Overhang wall

M204 S5000
G2 X143.438 Y130.134 I4.41 J-1.553 E.01607
G1 X130.561 Y130.134 E.42714
G2 X130.726 Y129.742 I-3.911 J-1.883 E.0141
M204 S250
G1 X129.952 Y130.324 F30000
G1 F600
M204 S5000
G2 X130.329 Y129.686 I-2.061 J-1.647 E.02467
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X130.368 Y129.583 E.00337
G1 F1295.195
G1 X130.405 Y129.468 E.00372
G1 F2258.541
G1 X130.437 Y129.351 E.00374
G1 F2582.345
G1 X130.445 Y129.317 E.00107
G1 F6737.327
G1 X130.498 Y128.992 E.01013
G1 F10985.317
G1 X130.51 Y128.752 E.00736
G1 F12000
G1 X130.51 Y128.352 E.01229
G1 X130.51 Y119.774 E.26359
G1 X139.789 Y119.774 E.28511
G1 X143.49 Y119.774 E.11373
G1 X143.49 Y128.352 E.26359
G1 X143.49 Y128.752 E.01229
G1 F10890.838
G1 X143.501 Y128.987 E.00722
G1 F6733.827
G1 X143.555 Y129.317 E.01027
G1 F2536.596
G1 X143.559 Y129.336 E.0006
G1 F2353.576
G1 X143.593 Y129.463 E.00403
G1 F1300.874
G1 X143.631 Y129.579 E.00375
G1 F600
G1 X143.671 Y129.686 E.00352
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X143.673 Y129.692 E.00022
G2 X144.227 Y130.526 I2.343 J-.955 E.03341
G1 X129.773 Y130.526 E.47946
G2 X129.914 Y130.37 I-1.882 J-1.849 E.00696
; WIPE_START
M204 S10000
G1 X130.099 Y130.126 E-.11657
G1 X130.222 Y129.917 E-.09217
G1 X130.329 Y129.686 E-.09671
G1 X130.368 Y129.583 E-.04169
G1 X130.405 Y129.468 E-.04604
G1 X130.437 Y129.351 E-.04621
G1 X130.445 Y129.317 E-.01319
G1 X130.498 Y128.992 E-.12523
G1 X130.51 Y128.752 E-.09104
G1 X130.51 Y128.512 E-.09116
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-1.17 J.336 P1  F30000
G1 X130.879 Y129.798 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X142.94 Y129.798 E.37526
G1 X142.863 Y129.538 E.00843
G3 X142.837 Y129.416 I.625 J-.2 E.00389
G1 X131.163 Y129.416 E.36323
G2 X131.22 Y129.034 I-1.936 J-.482 E.01203
G1 X142.784 Y129.034 E.35983
G3 X142.765 Y128.653 I2.628 J-.324 E.01191
G1 X131.232 Y128.653 E.35884
G1 X131.232 Y128.271 E.01188
G1 X142.934 Y128.271 E.36411
G1 X142.706 Y123.17 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.706 Y121.805 E.04193
G1 X131.294 Y121.805 E.35065
G1 X131.293 Y124.534 E.08386
G1 X142.706 Y124.534 E.35068
G1 X142.706 Y123.23 E.04008
G1 X142.329 Y123.17 F30000
G1 F12000
G1 X142.329 Y122.182 E.03034
G1 X131.671 Y122.182 E.32748
G1 X131.67 Y124.157 E.06068
G1 X142.329 Y124.157 E.32751
G1 X142.329 Y123.23 E.0285
G1 X141.952 Y123.17 F30000
G1 F12000
G1 X141.952 Y122.56 E.01876
G1 X132.048 Y122.56 E.30431
G1 X132.047 Y123.78 E.03751
G1 X141.952 Y123.78 E.30433
G1 X141.952 Y123.23 E.01691
G1 X141.552 Y123.17 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X141.552 Y122.959 E.00725
G1 X132.447 Y122.959 E.31302
G1 X132.447 Y123.381 E.0145
G1 X141.552 Y123.381 E.31303
G1 X141.552 Y123.23 E.00519
; WIPE_START
G1 X141.552 Y123.381 E-.05736
G1 X139.703 Y123.381 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X142.512 Y119.981 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X143.283 Y120.752 E.03349
G1 X143.188 Y121.191
G1 X141.979 Y119.981 E.05255
M73 P71 R8
G1 X141.445 Y119.981
G1 X142.655 Y121.191 E.05255
G1 X142.121 Y121.191
G1 X140.912 Y119.981 E.05255
G1 X140.379 Y119.981
G1 X141.588 Y121.191 E.05255
G1 X141.055 Y121.191
G1 X139.846 Y119.981 E.05255
G1 X139.312 Y119.981
G1 X140.522 Y121.191 E.05255
G1 X139.988 Y121.191
G1 X138.779 Y119.981 E.05255
G1 X138.246 Y119.981
G1 X139.455 Y121.191 E.05255
G1 X138.922 Y121.191
G1 X137.713 Y119.981 E.05255
G1 X137.179 Y119.981
G1 X138.389 Y121.191 E.05255
G1 X137.855 Y121.191
G1 X136.646 Y119.981 E.05255
G1 X136.113 Y119.981
G1 X137.322 Y121.191 E.05255
G1 X136.789 Y121.191
G1 X135.579 Y119.981 E.05255
G1 X135.046 Y119.981
G1 X136.256 Y121.191 E.05255
G1 X135.722 Y121.191
G1 X134.513 Y119.981 E.05255
G1 X133.98 Y119.981
G1 X135.189 Y121.191 E.05255
G1 X134.656 Y121.191
G1 X133.446 Y119.981 E.05255
G1 X132.913 Y119.981
G1 X134.123 Y121.191 E.05255
G1 X133.589 Y121.191
G1 X132.38 Y119.981 E.05255
G1 X131.847 Y119.981
G1 X133.056 Y121.191 E.05255
G1 X132.523 Y121.191
G1 X131.313 Y119.981 E.05255
G1 X130.78 Y119.981
G1 X131.989 Y121.191 E.05255
G1 X131.456 Y121.191
G1 X130.717 Y120.452 E.03211
; WIPE_START
M204 S10000
G1 X131.456 Y121.191 E-.39705
G1 X131.989 Y121.191 E-.20264
G1 X131.691 Y120.893 E-.16031
; WIPE_END
G1 E-.04 F1800
G1 X132.974 Y124.927 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X134.602 Y124.927 E.05401
G1 X136.653 Y126.977 E.09618
G1 X134.699 Y126.977 E.06481
G1 X136.749 Y124.927 E.09618
G1 X142.278 Y124.927 E.18341
G1 X142.75 Y125.398 E.02211
G1 X142.75 Y126.602 E.03995
G1 X142.375 Y126.977 E.01757
G1 X140.747 Y126.977 E.05401
G1 X131.328 Y127.405 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.492745
G1 F14005.448
G1 X131.328 Y127.855 E.01649
G1 X142.67 Y127.855 E.41573
G1 X142.67 Y127.405 E.01649
G1 X131.388 Y127.405 E.41353
; WIPE_START
G1 X133.388 Y127.405 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-.329 J-1.172 P1  F30000
G1 X125.253 Y129.686 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
M204 S5000
G2 X125.438 Y130.134 I4.404 J-1.55 E.01607
G1 X112.561 Y130.134 E.42714
G2 X112.747 Y129.686 I-3.912 J-1.884 E.01609
; FEATURE: Inner wall
M204 S10000
G1 X112.781 Y129.58 E.00368
G1 F1431.833
G1 X112.818 Y129.444 E.00467
G1 F2505.343
G1 X112.846 Y129.319 E.00427
G1 F2656.622
G1 X112.848 Y129.303 E.00052
G1 F6055.519
G1 X112.889 Y129.029 E.00919
G1 F10744.571
G1 X112.902 Y128.757 E.00903
G1 F15476.087
G1 X112.902 Y128.357 E.01327
G1 X112.902 Y121.413 E.23034
G1 X125.098 Y121.413 E.40456
G1 X125.098 Y128.357 E.23033
G1 X125.098 Y128.757 E.01327
G1 F10618.653
G2 X125.151 Y129.303 I3.092 J-.025 E.01824
G1 F2590.576
G1 X125.178 Y129.428 E.00424
G1 F1503.603
G1 X125.217 Y129.574 E.00499
G1 F600
G1 X125.235 Y129.629 E.00192
; WIPE_START
G1 X125.438 Y130.134 E-.2068
G1 X123.982 Y130.134 E-.5532
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-.108 J1.212 P1  F30000
G1 X126.041 Y130.318 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X126.227 Y130.526 I1.975 J-1.58 E.00926
G1 X111.773 Y130.526 E.47946
G2 X112.329 Y129.686 I-1.882 J-1.849 E.03362
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X112.368 Y129.583 E.00337
G1 F1295.325
G1 X112.405 Y129.468 E.00372
G1 F2258.626
G1 X112.437 Y129.351 E.00374
G1 F2582.456
G1 X112.445 Y129.317 E.00107
G1 F6737.942
G1 X112.498 Y128.992 E.01013
G1 F10985.695
G1 X112.51 Y128.752 E.00736
G1 F12000
G1 X112.51 Y128.352 E.01229
G1 X112.51 Y119.774 E.26359
G1 X121.789 Y119.774 E.28511
G1 X125.49 Y119.774 E.11373
G1 X125.49 Y128.352 E.26359
G1 X125.49 Y128.752 E.01229
G1 F10891.027
G1 X125.501 Y128.987 E.00722
G1 F6732.871
G1 X125.555 Y129.317 E.01026
G1 F2536.669
G1 X125.559 Y129.336 E.0006
G1 F2353.667
G1 X125.593 Y129.463 E.00403
G1 F1300.311
G1 X125.631 Y129.579 E.00375
G1 F600
G1 X125.671 Y129.686 E.00352
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X125.673 Y129.692 E.00023
G2 X126.004 Y130.271 I2.343 J-.955 E.02216
; WIPE_START
M204 S10000
G1 X126.227 Y130.526 E-.12882
G1 X124.566 Y130.526 E-.63118
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I1.201 J.196 P1  F30000
G1 X124.934 Y128.271 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X113.232 Y128.271 E.36411
G1 X113.232 Y128.653 E.01188
G1 X124.765 Y128.653 E.35884
G2 X124.784 Y129.034 I2.647 J.058 E.01191
G1 X113.22 Y129.034 E.35983
G3 X113.163 Y129.416 I-1.99 J-.1 E.01203
G1 X124.837 Y129.416 E.36323
G2 X124.94 Y129.798 I2.057 J-.35 E.01232
G1 X112.879 Y129.798 E.37526
; WIPE_START
G1 X114.879 Y129.798 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I1.206 J.16 P1  F30000
G1 X115.253 Y126.977 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X113.625 Y126.977 E.05401
G1 X113.248 Y126.6 E.01768
G1 X113.249 Y125.399 E.03982
G1 X113.722 Y124.927 E.02219
G1 X119.251 Y124.927 E.18341
G1 X121.301 Y126.977 E.09618
G1 X119.347 Y126.977 E.06481
G1 X121.397 Y124.927 E.09618
G1 X123.026 Y124.927 E.05401
G1 X124.706 Y123.17 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.706 Y121.805 E.04193
G1 X113.294 Y121.805 E.35065
G1 X113.293 Y124.534 E.08386
G1 X124.706 Y124.534 E.35068
G1 X124.706 Y123.23 E.04008
G1 X124.329 Y123.17 F30000
G1 F12000
G1 X124.329 Y122.182 E.03034
G1 X113.671 Y122.182 E.32748
G1 X113.67 Y124.157 E.06068
G1 X124.329 Y124.157 E.32751
G1 X124.329 Y123.23 E.0285
G1 X123.952 Y123.17 F30000
G1 F12000
G1 X123.952 Y122.56 E.01876
G1 X114.048 Y122.56 E.30431
G1 X114.047 Y123.78 E.03751
G1 X123.952 Y123.78 E.30433
G1 X123.952 Y123.23 E.01691
G1 X123.552 Y123.17 F30000
; LINE_WIDTH: 0.4648
G1 F12000
G1 X123.552 Y122.959 E.00725
G1 X114.447 Y122.959 E.31302
G1 X114.447 Y123.381 E.0145
G1 X123.552 Y123.381 E.31302
G1 X123.552 Y123.23 E.00519
; WIPE_START
G1 X123.552 Y123.381 E-.05736
G1 X121.703 Y123.381 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X125.283 Y120.35 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X124.914 Y119.981 E.016
G1 X124.381 Y119.981
G1 X125.283 Y120.883 E.03918
G1 X125.057 Y121.191
G1 X123.848 Y119.981 E.05255
G1 X123.315 Y119.981
G1 X124.524 Y121.191 E.05255
G1 X123.991 Y121.191
G1 X122.781 Y119.981 E.05255
G1 X122.248 Y119.981
G1 X123.457 Y121.191 E.05255
G1 X122.924 Y121.191
G1 X121.715 Y119.981 E.05255
G1 X121.182 Y119.981
G1 X122.391 Y121.191 E.05255
G1 X121.858 Y121.191
G1 X120.648 Y119.981 E.05255
G1 X120.115 Y119.981
G1 X121.324 Y121.191 E.05255
G1 X120.791 Y121.191
G1 X119.582 Y119.981 E.05255
G1 X119.049 Y119.981
G1 X120.258 Y121.191 E.05255
G1 X119.725 Y121.191
G1 X118.515 Y119.981 E.05255
G1 X117.982 Y119.981
G1 X119.191 Y121.191 E.05255
G1 X118.658 Y121.191
G1 X117.449 Y119.981 E.05255
G1 X116.915 Y119.981
G1 X118.125 Y121.191 E.05255
G1 X117.592 Y121.191
G1 X116.382 Y119.981 E.05255
G1 X115.849 Y119.981
G1 X117.058 Y121.191 E.05255
G1 X116.525 Y121.191
G1 X115.316 Y119.981 E.05255
G1 X114.782 Y119.981
G1 X115.992 Y121.191 E.05255
G1 X115.459 Y121.191
G1 X114.249 Y119.981 E.05255
G1 X113.716 Y119.981
G1 X114.925 Y121.191 E.05255
G1 X114.392 Y121.191
G1 X113.183 Y119.981 E.05255
G1 X112.717 Y120.049
G1 X113.859 Y121.191 E.0496
G1 X113.325 Y121.191
G1 X112.717 Y120.583 E.02642
; WIPE_START
M204 S10000
G1 X113.325 Y121.191 E-.32679
G1 X113.859 Y121.191 E-.20264
G1 X113.43 Y120.762 E-.23058
; WIPE_END
G1 E-.04 F1800
G1 X120 Y124.645 Z4.2 F30000
G1 X124.669 Y127.405 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.49275
G1 F14005.291
G1 X113.328 Y127.405 E.41573
G1 X113.328 Y127.855 E.01649
G1 X124.669 Y127.855 E.41574
G1 X124.669 Y127.465 E.01429
; WIPE_START
G1 X124.669 Y127.855 E-.14814
G1 X123.059 Y127.855 E-.61186
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-.14 J-1.209 P1  F30000
G1 X107.253 Y129.686 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
M204 S5000
G2 X107.438 Y130.134 I4.404 J-1.55 E.01607
G1 X94.561 Y130.134 E.42714
G2 X94.747 Y129.686 I-3.909 J-1.882 E.01609
; FEATURE: Inner wall
M204 S10000
G1 X94.781 Y129.58 E.00369
G1 F1430.404
G1 X94.818 Y129.445 E.00466
G1 F2504.42
G1 X94.846 Y129.319 E.00427
G1 F2655.575
G1 X94.848 Y129.303 E.00052
G1 F6053.94
G1 X94.889 Y129.029 E.00919
G1 F10742.074
G1 X94.902 Y128.757 E.00903
G1 F15476.087
G1 X94.902 Y128.357 E.01327
G1 X94.902 Y121.413 E.23034
G1 X107.098 Y121.413 E.40456
G1 X107.098 Y128.357 E.23033
G1 X107.098 Y128.757 E.01327
G1 F10618.653
G2 X107.151 Y129.303 I3.092 J-.025 E.01824
G1 F2590.576
G1 X107.178 Y129.428 E.00424
G1 F1503.603
G1 X107.217 Y129.574 E.00499
G1 F600
G1 X107.235 Y129.629 E.00192
; WIPE_START
G1 X107.438 Y130.134 E-.2068
G1 X105.982 Y130.134 E-.5532
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I-.108 J1.212 P1  F30000
G1 X108.041 Y130.318 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X108.227 Y130.526 I1.975 J-1.58 E.00927
G1 X93.773 Y130.526 E.47946
G2 X94.329 Y129.686 I-1.881 J-1.848 E.03362
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 X94.368 Y129.583 E.00337
G1 F1295.195
G1 X94.405 Y129.468 E.00372
G1 F2258.541
G1 X94.437 Y129.351 E.00374
G1 F2582.366
G1 X94.445 Y129.317 E.00107
G1 F6737.489
G1 X94.498 Y128.992 E.01013
G1 F10985.315
G1 X94.51 Y128.752 E.00736
G1 F12000
G1 X94.51 Y128.352 E.01229
G1 X94.51 Y119.774 E.26359
G1 X103.789 Y119.774 E.28511
G1 X107.49 Y119.774 E.11373
G1 X107.49 Y128.352 E.26359
G1 X107.49 Y128.752 E.01229
G1 F10891.027
G1 X107.501 Y128.987 E.00722
G1 F6732.871
G1 X107.555 Y129.317 E.01026
G1 F2536.669
G1 X107.559 Y129.336 E.0006
G1 F2353.667
G1 X107.593 Y129.463 E.00403
G1 F1300.311
G1 X107.631 Y129.579 E.00375
G1 F600
G1 X107.671 Y129.686 E.00352
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X107.673 Y129.692 E.00023
G2 X108.004 Y130.27 I2.343 J-.955 E.02216
; WIPE_START
M204 S10000
G1 X108.227 Y130.526 E-.12884
G1 X106.566 Y130.526 E-.63116
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I1.201 J.196 P1  F30000
G1 X106.934 Y128.271 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X95.232 Y128.271 E.36411
G1 X95.232 Y128.653 E.01188
G1 X106.765 Y128.653 E.35884
G2 X106.784 Y129.034 I2.647 J.058 E.01191
G1 X95.22 Y129.034 E.35983
G3 X95.163 Y129.416 I-1.987 J-.1 E.01203
G1 X106.837 Y129.416 E.36323
G2 X106.94 Y129.798 I2.057 J-.35 E.01232
G1 X94.879 Y129.798 E.37526
; WIPE_START
G1 X96.879 Y129.798 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I1.135 J-.439 P1  F30000
G1 X95.249 Y125.581 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X95.249 Y124.927 E.02171
G1 X96.223 Y124.927 E.03231
G1 X98.273 Y126.977 E.09618
G1 X96.319 Y126.977 E.06481
G1 X98.37 Y124.927 E.09618
G1 X103.899 Y124.927 E.18341
G1 X105.949 Y126.977 E.09618
G1 X103.995 Y126.977 E.06481
G1 X106.046 Y124.927 E.09618
G1 X106.75 Y124.927 E.02336
G1 X106.75 Y125.851 E.03066
G1 X106.669 Y127.405 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.492745
G1 F14005.448
G1 X95.328 Y127.405 E.41573
G1 X95.328 Y127.855 E.01649
G1 X106.669 Y127.855 E.41573
G1 X106.669 Y127.465 E.01429
G1 X106.706 Y123.17 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.706 Y121.805 E.04193
M73 P72 R8
G1 X95.294 Y121.805 E.35065
G1 X95.293 Y124.534 E.08386
G1 X106.706 Y124.534 E.35068
G1 X106.706 Y123.23 E.04008
G1 X106.329 Y123.17 F30000
G1 F12000
G1 X106.329 Y122.182 E.03034
G1 X95.671 Y122.182 E.32748
G1 X95.67 Y124.157 E.06068
G1 X106.329 Y124.157 E.32751
G1 X106.329 Y123.23 E.0285
G1 X105.952 Y123.17 F30000
G1 F12000
G1 X105.952 Y122.56 E.01876
G1 X96.048 Y122.56 E.30431
G1 X96.047 Y123.78 E.03751
G1 X105.952 Y123.78 E.30433
G1 X105.952 Y123.23 E.01691
G1 X105.552 Y123.17 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X105.552 Y122.959 E.00725
G1 X96.447 Y122.959 E.31302
G1 X96.447 Y123.381 E.0145
G1 X105.552 Y123.381 E.31303
G1 X105.552 Y123.23 E.00519
; WIPE_START
G1 X105.552 Y123.381 E-.05736
G1 X103.703 Y123.381 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X107.283 Y120.481 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.784 Y119.981 E.02169
G1 X106.25 Y119.981
G1 X107.283 Y121.014 E.04486
G1 X106.926 Y121.191
G1 X105.717 Y119.981 E.05255
G1 X105.184 Y119.982
G1 X106.393 Y121.191 E.05255
G1 X105.86 Y121.191
G1 X104.651 Y119.982 E.05255
G1 X104.117 Y119.982
G1 X105.327 Y121.191 E.05255
G1 X104.793 Y121.191
G1 X103.584 Y119.982 E.05255
G1 X103.051 Y119.982
G1 X104.26 Y121.191 E.05255
G1 X103.727 Y121.191
G1 X102.518 Y119.982 E.05255
G1 X101.984 Y119.982
G1 X103.194 Y121.191 E.05255
G1 X102.66 Y121.191
G1 X101.451 Y119.981 E.05255
G1 X100.918 Y119.981
G1 X102.127 Y121.191 E.05255
G1 X101.594 Y121.191
G1 X100.384 Y119.981 E.05255
G1 X99.851 Y119.981
G1 X101.061 Y121.191 E.05255
G1 X100.527 Y121.191
G1 X99.318 Y119.981 E.05255
G1 X98.785 Y119.981
G1 X99.994 Y121.191 E.05255
G1 X99.461 Y121.191
G1 X98.251 Y119.981 E.05255
G1 X97.718 Y119.981
G1 X98.928 Y121.191 E.05255
G1 X98.394 Y121.191
G1 X97.185 Y119.981 E.05255
G1 X96.652 Y119.981
G1 X97.861 Y121.191 E.05255
G1 X97.328 Y121.191
G1 X96.118 Y119.981 E.05255
G1 X95.585 Y119.981
G1 X96.794 Y121.191 E.05255
G1 X96.261 Y121.191
G1 X95.052 Y119.981 E.05255
G1 X94.717 Y120.18
G1 X95.728 Y121.191 E.04392
G1 X95.195 Y121.191
G1 X94.717 Y120.713 E.02074
; WIPE_START
M204 S10000
G1 X95.195 Y121.191 E-.25652
G1 X95.728 Y121.191 E-.20264
G1 X95.168 Y120.631 E-.30084
; WIPE_END
G1 E-.04 F1800
G1 X89.098 Y121.413 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X89.098 Y128.364 E.23056
G1 X89.098 Y128.764 E.01327
G1 F10502.847
G2 X89.151 Y129.303 I4.666 J-.187 E.018
G1 F2599.819
G1 X89.181 Y129.439 E.00461
G1 F1430.067
G1 X89.217 Y129.575 E.00466
G1 F600
G1 X89.253 Y129.686 E.00388
; FEATURE: Overhang wall

M204 S5000
G2 X89.437 Y130.134 I4.51 J-1.587 E.01607
G1 X73.602 Y130.134 E.52527
G1 X73.602 Y129.686 E.01486
; FEATURE: Inner wall
G1 F1920
M204 S10000
G1 X73.602 Y129.303 E.01269
G1 F6685.538
G1 X73.602 Y128.903 E.01327
G1 F14331.075
G1 X73.602 Y128.503 E.01327
G1 F15476.087
G1 X73.602 Y128.103 E.01327
G1 X73.602 Y121.413 E.22192
G1 X89.038 Y121.413 E.51204
; WIPE_START
G1 X89.055 Y123.413 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.49 Y119.774 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X89.49 Y128.355 E.26366
G1 X89.49 Y128.755 E.01229
G1 F10844.306
G1 X89.515 Y129.107 E.01086
G1 F4985.174
G1 X89.555 Y129.317 E.00656
G1 F2536.463
G1 X89.562 Y129.346 E.00091
G1 F2261.279
G1 X89.593 Y129.463 E.00373
G1 F1297.932
G1 X89.631 Y129.579 E.00374
G1 F600
G1 X89.671 Y129.685 E.00347
G1 X89.671 Y129.686 E.00004
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G2 X90.227 Y130.526 I2.341 J-.945 E.03364
G1 X73.21 Y130.526 E.56448
G1 X73.21 Y129.686 E.02786
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1920
G1 X73.21 Y129.317 E.01134
G1 F6685.538
G1 X73.21 Y128.917 E.01229
G1 F12000
G1 X73.21 Y128.517 E.01229
G1 X73.21 Y119.774 E.26864
G1 X89.426 Y119.774 E.49828
G1 X89.43 Y119.774 E.00011
M204 S10000
G1 X89.283 Y120.611 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X88.653 Y119.981 E.02737
G1 X88.12 Y119.981
G1 X89.283 Y121.145 E.05054
G1 X88.796 Y121.191
G1 X87.586 Y119.981 E.05255
G1 X87.053 Y119.981
G1 X88.262 Y121.191 E.05255
G1 X87.729 Y121.191
G1 X86.52 Y119.981 E.05255
G1 X85.987 Y119.981
G1 X87.196 Y121.191 E.05255
G1 X86.663 Y121.191
G1 X85.453 Y119.981 E.05255
G1 X84.92 Y119.981
G1 X86.129 Y121.191 E.05255
G1 X85.596 Y121.191
G1 X84.387 Y119.981 E.05255
G1 X83.854 Y119.981
G1 X85.063 Y121.191 E.05255
G1 X84.53 Y121.191
G1 X83.32 Y119.981 E.05255
G1 X82.787 Y119.981
G1 X83.996 Y121.191 E.05255
G1 X83.463 Y121.191
G1 X82.254 Y119.981 E.05255
G1 X81.72 Y119.981
G1 X82.93 Y121.191 E.05255
G1 X82.397 Y121.191
G1 X81.187 Y119.981 E.05255
G1 X80.654 Y119.981
G1 X81.863 Y121.191 E.05255
G1 X81.33 Y121.191
G1 X80.121 Y119.981 E.05255
G1 X79.587 Y119.981
G1 X80.797 Y121.191 E.05255
G1 X80.264 Y121.191
G1 X79.054 Y119.981 E.05255
G1 X78.521 Y119.981
G1 X79.73 Y121.191 E.05255
G1 X79.197 Y121.191
G1 X77.988 Y119.981 E.05255
G1 X77.454 Y119.981
G1 X78.664 Y121.191 E.05255
G1 X78.13 Y121.191
G1 X76.921 Y119.981 E.05255
G1 X76.388 Y119.981
G1 X77.597 Y121.191 E.05255
G1 X77.064 Y121.191
G1 X75.855 Y119.981 E.05255
G1 X75.321 Y119.981
G1 X76.531 Y121.191 E.05255
G1 X75.997 Y121.191
G1 X74.788 Y119.981 E.05255
G1 X74.255 Y119.981
G1 X75.464 Y121.191 E.05255
G1 X74.931 Y121.191
G1 X73.722 Y119.981 E.05255
G1 X73.417 Y120.211
G1 X74.398 Y121.191 E.0426
G1 X73.864 Y121.191
G1 X73.417 Y120.744 E.01943
; WIPE_START
M204 S10000
G1 X73.864 Y121.191 E-.24023
G1 X74.398 Y121.191 E-.20264
G1 X73.808 Y120.601 E-.31713
; WIPE_END
G1 E-.04 F1800
G1 X76.873 Y126.977 Z4.2 F30000
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X75.245 Y126.977 E.05401
G1 X73.95 Y125.682 E.06074
G1 X73.95 Y126.318 E.0211
G1 X75.342 Y124.927 E.06527
G1 X80.871 Y124.927 E.18341
G1 X82.921 Y126.977 E.09618
G1 X80.967 Y126.977 E.06481
G1 X83.018 Y124.927 E.09618
G1 X88.547 Y124.927 E.18341
G1 X88.75 Y125.129 E.00952
G1 X88.75 Y126.758 E.05401
G1 X88.669 Y127.405 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.492745
G1 F14005.448
G1 X74.031 Y127.405 E.53659
G1 X74.031 Y127.855 E.01649
G1 X88.669 Y127.855 E.53659
G1 X88.669 Y127.465 E.01429
G1 X88.934 Y128.271 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42476
G1 F3000
G1 X73.935 Y128.271 E.4667
G1 X73.935 Y128.653 E.01188
G1 X88.765 Y128.653 E.46142
G2 X88.784 Y129.034 I2.615 J.062 E.01191
G1 X73.935 Y129.034 E.46201
G1 X73.935 Y129.416 E.01188
G1 X88.837 Y129.416 E.46367
G2 X88.869 Y129.559 I.75 J-.092 E.00455
G1 X88.94 Y129.798 E.00776
G1 X73.766 Y129.798 E.47214
; WIPE_START
G1 X75.766 Y129.798 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.2 I.555 J1.083 P1  F30000
G1 X88.706 Y123.17 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y121.805 E.04193
G1 X73.994 Y121.805 E.45204
G1 X73.994 Y124.534 E.08386
G1 X88.706 Y124.534 E.45204
G1 X88.706 Y123.23 E.04008
G1 X88.329 Y123.17 F30000
G1 F12000
G1 X88.329 Y122.182 E.03034
G1 X74.371 Y122.182 E.42887
G1 X74.371 Y124.157 E.06068
G1 X88.329 Y124.157 E.42887
G1 X88.329 Y123.23 E.0285
G1 X87.952 Y123.17 F30000
G1 F12000
G1 X87.952 Y122.56 E.01876
G1 X74.748 Y122.56 E.4057
G1 X74.748 Y123.78 E.03751
G1 X87.952 Y123.78 E.4057
M73 P72 R7
G1 X87.952 Y123.23 E.01691
G1 X87.552 Y123.17 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X87.552 Y122.959 E.00725
G1 X75.148 Y122.959 E.42645
G1 X75.148 Y123.381 E.0145
G1 X87.552 Y123.381 E.42645
G1 X87.552 Y123.23 E.00519
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X87.552 Y123.381 E-.05736
G1 X85.703 Y123.381 E-.70264
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 20/33
; update layer progress
M73 L20
M991 S0 P19 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.2 I-.171 J1.205 P1  F30000
G1 X182.398 Y137.143 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X73.602 Y137.143 E3.60896
G1 X73.602 Y133.665 E.11537
G1 X73.602 Y133.63 E.00116
G1 X182.398 Y133.63 E3.60896
G1 X182.398 Y133.665 E.00116
G1 X182.398 Y137.083 E.11338
M204 S250
G1 X182.79 Y137.535 F30000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X73.21 Y137.535 E3.36709
G1 X73.21 Y134.451 E.09474
G1 X73.21 Y134.051 E.01229
G1 F6459.938
G1 X73.21 Y133.651 E.01229
G1 F1800
G1 X73.21 Y133.282 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X73.21 Y133.238 E.00148
G1 X182.79 Y133.238 E3.63497
G1 X182.79 Y133.282 E.00148
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y133.651 E.01134
G1 F6459.938
G1 X182.79 Y134.051 E.01229
G1 F12000
G1 X182.79 Y134.451 E.01229
G1 X182.79 Y137.475 E.0929
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

; WIPE_START
M204 S10000
G1 X180.79 Y137.476 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X173.161 Y137.232 Z4.4 F30000
G1 X74.038 Y134.066 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.5077
G1 F13554.799
G1 X74.038 Y134.531 E.0176
G1 X181.962 Y134.531 E4.08748
G1 X181.962 Y134.066 E.0176
G1 X74.098 Y134.066 E4.08521
G1 X73.95 Y134.986 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X75.559 Y134.967 E.05337
G1 X76.682 Y136.089 E.05266
G1 X79.531 Y136.089 E.09452
G1 X80.654 Y134.967 E.05266
G1 X83.235 Y134.967 E.08563
G1 X84.358 Y136.089 E.05266
G1 X87.207 Y136.089 E.09452
G1 X88.33 Y134.967 E.05266
G1 X90.911 Y134.967 E.08563
G1 X92.033 Y136.089 E.05266
G1 X94.883 Y136.089 E.09452
G1 X96.006 Y134.967 E.05266
G1 X98.587 Y134.967 E.08563
G1 X99.709 Y136.089 E.05266
G1 X102.559 Y136.089 E.09452
G1 X103.681 Y134.967 E.05266
G1 X106.263 Y134.967 E.08563
G1 X107.385 Y136.089 E.05266
G1 X110.235 Y136.089 E.09452
G1 X111.357 Y134.967 E.05266
G1 X113.939 Y134.967 E.08563
G1 X115.061 Y136.089 E.05266
G1 X117.911 Y136.089 E.09452
G1 X119.033 Y134.967 E.05266
G1 X121.615 Y134.967 E.08563
G1 X122.737 Y136.089 E.05266
G1 X125.587 Y136.089 E.09452
G1 X126.709 Y134.967 E.05266
G1 X129.291 Y134.967 E.08563
G1 X130.413 Y136.089 E.05266
G1 X133.263 Y136.089 E.09452
G1 X134.385 Y134.967 E.05266
G1 X136.967 Y134.967 E.08563
G1 X138.089 Y136.089 E.05266
G1 X140.939 Y136.089 E.09452
G1 X142.061 Y134.967 E.05266
G1 X144.643 Y134.967 E.08563
G1 X145.765 Y136.089 E.05266
G1 X148.615 Y136.089 E.09452
G1 X149.737 Y134.967 E.05266
G1 X152.319 Y134.967 E.08563
G1 X153.441 Y136.089 E.05266
G1 X156.291 Y136.089 E.09452
G1 X157.413 Y134.967 E.05266
G1 X159.994 Y134.967 E.08563
G1 X161.117 Y136.089 E.05266
G1 X163.967 Y136.089 E.09452
G1 X165.089 Y134.967 E.05266
G1 X167.67 Y134.967 E.08563
G1 X168.793 Y136.089 E.05266
G1 X171.642 Y136.089 E.09452
G1 X172.765 Y134.967 E.05266
G1 X175.346 Y134.967 E.08563
G1 X176.469 Y136.089 E.05266
G1 X179.318 Y136.089 E.09452
M73 P73 R7
G1 X180.441 Y134.967 E.05266
G1 X182.05 Y134.986 E.05337
G1 X73.967 Y136.778 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.36618
G1 F12000
G1 X182.033 Y136.778 E2.84662
G1 X182.033 Y136.454 E.00852
G1 X73.967 Y136.454 E2.84662
G1 X73.967 Y136.718 E.00693
; WIPE_START
G1 X73.967 Y136.454 E-.10004
G1 X75.704 Y136.454 E-.65996
; WIPE_END
G1 E-.04 F1800
G1 X83.291 Y135.623 Z4.4 F30000
G1 X126.092 Y130.936 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
M204 S5000
G2 X126.46 Y131.21 I2.778 J-3.347 E.01521
G1 X126.407 Y131.384 E.00603
G1 X111.592 Y131.384 E.49145
G1 X111.54 Y131.209 E.00605
G2 X111.908 Y130.936 I-2.297 J-3.477 E.0152
; FEATURE: Inner wall
M204 S10000
G1 X111.976 Y130.876 E.00299
G1 F840
G1 X112.076 Y130.778 E.00466
G1 F1788.593
G1 X112.172 Y130.675 E.00465
G1 F2951.955
G1 X112.254 Y130.578 E.00421
G1 F3286.361
G1 X112.273 Y130.553 E.00105
G1 F9128.623
G1 X112.501 Y130.222 E.01336
G1 F15082.176
G1 X112.635 Y129.967 E.00953
G1 F15476.087
G1 X112.722 Y129.735 E.00821
G2 X112.902 Y128.757 I-2.841 J-1.028 E.03315
G1 X112.902 Y122.185 E.21802
G1 X125.098 Y122.185 E.40456
G1 X125.098 Y128.757 E.21801
G2 X125.261 Y129.708 I2.913 J-.011 E.03217
G1 X125.428 Y130.094 E.01395
G1 F11850.753
G1 X125.57 Y130.337 E.00932
G1 F6759.123
G1 X125.726 Y130.553 E.00886
G1 F3233.409
G1 X125.734 Y130.564 E.00043
G1 F3093.909
G1 X125.824 Y130.671 E.00465
G1 F1791.508
G1 X125.92 Y130.774 E.00467
G1 F840
G1 X126.02 Y130.872 E.00465
G1 F600
G1 X126.047 Y130.896 E.00119
; WIPE_START
G1 X126.46 Y131.21 E-.19693
G1 X126.407 Y131.384 E-.06909
G1 X125.108 Y131.384 E-.49398
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I.032 J-1.217 P1  F30000
G1 X108.092 Y130.936 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X108.46 Y131.21 I2.775 J-3.344 E.01521
G1 X108.407 Y131.384 E.00603
G1 X93.593 Y131.384 E.49144
G1 X93.541 Y131.209 E.00604
G2 X93.908 Y130.936 I-2.511 J-3.758 E.0152
; FEATURE: Inner wall
M204 S10000
G1 X93.976 Y130.876 E.00299
G1 F840
G1 X94.076 Y130.778 E.00467
G1 F1787.685
G1 X94.172 Y130.675 E.00465
G1 F3088.779
G1 X94.262 Y130.568 E.00465
G1 F3288.93
G1 X94.274 Y130.553 E.00062
G1 F6741.51
G1 X94.427 Y130.342 E.00866
G1 F11847.924
G1 X94.57 Y130.099 E.00935
G1 F15476.087
G1 X94.739 Y129.707 E.01418
G2 X94.902 Y128.757 I-2.749 J-.96 E.0321
G1 X94.902 Y122.185 E.21802
G1 X107.098 Y122.185 E.40456
G1 X107.098 Y128.757 E.21801
G2 X107.261 Y129.708 I2.913 J-.011 E.03217
G1 X107.428 Y130.094 E.01394
G1 F12028.614
G1 X107.57 Y130.337 E.00932
G1 F6894.175
G1 X107.726 Y130.553 E.00887
G1 F3325.599
G1 X107.734 Y130.564 E.00043
G1 F3183.803
G1 X107.825 Y130.671 E.00465
G1 F1858.674
G1 X107.912 Y130.765 E.00424
G1 F960
G1 X108.019 Y130.871 E.00502
G1 F600
G1 X108.047 Y130.896 E.00123
; WIPE_START
G1 X108.46 Y131.21 E-.19693
G1 X108.407 Y131.384 E-.0691
G1 X107.108 Y131.384 E-.49397
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I.032 J-1.217 P1  F30000
G1 X90.092 Y130.936 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Overhang wall
G1 F600
M204 S5000
G2 X90.46 Y131.21 I2.975 J-3.613 E.01521
G1 X90.407 Y131.384 E.00603
M73 P74 R7
G1 X73.602 Y131.384 E.55747
G1 X73.602 Y130.936 E.01486
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X73.602 Y130.553 E.01269
G1 F6459.938
G1 X73.602 Y130.153 E.01327
G1 F13999.876
G1 X73.602 Y129.753 E.01327
G1 F15476.087
G1 X73.602 Y129.353 E.01327
G1 X73.602 Y122.185 E.2378
G1 X89.098 Y122.185 E.51403
G1 X89.098 Y128.757 E.21801
G2 X89.264 Y129.707 I2.957 J-.026 E.03215
G1 X89.369 Y129.975 E.00952
G1 F14765.067
G1 X89.484 Y130.197 E.0083
G1 F9559.066
G1 X89.726 Y130.553 E.0143
G1 F3233.031
G1 X89.734 Y130.564 E.00044
G1 F3091.808
G1 X89.824 Y130.671 E.00464
G1 F1791.391
G1 X89.92 Y130.774 E.00467
G1 F840
G1 X90.02 Y130.872 E.00465
G1 F600
G1 X90.047 Y130.896 E.00119
; WIPE_START
G1 X90.46 Y131.21 E-.19692
G1 X90.407 Y131.384 E-.0691
G1 X89.108 Y131.384 E-.49398
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I.204 J1.2 P1  F30000
G1 X143.098 Y122.185 Z4.4
G1 Z4
G1 E.8 F1800
G1 F15476.087
G1 X143.098 Y128.757 E.21801
G2 X143.261 Y129.708 I2.913 J-.011 E.03217
G1 X143.428 Y130.094 E.01395
G1 F11847.993
G1 X143.57 Y130.337 E.00931
G1 F6759.339
G1 X143.726 Y130.553 E.00887
G1 F3232.042
G1 X143.733 Y130.563 E.00039
G1 F3107.492
G1 X143.824 Y130.671 E.0047
G1 F1790.256
G1 X143.92 Y130.774 E.00466
G1 F840
G1 X144.02 Y130.872 E.00465
G1 F600
G1 X144.092 Y130.936 E.00318
; FEATURE: Overhang wall

M204 S5000
G2 X144.46 Y131.21 I2.771 J-3.339 E.01521
G1 X144.407 Y131.384 E.00603
G1 X129.592 Y131.384 E.49145
G1 X129.54 Y131.209 E.00605
G2 X129.908 Y130.936 I-2.303 J-3.484 E.0152
; FEATURE: Inner wall
M204 S10000
G1 X129.975 Y130.876 E.00298
G1 F720
G1 X130.067 Y130.787 E.00425
G1 F1700.342
G1 X130.171 Y130.676 E.00504
G1 F2984.018
G1 X130.262 Y130.568 E.00468
G1 F3180.264
G1 X130.274 Y130.553 E.00062
G1 F11734.277
G1 X130.572 Y130.095 E.01816
G1 F15476.087
G1 X130.737 Y129.708 E.01395
G2 X130.902 Y128.757 I-2.778 J-.972 E.03214
G1 X130.902 Y122.185 E.21802
G1 X143.038 Y122.185 E.40257
; WIPE_START
G1 X143.056 Y124.185 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X150.642 Y123.344 Z4.4 F30000
G1 X161.098 Y122.185 Z4.4
G1 Z4
G1 E.8 F1800
G1 F15476.087
G1 X161.098 Y128.757 E.21801
G2 X161.269 Y129.713 I3.019 J-.048 E.03235
G1 X161.427 Y130.093 E.01366
G1 F11883.103
G1 X161.57 Y130.337 E.00937
G1 F6757.23
G1 X161.726 Y130.553 E.00887
G1 F3231.823
G1 X161.734 Y130.564 E.00043
G1 F3092.885
G1 X161.825 Y130.671 E.00466
G1 F1789.004
G1 X161.92 Y130.774 E.00466
G1 F840
G1 X162.02 Y130.872 E.00466
G1 F600
G1 X162.092 Y130.936 E.00318
; FEATURE: Overhang wall

M204 S5000
G2 X162.46 Y131.21 I2.729 J-3.282 E.01524
G1 X162.408 Y131.384 E.00602
G1 X147.593 Y131.384 E.49145
G1 X147.541 Y131.209 E.00604
G2 X147.908 Y130.936 I-2.24 J-3.389 E.01519
; FEATURE: Inner wall
M204 S10000
G1 X147.975 Y130.877 E.00296
G1 F840
G1 X148.076 Y130.778 E.0047
G1 F1687.121
G1 X148.163 Y130.685 E.00423
G1 F3078.124
G1 X148.261 Y130.569 E.00504
G1 F3291.355
G1 X148.274 Y130.553 E.00066
G1 F11352.861
G1 X148.558 Y130.12 E.0172
G1 F15476.087
G1 X148.739 Y129.706 E.01498
G2 X148.902 Y128.757 I-2.749 J-.96 E.0321
G1 X148.902 Y122.185 E.21802
G1 X161.038 Y122.185 E.40257
; WIPE_START
G1 X161.056 Y124.185 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X168.655 Y123.473 Z4.4 F30000
G1 X182.398 Y122.185 Z4.4
G1 Z4
G1 E.8 F1800
G1 F15476.087
G1 X182.398 Y129.353 E.2378
G1 X182.398 Y129.753 E.01327
G1 F13999.876
G1 X182.398 Y130.153 E.01327
G1 F6459.938
G1 X182.398 Y130.553 E.01327
G1 F1800
G1 X182.398 Y130.936 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X182.398 Y131.384 E.01486
G1 F600
G1 X165.593 Y131.384 E.55747
G1 X165.541 Y131.209 E.00604
G2 X165.908 Y130.936 I-2.365 J-3.562 E.0152
; FEATURE: Inner wall
M204 S10000
G1 X165.967 Y130.884 E.0026
G1 F720
G1 X166.075 Y130.779 E.00501
G1 F1622.584
G1 X166.172 Y130.675 E.0047
G1 F2868.807
G1 X166.262 Y130.568 E.00464
G1 F3061.288
G1 X166.274 Y130.553 E.00062
G1 F8720.152
G1 X166.501 Y130.223 E.01331
G1 F14587.784
G1 X166.635 Y129.967 E.00958
G1 F15476.087
G1 X166.728 Y129.737 E.00821
G2 X166.902 Y128.757 I-2.744 J-.994 E.03319
G1 X166.902 Y122.185 E.21802
G1 X182.338 Y122.185 E.51204
; WIPE_START
G1 X182.355 Y124.185 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y120.546 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y129.767 E.28334
G1 X182.79 Y130.167 E.01229
G1 F6459.938
G1 X182.79 Y130.567 E.01229
G1 F1800
G1 X182.79 Y130.936 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F600
G1 X182.79 Y131.776 E.02786
G1 X178.283 Y131.776 E.1495
G1 X73.21 Y131.776 E3.48547
G1 X73.21 Y130.936 E.02786
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y130.567 E.01134
G1 F6459.938
G1 X73.21 Y130.167 E.01229
G1 F12000
G1 X73.21 Y129.767 E.01229
G1 X73.21 Y120.546 E.28334
G1 X89.49 Y120.546 E.50024
G1 X89.49 Y128.752 E.25217
G2 X89.674 Y129.692 I2.515 J-.005 E.02961
G1 X89.898 Y130.122 E.01487
G1 F11040.832
G1 X90.04 Y130.319 E.00747
G1 F6725.139
G1 X90.269 Y130.567 E.01036
G1 F2501.6
G1 X90.288 Y130.585 E.00082
G1 F2255.703
G1 X90.371 Y130.659 E.00341
G1 F1367.205
G1 X90.473 Y130.742 E.00404
G1 F600
G1 X90.571 Y130.814 E.00374
G2 X90.767 Y130.936 I1.356 J-1.953 E.00708
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X90.777 Y130.942 E.00041
G2 X93.233 Y130.936 I1.222 J-2.214 E.08507
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G2 X93.417 Y130.822 I-1.092 J-1.962 E.00665
G1 X93.523 Y130.746 E.004
G1 F1300.362
G1 X93.618 Y130.669 E.00375
G1 F2263.7
G1 X93.709 Y130.589 E.00373
G1 F2556.693
G1 X93.731 Y130.567 E.00097
G1 F6741.068
G1 X93.957 Y130.322 E.01022
G1 F11046.445
G1 X94.099 Y130.126 E.00745
G1 F12000
G1 X94.322 Y129.695 E.01491
G2 X94.51 Y128.752 I-2.352 J-.959 E.02973
G1 X94.51 Y120.546 E.25217
G1 X107.49 Y120.546 E.39884
G1 X107.49 Y128.752 E.25217
G2 X107.676 Y129.692 I2.54 J-.016 E.0296
G1 X107.898 Y130.122 E.01488
G1 F11035.653
G1 X108.04 Y130.319 E.00745
G1 F6729.941
G1 X108.269 Y130.567 E.01036
G1 F2503.757
G1 X108.287 Y130.585 E.0008
G1 F2262.481
G1 X108.378 Y130.666 E.00374
G1 F1297.066
G1 X108.473 Y130.742 E.00373
G1 F600
G1 X108.571 Y130.814 E.00373
G2 X108.767 Y130.936 I1.355 J-1.951 E.00708
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X108.777 Y130.942 E.00041
G2 X111.233 Y130.936 I1.222 J-2.214 E.08507
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G2 X111.424 Y130.817 I-1.223 J-2.178 E.00692
G1 X111.523 Y130.745 E.00374
G1 F1297.831
G1 X111.618 Y130.669 E.00373
G1 F2260.36
G1 X111.709 Y130.589 E.00373
G1 F2553.143
G1 X111.731 Y130.567 E.00097
G1 F8748.587
G1 X112.03 Y130.226 E.01393
G1 F12000
G1 X112.272 Y129.803 E.01497
G2 X112.51 Y128.752 I-2.338 J-1.082 E.03335
G1 X112.51 Y120.546 E.25217
G1 X125.49 Y120.546 E.39884
G1 X125.49 Y128.752 E.25217
G2 X125.676 Y129.691 I2.54 J-.016 E.0296
G1 X125.898 Y130.122 E.01489
G1 F11035.722
G1 X126.04 Y130.319 E.00745
G1 F6730.212
G1 X126.269 Y130.567 E.01036
G1 F2504.56
G1 X126.288 Y130.585 E.00082
G1 F2258.45
G1 X126.378 Y130.666 E.00373
G1 F1297.066
G1 X126.473 Y130.742 E.00373
G1 F600
G1 X126.571 Y130.814 E.00373
G2 X126.767 Y130.936 I1.445 J-2.096 E.00708
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X126.777 Y130.942 E.00039
G2 X129.233 Y130.936 I1.223 J-2.214 E.08508
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G2 X129.424 Y130.817 I-1.222 J-2.176 E.00692
G1 X129.523 Y130.745 E.00374
M73 P75 R7
G1 F1297.831
G1 X129.618 Y130.669 E.00373
G1 F2260.165
G1 X129.709 Y130.589 E.00373
G1 F2553.14
G1 X129.731 Y130.567 E.00097
G1 F8797.059
G1 X130.032 Y130.224 E.01401
G1 F12000
G1 X130.218 Y129.912 E.01115
G2 X130.51 Y128.752 I-2.29 J-1.194 E.03709
G1 X130.51 Y120.546 E.25217
G1 X143.49 Y120.546 E.39884
G1 X143.49 Y128.752 E.25217
G2 X143.676 Y129.692 I2.54 J-.016 E.0296
G1 X143.898 Y130.122 E.01488
G1 F11036.325
G1 X144.04 Y130.318 E.00744
G1 F6738.054
G1 X144.269 Y130.567 E.01038
G1 F2504.56
G1 X144.288 Y130.585 E.00082
G1 F2258.195
G1 X144.378 Y130.666 E.00373
G1 F1297.162
G1 X144.473 Y130.742 E.00373
G1 F600
G1 X144.571 Y130.814 E.00373
G2 X144.767 Y130.936 I1.354 J-1.95 E.00709
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X144.777 Y130.942 E.00041
G2 X147.233 Y130.936 I1.222 J-2.214 E.08507
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G2 X147.425 Y130.817 I-1.135 J-2.036 E.00693
G1 X147.523 Y130.745 E.00373
G1 F1227.833
G1 X147.61 Y130.676 E.00342
G1 F2256.776
G1 X147.708 Y130.589 E.00404
G1 F2553.128
G1 X147.731 Y130.567 E.00098
G1 F6728.864
G1 X147.956 Y130.323 E.0102
G1 F11098.348
G1 X148.101 Y130.124 E.00755
G1 F12000
G1 X148.324 Y129.696 E.01483
G2 X148.51 Y128.752 I-2.329 J-.949 E.02974
G1 X148.51 Y120.546 E.25217
G1 X161.49 Y120.546 E.39884
G1 X161.49 Y128.752 E.25217
G2 X161.835 Y130.019 I2.519 J-.007 E.0408
G1 X161.967 Y130.222 E.00745
G1 F8745.745
G1 X162.269 Y130.567 E.01408
G1 F2505.435
G1 X162.288 Y130.585 E.00082
G1 F2259.026
G1 X162.378 Y130.666 E.00373
G1 F1297.792
G1 X162.473 Y130.742 E.00373
G1 F600
G1 X162.563 Y130.808 E.00343
G2 X162.767 Y130.936 I1.326 J-1.884 E.00738
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45

G1 X162.777 Y130.942 E.00041
G2 X165.233 Y130.936 I1.222 J-2.212 E.08505
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G2 X165.425 Y130.817 I-1.058 J-1.919 E.00695
G1 X165.523 Y130.745 E.00373
G1 F1297.681
G1 X165.618 Y130.669 E.00373
G1 F2163.463
G1 X165.7 Y130.596 E.0034
G1 F2549.668
G1 X165.731 Y130.567 E.00129
G1 F8754.368
G1 X166.03 Y130.226 E.01395
G1 F12000
G1 X166.272 Y129.803 E.01496
G2 X166.51 Y128.752 I-2.336 J-1.082 E.03335
G1 X166.51 Y120.546 E.25217
G1 X182.73 Y120.546 E.4984
M204 S10000
G1 X182.583 Y121.277 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.897 Y121.962 E.02978
G1 X181.364 Y121.962
G1 X182.573 Y120.753 E.05255
G1 X182.04 Y120.753
G1 X180.831 Y121.962 E.05255
G1 X180.298 Y121.962
G1 X181.507 Y120.753 E.05255
G1 X180.974 Y120.753
G1 X179.764 Y121.962 E.05255
G1 X179.231 Y121.962
G1 X180.44 Y120.753 E.05255
G1 X179.907 Y120.753
G1 X178.698 Y121.962 E.05255
G1 X178.164 Y121.962
G1 X179.374 Y120.753 E.05255
G1 X178.841 Y120.753
G1 X177.631 Y121.962 E.05255
G1 X177.098 Y121.962
G1 X178.307 Y120.753 E.05255
G1 X177.774 Y120.753
G1 X176.565 Y121.962 E.05255
G1 X176.031 Y121.962
G1 X177.241 Y120.753 E.05255
G1 X176.708 Y120.753
G1 X175.498 Y121.962 E.05255
G1 X174.965 Y121.962
G1 X176.174 Y120.753 E.05255
G1 X175.641 Y120.753
G1 X174.432 Y121.962 E.05255
G1 X173.898 Y121.962
G1 X175.108 Y120.753 E.05255
G1 X174.574 Y120.753
G1 X173.365 Y121.962 E.05255
G1 X172.832 Y121.962
G1 X174.041 Y120.753 E.05255
G1 X173.508 Y120.753
G1 X172.299 Y121.962 E.05255
G1 X171.765 Y121.962
G1 X172.975 Y120.753 E.05255
G1 X172.441 Y120.753
G1 X171.232 Y121.962 E.05255
G1 X170.699 Y121.962
G1 X171.908 Y120.753 E.05255
G1 X171.375 Y120.753
G1 X170.166 Y121.962 E.05255
G1 X169.632 Y121.962
G1 X170.842 Y120.753 E.05255
G1 X170.308 Y120.753
G1 X169.099 Y121.962 E.05255
G1 X168.566 Y121.962
G1 X169.775 Y120.753 E.05255
G1 X169.242 Y120.753
G1 X168.033 Y121.962 E.05255
G1 X167.499 Y121.962
G1 X168.709 Y120.753 E.05255
G1 X168.175 Y120.753
G1 X166.966 Y121.962 E.05255
G1 X166.717 Y121.678
G1 X167.642 Y120.753 E.04018
G1 X167.109 Y120.753
G1 X166.717 Y121.144 E.01701
; WIPE_START
M204 S10000
G1 X167.109 Y120.753 E-.21038
G1 X167.642 Y120.753 E-.20264
G1 X166.996 Y121.399 E-.34698
; WIPE_END
G1 E-.04 F1800
G1 X167.706 Y125.698 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X167.25 Y125.698 E.01512
G1 X167.25 Y126.871 E.0389
G1 X168.314 Y127.934 E.0499
G1 X172.121 Y127.934 E.1263
G1 X174.358 Y125.698 E.10491
G1 X173.754 Y125.698 E.02004
G1 X175.99 Y127.934 E.10491
G1 X179.797 Y127.934 E.1263
G1 X182.034 Y125.698 E.10491
G1 X181.43 Y125.698 E.02004
G1 X182.05 Y126.318 E.02909
G1 X182.038 Y127.934 E.05362
G1 X182.234 Y129.521 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.42474
G1 F3000
G1 X167.143 Y129.521 E.46956
G3 X167.021 Y129.903 I-7.457 J-2.156 E.01247
G1 X182.065 Y129.903 E.46805
G1 X182.065 Y130.284 E.01188
G1 X166.845 Y130.284 E.47354
G3 X166.599 Y130.666 I-1.684 J-.812 E.01416
G1 X182.065 Y130.666 E.48118
G1 X182.065 Y131.048 E.01188
G1 X166.336 Y131.048 E.48936
G1 X166.111 Y131.061 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.106207
G1 F15000
G3 X165.984 Y131.162 I-.166 J-.078 E.00087
G1 X165.377 Y131.348 F30000
; LINE_WIDTH: 0.415346
G1 F15000
G1 X165.147 Y131.399 E.00715
; LINE_WIDTH: 0.391506
G1 X165.082 Y131.412 E.0019
; LINE_WIDTH: 0.364465
G1 X165.009 Y131.426 E.00195
; LINE_WIDTH: 0.326838
G1 X164.87 Y131.45 E.00324
; LINE_WIDTH: 0.282868
G1 X164.728 Y131.47 E.00282
; LINE_WIDTH: 0.246873
G1 X164.599 Y131.486 E.00215
; LINE_WIDTH: 0.207221
G1 X164.331 Y131.508 E.00361
; LINE_WIDTH: 0.177793
G1 X163.928 Y131.518 E.00443
G1 X163.526 Y131.498 E.00443
; LINE_WIDTH: 0.220452
G1 X163.39 Y131.484 E.00197
; LINE_WIDTH: 0.250411
G1 X163.254 Y131.468 E.00232
; LINE_WIDTH: 0.287298
G1 X163.117 Y131.447 E.00276
; LINE_WIDTH: 0.331384
G1 X162.978 Y131.424 E.00331
; LINE_WIDTH: 0.368211
G1 X162.912 Y131.411 E.00176
; LINE_WIDTH: 0.411381
G1 X162.623 Y131.348 E.00888
G1 X162.016 Y131.162 F30000
; LINE_WIDTH: 0.105422
G1 F15000
G1 X161.966 Y131.144 E.00027
G1 X161.885 Y131.057 E.00061
; WIPE_START
G1 X161.966 Y131.144 E-.52518
G1 X162.016 Y131.162 E-.23482
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I1.044 J-.625 P1  F30000
G1 X161.034 Y129.521 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42473
G1 F3000
G1 X149.141 Y129.521 E.37004
G3 X149.018 Y129.903 I-3.03 J-.764 E.01249
G1 X160.981 Y129.903 E.37219
G2 X161.153 Y130.284 I1.675 J-.526 E.01306
G1 X148.849 Y130.284 E.38282
G1 X148.607 Y130.666 E.01407
G1 X161.402 Y130.666 E.3981
G1 X161.573 Y130.891 E.0088
G1 X161.404 Y131.048 E.00718
G1 X148.338 Y131.048 E.40653
G1 X148.112 Y131.06 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.10614
G1 F15000
G3 X147.984 Y131.162 I-.167 J-.078 E.00087
G1 X147.377 Y131.348 F30000
; LINE_WIDTH: 0.41534
G1 F15000
G1 X147.147 Y131.399 E.00716
; LINE_WIDTH: 0.391489
G1 X147.082 Y131.412 E.0019
; LINE_WIDTH: 0.364459
G1 X147.009 Y131.426 E.00195
; LINE_WIDTH: 0.326979
G1 X146.871 Y131.449 E.00323
; LINE_WIDTH: 0.283811
G1 X146.734 Y131.469 E.00272
; LINE_WIDTH: 0.247014
G1 X146.592 Y131.486 E.00238
; LINE_WIDTH: 0.206583
G1 X146.331 Y131.508 E.0035
; LINE_WIDTH: 0.177795
G1 X145.929 Y131.518 E.00442
G1 X145.525 Y131.498 E.00445
; LINE_WIDTH: 0.221427
G1 X145.383 Y131.483 E.00208
; LINE_WIDTH: 0.251343
G1 X145.254 Y131.468 E.00221
; LINE_WIDTH: 0.287299
G1 X145.117 Y131.447 E.00276
; LINE_WIDTH: 0.331373
G1 X144.978 Y131.424 E.00331
; LINE_WIDTH: 0.368188
G1 X144.912 Y131.411 E.00176
; LINE_WIDTH: 0.41144
G1 X144.623 Y131.348 E.0089
G1 X144.016 Y131.162 F30000
; LINE_WIDTH: 0.106503
G1 F15000
G1 X143.963 Y131.143 E.00029
G1 X143.875 Y131.048 E.00067
; WIPE_START
G1 X143.963 Y131.143 E-.52833
G1 X144.016 Y131.162 E-.23167
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I1.044 J-.625 P1  F30000
G1 X143.034 Y129.521 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42472
G1 F3000
G1 X131.141 Y129.521 E.37003
G3 X131.019 Y129.903 I-3.159 J-.801 E.01248
G1 X142.982 Y129.903 E.37219
G1 X143.154 Y130.284 E.01303
G1 X130.848 Y130.284 E.38286
G3 X130.6 Y130.666 I-2.122 J-1.107 E.01418
G1 X143.395 Y130.666 E.39808
G1 X143.565 Y130.88 E.0085
G1 X143.383 Y131.048 E.00771
G1 X130.336 Y131.048 E.4059
G1 X130.111 Y131.061 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.106201
G1 F15000
G3 X129.984 Y131.162 I-.166 J-.078 E.00087
G1 X129.377 Y131.349 F30000
; LINE_WIDTH: 0.413625
G1 F15000
G1 X129.139 Y131.401 E.00738
; LINE_WIDTH: 0.377029
G1 X129.016 Y131.425 E.0034
; LINE_WIDTH: 0.328113
G1 X128.871 Y131.45 E.00343
; LINE_WIDTH: 0.282855
G1 X128.728 Y131.47 E.00282
; LINE_WIDTH: 0.246883
G1 X128.6 Y131.485 E.00214
; LINE_WIDTH: 0.207241
G1 X128.331 Y131.508 E.00362
; LINE_WIDTH: 0.177769
G1 X127.929 Y131.518 E.00442
G1 X127.526 Y131.498 E.00444
; LINE_WIDTH: 0.220452
G1 X127.39 Y131.484 E.00197
; LINE_WIDTH: 0.25041
G1 X127.254 Y131.468 E.00232
; LINE_WIDTH: 0.287287
G1 X127.117 Y131.447 E.00276
; LINE_WIDTH: 0.331373
G1 X126.978 Y131.424 E.00331
; LINE_WIDTH: 0.368188
G1 X126.912 Y131.411 E.00176
; LINE_WIDTH: 0.411444
G1 X126.623 Y131.348 E.0089
G1 X126.016 Y131.162 F30000
; LINE_WIDTH: 0.105464
G1 F15000
G1 X125.966 Y131.144 E.00027
G1 X125.884 Y131.056 E.00061
; WIPE_START
G1 X125.966 Y131.144 E-.52548
G1 X126.016 Y131.162 E-.23452
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I1.044 J-.625 P1  F30000
G1 X125.034 Y129.521 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42473
G1 F3000
G1 X113.143 Y129.521 E.36998
G3 X113.021 Y129.903 I-7.479 J-2.163 E.01246
G1 X124.982 Y129.903 E.37211
G2 X125.153 Y130.284 I1.657 J-.515 E.01305
G1 X112.845 Y130.284 E.38294
G3 X112.607 Y130.666 I-3.912 J-2.174 E.014
G1 X125.402 Y130.666 E.39809
G1 X125.573 Y130.891 E.00877
G1 X125.403 Y131.048 E.00721
G1 X112.314 Y131.048 E.40725
G1 X112.1 Y131.071 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.104883
G1 F15000
G3 X111.984 Y131.162 I-.151 J-.072 E.00077
G1 X111.377 Y131.348 F30000
; LINE_WIDTH: 0.415318
G1 F15000
G1 X111.147 Y131.399 E.00715
; LINE_WIDTH: 0.391496
G1 X111.082 Y131.412 E.00189
; LINE_WIDTH: 0.364485
G1 X111.009 Y131.426 E.00195
; LINE_WIDTH: 0.326981
G1 X110.871 Y131.449 E.00323
; LINE_WIDTH: 0.283843
G1 X110.735 Y131.469 E.0027
; LINE_WIDTH: 0.247743
G1 X110.599 Y131.486 E.00228
; LINE_WIDTH: 0.207217
G1 X110.331 Y131.508 E.00361
; LINE_WIDTH: 0.177808
G1 X109.932 Y131.518 E.00438
G1 X109.525 Y131.498 E.00448
; LINE_WIDTH: 0.221426
G1 X109.383 Y131.483 E.00208
; LINE_WIDTH: 0.251355
G1 X109.254 Y131.468 E.00221
; LINE_WIDTH: 0.287318
G1 X109.117 Y131.447 E.00276
; LINE_WIDTH: 0.331363
G1 X108.978 Y131.424 E.00331
; LINE_WIDTH: 0.368255
G1 X108.912 Y131.411 E.00177
; LINE_WIDTH: 0.411656
G1 X108.623 Y131.348 E.00889
G1 X108.016 Y131.162 F30000
; LINE_WIDTH: 0.105469
G1 F15000
G1 X107.966 Y131.144 E.00027
G1 X107.884 Y131.056 E.00061
; WIPE_START
G1 X107.966 Y131.144 E-.52531
G1 X108.016 Y131.162 E-.23469
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I1.045 J-.624 P1  F30000
G1 X107.036 Y129.521 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42472
G1 F3000
G1 X95.141 Y129.521 E.37007
G3 X95.02 Y129.903 I-3.535 J-.907 E.01246
G1 X106.982 Y129.903 E.37214
G2 X107.153 Y130.284 I1.657 J-.515 E.01305
G1 X94.845 Y130.284 E.38293
G3 X94.607 Y130.666 I-2.019 J-.992 E.01401
G1 X107.402 Y130.666 E.39807
G1 X107.573 Y130.891 E.00878
G1 X107.403 Y131.048 E.0072
G1 X94.336 Y131.048 E.40655
G1 X94.111 Y131.061 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.106169
G1 F15000
G3 X93.984 Y131.162 I-.166 J-.078 E.00087
G1 X93.377 Y131.348 F30000
; LINE_WIDTH: 0.41535
G1 F15000
G1 X93.147 Y131.399 E.00716
; LINE_WIDTH: 0.391501
G1 X93.082 Y131.412 E.00189
; LINE_WIDTH: 0.364454
G1 X93.009 Y131.426 E.00195
; LINE_WIDTH: 0.326793
G1 X92.87 Y131.45 E.00325
; LINE_WIDTH: 0.282815
G1 X92.728 Y131.47 E.00282
; LINE_WIDTH: 0.246862
G1 X92.599 Y131.486 E.00215
; LINE_WIDTH: 0.207217
G1 X92.331 Y131.508 E.00361
; LINE_WIDTH: 0.177808
G1 X91.932 Y131.518 E.00438
G1 X91.525 Y131.498 E.00448
; LINE_WIDTH: 0.221426
G1 X91.383 Y131.483 E.00208
; LINE_WIDTH: 0.251355
G1 X91.254 Y131.468 E.00221
; LINE_WIDTH: 0.287321
G1 X91.117 Y131.447 E.00276
; LINE_WIDTH: 0.331384
G1 X90.978 Y131.424 E.00331
; LINE_WIDTH: 0.368274
G1 X90.912 Y131.411 E.00177
; LINE_WIDTH: 0.411679
G1 X90.623 Y131.348 E.00889
G1 X90.001 Y131.18 F30000
; LINE_WIDTH: 0.108298
G1 F15000
G1 X89.885 Y131.057 E.0009
; WIPE_START
G1 X90.001 Y131.18 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I1.052 J-.613 P1  F30000
G1 X89.034 Y129.521 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42471
G1 F3000
G1 X73.935 Y129.521 E.46975
G1 X73.935 Y129.903 E.01188
G1 X88.98 Y129.903 E.46805
G2 X89.16 Y130.285 I1.652 J-.544 E.01316
G1 X73.935 Y130.285 E.47364
G1 X73.935 Y130.666 E.01188
G1 X89.402 Y130.666 E.48119
G1 X89.573 Y130.891 E.00878
G1 X89.403 Y131.048 E.0072
G1 X73.766 Y131.048 E.48651
; WIPE_START
G1 X75.766 Y131.048 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I1.053 J-.61 P1  F30000
G1 X73.962 Y127.934 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
M73 P76 R7
G1 F15476.087
G1 X73.95 Y126.318 E.05362
G1 X74.57 Y125.698 E.02909
G1 X73.966 Y125.698 E.02004
G1 X76.203 Y127.934 E.10491
G1 X80.01 Y127.934 E.1263
G1 X82.246 Y125.698 E.10491
G1 X81.642 Y125.698 E.02004
G1 X83.879 Y127.934 E.10491
G1 X87.686 Y127.934 E.1263
G1 X88.75 Y126.871 E.0499
G1 X88.75 Y125.698 E.0389
G1 X88.294 Y125.698 E.01512
G1 X88.706 Y125.306 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y122.577 E.08386
G1 X73.994 Y122.577 E.45204
G1 X73.994 Y125.306 E.08386
G1 X88.646 Y125.306 E.4502
G1 X88.329 Y124.929 F30000
G1 F12000
G1 X88.329 Y122.954 E.06068
G1 X74.371 Y122.954 E.42887
G1 X74.371 Y124.929 E.06068
G1 X88.269 Y124.929 E.42702
G1 X87.952 Y124.552 F30000
G1 F12000
G1 X87.952 Y123.331 E.03751
G1 X74.748 Y123.331 E.4057
G1 X74.748 Y124.552 E.03751
G1 X87.892 Y124.552 E.40385
G1 X87.552 Y124.152 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X87.552 Y123.73 E.0145
G1 X75.148 Y123.73 E.42645
G1 X75.148 Y124.152 E.0145
G1 X87.492 Y124.152 E.42439
; WIPE_START
G1 X85.492 Y124.152 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.283 Y121.257 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.577 Y121.962 E.03065
G1 X88.044 Y121.962
G1 X89.253 Y120.753 E.05255
G1 X88.72 Y120.753
G1 X87.511 Y121.962 E.05255
M73 P76 R6
G1 X86.977 Y121.962
G1 X88.187 Y120.753 E.05255
G1 X87.653 Y120.753
G1 X86.444 Y121.962 E.05255
G1 X85.911 Y121.962
G1 X87.12 Y120.753 E.05255
G1 X86.587 Y120.753
G1 X85.378 Y121.962 E.05255
G1 X84.844 Y121.962
G1 X86.054 Y120.753 E.05255
G1 X85.52 Y120.753
G1 X84.311 Y121.962 E.05255
G1 X83.778 Y121.962
G1 X84.987 Y120.753 E.05255
G1 X84.454 Y120.753
G1 X83.245 Y121.962 E.05255
G1 X82.711 Y121.962
G1 X83.921 Y120.753 E.05255
G1 X83.387 Y120.753
G1 X82.178 Y121.962 E.05255
G1 X81.645 Y121.962
G1 X82.854 Y120.753 E.05255
G1 X82.321 Y120.753
G1 X81.112 Y121.962 E.05255
G1 X80.578 Y121.962
G1 X81.788 Y120.753 E.05255
G1 X81.254 Y120.753
G1 X80.045 Y121.962 E.05255
G1 X79.512 Y121.962
G1 X80.721 Y120.753 E.05255
G1 X80.188 Y120.753
G1 X78.979 Y121.962 E.05255
G1 X78.445 Y121.962
G1 X79.655 Y120.753 E.05255
G1 X79.121 Y120.753
G1 X77.912 Y121.962 E.05255
G1 X77.379 Y121.962
G1 X78.588 Y120.753 E.05255
G1 X78.055 Y120.753
G1 X76.846 Y121.962 E.05255
G1 X76.312 Y121.962
G1 X77.522 Y120.753 E.05255
G1 X76.988 Y120.753
G1 X75.779 Y121.962 E.05255
G1 X75.246 Y121.962
G1 X76.455 Y120.753 E.05255
G1 X75.922 Y120.753
G1 X74.713 Y121.962 E.05255
G1 X74.179 Y121.962
G1 X75.389 Y120.753 E.05255
G1 X74.855 Y120.753
G1 X73.646 Y121.962 E.05255
G1 X73.417 Y121.658
G1 X74.322 Y120.753 E.03931
G1 X73.789 Y120.753
G1 X73.417 Y121.124 E.01614
; WIPE_START
M204 S10000
G1 X73.789 Y120.753 E-.1996
G1 X74.322 Y120.753 E-.20264
G1 X73.656 Y121.419 E-.35776
; WIPE_END
G1 E-.04 F1800
G1 X80.593 Y124.603 Z4.4 F30000
G1 X88.706 Y128.326 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X73.994 Y128.326 E.45204
G1 X73.994 Y129.141 E.02505
G1 X88.746 Y129.141 E.45326
G1 X88.709 Y128.386 E.02323
G1 X74.402 Y128.734 F30000
; LINE_WIDTH: 0.481
G1 F14380.934
G1 X88.238 Y128.734 E.49394
; WIPE_START
G1 X86.238 Y128.734 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.4 I.303 J1.179 P1  F30000
G1 X95.25 Y126.418 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X95.25 Y127.934 E.05031
G1 X95.362 Y127.934 E.0037
G1 X97.598 Y125.698 E.10491
G1 X96.994 Y125.698 E.02004
G1 X99.23 Y127.934 E.10491
G1 X103.038 Y127.934 E.1263
G1 X105.274 Y125.698 E.10491
G1 X104.67 Y125.698 E.02004
G1 X106.75 Y127.778 E.09756
G1 X106.75 Y127.934 E.0052
G1 X105.278 Y127.934 E.04882
G1 X106.706 Y128.326 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X95.294 Y128.326 E.35064
G1 X95.256 Y129.141 E.02507
G1 X106.745 Y129.141 E.35302
G1 X106.709 Y128.386 E.02323
G1 X95.702 Y128.734 F30000
; LINE_WIDTH: 0.48097
G1 F14381.919
G1 X106.238 Y128.734 E.37611
G1 X106.706 Y123.941 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.706 Y122.577 E.04193
G1 X95.294 Y122.577 E.35064
G1 X95.294 Y125.306 E.08386
G1 X106.706 Y125.306 E.35064
G1 X106.706 Y124.001 E.04008
G1 X106.329 Y123.941 F30000
G1 F12000
G1 X106.329 Y122.954 E.03034
G1 X95.671 Y122.954 E.32747
G1 X95.671 Y124.929 E.06068
G1 X106.329 Y124.929 E.32747
G1 X106.329 Y124.001 E.0285
G1 X105.952 Y123.941 F30000
G1 F12000
G1 X105.952 Y123.331 E.01876
G1 X96.048 Y123.331 E.3043
G1 X96.048 Y124.552 E.03751
G1 X105.952 Y124.552 E.3043
G1 X105.952 Y124.001 E.01691
G1 X105.552 Y123.941 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X105.552 Y123.73 E.00725
G1 X96.448 Y123.73 E.313
G1 X96.448 Y124.152 E.0145
G1 X105.552 Y124.152 E.313
G1 X105.552 Y124.001 E.00519
; WIPE_START
G1 X105.552 Y124.152 E-.05736
G1 X103.703 Y124.152 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X107.283 Y121.388 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.708 Y121.962 E.02497
G1 X106.175 Y121.962
G1 X107.283 Y120.854 E.04814
G1 X106.851 Y120.753
G1 X105.641 Y121.962 E.05255
G1 X105.108 Y121.962
G1 X106.318 Y120.753 E.05255
G1 X105.784 Y120.753
G1 X104.575 Y121.962 E.05255
G1 X104.042 Y121.962
G1 X105.251 Y120.753 E.05255
G1 X104.718 Y120.753
G1 X103.508 Y121.962 E.05255
G1 X102.975 Y121.962
G1 X104.184 Y120.753 E.05255
G1 X103.651 Y120.753
G1 X102.442 Y121.962 E.05255
G1 X101.909 Y121.962
G1 X103.118 Y120.753 E.05255
G1 X102.585 Y120.753
G1 X101.375 Y121.962 E.05255
G1 X100.842 Y121.962
G1 X102.051 Y120.753 E.05255
G1 X101.518 Y120.753
G1 X100.309 Y121.962 E.05255
G1 X99.776 Y121.962
G1 X100.985 Y120.753 E.05255
G1 X100.452 Y120.753
G1 X99.242 Y121.962 E.05255
G1 X98.709 Y121.962
G1 X99.918 Y120.753 E.05255
G1 X99.385 Y120.753
G1 X98.176 Y121.962 E.05255
G1 X97.643 Y121.962
G1 X98.852 Y120.753 E.05255
G1 X98.319 Y120.753
G1 X97.109 Y121.962 E.05255
G1 X96.576 Y121.962
G1 X97.785 Y120.753 E.05255
G1 X97.252 Y120.753
G1 X96.043 Y121.962 E.05255
G1 X95.51 Y121.962
G1 X96.719 Y120.753 E.05255
G1 X96.186 Y120.753
G1 X94.976 Y121.962 E.05255
G1 X94.717 Y121.688
G1 X95.652 Y120.753 E.04063
G1 X95.119 Y120.753
G1 X94.717 Y121.155 E.01746
; WIPE_START
M204 S10000
G1 X95.119 Y120.753 E-.21588
G1 X95.652 Y120.753 E-.20264
G1 X95.017 Y121.388 E-.34148
; WIPE_END
G1 E-.04 F1800
G1 X102.46 Y123.08 Z4.4 F30000
G1 X113.974 Y125.698 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X113.25 Y125.698 E.02402
G1 X113.25 Y126.602 E.03
G1 X114.582 Y127.934 E.06249
G1 X118.39 Y127.934 E.1263
G1 X120.626 Y125.698 E.10491
G1 X120.022 Y125.698 E.02004
G1 X122.258 Y127.934 E.10491
G1 X123.887 Y127.934 E.05401
G1 X124.706 Y128.326 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X113.294 Y128.326 E.35064
G1 X113.257 Y129.141 E.02507
G1 X124.744 Y129.141 E.35297
G1 X124.709 Y128.386 E.02323
G1 X113.702 Y128.734 F30000
; LINE_WIDTH: 0.48097
G1 F14381.919
G1 X124.238 Y128.734 E.37611
G1 X124.706 Y123.941 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.706 Y122.577 E.04193
G1 X113.294 Y122.577 E.35064
G1 X113.294 Y125.306 E.08386
G1 X124.706 Y125.306 E.35064
G1 X124.706 Y124.001 E.04008
G1 X124.329 Y123.941 F30000
G1 F12000
G1 X124.329 Y122.954 E.03034
G1 X113.671 Y122.954 E.32747
G1 X113.671 Y124.929 E.06068
G1 X124.329 Y124.929 E.32747
G1 X124.329 Y124.001 E.0285
G1 X123.952 Y123.941 F30000
G1 F12000
G1 X123.952 Y123.331 E.01876
G1 X114.048 Y123.331 E.3043
G1 X114.048 Y124.552 E.03751
G1 X123.952 Y124.552 E.3043
G1 X123.952 Y124.001 E.01691
G1 X123.552 Y123.941 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X123.552 Y123.73 E.00725
G1 X114.448 Y123.73 E.313
G1 X114.448 Y124.152 E.0145
G1 X123.552 Y124.152 E.313
G1 X123.552 Y124.001 E.00519
; WIPE_START
G1 X123.552 Y124.152 E-.05736
G1 X121.703 Y124.152 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X125.283 Y121.518 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X124.839 Y121.962 E.01929
G1 X124.305 Y121.962
G1 X125.283 Y120.985 E.04246
G1 X124.982 Y120.753
G1 X123.772 Y121.962 E.05255
G1 X123.239 Y121.962
G1 X124.448 Y120.753 E.05255
G1 X123.915 Y120.753
G1 X122.706 Y121.962 E.05255
G1 X122.172 Y121.962
G1 X123.382 Y120.753 E.05255
G1 X122.848 Y120.753
G1 X121.639 Y121.962 E.05255
G1 X121.106 Y121.962
G1 X122.315 Y120.753 E.05255
G1 X121.782 Y120.753
G1 X120.573 Y121.962 E.05255
G1 X120.039 Y121.962
G1 X121.249 Y120.753 E.05255
G1 X120.715 Y120.753
G1 X119.506 Y121.962 E.05255
G1 X118.973 Y121.962
G1 X120.182 Y120.753 E.05255
G1 X119.649 Y120.753
G1 X118.44 Y121.962 E.05255
G1 X117.906 Y121.962
G1 X119.116 Y120.753 E.05255
G1 X118.582 Y120.753
G1 X117.373 Y121.962 E.05255
G1 X116.84 Y121.962
G1 X118.049 Y120.753 E.05255
G1 X117.516 Y120.753
G1 X116.307 Y121.962 E.05255
G1 X115.773 Y121.962
G1 X116.983 Y120.753 E.05255
G1 X116.449 Y120.753
G1 X115.24 Y121.962 E.05255
G1 X114.707 Y121.962
G1 X115.916 Y120.753 E.05255
G1 X115.383 Y120.753
G1 X114.174 Y121.962 E.05255
G1 X113.64 Y121.962
G1 X114.85 Y120.753 E.05255
G1 X114.316 Y120.753
G1 X113.107 Y121.962 E.05255
G1 X112.717 Y121.819
G1 X113.783 Y120.753 E.04631
G1 X113.25 Y120.753
G1 X112.717 Y121.285 E.02314
; WIPE_START
M204 S10000
G1 X113.25 Y120.753 E-.28616
G1 X113.783 Y120.753 E-.20264
G1 X113.278 Y121.258 E-.27121
; WIPE_END
G1 E-.04 F1800
G1 X120.384 Y124.045 Z4.4 F30000
G1 X131.294 Y128.326 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X131.256 Y129.141 E.02507
G1 X142.744 Y129.141 E.35298
G1 X142.706 Y128.326 E.02507
G1 X131.354 Y128.326 E.3488
G1 X131.702 Y128.734 F30000
; LINE_WIDTH: 0.48097
G1 F14381.919
G1 X142.238 Y128.734 E.37611
G1 X142.706 Y125.306 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.706 Y122.577 E.08386
G1 X131.294 Y122.577 E.35064
G1 X131.294 Y125.306 E.08386
G1 X142.646 Y125.306 E.3488
G1 X142.329 Y124.929 F30000
G1 F12000
G1 X142.329 Y122.954 E.06068
G1 X131.671 Y122.954 E.32747
G1 X131.671 Y124.929 E.06068
G1 X142.269 Y124.929 E.32563
G1 X141.952 Y124.552 F30000
G1 F12000
G1 X141.952 Y123.331 E.03751
G1 X132.048 Y123.331 E.3043
G1 X132.048 Y124.552 E.03751
G1 X141.892 Y124.552 E.30245
G1 X141.552 Y124.152 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X141.552 Y123.73 E.0145
G1 X132.448 Y123.73 E.313
G1 X132.448 Y124.152 E.0145
G1 X141.492 Y124.152 E.31094
; WIPE_START
G1 X139.492 Y124.152 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X142.436 Y121.962 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X143.283 Y121.116 E.03678
G1 X143.112 Y120.753
G1 X141.903 Y121.962 E.05255
G1 X141.37 Y121.962
G1 X142.579 Y120.753 E.05255
G1 X142.046 Y120.753
G1 X140.836 Y121.962 E.05255
G1 X140.303 Y121.962
G1 X141.513 Y120.753 E.05255
G1 X140.979 Y120.753
G1 X139.77 Y121.962 E.05255
G1 X139.237 Y121.962
G1 X140.446 Y120.753 E.05255
G1 X139.913 Y120.753
G1 X138.703 Y121.962 E.05255
G1 X138.17 Y121.962
G1 X139.379 Y120.753 E.05255
G1 X138.846 Y120.753
G1 X137.637 Y121.962 E.05255
G1 X137.104 Y121.962
G1 X138.313 Y120.753 E.05255
G1 X137.78 Y120.753
G1 X136.57 Y121.962 E.05255
G1 X136.037 Y121.962
G1 X137.246 Y120.753 E.05255
G1 X136.713 Y120.753
G1 X135.504 Y121.962 E.05255
G1 X134.971 Y121.962
G1 X136.18 Y120.753 E.05255
G1 X135.647 Y120.753
G1 X134.437 Y121.962 E.05255
G1 X133.904 Y121.962
G1 X135.113 Y120.753 E.05255
G1 X134.58 Y120.753
G1 X133.371 Y121.962 E.05255
G1 X132.838 Y121.962
G1 X134.047 Y120.753 E.05255
G1 X133.514 Y120.753
G1 X132.304 Y121.962 E.05255
G1 X131.771 Y121.962
G1 X132.98 Y120.753 E.05255
G1 X132.447 Y120.753
G1 X131.238 Y121.962 E.05255
G1 X130.717 Y121.949
G1 X131.914 Y120.753 E.05199
G1 X131.381 Y120.753
G1 X130.717 Y121.416 E.02882
; WIPE_START
M204 S10000
G1 X131.381 Y120.753 E-.35641
G1 X131.914 Y120.753 E-.20264
G1 X131.54 Y121.127 E-.20095
; WIPE_END
G1 E-.04 F1800
G1 X132.113 Y127.934 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X133.742 Y127.934 E.05401
G1 X135.978 Y125.698 E.10491
G1 X135.374 Y125.698 E.02004
G1 X137.61 Y127.934 E.10491
G1 X141.418 Y127.934 E.1263
G1 X142.75 Y126.602 E.06249
G1 X142.75 Y125.698 E.03
G1 X142.026 Y125.698 E.02402
; WIPE_START
G1 X142.75 Y125.698 E-.27515
G1 X142.75 Y126.602 E-.34361
G1 X142.487 Y126.865 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X149.294 Y128.326 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X149.256 Y129.141 E.02507
G1 X160.744 Y129.141 E.35298
G1 X160.706 Y128.326 E.02507
G1 X149.354 Y128.326 E.3488
G1 X149.702 Y128.734 F30000
; LINE_WIDTH: 0.48097
G1 F14381.919
G1 X160.238 Y128.734 E.37611
G1 X160.706 Y123.941 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.706 Y122.577 E.04193
G1 X149.294 Y122.577 E.35064
G1 X149.294 Y125.306 E.08386
G1 X160.706 Y125.306 E.35064
G1 X160.706 Y124.001 E.04008
G1 X160.329 Y123.941 F30000
G1 F12000
G1 X160.329 Y122.954 E.03034
G1 X149.671 Y122.954 E.32747
G1 X149.671 Y124.929 E.06068
G1 X160.329 Y124.929 E.32747
G1 X160.329 Y124.001 E.0285
G1 X159.952 Y123.941 F30000
G1 F12000
G1 X159.952 Y123.331 E.01876
G1 X150.048 Y123.331 E.3043
G1 X150.048 Y124.552 E.03751
G1 X159.952 Y124.552 E.3043
G1 X159.952 Y124.001 E.01691
G1 X159.552 Y123.941 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X159.552 Y123.73 E.00725
G1 X150.448 Y123.73 E.313
G1 X150.448 Y124.152 E.0145
G1 X159.552 Y124.152 E.313
G1 X159.552 Y124.001 E.00519
; WIPE_START
G1 X159.552 Y124.152 E-.05736
G1 X157.703 Y124.152 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X161.283 Y121.247 Z4.4 F30000
G1 Z4
M73 P77 R6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X160.567 Y121.962 E.0311
G1 X160.034 Y121.962
G1 X161.243 Y120.753 E.05255
G1 X160.71 Y120.753
G1 X159.5 Y121.962 E.05255
G1 X158.967 Y121.962
G1 X160.177 Y120.753 E.05255
G1 X159.643 Y120.753
G1 X158.434 Y121.962 E.05255
G1 X157.901 Y121.962
G1 X159.11 Y120.753 E.05255
G1 X158.577 Y120.753
G1 X157.367 Y121.962 E.05255
G1 X156.834 Y121.962
G1 X158.043 Y120.753 E.05255
G1 X157.51 Y120.753
G1 X156.301 Y121.962 E.05255
G1 X155.768 Y121.962
G1 X156.977 Y120.753 E.05255
G1 X156.444 Y120.753
G1 X155.234 Y121.962 E.05255
G1 X154.701 Y121.962
G1 X155.91 Y120.753 E.05255
G1 X155.377 Y120.753
G1 X154.168 Y121.962 E.05255
G1 X153.635 Y121.962
G1 X154.844 Y120.753 E.05255
G1 X154.311 Y120.753
G1 X153.101 Y121.962 E.05255
G1 X152.568 Y121.962
G1 X153.777 Y120.753 E.05255
G1 X153.244 Y120.753
G1 X152.035 Y121.962 E.05255
G1 X151.502 Y121.962
G1 X152.711 Y120.753 E.05255
G1 X152.178 Y120.753
G1 X150.968 Y121.962 E.05255
G1 X150.435 Y121.962
G1 X151.644 Y120.753 E.05255
G1 X151.111 Y120.753
G1 X149.902 Y121.962 E.05255
G1 X149.369 Y121.962
G1 X150.578 Y120.753 E.05255
G1 X150.045 Y120.753
G1 X148.835 Y121.962 E.05255
G1 X148.717 Y121.547
G1 X149.511 Y120.753 E.0345
; WIPE_START
M204 S10000
G1 X148.717 Y121.547 E-.42669
G1 X148.835 Y121.962 E-.16407
G1 X149.15 Y121.647 E-.16924
; WIPE_END
G1 E-.04 F1800
G1 X150.722 Y127.934 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X149.25 Y127.934 E.04882
G1 X149.25 Y127.778 E.0052
G1 X151.33 Y125.698 E.09756
G1 X150.726 Y125.698 E.02004
G1 X152.962 Y127.934 E.10491
G1 X156.77 Y127.934 E.1263
G1 X159.006 Y125.698 E.10491
G1 X158.402 Y125.698 E.02004
G1 X160.638 Y127.934 E.10491
G1 X160.75 Y127.934 E.0037
G1 X160.75 Y126.418 E.05031
; WIPE_START
G1 X160.75 Y127.934 E-.57635
G1 X160.638 Y127.934 E-.04241
G1 X160.375 Y127.671 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X167.294 Y128.326 Z4.4 F30000
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X167.257 Y129.141 E.02507
G1 X182.006 Y129.141 E.45319
G1 X182.006 Y128.326 E.02505
G1 X167.354 Y128.326 E.4502
G1 X167.702 Y128.734 F30000
; LINE_WIDTH: 0.48094
G1 F14382.906
G1 X181.538 Y128.734 E.49387
G1 X182.006 Y123.941 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y122.577 E.04193
G1 X167.294 Y122.577 E.45204
G1 X167.294 Y125.306 E.08386
G1 X182.006 Y125.306 E.45204
G1 X182.006 Y124.001 E.04008
G1 X181.629 Y123.941 F30000
G1 F12000
G1 X181.629 Y122.954 E.03034
G1 X167.671 Y122.954 E.42887
G1 X167.671 Y124.929 E.06068
G1 X181.629 Y124.929 E.42887
G1 X181.629 Y124.001 E.0285
G1 X181.252 Y123.941 F30000
G1 F12000
G1 X181.252 Y123.331 E.01876
G1 X168.048 Y123.331 E.4057
G1 X168.048 Y124.552 E.03751
G1 X181.252 Y124.552 E.4057
G1 X181.252 Y124.001 E.01691
G1 X180.852 Y123.941 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X180.852 Y123.73 E.00725
G1 X168.448 Y123.73 E.42645
G1 X168.448 Y124.152 E.0145
G1 X180.852 Y124.152 E.42645
G1 X180.852 Y124.001 E.00519
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X180.852 Y124.152 E-.05736
G1 X179.003 Y124.152 E-.70264
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 21/33
; update layer progress
M73 L21
M991 S0 P20 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.4 I.404 J1.148 P1  F30000
G1 X182.398 Y122.956 Z4.4
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y130.603 E.25367
G1 X182.398 Y131.003 E.01327
G1 F14331.075
G1 X182.398 Y131.403 E.01327
G1 F6685.538
G1 X182.398 Y131.803 E.01327
G1 F1920
G1 X182.398 Y132.186 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X182.398 Y132.828 E.0213
; FEATURE: Inner wall
G1 F1800
M204 S10000
G1 X182.398 Y133.21 E.01269
G1 F6459.938
G1 X182.398 Y133.61 E.01327
G1 F13999.876
G1 X182.398 Y134.01 E.01327
G1 F15476.087
G1 X182.398 Y134.41 E.01327
G1 X182.398 Y137.1 E.08921
G1 X73.602 Y137.1 E3.60896
G1 X73.602 Y134.41 E.08921
G1 X73.602 Y134.01 E.01327
G1 F13999.876
G1 X73.602 Y133.61 E.01327
G1 F6459.938
G1 X73.602 Y133.21 E.01327
G1 F1800
G1 X73.602 Y132.828 E.01269
; FEATURE: Overhang wall
G1 F3000
M204 S5000
G1 X73.602 Y132.186 E.0213
; FEATURE: Inner wall
G1 F1920
M204 S10000
G1 X73.602 Y131.803 E.01269
G1 F6685.538
G1 X73.602 Y131.403 E.01327
G1 F14331.075
G1 X73.602 Y131.003 E.01327
G1 F15476.087
G1 X73.602 Y130.603 E.01327
G1 X73.602 Y122.956 E.25367
G1 X89.098 Y122.956 E.51403
G1 X89.098 Y128.757 E.19242
G2 X94.902 Y128.757 I2.902 J-.007 E.30194
G1 X94.902 Y122.956 E.19242
G1 X107.098 Y122.956 E.40456
G1 X107.098 Y128.757 E.19242
G2 X112.902 Y128.757 I2.902 J-.014 E.30151
G1 X112.902 Y122.956 E.19242
G1 X125.098 Y122.956 E.40456
G1 X125.098 Y128.757 E.19242
G2 X130.902 Y128.757 I2.902 J-.01 E.30175
G1 X130.902 Y122.956 E.19243
G1 X143.098 Y122.956 E.40456
G1 X143.098 Y128.757 E.19242
G2 X148.902 Y128.757 I2.902 J-.01 E.30175
G1 X148.902 Y122.956 E.19243
G1 X161.098 Y122.956 E.40456
G1 X161.098 Y128.757 E.19242
G2 X166.902 Y128.757 I2.902 J-.011 E.30171
G1 X166.902 Y122.956 E.19243
G1 X182.338 Y122.956 E.51204
; WIPE_START
G1 X182.354 Y124.956 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y121.317 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y131.017 E.29805
G1 X182.79 Y131.417 E.01229
G1 F6685.538
G1 X182.79 Y131.817 E.01229
G1 F1920
G1 X182.79 Y132.186 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X182.79 Y132.828 E.0213
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X182.79 Y133.197 E.01134
G1 F6459.938
G1 X182.79 Y133.597 E.01229
G1 F12000
G1 X182.79 Y133.997 E.01229
G1 X182.79 Y137.492 E.10739
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y137.492 E3.36709
G1 X73.21 Y133.997 E.10739
G1 X73.21 Y133.597 E.01229
G1 F6459.938
G1 X73.21 Y133.197 E.01229
G1 F1800
G1 X73.21 Y132.828 E.01134
; FEATURE: Overhang wall
; LINE_WIDTH: 0.45
G1 F3000
G1 X73.21 Y132.186 E.0213
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1800
G1 X73.21 Y131.817 E.01134
G1 F6459.938
G1 X73.21 Y131.417 E.01229
G1 F12000
G1 X73.21 Y131.017 E.01229
G1 X73.21 Y121.317 E.29805
G1 X89.49 Y121.317 E.50024
G1 X89.49 Y128.752 E.22847
G2 X94.51 Y128.752 I2.51 J-.003 E.24211
G1 X94.51 Y121.317 E.22847
G1 X107.49 Y121.317 E.39884
G1 X107.49 Y128.752 E.22847
G2 X112.51 Y128.752 I2.51 J-.009 E.24176
G1 X112.51 Y121.317 E.22847
G1 X125.49 Y121.317 E.39884
G1 X125.49 Y128.752 E.22847
G2 X130.51 Y128.752 I2.51 J-.005 E.24198
G1 X130.51 Y121.317 E.22847
G1 X143.49 Y121.317 E.39884
G1 X143.49 Y128.752 E.22847
G2 X148.51 Y128.752 I2.51 J-.005 E.24198
G1 X148.51 Y121.317 E.22847
G1 X161.49 Y121.317 E.39884
G1 X161.49 Y128.752 E.22847
G2 X166.51 Y128.752 I2.51 J-.006 E.24194
G1 X166.51 Y121.317 E.22847
G1 X182.73 Y121.317 E.4984
M204 S10000
G1 X182.583 Y122.191 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.916 Y121.524 E.02897
G1 X181.383 Y121.524
G1 X182.583 Y122.724 E.05214
G1 X182.059 Y122.734
G1 X180.849 Y121.524 E.05255
G1 X180.316 Y121.524
G1 X181.526 Y122.734 E.05255
G1 X180.992 Y122.734
G1 X179.783 Y121.524 E.05255
G1 X179.25 Y121.524
G1 X180.459 Y122.734 E.05255
G1 X179.926 Y122.734
G1 X178.716 Y121.524 E.05255
G1 X178.183 Y121.524
G1 X179.392 Y122.734 E.05255
G1 X178.859 Y122.734
G1 X177.65 Y121.524 E.05255
G1 X177.117 Y121.524
G1 X178.326 Y122.734 E.05255
G1 X177.793 Y122.734
G1 X176.583 Y121.524 E.05255
G1 X176.05 Y121.524
G1 X177.259 Y122.734 E.05255
G1 X176.726 Y122.734
G1 X175.517 Y121.524 E.05255
G1 X174.984 Y121.524
G1 X176.193 Y122.734 E.05255
G1 X175.66 Y122.734
G1 X174.45 Y121.524 E.05255
G1 X173.917 Y121.524
G1 X175.126 Y122.734 E.05255
G1 X174.593 Y122.734
G1 X173.384 Y121.524 E.05255
G1 X172.851 Y121.524
G1 X174.06 Y122.734 E.05255
G1 X173.527 Y122.734
G1 X172.317 Y121.524 E.05255
G1 X171.784 Y121.524
G1 X172.993 Y122.734 E.05255
G1 X172.46 Y122.734
G1 X171.251 Y121.524 E.05255
G1 X170.718 Y121.524
G1 X171.927 Y122.734 E.05255
G1 X171.394 Y122.734
G1 X170.184 Y121.524 E.05255
G1 X169.651 Y121.524
G1 X170.86 Y122.734 E.05255
G1 X170.327 Y122.734
G1 X169.118 Y121.524 E.05255
G1 X168.585 Y121.524
G1 X169.794 Y122.734 E.05255
G1 X169.261 Y122.734
G1 X168.051 Y121.524 E.05255
G1 X167.518 Y121.524
G1 X168.727 Y122.734 E.05255
G1 X168.194 Y122.734
G1 X166.985 Y121.524 E.05255
G1 X166.717 Y121.79
G1 X167.661 Y122.734 E.041
G1 X167.128 Y122.734
G1 X166.717 Y122.323 E.01782
; WIPE_START
M204 S10000
G1 X167.128 Y122.734 E-.22042
G1 X167.661 Y122.734 E-.20264
G1 X167.034 Y122.107 E-.33694
; WIPE_END
G1 E-.04 F1800
G1 X161.283 Y122.221 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X160.586 Y121.524 E.03029
G1 X160.052 Y121.524
G1 X161.262 Y122.734 E.05255
G1 X160.728 Y122.734
G1 X159.519 Y121.524 E.05255
G1 X158.986 Y121.524
G1 X160.195 Y122.734 E.05255
G1 X159.662 Y122.734
G1 X158.453 Y121.524 E.05255
G1 X157.919 Y121.524
G1 X159.129 Y122.734 E.05255
G1 X158.595 Y122.734
G1 X157.386 Y121.524 E.05255
G1 X156.853 Y121.524
G1 X158.062 Y122.734 E.05255
G1 X157.529 Y122.734
G1 X156.32 Y121.524 E.05255
G1 X155.786 Y121.524
G1 X156.996 Y122.734 E.05255
G1 X156.462 Y122.734
G1 X155.253 Y121.524 E.05255
G1 X154.72 Y121.524
G1 X155.929 Y122.734 E.05255
G1 X155.396 Y122.734
G1 X154.187 Y121.524 E.05255
G1 X153.653 Y121.524
G1 X154.863 Y122.734 E.05255
G1 X154.329 Y122.734
G1 X153.12 Y121.524 E.05255
G1 X152.587 Y121.524
G1 X153.796 Y122.734 E.05255
G1 X153.263 Y122.734
G1 X152.054 Y121.524 E.05255
G1 X151.52 Y121.524
G1 X152.73 Y122.734 E.05255
G1 X152.196 Y122.734
G1 X150.987 Y121.524 E.05255
G1 X150.454 Y121.524
G1 X151.663 Y122.734 E.05255
G1 X151.13 Y122.734
G1 X149.921 Y121.524 E.05255
G1 X149.387 Y121.524
G1 X150.597 Y122.734 E.05255
G1 X150.063 Y122.734
G1 X148.854 Y121.524 E.05255
G1 X148.717 Y121.921
G1 X149.53 Y122.734 E.03531
M204 S10000
G1 X149.294 Y123.348 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.706 Y123.348 E.35065
G1 X160.707 Y125.494 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.708 Y126.077 E.01791
G1 X149.294 Y126.077 E.35069
G1 X149.294 Y125.494 E.01791
; Slow Down End
G1 F12000
G1 X149.294 Y123.408 E.0641
G1 X149.671 Y123.725 F30000
G1 F12000
G1 X160.329 Y123.725 E.32748
G1 X160.33 Y125.494 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.33 Y125.7 E.00632
G1 X149.671 Y125.7 E.32752
G1 X149.671 Y125.494 E.00632
; Slow Down End
G1 F12000
G1 X149.671 Y123.785 E.05252
G1 X150.048 Y124.102 F30000
G1 F12000
G1 X150.048 Y125.323 E.03751
G1 X159.953 Y125.323 E.30434
G1 X159.952 Y124.102 E.03751
G1 X150.108 Y124.102 E.30247
G1 X150.448 Y124.502 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X150.448 Y124.924 E.0145
G1 X159.553 Y124.924 E.31303
G1 X159.553 Y124.502 E.0145
G1 X150.508 Y124.502 E.31096
G1 X148.851 Y130.391 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X161.167 Y130.391 E.37841
G1 X160.987 Y130.079 E.01107
G1 X160.826 Y129.576 E.01623
G1 X149.182 Y129.576 E.35778
G1 X149.105 Y129.851 E.00876
G1 X148.883 Y130.341 E.01651
G1 X149.491 Y129.984 F30000
; LINE_WIDTH: 0.48099
G1 F14381.263
G1 X160.468 Y129.984 E.39187
G1 X160.295 Y129.184 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X160.786 Y129.184 E.01628
G3 X160.752 Y128.049 I4.7 J-.705 E.03778
G1 X159.173 Y126.469 E.07409
G1 X158.234 Y126.469 E.03114
G1 X155.52 Y129.184 E.12736
G1 X154.212 Y129.184 E.04337
G1 X151.497 Y126.469 E.12736
G1 X150.558 Y126.469 E.03114
G1 X149.25 Y127.778 E.06137
G3 X149.218 Y129.184 I-8.18 J.516 E.04673
G1 X149.438 Y129.184 E.0073
; WIPE_START
G1 X149.218 Y129.184 E-.08358
G1 X149.25 Y127.778 E-.53469
G1 X149.514 Y127.514 E-.14173
; WIPE_END
G1 E-.04 F1800
G1 X141.942 Y126.556 Z4.6 F30000
G1 X141.254 Y126.469 Z4.6
G1 Z4.2
G1 E.8 F1800
G1 F15476.087
G1 X142.752 Y126.469 E.04968
G1 X142.752 Y126.6 E.00434
G1 X140.168 Y129.184 E.12122
G1 X138.86 Y129.184 E.04337
G1 X136.145 Y126.469 E.12736
G1 X135.207 Y126.469 E.03114
G1 X132.492 Y129.184 E.12736
G1 X131.22 Y129.184 E.04218
G1 X131.246 Y128.829 E.01183
G1 X131.188 Y129.576 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X130.993 Y130.126 E.01794
G1 X130.838 Y130.391 E.00943
G1 X143.154 Y130.391 E.37842
G1 X142.895 Y129.852 E.01839
G1 X142.819 Y129.576 E.00878
G1 X131.248 Y129.576 E.35552
G1 X131.477 Y129.984 F30000
; LINE_WIDTH: 0.48099
G1 F14381.263
G1 X142.449 Y129.984 E.39169
; WIPE_START
G1 X140.449 Y129.984 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I1.184 J.281 P1  F30000
G1 X142.455 Y121.524 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X143.283 Y122.352 E.03597
G1 X143.131 Y122.734
G1 X141.922 Y121.524 E.05255
G1 X141.388 Y121.524
G1 X142.598 Y122.734 E.05255
G1 X142.064 Y122.734
G1 X140.855 Y121.524 E.05255
G1 X140.322 Y121.524
G1 X141.531 Y122.734 E.05255
G1 X140.998 Y122.734
G1 X139.789 Y121.524 E.05255
G1 X139.255 Y121.524
G1 X140.465 Y122.734 E.05255
G1 X139.931 Y122.734
G1 X138.722 Y121.524 E.05255
G1 X138.189 Y121.524
G1 X139.398 Y122.734 E.05255
G1 X138.865 Y122.734
G1 X137.656 Y121.524 E.05255
G1 X137.122 Y121.524
G1 X138.332 Y122.734 E.05255
G1 X137.798 Y122.734
G1 X136.589 Y121.524 E.05255
G1 X136.056 Y121.524
G1 X137.265 Y122.734 E.05255
G1 X136.732 Y122.734
G1 X135.523 Y121.524 E.05255
G1 X134.989 Y121.524
G1 X136.199 Y122.734 E.05255
G1 X135.665 Y122.734
G1 X134.456 Y121.524 E.05255
G1 X133.923 Y121.524
G1 X135.132 Y122.734 E.05255
G1 X134.599 Y122.734
G1 X133.39 Y121.524 E.05255
G1 X132.856 Y121.524
G1 X134.066 Y122.734 E.05255
G1 X133.532 Y122.734
G1 X132.323 Y121.524 E.05255
G1 X131.79 Y121.524
G1 X132.999 Y122.734 E.05255
G1 X132.466 Y122.734
G1 X131.256 Y121.524 E.05255
G1 X130.723 Y121.524
G1 X131.933 Y122.734 E.05255
G1 X131.399 Y122.734
G1 X130.717 Y122.052 E.02963
; WIPE_START
M204 S10000
G1 X131.399 Y122.734 E-.36646
G1 X131.933 Y122.734 E-.20264
G1 X131.577 Y122.378 E-.1909
; WIPE_END
G1 E-.04 F1800
G1 X131.294 Y123.348 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.706 Y123.348 E.35065
G1 X142.707 Y125.494 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.708 Y126.077 E.01791
G1 X131.294 Y126.077 E.35069
G1 X131.294 Y125.494 E.01791
; Slow Down End
G1 F12000
G1 X131.294 Y123.408 E.0641
G1 X131.671 Y123.725 F30000
G1 F12000
G1 X142.329 Y123.725 E.32748
G1 X142.33 Y125.494 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.33 Y125.7 E.00632
G1 X131.671 Y125.7 E.32752
G1 X131.671 Y125.494 E.00632
; Slow Down End
G1 F12000
G1 X131.671 Y123.785 E.05252
G1 X132.048 Y124.102 F30000
G1 F12000
G1 X132.048 Y125.323 E.03751
G1 X141.953 Y125.323 E.30434
G1 X141.952 Y124.102 E.03751
G1 X132.108 Y124.102 E.30247
G1 X132.448 Y124.502 F30000
; LINE_WIDTH: 0.464805
G1 F12000
G1 X132.448 Y124.924 E.0145
G1 X141.553 Y124.924 E.31303
G1 X141.553 Y124.502 E.0145
G1 X132.508 Y124.502 E.31096
; WIPE_START
G1 X134.508 Y124.502 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X127.152 Y122.467 Z4.6 F30000
G1 X125.283 Y121.95 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X124.857 Y121.524 E.01848
G1 X124.324 Y121.524
G1 X125.283 Y122.483 E.04165
G1 X125 Y122.734
G1 X123.791 Y121.524 E.05255
G1 X123.258 Y121.524
M73 P78 R6
G1 X124.467 Y122.734 E.05255
G1 X123.934 Y122.734
G1 X122.724 Y121.524 E.05255
G1 X122.191 Y121.524
G1 X123.4 Y122.734 E.05255
G1 X122.867 Y122.734
G1 X121.658 Y121.524 E.05255
G1 X121.125 Y121.524
G1 X122.334 Y122.734 E.05255
G1 X121.801 Y122.734
G1 X120.591 Y121.524 E.05255
G1 X120.058 Y121.524
G1 X121.267 Y122.734 E.05255
G1 X120.734 Y122.734
G1 X119.525 Y121.524 E.05255
G1 X118.992 Y121.524
G1 X120.201 Y122.734 E.05255
G1 X119.668 Y122.734
G1 X118.458 Y121.524 E.05255
G1 X117.925 Y121.524
G1 X119.134 Y122.734 E.05255
G1 X118.601 Y122.734
G1 X117.392 Y121.524 E.05255
G1 X116.859 Y121.524
G1 X118.068 Y122.734 E.05255
G1 X117.535 Y122.734
G1 X116.325 Y121.524 E.05255
G1 X115.792 Y121.524
G1 X117.001 Y122.734 E.05255
G1 X116.468 Y122.734
G1 X115.259 Y121.524 E.05255
G1 X114.726 Y121.524
G1 X115.935 Y122.734 E.05255
G1 X115.402 Y122.734
G1 X114.192 Y121.524 E.05255
G1 X113.659 Y121.524
G1 X114.868 Y122.734 E.05255
G1 X114.335 Y122.734
G1 X113.126 Y121.524 E.05255
G1 X112.717 Y121.649
G1 X113.802 Y122.734 E.04712
G1 X113.269 Y122.734
G1 X112.717 Y122.182 E.02395
; WIPE_START
M204 S10000
G1 X113.269 Y122.734 E-.2962
G1 X113.802 Y122.734 E-.20264
G1 X113.316 Y122.248 E-.26116
; WIPE_END
G1 E-.04 F1800
G1 X113.294 Y126.077 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.294 Y125.494 E.01791
; Slow Down End
G1 F12000
G1 X113.294 Y123.348 E.06595
G1 X124.706 Y123.348 E.35065
G1 X124.707 Y125.494 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.708 Y126.077 E.01791
; Slow Down End
G1 F12000
G1 X113.354 Y126.077 E.34885
G1 X113.671 Y125.7 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.671 Y125.494 E.00632
; Slow Down End
G1 F12000
G1 X113.671 Y123.725 E.05436
G1 X124.329 Y123.725 E.32748
G1 X124.33 Y125.494 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.33 Y125.7 E.00632
; Slow Down End
G1 F12000
G1 X113.731 Y125.7 E.32567
G1 X114.048 Y125.323 F30000
G1 F12000
G1 X123.953 Y125.323 E.30434
G1 X123.952 Y124.102 E.03751
G1 X114.048 Y124.102 E.30432
G1 X114.048 Y125.263 E.03567
G1 X114.448 Y124.924 F30000
; LINE_WIDTH: 0.464815
G1 F12000
G1 X123.553 Y124.924 E.31304
G1 X123.553 Y124.502 E.0145
G1 X114.448 Y124.502 E.31303
G1 X114.448 Y124.864 E.01244
; WIPE_START
G1 X114.448 Y124.502 E-.13752
G1 X116.086 Y124.502 E-.62248
; WIPE_END
G1 E-.04 F1800
G1 X108.727 Y122.478 Z4.6 F30000
G1 X107.283 Y122.08 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.727 Y121.524 E.02416
G1 X106.193 Y121.524
G1 X107.283 Y122.614 E.04733
G1 X106.869 Y122.734
G1 X105.66 Y121.524 E.05255
G1 X105.127 Y121.524
G1 X106.336 Y122.734 E.05255
G1 X105.803 Y122.734
G1 X104.594 Y121.524 E.05255
G1 X104.06 Y121.524
G1 X105.27 Y122.734 E.05255
G1 X104.736 Y122.734
G1 X103.527 Y121.524 E.05255
G1 X102.994 Y121.524
G1 X104.203 Y122.734 E.05255
G1 X103.67 Y122.734
G1 X102.461 Y121.524 E.05255
G1 X101.927 Y121.524
G1 X103.137 Y122.734 E.05255
G1 X102.603 Y122.734
G1 X101.394 Y121.524 E.05255
G1 X100.861 Y121.524
G1 X102.07 Y122.734 E.05255
G1 X101.537 Y122.734
G1 X100.328 Y121.524 E.05255
G1 X99.794 Y121.524
G1 X101.004 Y122.734 E.05255
G1 X100.47 Y122.734
G1 X99.261 Y121.524 E.05255
G1 X98.728 Y121.524
G1 X99.937 Y122.734 E.05255
G1 X99.404 Y122.734
G1 X98.195 Y121.524 E.05255
G1 X97.661 Y121.524
G1 X98.871 Y122.734 E.05255
G1 X98.337 Y122.734
G1 X97.128 Y121.524 E.05255
G1 X96.595 Y121.524
G1 X97.804 Y122.734 E.05255
G1 X97.271 Y122.734
G1 X96.062 Y121.524 E.05255
G1 X95.528 Y121.524
G1 X96.738 Y122.734 E.05255
G1 X96.204 Y122.734
G1 X94.995 Y121.524 E.05255
G1 X94.717 Y121.78
G1 X95.671 Y122.734 E.04144
G1 X95.138 Y122.734
G1 X94.717 Y122.313 E.01827
; WIPE_START
M204 S10000
G1 X95.138 Y122.734 E-.22593
G1 X95.671 Y122.734 E-.20264
G1 X95.054 Y122.117 E-.33143
; WIPE_END
G1 E-.04 F1800
G1 X95.294 Y123.348 Z4.6 F30000
G1 Z4.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.706 Y123.348 E.35065
G1 X106.707 Y125.494 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.708 Y126.077 E.01791
G1 X95.294 Y126.077 E.35069
G1 X95.294 Y125.494 E.01791
; Slow Down End
G1 F12000
G1 X95.294 Y123.408 E.0641
G1 X95.671 Y123.725 F30000
G1 F12000
G1 X106.329 Y123.725 E.32748
G1 X106.33 Y125.494 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.33 Y125.7 E.00632
G1 X95.671 Y125.7 E.32752
G1 X95.671 Y125.494 E.00632
; Slow Down End
G1 F12000
G1 X95.671 Y123.785 E.05252
G1 X96.048 Y124.102 F30000
G1 F12000
G1 X96.048 Y125.323 E.03751
G1 X105.953 Y125.323 E.30434
G1 X105.952 Y124.102 E.03751
G1 X96.108 Y124.102 E.30247
G1 X96.448 Y124.502 F30000
; LINE_WIDTH: 0.464815
G1 F12000
G1 X96.448 Y124.924 E.0145
G1 X105.553 Y124.924 E.31304
G1 X105.553 Y124.502 E.0145
G1 X96.508 Y124.502 E.31097
; WIPE_START
G1 X98.508 Y124.502 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X91.1 Y122.662 Z4.6 F30000
G1 X89.283 Y122.211 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.596 Y121.524 E.02984
G1 X88.063 Y121.524
G1 X89.272 Y122.734 E.05255
G1 X88.739 Y122.734
G1 X87.529 Y121.524 E.05255
G1 X86.996 Y121.524
G1 X88.205 Y122.734 E.05255
G1 X87.672 Y122.734
G1 X86.463 Y121.524 E.05255
G1 X85.93 Y121.524
G1 X87.139 Y122.734 E.05255
G1 X86.606 Y122.734
G1 X85.396 Y121.524 E.05255
G1 X84.863 Y121.524
G1 X86.072 Y122.734 E.05255
G1 X85.539 Y122.734
G1 X84.33 Y121.524 E.05255
G1 X83.797 Y121.524
G1 X85.006 Y122.734 E.05255
G1 X84.473 Y122.734
G1 X83.263 Y121.524 E.05255
G1 X82.73 Y121.524
G1 X83.939 Y122.734 E.05255
G1 X83.406 Y122.734
G1 X82.197 Y121.524 E.05255
G1 X81.664 Y121.524
G1 X82.873 Y122.734 E.05255
G1 X82.34 Y122.734
G1 X81.13 Y121.524 E.05255
G1 X80.597 Y121.524
G1 X81.806 Y122.734 E.05255
G1 X81.273 Y122.734
G1 X80.064 Y121.524 E.05255
G1 X79.531 Y121.524
G1 X80.74 Y122.734 E.05255
G1 X80.207 Y122.734
G1 X78.997 Y121.524 E.05255
G1 X78.464 Y121.524
G1 X79.673 Y122.734 E.05255
G1 X79.14 Y122.734
G1 X77.931 Y121.524 E.05255
G1 X77.397 Y121.524
G1 X78.607 Y122.734 E.05255
G1 X78.074 Y122.734
G1 X76.864 Y121.524 E.05255
G1 X76.331 Y121.524
G1 X77.54 Y122.734 E.05255
G1 X77.007 Y122.734
G1 X75.798 Y121.524 E.05255
G1 X75.264 Y121.524
G1 X76.474 Y122.734 E.05255
G1 X75.941 Y122.734
G1 X74.731 Y121.524 E.05255
G1 X74.198 Y121.524
G1 X75.407 Y122.734 E.05255
G1 X74.874 Y122.734
G1 X73.665 Y121.524 E.05255
G1 X73.417 Y121.81
G1 X74.341 Y122.734 E.04012
G1 X73.808 Y122.734
G1 X73.417 Y122.344 E.01695
; WIPE_START
M204 S10000
G1 X73.808 Y122.734 E-.20965
G1 X74.341 Y122.734 E-.20264
G1 X73.694 Y122.087 E-.34772
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I-1.216 J.035 P1  F30000
G1 X73.936 Y130.599 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.42099
G1 F3000
G1 X73.936 Y134.12 E.10848
G1 X74.314 Y134.12 E.01165
G1 X74.314 Y130.769 E.10325
G1 X74.692 Y130.769 E.01165
G1 X74.692 Y134.12 E.10325
G1 X75.07 Y134.12 E.01165
G1 X75.07 Y130.769 E.10325
G1 X75.448 Y130.769 E.01165
G1 X75.448 Y134.12 E.10325
G1 X75.826 Y134.12 E.01165
G1 X75.826 Y130.769 E.10325
G1 X76.204 Y130.769 E.01165
G1 X76.204 Y134.12 E.10325
G1 X76.582 Y134.12 E.01165
G1 X76.582 Y130.769 E.10325
G1 X76.96 Y130.769 E.01165
G1 X76.96 Y134.12 E.10325
G1 X77.339 Y134.12 E.01165
G1 X77.339 Y130.769 E.10325
G1 X77.717 Y130.769 E.01165
G1 X77.717 Y134.12 E.10325
G1 X78.095 Y134.12 E.01165
G1 X78.095 Y130.769 E.10325
G1 X78.473 Y130.769 E.01165
G1 X78.473 Y134.12 E.10325
G1 X78.851 Y134.12 E.01165
G1 X78.851 Y130.769 E.10325
G1 X79.229 Y130.769 E.01165
G1 X79.229 Y134.12 E.10325
G1 X79.607 Y134.12 E.01165
G1 X79.607 Y130.769 E.10325
G1 X79.985 Y130.769 E.01165
G1 X79.985 Y134.12 E.10325
G1 X80.363 Y134.12 E.01165
G1 X80.363 Y130.769 E.10325
G1 X80.741 Y130.769 E.01165
G1 X80.741 Y134.12 E.10325
G1 X81.119 Y134.12 E.01165
G1 X81.119 Y130.769 E.10325
G1 X81.497 Y130.769 E.01165
G1 X81.497 Y134.12 E.10325
G1 X81.875 Y134.12 E.01165
G1 X81.875 Y130.769 E.10325
G1 X82.253 Y130.769 E.01165
G1 X82.253 Y134.12 E.10325
G1 X82.631 Y134.12 E.01165
G1 X82.631 Y130.769 E.10325
G1 X83.01 Y130.769 E.01165
G1 X83.01 Y134.12 E.10325
G1 X83.388 Y134.12 E.01165
G1 X83.388 Y130.769 E.10325
G1 X83.766 Y130.769 E.01165
G1 X83.766 Y134.12 E.10325
G1 X84.144 Y134.12 E.01165
G1 X84.144 Y130.769 E.10325
G1 X84.522 Y130.769 E.01165
G1 X84.522 Y134.12 E.10325
G1 X84.9 Y134.12 E.01165
G1 X84.9 Y130.769 E.10325
G1 X85.278 Y130.769 E.01165
G1 X85.278 Y134.12 E.10325
G1 X85.656 Y134.12 E.01165
G1 X85.656 Y130.769 E.10325
G1 X86.034 Y130.769 E.01165
G1 X86.034 Y134.12 E.10325
G1 X86.412 Y134.12 E.01165
G1 X86.412 Y130.769 E.10325
G1 X86.79 Y130.769 E.01165
G1 X86.79 Y134.12 E.10325
G1 X87.168 Y134.12 E.01165
G1 X87.168 Y130.769 E.10325
G1 X87.546 Y130.769 E.01165
G1 X87.546 Y134.12 E.10325
G1 X87.924 Y134.12 E.01165
G1 X87.924 Y130.769 E.10325
G1 X88.303 Y130.769 E.01165
G1 X88.303 Y134.12 E.10325
G1 X88.681 Y134.12 E.01165
G1 X88.681 Y130.769 E.10325
G1 X89.059 Y130.769 E.01165
G1 X89.059 Y134.12 E.10325
G1 X89.437 Y134.12 E.01165
G1 X89.437 Y130.769 E.10325
G1 X89.48 Y130.769 E.00132
G2 X89.815 Y131.135 I2.804 J-2.225 E.01533
G1 X89.815 Y134.12 E.09194
G1 X90.193 Y134.12 E.01165
G1 X90.193 Y131.432 E.0828
G2 X90.571 Y131.646 I1.063 J-1.439 E.01341
G1 X90.571 Y134.12 E.07622
G1 X90.949 Y134.12 E.01165
G1 X90.949 Y131.807 E.07126
G2 X91.327 Y131.911 I.724 J-1.882 E.0121
G1 X91.327 Y134.12 E.06804
G1 X91.705 Y134.12 E.01165
G1 X91.705 Y131.965 E.06639
G2 X92.083 Y131.981 I.256 J-1.559 E.01169
G1 X92.083 Y134.12 E.0659
G1 X92.461 Y134.12 E.01165
G1 X92.461 Y131.945 E.067
G1 X92.524 Y131.936 E.00194
G2 X92.839 Y131.871 I-.111 J-1.34 E.00995
G1 X92.839 Y134.12 E.06928
G1 X93.217 Y134.12 E.01165
G1 X93.217 Y131.74 E.07332
G2 X93.596 Y131.561 I-.553 J-1.655 E.01292
G1 X93.596 Y134.12 E.07884
G1 X93.974 Y134.12 E.01165
G1 X93.974 Y131.306 E.08668
G2 X94.352 Y130.969 I-1.922 J-2.536 E.01562
G1 X94.352 Y134.12 E.09706
G1 X94.73 Y134.12 E.01165
G1 X94.73 Y130.769 E.10325
G1 X95.108 Y130.769 E.01165
G1 X95.108 Y134.12 E.10325
G1 X95.486 Y134.12 E.01165
G1 X95.486 Y130.769 E.10325
G1 X95.864 Y130.769 E.01165
G1 X95.864 Y134.12 E.10325
G1 X96.242 Y134.12 E.01165
G1 X96.242 Y130.769 E.10325
G1 X96.62 Y130.769 E.01165
G1 X96.62 Y134.12 E.10325
G1 X96.998 Y134.12 E.01165
G1 X96.998 Y130.769 E.10325
G1 X97.376 Y130.769 E.01165
G1 X97.376 Y134.12 E.10325
G1 X97.754 Y134.12 E.01165
G1 X97.754 Y130.769 E.10325
G1 X98.132 Y130.769 E.01165
G1 X98.132 Y134.12 E.10325
G1 X98.51 Y134.12 E.01165
G1 X98.51 Y130.769 E.10325
G1 X98.888 Y130.769 E.01165
G1 X98.888 Y134.12 E.10325
G1 X99.267 Y134.12 E.01165
G1 X99.267 Y130.769 E.10325
G1 X99.645 Y130.769 E.01165
G1 X99.645 Y134.12 E.10325
G1 X100.023 Y134.12 E.01165
G1 X100.023 Y130.769 E.10325
G1 X100.401 Y130.769 E.01165
G1 X100.401 Y134.12 E.10325
G1 X100.779 Y134.12 E.01165
G1 X100.779 Y130.769 E.10325
G1 X101.157 Y130.769 E.01165
G1 X101.157 Y134.12 E.10325
G1 X101.535 Y134.12 E.01165
G1 X101.535 Y130.769 E.10325
G1 X101.913 Y130.769 E.01165
G1 X101.913 Y134.12 E.10325
G1 X102.291 Y134.12 E.01165
G1 X102.291 Y130.769 E.10325
G1 X102.669 Y130.769 E.01165
G1 X102.669 Y134.12 E.10325
G1 X103.047 Y134.12 E.01165
G1 X103.047 Y130.769 E.10325
G1 X103.425 Y130.769 E.01165
G1 X103.425 Y134.12 E.10325
G1 X103.803 Y134.12 E.01165
G1 X103.803 Y130.769 E.10325
G1 X104.181 Y130.769 E.01165
G1 X104.181 Y134.12 E.10325
G1 X104.56 Y134.12 E.01165
G1 X104.56 Y130.769 E.10325
G1 X104.938 Y130.769 E.01165
G1 X104.938 Y134.12 E.10325
G1 X105.316 Y134.12 E.01165
G1 X105.316 Y130.769 E.10325
G1 X105.694 Y130.769 E.01165
G1 X105.694 Y134.12 E.10325
G1 X106.072 Y134.12 E.01165
G1 X106.072 Y130.769 E.10325
G1 X106.45 Y130.769 E.01165
G1 X106.45 Y134.12 E.10325
G1 X106.828 Y134.12 E.01165
G1 X106.828 Y130.769 E.10325
G1 X107.206 Y130.769 E.01165
G1 X107.206 Y134.12 E.10325
G1 X107.584 Y134.12 E.01165
G1 X107.584 Y130.898 E.09925
G2 X107.962 Y131.259 I2.744 J-2.498 E.01611
G1 X107.962 Y134.12 E.08814
G1 X108.34 Y134.12 E.01165
G1 X108.34 Y131.526 E.07992
G2 X108.718 Y131.716 I1.204 J-1.916 E.01306
G1 X108.718 Y134.12 E.07404
G1 X109.096 Y134.12 E.01165
G1 X109.096 Y131.843 E.07014
G1 X109.474 Y131.942 E.01204
G1 X109.474 Y134.12 E.0671
G1 X109.853 Y134.12 E.01165
G1 X109.853 Y131.98 E.06592
G2 X110.231 Y131.969 I.144 J-1.585 E.01168
G1 X110.231 Y134.12 E.06626
G1 X110.609 Y134.12 E.01165
G1 X110.609 Y131.925 E.06762
G1 X110.987 Y131.832 E.012
G1 X110.987 Y134.12 E.0705
G1 X111.365 Y134.12 E.01165
G1 X111.365 Y131.681 E.07512
G2 X111.743 Y131.472 I-.925 J-2.114 E.01334
G1 X111.743 Y134.12 E.08158
G1 X112.121 Y134.12 E.01165
G1 X112.121 Y131.186 E.09038
G1 X112.209 Y131.116 E.00347
G1 X112.499 Y130.803 E.01314
G1 X112.499 Y134.12 E.10219
G1 X112.877 Y134.12 E.01165
G1 X112.877 Y130.769 E.10325
G1 X113.255 Y130.769 E.01165
G1 X113.255 Y134.12 E.10325
G1 X113.633 Y134.12 E.01165
G1 X113.633 Y130.769 E.10325
G1 X114.011 Y130.769 E.01165
G1 X114.011 Y134.12 E.10325
G1 X114.389 Y134.12 E.01165
G1 X114.389 Y130.769 E.10325
G1 X114.767 Y130.769 E.01165
G1 X114.767 Y134.12 E.10325
G1 X115.146 Y134.12 E.01165
G1 X115.146 Y130.769 E.10325
G1 X115.524 Y130.769 E.01165
G1 X115.524 Y134.12 E.10325
G1 X115.902 Y134.12 E.01165
G1 X115.902 Y130.769 E.10325
G1 X116.28 Y130.769 E.01165
G1 X116.28 Y134.12 E.10325
G1 X116.658 Y134.12 E.01165
G1 X116.658 Y130.769 E.10325
G1 X117.036 Y130.769 E.01165
G1 X117.036 Y134.12 E.10325
G1 X117.414 Y134.12 E.01165
G1 X117.414 Y130.769 E.10325
G1 X117.792 Y130.769 E.01165
G1 X117.792 Y134.12 E.10325
G1 X118.17 Y134.12 E.01165
G1 X118.17 Y130.769 E.10325
G1 X118.548 Y130.769 E.01165
G1 X118.548 Y134.12 E.10325
G1 X118.926 Y134.12 E.01165
G1 X118.926 Y130.769 E.10325
G1 X119.304 Y130.769 E.01165
G1 X119.304 Y134.12 E.10325
G1 X119.682 Y134.12 E.01165
G1 X119.682 Y130.769 E.10325
G1 X120.06 Y130.769 E.01165
G1 X120.06 Y134.12 E.10325
G1 X120.438 Y134.12 E.01165
G1 X120.438 Y130.769 E.10325
G1 X120.817 Y130.769 E.01165
G1 X120.817 Y134.12 E.10325
G1 X121.195 Y134.12 E.01165
G1 X121.195 Y130.769 E.10325
G1 X121.573 Y130.769 E.01165
G1 X121.573 Y134.12 E.10325
M73 P79 R6
G1 X121.951 Y134.12 E.01165
G1 X121.951 Y130.769 E.10325
G1 X122.329 Y130.769 E.01165
G1 X122.329 Y134.12 E.10325
G1 X122.707 Y134.12 E.01165
G1 X122.707 Y130.769 E.10325
G1 X123.085 Y130.769 E.01165
G1 X123.085 Y134.12 E.10325
G1 X123.463 Y134.12 E.01165
G1 X123.463 Y130.769 E.10325
G1 X123.841 Y130.769 E.01165
G1 X123.841 Y134.12 E.10325
G1 X124.219 Y134.12 E.01165
G1 X124.219 Y130.769 E.10325
G1 X124.597 Y130.769 E.01165
G1 X124.597 Y134.12 E.10325
G1 X124.975 Y134.12 E.01165
G1 X124.975 Y130.769 E.10325
G1 X125.353 Y130.769 E.01165
G1 X125.353 Y134.12 E.10325
G1 X125.731 Y134.12 E.01165
G1 X125.731 Y131.051 E.09455
G2 X126.11 Y131.372 I2.226 J-2.234 E.01531
G1 X126.11 Y134.12 E.08465
G1 X126.488 Y134.12 E.01165
G1 X126.488 Y131.602 E.07758
G2 X126.866 Y131.776 I.905 J-1.462 E.01286
G1 X126.866 Y134.12 E.0722
G1 X127.244 Y134.12 E.01165
G1 X127.244 Y131.895 E.06855
G2 X127.622 Y131.956 I1.174 J-6.027 E.0118
G1 X127.622 Y134.12 E.06665
G1 X128 Y134.12 E.01165
G1 X128 Y131.983 E.06583
G2 X128.378 Y131.963 I.087 J-1.945 E.01168
G1 X128.378 Y134.12 E.06645
G1 X128.756 Y134.12 E.01165
G1 X128.756 Y131.892 E.06865
G2 X129.134 Y131.78 I-.273 J-1.622 E.01217
G1 X129.134 Y134.12 E.07209
G1 X129.512 Y134.12 E.01165
G1 X129.512 Y131.603 E.07753
G1 X129.89 Y131.373 E.01364
G1 X129.89 Y134.12 E.08464
G1 X130.268 Y134.12 E.01165
G1 X130.268 Y131.052 E.09453
G2 X130.528 Y130.769 I-1.041 J-1.218 E.01187
G1 X130.646 Y130.769 E.00363
G1 X130.646 Y134.12 E.10325
G1 X131.024 Y134.12 E.01165
G1 X131.024 Y130.769 E.10325
G1 X131.403 Y130.769 E.01165
G1 X131.403 Y134.12 E.10325
G1 X131.781 Y134.12 E.01165
G1 X131.781 Y130.769 E.10325
G1 X132.159 Y130.769 E.01165
G1 X132.159 Y134.12 E.10325
G1 X132.537 Y134.12 E.01165
G1 X132.537 Y130.769 E.10325
G1 X132.915 Y130.769 E.01165
G1 X132.915 Y134.12 E.10325
G1 X133.293 Y134.12 E.01165
G1 X133.293 Y130.769 E.10325
G1 X133.671 Y130.769 E.01165
G1 X133.671 Y134.12 E.10325
G1 X134.049 Y134.12 E.01165
G1 X134.049 Y130.769 E.10325
G1 X134.427 Y130.769 E.01165
G1 X134.427 Y134.12 E.10325
G1 X134.805 Y134.12 E.01165
G1 X134.805 Y130.769 E.10325
G1 X135.183 Y130.769 E.01165
G1 X135.183 Y134.12 E.10325
G1 X135.561 Y134.12 E.01165
G1 X135.561 Y130.769 E.10325
G1 X135.939 Y130.769 E.01165
G1 X135.939 Y134.12 E.10325
G1 X136.317 Y134.12 E.01165
G1 X136.317 Y130.769 E.10325
G1 X136.695 Y130.769 E.01165
G1 X136.695 Y134.12 E.10325
G1 X137.074 Y134.12 E.01165
G1 X137.074 Y130.769 E.10325
G1 X137.452 Y130.769 E.01165
G1 X137.452 Y134.12 E.10325
G1 X137.83 Y134.12 E.01165
G1 X137.83 Y130.769 E.10325
G1 X138.208 Y130.769 E.01165
G1 X138.208 Y134.12 E.10325
G1 X138.586 Y134.12 E.01165
G1 X138.586 Y130.769 E.10325
G1 X138.964 Y130.769 E.01165
G1 X138.964 Y134.12 E.10325
G1 X139.342 Y134.12 E.01165
G1 X139.342 Y130.769 E.10325
G1 X139.72 Y130.769 E.01165
G1 X139.72 Y134.12 E.10325
G1 X140.098 Y134.12 E.01165
G1 X140.098 Y130.769 E.10325
G1 X140.476 Y130.769 E.01165
G1 X140.476 Y134.12 E.10325
G1 X140.854 Y134.12 E.01165
G1 X140.854 Y130.769 E.10325
G1 X141.232 Y130.769 E.01165
G1 X141.232 Y134.12 E.10325
G1 X141.61 Y134.12 E.01165
G1 X141.61 Y130.769 E.10325
G1 X141.988 Y130.769 E.01165
G1 X141.988 Y134.12 E.10325
G1 X142.367 Y134.12 E.01165
G1 X142.367 Y130.769 E.10325
G1 X142.745 Y130.769 E.01165
G1 X142.745 Y134.12 E.10325
G1 X143.123 Y134.12 E.01165
G1 X143.123 Y130.769 E.10325
G1 X143.47 Y130.769 E.01069
G1 X143.501 Y130.802 E.0014
G1 X143.501 Y134.12 E.10222
G1 X143.879 Y134.12 E.01165
G1 X143.879 Y131.189 E.09029
G2 X144.257 Y131.474 I1.66 J-1.808 E.01461
G1 X144.257 Y134.12 E.08151
G1 X144.635 Y134.12 E.01165
G1 X144.635 Y131.679 E.07519
G2 X145.013 Y131.831 I1.924 J-4.234 E.01256
G1 X145.013 Y134.12 E.0705
G1 X145.391 Y134.12 E.01165
G1 X145.391 Y131.921 E.06773
G1 X145.769 Y131.978 E.01178
G1 X145.769 Y134.12 E.066
G1 X146.147 Y134.12 E.01165
G1 X146.147 Y131.978 E.06599
G2 X146.525 Y131.937 I-.134 J-2.964 E.01173
G1 X146.525 Y134.12 E.06727
G1 X146.903 Y134.12 E.01165
G1 X146.903 Y131.848 E.07
G2 X147.281 Y131.714 I-.252 J-1.317 E.0124
G1 X147.281 Y134.12 E.07411
G1 X147.66 Y134.12 E.01165
G1 X147.66 Y131.524 E.07998
G2 X148.038 Y131.262 I-1.199 J-2.134 E.01419
G1 X148.038 Y134.12 E.08804
G1 X148.416 Y134.12 E.01165
G1 X148.416 Y130.901 E.09917
G1 X148.523 Y130.769 E.00526
G1 X148.794 Y130.769 E.00833
G1 X148.794 Y134.12 E.10325
G1 X149.172 Y134.12 E.01165
G1 X149.172 Y130.769 E.10325
G1 X149.55 Y130.769 E.01165
G1 X149.55 Y134.12 E.10325
G1 X149.928 Y134.12 E.01165
G1 X149.928 Y130.769 E.10325
G1 X150.306 Y130.769 E.01165
G1 X150.306 Y134.12 E.10325
G1 X150.684 Y134.12 E.01165
G1 X150.684 Y130.769 E.10325
G1 X151.062 Y130.769 E.01165
G1 X151.062 Y134.12 E.10325
G1 X151.44 Y134.12 E.01165
G1 X151.44 Y130.769 E.10325
G1 X151.818 Y130.769 E.01165
G1 X151.818 Y134.12 E.10325
G1 X152.196 Y134.12 E.01165
G1 X152.196 Y130.769 E.10325
G1 X152.574 Y130.769 E.01165
G1 X152.574 Y134.12 E.10325
G1 X152.953 Y134.12 E.01165
G1 X152.953 Y130.769 E.10325
G1 X153.331 Y130.769 E.01165
G1 X153.331 Y134.12 E.10325
G1 X153.709 Y134.12 E.01165
G1 X153.709 Y130.769 E.10325
G1 X154.087 Y130.769 E.01165
G1 X154.087 Y134.12 E.10325
G1 X154.465 Y134.12 E.01165
G1 X154.465 Y130.769 E.10325
G1 X154.843 Y130.769 E.01165
G1 X154.843 Y134.12 E.10325
G1 X155.221 Y134.12 E.01165
G1 X155.221 Y130.769 E.10325
G1 X155.599 Y130.769 E.01165
G1 X155.599 Y134.12 E.10325
G1 X155.977 Y134.12 E.01165
G1 X155.977 Y130.769 E.10325
G1 X156.355 Y130.769 E.01165
G1 X156.355 Y134.12 E.10325
G1 X156.733 Y134.12 E.01165
G1 X156.733 Y130.769 E.10325
G1 X157.111 Y130.769 E.01165
G1 X157.111 Y134.12 E.10325
G1 X157.489 Y134.12 E.01165
G1 X157.489 Y130.769 E.10325
G1 X157.867 Y130.769 E.01165
G1 X157.867 Y134.12 E.10325
G1 X158.245 Y134.12 E.01165
G1 X158.245 Y130.769 E.10325
G1 X158.624 Y130.769 E.01165
G1 X158.624 Y134.12 E.10325
G1 X159.002 Y134.12 E.01165
G1 X159.002 Y130.769 E.10325
G1 X159.38 Y130.769 E.01165
G1 X159.38 Y134.12 E.10325
G1 X159.758 Y134.12 E.01165
G1 X159.758 Y130.769 E.10325
G1 X160.136 Y130.769 E.01165
G1 X160.136 Y134.12 E.10325
G1 X160.514 Y134.12 E.01165
G1 X160.514 Y130.769 E.10325
G1 X160.892 Y130.769 E.01165
G1 X160.892 Y134.12 E.10325
G1 X161.27 Y134.12 E.01165
G1 X161.27 Y130.769 E.10325
G1 X161.471 Y130.769 E.00618
G2 X161.648 Y130.961 I.746 J-.51 E.00809
G1 X161.648 Y134.12 E.09732
G1 X162.026 Y134.12 E.01165
G1 X162.026 Y131.297 E.08698
G2 X162.404 Y131.558 I.952 J-.974 E.01422
G1 X162.404 Y134.12 E.07894
G1 X162.782 Y134.12 E.01165
G1 X162.782 Y131.743 E.07322
G2 X163.16 Y131.874 I.727 J-1.486 E.01236
G1 X163.16 Y134.12 E.06918
G1 X163.538 Y134.12 E.01165
G1 X163.538 Y131.95 E.06684
G1 X163.695 Y131.97 E.00485
G2 X163.917 Y131.977 I.139 J-.926 E.00685
G1 X163.917 Y134.12 E.06603
G1 X164.295 Y134.12 E.01165
G1 X164.295 Y131.97 E.06623
G1 X164.401 Y131.957 E.0033
G2 X164.673 Y131.912 I-.102 J-1.461 E.0085
G1 X164.673 Y134.12 E.06802
G1 X165.051 Y134.12 E.01165
G1 X165.051 Y131.807 E.07127
G2 X165.429 Y131.647 I-.465 J-1.626 E.01268
G1 X165.429 Y134.12 E.07619
G1 X165.807 Y134.12 E.01165
G1 X165.807 Y131.424 E.08306
G2 X166.185 Y131.127 I-.791 J-1.396 E.01486
G1 X166.185 Y134.12 E.0922
G1 X166.563 Y134.12 E.01165
G1 X166.563 Y130.769 E.10325
G1 X166.941 Y130.769 E.01165
G1 X166.941 Y134.12 E.10325
G1 X167.319 Y134.12 E.01165
G1 X167.319 Y130.769 E.10325
G1 X167.697 Y130.769 E.01165
G1 X167.697 Y134.12 E.10325
G1 X168.075 Y134.12 E.01165
G1 X168.075 Y130.769 E.10325
G1 X168.453 Y130.769 E.01165
G1 X168.453 Y134.12 E.10325
G1 X168.831 Y134.12 E.01165
G1 X168.831 Y130.769 E.10325
M73 P79 R5
G1 X169.21 Y130.769 E.01165
G1 X169.21 Y134.12 E.10325
G1 X169.588 Y134.12 E.01165
G1 X169.588 Y130.769 E.10325
G1 X169.966 Y130.769 E.01165
G1 X169.966 Y134.12 E.10325
G1 X170.344 Y134.12 E.01165
G1 X170.344 Y130.769 E.10325
G1 X170.722 Y130.769 E.01165
G1 X170.722 Y134.12 E.10325
G1 X171.1 Y134.12 E.01165
G1 X171.1 Y130.769 E.10325
G1 X171.478 Y130.769 E.01165
G1 X171.478 Y134.12 E.10325
G1 X171.856 Y134.12 E.01165
G1 X171.856 Y130.769 E.10325
G1 X172.234 Y130.769 E.01165
G1 X172.234 Y134.12 E.10325
G1 X172.612 Y134.12 E.01165
G1 X172.612 Y130.769 E.10325
G1 X172.99 Y130.769 E.01165
G1 X172.99 Y134.12 E.10325
G1 X173.368 Y134.12 E.01165
G1 X173.368 Y130.769 E.10325
G1 X173.746 Y130.769 E.01165
G1 X173.746 Y134.12 E.10325
G1 X174.124 Y134.12 E.01165
G1 X174.124 Y130.769 E.10325
G1 X174.502 Y130.769 E.01165
G1 X174.502 Y134.12 E.10325
G1 X174.881 Y134.12 E.01165
G1 X174.881 Y130.769 E.10325
G1 X175.259 Y130.769 E.01165
G1 X175.259 Y134.12 E.10325
G1 X175.637 Y134.12 E.01165
G1 X175.637 Y130.769 E.10325
G1 X176.015 Y130.769 E.01165
G1 X176.015 Y134.12 E.10325
G1 X176.393 Y134.12 E.01165
G1 X176.393 Y130.769 E.10325
G1 X176.771 Y130.769 E.01165
G1 X176.771 Y134.12 E.10325
G1 X177.149 Y134.12 E.01165
G1 X177.149 Y130.769 E.10325
G1 X177.527 Y130.769 E.01165
G1 X177.527 Y134.12 E.10325
G1 X177.905 Y134.12 E.01165
G1 X177.905 Y130.769 E.10325
G1 X178.283 Y130.769 E.01165
G1 X178.283 Y134.12 E.10325
G1 X178.661 Y134.12 E.01165
G1 X178.661 Y130.769 E.10325
G1 X179.039 Y130.769 E.01165
G1 X179.039 Y134.12 E.10325
G1 X179.417 Y134.12 E.01165
G1 X179.417 Y130.769 E.10325
G1 X179.795 Y130.769 E.01165
G1 X179.795 Y134.12 E.10325
G1 X180.174 Y134.12 E.01165
G1 X180.174 Y130.769 E.10325
G1 X180.552 Y130.769 E.01165
G1 X180.552 Y134.12 E.10325
G1 X180.93 Y134.12 E.01165
G1 X180.93 Y130.769 E.10325
G1 X181.308 Y130.769 E.01165
G1 X181.308 Y134.12 E.10325
G1 X181.686 Y134.12 E.01165
G1 X181.686 Y130.769 E.10325
G1 X182.064 Y130.769 E.01165
G1 X182.064 Y134.29 E.10848
G1 X179.267 Y134.512 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.896 Y134.512 E.05401
G1 X179.773 Y135.635 E.05266
G1 X176.014 Y135.635 E.12468
G1 X174.892 Y134.512 E.05266
G1 X173.22 Y134.512 E.05547
G1 X172.097 Y135.635 E.05266
G1 X168.338 Y135.635 E.12468
G1 X167.216 Y134.512 E.05266
G1 X165.544 Y134.512 E.05547
G1 X164.421 Y135.635 E.05266
G1 X160.663 Y135.635 E.12468
G1 X159.54 Y134.512 E.05266
G1 X157.868 Y134.512 E.05547
G1 X156.745 Y135.635 E.05266
G1 X152.987 Y135.635 E.12468
G1 X151.864 Y134.512 E.05266
G1 X150.192 Y134.512 E.05547
G1 X149.069 Y135.635 E.05266
G1 X145.311 Y135.635 E.12468
G1 X144.188 Y134.512 E.05266
G1 X142.516 Y134.512 E.05547
G1 X141.393 Y135.635 E.05266
G1 X137.635 Y135.635 E.12468
G1 X136.512 Y134.512 E.05266
G1 X134.84 Y134.512 E.05547
G1 X133.717 Y135.635 E.05266
G1 X129.959 Y135.635 E.12468
G1 X128.836 Y134.512 E.05266
G1 X127.164 Y134.512 E.05547
G1 X126.041 Y135.635 E.05266
G1 X122.283 Y135.635 E.12468
G1 X121.16 Y134.512 E.05266
G1 X119.488 Y134.512 E.05547
G1 X118.365 Y135.635 E.05266
G1 X114.607 Y135.635 E.12468
G1 X113.484 Y134.512 E.05266
G1 X111.812 Y134.512 E.05547
G1 X110.689 Y135.635 E.05266
G1 X106.931 Y135.635 E.12468
G1 X105.808 Y134.512 E.05266
G1 X104.136 Y134.512 E.05547
G1 X103.013 Y135.635 E.05266
G1 X99.255 Y135.635 E.12468
G1 X98.132 Y134.512 E.05266
G1 X96.46 Y134.512 E.05547
G1 X95.337 Y135.635 E.05266
G1 X91.579 Y135.635 E.12468
G1 X90.456 Y134.512 E.05266
G1 X88.784 Y134.512 E.05547
G1 X87.661 Y135.635 E.05266
G1 X83.903 Y135.635 E.12468
G1 X82.78 Y134.512 E.05266
G1 X81.108 Y134.512 E.05547
G1 X79.986 Y135.635 E.05266
G1 X76.227 Y135.635 E.12468
G1 X75.104 Y134.512 E.05266
G1 X76.733 Y134.512 E.05401
G1 X74.07 Y136.632 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.57198
G1 F11907.912
G1 X181.93 Y136.632 E4.65002
G1 X181.93 Y136.103 E.02281
G1 X74.07 Y136.103 E4.65002
G1 X74.07 Y136.572 E.02022
; WIPE_START
G1 X74.07 Y136.103 E-.17824
G1 X75.601 Y136.103 E-.58176
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I.472 J1.122 P1  F30000
G1 X89.162 Y130.391 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X88.902 Y129.869 E.01793
G1 X88.821 Y129.576 E.00933
G1 X73.994 Y129.576 E.45556
G1 X73.994 Y130.391 E.02505
G1 X89.102 Y130.391 E.4642
G1 X74.402 Y129.984 F30000
; LINE_WIDTH: 0.48098
G1 F14381.592
G1 X88.449 Y129.984 E.50145
G1 X87.522 Y126.469 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.75 Y126.469 E.04071
G1 X88.75 Y126.871 E.01331
G1 X86.436 Y129.184 E.10854
G1 X85.129 Y129.184 E.04337
G1 X82.414 Y126.469 E.12736
G1 X81.475 Y126.469 E.03114
G1 X78.76 Y129.184 E.12736
G1 X77.453 Y129.184 E.04337
G1 X74.738 Y126.469 E.12736
G1 X73.95 Y126.469 E.02612
G1 X73.95 Y127.31 E.02789
G1 X88.706 Y124.713 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y123.348 E.04193
G1 X73.994 Y123.348 E.45204
G1 X73.994 Y126.077 E.08386
G1 X88.706 Y126.077 E.45204
G1 X88.706 Y124.773 E.04008
G1 X88.329 Y124.713 F30000
G1 F12000
G1 X88.329 Y123.725 E.03034
G1 X74.371 Y123.725 E.42887
G1 X74.371 Y125.7 E.06068
G1 X88.329 Y125.7 E.42887
G1 X88.329 Y124.773 E.0285
G1 X87.952 Y124.713 F30000
G1 F12000
G1 X87.952 Y124.102 E.01876
G1 X74.748 Y124.102 E.4057
G1 X74.748 Y125.323 E.03751
G1 X87.952 Y125.323 E.4057
G1 X87.952 Y124.773 E.01691
G1 X87.552 Y124.713 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X87.552 Y124.502 E.00725
G1 X75.148 Y124.502 E.42645
G1 X75.148 Y124.924 E.0145
G1 X87.552 Y124.924 E.42645
G1 X87.552 Y124.773 E.00519
; WIPE_START
G1 X87.552 Y124.924 E-.05736
G1 X85.703 Y124.924 E-.70264
; WIPE_END
G1 E-.04 F1800
G1 X93.181 Y126.451 Z4.6 F30000
G1 X106.563 Y129.184 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X106.786 Y129.184 E.00737
G3 X106.752 Y127.78 I5.814 J-.84 E.0467
G1 X105.442 Y126.469 E.06149
G1 X104.503 Y126.469 E.03114
G1 X101.788 Y129.184 E.12736
G1 X100.48 Y129.184 E.04337
G1 X97.766 Y126.469 E.12736
G1 X96.827 Y126.469 E.03114
G1 X95.25 Y128.046 E.07395
G3 X95.216 Y129.184 I-6.186 J.383 E.03783
G1 X95.704 Y129.184 E.01619
G1 X107.167 Y130.391 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X106.987 Y130.079 E.01108
G1 X106.826 Y129.576 E.01623
G1 X95.185 Y129.576 E.35768
G1 X94.93 Y130.254 E.02224
G1 X94.849 Y130.391 E.0049
G1 X107.107 Y130.391 E.37664
G1 X95.467 Y129.984 F30000
; LINE_WIDTH: 0.481
G1 F14380.934
G1 X106.468 Y129.984 E.39272
; WIPE_START
G1 X104.468 Y129.984 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I.069 J1.215 P1  F30000
M73 P80 R5
G1 X124.753 Y128.835 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G2 X124.786 Y129.184 I1.465 J.039 E.01166
G1 X123.508 Y129.184 E.04237
G1 X120.793 Y126.469 E.12736
G1 X119.855 Y126.469 E.03114
G1 X117.14 Y129.184 E.12736
G1 X115.832 Y129.184 E.04337
G1 X113.25 Y126.602 E.12113
G1 X113.25 Y126.469 E.00441
G1 X114.746 Y126.469 E.04961
G1 X124.819 Y129.576 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X113.169 Y129.576 E.35796
G1 X113.025 Y130.051 E.01524
G1 X112.828 Y130.391 E.01208
G1 X125.154 Y130.391 E.37871
G1 X124.895 Y129.852 E.01839
G1 X124.835 Y129.634 E.00694
G1 X113.475 Y129.984 F30000
; LINE_WIDTH: 0.48099
G1 F14381.263
G1 X124.449 Y129.984 E.39176
; WIPE_START
G1 X122.449 Y129.984 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z4.6 I-.011 J1.217 P1  F30000
G1 X166.838 Y130.391 Z4.6
G1 Z4.2
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F15000
G1 X182.006 Y130.391 E.46606
G1 X182.006 Y129.576 E.02505
G1 X167.17 Y129.576 E.45586
G1 X167 Y130.11 E.01722
G1 X166.868 Y130.339 E.00812
G1 X167.468 Y129.984 F30000
; LINE_WIDTH: 0.481
G1 F14380.934
G1 X181.538 Y129.984 E.50229
G1 X182.05 Y127.31 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.05 Y126.469 E.02789
G1 X181.262 Y126.469 E.02612
G1 X178.547 Y129.184 E.12736
G1 X177.24 Y129.184 E.04337
G1 X174.525 Y126.469 E.12736
G1 X173.586 Y126.469 E.03114
G1 X170.871 Y129.184 E.12736
G1 X169.564 Y129.184 E.04337
G1 X167.25 Y126.871 E.10854
G1 X167.25 Y126.469 E.01331
G1 X168.477 Y126.469 E.04071
G1 X182.006 Y124.713 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y123.348 E.04193
G1 X167.294 Y123.348 E.45204
G1 X167.294 Y126.077 E.08386
G1 X182.006 Y126.077 E.45204
G1 X182.006 Y124.773 E.04008
G1 X181.629 Y124.713 F30000
G1 F12000
G1 X181.629 Y123.725 E.03034
G1 X167.671 Y123.725 E.42887
G1 X167.671 Y125.7 E.06068
G1 X181.629 Y125.7 E.42887
G1 X181.629 Y124.773 E.0285
G1 X181.252 Y124.713 F30000
G1 F12000
G1 X181.252 Y124.102 E.01876
G1 X168.048 Y124.102 E.4057
G1 X168.048 Y125.323 E.03751
G1 X181.252 Y125.323 E.4057
G1 X181.252 Y124.773 E.01691
G1 X180.852 Y124.713 F30000
; LINE_WIDTH: 0.46481
G1 F12000
G1 X180.852 Y124.502 E.00725
G1 X168.448 Y124.502 E.42645
G1 X168.448 Y124.924 E.0145
G1 X180.852 Y124.924 E.42645
G1 X180.852 Y124.773 E.00519
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X180.852 Y124.924 E-.05736
G1 X179.003 Y124.924 E-.70264
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 22/33
; update layer progress
M73 L22
M991 S0 P21 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.6 I.404 J1.148 P1  F30000
G1 X182.398 Y123.728 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y137.007 E.4405
G1 X73.602 Y137.007 E3.60896
G1 X73.602 Y123.728 E.4405
G1 X89.098 Y123.728 E.51403
G1 X89.098 Y128.763 E.16702
G2 X94.902 Y128.757 I2.902 J-.014 E.30171
G1 X94.902 Y123.728 E.16683
G1 X107.098 Y123.728 E.40456
G1 X107.098 Y128.763 E.16702
G2 X112.902 Y128.757 I2.902 J-.016 E.30157
G1 X112.902 Y123.728 E.16683
G1 X125.098 Y123.728 E.40456
G1 X125.098 Y128.763 E.16702
G2 X130.902 Y128.757 I2.902 J-.015 E.30162
G1 X130.902 Y123.728 E.16684
G1 X143.098 Y123.728 E.40456
G1 X143.098 Y128.757 E.16683
G2 X148.902 Y128.757 I2.902 J-.014 E.3015
G1 X148.902 Y123.728 E.16684
G1 X161.098 Y123.728 E.40456
G1 X161.098 Y128.757 E.16683
G2 X166.902 Y128.757 I2.902 J-.014 E.3015
G1 X166.902 Y123.728 E.16684
G1 X182.338 Y123.728 E.51204
; WIPE_START
G1 X182.347 Y125.728 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y122.088 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y137.399 E.47045
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y137.399 E3.36709
G1 X73.21 Y122.088 E.47045
G1 X89.49 Y122.088 E.50024
G1 X89.49 Y128.754 E.20483
G2 X94.51 Y128.752 I2.51 J-.005 E.24202
G1 X94.51 Y122.088 E.20477
G1 X107.49 Y122.088 E.39884
G1 X107.49 Y128.754 E.20483
G2 X112.51 Y128.752 I2.51 J-.007 E.24191
G1 X112.51 Y122.088 E.20477
G1 X125.49 Y122.088 E.39884
G1 X125.49 Y128.754 E.20483
G2 X130.51 Y128.752 I2.51 J-.007 E.24195
G1 X130.51 Y122.088 E.20477
G1 X143.49 Y122.088 E.39884
G1 X143.49 Y128.752 E.20477
G2 X148.51 Y128.752 I2.51 J-.009 E.24176
G1 X148.51 Y122.088 E.20477
G1 X161.49 Y122.088 E.39884
G1 X161.49 Y128.752 E.20477
G2 X166.51 Y128.752 I2.51 J-.009 E.24176
G1 X166.51 Y122.088 E.20477
G1 X182.73 Y122.088 E.4984
M204 S10000
G1 X182.583 Y122.877 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.954 Y123.505 E.02731
G1 X181.421 Y123.505
G1 X182.583 Y122.343 E.05048
G1 X182.097 Y122.296
G1 X180.888 Y123.505 E.05255
G1 X180.354 Y123.505
G1 X181.564 Y122.296 E.05255
G1 X181.031 Y122.296
G1 X179.821 Y123.505 E.05255
G1 X179.288 Y123.505
G1 X180.497 Y122.296 E.05255
G1 X179.964 Y122.296
G1 X178.755 Y123.505 E.05255
G1 X178.221 Y123.505
G1 X179.431 Y122.296 E.05255
G1 X178.897 Y122.296
G1 X177.688 Y123.505 E.05255
G1 X177.155 Y123.505
G1 X178.364 Y122.296 E.05255
G1 X177.831 Y122.296
G1 X176.622 Y123.505 E.05255
G1 X176.088 Y123.505
G1 X177.298 Y122.296 E.05255
G1 X176.764 Y122.296
G1 X175.555 Y123.505 E.05255
G1 X175.022 Y123.505
G1 X176.231 Y122.296 E.05255
G1 X175.698 Y122.296
G1 X174.489 Y123.505 E.05255
G1 X173.955 Y123.505
G1 X175.165 Y122.296 E.05255
G1 X174.631 Y122.296
G1 X173.422 Y123.505 E.05255
G1 X172.889 Y123.505
G1 X174.098 Y122.296 E.05255
G1 X173.565 Y122.296
G1 X172.356 Y123.505 E.05255
G1 X171.822 Y123.505
G1 X173.032 Y122.296 E.05255
G1 X172.498 Y122.296
G1 X171.289 Y123.505 E.05255
G1 X170.756 Y123.505
G1 X171.965 Y122.296 E.05255
G1 X171.432 Y122.296
G1 X170.223 Y123.505 E.05255
G1 X169.689 Y123.505
G1 X170.899 Y122.296 E.05255
G1 X170.365 Y122.296
G1 X169.156 Y123.505 E.05255
G1 X168.623 Y123.505
G1 X169.832 Y122.296 E.05255
G1 X169.299 Y122.296
G1 X168.09 Y123.505 E.05255
G1 X167.556 Y123.505
G1 X168.766 Y122.296 E.05255
G1 X168.232 Y122.296
G1 X167.023 Y123.505 E.05255
G1 X166.717 Y123.277
G1 X167.699 Y122.296 E.04266
G1 X167.166 Y122.296
G1 X166.717 Y122.744 E.01949
; WIPE_START
M204 S10000
G1 X167.166 Y122.296 E-.24097
G1 X167.699 Y122.296 E-.20264
G1 X167.11 Y122.885 E-.31639
; WIPE_END
G1 E-.04 F1800
G1 X161.283 Y122.846 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X160.624 Y123.505 E.02863
G1 X160.091 Y123.505
G1 X161.283 Y122.313 E.0518
G1 X160.767 Y122.296
G1 X159.557 Y123.505 E.05255
G1 X159.024 Y123.505
G1 X160.233 Y122.296 E.05255
G1 X159.7 Y122.296
G1 X158.491 Y123.505 E.05255
G1 X157.958 Y123.505
G1 X159.167 Y122.296 E.05255
G1 X158.634 Y122.296
G1 X157.424 Y123.505 E.05255
G1 X156.891 Y123.505
G1 X158.1 Y122.296 E.05255
G1 X157.567 Y122.296
G1 X156.358 Y123.505 E.05255
G1 X155.825 Y123.505
G1 X157.034 Y122.296 E.05255
G1 X156.501 Y122.296
G1 X155.291 Y123.505 E.05255
G1 X154.758 Y123.505
G1 X155.967 Y122.296 E.05255
G1 X155.434 Y122.296
G1 X154.225 Y123.505 E.05255
G1 X153.692 Y123.505
G1 X154.901 Y122.296 E.05255
G1 X154.368 Y122.296
G1 X153.158 Y123.505 E.05255
G1 X152.625 Y123.505
G1 X153.834 Y122.296 E.05255
G1 X153.301 Y122.296
G1 X152.092 Y123.505 E.05255
G1 X151.559 Y123.505
G1 X152.768 Y122.296 E.05255
G1 X152.235 Y122.296
G1 X151.025 Y123.505 E.05255
G1 X150.492 Y123.505
G1 X151.701 Y122.296 E.05255
G1 X151.168 Y122.296
G1 X149.959 Y123.505 E.05255
G1 X149.425 Y123.505
G1 X150.635 Y122.296 E.05255
G1 X150.102 Y122.296
G1 X148.892 Y123.505 E.05255
G1 X148.717 Y123.147
G1 X149.568 Y122.296 E.03698
; WIPE_START
M204 S10000
G1 X148.717 Y123.147 E-.45728
G1 X148.892 Y123.505 E-.15154
G1 X149.174 Y123.224 E-.15118
; WIPE_END
G1 E-.04 F1800
G1 X149.294 Y124.12 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.706 Y124.12 E.35065
G1 X160.707 Y126.266 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.708 Y126.849 E.01791
G1 X149.294 Y126.849 E.3507
G1 X149.294 Y126.266 E.01791
; Slow Down End
G1 F12000
G1 X149.294 Y124.18 E.0641
G1 X149.671 Y124.497 F30000
G1 F12000
G1 X160.329 Y124.497 E.32749
G1 X160.33 Y126.266 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.331 Y126.472 E.00633
G1 X149.671 Y126.472 E.32752
G1 X149.671 Y126.266 E.00633
; Slow Down End
G1 F12000
G1 X149.671 Y124.557 E.05252
G1 X150.048 Y124.874 F30000
G1 F12000
G1 X150.048 Y126.095 E.03752
G1 X159.953 Y126.095 E.30434
G1 X159.952 Y124.874 E.03752
G1 X150.108 Y124.874 E.30248
G1 X150.448 Y125.273 F30000
; LINE_WIDTH: 0.464855
G1 F12000
G1 X150.448 Y125.695 E.01451
G1 X159.553 Y125.695 E.31308
G1 X159.553 Y125.273 E.01451
G1 X150.508 Y125.273 E.311
; WIPE_START
G1 X152.508 Y125.273 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X144.992 Y123.946 Z4.8 F30000
G1 X142.493 Y123.505 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X143.283 Y122.716 E.03431
G1 X143.169 Y122.296
G1 X141.96 Y123.505 E.05255
G1 X141.427 Y123.505
G1 X142.636 Y122.296 E.05255
G1 X142.103 Y122.296
G1 X140.893 Y123.505 E.05255
G1 X140.36 Y123.505
G1 X141.569 Y122.296 E.05255
G1 X141.036 Y122.296
G1 X139.827 Y123.505 E.05255
G1 X139.294 Y123.505
G1 X140.503 Y122.296 E.05255
G1 X139.97 Y122.296
G1 X138.76 Y123.505 E.05255
G1 X138.227 Y123.505
G1 X139.436 Y122.296 E.05255
G1 X138.903 Y122.296
G1 X137.694 Y123.505 E.05255
G1 X137.161 Y123.505
G1 X138.37 Y122.296 E.05255
G1 X137.837 Y122.296
G1 X136.627 Y123.505 E.05255
G1 X136.094 Y123.505
G1 X137.303 Y122.296 E.05255
G1 X136.77 Y122.296
G1 X135.561 Y123.505 E.05255
G1 X135.028 Y123.505
G1 X136.237 Y122.296 E.05255
G1 X135.704 Y122.296
G1 X134.494 Y123.505 E.05255
G1 X133.961 Y123.505
G1 X135.17 Y122.296 E.05255
G1 X134.637 Y122.296
G1 X133.428 Y123.505 E.05255
G1 X132.895 Y123.505
G1 X134.104 Y122.296 E.05255
G1 X133.571 Y122.296
G1 X132.361 Y123.505 E.05255
G1 X131.828 Y123.505
G1 X133.037 Y122.296 E.05255
G1 X132.504 Y122.296
G1 X131.295 Y123.505 E.05255
G1 X130.761 Y123.505
G1 X131.971 Y122.296 E.05255
G1 X131.438 Y122.296
G1 X130.717 Y123.016 E.03129
; WIPE_START
M204 S10000
G1 X131.438 Y122.296 E-.38701
G1 X131.971 Y122.296 E-.20264
G1 X131.654 Y122.613 E-.17036
; WIPE_END
G1 E-.04 F1800
G1 X131.294 Y124.12 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.706 Y124.12 E.35066
G1 X142.707 Y126.266 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.708 Y126.849 E.01791
G1 X131.292 Y126.849 E.35076
G1 X131.293 Y126.266 E.01791
; Slow Down End
G1 F12000
G1 X131.294 Y124.18 E.0641
G1 X131.671 Y124.497 F30000
G1 F12000
G1 X142.329 Y124.497 E.3275
G1 X142.33 Y126.266 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.331 Y126.472 E.00633
G1 X131.67 Y126.472 E.32758
G1 X131.67 Y126.266 E.00633
; Slow Down End
G1 F12000
G1 X131.671 Y124.557 E.05252
G1 X132.048 Y124.874 F30000
G1 F12000
G1 X132.047 Y126.095 E.03752
G1 X141.953 Y126.095 E.30439
G1 X141.952 Y124.874 E.03752
G1 X132.108 Y124.874 E.3025
G1 X132.447 Y125.273 F30000
; LINE_WIDTH: 0.464855
G1 F12000
G1 X132.447 Y125.695 E.01451
G1 X141.553 Y125.695 E.31312
G1 X141.553 Y125.273 E.01451
G1 X132.507 Y125.273 E.31104
; WIPE_START
G1 X134.507 Y125.273 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X127.075 Y123.537 Z4.8 F30000
G1 X125.283 Y123.118 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X124.896 Y123.505 E.01682
G1 X124.362 Y123.505
G1 X125.283 Y122.585 E.03999
G1 X125.038 Y122.296
G1 X123.829 Y123.505 E.05255
G1 X123.296 Y123.505
G1 X124.505 Y122.296 E.05255
G1 X123.972 Y122.296
G1 X122.763 Y123.505 E.05255
G1 X122.229 Y123.505
G1 X123.439 Y122.296 E.05255
G1 X122.905 Y122.296
G1 X121.696 Y123.505 E.05255
G1 X121.163 Y123.505
G1 X122.372 Y122.296 E.05255
G1 X121.839 Y122.296
G1 X120.63 Y123.505 E.05255
G1 X120.096 Y123.505
G1 X121.306 Y122.296 E.05255
G1 X120.772 Y122.296
G1 X119.563 Y123.505 E.05255
G1 X119.03 Y123.505
G1 X120.239 Y122.296 E.05255
G1 X119.706 Y122.296
G1 X118.497 Y123.505 E.05255
G1 X117.963 Y123.505
G1 X119.173 Y122.296 E.05255
G1 X118.639 Y122.296
G1 X117.43 Y123.505 E.05255
G1 X116.897 Y123.505
G1 X118.106 Y122.296 E.05255
G1 X117.573 Y122.296
G1 X116.364 Y123.505 E.05255
G1 X115.83 Y123.505
G1 X117.04 Y122.296 E.05255
G1 X116.506 Y122.296
G1 X115.297 Y123.505 E.05255
G1 X114.764 Y123.505
G1 X115.973 Y122.296 E.05255
G1 X115.44 Y122.296
G1 X114.23 Y123.505 E.05255
M73 P81 R5
G1 X113.697 Y123.505
G1 X114.907 Y122.296 E.05255
G1 X114.373 Y122.296
G1 X113.164 Y123.505 E.05255
G1 X112.717 Y123.418
G1 X113.84 Y122.296 E.04878
G1 X113.307 Y122.296
G1 X112.717 Y122.885 E.02561
; WIPE_START
M204 S10000
G1 X113.307 Y122.296 E-.31674
G1 X113.84 Y122.296 E-.20264
G1 X113.392 Y122.744 E-.24062
; WIPE_END
G1 E-.04 F1800
G1 X107.283 Y122.987 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X106.765 Y123.505 E.0225
G1 X106.232 Y123.505
G1 X107.283 Y122.454 E.04567
G1 X106.908 Y122.296
G1 X105.698 Y123.505 E.05255
G1 X105.165 Y123.505
G1 X106.374 Y122.296 E.05255
G1 X105.841 Y122.296
G1 X104.632 Y123.505 E.05255
G1 X104.099 Y123.505
G1 X105.308 Y122.296 E.05255
G1 X104.775 Y122.296
G1 X103.565 Y123.505 E.05255
G1 X103.032 Y123.505
G1 X104.241 Y122.296 E.05255
G1 X103.708 Y122.296
G1 X102.499 Y123.505 E.05255
G1 X101.966 Y123.505
G1 X103.175 Y122.296 E.05255
G1 X102.642 Y122.296
G1 X101.432 Y123.505 E.05255
G1 X100.899 Y123.505
G1 X102.108 Y122.296 E.05255
G1 X101.575 Y122.296
G1 X100.366 Y123.505 E.05255
G1 X99.833 Y123.505
G1 X101.042 Y122.296 E.05255
G1 X100.509 Y122.296
G1 X99.299 Y123.505 E.05255
G1 X98.766 Y123.505
G1 X99.975 Y122.296 E.05255
G1 X99.442 Y122.296
G1 X98.233 Y123.505 E.05255
G1 X97.7 Y123.505
G1 X98.909 Y122.296 E.05255
G1 X98.376 Y122.296
G1 X97.166 Y123.505 E.05255
G1 X96.633 Y123.505
G1 X97.842 Y122.296 E.05255
G1 X97.309 Y122.296
G1 X96.1 Y123.505 E.05255
G1 X95.566 Y123.505
G1 X96.776 Y122.296 E.05255
G1 X96.243 Y122.296
G1 X95.033 Y123.505 E.05255
G1 X94.717 Y123.288
G1 X95.709 Y122.296 E.0431
G1 X95.176 Y122.296
G1 X94.717 Y122.754 E.01993
; WIPE_START
M204 S10000
G1 X95.176 Y122.296 E-.24647
G1 X95.709 Y122.296 E-.20264
G1 X95.131 Y122.874 E-.31089
; WIPE_END
G1 E-.04 F1800
G1 X89.283 Y122.857 Z4.8 F30000
G1 Z4.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X88.634 Y123.505 E.02818
G1 X88.101 Y123.505
G1 X89.283 Y122.323 E.05135
G1 X88.777 Y122.296
G1 X87.568 Y123.505 E.05255
G1 X87.034 Y123.505
G1 X88.244 Y122.296 E.05255
G1 X87.71 Y122.296
G1 X86.501 Y123.505 E.05255
G1 X85.968 Y123.505
G1 X87.177 Y122.296 E.05255
G1 X86.644 Y122.296
G1 X85.435 Y123.505 E.05255
G1 X84.901 Y123.505
G1 X86.111 Y122.296 E.05255
G1 X85.577 Y122.296
G1 X84.368 Y123.505 E.05255
G1 X83.835 Y123.505
G1 X85.044 Y122.296 E.05255
G1 X84.511 Y122.296
G1 X83.302 Y123.505 E.05255
G1 X82.768 Y123.505
G1 X83.978 Y122.296 E.05255
G1 X83.444 Y122.296
G1 X82.235 Y123.505 E.05255
G1 X81.702 Y123.505
G1 X82.911 Y122.296 E.05255
G1 X82.378 Y122.296
G1 X81.169 Y123.505 E.05255
G1 X80.635 Y123.505
G1 X81.845 Y122.296 E.05255
G1 X81.311 Y122.296
G1 X80.102 Y123.505 E.05255
G1 X79.569 Y123.505
G1 X80.778 Y122.296 E.05255
G1 X80.245 Y122.296
G1 X79.035 Y123.505 E.05255
G1 X78.502 Y123.505
G1 X79.712 Y122.296 E.05255
G1 X79.178 Y122.296
G1 X77.969 Y123.505 E.05255
G1 X77.436 Y123.505
G1 X78.645 Y122.296 E.05255
G1 X78.112 Y122.296
G1 X76.902 Y123.505 E.05255
G1 X76.369 Y123.505
G1 X77.579 Y122.296 E.05255
G1 X77.045 Y122.296
G1 X75.836 Y123.505 E.05255
G1 X75.303 Y123.505
G1 X76.512 Y122.296 E.05255
G1 X75.979 Y122.296
G1 X74.769 Y123.505 E.05255
G1 X74.236 Y123.505
G1 X75.445 Y122.296 E.05255
G1 X74.912 Y122.296
G1 X73.703 Y123.505 E.05255
G1 X73.417 Y123.257
G1 X74.379 Y122.296 E.04179
G1 X73.846 Y122.296
G1 X73.417 Y122.724 E.01861
; WIPE_START
M204 S10000
G1 X73.846 Y122.296 E-.23019
G1 X74.379 Y122.296 E-.20264
G1 X73.77 Y122.905 E-.32718
; WIPE_END
G1 E-.04 F1800
G1 X75.445 Y130.351 Z4.8 F30000
G1 X76.278 Y134.058 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X74.65 Y134.058 E.05401
G1 X75.772 Y135.18 E.05266
G1 X80.44 Y135.18 E.15483
G1 X81.563 Y134.058 E.05266
G1 X82.326 Y134.058 E.02531
G1 X83.448 Y135.18 E.05266
G1 X88.116 Y135.18 E.15483
G1 X89.239 Y134.058 E.05266
G1 X90.002 Y134.058 E.02531
G1 X91.124 Y135.18 E.05266
G1 X95.792 Y135.18 E.15483
G1 X96.915 Y134.058 E.05266
G1 X97.678 Y134.058 E.02531
G1 X98.8 Y135.18 E.05266
G1 X103.468 Y135.18 E.15483
G1 X104.591 Y134.058 E.05266
G1 X105.354 Y134.058 E.02531
G1 X106.476 Y135.18 E.05266
G1 X111.144 Y135.18 E.15483
G1 X112.267 Y134.058 E.05266
G1 X113.03 Y134.058 E.02531
G1 X114.152 Y135.18 E.05266
G1 X118.82 Y135.18 E.15483
G1 X119.942 Y134.058 E.05266
G1 X120.706 Y134.058 E.02531
G1 X121.828 Y135.18 E.05266
G1 X126.496 Y135.18 E.15483
G1 X127.618 Y134.058 E.05266
G1 X128.382 Y134.058 E.02531
G1 X129.504 Y135.18 E.05266
G1 X134.172 Y135.18 E.15483
G1 X135.294 Y134.058 E.05266
G1 X136.058 Y134.058 E.02531
G1 X137.18 Y135.18 E.05266
G1 X141.848 Y135.18 E.15483
G1 X142.97 Y134.058 E.05266
G1 X143.733 Y134.058 E.02531
G1 X144.856 Y135.18 E.05266
G1 X149.524 Y135.18 E.15483
G1 X150.646 Y134.058 E.05266
G1 X151.409 Y134.058 E.02531
G1 X152.532 Y135.18 E.05266
G1 X157.2 Y135.18 E.15483
G1 X158.322 Y134.058 E.05266
G1 X159.085 Y134.058 E.02531
G1 X160.208 Y135.18 E.05266
G1 X164.876 Y135.18 E.15483
G1 X165.998 Y134.058 E.05266
G1 X166.761 Y134.058 E.02531
G1 X167.884 Y135.18 E.05266
G1 X172.552 Y135.18 E.15483
G1 X173.674 Y134.058 E.05266
G1 X174.437 Y134.058 E.02531
G1 X175.56 Y135.18 E.05266
G1 X180.228 Y135.18 E.15483
G1 X181.35 Y134.058 E.05266
G1 X179.722 Y134.058 E.05401
G1 X182.05 Y127.31 F30000
G1 F15476.087
G1 X182.05 Y127.241 E.0023
G1 X180.491 Y127.241 E.05171
G1 X177.297 Y130.434 E.14981
G1 X178.49 Y130.434 E.03956
G1 X175.297 Y127.241 E.14981
G1 X172.815 Y127.241 E.08232
G1 X169.622 Y130.434 E.1498
G1 X170.814 Y130.434 E.03955
G1 X167.621 Y127.241 E.1498
G1 X167.25 Y127.241 E.01228
G1 X167.25 Y128.499 E.04173
G1 X166.462 Y132.484 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.519951
G1 F13206.704
G1 X180.825 Y132.484 E.5583
G1 X180.825 Y132.007 E.01854
G1 X167.054 Y132.007 E.5353
G1 X166.509 Y132.447 E.02721
G1 X164.424 Y132.836 F30000
; LINE_WIDTH: 0.527007
G1 F13014.198
G1 X164.674 Y132.861 E.00992
; LINE_WIDTH: 0.4842
G1 F14276.65
G1 X164.925 Y132.886 E.00904
; LINE_WIDTH: 0.420149
G1 F15000
G1 X165.175 Y132.911 E.00773
G1 X181.252 Y132.911 E.4942
G1 X181.252 Y131.58 E.04092
G1 X166.87 Y131.58 E.4421
G1 X166.561 Y131.884 E.01332
G1 X166.041 Y132.241 E.01937
G1 X165.362 Y132.557 E.02303
; LINE_WIDTH: 0.441394
G1 X165.069 Y132.644 E.00994
; LINE_WIDTH: 0.4842
G1 F14276.65
G1 X164.775 Y132.732 E.01101
; LINE_WIDTH: 0.527007
G1 F13014.198
G1 X164.482 Y132.819 E.01208
G1 X163.536 Y132.839 F30000
; LINE_WIDTH: 0.551701
G1 F12382.539
G2 X164.344 Y132.846 I.46 J-6.85 E.0335
G1 X148.462 Y132.484 F30000
; LINE_WIDTH: 0.519925
G1 F13207.424
G1 X161.542 Y132.484 E.50839
G3 X160.934 Y132.007 I2.648 J-3.995 E.03004
G1 X149.054 Y132.007 E.4618
G1 X148.509 Y132.447 E.02721
G1 X146.424 Y132.836 F30000
; LINE_WIDTH: 0.527007
G1 F13014.198
G1 X146.674 Y132.861 E.00992
; LINE_WIDTH: 0.4842
G1 F14276.65
G1 X146.925 Y132.886 E.00904
; LINE_WIDTH: 0.420329
G1 F15000
G1 X147.175 Y132.911 E.00773
G1 X162.822 Y132.911 E.48121
; LINE_WIDTH: 0.443985
G1 X163.06 Y132.887 E.00782
; LINE_WIDTH: 0.491975
G1 F14029.461
G1 X163.298 Y132.863 E.00875
; LINE_WIDTH: 0.539965
G1 F12674.91
G1 X163.536 Y132.839 E.00969
G1 X163.308 Y132.769 E.00969
; LINE_WIDTH: 0.491975
G1 F14029.461
G1 X163.079 Y132.698 E.00875
; LINE_WIDTH: 0.420342
G1 F15000
G1 X162.851 Y132.627 E.00736
G1 X161.955 Y132.239 E.03001
G1 X161.31 Y131.772 E.0245
G1 X161.116 Y131.58 E.00837
G1 X148.87 Y131.58 E.37665
G1 X148.561 Y131.884 E.01332
G1 X148.041 Y132.241 E.01938
G1 X147.362 Y132.557 E.02304
; LINE_WIDTH: 0.441394
G1 X147.069 Y132.644 E.00994
; LINE_WIDTH: 0.4842
G1 F14276.65
G1 X146.775 Y132.732 E.01101
; LINE_WIDTH: 0.527007
G1 F13014.198
G1 X146.482 Y132.819 E.01208
G1 X145.536 Y132.839 F30000
; LINE_WIDTH: 0.551701
G1 F12382.539
G2 X146.344 Y132.846 I.46 J-6.85 E.0335
G1 X131.044 Y132.007 F30000
; LINE_WIDTH: 0.519925
G1 F13207.422
G1 X130.452 Y132.484 E.02955
G1 X143.542 Y132.484 E.50878
G3 X142.934 Y132.007 I2.648 J-3.995 E.03004
G1 X131.104 Y132.007 E.45985
G1 X130.883 Y131.58 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X130.39 Y132.012 E.02015
G1 X129.546 Y132.487 E.02976
; LINE_WIDTH: 0.442919
G1 X129.336 Y132.578 E.00745
; LINE_WIDTH: 0.488775
G1 F14130.154
G1 X129.127 Y132.67 E.00831
; LINE_WIDTH: 0.534632
G1 F12812.386
G1 X128.917 Y132.762 E.00916
; LINE_WIDTH: 0.57159
G1 F11916.697
G1 X128.865 Y132.788 E.00251
; LINE_WIDTH: 0.59965
G1 F11316.079
G1 X128.813 Y132.815 E.00264
; LINE_WIDTH: 0.589469
G1 F11526.878
G1 X128.965 Y132.839 E.00684
; LINE_WIDTH: 0.541047
G1 F12647.396
G1 X129.117 Y132.863 E.00624
; LINE_WIDTH: 0.492624
G1 F14009.223
G1 X129.269 Y132.887 E.00563
; LINE_WIDTH: 0.420229
G1 F15000
G1 X129.42 Y132.911 E.00472
G1 X144.822 Y132.911 E.47354
; LINE_WIDTH: 0.443985
G1 X145.06 Y132.887 E.00782
; LINE_WIDTH: 0.491975
G1 F14029.461
G1 X145.298 Y132.863 E.00875
; LINE_WIDTH: 0.539965
G1 F12674.91
G1 X145.536 Y132.839 E.00969
G1 X145.308 Y132.769 E.00969
; LINE_WIDTH: 0.491975
G1 F14029.461
G1 X145.079 Y132.698 E.00875
; LINE_WIDTH: 0.420387
G1 F15000
G1 X144.851 Y132.627 E.00736
G1 X143.955 Y132.239 E.03002
G1 X143.31 Y131.772 E.0245
G1 X143.116 Y131.58 E.00837
G1 X130.943 Y131.58 E.37443
G1 X127.022 Y132.794 F30000
; LINE_WIDTH: 0.636217
G1 F10618.634
G1 X127.26 Y132.812 E.01154
; LINE_WIDTH: 0.60029
G1 F11303.084
G1 X127.498 Y132.83 E.01084
; LINE_WIDTH: 0.57216
G1 F11903.861
G1 X127.736 Y132.848 E.01029
G1 X128.721 Y132.821 E.04247
; LINE_WIDTH: 0.60769
G1 F11154.984
G1 X128.754 Y132.818 E.00151
G1 X124.935 Y132.007 F30000
; LINE_WIDTH: 0.519925
G1 F13207.421
G1 X113.054 Y132.007 E.46181
G3 X112.456 Y132.484 I-2.321 J-2.296 E.0298
G1 X125.542 Y132.484 E.50864
G3 X124.98 Y132.048 I2.351 J-3.607 E.02771
G1 X125.116 Y131.58 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X112.87 Y131.58 E.3763
G1 X112.557 Y131.887 E.01347
G1 X112.033 Y132.249 E.01956
G3 X110.955 Y132.683 I-2.039 J-3.512 E.03583
; LINE_WIDTH: 0.444135
G1 X110.824 Y132.734 E.00459
; LINE_WIDTH: 0.492425
G1 F14015.416
G1 X110.693 Y132.784 E.00514
; LINE_WIDTH: 0.540715
G1 F12655.813
G1 X110.562 Y132.835 E.0057
G1 X110.75 Y132.86 E.00767
; LINE_WIDTH: 0.492425
G1 F14015.416
G1 X110.937 Y132.886 E.00692
; LINE_WIDTH: 0.420286
G1 F15000
G1 X111.124 Y132.911 E.00581
G1 X126.369 Y132.911 E.46879
; LINE_WIDTH: 0.443409
G1 X126.5 Y132.888 E.00433
; LINE_WIDTH: 0.490247
G1 F14083.657
G1 X126.63 Y132.865 E.00484
; LINE_WIDTH: 0.537085
G1 F12748.778
G1 X126.761 Y132.841 E.00534
; LINE_WIDTH: 0.583923
G1 F11645.038
G1 X126.892 Y132.818 E.00585
; LINE_WIDTH: 0.630761
G1 F10717.184
G1 X127.022 Y132.794 E.00636
G1 X126.906 Y132.732 E.0063
; LINE_WIDTH: 0.583923
G1 F11645.038
G1 X126.79 Y132.671 E.0058
; LINE_WIDTH: 0.537085
G1 F12748.778
G1 X126.674 Y132.609 E.00529
; LINE_WIDTH: 0.490247
G1 F14083.657
G1 X126.558 Y132.547 E.00479
; LINE_WIDTH: 0.421816
G1 F15000
G2 X125.884 Y132.199 I-11.68 J21.792 E.02344
G1 X125.303 Y131.766 E.02236
G1 X125.159 Y131.623 E.00627
G1 X125.285 Y131.203 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X112.707 Y131.203 E.38648
G1 X112.337 Y131.581 E.01624
G3 X109.84 Y132.415 I-2.376 J-2.957 E.0826
G1 X109.106 Y132.308 E.02282
G1 X108.277 Y131.988 E.02729
G1 X107.671 Y131.585 E.02236
G1 X107.301 Y131.203 E.01634
G1 X94.705 Y131.203 E.38702
G1 X94.291 Y131.617 E.01798
G1 X93.823 Y131.935 E.01739
G1 X93.022 Y132.273 E.02671
G1 X92.149 Y132.415 E.02718
G1 X91.266 Y132.344 E.0272
G1 X90.424 Y132.063 E.02728
G1 X89.815 Y131.699 E.0218
G1 X89.43 Y131.369 E.01558
G1 X89.283 Y131.203 E.00682
G1 X74.371 Y131.203 E.45818
G1 X74.371 Y133.288 E.06407
G1 X181.629 Y133.288 E3.29564
G1 X181.629 Y131.203 E.06407
G1 X166.707 Y131.203 E.45849
G1 X166.339 Y131.579 E.01617
G1 X165.882 Y131.899 E.01713
G1 X165.203 Y132.215 E.02302
G1 X164.339 Y132.403 E.02718
G1 X163.734 Y132.411 E.01858
G1 X162.925 Y132.258 E.02528
G1 X162.114 Y131.897 E.02727
G1 X161.539 Y131.473 E.02196
G1 X161.285 Y131.203 E.01138
G1 X148.707 Y131.203 E.38649
G1 X148.339 Y131.579 E.01617
G1 X147.882 Y131.899 E.01713
G1 X147.203 Y132.215 E.02302
G1 X146.339 Y132.403 E.02718
G1 X145.734 Y132.411 E.01858
G1 X144.925 Y132.258 E.02528
G1 X144.114 Y131.897 E.02727
G1 X143.539 Y131.473 E.02196
G1 X143.285 Y131.203 E.01138
G1 X130.729 Y131.203 E.38579
G1 X130.142 Y131.729 E.02423
G1 X129.37 Y132.153 E.02707
G1 X128.792 Y132.334 E.01859
G1 X127.935 Y132.417 E.02646
G1 X127.097 Y132.306 E.02599
G3 X125.326 Y131.247 I.846 J-3.423 E.06432
G1 X125.454 Y130.826 F30000
G1 F15000
G1 X112.544 Y130.826 E.39667
G1 X112.142 Y131.253 E.01802
G3 X109.895 Y132.042 I-2.184 J-2.625 E.07475
G1 X109.16 Y131.935 E.02282
G1 X108.419 Y131.639 E.02452
G1 X107.885 Y131.275 E.01984
G1 X107.466 Y130.826 E.01887
G1 X94.544 Y130.826 E.39705
G1 X94.108 Y131.28 E.01933
G1 X93.611 Y131.623 E.01858
G1 X92.88 Y131.924 E.02426
G1 X92.095 Y132.042 E.0244
G1 X91.304 Y131.969 E.02442
G1 X90.55 Y131.707 E.0245
G1 X90.015 Y131.379 E.01931
G3 X89.452 Y130.826 I1.721 J-2.314 E.0243
G1 X73.994 Y130.826 E.47498
G1 X73.994 Y133.666 E.08724
G1 X182.006 Y133.666 E3.31881
G1 X182.006 Y130.826 E.08724
G1 X166.544 Y130.826 E.47508
G1 X166.141 Y131.254 E.01807
G1 X165.723 Y131.557 E.01587
G1 X165.044 Y131.874 E.02302
G1 X164.265 Y132.033 E.02441
G1 X163.736 Y132.033 E.01626
G1 X163 Y131.888 E.02305
G1 X162.274 Y131.555 E.02455
G1 X161.769 Y131.174 E.01945
G1 X161.454 Y130.826 E.01441
G1 X148.544 Y130.826 E.39667
G1 X148.141 Y131.254 E.01807
G1 X147.723 Y131.557 E.01586
G1 X147.044 Y131.874 E.02302
G1 X146.265 Y132.033 E.02441
G1 X145.736 Y132.033 E.01626
G1 X145 Y131.888 E.02305
G1 X144.274 Y131.555 E.02455
G1 X143.769 Y131.174 E.01945
G1 X143.454 Y130.826 E.01441
G1 X130.548 Y130.826 E.39654
G3 X129.857 Y131.47 I-4.35 J-3.978 E.02906
G1 X129.194 Y131.82 E.02304
G1 X128.687 Y131.972 E.01627
G1 X127.903 Y132.042 E.02417
G1 X127.153 Y131.933 E.02329
G3 X125.494 Y130.871 I.811 J-3.093 E.06153
G1 X109.034 Y132.795 F30000
; LINE_WIDTH: 0.628691
G1 F10755.056
G1 X108.854 Y132.704 E.00964
; LINE_WIDTH: 0.582313
G1 F11679.795
G1 X108.674 Y132.612 E.00887
; LINE_WIDTH: 0.535935
G1 F12778.516
G1 X108.495 Y132.521 E.00811
; LINE_WIDTH: 0.489557
G1 F14105.415
G1 X108.315 Y132.429 E.00735
; LINE_WIDTH: 0.420307
G1 F15000
G1 X108.135 Y132.338 E.00621
G1 X107.456 Y131.895 E.02491
G1 X107.135 Y131.58 E.01383
G1 X94.865 Y131.58 E.37732
G1 X94.503 Y131.928 E.01545
G1 X94.035 Y132.247 E.0174
; LINE_WIDTH: 0.436804
G1 X93.751 Y132.388 E.01018
; LINE_WIDTH: 0.47043
G1 F14736.496
G1 X93.467 Y132.529 E.01105
; LINE_WIDTH: 0.504057
G1 F13661.892
G1 X93.182 Y132.669 E.01192
; LINE_WIDTH: 0.543369
G1 F12588.714
G1 X93.119 Y132.711 E.00308
; LINE_WIDTH: 0.588365
G1 F11550.203
G1 X93.056 Y132.752 E.00335
; LINE_WIDTH: 0.633362
G1 F10669.979
G1 X92.993 Y132.793 E.00363
G1 X93.068 Y132.816 E.00379
; LINE_WIDTH: 0.588365
G1 F11550.203
G1 X93.144 Y132.838 E.0035
; LINE_WIDTH: 0.543369
G1 F12588.714
G1 X93.22 Y132.861 E.00322
; LINE_WIDTH: 0.504057
G1 F13661.892
G1 X93.469 Y132.878 E.00941
; LINE_WIDTH: 0.47043
G1 F14736.496
G1 X93.719 Y132.895 E.00872
; LINE_WIDTH: 0.420285
G1 F15000
G1 X93.969 Y132.911 E.0077
G1 X108.022 Y132.911 E.43215
; LINE_WIDTH: 0.440118
G1 X108.399 Y132.891 E.0122
; LINE_WIDTH: 0.480373
G1 F14401.564
G1 X108.775 Y132.871 E.01344
; LINE_WIDTH: 0.519423
G1 F13221.337
G1 X108.826 Y132.856 E.00204
; LINE_WIDTH: 0.557268
G1 F12248.529
G1 X108.876 Y132.842 E.0022
; LINE_WIDTH: 0.595113
G1 F11409.064
G1 X108.926 Y132.827 E.00236
; LINE_WIDTH: 0.632958
G1 F10677.288
G1 X108.977 Y132.812 E.00252
G1 X109.034 Y132.795 F30000
; LINE_WIDTH: 0.633884
G1 F10660.561
G1 X109.282 Y132.813 E.01195
; LINE_WIDTH: 0.59789
G1 F11351.966
G1 X109.529 Y132.831 E.01122
; LINE_WIDTH: 0.553968
G1 F12327.626
G2 X110.488 Y132.84 I.573 J-10.956 E.03995
G1 X107.557 Y132.484 F30000
; LINE_WIDTH: 0.519925
G1 F13207.421
G1 X107.014 Y132.079 E.02633
G2 X106.844 Y132.007 I-.119 J.044 E.00805
G1 X95.047 Y132.007 E.45854
G3 X94.445 Y132.484 I-2.048 J-1.967 E.02996
G1 X107.497 Y132.484 E.50733
G1 X91.22 Y132.815 F30000
; LINE_WIDTH: 0.593885
G1 F11434.483
G1 X91.594 Y132.834 E.01685
; LINE_WIDTH: 0.556735
G1 F12261.223
G1 X91.969 Y132.852 E.01571
; LINE_WIDTH: 0.55691
G1 F12257.049
G1 X92.291 Y132.834 E.01348
; LINE_WIDTH: 0.59441
G1 F11423.598
G1 X92.612 Y132.816 E.01446
; LINE_WIDTH: 0.63191
G1 F10696.277
G1 X92.933 Y132.798 E.01544
G1 X91.22 Y132.815 F30000
; LINE_WIDTH: 0.588402
G1 F11549.434
G1 X90.989 Y132.716 E.01115
; LINE_WIDTH: 0.540284
G1 F12666.786
G1 X90.759 Y132.617 E.01017
; LINE_WIDTH: 0.492167
G1 F14023.491
G1 X90.529 Y132.517 E.00918
; LINE_WIDTH: 0.420174
G1 F15000
G1 X90.298 Y132.418 E.00771
G1 X89.616 Y132.019 E.02431
G1 X89.148 Y131.619 E.01891
G1 X89.061 Y131.58 E.00293
G1 X74.748 Y131.58 E.43999
G1 X74.748 Y132.911 E.04092
G1 X90.213 Y132.911 E.47541
; LINE_WIDTH: 0.437325
G1 X90.589 Y132.894 E.0121
; LINE_WIDTH: 0.471995
G1 F14682.748
G1 X90.965 Y132.877 E.01316
; LINE_WIDTH: 0.509852
G1 F13492.338
G1 X91.031 Y132.861 E.00256
; LINE_WIDTH: 0.550895
G1 F12402.186
G1 X91.096 Y132.845 E.00278
; LINE_WIDTH: 0.591939
G1 F11475.027
G1 X91.161 Y132.829 E.00301
G1 X89.556 Y132.484 F30000
; LINE_WIDTH: 0.51991
G1 F13207.825
G1 X88.998 Y132.065 E.02714
G1 X88.891 Y132.007 E.00471
G1 X75.175 Y132.007 E.53311
G1 X75.175 Y132.484 E.01854
G1 X89.496 Y132.484 E.55662
G1 X88.75 Y128.499 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X88.75 Y127.241 E.04173
G1 X88.379 Y127.241 E.01228
G1 X85.186 Y130.434 E.14981
G1 X86.379 Y130.434 E.03956
G1 X83.185 Y127.241 E.14981
G1 X80.703 Y127.241 E.08232
G1 X77.51 Y130.434 E.14981
G1 X78.703 Y130.434 E.03956
G1 X75.509 Y127.241 E.14981
G1 X73.95 Y127.241 E.05171
G1 X73.95 Y127.31 E.00231
G1 X73.994 Y136.615 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y136.615 E3.31882
G1 X182.006 Y135.572 E.03204
G1 X73.994 Y135.572 E3.31882
G1 X73.994 Y136.555 E.0302
G1 X74.349 Y136.26 F30000
; LINE_WIDTH: 0.37574
G1 F12000
G1 X181.651 Y136.26 E2.91009
G1 X181.651 Y135.927 E.00903
G1 X74.349 Y135.927 E2.91009
G1 X74.349 Y136.2 E.0074
G1 X88.706 Y125.484 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y124.12 E.04193
G1 X73.994 Y124.12 E.45204
G1 X73.994 Y126.849 E.08386
G1 X88.706 Y126.849 E.45204
G1 X88.706 Y125.544 E.04009
G1 X88.329 Y125.484 F30000
G1 F12000
G1 X88.329 Y124.497 E.03034
G1 X74.371 Y124.497 E.42887
G1 X74.371 Y126.472 E.06069
G1 X88.329 Y126.472 E.42887
G1 X88.329 Y125.544 E.0285
G1 X87.952 Y125.484 F30000
G1 F12000
G1 X87.952 Y124.874 E.01876
G1 X74.748 Y124.874 E.4057
G1 X74.748 Y126.095 E.03752
G1 X87.952 Y126.095 E.4057
G1 X87.952 Y125.544 E.01691
G1 X87.552 Y125.484 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X87.552 Y125.273 E.00725
G1 X75.148 Y125.273 E.4265
G1 X75.148 Y125.695 E.01451
G1 X87.552 Y125.695 E.4265
G1 X87.552 Y125.544 E.00519
; WIPE_START
G1 X87.552 Y125.695 E-.05737
G1 X85.703 Y125.695 E-.70263
; WIPE_END
G1 E-.04 F1800
G1 X93.335 Y125.619 Z4.8 F30000
G1 X106.706 Y125.484 Z4.8
G1 Z4.4
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.706 Y124.12 E.04193
G1 X95.294 Y124.12 E.35064
G1 X95.294 Y126.849 E.08386
G1 X106.706 Y126.849 E.35064
G1 X106.706 Y125.544 E.04009
G1 X106.329 Y125.484 F30000
G1 F12000
G1 X106.329 Y124.497 E.03034
G1 X95.671 Y124.497 E.32747
G1 X95.671 Y126.472 E.06069
G1 X106.329 Y126.472 E.32747
G1 X106.329 Y125.544 E.0285
G1 X105.952 Y125.484 F30000
G1 F12000
G1 X105.952 Y124.874 E.01876
G1 X96.048 Y124.874 E.3043
G1 X96.048 Y126.095 E.03752
G1 X105.952 Y126.095 E.3043
G1 X105.952 Y125.544 E.01691
G1 X105.552 Y125.484 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X105.552 Y125.273 E.00725
G1 X96.448 Y125.273 E.31304
G1 X96.448 Y125.695 E.01451
G1 X105.552 Y125.695 E.31304
G1 X105.552 Y125.544 E.00519
G1 X106.817 Y129.401 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X106.75 Y127.778 I7.108 J-1.11 E.05403
G1 X106.213 Y127.241 E.02518
G1 X103.731 Y127.241 E.08232
G1 X100.538 Y130.434 E.14981
G1 X101.73 Y130.434 E.03956
G1 X98.537 Y127.241 E.14981
G1 X96.055 Y127.241 E.08232
G1 X95.25 Y128.046 E.03776
G3 X95.114 Y129.66 I-6.258 J.286 E.0539
; WIPE_START
G1 X95.23 Y129.119 E-.21051
G1 X95.25 Y128.046 E-.40774
G1 X95.514 Y127.782 E-.14176
; WIPE_END
G1 E-.04 F1800
G1 X103.146 Y127.732 Z4.8 F30000
G1 X124.75 Y127.59 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F15476.087
G2 X124.783 Y129.217 I12.668 J.557 E.05402
G1 X123.566 Y130.434 E.05709
G1 X124.758 Y130.434 E.03956
G1 X121.565 Y127.241 E.14981
G1 X119.083 Y127.241 E.08232
G1 X115.89 Y130.434 E.14981
G1 X117.082 Y130.434 E.03956
G1 X113.889 Y127.241 E.14981
G1 X113.248 Y127.241 E.02125
G1 X113.248 Y128.228 E.03276
G1 X124.706 Y125.484 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
M73 P82 R5
G1 X124.706 Y124.12 E.04193
G1 X113.294 Y124.12 E.35065
G1 X113.292 Y126.849 E.08386
G1 X124.706 Y126.849 E.3507
G1 X124.706 Y125.544 E.04009
G1 X124.329 Y125.484 F30000
G1 F12000
G1 X124.329 Y124.497 E.03034
G1 X113.671 Y124.497 E.32748
G1 X113.67 Y126.472 E.06069
G1 X124.329 Y126.472 E.32752
G1 X124.329 Y125.544 E.0285
G1 X123.952 Y125.484 F30000
G1 F12000
G1 X123.952 Y124.874 E.01876
G1 X114.048 Y124.874 E.30432
G1 X114.047 Y126.095 E.03752
G1 X123.952 Y126.095 E.30434
G1 X123.952 Y125.544 E.01691
G1 X123.552 Y125.484 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X123.552 Y125.273 E.00725
G1 X114.447 Y125.273 E.31307
G1 X114.447 Y125.695 E.01451
G1 X123.552 Y125.695 E.31308
G1 X123.552 Y125.544 E.00519
; WIPE_START
G1 X123.552 Y125.695 E-.05737
G1 X121.703 Y125.695 E-.70263
; WIPE_END
G1 E-.04 F1800
G1 X129.281 Y126.607 Z4.8 F30000
G1 X142.753 Y128.228 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X142.752 Y127.241 E.03276
G1 X142.111 Y127.241 E.02126
G1 X138.918 Y130.434 E.14981
G1 X140.11 Y130.434 E.03956
G1 X136.917 Y127.241 E.14981
G1 X134.435 Y127.241 E.08232
G1 X131.242 Y130.434 E.14981
G1 X132.434 Y130.434 E.03956
G1 X131.209 Y129.209 E.0575
G2 X131.248 Y127.583 I-6.255 J-.965 E.0541
; WIPE_START
G1 X131.209 Y129.209 E-.618
G1 X131.473 Y129.473 E-.142
; WIPE_END
G1 E-.04 F1800
G1 X139.105 Y129.522 Z4.8 F30000
G1 X160.888 Y129.663 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F15476.087
G3 X160.752 Y128.049 I4.426 J-1.184 E.05402
G1 X159.945 Y127.241 E.03789
G1 X157.463 Y127.241 E.08232
G1 X154.27 Y130.434 E.14981
G1 X155.462 Y130.434 E.03956
G1 X152.269 Y127.241 E.14981
G1 X149.787 Y127.241 E.08232
G1 X149.25 Y127.778 E.02518
G3 X149.183 Y129.401 I-9.083 J.439 E.05398
; WIPE_START
G1 X149.25 Y128.767 E-.24225
G1 X149.25 Y127.778 E-.37614
G1 X149.514 Y127.514 E-.14161
; WIPE_END
G1 E-.04 F1800
G1 X157.131 Y127.038 Z4.8 F30000
G1 X182.006 Y125.484 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y124.12 E.04193
G1 X167.294 Y124.12 E.45204
G1 X167.294 Y126.849 E.08386
G1 X182.006 Y126.849 E.45204
G1 X182.006 Y125.544 E.04009
G1 X181.629 Y125.484 F30000
G1 F12000
G1 X181.629 Y124.497 E.03034
G1 X167.671 Y124.497 E.42887
G1 X167.671 Y126.472 E.06069
G1 X181.629 Y126.472 E.42887
G1 X181.629 Y125.544 E.0285
G1 X181.252 Y125.484 F30000
G1 F12000
G1 X181.252 Y124.874 E.01876
G1 X168.048 Y124.874 E.4057
G1 X168.048 Y126.095 E.03752
G1 X181.252 Y126.095 E.4057
G1 X181.252 Y125.544 E.01691
G1 X180.852 Y125.484 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X180.852 Y125.273 E.00725
G1 X168.448 Y125.273 E.4265
G1 X168.448 Y125.695 E.01451
G1 X180.852 Y125.695 E.4265
G1 X180.852 Y125.544 E.00519
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X180.852 Y125.695 E-.05737
G1 X179.003 Y125.695 E-.70263
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 23/33
; update layer progress
M73 L23
M991 S0 P22 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z4.8 I.404 J1.148 P1  F30000
G1 X182.398 Y124.499 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y136.843 E.40946
G1 X73.602 Y136.843 E3.60896
G1 X73.602 Y124.499 E.40946
G1 X89.098 Y124.499 E.51403
G1 X89.098 Y128.762 E.14142
G2 X94.902 Y128.757 I2.902 J-.014 E.30166
G1 X94.902 Y124.499 E.14124
G1 X107.098 Y124.499 E.40456
G1 X107.098 Y128.762 E.14142
G2 X112.902 Y128.757 I2.902 J-.017 E.3015
G1 X112.902 Y124.499 E.14124
G1 X125.098 Y124.499 E.40456
G1 X125.098 Y128.762 E.14142
G2 X130.902 Y128.757 I2.902 J-.018 E.30138
G1 X130.902 Y124.499 E.14125
G1 X143.098 Y124.499 E.40456
G1 X143.098 Y128.762 E.14142
G2 X148.902 Y128.757 I2.902 J-.017 E.3015
G1 X148.902 Y124.499 E.14124
G1 X161.098 Y124.499 E.40456
G1 X161.098 Y128.762 E.14142
G2 X166.902 Y128.757 I2.902 J-.017 E.3015
G1 X166.902 Y124.499 E.14124
G1 X182.338 Y124.499 E.51204
; WIPE_START
G1 X182.348 Y126.499 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y122.86 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y137.235 E.4417
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y137.235 E3.36709
G1 X73.21 Y122.86 E.4417
G1 X89.49 Y122.86 E.50024
G1 X89.49 Y128.754 E.18112
G2 X94.51 Y128.752 I2.51 J-.006 E.24196
G1 X94.51 Y122.86 E.18106
G1 X107.49 Y122.86 E.39884
G1 X107.49 Y128.754 E.18112
G2 X112.51 Y128.752 I2.51 J-.008 E.24185
G1 X112.51 Y122.86 E.18106
G1 X125.49 Y122.86 E.39884
G1 X125.49 Y128.754 E.18112
G2 X130.51 Y128.752 I2.51 J-.01 E.24176
G1 X130.51 Y122.86 E.18106
G1 X143.49 Y122.86 E.39884
G1 X143.49 Y128.754 E.18112
G2 X148.51 Y128.752 I2.51 J-.008 E.24185
G1 X148.51 Y122.86 E.18106
G1 X161.49 Y122.86 E.39884
G1 X161.49 Y128.754 E.18112
G2 X166.51 Y128.752 I2.51 J-.008 E.24185
G1 X166.51 Y122.86 E.18106
G1 X182.73 Y122.86 E.4984
M204 S10000
G1 X182.583 Y123.791 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.859 Y123.067 E.03144
G1 X181.326 Y123.067
G1 X182.535 Y124.277 E.05255
G1 X182.002 Y124.277
G1 X180.793 Y123.067 E.05255
G1 X180.259 Y123.067
G1 X181.469 Y124.277 E.05255
G1 X180.935 Y124.277
G1 X179.726 Y123.067 E.05255
G1 X179.193 Y123.067
G1 X180.402 Y124.277 E.05255
G1 X179.869 Y124.277
G1 X178.66 Y123.067 E.05255
G1 X178.126 Y123.067
G1 X179.336 Y124.277 E.05255
G1 X178.802 Y124.277
G1 X177.593 Y123.067 E.05255
G1 X177.06 Y123.067
G1 X178.269 Y124.277 E.05255
G1 X177.736 Y124.277
G1 X176.526 Y123.067 E.05255
G1 X175.993 Y123.067
G1 X177.203 Y124.277 E.05255
G1 X176.669 Y124.277
G1 X175.46 Y123.067 E.05255
G1 X174.927 Y123.067
G1 X176.136 Y124.277 E.05255
G1 X175.603 Y124.277
G1 X174.393 Y123.067 E.05255
G1 X173.86 Y123.067
G1 X175.07 Y124.277 E.05255
G1 X174.536 Y124.277
G1 X173.327 Y123.067 E.05255
G1 X172.794 Y123.067
G1 X174.003 Y124.277 E.05255
G1 X173.47 Y124.277
G1 X172.26 Y123.067 E.05255
G1 X171.727 Y123.067
G1 X172.936 Y124.277 E.05255
G1 X172.403 Y124.277
G1 X171.194 Y123.067 E.05255
G1 X170.661 Y123.067
G1 X171.87 Y124.277 E.05255
G1 X171.337 Y124.277
G1 X170.127 Y123.067 E.05255
G1 X169.594 Y123.067
G1 X170.803 Y124.277 E.05255
G1 X170.27 Y124.277
G1 X169.061 Y123.067 E.05255
G1 X168.528 Y123.067
G1 X169.737 Y124.277 E.05255
G1 X169.204 Y124.277
G1 X167.994 Y123.067 E.05255
G1 X167.461 Y123.067
G1 X168.67 Y124.277 E.05255
G1 X168.137 Y124.277
G1 X166.928 Y123.067 E.05255
G1 X166.717 Y123.39
G1 X167.604 Y124.277 E.03852
G1 X167.071 Y124.277
G1 X166.717 Y123.923 E.01535
; WIPE_START
M204 S10000
G1 X167.071 Y124.277 E-.18984
G1 X167.604 Y124.277 E-.20264
G1 X166.92 Y123.593 E-.36752
; WIPE_END
G1 E-.04 F1800
G1 X161.283 Y123.821 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X160.529 Y123.067 E.03276
G1 X159.995 Y123.067
G1 X161.205 Y124.277 E.05255
G1 X160.672 Y124.277
G1 X159.462 Y123.067 E.05255
G1 X158.929 Y123.067
G1 X160.138 Y124.277 E.05255
G1 X159.605 Y124.277
G1 X158.396 Y123.067 E.05255
G1 X157.862 Y123.067
G1 X159.072 Y124.277 E.05255
G1 X158.539 Y124.277
G1 X157.329 Y123.067 E.05255
G1 X156.796 Y123.067
G1 X158.005 Y124.277 E.05255
G1 X157.472 Y124.277
G1 X156.263 Y123.067 E.05255
G1 X155.729 Y123.067
G1 X156.939 Y124.277 E.05255
G1 X156.405 Y124.277
G1 X155.196 Y123.067 E.05255
G1 X154.663 Y123.067
G1 X155.872 Y124.277 E.05255
G1 X155.339 Y124.277
G1 X154.13 Y123.067 E.05255
G1 X153.596 Y123.067
G1 X154.806 Y124.277 E.05255
G1 X154.272 Y124.277
G1 X153.063 Y123.067 E.05255
G1 X152.53 Y123.067
G1 X153.739 Y124.277 E.05255
G1 X153.206 Y124.277
G1 X151.997 Y123.067 E.05255
G1 X151.463 Y123.067
G1 X152.673 Y124.277 E.05255
G1 X152.139 Y124.277
G1 X150.93 Y123.067 E.05255
G1 X150.397 Y123.067
G1 X151.606 Y124.277 E.05255
G1 X151.073 Y124.277
G1 X149.864 Y123.067 E.05255
G1 X149.33 Y123.067
G1 X150.54 Y124.277 E.05255
G1 X150.006 Y124.277
G1 X148.797 Y123.067 E.05255
G1 X148.717 Y123.521
G1 X149.473 Y124.277 E.03284
; WIPE_START
M204 S10000
G1 X148.717 Y123.521 E-.40615
G1 X148.797 Y123.067 E-.17499
G1 X149.13 Y123.4 E-.17886
; WIPE_END
G1 E-.04 F1800
G1 X143.283 Y123.419 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X142.931 Y123.067 E.01527
G1 X142.398 Y123.067
G1 X143.283 Y123.952 E.03844
G1 X143.074 Y124.277
G1 X141.865 Y123.067 E.05255
G1 X141.331 Y123.067
G1 X142.541 Y124.277 E.05255
G1 X142.008 Y124.277
G1 X140.798 Y123.067 E.05255
G1 X140.265 Y123.067
G1 X141.474 Y124.277 E.05255
G1 X140.941 Y124.277
G1 X139.732 Y123.067 E.05255
G1 X139.198 Y123.067
G1 X140.408 Y124.277 E.05255
G1 X139.875 Y124.277
G1 X138.665 Y123.067 E.05255
G1 X138.132 Y123.067
G1 X139.341 Y124.277 E.05255
G1 X138.808 Y124.277
G1 X137.599 Y123.067 E.05255
G1 X137.065 Y123.067
G1 X138.275 Y124.277 E.05255
G1 X137.741 Y124.277
G1 X136.532 Y123.067 E.05255
G1 X135.999 Y123.067
G1 X137.208 Y124.277 E.05255
G1 X136.675 Y124.277
G1 X135.466 Y123.067 E.05255
G1 X134.932 Y123.067
G1 X136.142 Y124.277 E.05255
G1 X135.608 Y124.277
G1 X134.399 Y123.067 E.05255
G1 X133.866 Y123.067
G1 X135.075 Y124.277 E.05255
G1 X134.542 Y124.277
G1 X133.333 Y123.067 E.05255
G1 X132.799 Y123.067
G1 X134.009 Y124.277 E.05255
G1 X133.475 Y124.277
G1 X132.266 Y123.067 E.05255
G1 X131.733 Y123.067
G1 X132.942 Y124.277 E.05255
G1 X132.409 Y124.277
G1 X131.2 Y123.067 E.05255
G1 X130.717 Y123.118
G1 X131.876 Y124.277 E.05033
G1 X131.342 Y124.277
G1 X130.717 Y123.652 E.02716
; WIPE_START
M204 S10000
G1 X131.342 Y124.277 E-.33588
G1 X131.876 Y124.277 E-.20264
G1 X131.464 Y123.864 E-.22148
; WIPE_END
G1 E-.04 F1800
G1 X125.283 Y123.549 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X124.8 Y123.067 E.02095
G1 X124.267 Y123.067
G1 X125.283 Y124.083 E.04412
G1 X124.943 Y124.277
G1 X123.734 Y123.067 E.05255
G1 X123.201 Y123.067
G1 X124.41 Y124.277 E.05255
G1 X123.877 Y124.277
G1 X122.667 Y123.067 E.05255
G1 X122.134 Y123.067
G1 X123.344 Y124.277 E.05255
G1 X122.81 Y124.277
G1 X121.601 Y123.067 E.05255
G1 X121.068 Y123.067
G1 X122.277 Y124.277 E.05255
G1 X121.744 Y124.277
G1 X120.534 Y123.067 E.05255
G1 X120.001 Y123.067
G1 X121.211 Y124.277 E.05255
G1 X120.677 Y124.277
G1 X119.468 Y123.067 E.05255
G1 X118.935 Y123.067
G1 X120.144 Y124.277 E.05255
G1 X119.611 Y124.277
G1 X118.401 Y123.067 E.05255
G1 X117.868 Y123.067
G1 X119.077 Y124.277 E.05255
G1 X118.544 Y124.277
G1 X117.335 Y123.067 E.05255
G1 X116.802 Y123.067
G1 X118.011 Y124.277 E.05255
G1 X117.478 Y124.277
G1 X116.268 Y123.067 E.05255
G1 X115.735 Y123.067
G1 X116.944 Y124.277 E.05255
G1 X116.411 Y124.277
G1 X115.202 Y123.067 E.05255
G1 X114.669 Y123.067
G1 X115.878 Y124.277 E.05255
G1 X115.345 Y124.277
G1 X114.135 Y123.067 E.05255
G1 X113.602 Y123.067
G1 X114.811 Y124.277 E.05255
G1 X114.278 Y124.277
G1 X113.069 Y123.067 E.05255
G1 X112.717 Y123.249
G1 X113.745 Y124.277 E.04465
G1 X113.212 Y124.277
G1 X112.717 Y123.782 E.02148
; WIPE_START
M204 S10000
G1 X113.212 Y124.277 E-.26561
G1 X113.745 Y124.277 E-.20264
G1 X113.202 Y123.734 E-.29175
; WIPE_END
G1 E-.04 F1800
G1 X107.283 Y123.68 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X106.67 Y123.067 E.02663
G1 X106.136 Y123.067
G1 X107.283 Y124.213 E.0498
G1 X106.813 Y124.277
G1 X105.603 Y123.067 E.05255
G1 X105.07 Y123.067
G1 X106.279 Y124.277 E.05255
G1 X105.746 Y124.277
G1 X104.537 Y123.067 E.05255
G1 X104.003 Y123.067
G1 X105.213 Y124.277 E.05255
G1 X104.68 Y124.277
G1 X103.47 Y123.067 E.05255
G1 X102.937 Y123.067
G1 X104.146 Y124.277 E.05255
G1 X103.613 Y124.277
G1 X102.404 Y123.067 E.05255
G1 X101.87 Y123.067
G1 X103.08 Y124.277 E.05255
G1 X102.546 Y124.277
G1 X101.337 Y123.067 E.05255
G1 X100.804 Y123.067
G1 X102.013 Y124.277 E.05255
G1 X101.48 Y124.277
G1 X100.271 Y123.067 E.05255
G1 X99.737 Y123.067
G1 X100.947 Y124.277 E.05255
G1 X100.413 Y124.277
G1 X99.204 Y123.067 E.05255
G1 X98.671 Y123.067
G1 X99.88 Y124.277 E.05255
G1 X99.347 Y124.277
G1 X98.138 Y123.067 E.05255
G1 X97.604 Y123.067
G1 X98.814 Y124.277 E.05255
G1 X98.28 Y124.277
G1 X97.071 Y123.067 E.05255
G1 X96.538 Y123.067
G1 X97.747 Y124.277 E.05255
M73 P82 R4
G1 X97.214 Y124.277
G1 X96.005 Y123.067 E.05255
G1 X95.471 Y123.067
G1 X96.681 Y124.277 E.05255
G1 X96.147 Y124.277
G1 X94.938 Y123.067 E.05255
G1 X94.717 Y123.38
G1 X95.614 Y124.277 E.03897
G1 X95.081 Y124.277
G1 X94.717 Y123.913 E.0158
; WIPE_START
M204 S10000
G1 X95.081 Y124.277 E-.19534
G1 X95.614 Y124.277 E-.20264
G1 X94.941 Y123.603 E-.36202
; WIPE_END
G1 E-.04 F1800
G1 X95.294 Y124.891 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.707 Y124.891 E.35067
G1 X106.711 Y127.037 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
M73 P83 R4
G1 X106.712 Y127.62 E.01791
G1 X95.292 Y127.62 E.35089
G1 X95.292 Y127.037 E.01791
; Slow Down End
G1 F12000
G1 X95.294 Y124.951 E.0641
G1 X95.671 Y125.268 F30000
G1 F12000
G1 X106.33 Y125.268 E.32753
G1 X106.334 Y127.037 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.334 Y127.243 E.00633
G1 X95.669 Y127.243 E.32769
G1 X95.669 Y127.037 E.00633
; Slow Down End
G1 F12000
G1 X95.671 Y125.328 E.05252
G1 X96.047 Y125.645 F30000
G1 F12000
G1 X96.047 Y126.866 E.03752
G1 X105.956 Y126.866 E.30449
G1 X105.954 Y125.645 E.03752
G1 X96.107 Y125.645 E.30255
G1 X96.447 Y126.045 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X96.446 Y126.467 E.01451
G1 X105.556 Y126.467 E.31321
G1 X105.555 Y126.045 E.01451
G1 X96.507 Y126.045 E.31111
; WIPE_START
G1 X98.507 Y126.045 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X91.089 Y124.248 Z5 F30000
G1 X89.283 Y123.811 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.539 Y123.067 E.03231
G1 X88.006 Y123.067
G1 X89.215 Y124.277 E.05255
G1 X88.682 Y124.277
G1 X87.472 Y123.067 E.05255
G1 X86.939 Y123.067
G1 X88.149 Y124.277 E.05255
G1 X87.615 Y124.277
G1 X86.406 Y123.067 E.05255
G1 X85.873 Y123.067
G1 X87.082 Y124.277 E.05255
G1 X86.549 Y124.277
G1 X85.339 Y123.067 E.05255
G1 X84.806 Y123.067
G1 X86.016 Y124.277 E.05255
G1 X85.482 Y124.277
G1 X84.273 Y123.067 E.05255
G1 X83.74 Y123.067
G1 X84.949 Y124.277 E.05255
G1 X84.416 Y124.277
G1 X83.206 Y123.067 E.05255
G1 X82.673 Y123.067
G1 X83.882 Y124.277 E.05255
G1 X83.349 Y124.277
G1 X82.14 Y123.067 E.05255
G1 X81.607 Y123.067
G1 X82.816 Y124.277 E.05255
G1 X82.283 Y124.277
G1 X81.073 Y123.067 E.05255
G1 X80.54 Y123.067
G1 X81.749 Y124.277 E.05255
G1 X81.216 Y124.277
G1 X80.007 Y123.067 E.05255
G1 X79.474 Y123.067
G1 X80.683 Y124.277 E.05255
G1 X80.15 Y124.277
G1 X78.94 Y123.067 E.05255
G1 X78.407 Y123.067
G1 X79.616 Y124.277 E.05255
G1 X79.083 Y124.277
G1 X77.874 Y123.067 E.05255
G1 X77.341 Y123.067
G1 X78.55 Y124.277 E.05255
G1 X78.017 Y124.277
G1 X76.807 Y123.067 E.05255
G1 X76.274 Y123.067
G1 X77.483 Y124.277 E.05255
G1 X76.95 Y124.277
G1 X75.741 Y123.067 E.05255
G1 X75.208 Y123.067
G1 X76.417 Y124.277 E.05255
G1 X75.884 Y124.277
G1 X74.674 Y123.067 E.05255
G1 X74.141 Y123.067
G1 X75.35 Y124.277 E.05255
G1 X74.817 Y124.277
G1 X73.608 Y123.067 E.05255
G1 X73.417 Y123.41
G1 X74.284 Y124.277 E.03765
; WIPE_START
M204 S10000
G1 X73.417 Y123.41 E-.46563
G1 X73.608 Y123.067 E-.14903
G1 X73.878 Y123.338 E-.14534
; WIPE_END
G1 E-.04 F1800
G1 X73.979 Y130.969 Z5 F30000
G1 X73.994 Y132.076 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X73.994 Y132.938 E.02646
G1 X182.006 Y132.938 E3.31882
G1 X182.006 Y132.076 E.02646
G1 X74.054 Y132.076 E3.31697
G1 X74.425 Y132.507 F30000
; LINE_WIDTH: 0.52714
G1 F13010.615
G1 X181.515 Y132.507 E4.22555
G1 X181.368 Y131.684 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X179.74 Y131.684 E.05401
G1 X176.068 Y128.012 E.17226
G1 X179.719 Y128.012 E.12112
G1 X176.047 Y131.684 E.17226
G1 X172.064 Y131.684 E.13214
G1 X168.392 Y128.012 E.17226
G1 X172.043 Y128.012 E.12112
G1 X168.371 Y131.684 E.17226
G1 X166.743 Y131.684 E.05401
; WIPE_START
G1 X168.371 Y131.684 E-.61876
G1 X168.634 Y131.421 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X162.239 Y127.255 Z5 F30000
G1 X160.706 Y126.256 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.706 Y124.891 E.04193
G1 X149.294 Y124.891 E.35065
G1 X149.292 Y127.62 E.08386
G1 X160.706 Y127.62 E.35071
G1 X160.706 Y126.316 E.04009
G1 X160.329 Y126.256 F30000
G1 F12000
G1 X160.329 Y125.268 E.03034
G1 X149.671 Y125.268 E.32749
G1 X149.669 Y127.243 E.06069
G1 X160.329 Y127.243 E.32753
G1 X160.329 Y126.316 E.0285
G1 X159.952 Y126.256 F30000
G1 F12000
G1 X159.952 Y125.645 E.01876
G1 X150.047 Y125.645 E.30432
G1 X150.047 Y126.866 E.03752
G1 X159.952 Y126.866 E.30435
G1 X159.952 Y126.316 E.01691
G1 X159.552 Y126.256 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X159.552 Y126.045 E.00725
G1 X150.447 Y126.045 E.31308
G1 X150.446 Y126.467 E.01451
G1 X159.552 Y126.467 E.31309
G1 X159.552 Y126.316 E.00519
G1 X159.088 Y128.012 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X160.75 Y128.046 E.05514
G2 X161.526 Y130.854 I3.666 J.497 E.09932
G1 X160.696 Y131.684 E.03897
G1 X156.712 Y131.684 E.13214
G1 X153.04 Y128.012 E.17226
G1 X156.692 Y128.012 E.12112
G1 X153.02 Y131.684 E.17226
G1 X149.036 Y131.684 E.13214
G1 X148.346 Y130.994 E.03236
G2 X149.137 Y129.591 I-3.551 J-2.924 E.05371
; WIPE_START
G1 X148.775 Y130.444 E-.35237
G1 X148.346 Y130.994 E-.26488
G1 X148.612 Y131.26 E-.14275
; WIPE_END
G1 E-.04 F1800
G1 X142.989 Y131.684 Z5 F30000
G1 Z4.6
G1 E.8 F1800
G1 F15476.087
G1 X141.36 Y131.684 E.05401
G1 X137.688 Y128.012 E.17226
G1 X141.34 Y128.012 E.12112
G1 X137.668 Y131.684 E.17226
G1 X133.684 Y131.684 E.13214
G1 X131.205 Y129.205 E.11631
G2 X131.248 Y128.012 I-4.063 J-.743 E.03973
G1 X133.664 Y128.012 E.08014
G1 X129.992 Y131.684 E.17226
G1 X131.62 Y131.684 E.05401
G1 X124.38 Y131.684 F30000
G1 F15476.087
G1 X126.008 Y131.684 E.05401
G1 X122.336 Y128.012 E.17226
G1 X124.75 Y128.012 E.08006
G2 X124.783 Y129.217 I10.131 J.326 E.04001
G1 X122.316 Y131.684 E.11573
G1 X118.332 Y131.684 E.13214
G1 X114.66 Y128.012 E.17226
G1 X118.312 Y128.012 E.12112
G1 X114.64 Y131.684 E.17226
G1 X113.011 Y131.684 E.05401
; WIPE_START
G1 X114.64 Y131.684 E-.61876
G1 X114.903 Y131.421 E-.14125
; WIPE_END
G1 E-.04 F1800
G1 X107.461 Y129.727 Z5 F30000
G1 X106.864 Y129.591 Z5
G1 Z4.6
G1 E.8 F1800
G1 F15476.087
G2 X107.652 Y130.996 I3.296 J-.924 E.05394
G1 X106.964 Y131.684 E.03228
G1 X102.98 Y131.684 E.13214
G1 X99.308 Y128.012 E.17226
G1 X102.96 Y128.012 E.12112
G1 X99.288 Y131.684 E.17226
G1 X95.304 Y131.684 E.13214
G1 X94.475 Y130.855 E.03892
G2 X95.248 Y128.048 I-2.795 J-2.279 E.09938
G1 X96.912 Y128.012 E.05523
; WIPE_START
G1 X95.248 Y128.048 E-.63267
G1 X95.247 Y128.384 E-.12733
; WIPE_END
G1 E-.04 F1800
G1 X88.706 Y127.62 Z5 F30000
G1 Z4.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y124.891 E.08386
G1 X73.994 Y124.891 E.45204
G1 X73.994 Y127.62 E.08386
G1 X88.646 Y127.62 E.4502
G1 X88.329 Y126.256 F30000
G1 F12000
G1 X88.329 Y125.268 E.03034
G1 X74.371 Y125.268 E.42887
G1 X74.371 Y127.243 E.06069
G1 X88.329 Y127.243 E.42887
G1 X88.329 Y126.316 E.0285
G1 X87.952 Y126.256 F30000
G1 F12000
G1 X87.952 Y125.645 E.01876
G1 X74.748 Y125.645 E.4057
G1 X74.748 Y126.866 E.03752
G1 X87.952 Y126.866 E.4057
G1 X87.952 Y126.316 E.01691
G1 X87.552 Y126.256 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X87.552 Y126.045 E.00725
G1 X75.148 Y126.045 E.4265
G1 X75.148 Y126.467 E.01451
G1 X87.552 Y126.467 E.4265
G1 X87.552 Y126.316 E.00519
G1 X89.257 Y131.684 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X87.629 Y131.684 E.05401
G1 X83.957 Y128.012 E.17226
G1 X87.608 Y128.012 E.12112
G1 X83.936 Y131.684 E.17226
G1 X79.953 Y131.684 E.13214
G1 X76.281 Y128.012 E.17226
G1 X79.932 Y128.012 E.12112
G1 X76.26 Y131.684 E.17226
G1 X74.632 Y131.684 E.05401
G1 X73.994 Y136.451 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y136.451 E3.31882
G1 X182.006 Y135.118 E.04096
G1 X73.994 Y135.118 E3.31882
G1 X73.994 Y136.391 E.03912
G1 X74.422 Y136.023 F30000
; LINE_WIDTH: 0.52089
G1 F12000
G1 X181.578 Y136.023 E4.17359
G1 X181.578 Y135.545 E.01862
G1 X74.422 Y135.545 E4.17359
G1 X74.422 Y135.963 E.01628
; WIPE_START
G1 X74.422 Y135.545 E-.15883
G1 X76.004 Y135.545 E-.60117
; WIPE_END
G1 E-.04 F1800
G1 X83.501 Y134.115 Z5 F30000
G1 X124.706 Y126.256 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.706 Y124.891 E.04193
G1 X113.294 Y124.891 E.35065
G1 X113.292 Y127.62 E.08386
G1 X124.706 Y127.62 E.35071
G1 X124.706 Y126.316 E.04009
G1 X124.329 Y126.256 F30000
G1 F12000
G1 X124.329 Y125.268 E.03034
G1 X113.671 Y125.268 E.32749
G1 X113.669 Y127.243 E.06069
G1 X124.329 Y127.243 E.32753
G1 X124.329 Y126.316 E.0285
G1 X123.952 Y126.256 F30000
G1 F12000
G1 X123.952 Y125.645 E.01876
G1 X114.047 Y125.645 E.30432
G1 X114.047 Y126.866 E.03752
G1 X123.952 Y126.866 E.30435
G1 X123.952 Y126.316 E.01691
G1 X123.552 Y126.256 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X123.552 Y126.045 E.00725
G1 X114.447 Y126.045 E.31308
G1 X114.446 Y126.467 E.01451
G1 X123.552 Y126.467 E.31309
G1 X123.552 Y126.316 E.00519
; WIPE_START
G1 X123.552 Y126.467 E-.05737
G1 X121.703 Y126.467 E-.70263
; WIPE_END
G1 E-.04 F1800
G1 X129.335 Y126.39 Z5 F30000
G1 X142.706 Y126.256 Z5
G1 Z4.6
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.706 Y124.891 E.04193
G1 X131.294 Y124.891 E.35065
G1 X131.292 Y127.62 E.08386
G1 X142.706 Y127.62 E.35071
G1 X142.706 Y126.316 E.04009
G1 X142.329 Y127.243 F30000
G1 F12000
G1 X142.329 Y125.268 E.06069
G1 X131.671 Y125.268 E.32749
G1 X131.669 Y127.243 E.06069
G1 X142.269 Y127.243 E.32569
G1 X141.952 Y126.866 F30000
G1 F12000
G1 X141.952 Y125.645 E.03752
G1 X132.047 Y125.645 E.30432
G1 X132.047 Y126.866 E.03752
G1 X141.892 Y126.866 E.30251
G1 X141.552 Y126.467 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X141.552 Y126.045 E.01451
G1 X132.447 Y126.045 E.31308
G1 X132.446 Y126.467 E.01451
G1 X141.492 Y126.467 E.31102
; WIPE_START
G1 X139.492 Y126.467 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X147.016 Y127.749 Z5 F30000
G1 X179.757 Y133.329 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X181.385 Y133.329 E.05401
G1 X182.05 Y133.994 E.03117
G1 X182.05 Y133.358 E.0211
G1 X180.682 Y134.726 E.06416
G1 X175.105 Y134.726 E.18499
G1 X173.709 Y133.329 E.06549
G1 X174.402 Y133.329 E.02299
G1 X173.006 Y134.726 E.06549
G1 X167.429 Y134.726 E.18499
G1 X166.033 Y133.329 E.06549
G1 X166.726 Y133.329 E.02299
G1 X165.33 Y134.726 E.06549
G1 X159.753 Y134.726 E.18499
G1 X158.357 Y133.329 E.06549
G1 X159.05 Y133.329 E.02299
G1 X157.654 Y134.726 E.06549
G1 X152.077 Y134.726 E.18499
G1 X150.681 Y133.329 E.06549
G1 X151.374 Y133.329 E.02299
G1 X149.978 Y134.726 E.06549
G1 X144.402 Y134.726 E.18499
G1 X143.005 Y133.329 E.06549
G1 X143.698 Y133.329 E.02299
G1 X142.302 Y134.726 E.06549
G1 X136.726 Y134.726 E.18499
G1 X135.329 Y133.329 E.06549
G1 X136.022 Y133.329 E.02299
G1 X134.626 Y134.726 E.06549
G1 X129.05 Y134.726 E.18499
G1 X127.653 Y133.329 E.06549
G1 X128.346 Y133.329 E.02299
G1 X126.95 Y134.726 E.06549
G1 X121.374 Y134.726 E.18499
G1 X119.978 Y133.329 E.06549
G1 X120.671 Y133.329 E.02299
G1 X119.274 Y134.726 E.06549
G1 X113.698 Y134.726 E.18499
G1 X112.302 Y133.329 E.06549
G1 X112.995 Y133.329 E.02299
G1 X111.598 Y134.726 E.06549
G1 X106.022 Y134.726 E.18499
G1 X104.626 Y133.329 E.06549
G1 X105.319 Y133.329 E.02299
G1 X103.923 Y134.726 E.06549
G1 X98.346 Y134.726 E.18499
G1 X96.95 Y133.329 E.06549
G1 X97.643 Y133.329 E.02299
G1 X96.247 Y134.726 E.06549
G1 X90.67 Y134.726 E.18499
G1 X89.274 Y133.329 E.06549
G1 X89.967 Y133.329 E.02299
G1 X88.571 Y134.726 E.06549
G1 X82.994 Y134.726 E.18499
G1 X81.598 Y133.329 E.06549
G1 X82.291 Y133.329 E.02299
G1 X80.895 Y134.726 E.06549
G1 X75.318 Y134.726 E.18499
G1 X73.95 Y133.358 E.06416
G1 X73.95 Y133.994 E.0211
G1 X74.615 Y133.329 E.03117
G1 X76.243 Y133.329 E.05401
; WIPE_START
G1 X74.615 Y133.329 E-.61876
G1 X74.352 Y133.592 E-.14124
; WIPE_END
G1 E-.04 F1800
G17
G3 Z5 I.083 J1.214 P1  F30000
G1 X182.006 Y126.256 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y124.891 E.04193
G1 X167.294 Y124.891 E.45205
G1 X167.292 Y127.62 E.08386
G1 X182.006 Y127.62 E.45211
G1 X182.006 Y126.316 E.04009
G1 X181.629 Y126.256 F30000
G1 F12000
G1 X181.629 Y125.268 E.03034
G1 X167.671 Y125.268 E.42888
G1 X167.669 Y127.243 E.06069
G1 X181.629 Y127.243 E.42893
G1 X181.629 Y126.316 E.0285
G1 X181.252 Y126.256 F30000
G1 F12000
G1 X181.252 Y125.645 E.01876
G1 X168.047 Y125.645 E.40572
G1 X168.047 Y126.866 E.03752
G1 X181.252 Y126.866 E.40575
G1 X181.252 Y126.316 E.01691
G1 X180.852 Y126.256 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X180.852 Y126.045 E.00725
G1 X168.447 Y126.045 E.42654
G1 X168.446 Y126.467 E.01451
G1 X180.852 Y126.467 E.42655
G1 X180.852 Y126.316 E.00519
; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X180.852 Y126.467 E-.05737
G1 X179.003 Y126.467 E-.70263
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 24/33
; update layer progress
M73 L24
M991 S0 P23 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5 I.404 J1.148 P1  F30000
G1 X182.398 Y125.27 Z5
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y136.517 E.37306
G1 X73.602 Y136.517 E3.60896
G1 X73.602 Y125.27 E.37306
G1 X89.098 Y125.27 E.51403
G1 X89.098 Y128.762 E.11582
G2 X94.902 Y128.757 I2.902 J-.017 E.30149
G1 X94.902 Y125.27 E.11565
M73 P84 R4
G1 X107.098 Y125.27 E.40456
G1 X107.098 Y128.757 E.11565
G2 X112.902 Y128.757 I2.902 J-.01 E.30176
G1 X112.902 Y125.27 E.11565
G1 X125.098 Y125.27 E.40456
G1 X125.098 Y128.757 E.11565
G2 X130.902 Y128.757 I2.902 J-.013 E.30159
G1 X130.902 Y125.27 E.11565
G1 X143.098 Y125.27 E.40456
G1 X143.098 Y128.762 E.11581
G2 X148.902 Y128.762 I2.902 J-.019 E.3012
G1 X148.902 Y125.27 E.11581
G1 X161.098 Y125.27 E.40456
G1 X161.098 Y128.762 E.11581
G2 X166.902 Y128.762 I2.902 J-.019 E.3012
G1 X166.902 Y125.27 E.11581
G1 X182.338 Y125.27 E.51204
; WIPE_START
G1 X182.349 Y127.27 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y123.631 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y136.909 E.40798
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y136.909 E3.36709
G1 X73.21 Y123.631 E.40798
G1 X89.49 Y123.631 E.50024
G1 X89.49 Y128.754 E.15741
G2 X94.51 Y128.752 I2.51 J-.008 E.24184
G1 X94.51 Y123.631 E.15736
G1 X107.49 Y123.631 E.39884
G1 X107.49 Y128.752 E.15736
G2 X112.51 Y128.752 I2.51 J-.005 E.24197
G1 X112.51 Y123.631 E.15736
G1 X125.49 Y123.631 E.39884
G1 X125.49 Y128.752 E.15736
G2 X130.51 Y128.752 I2.51 J-.008 E.24183
G1 X130.51 Y123.631 E.15736
G1 X143.49 Y123.631 E.39884
G1 X143.49 Y128.754 E.15741
G2 X148.51 Y128.754 I2.51 J-.01 E.24166
G1 X148.51 Y123.631 E.15741
G1 X161.49 Y123.631 E.39884
G1 X161.49 Y128.754 E.15741
G2 X166.51 Y128.754 I2.51 J-.01 E.24166
G1 X166.51 Y123.631 E.15741
G1 X182.73 Y123.631 E.4984
M204 S10000
G1 X182.583 Y124.476 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.011 Y125.048 E.02484
G1 X181.478 Y125.048
G1 X182.583 Y123.943 E.04801
G1 X182.154 Y123.839
G1 X180.945 Y125.048 E.05255
G1 X180.411 Y125.048
G1 X181.621 Y123.839 E.05255
G1 X181.087 Y123.839
G1 X179.878 Y125.048 E.05255
G1 X179.345 Y125.048
G1 X180.554 Y123.839 E.05255
G1 X180.021 Y123.839
G1 X178.812 Y125.048 E.05255
G1 X178.278 Y125.048
G1 X179.488 Y123.839 E.05255
G1 X178.954 Y123.839
G1 X177.745 Y125.048 E.05255
G1 X177.212 Y125.048
G1 X178.421 Y123.839 E.05255
G1 X177.888 Y123.839
G1 X176.679 Y125.048 E.05255
G1 X176.145 Y125.048
G1 X177.355 Y123.839 E.05255
G1 X176.821 Y123.839
G1 X175.612 Y125.048 E.05255
G1 X175.079 Y125.048
G1 X176.288 Y123.839 E.05255
G1 X175.755 Y123.839
G1 X174.546 Y125.048 E.05255
G1 X174.012 Y125.048
G1 X175.222 Y123.839 E.05255
G1 X174.688 Y123.839
G1 X173.479 Y125.048 E.05255
G1 X172.946 Y125.048
G1 X174.155 Y123.839 E.05255
G1 X173.622 Y123.839
G1 X172.412 Y125.048 E.05255
G1 X171.879 Y125.048
G1 X173.089 Y123.839 E.05255
G1 X172.555 Y123.839
G1 X171.346 Y125.048 E.05255
G1 X170.813 Y125.048
G1 X172.022 Y123.839 E.05255
G1 X171.489 Y123.839
G1 X170.279 Y125.048 E.05255
G1 X169.746 Y125.048
G1 X170.956 Y123.839 E.05255
G1 X170.422 Y123.839
G1 X169.213 Y125.048 E.05255
G1 X168.68 Y125.048
G1 X169.889 Y123.839 E.05255
G1 X169.356 Y123.839
G1 X168.146 Y125.048 E.05255
G1 X167.613 Y125.048
G1 X168.822 Y123.839 E.05255
G1 X168.289 Y123.839
G1 X167.08 Y125.048 E.05255
G1 X166.717 Y124.877
G1 X167.756 Y123.839 E.04513
G1 X167.223 Y123.839
G1 X166.717 Y124.344 E.02196
; WIPE_START
M204 S10000
G1 X167.223 Y123.839 E-.27155
G1 X167.756 Y123.839 E-.20264
G1 X167.224 Y124.37 E-.28581
; WIPE_END
G1 E-.04 F1800
G1 X161.283 Y124.446 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X160.681 Y125.048 E.02615
G1 X160.148 Y125.048
G1 X161.283 Y123.913 E.04932
G1 X160.824 Y123.839
G1 X159.614 Y125.048 E.05255
G1 X159.081 Y125.048
G1 X160.29 Y123.839 E.05255
G1 X159.757 Y123.839
G1 X158.548 Y125.048 E.05255
G1 X158.015 Y125.048
G1 X159.224 Y123.839 E.05255
G1 X158.691 Y123.839
G1 X157.481 Y125.048 E.05255
G1 X156.948 Y125.048
G1 X158.157 Y123.839 E.05255
G1 X157.624 Y123.839
G1 X156.415 Y125.048 E.05255
G1 X155.881 Y125.048
G1 X157.091 Y123.839 E.05255
G1 X156.558 Y123.839
G1 X155.348 Y125.048 E.05255
G1 X154.815 Y125.048
G1 X156.024 Y123.839 E.05255
G1 X155.491 Y123.839
G1 X154.282 Y125.048 E.05255
G1 X153.748 Y125.048
G1 X154.958 Y123.839 E.05255
G1 X154.425 Y123.839
G1 X153.215 Y125.048 E.05255
G1 X152.682 Y125.048
G1 X153.891 Y123.839 E.05255
G1 X153.358 Y123.839
G1 X152.149 Y125.048 E.05255
G1 X151.615 Y125.048
G1 X152.825 Y123.839 E.05255
G1 X152.291 Y123.839
G1 X151.082 Y125.048 E.05255
G1 X150.549 Y125.048
G1 X151.758 Y123.839 E.05255
G1 X151.225 Y123.839
G1 X150.016 Y125.048 E.05255
G1 X149.482 Y125.048
G1 X150.692 Y123.839 E.05255
G1 X150.158 Y123.839
G1 X148.949 Y125.048 E.05255
G1 X148.717 Y124.746
G1 X149.625 Y123.839 E.03945
G1 X149.092 Y123.839
G1 X148.717 Y124.213 E.01628
; WIPE_START
M204 S10000
G1 X149.092 Y123.839 E-.20129
G1 X149.625 Y123.839 E-.20264
G1 X148.963 Y124.501 E-.35608
; WIPE_END
G1 E-.04 F1800
G1 X149.293 Y125.663 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.707 Y125.663 E.35069
G1 X160.711 Y127.809 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.712 Y128.392 E.01791
G1 X149.288 Y128.392 E.35104
G1 X149.289 Y127.809 E.01791
; Slow Down End
G1 F12000
G1 X149.293 Y125.723 E.0641
G1 X149.67 Y126.04 F30000
G1 F12000
G1 X160.33 Y126.04 E.32757
G1 X160.334 Y127.809 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X160.335 Y128.015 E.00633
G1 X149.666 Y128.015 E.32782
G1 X149.666 Y127.809 E.00633
; Slow Down End
G1 F12000
G1 X149.669 Y126.1 E.05252
G1 X150.046 Y126.417 F30000
G1 F12000
G1 X150.043 Y127.638 E.03752
G1 X159.957 Y127.638 E.3046
G1 X159.954 Y126.417 E.03751
G1 X150.106 Y126.417 E.3026
G1 X150.445 Y126.816 F30000
; LINE_WIDTH: 0.46485
G1 F12000
G1 X150.444 Y127.238 E.01451
G1 X159.556 Y127.238 E.31331
G1 X159.555 Y126.816 E.01451
G1 X150.505 Y126.816 E.31119
; WIPE_START
G1 X152.505 Y126.816 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.138 Y124.819 Z5.2 F30000
G1 X143.283 Y124.315 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X142.55 Y125.048 E.03183
G1 X142.017 Y125.048
G1 X143.226 Y123.839 E.05255
G1 X142.693 Y123.839
G1 X141.484 Y125.048 E.05255
G1 X140.95 Y125.048
G1 X142.16 Y123.839 E.05255
G1 X141.626 Y123.839
G1 X140.417 Y125.048 E.05255
G1 X139.884 Y125.048
G1 X141.093 Y123.839 E.05255
G1 X140.56 Y123.839
G1 X139.351 Y125.048 E.05255
G1 X138.817 Y125.048
G1 X140.027 Y123.839 E.05255
G1 X139.493 Y123.839
G1 X138.284 Y125.048 E.05255
G1 X137.751 Y125.048
G1 X138.96 Y123.839 E.05255
G1 X138.427 Y123.839
G1 X137.217 Y125.048 E.05255
G1 X136.684 Y125.048
G1 X137.894 Y123.839 E.05255
G1 X137.36 Y123.839
G1 X136.151 Y125.048 E.05255
G1 X135.618 Y125.048
G1 X136.827 Y123.839 E.05255
G1 X136.294 Y123.839
G1 X135.084 Y125.048 E.05255
G1 X134.551 Y125.048
G1 X135.761 Y123.839 E.05255
G1 X135.227 Y123.839
G1 X134.018 Y125.048 E.05255
G1 X133.485 Y125.048
G1 X134.694 Y123.839 E.05255
G1 X134.161 Y123.839
G1 X132.951 Y125.048 E.05255
G1 X132.418 Y125.048
G1 X133.627 Y123.839 E.05255
G1 X133.094 Y123.839
G1 X131.885 Y125.048 E.05255
G1 X131.352 Y125.048
G1 X132.561 Y123.839 E.05255
G1 X132.028 Y123.839
G1 X130.818 Y125.048 E.05255
G1 X130.717 Y124.616
G1 X131.494 Y123.839 E.03377
; WIPE_START
M204 S10000
G1 X130.717 Y124.616 E-.4176
G1 X130.818 Y125.048 E-.16868
G1 X131.142 Y124.725 E-.17372
; WIPE_END
G1 E-.04 F1800
G1 X131.291 Y128.392 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.292 Y127.809 E.01791
; Slow Down End
G1 F12000
G1 X131.294 Y125.663 E.06595
G1 X142.707 Y125.663 E.35068
G1 X142.711 Y127.809 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.712 Y128.392 E.01791
; Slow Down End
G1 F12000
G1 X131.351 Y128.392 E.34909
G1 X131.669 Y128.015 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.669 Y127.809 E.00633
; Slow Down End
G1 F12000
G1 X131.671 Y126.04 E.05436
G1 X142.33 Y126.04 E.32754
G1 X142.334 Y127.809 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X142.335 Y128.015 E.00633
; Slow Down End
G1 F12000
G1 X131.729 Y128.015 E.32588
G1 X132.046 Y127.638 F30000
G1 F12000
G1 X141.957 Y127.638 E.30452
G1 X141.954 Y126.417 E.03751
G1 X132.047 Y126.417 E.3044
G1 X132.046 Y127.578 E.03567
G1 X132.446 Y127.238 F30000
; LINE_WIDTH: 0.46485
G1 F12000
G1 X141.556 Y127.238 E.31323
G1 X141.555 Y126.816 E.01451
G1 X132.446 Y126.816 E.31319
G1 X132.446 Y127.178 E.01244
; WIPE_START
G1 X132.446 Y126.816 E-.13754
G1 X134.084 Y126.816 E-.62246
; WIPE_END
G1 E-.04 F1800
G1 X126.577 Y125.443 Z5.2 F30000
G1 X124.419 Y125.048 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X125.283 Y124.185 E.03752
G1 X125.095 Y123.839
G1 X123.886 Y125.048 E.05255
G1 X123.353 Y125.048
G1 X124.562 Y123.839 E.05255
G1 X124.029 Y123.839
G1 X122.82 Y125.048 E.05255
G1 X122.286 Y125.048
G1 X123.496 Y123.839 E.05255
G1 X122.962 Y123.839
G1 X121.753 Y125.048 E.05255
G1 X121.22 Y125.048
G1 X122.429 Y123.839 E.05255
G1 X121.896 Y123.839
G1 X120.686 Y125.048 E.05255
G1 X120.153 Y125.048
G1 X121.363 Y123.839 E.05255
G1 X120.829 Y123.839
G1 X119.62 Y125.048 E.05255
G1 X119.087 Y125.048
G1 X120.296 Y123.839 E.05255
G1 X119.763 Y123.839
G1 X118.553 Y125.048 E.05255
G1 X118.02 Y125.048
G1 X119.23 Y123.839 E.05255
G1 X118.696 Y123.839
G1 X117.487 Y125.048 E.05255
G1 X116.954 Y125.048
G1 X118.163 Y123.839 E.05255
G1 X117.63 Y123.839
G1 X116.42 Y125.048 E.05255
G1 X115.887 Y125.048
G1 X117.097 Y123.839 E.05255
G1 X116.563 Y123.839
G1 X115.354 Y125.048 E.05255
G1 X114.821 Y125.048
G1 X116.03 Y123.839 E.05255
G1 X115.497 Y123.839
G1 X114.287 Y125.048 E.05255
G1 X113.754 Y125.048
G1 X114.963 Y123.839 E.05255
G1 X114.43 Y123.839
G1 X113.221 Y125.048 E.05255
G1 X112.717 Y125.018
G1 X113.897 Y123.839 E.05126
G1 X113.364 Y123.839
G1 X112.717 Y124.485 E.02809
; WIPE_START
M204 S10000
G1 X113.364 Y123.839 E-.34733
G1 X113.897 Y123.839 E-.20264
G1 X113.506 Y124.229 E-.21003
; WIPE_END
G1 E-.04 F1800
G1 X113.294 Y125.663 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.706 Y125.663 E.35066
G1 X124.708 Y127.809 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.709 Y128.392 E.01791
G1 X113.291 Y128.392 E.35081
G1 X113.292 Y127.809 E.01791
; Slow Down End
G1 F12000
G1 X113.294 Y125.723 E.0641
G1 X113.671 Y126.04 F30000
G1 F12000
G1 X124.329 Y126.04 E.32751
G1 X124.331 Y127.809 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X124.331 Y128.015 E.00633
G1 X113.669 Y128.015 E.32762
G1 X113.669 Y127.809 E.00633
; Slow Down End
G1 F12000
G1 X113.67 Y126.1 E.05252
G1 X114.047 Y126.417 F30000
G1 F12000
G1 X114.046 Y127.638 E.03752
G1 X123.954 Y127.638 E.30443
G1 X123.953 Y126.417 E.03752
G1 X114.107 Y126.417 E.30252
G1 X114.446 Y126.816 F30000
; LINE_WIDTH: 0.464855
G1 F12000
G1 X114.446 Y127.238 E.01451
G1 X123.554 Y127.238 E.31315
G1 X123.554 Y126.816 E.01451
G1 X114.506 Y126.816 E.31106
; WIPE_START
G1 X116.506 Y126.816 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.087 Y125.023 Z5.2 F30000
G1 X107.283 Y124.587 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.822 Y125.048 E.02002
G1 X106.289 Y125.048
G1 X107.283 Y124.054 E.0432
G1 X106.965 Y123.839
G1 X105.755 Y125.048 E.05255
G1 X105.222 Y125.048
G1 X106.431 Y123.839 E.05255
G1 X105.898 Y123.839
G1 X104.689 Y125.048 E.05255
G1 X104.156 Y125.048
G1 X105.365 Y123.839 E.05255
G1 X104.832 Y123.839
G1 X103.622 Y125.048 E.05255
G1 X103.089 Y125.048
G1 X104.298 Y123.839 E.05255
G1 X103.765 Y123.839
G1 X102.556 Y125.048 E.05255
G1 X102.022 Y125.048
G1 X103.232 Y123.839 E.05255
G1 X102.699 Y123.839
G1 X101.489 Y125.048 E.05255
G1 X100.956 Y125.048
G1 X102.165 Y123.839 E.05255
G1 X101.632 Y123.839
G1 X100.423 Y125.048 E.05255
G1 X99.889 Y125.048
G1 X101.099 Y123.839 E.05255
G1 X100.566 Y123.839
G1 X99.356 Y125.048 E.05255
G1 X98.823 Y125.048
G1 X100.032 Y123.839 E.05255
G1 X99.499 Y123.839
G1 X98.29 Y125.048 E.05255
G1 X97.756 Y125.048
G1 X98.966 Y123.839 E.05255
G1 X98.432 Y123.839
G1 X97.223 Y125.048 E.05255
G1 X96.69 Y125.048
G1 X97.899 Y123.839 E.05255
G1 X97.366 Y123.839
G1 X96.157 Y125.048 E.05255
G1 X95.623 Y125.048
G1 X96.833 Y123.839 E.05255
G1 X96.299 Y123.839
G1 X95.09 Y125.048 E.05255
G1 X94.717 Y124.887
G1 X95.766 Y123.839 E.04558
G1 X95.233 Y123.839
G1 X94.717 Y124.354 E.0224
; WIPE_START
M204 S10000
G1 X95.233 Y123.839 E-.27706
G1 X95.766 Y123.839 E-.20264
G1 X95.245 Y124.36 E-.2803
; WIPE_END
G1 E-.04 F1800
G1 X95.291 Y128.392 Z5.2 F30000
G1 Z4.8
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X95.292 Y127.809 E.01791
; Slow Down End
G1 F12000
G1 X95.294 Y125.663 E.06595
G1 X106.706 Y125.663 E.35066
G1 X106.708 Y127.809 E.06595
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.709 Y128.392 E.01791
; Slow Down End
G1 F12000
G1 X95.351 Y128.392 E.34896
G1 X95.669 Y128.015 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X95.669 Y127.809 E.00633
; Slow Down End
G1 F12000
G1 X95.671 Y126.04 E.05436
G1 X106.329 Y126.04 E.32751
G1 X106.331 Y127.809 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X106.331 Y128.015 E.00633
; Slow Down End
G1 F12000
G1 X95.729 Y128.015 E.32577
G1 X96.046 Y127.638 F30000
G1 F12000
M73 P85 R4
G1 X105.954 Y127.638 E.30442
G1 X105.953 Y126.417 E.03752
G1 X96.047 Y126.417 E.30436
G1 X96.046 Y127.578 E.03567
G1 X96.446 Y127.238 F30000
; LINE_WIDTH: 0.46486
G1 F12000
G1 X105.554 Y127.238 E.31315
G1 X105.554 Y126.816 E.01451
G1 X96.446 Y126.816 E.31313
G1 X96.446 Y127.178 E.01244
; WIPE_START
G1 X96.446 Y126.816 E-.13754
G1 X98.084 Y126.816 E-.62246
; WIPE_END
G1 E-.04 F1800
G1 X90.712 Y124.84 Z5.2 F30000
G1 X89.283 Y124.456 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.691 Y125.048 E.02571
G1 X88.158 Y125.048
G1 X89.283 Y123.923 E.04888
G1 X88.834 Y123.839
G1 X87.625 Y125.048 E.05255
G1 X87.091 Y125.048
G1 X88.301 Y123.839 E.05255
G1 X87.767 Y123.839
G1 X86.558 Y125.048 E.05255
G1 X86.025 Y125.048
G1 X87.234 Y123.839 E.05255
G1 X86.701 Y123.839
G1 X85.491 Y125.048 E.05255
G1 X84.958 Y125.048
G1 X86.168 Y123.839 E.05255
G1 X85.634 Y123.839
G1 X84.425 Y125.048 E.05255
G1 X83.892 Y125.048
G1 X85.101 Y123.839 E.05255
G1 X84.568 Y123.839
G1 X83.358 Y125.048 E.05255
G1 X82.825 Y125.048
G1 X84.035 Y123.839 E.05255
G1 X83.501 Y123.839
G1 X82.292 Y125.048 E.05255
G1 X81.759 Y125.048
G1 X82.968 Y123.839 E.05255
G1 X82.435 Y123.839
G1 X81.225 Y125.048 E.05255
G1 X80.692 Y125.048
G1 X81.901 Y123.839 E.05255
G1 X81.368 Y123.839
G1 X80.159 Y125.048 E.05255
G1 X79.626 Y125.048
G1 X80.835 Y123.839 E.05255
G1 X80.302 Y123.839
G1 X79.092 Y125.048 E.05255
G1 X78.559 Y125.048
G1 X79.768 Y123.839 E.05255
G1 X79.235 Y123.839
G1 X78.026 Y125.048 E.05255
G1 X77.493 Y125.048
G1 X78.702 Y123.839 E.05255
G1 X78.169 Y123.839
G1 X76.959 Y125.048 E.05255
G1 X76.426 Y125.048
G1 X77.635 Y123.839 E.05255
G1 X77.102 Y123.839
G1 X75.893 Y125.048 E.05255
G1 X75.36 Y125.048
G1 X76.569 Y123.839 E.05255
G1 X76.036 Y123.839
G1 X74.826 Y125.048 E.05255
G1 X74.293 Y125.048
G1 X75.502 Y123.839 E.05255
G1 X74.969 Y123.839
G1 X73.76 Y125.048 E.05255
G1 X73.417 Y124.857
G1 X74.436 Y123.839 E.04426
G1 X73.903 Y123.839
G1 X73.417 Y124.324 E.02109
; WIPE_START
M204 S10000
G1 X73.903 Y123.839 E-.26077
G1 X74.436 Y123.839 E-.20264
G1 X73.884 Y124.391 E-.29659
; WIPE_END
G1 E-.04 F1800
G1 X73.956 Y132.023 Z5.2 F30000
G1 X73.994 Y136.125 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y136.125 E3.31882
G1 X182.006 Y134.663 E.04491
G1 X73.994 Y134.663 E3.31882
G1 X73.994 Y136.065 E.04307
G1 X74.371 Y135.748 F30000
G1 F12000
G1 X181.629 Y135.748 E3.29564
G1 X181.629 Y135.04 E.02174
G1 X74.371 Y135.04 E3.29564
G1 X74.371 Y135.688 E.0199
G1 X74.725 Y135.394 F30000
; LINE_WIDTH: 0.3734
G1 F12000
G1 X181.215 Y135.394 E2.86777
G1 X179.508 Y134.271 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X181.137 Y134.271 E.05401
G1 X182.05 Y133.358 E.04283
G1 X182.05 Y133.994 E.0211
G1 X176.839 Y128.784 E.24442
G1 X178.948 Y128.784 E.06995
G1 X173.461 Y134.271 E.25742
G1 X174.651 Y134.271 E.03948
G1 X169.163 Y128.784 E.25742
G1 X171.272 Y128.784 E.06995
G1 X165.785 Y134.271 E.25742
G1 X166.975 Y134.271 E.03948
G1 X164.635 Y131.931 E.10978
G3 X161.527 Y130.853 I-.626 J-3.214 E.11433
G1 X158.109 Y134.271 E.16034
G1 X159.299 Y134.271 E.03948
G1 X153.812 Y128.784 E.25742
G1 X155.92 Y128.784 E.06995
G1 X150.433 Y134.271 E.25742
G1 X151.623 Y134.271 E.03948
G1 X148.346 Y130.995 E.15371
G3 X145.148 Y131.88 I-2.348 J-2.262 E.1155
G1 X142.757 Y134.271 E.11217
G1 X143.947 Y134.271 E.03948
G1 X138.46 Y128.784 E.25742
G1 X140.568 Y128.784 E.06995
G1 X135.081 Y134.271 E.25742
G1 X136.271 Y134.271 E.03948
G1 X131.205 Y129.205 E.23766
G2 X131.247 Y128.784 I-1.422 J-.355 E.0141
G1 X132.892 Y128.784 E.05457
G1 X127.405 Y134.271 E.25742
G1 X128.595 Y134.271 E.03948
G1 X123.108 Y128.784 E.25742
G1 X124.753 Y128.784 E.05457
G2 X124.795 Y129.205 I1.491 J.064 E.0141
G1 X119.729 Y134.271 E.23765
G1 X120.919 Y134.271 E.03948
G1 X115.432 Y128.784 E.25742
G1 X117.54 Y128.784 E.06995
G1 X112.053 Y134.271 E.25742
G1 X113.243 Y134.271 E.03948
G1 X110.855 Y131.883 E.11205
G3 X107.655 Y130.993 I-.846 J-3.157 E.11555
G1 X104.377 Y134.271 E.15379
G1 X105.567 Y134.271 E.03948
G1 X100.08 Y128.784 E.25742
G1 X102.188 Y128.784 E.06995
G1 X96.701 Y134.271 E.25742
G1 X97.891 Y134.271 E.03948
G1 X94.474 Y130.854 E.1603
G3 X91.362 Y131.934 I-2.476 J-2.109 E.1146
G1 X89.025 Y134.271 E.10962
G1 X90.215 Y134.271 E.03948
G1 X84.728 Y128.784 E.25742
G1 X86.837 Y128.784 E.06995
G1 X81.349 Y134.271 E.25742
G1 X82.539 Y134.271 E.03948
G1 X77.052 Y128.784 E.25742
G1 X79.161 Y128.784 E.06995
G1 X73.95 Y133.994 E.24442
G1 X73.95 Y133.358 E.0211
G1 X74.863 Y134.271 E.04283
G1 X76.492 Y134.271 E.05401
G1 X88.706 Y127.027 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y125.663 E.04193
G1 X73.994 Y125.663 E.45204
G1 X73.994 Y128.392 E.08386
G1 X88.706 Y128.392 E.45204
G1 X88.706 Y127.087 E.04009
G1 X88.329 Y127.027 F30000
G1 F12000
G1 X88.329 Y126.04 E.03034
G1 X74.371 Y126.04 E.42887
G1 X74.371 Y128.015 E.06069
G1 X88.329 Y128.015 E.42887
G1 X88.329 Y127.087 E.0285
G1 X87.952 Y127.027 F30000
G1 F12000
G1 X87.952 Y126.417 E.01876
G1 X74.748 Y126.417 E.4057
G1 X74.748 Y127.638 E.03752
G1 X87.952 Y127.638 E.4057
G1 X87.952 Y127.087 E.01691
G1 X87.552 Y127.027 F30000
; LINE_WIDTH: 0.464855
G1 F12000
G1 X87.552 Y126.816 E.00725
G1 X75.148 Y126.816 E.42649
G1 X75.148 Y127.238 E.01451
G1 X87.552 Y127.238 E.42649
G1 X87.552 Y127.087 E.00519
; WIPE_START
G1 X87.552 Y127.238 E-.05737
G1 X85.703 Y127.238 E-.70263
; WIPE_END
G1 E-.04 F1800
G1 X93.336 Y127.221 Z5.2 F30000
G1 X182.006 Y127.027 Z5.2
G1 Z4.8
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y125.663 E.04193
G1 X167.293 Y125.663 E.45206
G1 X167.288 Y128.392 E.08386
G1 X182.006 Y128.392 E.45224
G1 X182.006 Y127.087 E.04009
G1 X181.629 Y127.027 F30000
G1 F12000
G1 X181.629 Y126.04 E.03034
G1 X167.67 Y126.04 E.42892
G1 X167.666 Y128.015 E.06069
G1 X181.629 Y128.015 E.42904
G1 X181.629 Y127.087 E.0285
G1 X181.252 Y127.027 F30000
G1 F12000
G1 X181.252 Y126.417 E.01876
G1 X168.046 Y126.417 E.40577
G1 X168.043 Y127.638 E.03752
G1 X181.252 Y127.638 E.40585
G1 X181.252 Y127.087 E.01691
G1 X180.852 Y127.027 F30000
; LINE_WIDTH: 0.464855
G1 F12000
G1 X180.852 Y126.816 E.00725
G1 X168.445 Y126.816 E.42661
G1 X168.444 Y127.238 E.01451
G1 X180.852 Y127.238 E.42664
G1 X180.852 Y127.087 E.00519
; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X180.852 Y127.238 E-.05737
G1 X179.003 Y127.238 E-.70263
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 25/33
; update layer progress
M73 L25
M991 S0 P24 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.2 I.404 J1.148 P1  F30000
G1 X182.398 Y126.042 Z5.2
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y136.062 E.33239
G1 X73.602 Y136.062 E3.60896
G1 X73.602 Y126.042 E.33239
G1 X89.098 Y126.042 E.51403
G1 X89.098 Y128.761 E.09021
G2 X94.902 Y128.757 I2.902 J-.019 E.30131
G1 X94.902 Y126.042 E.09006
G1 X107.098 Y126.042 E.40456
G1 X107.098 Y128.757 E.09007
G2 X112.902 Y128.762 I2.902 J-.008 E.30175
G1 X112.902 Y126.042 E.09023
G1 X125.098 Y126.042 E.40456
G1 X125.098 Y128.757 E.09007
G2 X130.902 Y128.762 I2.902 J-.009 E.30168
G1 X130.902 Y126.042 E.09023
G1 X143.098 Y126.042 E.40456
G1 X143.098 Y128.757 E.09006
G2 X148.902 Y128.762 I2.902 J-.009 E.30169
G1 X148.902 Y126.042 E.09023
G1 X161.098 Y126.042 E.40456
G1 X161.098 Y128.757 E.09006
G2 X166.902 Y128.762 I2.902 J-.008 E.30176
G1 X166.902 Y126.042 E.09023
G1 X182.338 Y126.042 E.51204
; WIPE_START
G1 X182.35 Y128.042 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y124.403 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y136.454 E.37031
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y136.454 E3.36709
G1 X73.21 Y124.403 E.37031
G1 X89.49 Y124.403 E.50024
G1 X89.49 Y128.754 E.1337
G2 X94.51 Y128.752 I2.51 J-.011 E.24167
G1 X94.51 Y124.403 E.13365
G1 X107.49 Y124.403 E.39884
G1 X107.49 Y128.752 E.13365
G2 X112.51 Y128.754 I2.51 J-.003 E.24206
G1 X112.51 Y124.403 E.13371
G1 X125.49 Y124.403 E.39884
G1 X125.49 Y128.752 E.13365
G2 X130.51 Y128.754 I2.51 J-.004 E.24199
G1 X130.51 Y124.403 E.13371
G1 X143.49 Y124.403 E.39884
G1 X143.49 Y128.752 E.13365
G2 X148.51 Y128.754 I2.51 J-.004 E.24199
G1 X148.51 Y124.403 E.13371
G1 X161.49 Y124.403 E.39884
G1 X161.49 Y128.752 E.13365
G2 X166.51 Y128.754 I2.51 J-.003 E.24206
G1 X166.51 Y124.403 E.13371
G1 X182.73 Y124.403 E.4984
M204 S10000
G1 X182.583 Y125.391 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.802 Y124.61 E.03392
G1 X181.269 Y124.61
G1 X182.478 Y125.819 E.05255
G1 X181.945 Y125.819
G1 X180.736 Y124.61 E.05255
G1 X180.202 Y124.61
G1 X181.412 Y125.819 E.05255
G1 X180.878 Y125.819
G1 X179.669 Y124.61 E.05255
G1 X179.136 Y124.61
G1 X180.345 Y125.819 E.05255
G1 X179.812 Y125.819
G1 X178.603 Y124.61 E.05255
G1 X178.069 Y124.61
G1 X179.279 Y125.819 E.05255
G1 X178.745 Y125.819
G1 X177.536 Y124.61 E.05255
G1 X177.003 Y124.61
G1 X178.212 Y125.819 E.05255
G1 X177.679 Y125.819
G1 X176.47 Y124.61 E.05255
G1 X175.936 Y124.61
G1 X177.146 Y125.819 E.05255
G1 X176.612 Y125.819
G1 X175.403 Y124.61 E.05255
G1 X174.87 Y124.61
G1 X176.079 Y125.819 E.05255
G1 X175.546 Y125.819
G1 X174.337 Y124.61 E.05255
G1 X173.803 Y124.61
G1 X175.013 Y125.819 E.05255
G1 X174.479 Y125.819
G1 X173.27 Y124.61 E.05255
G1 X172.737 Y124.61
G1 X173.946 Y125.819 E.05255
G1 X173.413 Y125.819
G1 X172.203 Y124.61 E.05255
G1 X171.67 Y124.61
G1 X172.88 Y125.819 E.05255
G1 X172.346 Y125.819
G1 X171.137 Y124.61 E.05255
G1 X170.604 Y124.61
G1 X171.813 Y125.819 E.05255
G1 X171.28 Y125.819
G1 X170.07 Y124.61 E.05255
G1 X169.537 Y124.61
G1 X170.747 Y125.819 E.05255
G1 X170.213 Y125.819
G1 X169.004 Y124.61 E.05255
G1 X168.471 Y124.61
G1 X169.68 Y125.819 E.05255
G1 X169.147 Y125.819
G1 X167.937 Y124.61 E.05255
G1 X167.404 Y124.61
G1 X168.614 Y125.819 E.05255
G1 X168.08 Y125.819
G1 X166.871 Y124.61 E.05255
G1 X166.717 Y124.99
G1 X167.547 Y125.819 E.03605
; WIPE_START
M204 S10000
G1 X166.717 Y124.99 E-.44583
G1 X166.871 Y124.61 E-.15565
G1 X167.166 Y124.905 E-.15853
; WIPE_END
G1 E-.04 F1800
G1 X167.17 Y129.488 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X166.95 Y130.128 E.01874
G1 X166.678 Y130.607 E.01526
G1 X166.335 Y131.014 E.01475
G1 X165.846 Y131.438 E.01793
G1 X165.389 Y131.698 E.01455
G1 X164.974 Y131.848 E.01222
; Slow Down End
; WIPE_START
G1 X165.389 Y131.698 E-.16765
G1 X165.846 Y131.438 E-.19961
G1 X166.335 Y131.014 E-.24598
G1 X166.584 Y130.719 E-.14676
; WIPE_END
G1 E-.04 F1800
G1 X167.293 Y126.434 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; LINE_WIDTH: 0.419947
G1 F12000
G1 X182.006 Y126.434 E.45202
G2 X182.008 Y128.58 I442.465 J.729 E.06594
; Slow Down Start
; LINE_WIDTH: 0.41328
G1 F3000;_EXTRUDE_SET_SPEED
G2 X182.035 Y129.538 I6.04 J.305 E.02894
G1 X181.876 Y129.352 E.00737
G1 X167.657 Y129.349 E.42913
G1 X167.325 Y129.357 E.01
G1 X167.17 Y129.488 E.00613
G1 X167.286 Y128.977 E.01581
G1 X167.287 Y128.58 E.01199
; Slow Down End
; LINE_WIDTH: 0.41999
G1 F12000
G1 X167.293 Y126.494 E.0641
G1 X181.629 Y127.892 F30000
G1 F12000
G1 X181.629 Y126.811 E.0332
G1 X167.669 Y126.811 E.42893
G1 X167.663 Y128.972 E.06641
G1 X181.629 Y128.972 E.42912
G1 X181.629 Y127.952 E.03136
G1 X181.252 Y127.892 F30000
G1 F12000
G1 X181.252 Y127.188 E.02162
G1 X168.045 Y127.188 E.4058
G1 X168.041 Y128.595 E.04323
G1 X181.252 Y128.595 E.40592
G1 X181.252 Y127.952 E.01977
G1 X180.806 Y127.892 F30000
; LINE_WIDTH: 0.5579
G1 F12000
G1 X180.806 Y127.634 E.01081
M73 P86 R4
G1 X168.49 Y127.634 E.51683
G1 X168.488 Y128.149 E.02161
G1 X180.806 Y128.149 E.51689
G1 X180.806 Y127.952 E.00829
G1 X182.035 Y130.903 F30000
; LINE_WIDTH: 0.38292
G1 F12000
G1 X182.035 Y129.598 E.03616
G1 X182.006 Y134.939 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y134.208 E.02246
G1 X73.994 Y134.208 E3.31882
G1 X73.994 Y135.67 E.04492
G1 X182.006 Y135.67 E3.31882
G1 X182.006 Y134.999 E.02061
G1 X181.629 Y134.939 F30000
G1 F12000
G1 X181.629 Y134.585 E.01087
G1 X74.371 Y134.585 E3.29564
G1 X74.371 Y135.293 E.02174
G1 X181.629 Y135.293 E3.29564
G1 X181.629 Y134.999 E.00903
G1 X74.725 Y134.939 F30000
; LINE_WIDTH: 0.3735
G1 F12000
G1 X181.215 Y134.939 E2.86864
; WIPE_START
G1 X179.215 Y134.939 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X172.53 Y131.255 Z5.4 F30000
G1 X160.472 Y124.61 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X161.283 Y125.421 E.03523
G1 X161.148 Y125.819
G1 X159.939 Y124.61 E.05255
G1 X159.405 Y124.61
G1 X160.615 Y125.819 E.05255
G1 X160.081 Y125.819
G1 X158.872 Y124.61 E.05255
G1 X158.339 Y124.61
G1 X159.548 Y125.819 E.05255
G1 X159.015 Y125.819
G1 X157.806 Y124.61 E.05255
G1 X157.272 Y124.61
G1 X158.482 Y125.819 E.05255
G1 X157.948 Y125.819
G1 X156.739 Y124.61 E.05255
G1 X156.206 Y124.61
G1 X157.415 Y125.819 E.05255
G1 X156.882 Y125.819
G1 X155.673 Y124.61 E.05255
G1 X155.139 Y124.61
G1 X156.349 Y125.819 E.05255
G1 X155.815 Y125.819
G1 X154.606 Y124.61 E.05255
G1 X154.073 Y124.61
G1 X155.282 Y125.819 E.05255
G1 X154.749 Y125.819
G1 X153.539 Y124.61 E.05255
G1 X153.006 Y124.61
G1 X154.216 Y125.819 E.05255
G1 X153.682 Y125.819
G1 X152.473 Y124.61 E.05255
G1 X151.94 Y124.61
G1 X153.149 Y125.819 E.05255
G1 X152.616 Y125.819
G1 X151.406 Y124.61 E.05255
G1 X150.873 Y124.61
G1 X152.083 Y125.819 E.05255
G1 X151.549 Y125.819
G1 X150.34 Y124.61 E.05255
G1 X149.807 Y124.61
G1 X151.016 Y125.819 E.05255
G1 X150.483 Y125.819
G1 X149.273 Y124.61 E.05255
G1 X148.74 Y124.61
G1 X149.95 Y125.819 E.05255
G1 X149.416 Y125.819
G1 X148.717 Y125.121 E.03037
; WIPE_START
M204 S10000
G1 X149.416 Y125.819 E-.37556
G1 X149.95 Y125.819 E-.20264
G1 X149.611 Y125.481 E-.1818
; WIPE_END
G1 E-.04 F1800
G1 X149.293 Y126.434 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X160.706 Y126.434 E.35069
G1 X160.709 Y128.58 E.06595
G2 X160.775 Y129.349 I2.636 J.16 E.0238
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X149.234 Y129.349 E.35461
G2 X149.287 Y128.58 I-2.811 J-.579 E.02376
; Slow Down End
G1 F12000
G1 X149.293 Y126.494 E.0641
G1 X149.669 Y126.811 F30000
G1 F12000
G1 X160.33 Y126.811 E.32756
G1 X160.332 Y128.58 E.05436
G2 X160.337 Y128.972 I2.59 J.16 E.01206
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X149.663 Y128.972 E.32798
G1 X149.664 Y128.58 E.01205
; Slow Down End
G1 F12000
G1 X149.669 Y126.871 E.05252
G1 X150.045 Y127.188 F30000
G1 F12000
G1 X159.953 Y127.188 E.30444
G1 X159.955 Y128.595 E.04323
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X150.041 Y128.595 E.30461
G1 X150.041 Y128.58 E.00046
; Slow Down End
G1 F12000
G1 X150.045 Y127.248 E.04093
G1 X150.49 Y127.634 F30000
; LINE_WIDTH: 0.5579
G1 F12000
G1 X150.488 Y128.149 E.02161
G1 X159.508 Y128.149 E.37851
G1 X159.508 Y127.634 E.02161
G1 X150.55 Y127.634 E.37591
; WIPE_START
G1 X152.55 Y127.634 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.204 Y125.561 Z5.4 F30000
G1 X143.283 Y125.018 Z5.4
G1 Z5
M73 P86 R3
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X142.874 Y124.61 E.01774
G1 X142.341 Y124.61
G1 X143.283 Y125.552 E.04091
G1 X143.017 Y125.819
G1 X141.808 Y124.61 E.05255
G1 X141.275 Y124.61
G1 X142.484 Y125.819 E.05255
G1 X141.951 Y125.819
G1 X140.741 Y124.61 E.05255
G1 X140.208 Y124.61
G1 X141.417 Y125.819 E.05255
G1 X140.884 Y125.819
G1 X139.675 Y124.61 E.05255
G1 X139.142 Y124.61
G1 X140.351 Y125.819 E.05255
G1 X139.818 Y125.819
G1 X138.608 Y124.61 E.05255
G1 X138.075 Y124.61
G1 X139.284 Y125.819 E.05255
G1 X138.751 Y125.819
G1 X137.542 Y124.61 E.05255
G1 X137.009 Y124.61
G1 X138.218 Y125.819 E.05255
G1 X137.685 Y125.819
G1 X136.475 Y124.61 E.05255
G1 X135.942 Y124.61
G1 X137.151 Y125.819 E.05255
G1 X136.618 Y125.819
G1 X135.409 Y124.61 E.05255
G1 X134.875 Y124.61
G1 X136.085 Y125.819 E.05255
G1 X135.552 Y125.819
G1 X134.342 Y124.61 E.05255
G1 X133.809 Y124.61
G1 X135.018 Y125.819 E.05255
G1 X134.485 Y125.819
G1 X133.276 Y124.61 E.05255
G1 X132.742 Y124.61
G1 X133.952 Y125.819 E.05255
G1 X133.419 Y125.819
G1 X132.209 Y124.61 E.05255
G1 X131.676 Y124.61
G1 X132.885 Y125.819 E.05255
G1 X132.352 Y125.819
G1 X131.143 Y124.61 E.05255
G1 X130.717 Y124.718
G1 X131.819 Y125.819 E.04786
G1 X131.285 Y125.819
G1 X130.717 Y125.251 E.02469
; WIPE_START
M204 S10000
G1 X131.285 Y125.819 E-.30529
G1 X131.819 Y125.819 E-.20264
G1 X131.35 Y125.35 E-.25207
; WIPE_END
G1 E-.04 F1800
G1 X131.234 Y129.349 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G2 X131.287 Y128.58 I-2.812 J-.579 E.02376
; Slow Down End
G1 F12000
G1 X131.293 Y126.434 E.06595
G1 X142.706 Y126.434 E.35068
G2 X142.707 Y128.781 I1432.397 J.631 E.07213
G1 X142.762 Y129.349 E.01753
G1 X131.294 Y129.349 E.35237
G1 X131.663 Y128.972 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.664 Y128.58 E.01205
; Slow Down End
G1 F12000
G1 X131.669 Y126.811 E.05436
G1 X142.329 Y126.811 E.32754
G2 X142.347 Y128.972 I86.776 J.368 E.06641
G1 X131.723 Y128.972 E.32643
G1 X132.041 Y128.595 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X132.041 Y128.58 E.00046
; Slow Down End
G1 F12000
G1 X132.045 Y127.188 E.04277
G1 X141.952 Y127.188 E.3044
G1 X141.952 Y128.595 E.04323
G1 X132.101 Y128.595 E.30268
G1 X132.488 Y128.149 F30000
; LINE_WIDTH: 0.5579
G1 F12000
G1 X141.506 Y128.149 E.37841
G1 X141.506 Y127.634 E.02161
G1 X132.49 Y127.634 E.37835
G1 X132.488 Y128.089 E.01909
; WIPE_START
G1 X132.49 Y127.634 E-.1729
G1 X134.035 Y127.634 E-.5871
; WIPE_END
G1 E-.04 F1800
G1 X126.693 Y125.549 Z5.4 F30000
G1 X125.283 Y125.149 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X124.744 Y124.61 E.02342
G1 X124.21 Y124.61
G1 X125.283 Y125.682 E.0466
G1 X124.886 Y125.819
G1 X123.677 Y124.61 E.05255
G1 X123.144 Y124.61
G1 X124.353 Y125.819 E.05255
G1 X123.82 Y125.819
G1 X122.611 Y124.61 E.05255
G1 X122.077 Y124.61
G1 X123.287 Y125.819 E.05255
G1 X122.753 Y125.819
G1 X121.544 Y124.61 E.05255
G1 X121.011 Y124.61
G1 X122.22 Y125.819 E.05255
G1 X121.687 Y125.819
G1 X120.478 Y124.61 E.05255
G1 X119.944 Y124.61
G1 X121.154 Y125.819 E.05255
G1 X120.62 Y125.819
G1 X119.411 Y124.61 E.05255
G1 X118.878 Y124.61
G1 X120.087 Y125.819 E.05255
G1 X119.554 Y125.819
G1 X118.344 Y124.61 E.05255
G1 X117.811 Y124.61
G1 X119.021 Y125.819 E.05255
G1 X118.487 Y125.819
G1 X117.278 Y124.61 E.05255
G1 X116.745 Y124.61
G1 X117.954 Y125.819 E.05255
G1 X117.421 Y125.819
G1 X116.211 Y124.61 E.05255
G1 X115.678 Y124.61
G1 X116.888 Y125.819 E.05255
G1 X116.354 Y125.819
G1 X115.145 Y124.61 E.05255
G1 X114.612 Y124.61
G1 X115.821 Y125.819 E.05255
G1 X115.288 Y125.819
G1 X114.078 Y124.61 E.05255
G1 X113.545 Y124.61
G1 X114.755 Y125.819 E.05255
G1 X114.221 Y125.819
G1 X113.012 Y124.61 E.05255
G1 X112.717 Y124.849
G1 X113.688 Y125.819 E.04218
G1 X113.155 Y125.819
G1 X112.717 Y125.382 E.019
; WIPE_START
M204 S10000
G1 X113.155 Y125.819 E-.23503
G1 X113.688 Y125.819 E-.20264
G1 X113.088 Y125.22 E-.32233
; WIPE_END
G1 E-.04 F1800
G1 X113.293 Y126.434 Z5.4 F30000
G1 Z5
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.706 Y126.434 E.35068
G2 X124.707 Y128.782 I1477.189 J.614 E.07214
G1 X124.762 Y129.349 E.01752
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.234 Y129.349 E.35421
G2 X113.287 Y128.58 I-2.812 J-.579 E.02376
; Slow Down End
G1 F12000
G1 X113.293 Y126.494 E.0641
G1 X113.669 Y126.811 F30000
G1 F12000
G1 X124.329 Y126.811 E.32754
G2 X124.347 Y128.972 I87.012 J.368 E.06641
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.663 Y128.972 E.32827
G1 X113.664 Y128.58 E.01205
; Slow Down End
G1 F12000
G1 X113.669 Y126.871 E.05252
G1 X114.045 Y127.188 F30000
G1 F12000
G1 X123.952 Y127.188 E.3044
G1 X123.952 Y128.595 E.04323
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X114.041 Y128.595 E.30452
G1 X114.041 Y128.58 E.00046
; Slow Down End
G1 F12000
G1 X114.045 Y127.248 E.04093
G1 X114.49 Y127.634 F30000
; LINE_WIDTH: 0.5579
G1 F12000
G1 X114.488 Y128.149 E.02161
G1 X123.506 Y128.149 E.37841
G1 X123.506 Y127.634 E.02161
G1 X114.55 Y127.634 E.37583
; WIPE_START
G1 X116.55 Y127.634 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X109.152 Y125.755 Z5.4 F30000
G1 X107.283 Y125.28 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.613 Y124.61 E.02911
G1 X106.08 Y124.61
G1 X107.283 Y125.813 E.05228
G1 X106.756 Y125.819
G1 X105.546 Y124.61 E.05255
G1 X105.013 Y124.61
G1 X106.222 Y125.819 E.05255
G1 X105.689 Y125.819
G1 X104.48 Y124.61 E.05255
G1 X103.947 Y124.61
G1 X105.156 Y125.819 E.05255
G1 X104.623 Y125.819
G1 X103.413 Y124.61 E.05255
G1 X102.88 Y124.61
G1 X104.089 Y125.819 E.05255
G1 X103.556 Y125.819
G1 X102.347 Y124.61 E.05255
G1 X101.814 Y124.61
G1 X103.023 Y125.819 E.05255
G1 X102.49 Y125.819
G1 X101.28 Y124.61 E.05255
G1 X100.747 Y124.61
G1 X101.956 Y125.819 E.05255
G1 X101.423 Y125.819
G1 X100.214 Y124.61 E.05255
G1 X99.68 Y124.61
G1 X100.89 Y125.819 E.05255
G1 X100.357 Y125.819
G1 X99.147 Y124.61 E.05255
G1 X98.614 Y124.61
G1 X99.823 Y125.819 E.05255
G1 X99.29 Y125.819
G1 X98.081 Y124.61 E.05255
G1 X97.547 Y124.61
G1 X98.757 Y125.819 E.05255
G1 X98.224 Y125.819
G1 X97.014 Y124.61 E.05255
G1 X96.481 Y124.61
G1 X97.69 Y125.819 E.05255
G1 X97.157 Y125.819
G1 X95.948 Y124.61 E.05255
G1 X95.414 Y124.61
G1 X96.624 Y125.819 E.05255
G1 X96.09 Y125.819
G1 X94.881 Y124.61 E.05255
G1 X94.717 Y124.98
G1 X95.557 Y125.819 E.0365
M204 S10000
G1 X95.294 Y126.434 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X106.706 Y126.434 E.35065
G2 X106.707 Y128.782 I1477.149 J.614 E.07214
G1 X106.762 Y129.349 E.01752
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X95.233 Y129.349 E.35425
G2 X95.291 Y128.58 I-2.997 J-.613 E.02376
; Slow Down End
G1 F12000
G1 X95.294 Y126.494 E.0641
G1 X106.329 Y127.892 F30000
G1 F12000
G1 X106.329 Y126.811 E.0332
G1 X95.67 Y126.811 E.3275
G1 X95.668 Y128.58 E.05436
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G3 X95.663 Y128.972 I-3.058 J.156 E.01205
; Slow Down End
G1 F12000
G1 X106.347 Y128.972 E.32826
G1 X106.33 Y127.952 E.03136
G1 X105.952 Y127.188 F30000
G1 F12000
G1 X96.047 Y127.188 E.30434
G1 X96.046 Y128.58 E.04277
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X96.045 Y128.595 E.00046
; Slow Down End
G1 F12000
G1 X105.952 Y128.595 E.30438
G1 X105.952 Y127.248 E.04139
G1 X105.506 Y127.634 F30000
; LINE_WIDTH: 0.5579
G1 F12000
G1 X96.493 Y127.634 E.37823
G1 X96.492 Y128.149 E.02161
G1 X105.506 Y128.149 E.37826
G1 X105.506 Y127.694 E.01909
; WIPE_START
G1 X105.506 Y128.149 E-.1729
G1 X103.961 Y128.149 E-.5871
; WIPE_END
G1 E-.04 F1800
G1 X96.635 Y130.291 Z5.4 F30000
G1 X91.153 Y131.894 Z5.4
G1 Z5
G1 E.8 F1800
; Slow Down Start
; LINE_WIDTH: 0.382968
G1 F3000;_EXTRUDE_SET_SPEED
G1 X90.845 Y131.794 E.009
G1 X90.272 Y131.507 E.01775
G1 X89.835 Y131.187 E.01501
G1 X89.384 Y130.699 E.01842
G1 X89.035 Y130.106 E.01907
G1 X88.832 Y129.519 E.01721
; Slow Down End
G1 X73.994 Y127.892 F30000
; LINE_WIDTH: 0.419131
G1 F12000
G1 X73.994 Y126.434 E.04469
G1 X88.706 Y126.434 E.45101
G2 X88.707 Y128.79 I1134.411 J.624 E.07221
G1 X88.813 Y129.462 E.02087
; Slow Down Start
; LINE_WIDTH: 0.415841
G1 F3000;_EXTRUDE_SET_SPEED
G1 X88.671 Y129.36 E.00532
G1 X88.206 Y129.349 E.01413
G1 X74.124 Y129.352 E.42793
G1 X73.965 Y129.538 E.00742
G2 X73.992 Y128.58 I-6.013 J-.653 E.02914
; Slow Down End
; LINE_WIDTH: 0.418932
G1 F12000
G1 X73.994 Y127.952 E.01926
G1 X74.371 Y126.811 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.329 Y126.811 E.42887
G2 X88.348 Y128.972 I80.604 J.368 E.06641
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X74.371 Y128.972 E.42945
G1 X74.371 Y128.58 E.01205
; Slow Down End
G1 F12000
G1 X74.371 Y126.871 E.05252
G1 X74.748 Y127.188 F30000
G1 F12000
G1 X87.952 Y127.188 E.4057
G1 X87.952 Y128.595 E.04323
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X74.748 Y128.595 E.4057
G1 X74.748 Y128.58 E.00046
; Slow Down End
G1 F12000
G1 X74.748 Y127.248 E.04093
G1 X75.194 Y127.634 F30000
; LINE_WIDTH: 0.5579
G1 F12000
G1 X75.194 Y128.149 E.02161
G1 X87.506 Y128.149 E.51664
G1 X87.506 Y127.634 E.02161
G1 X75.254 Y127.634 E.51412
G1 X73.965 Y130.899 F30000
; LINE_WIDTH: 0.38292
G1 F12000
G1 X73.965 Y129.598 E.03605
G1 X73.95 Y131.73 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X73.95 Y133.358 E.05401
M73 P87 R3
G1 X74.409 Y133.816 E.0215
G1 X74.128 Y133.816 E.00932
G1 X78.203 Y129.741 E.19117
G1 X78.01 Y129.741 E.00642
G1 X82.085 Y133.816 E.19117
G1 X81.804 Y133.816 E.00932
G1 X85.879 Y129.741 E.19117
G1 X85.685 Y129.741 E.00642
G1 X89.761 Y133.816 E.19117
G1 X89.48 Y133.816 E.00932
G1 X91.045 Y132.251 E.07343
G2 X91.509 Y132.333 I.49 J-1.424 E.01569
G1 X91.507 Y131.95 E.01271
G2 X94.474 Y130.854 I.506 J-3.194 E.10963
G1 X97.437 Y133.816 E.13898
G1 X97.156 Y133.816 E.00932
G1 X101.231 Y129.741 E.19117
G1 X101.037 Y129.741 E.00642
G1 X105.113 Y133.816 E.19117
G1 X104.832 Y133.816 E.00932
G1 X107.652 Y130.996 E.13231
G2 X110.851 Y131.879 I2.353 J-2.288 E.11541
G1 X112.789 Y133.816 E.0909
G1 X112.508 Y133.816 E.00932
G1 X116.583 Y129.741 E.19117
G1 X116.389 Y129.741 E.00642
G1 X120.464 Y133.816 E.19117
G1 X120.184 Y133.816 E.00932
G1 X124.259 Y129.741 E.19117
G1 X124.065 Y129.741 E.00642
G1 X128.14 Y133.816 E.19117
G1 X127.86 Y133.816 E.00932
G1 X131.935 Y129.741 E.19117
G1 X131.741 Y129.741 E.00642
G1 X135.816 Y133.816 E.19117
G1 X135.536 Y133.816 E.00932
G1 X139.611 Y129.741 E.19118
G1 X139.417 Y129.741 E.00642
G1 X143.492 Y133.816 E.19117
G1 X143.211 Y133.816 E.00932
G1 X145.142 Y131.886 E.09055
G2 X148.344 Y130.992 I.84 J-3.172 E.11565
G1 X151.168 Y133.816 E.13251
G1 X150.887 Y133.816 E.00932
G1 X154.963 Y129.741 E.19117
G1 X154.769 Y129.741 E.00642
G1 X158.844 Y133.816 E.19117
G1 X158.563 Y133.816 E.00932
G1 X161.528 Y130.852 E.13907
G2 X164.506 Y131.959 I2.532 J-2.251 E.1097
G1 X164.496 Y132.354 E.01311
G1 X164.951 Y132.247 E.01549
G1 X166.52 Y133.816 E.07362
G1 X166.239 Y133.816 E.00932
G1 X170.315 Y129.741 E.19117
G1 X170.121 Y129.741 E.00642
G1 X174.196 Y133.816 E.19117
G1 X173.915 Y133.816 E.00932
G1 X177.99 Y129.741 E.19117
G1 X177.797 Y129.741 E.00642
G1 X181.872 Y133.816 E.19117
G1 X181.591 Y133.816 E.00932
G1 X182.05 Y133.358 E.02151
G1 X182.05 Y131.73 E.05401
; WIPE_START
G1 X182.05 Y133.358 E-.61876
G1 X181.787 Y133.621 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X174.184 Y132.946 Z5.4 F30000
G1 X89.283 Y125.411 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.482 Y124.61 E.03479
G1 X87.949 Y124.61
G1 X89.158 Y125.819 E.05255
G1 X88.625 Y125.819
G1 X87.416 Y124.61 E.05255
G1 X86.882 Y124.61
G1 X88.092 Y125.819 E.05255
G1 X87.558 Y125.819
G1 X86.349 Y124.61 E.05255
G1 X85.816 Y124.61
G1 X87.025 Y125.819 E.05255
G1 X86.492 Y125.819
G1 X85.283 Y124.61 E.05255
G1 X84.749 Y124.61
G1 X85.959 Y125.819 E.05255
G1 X85.425 Y125.819
G1 X84.216 Y124.61 E.05255
G1 X83.683 Y124.61
G1 X84.892 Y125.819 E.05255
G1 X84.359 Y125.819
G1 X83.149 Y124.61 E.05255
G1 X82.616 Y124.61
G1 X83.826 Y125.819 E.05255
G1 X83.292 Y125.819
G1 X82.083 Y124.61 E.05255
G1 X81.55 Y124.61
G1 X82.759 Y125.819 E.05255
G1 X82.226 Y125.819
G1 X81.016 Y124.61 E.05255
G1 X80.483 Y124.61
G1 X81.693 Y125.819 E.05255
G1 X81.159 Y125.819
G1 X79.95 Y124.61 E.05255
G1 X79.417 Y124.61
G1 X80.626 Y125.819 E.05255
G1 X80.093 Y125.819
G1 X78.883 Y124.61 E.05255
G1 X78.35 Y124.61
G1 X79.56 Y125.819 E.05255
G1 X79.026 Y125.819
G1 X77.817 Y124.61 E.05255
G1 X77.284 Y124.61
G1 X78.493 Y125.819 E.05255
G1 X77.96 Y125.819
G1 X76.75 Y124.61 E.05255
G1 X76.217 Y124.61
G1 X77.426 Y125.819 E.05255
G1 X76.893 Y125.819
G1 X75.684 Y124.61 E.05255
G1 X75.151 Y124.61
G1 X76.36 Y125.819 E.05255
G1 X75.827 Y125.819
G1 X74.617 Y124.61 E.05255
G1 X74.084 Y124.61
G1 X75.293 Y125.819 E.05255
G1 X74.76 Y125.819
G1 X73.551 Y124.61 E.05255
G1 X73.417 Y125.01
G1 X74.227 Y125.819 E.03518
; CHANGE_LAYER
; Z_HEIGHT: 5.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
M204 S10000
G1 X73.417 Y125.01 E-.43505
G1 X73.551 Y124.61 E-.16016
G1 X73.858 Y124.917 E-.16479
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 26/33
; update layer progress
M73 L26
M991 S0 P25 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.4 I-.021 J1.217 P1  F30000
G1 X182.398 Y126.813 Z5.4
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y135.608 E.29173
G1 X73.602 Y135.608 E3.60896
G1 X73.602 Y126.813 E.29173
G1 X89.098 Y126.813 E.51403
G1 X89.098 Y128.757 E.06449
G2 X94.902 Y128.763 I2.902 J-.011 E.30156
G1 X94.902 Y126.813 E.06466
G1 X107.098 Y126.813 E.40456
G2 X107.101 Y128.889 I43.182 J.972 E.06887
G2 X112.902 Y128.757 I2.899 J-.141 E.29747
G1 X112.902 Y126.813 E.06447
G1 X125.098 Y126.813 E.40456
G2 X125.101 Y128.889 I43.182 J.972 E.06887
G2 X130.902 Y128.757 I2.899 J-.14 E.29755
G1 X130.902 Y126.813 E.06447
G1 X143.098 Y126.813 E.40456
G2 X143.101 Y128.889 I43.312 J.972 E.06887
G2 X148.902 Y128.757 I2.899 J-.14 E.29755
G1 X148.902 Y126.813 E.06447
G1 X161.098 Y126.813 E.40456
G2 X161.101 Y128.889 I43.319 J.972 E.06887
G2 X166.902 Y128.757 I2.899 J-.141 E.29747
G1 X166.902 Y126.813 E.06447
G1 X182.338 Y126.813 E.51204
; WIPE_START
G1 X182.352 Y128.813 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y125.174 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y136 E.33264
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y136 E3.36709
G1 X73.21 Y125.174 E.33264
G1 X89.49 Y125.174 E.50024
G1 X89.49 Y128.752 E.10995
G2 X94.51 Y128.754 I2.51 J-.005 E.24191
G1 X94.51 Y125.174 E.11001
G1 X107.49 Y125.174 E.39884
G1 X107.49 Y128.752 E.10995
G2 X112.51 Y128.752 I2.51 J-.007 E.24186
G1 X112.51 Y125.174 E.10995
G1 X125.49 Y125.174 E.39884
G1 X125.49 Y128.752 E.10995
G2 X130.51 Y128.752 I2.51 J-.005 E.24197
G1 X130.51 Y125.174 E.10995
G1 X143.49 Y125.174 E.39884
G1 X143.49 Y128.752 E.10995
G2 X148.51 Y128.752 I2.51 J-.005 E.24197
G1 X148.51 Y125.174 E.10995
G1 X161.49 Y125.174 E.39884
G1 X161.49 Y128.752 E.10995
G2 X166.51 Y128.752 I2.51 J-.009 E.24176
G1 X166.51 Y125.174 E.10995
G1 X182.73 Y125.174 E.4984
M204 S10000
G1 X182.583 Y126.076 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.068 Y126.591 E.02236
G1 X181.535 Y126.591
G1 X182.583 Y125.543 E.04553
G1 X182.211 Y125.381
G1 X181.002 Y126.591 E.05255
G1 X180.468 Y126.591
G1 X181.678 Y125.381 E.05255
G1 X181.144 Y125.381
G1 X179.935 Y126.591 E.05255
G1 X179.402 Y126.591
G1 X180.611 Y125.381 E.05255
G1 X180.078 Y125.381
G1 X178.868 Y126.591 E.05255
G1 X178.335 Y126.591
G1 X179.545 Y125.381 E.05255
G1 X179.011 Y125.381
G1 X177.802 Y126.591 E.05255
G1 X177.269 Y126.591
G1 X178.478 Y125.381 E.05255
G1 X177.945 Y125.381
G1 X176.735 Y126.591 E.05255
G1 X176.202 Y126.591
G1 X177.412 Y125.381 E.05255
G1 X176.878 Y125.381
G1 X175.669 Y126.591 E.05255
G1 X175.136 Y126.591
G1 X176.345 Y125.381 E.05255
G1 X175.812 Y125.381
G1 X174.602 Y126.591 E.05255
G1 X174.069 Y126.591
G1 X175.278 Y125.381 E.05255
G1 X174.745 Y125.381
G1 X173.536 Y126.591 E.05255
G1 X173.003 Y126.591
G1 X174.212 Y125.381 E.05255
G1 X173.679 Y125.381
G1 X172.469 Y126.591 E.05255
G1 X171.936 Y126.591
G1 X173.145 Y125.381 E.05255
G1 X172.612 Y125.381
G1 X171.403 Y126.591 E.05255
G1 X170.87 Y126.591
G1 X172.079 Y125.381 E.05255
G1 X171.546 Y125.381
G1 X170.336 Y126.591 E.05255
G1 X169.803 Y126.591
G1 X171.012 Y125.381 E.05255
G1 X170.479 Y125.381
G1 X169.27 Y126.591 E.05255
G1 X168.737 Y126.591
G1 X169.946 Y125.381 E.05255
G1 X169.413 Y125.381
G1 X168.203 Y126.591 E.05255
G1 X167.67 Y126.591
G1 X168.879 Y125.381 E.05255
G1 X168.346 Y125.381
G1 X167.137 Y126.591 E.05255
G1 X166.717 Y126.477
G1 X167.813 Y125.381 E.0476
G1 X167.28 Y125.381
G1 X166.717 Y125.944 E.02443
; WIPE_START
M204 S10000
G1 X167.28 Y125.381 E-.30214
G1 X167.813 Y125.381 E-.20264
G1 X167.338 Y125.856 E-.25522
; WIPE_END
G1 E-.04 F1800
G1 X167.294 Y127.205 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X167.294 Y128.674 E.04512
G1 X182.006 Y128.674 E.45204
G1 X182.006 Y127.205 E.04512
G1 X167.354 Y127.205 E.4502
G1 X167.671 Y127.582 F30000
G1 F15000
G1 X167.671 Y128.297 E.02195
G1 X181.629 Y128.297 E.42887
G1 X181.629 Y127.582 E.02195
G1 X167.731 Y127.582 E.42702
G1 X168.028 Y127.94 F30000
; LINE_WIDTH: 0.38029
G1 F15000
G1 X181.212 Y127.94 E.36242
G1 X180.753 Y132.698 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X181.418 Y133.362 E.03116
G1 X180.183 Y132.661 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40138
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X182.028 Y130.815 E.13456
G1 X182.028 Y130.177 E.03291
G1 X180.007 Y132.199 E.14739
G1 X179.687 Y131.879 E.02327
G1 X182.028 Y129.539 E.17066
G1 X182.028 Y129.087 E.02326
G1 X181.841 Y129.087 E.00965
G1 X179.368 Y131.56 E.18028
G1 X179.049 Y131.241 E.02327
G1 X181.203 Y129.087 E.15701
G1 X180.564 Y129.087 E.03291
G1 X175.182 Y134.47 E.39244
G1 X174.543 Y134.47 E.03291
G1 X179.926 Y129.087 E.39244
G1 X179.288 Y129.087 E.03291
G1 X173.905 Y134.47 E.39244
G1 X173.572 Y134.47 E.01719
G1 X173.826 Y133.911 E.03168
G1 X178.649 Y129.087 E.35165
G1 X178.011 Y129.087 E.03291
G1 X173.615 Y133.483 E.32048
G1 X173.296 Y133.164 E.02327
G1 X177.373 Y129.087 E.29721
G1 X176.734 Y129.087 E.03291
G1 X172.977 Y132.845 E.27394
G1 X172.658 Y132.526 E.02327
G1 X176.096 Y129.087 E.25067
G1 X175.458 Y129.087 E.03291
G1 X172.339 Y132.206 E.2274
G1 X172.019 Y131.887 E.02327
G1 X174.819 Y129.087 E.20413
G1 X174.181 Y129.087 E.03291
G1 X171.7 Y131.568 E.18086
G1 X171.381 Y131.249 E.02327
G1 X173.543 Y129.087 E.15759
G1 X172.904 Y129.087 E.03291
G1 X167.522 Y134.47 E.39244
G1 X166.883 Y134.47 E.03291
G1 X172.266 Y129.087 E.39244
G1 X171.627 Y129.087 E.03291
G1 X166.245 Y134.47 E.39244
G1 X165.929 Y134.47 E.01627
G1 X166.189 Y133.888 E.03286
G1 X170.989 Y129.087 E.34999
G1 X170.351 Y129.087 E.03291
G1 X165.947 Y133.491 E.32106
G1 X165.628 Y133.172 E.02327
G1 X169.712 Y129.087 E.29779
G1 X169.074 Y129.087 E.03291
G1 X165.309 Y132.853 E.27452
G1 X164.99 Y132.534 E.02327
G1 X168.436 Y129.087 E.25124
G1 X167.797 Y129.087 E.03291
G1 X167.103 Y129.782 E.05066
G1 X166.892 Y130.281 E.02793
G3 X165.041 Y131.844 I-2.884 J-1.539 E.12789
G1 X164.727 Y132.157 E.02288
G1 X163.94 Y132.013 F30000
; Slow Down Start
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
; LAYER_HEIGHT: 0.2
G1 F3000;_EXTRUDE_SET_SPEED
G3 X162.651 Y131.719 I.138 J-3.588 E.03684
G1 X162.043 Y131.352 E.01969
G3 X161.416 Y130.729 I2.377 J-3.019 E.02454
; Slow Down End
G1 X149.265 Y129.179 F30000
; LINE_WIDTH: 0.418771
G1 F12000
G1 X149.294 Y128.763 E.01276
G1 X149.294 Y127.205 E.04771
G1 X160.708 Y127.205 E.34958
G2 X160.723 Y129.08 I54.342 J.52 E.05742
G1 X160.849 Y129.706 E.01956
G1 X161.148 Y130.397 E.02307
G1 X161.376 Y130.684 E.01122
; Slow Down Start
; LINE_WIDTH: 0.411895
G1 F3000;_EXTRUDE_SET_SPEED
G1 X161.255 Y130.617 E.00417
G1 X161.015 Y130.599 E.00722
G1 X149.564 Y130.599 E.3443
G1 X148.825 Y130.608 E.02223
G1 X148.625 Y130.678 E.00638
G1 X148.799 Y130.475 E.00803
G1 X149.115 Y129.822 E.02181
G1 X149.181 Y129.538 E.00879
; Slow Down End
; LINE_WIDTH: 0.41999
G1 F12000
G1 X149.251 Y129.237 E.00947
G1 X149.632 Y129.265 F30000
G1 F12000
G1 X149.671 Y128.763 E.01545
G1 X149.671 Y127.582 E.03628
G1 X160.333 Y127.582 E.32761
G2 X160.352 Y129.152 I20.78 J.533 E.04824
G1 X160.466 Y129.739 E.01838
G1 X160.661 Y130.222 E.016
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X149.345 Y130.222 E.34769
G2 X149.568 Y129.538 I-1.766 J-.954 E.02224
; Slow Down End
G1 F12000
G1 X149.619 Y129.323 E.00677
G1 X149.999 Y129.351 F30000
G1 F12000
G2 X150.048 Y127.959 I-8.335 J-.989 E.04282
G1 X159.959 Y127.96 E.30451
G1 X159.982 Y129.224 E.03885
G1 X160.107 Y129.845 E.01947
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X149.884 Y129.845 E.31411
G1 X149.956 Y129.538 E.0097
; Slow Down End
G1 F12000
G1 X149.986 Y129.409 E.00406
G1 X159.646 Y129.468 F30000
G1 F12000
G3 X159.584 Y128.337 I5.814 J-.885 E.03487
G1 X150.425 Y128.337 E.2814
G3 X150.359 Y129.468 I-8.085 J.095 E.03485
G1 X159.586 Y129.468 E.28349
G1 X159.214 Y129.091 F30000
; LINE_WIDTH: 0.42006
G1 F12000
G1 X159.209 Y128.714 E.01159
G1 X150.802 Y128.714 E.25835
G1 X150.785 Y129.091 E.0116
G1 X159.154 Y129.091 E.25722
G1 X148.625 Y130.678 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X148.282 Y131.08 E.01465
G1 X147.718 Y131.519 E.01979
G1 X147.166 Y131.793 E.01706
G3 X146.315 Y131.986 I-.987 J-2.381 E.02429
; Slow Down End
G1 X145.364 Y131.941 F30000
; Slow Down Start
; LINE_WIDTH: 0.382929
G1 F3000;_EXTRUDE_SET_SPEED
G1 X144.741 Y131.75 E.01806
G1 X144.264 Y131.516 E.01471
G1 X143.862 Y131.203 E.01411
G1 X143.419 Y130.722 E.01811
; Slow Down End
G1 X131.265 Y129.179 F30000
; LINE_WIDTH: 0.418777
G1 F12000
G1 X131.294 Y128.763 E.01276
G1 X131.294 Y127.205 E.04772
G1 X142.708 Y127.205 E.34958
G2 X142.723 Y129.08 I54.369 J.52 E.05742
G1 X142.849 Y129.706 E.01956
G1 X143.145 Y130.391 E.02286
G1 X143.379 Y130.678 E.01134
; Slow Down Start
; LINE_WIDTH: 0.408398
G1 F3000;_EXTRUDE_SET_SPEED
G1 X143.249 Y130.61 E.00437
G1 X143.008 Y130.599 E.00718
G1 X131.592 Y130.599 E.33997
G1 X130.75 Y130.618 E.0251
G1 X130.651 Y130.66 E.00319
G1 X130.912 Y130.291 E.01344
G1 X131.115 Y129.822 E.01523
G1 X131.181 Y129.538 E.0087
; Slow Down End
; LINE_WIDTH: 0.41999
G1 F12000
G1 X131.251 Y129.237 E.00947
G1 X131.632 Y129.265 F30000
G1 F12000
G1 X131.671 Y128.763 E.01545
G1 X131.671 Y127.582 E.03628
M73 P88 R3
G1 X142.333 Y127.582 E.32761
G2 X142.352 Y129.152 I20.787 J.532 E.04824
G1 X142.466 Y129.739 E.01838
G1 X142.661 Y130.222 E.016
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.355 Y130.222 E.34737
G2 X131.568 Y129.538 I-2.106 J-1.031 E.02211
; Slow Down End
G1 F12000
G1 X131.619 Y129.323 E.00677
G1 X131.884 Y129.845 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.956 Y129.538 E.0097
; Slow Down End
G1 F12000
G1 X131.999 Y129.351 E.0059
G2 X132.048 Y127.959 I-8.334 J-.989 E.04282
G1 X141.959 Y127.96 E.30451
G1 X141.982 Y129.224 E.03885
G1 X142.107 Y129.845 E.01947
G1 X131.944 Y129.845 E.31227
G1 X141.646 Y129.468 F30000
G1 F12000
G3 X141.584 Y128.337 I5.815 J-.885 E.03487
G1 X132.425 Y128.337 E.2814
G3 X132.359 Y129.468 I-8.086 J.095 E.03485
G1 X141.586 Y129.468 E.28349
G1 X141.214 Y129.091 F30000
; LINE_WIDTH: 0.42006
G1 F12000
G1 X141.209 Y128.714 E.01159
G1 X132.802 Y128.714 E.25835
G1 X132.785 Y129.091 E.0116
G1 X141.154 Y129.091 E.25722
G1 X130.636 Y130.677 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X130.28 Y131.08 E.01488
G1 X129.77 Y131.49 E.01812
G1 X129.142 Y131.809 E.01954
G1 X128.241 Y132.014 E.02561
G1 X127.507 Y131.966 E.02036
G1 X126.929 Y131.83 E.01645
G1 X126.346 Y131.556 E.01786
G1 X125.765 Y131.123 E.02006
G1 X125.42 Y130.727 E.01456
; Slow Down End
G1 X125.193 Y130.61 F30000
; Slow Down Start
; LINE_WIDTH: 0.408607
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.592 Y130.599 E.34569
G1 X112.75 Y130.618 E.02511
G1 X112.651 Y130.66 E.00319
G1 X112.912 Y130.292 E.01344
G1 X113.115 Y129.822 E.01524
G1 X113.181 Y129.538 E.0087
; Slow Down End
; LINE_WIDTH: 0.418616
G1 F12000
G2 X113.294 Y128.763 I-2.347 J-.738 E.02406
G1 X113.294 Y127.205 E.04769
G1 X124.706 Y127.205 E.34936
G1 X124.706 Y128.765 E.04774
G1 X124.745 Y129.25 E.01491
G1 X124.959 Y130.016 E.02433
G1 X125.241 Y130.531 E.01798
G1 X125.381 Y130.682 E.0063
G1 X125.249 Y130.631 E.00431
G1 X124.381 Y129.35 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G3 X124.329 Y128.765 I5.173 J-.756 E.01805
G1 X124.329 Y127.582 E.03633
G1 X113.671 Y127.582 E.32747
G1 X113.671 Y128.763 E.03628
G1 X113.632 Y129.265 E.01545
G1 X113.568 Y129.538 E.00861
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G3 X113.355 Y130.222 I-2.318 J-.346 E.02211
; Slow Down End
G1 F12000
G1 X124.641 Y130.222 E.34678
G1 X124.398 Y129.407 E.02613
G1 X113.999 Y129.35 F30000
G1 F12000
G2 X114.048 Y127.959 I-8.338 J-.989 E.04282
G1 X123.952 Y127.959 E.3043
G2 X123.986 Y129.27 I9.582 J.403 E.0403
G1 X124.126 Y129.845 E.01819
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.884 Y129.845 E.31469
G1 X113.956 Y129.538 E.0097
; Slow Down End
G1 F12000
G1 X113.986 Y129.409 E.00406
G1 X123.64 Y129.468 F30000
G1 F12000
G3 X123.575 Y128.337 I5.957 J-.91 E.03487
G1 X114.425 Y128.337 E.28113
G3 X114.359 Y129.468 I-8.083 J.095 E.03485
G1 X123.58 Y129.468 E.28331
G1 X123.217 Y129.091 F30000
; LINE_WIDTH: 0.420065
G1 F12000
G1 X123.198 Y128.714 E.01161
G1 X114.802 Y128.714 E.258
G1 X114.785 Y129.091 E.0116
G1 X123.157 Y129.091 E.2573
G1 X112.636 Y130.677 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G1 X112.281 Y131.079 E.01485
G1 X111.705 Y131.525 E.02018
G1 X111.205 Y131.778 E.01553
G1 X110.655 Y131.946 E.01593
G1 X110.297 Y131.995 E.01001
; Slow Down End
G1 X109.276 Y131.919 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X108.764 Y131.766 E.0148
G1 X108.233 Y131.487 E.01663
G3 X107.43 Y130.737 I1.903 J-2.839 E.03056
; Slow Down End
G1 X95.285 Y128.987 F30000
; LINE_WIDTH: 0.418825
G1 F12000
G1 X95.293 Y127.205 E.05457
G1 X106.706 Y127.205 E.34961
G1 X106.706 Y128.765 E.04777
G1 X106.744 Y129.248 E.01485
G1 X106.897 Y129.856 E.0192
G1 X107.189 Y130.46 E.02054
G1 X107.39 Y130.693 E.00943
; Slow Down Start
; LINE_WIDTH: 0.404741
G1 F3000;_EXTRUDE_SET_SPEED
G2 X107.099 Y130.603 I-.237 J.251 E.0093
G1 X95.078 Y130.599 E.35443
G1 X94.655 Y130.655 E.01258
G1 X94.924 Y130.268 E.0139
G1 X95.164 Y129.667 E.01906
G1 X95.187 Y129.538 E.00389
; Slow Down End
; LINE_WIDTH: 0.41999
G1 F12000
G1 X95.275 Y129.046 E.01535
G1 X106.377 Y129.338 F30000
G1 F12000
G3 X106.329 Y128.765 I5.511 J-.756 E.0177
G1 X106.329 Y127.582 E.03633
G1 X95.668 Y127.582 E.32757
G1 X95.662 Y128.988 E.0432
G1 X95.568 Y129.538 E.01712
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X95.534 Y129.735 E.00616
G1 X95.349 Y130.222 E.01601
; Slow Down End
G1 F12000
G1 X106.654 Y130.222 E.34737
G3 X106.427 Y129.538 I1.892 J-1.01 E.02227
G1 X106.392 Y129.397 E.00446
G1 X105.986 Y129.272 F30000
G1 F12000
G3 X105.952 Y127.959 I9.564 J-.91 E.04038
G1 X96.044 Y127.959 E.30444
G1 X96.039 Y128.99 E.03166
G1 X95.949 Y129.538 E.01706
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G3 X95.893 Y129.845 I-1.295 J-.077 E.00962
; Slow Down End
G1 F12000
G1 X106.114 Y129.845 E.31405
G1 X106 Y129.331 E.01619
G1 X105.637 Y129.468 F30000
G1 F12000
G3 X105.575 Y128.337 I6.228 J-.911 E.03486
G1 X96.419 Y128.337 E.28132
G1 X96.416 Y128.991 E.02012
G1 X96.35 Y129.468 E.01478
G1 X105.577 Y129.468 E.28352
G1 X105.217 Y129.091 F30000
; LINE_WIDTH: 0.420065
G1 F12000
G1 X105.198 Y128.714 E.01161
G1 X96.795 Y128.714 E.25824
G1 X96.784 Y129.091 E.01159
G1 X105.157 Y129.091 E.25731
G1 X94.64 Y130.671 F30000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F3000;_EXTRUDE_SET_SPEED
G3 X94.158 Y131.186 I-17.585 J-15.974 E.01954
G3 X92.205 Y131.994 I-2.13 J-2.38 E.05969
; Slow Down End
; WIPE_START
G1 X92.695 Y131.934 E-.1876
G1 X93.258 Y131.754 E-.22452
G1 X93.738 Y131.503 E-.20568
G1 X94.036 Y131.278 E-.14221
; WIPE_END
G1 E-.04 F1800
G1 X88.004 Y128.885 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40138
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X88.896 Y129.777 E.06505
G2 X90.972 Y131.853 I3.108 J-1.032 E.15694
G1 X91.078 Y131.96 E.00776
G1 X91.081 Y132.463 E.02594
G1 X91.012 Y132.532 E.00502
G1 X87.568 Y129.087 E.25111
G1 X86.93 Y129.087 E.03291
G1 X90.693 Y132.851 E.27438
G1 X90.374 Y133.17 E.02327
G1 X86.291 Y129.087 E.29765
G1 X85.653 Y129.087 E.03291
G1 X90.055 Y133.489 E.32092
G1 X89.765 Y133.779 E.0211
G1 X89.813 Y133.886 E.00606
G1 X85.015 Y129.087 E.34985
G1 X84.376 Y129.087 E.03291
G1 X89.759 Y134.47 E.39244
G1 X89.121 Y134.47 E.03291
G1 X83.738 Y129.087 E.39244
G1 X83.1 Y129.087 E.03291
G1 X88.482 Y134.47 E.39244
G1 X88.13 Y134.47 E.01817
G1 X84.764 Y131.104 E.24541
G1 X84.621 Y131.247 E.01042
G1 X82.461 Y129.087 E.15745
G1 X81.823 Y129.087 E.03291
G1 X84.302 Y131.566 E.18072
G1 X83.982 Y131.885 E.02327
G1 X81.185 Y129.087 E.20399
G1 X80.546 Y129.087 E.03291
G1 X83.663 Y132.205 E.22726
G1 X83.344 Y132.524 E.02327
G1 X79.908 Y129.087 E.25053
G1 X79.269 Y129.087 E.03291
G1 X83.025 Y132.843 E.2738
G1 X82.706 Y133.162 E.02327
G1 X78.631 Y129.087 E.29707
G1 X77.993 Y129.087 E.03291
G1 X82.387 Y133.481 E.32034
G1 X82.108 Y133.76 E.02032
G1 X82.176 Y133.909 E.00844
G1 X77.354 Y129.087 E.35152
G1 X76.716 Y129.087 E.03291
G1 X82.099 Y134.47 E.39244
G1 X81.46 Y134.47 E.03291
G1 X76.078 Y129.087 E.39244
G1 X75.439 Y129.087 E.03291
G1 X80.822 Y134.47 E.39244
G1 X80.493 Y134.47 E.01696
G1 X77.107 Y131.084 E.24684
G1 X76.953 Y131.239 E.01128
G1 X74.801 Y129.087 E.15687
G1 X74.163 Y129.087 E.03291
G1 X76.634 Y131.558 E.18014
G1 X76.314 Y131.878 E.02327
G1 X73.972 Y129.535 E.17079
G1 X73.972 Y130.173 E.03291
G1 X75.995 Y132.197 E.14752
G1 X75.676 Y132.516 E.02327
G1 X73.769 Y130.609 E.13902
G1 X75.249 Y132.696 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
G1 X74.582 Y133.362 E.03125
G1 X73.994 Y133.754 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.417594
G1 F12000
G1 X73.994 Y135.216 E.04463
G2 X83.676 Y135.216 I4.84 J-1518.233 E.29561
G2 X91.316 Y135.216 I3.82 J-1022.297 E.23324
G1 X164.688 Y135.216 E2.24013
G2 X172.327 Y135.216 I3.82 J-943.48 E.23324
G2 X182.006 Y135.216 I4.841 J-1400.34 E.2955
G1 X182.006 Y133.754 E.04463
G1 X176.812 Y133.754 E.15858
G3 X175.734 Y134.826 I-162.315 J-162.093 E.0464
G1 X175.604 Y134.872 E.00423
G1 X173.222 Y134.872 E.07272
G1 X173.039 Y134.652 E.00876
G3 X173.399 Y133.851 I85.973 J38.202 E.0268
G1 X173.301 Y133.754 E.00421
G1 X169.175 Y133.754 E.12598
G3 X168.098 Y134.826 I-163.748 J-163.534 E.0464
G1 X167.967 Y134.872 E.00423
G1 X165.583 Y134.872 E.0728
G1 X165.399 Y134.652 E.00876
G3 X165.743 Y133.872 I86.982 J37.886 E.02603
G1 X165.625 Y133.754 E.00509
G1 X90.375 Y133.754 E2.29748
G1 X90.259 Y133.87 E.00501
G1 X90.604 Y134.652 E.02611
G1 X90.421 Y134.872 E.00876
G1 X88.037 Y134.872 E.07279
G1 X87.905 Y134.826 E.00425
G3 X86.829 Y133.754 I230.751 J-232.686 E.0464
G1 X82.699 Y133.754 E.12609
G1 X82.603 Y133.849 E.00413
G1 X82.965 Y134.652 E.02688
G1 X82.781 Y134.872 E.00876
G1 X80.4 Y134.872 E.07271
G1 X80.269 Y134.826 E.00425
G3 X79.192 Y133.754 I230.751 J-232.686 E.0464
G1 X74.054 Y133.754 E.15686
G1 X176.26 Y134.839 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X181.629 Y134.839 E.16495
G1 X181.629 Y134.131 E.02174
G1 X176.968 Y134.131 E.14321
G1 X176.303 Y134.796 E.0289
G1 X177.114 Y134.485 F30000
; LINE_WIDTH: 0.3734
G1 F12000
G1 X181.215 Y134.485 E.11043
G1 X172.888 Y134.839 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X172.671 Y134.566 E.01069
G1 X172.857 Y134.131 E.01453
G1 X169.331 Y134.131 E.10835
G1 X168.624 Y134.839 E.03075
G1 X172.828 Y134.839 E.12917
G1 X169.478 Y134.485 F30000
; LINE_WIDTH: 0.37339
G1 F12000
G1 X172.267 Y134.485 E.07512
G1 X165.248 Y134.839 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X165.032 Y134.566 E.01069
G1 X165.215 Y134.131 E.01449
G1 X90.788 Y134.131 E2.28686
G1 X90.971 Y134.566 E.01449
G1 X90.791 Y134.839 E.01004
G1 X165.188 Y134.839 E2.28595
G1 X91.316 Y134.485 F30000
; LINE_WIDTH: 0.37338
G1 F12000
G1 X164.628 Y134.485 E1.97417
G1 X87.38 Y134.839 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X86.673 Y134.131 E.03075
G1 X83.146 Y134.131 E.10836
G1 X83.332 Y134.566 E.01453
G1 X83.152 Y134.839 E.01004
G1 X87.32 Y134.839 E.12807
G1 X83.676 Y134.485 F30000
; LINE_WIDTH: 0.37339
G1 F12000
G1 X86.466 Y134.485 E.07512
G1 X79.743 Y134.839 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X79.036 Y134.131 E.03075
G1 X74.371 Y134.131 E.14333
G1 X74.371 Y134.839 E.02174
G1 X79.683 Y134.839 E.16322
G1 X74.725 Y134.485 F30000
; LINE_WIDTH: 0.3734
G1 F12000
G1 X78.829 Y134.485 E.11053
G1 X74.728 Y127.94 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38029
G1 F15000
G1 X87.914 Y127.94 E.36249
G1 X88.33 Y127.582 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X74.371 Y127.582 E.42891
G1 X74.371 Y128.297 E.02195
G1 X88.332 Y128.297 E.42897
G1 X88.33 Y127.642 E.02011
G1 X88.706 Y127.205 F30000
G1 F15000
G1 X73.994 Y127.205 E.45205
G1 X73.994 Y128.674 E.04512
G1 X88.71 Y128.674 E.45217
G1 X88.707 Y127.265 E.04328
; WIPE_START
G1 X88.71 Y128.674 E-.53527
G1 X88.119 Y128.674 E-.22473
; WIPE_END
G1 E-.04 F1800
G1 X89.283 Y126.056 Z5.6 F30000
G1 Z5.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.748 Y126.591 E.02323
G1 X88.215 Y126.591
G1 X89.283 Y125.523 E.04641
G1 X88.891 Y125.381
G1 X87.681 Y126.591 E.05255
G1 X87.148 Y126.591
G1 X88.358 Y125.381 E.05255
G1 X87.824 Y125.381
G1 X86.615 Y126.591 E.05255
G1 X86.082 Y126.591
G1 X87.291 Y125.381 E.05255
G1 X86.758 Y125.381
G1 X85.548 Y126.591 E.05255
G1 X85.015 Y126.591
G1 X86.224 Y125.381 E.05255
G1 X85.691 Y125.381
G1 X84.482 Y126.591 E.05255
G1 X83.949 Y126.591
G1 X85.158 Y125.381 E.05255
G1 X84.625 Y125.381
G1 X83.415 Y126.591 E.05255
G1 X82.882 Y126.591
G1 X84.091 Y125.381 E.05255
G1 X83.558 Y125.381
G1 X82.349 Y126.591 E.05255
G1 X81.816 Y126.591
G1 X83.025 Y125.381 E.05255
G1 X82.492 Y125.381
G1 X81.282 Y126.591 E.05255
G1 X80.749 Y126.591
G1 X81.958 Y125.381 E.05255
G1 X81.425 Y125.381
G1 X80.216 Y126.591 E.05255
G1 X79.683 Y126.591
G1 X80.892 Y125.381 E.05255
G1 X80.359 Y125.381
G1 X79.149 Y126.591 E.05255
G1 X78.616 Y126.591
G1 X79.825 Y125.381 E.05255
G1 X79.292 Y125.381
G1 X78.083 Y126.591 E.05255
G1 X77.55 Y126.591
G1 X78.759 Y125.381 E.05255
G1 X78.226 Y125.381
G1 X77.016 Y126.591 E.05255
G1 X76.483 Y126.591
G1 X77.692 Y125.381 E.05255
G1 X77.159 Y125.381
G1 X75.95 Y126.591 E.05255
G1 X75.417 Y126.591
G1 X76.626 Y125.381 E.05255
G1 X76.093 Y125.381
G1 X74.883 Y126.591 E.05255
G1 X74.35 Y126.591
G1 X75.559 Y125.381 E.05255
G1 X75.026 Y125.381
G1 X73.817 Y126.591 E.05255
G1 X73.417 Y126.457
G1 X74.493 Y125.381 E.04673
G1 X73.96 Y125.381
G1 X73.417 Y125.924 E.02356
; WIPE_START
M204 S10000
G1 X73.96 Y125.381 E-.29136
G1 X74.493 Y125.381 E-.20264
G1 X73.998 Y125.876 E-.26601
; WIPE_END
G1 E-.04 F1800
G1 X81.63 Y125.948 Z5.6 F30000
G1 X107.283 Y126.187 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X106.879 Y126.591 E.01755
G1 X106.345 Y126.591
G1 X107.283 Y125.654 E.04072
G1 X107.022 Y125.381
G1 X105.812 Y126.591 E.05255
G1 X105.279 Y126.591
G1 X106.488 Y125.381 E.05255
G1 X105.955 Y125.381
G1 X104.746 Y126.591 E.05255
G1 X104.212 Y126.591
G1 X105.422 Y125.381 E.05255
G1 X104.888 Y125.381
G1 X103.679 Y126.591 E.05255
G1 X103.146 Y126.591
G1 X104.355 Y125.381 E.05255
G1 X103.822 Y125.381
G1 X102.613 Y126.591 E.05255
G1 X102.079 Y126.591
G1 X103.289 Y125.381 E.05255
G1 X102.755 Y125.381
G1 X101.546 Y126.591 E.05255
G1 X101.013 Y126.591
G1 X102.222 Y125.381 E.05255
G1 X101.689 Y125.381
G1 X100.48 Y126.591 E.05255
G1 X99.946 Y126.591
G1 X101.156 Y125.381 E.05255
G1 X100.622 Y125.381
G1 X99.413 Y126.591 E.05255
G1 X98.88 Y126.591
G1 X100.089 Y125.381 E.05255
G1 X99.556 Y125.381
G1 X98.347 Y126.591 E.05255
G1 X97.813 Y126.591
G1 X99.023 Y125.381 E.05255
G1 X98.489 Y125.381
G1 X97.28 Y126.591 E.05255
G1 X96.747 Y126.591
G1 X97.956 Y125.381 E.05255
G1 X97.423 Y125.381
G1 X96.214 Y126.591 E.05255
G1 X95.68 Y126.591
G1 X96.89 Y125.381 E.05255
G1 X96.356 Y125.381
G1 X95.147 Y126.591 E.05255
G1 X94.717 Y126.487
G1 X95.823 Y125.381 E.04805
G1 X95.29 Y125.381
G1 X94.717 Y125.954 E.02488
; WIPE_START
M204 S10000
G1 X95.29 Y125.381 E-.30764
G1 X95.823 Y125.381 E-.20264
G1 X95.358 Y125.846 E-.24972
; WIPE_END
G1 E-.04 F1800
G1 X102.988 Y126.041 Z5.6 F30000
G1 X124.476 Y126.591 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X125.283 Y125.784 E.03504
G1 X125.152 Y125.381
G1 X123.943 Y126.591 E.05255
G1 X123.41 Y126.591
G1 X124.619 Y125.381 E.05255
G1 X124.086 Y125.381
G1 X122.876 Y126.591 E.05255
G1 X122.343 Y126.591
G1 X123.553 Y125.381 E.05255
G1 X123.019 Y125.381
G1 X121.81 Y126.591 E.05255
G1 X121.277 Y126.591
G1 X122.486 Y125.381 E.05255
G1 X121.953 Y125.381
G1 X120.743 Y126.591 E.05255
G1 X120.21 Y126.591
G1 X121.419 Y125.381 E.05255
G1 X120.886 Y125.381
G1 X119.677 Y126.591 E.05255
G1 X119.144 Y126.591
G1 X120.353 Y125.381 E.05255
G1 X119.82 Y125.381
G1 X118.61 Y126.591 E.05255
G1 X118.077 Y126.591
G1 X119.286 Y125.381 E.05255
G1 X118.753 Y125.381
G1 X117.544 Y126.591 E.05255
G1 X117.011 Y126.591
G1 X118.22 Y125.381 E.05255
G1 X117.687 Y125.381
G1 X116.477 Y126.591 E.05255
G1 X115.944 Y126.591
G1 X117.153 Y125.381 E.05255
G1 X116.62 Y125.381
G1 X115.411 Y126.591 E.05255
G1 X114.878 Y126.591
M73 P89 R3
G1 X116.087 Y125.381 E.05255
G1 X115.554 Y125.381
G1 X114.344 Y126.591 E.05255
G1 X113.811 Y126.591
G1 X115.02 Y125.381 E.05255
G1 X114.487 Y125.381
G1 X113.278 Y126.591 E.05255
G1 X112.745 Y126.591
G1 X113.954 Y125.381 E.05255
G1 X113.421 Y125.381
G1 X112.717 Y126.085 E.03056
; WIPE_START
M204 S10000
G1 X113.421 Y125.381 E-.37791
G1 X113.954 Y125.381 E-.20264
G1 X113.62 Y125.715 E-.17945
; WIPE_END
G1 E-.04 F1800
G1 X121.252 Y125.767 Z5.6 F30000
G1 X143.283 Y125.915 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X142.607 Y126.591 E.02936
G1 X142.074 Y126.591
G1 X143.283 Y125.382 E.05253
G1 X142.75 Y125.381
G1 X141.54 Y126.591 E.05255
G1 X141.007 Y126.591
G1 X142.217 Y125.381 E.05255
G1 X141.683 Y125.381
G1 X140.474 Y126.591 E.05255
G1 X139.941 Y126.591
G1 X141.15 Y125.381 E.05255
G1 X140.617 Y125.381
G1 X139.407 Y126.591 E.05255
G1 X138.874 Y126.591
G1 X140.083 Y125.381 E.05255
G1 X139.55 Y125.381
G1 X138.341 Y126.591 E.05255
G1 X137.808 Y126.591
G1 X139.017 Y125.381 E.05255
G1 X138.484 Y125.381
G1 X137.274 Y126.591 E.05255
G1 X136.741 Y126.591
G1 X137.95 Y125.381 E.05255
G1 X137.417 Y125.381
G1 X136.208 Y126.591 E.05255
G1 X135.675 Y126.591
G1 X136.884 Y125.381 E.05255
G1 X136.351 Y125.381
G1 X135.141 Y126.591 E.05255
G1 X134.608 Y126.591
G1 X135.817 Y125.381 E.05255
G1 X135.284 Y125.381
G1 X134.075 Y126.591 E.05255
G1 X133.542 Y126.591
G1 X134.751 Y125.381 E.05255
G1 X134.218 Y125.381
G1 X133.008 Y126.591 E.05255
G1 X132.475 Y126.591
G1 X133.684 Y125.381 E.05255
G1 X133.151 Y125.381
G1 X131.942 Y126.591 E.05255
G1 X131.409 Y126.591
G1 X132.618 Y125.381 E.05255
G1 X132.085 Y125.381
G1 X130.875 Y126.591 E.05255
G1 X130.717 Y126.215
G1 X131.551 Y125.381 E.03624
; WIPE_START
M204 S10000
G1 X130.717 Y126.215 E-.44818
G1 X130.875 Y126.591 E-.15474
G1 X131.168 Y126.299 E-.15708
; WIPE_END
G1 E-.04 F1800
G1 X138.8 Y126.234 Z5.6 F30000
G1 X161.283 Y126.046 Z5.6
G1 Z5.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X160.738 Y126.591 E.02368
G1 X160.204 Y126.591
G1 X161.283 Y125.513 E.04685
G1 X160.881 Y125.381
G1 X159.671 Y126.591 E.05255
G1 X159.138 Y126.591
G1 X160.347 Y125.381 E.05255
G1 X159.814 Y125.381
G1 X158.605 Y126.591 E.05255
G1 X158.071 Y126.591
G1 X159.281 Y125.381 E.05255
G1 X158.748 Y125.381
G1 X157.538 Y126.591 E.05255
G1 X157.005 Y126.591
G1 X158.214 Y125.381 E.05255
G1 X157.681 Y125.381
G1 X156.472 Y126.591 E.05255
G1 X155.938 Y126.591
G1 X157.148 Y125.381 E.05255
G1 X156.614 Y125.381
G1 X155.405 Y126.591 E.05255
G1 X154.872 Y126.591
G1 X156.081 Y125.381 E.05255
G1 X155.548 Y125.381
G1 X154.339 Y126.591 E.05255
G1 X153.805 Y126.591
G1 X155.015 Y125.381 E.05255
G1 X154.481 Y125.381
G1 X153.272 Y126.591 E.05255
G1 X152.739 Y126.591
G1 X153.948 Y125.381 E.05255
G1 X153.415 Y125.381
G1 X152.206 Y126.591 E.05255
G1 X151.672 Y126.591
G1 X152.882 Y125.381 E.05255
G1 X152.348 Y125.381
G1 X151.139 Y126.591 E.05255
G1 X150.606 Y126.591
G1 X151.815 Y125.381 E.05255
G1 X151.282 Y125.381
G1 X150.073 Y126.591 E.05255
G1 X149.539 Y126.591
G1 X150.749 Y125.381 E.05255
G1 X150.215 Y125.381
G1 X149.006 Y126.591 E.05255
G1 X148.717 Y126.346
G1 X149.682 Y125.381 E.04192
G1 X149.149 Y125.381
G1 X148.717 Y125.813 E.01875
; WIPE_START
M204 S10000
G1 X149.149 Y125.381 E-.23188
G1 X149.682 Y125.381 E-.20264
G1 X149.076 Y125.987 E-.32549
; WIPE_END
G1 E-.04 F1800
G1 X156.032 Y129.131 Z5.6 F30000
G1 X162.559 Y132.081 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G3 X161.26 Y131.12 I1.576 J-3.49 E.054
G1 X159.018 Y133.362 E.10518
G1 X158.39 Y133.362 E.02084
G1 X156.019 Y130.991 E.11121
G1 X153.713 Y130.991 E.07651
G1 X151.342 Y133.362 E.11121
G1 X150.714 Y133.362 E.02084
G1 X148.611 Y131.259 E.09865
G3 X144.836 Y132.192 I-2.649 J-2.616 E.13571
G1 X143.666 Y133.362 E.05488
G1 X143.038 Y133.362 E.02084
G1 X140.667 Y130.991 E.11121
G1 X138.361 Y130.991 E.07651
G1 X135.99 Y133.362 E.11121
G1 X135.362 Y133.362 E.02084
G1 X132.991 Y130.991 E.11121
G1 X130.831 Y131.009 E.07168
G3 X129.745 Y131.931 I-3.059 J-2.502 E.04752
G1 X128.314 Y133.362 E.0671
G1 X127.686 Y133.362 E.02084
G1 X126.238 Y131.914 E.0679
G3 X125.152 Y130.991 I2.129 J-3.605 E.04751
G1 X123.009 Y130.991 E.07111
G1 X120.638 Y133.362 E.11121
G1 X120.01 Y133.362 E.02084
G1 X117.639 Y130.991 E.11121
G1 X115.333 Y130.991 E.07651
G1 X112.962 Y133.362 E.11121
G1 X112.334 Y133.362 E.02084
G1 X111.158 Y132.186 E.05517
G3 X109.345 Y132.379 I-1.395 J-4.481 E.06088
G1 X109.74 Y131.984 E.01854
G1 X109.396 Y132.318 E.01592
G3 X107.388 Y131.26 I.652 J-3.669 E.07649
G1 X105.286 Y133.362 E.09861
G1 X104.658 Y133.362 E.02084
G1 X102.287 Y130.991 E.11121
G1 X99.981 Y130.991 E.07651
G1 X97.61 Y133.362 E.11121
G1 X96.982 Y133.362 E.02084
G1 X94.74 Y131.12 E.10517
G3 X93.439 Y132.075 I-2.719 J-2.342 E.054
; CHANGE_LAYER
; Z_HEIGHT: 5.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X94.098 Y131.709 E-.28622
G1 X94.74 Y131.12 E-.33129
G1 X95.005 Y131.385 E-.14249
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 27/33
; update layer progress
M73 L27
M991 S0 P26 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.6 I.053 J1.216 P1  F30000
G1 X182.398 Y127.585 Z5.6
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F15476.087
G1 X182.398 Y135.153 E.25106
G1 X73.602 Y135.153 E3.60896
G1 X73.602 Y127.585 E.25106
G1 X89.098 Y127.585 E.51403
G1 X89.098 Y128.757 E.0389
G2 X94.899 Y128.887 I2.902 J-.011 E.29744
G1 X94.901 Y127.585 E.0432
G1 X107.098 Y127.585 E.40461
G2 X107.111 Y129.028 I14.831 J.586 E.0479
G2 X112.899 Y128.881 I2.889 J-.28 E.28875
G1 X112.901 Y127.585 E.043
G1 X125.098 Y127.585 E.40461
G2 X125.111 Y129.028 I14.831 J.586 E.0479
G2 X130.902 Y128.757 I2.888 J-.286 E.29251
G1 X130.902 Y127.585 E.03888
G1 X143.098 Y127.585 E.40456
G2 X143.111 Y129.028 I14.843 J.586 E.0479
G2 X148.899 Y128.881 I2.889 J-.281 E.28872
G1 X148.901 Y127.585 E.043
G1 X161.098 Y127.585 E.40461
G2 X161.111 Y129.028 I14.835 J.586 E.04791
G2 X166.899 Y128.881 I2.889 J-.281 E.28872
G1 X166.901 Y127.585 E.043
G1 X182.338 Y127.585 E.51209
; WIPE_START
G1 X182.354 Y129.585 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y125.946 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y135.545 E.29497
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y135.545 E3.36709
G1 X73.21 Y125.946 E.29497
G1 X89.49 Y125.946 E.50024
G1 X89.49 Y128.752 E.08625
G2 X94.507 Y128.869 I2.51 J-.005 E.2384
G1 X94.51 Y125.946 E.08983
G1 X107.49 Y125.946 E.39884
G1 X107.49 Y128.752 E.08625
G2 X112.507 Y128.867 I2.51 J-.004 E.23851
G1 X112.51 Y125.946 E.08976
G1 X125.49 Y125.946 E.39884
G1 X125.49 Y128.752 E.08625
G2 X130.51 Y128.752 I2.51 J-.009 E.24172
G1 X130.51 Y125.946 E.08625
G1 X143.49 Y125.946 E.39884
G1 X143.49 Y128.752 E.08625
G2 X148.507 Y128.867 I2.51 J-.004 E.23854
G1 X148.51 Y125.946 E.08976
G1 X161.49 Y125.946 E.39885
G1 X161.49 Y128.752 E.08625
G2 X166.507 Y128.867 I2.51 J-.004 E.23854
G1 X166.51 Y125.946 E.08976
G1 X182.73 Y125.946 E.4984
; WIPE_START
M204 S10000
G1 X182.743 Y127.945 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X181.745 Y126.153 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.583 Y126.99 E.03639
G1 X182.421 Y127.362
G1 X181.212 Y126.153 E.05255
G1 X180.679 Y126.153
G1 X181.888 Y127.362 E.05255
G1 X181.355 Y127.362
G1 X180.145 Y126.153 E.05255
G1 X179.612 Y126.153
G1 X180.822 Y127.362 E.05255
G1 X180.288 Y127.362
G1 X179.079 Y126.153 E.05255
G1 X178.546 Y126.153
G1 X179.755 Y127.362 E.05255
G1 X179.222 Y127.362
G1 X178.012 Y126.153 E.05255
G1 X177.479 Y126.153
G1 X178.688 Y127.362 E.05255
G1 X178.155 Y127.362
G1 X176.946 Y126.153 E.05255
G1 X176.413 Y126.153
G1 X177.622 Y127.362 E.05255
G1 X177.089 Y127.362
G1 X175.879 Y126.153 E.05255
G1 X175.346 Y126.153
G1 X176.555 Y127.362 E.05255
G1 X176.022 Y127.362
G1 X174.813 Y126.153 E.05255
G1 X174.28 Y126.153
G1 X175.489 Y127.362 E.05255
G1 X174.956 Y127.362
G1 X173.746 Y126.153 E.05255
G1 X173.213 Y126.153
G1 X174.422 Y127.362 E.05255
G1 X173.889 Y127.362
G1 X172.68 Y126.153 E.05255
G1 X172.147 Y126.153
G1 X173.356 Y127.362 E.05255
G1 X172.823 Y127.362
G1 X171.613 Y126.153 E.05255
G1 X171.08 Y126.153
G1 X172.289 Y127.362 E.05255
G1 X171.756 Y127.362
G1 X170.547 Y126.153 E.05255
G1 X170.014 Y126.153
G1 X171.223 Y127.362 E.05255
G1 X170.69 Y127.362
G1 X169.48 Y126.153 E.05255
G1 X168.947 Y126.153
G1 X170.156 Y127.362 E.05255
G1 X169.623 Y127.362
G1 X168.414 Y126.153 E.05255
G1 X167.881 Y126.153
G1 X169.09 Y127.362 E.05255
G1 X168.557 Y127.362
G1 X167.347 Y126.153 E.05255
G1 X166.814 Y126.153
G1 X168.023 Y127.362 E.05255
G1 X167.49 Y127.362
G1 X166.717 Y126.589 E.03361
; WIPE_START
M204 S10000
G1 X167.49 Y127.362 E-.41563
G1 X168.023 Y127.362 E-.20264
G1 X167.76 Y127.098 E-.14174
; WIPE_END
G1 E-.04 F1800
G1 X160.415 Y126.153 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X161.283 Y127.021 E.03771
G1 X161.091 Y127.362
G1 X159.882 Y126.153 E.05255
G1 X159.348 Y126.153
G1 X160.558 Y127.362 E.05255
G1 X160.024 Y127.362
G1 X158.815 Y126.153 E.05255
G1 X158.282 Y126.153
G1 X159.491 Y127.362 E.05255
G1 X158.958 Y127.362
G1 X157.749 Y126.153 E.05255
G1 X157.215 Y126.153
G1 X158.425 Y127.362 E.05255
G1 X157.891 Y127.362
G1 X156.682 Y126.153 E.05255
G1 X156.149 Y126.153
G1 X157.358 Y127.362 E.05255
G1 X156.825 Y127.362
G1 X155.616 Y126.153 E.05255
G1 X155.082 Y126.153
G1 X156.292 Y127.362 E.05255
G1 X155.758 Y127.362
G1 X154.549 Y126.153 E.05255
G1 X154.016 Y126.153
G1 X155.225 Y127.362 E.05255
G1 X154.692 Y127.362
G1 X153.483 Y126.153 E.05255
G1 X152.949 Y126.153
G1 X154.159 Y127.362 E.05255
G1 X153.625 Y127.362
G1 X152.416 Y126.153 E.05255
G1 X151.883 Y126.153
G1 X153.092 Y127.362 E.05255
G1 X152.559 Y127.362
G1 X151.35 Y126.153 E.05255
G1 X150.816 Y126.153
G1 X152.026 Y127.362 E.05255
G1 X151.492 Y127.362
G1 X150.283 Y126.153 E.05255
G1 X149.75 Y126.153
G1 X150.959 Y127.362 E.05255
G1 X150.426 Y127.362
G1 X149.217 Y126.153 E.05255
G1 X148.717 Y126.187
G1 X149.893 Y127.362 E.05108
G1 X149.359 Y127.362
G1 X148.717 Y126.72 E.02793
; WIPE_START
M204 S10000
G1 X149.359 Y127.362 E-.34541
G1 X149.893 Y127.362 E-.20264
G1 X149.498 Y126.968 E-.21196
; WIPE_END
G1 E-.04 F1800
G1 X150.061 Y128.746 Z5.8 F30000
M73 P89 R2
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.45089
G1 F15000
G1 X150.03 Y129.154 E.0136
G1 X159.963 Y129.154 E.33021
G1 X159.939 Y128.746 E.01359
G1 X150.121 Y128.746 E.32639
G1 X149.669 Y128.354 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X149.669 Y128.891 E.01651
G1 X149.567 Y129.547 E.02039
G1 X160.422 Y129.547 E.33355
G3 X160.331 Y128.354 I4.213 J-.923 E.03688
G1 X149.729 Y128.354 E.32575
G1 X149.292 Y127.977 F30000
G1 F15000
G1 X149.292 Y128.891 E.02809
G1 X149.165 Y129.66 E.02394
G1 X149.063 Y129.924 E.00871
G1 X160.941 Y129.924 E.36499
G1 X160.772 Y129.403 E.01682
G1 X160.709 Y128.902 E.01552
G1 X160.707 Y127.977 E.02844
G1 X149.352 Y127.977 E.34889
; WIPE_START
G1 X151.352 Y127.977 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X143.826 Y126.71 Z5.8 F30000
G1 X143.283 Y126.618 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X142.817 Y126.153 E.02022
G1 X142.284 Y126.153
G1 X143.283 Y127.151 E.04339
G1 X142.96 Y127.362
G1 X141.751 Y126.153 E.05255
G1 X141.218 Y126.153
G1 X142.427 Y127.362 E.05255
G1 X141.894 Y127.362
G1 X140.684 Y126.153 E.05255
G1 X140.151 Y126.153
G1 X141.36 Y127.362 E.05255
G1 X140.827 Y127.362
G1 X139.618 Y126.153 E.05255
G1 X139.085 Y126.153
G1 X140.294 Y127.362 E.05255
G1 X139.761 Y127.362
G1 X138.551 Y126.153 E.05255
G1 X138.018 Y126.153
G1 X139.227 Y127.362 E.05255
G1 X138.694 Y127.362
G1 X137.485 Y126.153 E.05255
G1 X136.952 Y126.153
G1 X138.161 Y127.362 E.05255
G1 X137.628 Y127.362
G1 X136.418 Y126.153 E.05255
G1 X135.885 Y126.153
G1 X137.094 Y127.362 E.05255
G1 X136.561 Y127.362
G1 X135.352 Y126.153 E.05255
G1 X134.819 Y126.153
G1 X136.028 Y127.362 E.05255
G1 X135.495 Y127.362
G1 X134.285 Y126.153 E.05255
G1 X133.752 Y126.153
G1 X134.961 Y127.362 E.05255
G1 X134.428 Y127.362
G1 X133.219 Y126.153 E.05255
G1 X132.686 Y126.153
G1 X133.895 Y127.362 E.05255
G1 X133.362 Y127.362
G1 X132.152 Y126.153 E.05255
G1 X131.619 Y126.153
G1 X132.828 Y127.362 E.05255
G1 X132.295 Y127.362
G1 X131.086 Y126.153 E.05255
G1 X130.717 Y126.318
G1 X131.762 Y127.362 E.04539
G1 X131.229 Y127.362
G1 X130.717 Y126.851 E.02221
; WIPE_START
M204 S10000
G1 X131.229 Y127.362 E-.27471
G1 X131.762 Y127.362 E-.20264
G1 X131.236 Y126.836 E-.28265
; WIPE_END
G1 E-.04 F1800
G1 X125.283 Y126.749 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X124.687 Y126.153 E.0259
G1 X124.153 Y126.153
G1 X125.283 Y127.282 E.04907
G1 X124.829 Y127.362
G1 X123.62 Y126.153 E.05255
G1 X123.087 Y126.153
G1 X124.296 Y127.362 E.05255
G1 X123.763 Y127.362
G1 X122.554 Y126.153 E.05255
G1 X122.02 Y126.153
G1 X123.23 Y127.362 E.05255
G1 X122.696 Y127.362
G1 X121.487 Y126.153 E.05255
G1 X120.954 Y126.153
G1 X122.163 Y127.362 E.05255
G1 X121.63 Y127.362
G1 X120.421 Y126.153 E.05255
G1 X119.887 Y126.153
G1 X121.097 Y127.362 E.05255
G1 X120.563 Y127.362
G1 X119.354 Y126.153 E.05255
G1 X118.821 Y126.153
G1 X120.03 Y127.362 E.05255
G1 X119.497 Y127.362
G1 X118.288 Y126.153 E.05255
G1 X117.754 Y126.153
G1 X118.964 Y127.362 E.05255
G1 X118.43 Y127.362
M73 P90 R2
G1 X117.221 Y126.153 E.05255
G1 X116.688 Y126.153
G1 X117.897 Y127.362 E.05255
G1 X117.364 Y127.362
G1 X116.155 Y126.153 E.05255
G1 X115.621 Y126.153
G1 X116.831 Y127.362 E.05255
G1 X116.297 Y127.362
G1 X115.088 Y126.153 E.05255
G1 X114.555 Y126.153
G1 X115.764 Y127.362 E.05255
G1 X115.231 Y127.362
G1 X114.022 Y126.153 E.05255
G1 X113.488 Y126.153
G1 X114.698 Y127.362 E.05255
G1 X114.164 Y127.362
G1 X112.955 Y126.153 E.05255
G1 X112.717 Y126.448
G1 X113.631 Y127.362 E.03973
G1 X113.098 Y127.362
G1 X112.716 Y126.981 E.01658
; WIPE_START
M204 S10000
G1 X113.098 Y127.362 E-.205
G1 X113.631 Y127.362 E-.20264
G1 X112.975 Y126.707 E-.35237
; WIPE_END
G1 E-.04 F1800
G1 X110.574 Y131.761 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40669
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X108.319 Y134.016 E.16878
G1 X108.965 Y134.016 E.03418
G1 X111.178 Y131.802 E.16568
G1 X111.473 Y131.665 E.0172
G2 X111.841 Y131.451 I-.624 J-1.492 E.02261
G2 X112.867 Y130.337 I-1.915 J-2.795 E.08081
G1 X113.289 Y130.337 E.02234
G1 X111.175 Y132.451 E.15821
G1 X111.498 Y132.774 E.02417
G1 X113.935 Y130.337 E.18238
G1 X114.581 Y130.337 E.03418
G1 X111.821 Y133.097 E.20655
G1 X112.067 Y133.343 E.01843
G1 X112.199 Y133.365 E.00705
G1 X115.227 Y130.337 E.22664
G1 X115.872 Y130.337 E.03418
G1 X112.751 Y133.459 E.23363
G1 X112.787 Y133.465 E.00189
G1 X112.635 Y134.016 E.03025
G1 X112.84 Y134.016 E.01087
G1 X116.518 Y130.337 E.27532
G1 X117.164 Y130.337 E.03418
G1 X113.486 Y134.016 E.27532
G1 X114.132 Y134.016 E.03418
G1 X117.81 Y130.337 E.27532
G1 X118.456 Y130.337 E.03418
G1 X114.778 Y134.016 E.27532
G1 X115.423 Y134.016 E.03418
G1 X119.102 Y130.337 E.27532
G1 X119.748 Y130.337 E.03418
G1 X116.069 Y134.016 E.27532
G1 X116.715 Y134.016 E.03418
G1 X120.393 Y130.337 E.27532
G1 X121.039 Y130.337 E.03418
G1 X118.889 Y132.488 E.16099
G1 X119.211 Y132.811 E.02417
G1 X121.685 Y130.337 E.18516
G1 X122.331 Y130.337 E.03418
G1 X119.534 Y133.134 E.20933
G1 X119.728 Y133.327 E.01446
G1 X119.942 Y133.373 E.01158
G1 X122.977 Y130.337 E.22719
G1 X123.623 Y130.337 E.03418
G1 X120.396 Y133.564 E.24154
G1 X120.271 Y134.016 E.02477
G1 X120.59 Y134.016 E.01688
G1 X124.269 Y130.337 E.27532
G1 X124.914 Y130.337 E.03418
G1 X121.236 Y134.016 E.27532
G1 X121.882 Y134.016 E.03418
G1 X125.301 Y130.597 E.25589
G2 X125.587 Y130.956 I2.839 J-1.967 E.02434
G1 X122.528 Y134.016 E.22898
G1 X123.174 Y134.016 E.03418
G1 X125.917 Y131.272 E.20537
G2 X126.299 Y131.537 I1.283 J-1.44 E.02462
G1 X123.82 Y134.016 E.18555
G1 X124.465 Y134.016 E.03418
G1 X126.723 Y131.759 E.16895
G2 X127.207 Y131.92 I.907 J-1.912 E.02708
G1 X126.602 Y132.525 E.0453
G1 X126.925 Y132.848 E.02417
G1 X127.759 Y132.014 E.06244
G1 X128.322 Y132.097 E.03014
G1 X127.248 Y133.171 E.08044
G1 X127.272 Y133.196 E.00182
G1 X127.092 Y133.375 E.01347
G1 X127.661 Y133.404 E.03014
G1 X129.335 Y131.729 E.12533
G2 X130.867 Y130.337 I-1.376 J-3.053 E.11137
G1 X131.373 Y130.337 E.02678
G1 X128.268 Y133.442 E.23241
G1 X128.11 Y134.016 E.03147
G1 X128.341 Y134.016 E.01221
G1 X132.019 Y130.337 E.27532
G1 X132.665 Y130.337 E.03418
G1 X128.986 Y134.016 E.27532
G1 X129.632 Y134.016 E.03418
G1 X133.311 Y130.337 E.27532
G1 X133.956 Y130.337 E.03418
G1 X130.278 Y134.016 E.27532
G1 X130.924 Y134.016 E.03418
G1 X134.602 Y130.337 E.27532
G1 X135.248 Y130.337 E.03418
G1 X131.57 Y134.016 E.27532
G1 X132.216 Y134.016 E.03418
G1 X135.894 Y130.337 E.27532
G1 X136.54 Y130.337 E.03418
G1 X134.315 Y132.563 E.16655
G1 X134.638 Y132.885 E.02417
G1 X137.186 Y130.337 E.19072
G1 X137.832 Y130.337 E.03418
G1 X134.961 Y133.208 E.21489
G1 X135.13 Y133.378 E.01269
G1 X135.413 Y133.402 E.01502
G1 X138.477 Y130.337 E.22938
G1 X139.123 Y130.337 E.03418
G1 X135.862 Y133.599 E.24414
G1 X135.747 Y134.016 E.02287
G1 X136.091 Y134.016 E.01822
G1 X139.769 Y130.337 E.27532
G1 X140.415 Y130.337 E.03418
G1 X136.737 Y134.016 E.27532
G1 X137.383 Y134.016 E.03418
G1 X141.061 Y130.337 E.27532
G1 X141.707 Y130.337 E.03418
G1 X138.028 Y134.016 E.27532
G1 X138.674 Y134.016 E.03418
G1 X142.353 Y130.337 E.27532
G1 X142.998 Y130.337 E.03418
G1 X139.32 Y134.016 E.27532
G1 X139.966 Y134.016 E.03418
G1 X143.336 Y130.646 E.25221
G2 X143.63 Y130.998 I2.368 J-1.68 E.02429
G1 X142.028 Y132.6 E.11989
G1 X142.351 Y132.923 E.02417
G1 X143.966 Y131.307 E.1209
G2 X144.344 Y131.568 I2.983 J-3.927 E.0243
G1 X142.674 Y133.246 E.12531
G1 X142.79 Y133.362 E.00869
G1 X143.158 Y133.407 E.01965
G1 X144.783 Y131.782 E.12159
G1 X145.26 Y131.951 E.0268
G1 X143.552 Y133.659 E.12787
G1 X144.14 Y134.218 F30000
; LINE_WIDTH: 0.40804
G1 F3000
G1 X146.364 Y131.995 E.16754
G2 X147.233 Y131.773 I-.234 J-2.73 E.04804
G1 X144.99 Y134.016 E.16901
G1 X145.638 Y134.016 E.03451
G1 X149.316 Y130.337 E.27715
G1 X149.964 Y130.337 E.03451
G1 X146.286 Y134.016 E.27715
G1 X146.934 Y134.016 E.03451
G1 X150.612 Y130.337 E.27715
G1 X151.26 Y130.337 E.03451
G1 X147.581 Y134.016 E.27715
G1 X147.978 Y134.016 E.02114
G1 X148.826 Y133.419 E.05522
G1 X151.907 Y130.337 E.2322
G1 X152.555 Y130.337 E.03451
G1 X149.998 Y132.894 E.19265
G2 X150.323 Y133.218 I23.87 J-23.594 E.0244
G1 X153.203 Y130.337 E.21703
G1 X153.851 Y130.337 E.03451
G1 X150.649 Y133.54 E.24127
G1 X150.687 Y133.577 E.00287
G1 X150.566 Y134.016 E.02422
G1 X150.82 Y134.016 E.01353
G1 X154.499 Y130.337 E.27715
G1 X155.146 Y130.337 E.03451
G1 X151.468 Y134.016 E.27715
G1 X152.116 Y134.016 E.03451
G1 X155.794 Y130.337 E.27715
G1 X156.442 Y130.337 E.03451
G1 X152.764 Y134.016 E.27715
G1 X153.411 Y134.016 E.03451
G1 X157.09 Y130.337 E.27715
G1 X157.737 Y130.337 E.03451
G1 X154.059 Y134.016 E.27715
G1 X154.707 Y134.016 E.03451
G1 X158.385 Y130.337 E.27715
G1 X159.033 Y130.337 E.03451
G1 X155.355 Y134.016 E.27715
G1 X155.613 Y134.016 E.01378
G1 X156.939 Y133.079 E.08651
G1 X159.681 Y130.337 E.20655
G1 X160.328 Y130.337 E.03451
G1 X157.723 Y132.943 E.19632
G1 X158.047 Y133.267 E.0244
G1 X160.976 Y130.337 E.22072
G1 X161.147 Y130.337 E.00912
G2 X161.327 Y130.634 I1.448 J-.675 E.01853
G1 X158.546 Y133.415 E.20955
G1 X159.001 Y133.428 E.02427
G1 X158.933 Y133.676 E.0137
G1 X161.62 Y130.989 E.20248
G2 X161.957 Y131.3 I1.234 J-.995 E.02451
G1 X159.241 Y134.016 E.20459
G1 X159.889 Y134.016 E.03451
G1 X162.339 Y131.565 E.18464
G2 X162.773 Y131.779 I.949 J-1.379 E.02586
G1 X160.537 Y134.016 E.16853
G1 X161.184 Y134.016 E.03451
G1 X163.264 Y131.936 E.15668
G2 X163.423 Y131.969 I.441 J-1.748 E.00865
G1 X163.815 Y132.033 E.02116
G1 X161.63 Y134.218 E.16465
G1 X163.736 Y132.724 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
G1 X164.389 Y132.071 E.03063
G1 X164.412 Y132.241 E.00569
G1 X164.945 Y132.241 E.01769
G1 X165.611 Y132.907 E.03125
G1 X167.148 Y132.907 E.051
G1 X167.815 Y132.241 E.03125
G1 X172.621 Y132.241 E.15944
G1 X173.287 Y132.907 E.03125
G1 X174.824 Y132.907 E.051
G1 X175.49 Y132.241 E.03125
G1 X180.297 Y132.241 E.15944
G1 X180.963 Y132.907 E.03125
G1 X179.335 Y132.907 E.05401
G1 X182.006 Y129.913 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y127.977 E.05949
G1 X167.292 Y127.977 E.4521
G1 X167.292 Y128.891 E.02809
G3 X167.057 Y129.975 I-4.75 J-.459 E.03416
G1 X166.712 Y130.618 E.02243
G1 X166.259 Y131.148 E.02141
G3 X165.105 Y131.849 I-2.41 J-2.666 E.04174
G1 X182.006 Y131.849 E.51931
G1 X182.006 Y129.973 E.05765
G1 X181.629 Y129.913 F30000
G1 F12000
G1 X181.629 Y128.354 E.04791
G1 X167.669 Y128.354 E.42893
G3 X167.421 Y130.075 I-4.446 J.237 E.05376
G1 X167.043 Y130.799 E.02511
G3 X166.473 Y131.468 I-5.102 J-3.766 E.02703
G1 X181.629 Y131.472 E.46569
G1 X181.629 Y129.973 E.04606
G1 X181.252 Y129.913 F30000
G1 F12000
G1 X181.252 Y128.731 E.03632
G1 X168.046 Y128.731 E.40577
G1 X168.012 Y129.292 E.01727
G1 X167.785 Y130.174 E.02798
G1 X167.374 Y130.98 E.02779
G1 X167.294 Y131.095 E.00431
G1 X181.252 Y131.095 E.42889
G1 X181.252 Y129.973 E.03448
G1 X180.875 Y129.913 F30000
G1 F12000
G1 X180.875 Y129.108 E.02473
G1 X168.408 Y129.108 E.38306
G3 X168.148 Y130.273 I-6.238 J-.778 E.03674
G1 X167.946 Y130.718 E.015
G1 X180.875 Y130.718 E.39725
G1 X180.875 Y129.973 E.02289
G1 X180.498 Y129.913 F30000
G1 F12000
G1 X180.498 Y129.485 E.01315
G1 X168.74 Y129.485 E.36127
G1 X168.521 Y130.341 E.02715
G1 X180.498 Y130.341 E.368
G1 X180.498 Y129.973 E.0113
G1 X169.082 Y129.913 F30000
; LINE_WIDTH: 0.52166
G1 F12000
G1 X180.01 Y129.913 E.42632
; WIPE_START
G1 X178.01 Y129.913 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X170.416 Y130.678 Z5.8 F30000
G1 X144.496 Y133.288 Z5.8
G1 Z5.4
G1 E.8 F1800
; LINE_WIDTH: 0.39674
G1 F12000
G1 X143.987 Y133.797 E.02077
G1 X107.6 Y134.121 F30000
; LINE_WIDTH: 0.457757
G1 F12000
G3 X108.358 Y133.36 I100.07 J99.021 E.03629
G1 X109.811 Y134.371 F30000
; LINE_WIDTH: 0.397923
G1 F12000
G1 X109.681 Y134.418 E.00401
G1 X107.771 Y134.418 E.05524
; LINE_WIDTH: 0.412563
G1 X107.698 Y134.403 E.00226
; LINE_WIDTH: 0.45749
G1 X107.624 Y134.387 E.00253
G1 X107.6 Y134.121 E.00904
G1 X107.332 Y134.388 E.01279
; LINE_WIDTH: 0.442828
G1 X107.258 Y134.403 E.00244
; LINE_WIDTH: 0.411343
G1 X107.185 Y134.418 E.00225
G1 X104.435 Y134.418 E.08258
G1 X104.253 Y134.19 E.00874
G1 X104.375 Y133.747 E.01382
G1 X104.035 Y133.572 E.01147
G1 X103.763 Y133.299 E.01157
G1 X102.984 Y133.299 E.0234
G3 X101.906 Y134.371 I-162.318 J-162.096 E.04562
G1 X101.776 Y134.418 E.00416
G1 X96.798 Y134.418 E.14945
G1 X96.616 Y134.19 E.00874
G1 X96.736 Y133.755 E.01356
G1 X96.379 Y133.591 E.01179
G1 X96.087 Y133.299 E.0124
G1 X95.347 Y133.299 E.02222
G3 X94.27 Y134.371 I-163.469 J-163.255 E.04562
G1 X94.139 Y134.418 E.00416
G1 X89.684 Y134.418 E.13375
G1 X89.501 Y134.197 E.00861
G1 X89.551 Y134.107 E.0031
G1 X90.359 Y133.299 E.0343
G1 X73.994 Y133.299 E.49129
G1 X73.994 Y134.761 E.04388
G1 X88.789 Y134.761 E.44417
G2 X96.798 Y134.772 I6.679 J-1899.218 E.24044
G1 X101.776 Y134.772 E.14945
G3 X107.185 Y134.772 I2.705 J795.355 E.1624
; LINE_WIDTH: 0.412563
G1 X107.332 Y134.757 E.00444
; LINE_WIDTH: 0.432739
G3 X107.771 Y134.772 I.183 J1.06 E.01407
; LINE_WIDTH: 0.408777
G3 X117.317 Y134.772 I4.773 J1016.192 E.2846
G3 X124.954 Y134.772 I3.818 J1249.185 E.22767
G3 X133.086 Y134.765 I5.833 J1974.047 E.24245
G2 X140.43 Y134.772 I4.854 J-1192.739 E.21892
G3 X143.794 Y134.772 I1.682 J90.105 E.1003
G1 X148.049 Y134.772 E.12688
G3 X155.91 Y134.767 I4.816 J1268.006 E.23434
G2 X161.931 Y134.772 I4.328 J-1444.554 E.17951
G3 X163.442 Y134.761 I1.018 J35.125 E.04504
G1 X182.006 Y134.761 E.55345
G1 X182.006 Y133.299 E.04358
G1 X163.139 Y133.299 E.56247
G3 X162.062 Y134.371 I-164.039 J-163.825 E.0453
G1 X161.931 Y134.418 E.00413
G1 X158.544 Y134.418 E.10098
G1 X158.356 Y134.249 E.00755
G1 X158.463 Y133.827 E.01298
G1 X158.027 Y133.805 E.013
G3 X157.495 Y133.299 I8.541 J-9.519 E.0219
G1 X157.344 Y133.299 E.00451
G3 X155.79 Y134.39 I-137.098 J-193.645 E.05658
G1 X155.685 Y134.418 E.00325
G1 X150.271 Y134.418 E.1614
G1 X150.083 Y134.224 E.00805
G1 X150.224 Y133.701 E.01615
G1 X149.819 Y133.299 E.017
G1 X149.677 Y133.326 E.00432
G3 X148.155 Y134.39 I-112.991 J-159.972 E.05537
G1 X148.049 Y134.418 E.00324
G1 X143.794 Y134.418 E.12688
G1 X143.606 Y134.256 E.0074
G1 X143.66 Y134.107 E.00471
G1 X143.945 Y133.839 E.01164
G1 X143.797 Y133.895 E.00469
G3 X142.663 Y133.763 I5.637 J-53.192 E.03406
G1 X142.552 Y133.709 E.00366
G1 X142.143 Y133.299 E.01726
G1 X141.637 Y133.299 E.01507
G3 X140.56 Y134.371 I-157.695 J-157.451 E.0453
G1 X140.43 Y134.418 E.00413
G1 X135.451 Y134.418 E.14841
G1 X135.263 Y134.241 E.0077
G1 X135.374 Y133.814 E.01317
G1 X134.953 Y133.768 E.01261
G1 X134.467 Y133.299 E.02013
G1 X134.001 Y133.299 E.0139
G3 X132.923 Y134.371 I-155.539 J-155.282 E.0453
G1 X132.793 Y134.418 E.00413
G1 X127.815 Y134.418 E.14841
G1 X127.626 Y134.251 E.0075
G1 X127.735 Y133.821 E.0132
G1 X126.565 Y133.763 E.03491
G1 X126.458 Y133.723 E.00339
G1 X126.394 Y133.519 E.00638
G1 X126.583 Y133.299 E.00864
G1 X126.162 Y133.299 E.01256
G3 X125.085 Y134.371 I-114.751 J-114.277 E.0453
G1 X124.954 Y134.418 E.00413
G1 X119.976 Y134.418 E.14841
G1 X119.788 Y134.227 E.00799
G1 X119.905 Y133.788 E.01355
G1 X119.516 Y133.694 E.01193
G1 X119.115 Y133.299 E.01677
G1 X118.525 Y133.299 E.01758
G3 X117.448 Y134.371 I-162.158 J-161.931 E.0453
G1 X117.317 Y134.418 E.00413
G1 X112.339 Y134.418 E.14841
G1 X112.151 Y134.231 E.0079
G1 X112.266 Y133.796 E.01342
G1 X111.867 Y133.717 E.01213
G1 X111.439 Y133.299 E.01783
G1 X110.888 Y133.299 E.01641
G3 X109.854 Y134.329 I-152.643 J-152.403 E.04352
G1 X162.588 Y134.384 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X181.629 Y134.384 E.58507
G1 X181.629 Y133.676 E.02174
G1 X163.295 Y133.676 E.56333
G1 X162.63 Y134.342 E.0289
G1 X163.442 Y134.03 F30000
; LINE_WIDTH: 0.3734
G1 F12000
G1 X181.215 Y134.03 E.47863
G1 X158.003 Y134.336 F30000
; LINE_WIDTH: 0.51625
G1 F12000
G1 X157.931 Y134.267 E.00386
G1 X157.937 Y134.216 E.00197
G1 X157.655 Y134.061 E.01237
G1 X157.385 Y133.791 E.01476
G1 X156.613 Y134.336 E.03643
G1 X157.943 Y134.336 E.05129
G1 X149.863 Y134.372 F30000
; LINE_WIDTH: 0.44309
G1 F12000
G1 X149.696 Y134.19 E.00807
G1 X149.766 Y133.794 E.01311
G1 X149.733 Y133.761 E.00151
G1 X148.865 Y134.372 E.03462
G1 X149.803 Y134.372 E.0306
G1 X142.874 Y134.277 F30000
; LINE_WIDTH: 0.61867
G1 F10942.25
G1 X143.079 Y134.289 E.00966
G1 X142.874 Y134.277 F30000
; LINE_WIDTH: 0.614354
G1 F11024.901
G1 X142.722 Y134.206 E.00779
; LINE_WIDTH: 0.573342
G1 F11877.352
G1 X142.571 Y134.135 E.00723
; LINE_WIDTH: 0.532329
G1 F12000
G1 X142.419 Y134.064 E.00667
; LINE_WIDTH: 0.491317
G1 X142.268 Y133.993 E.00611
; LINE_WIDTH: 0.494235
G1 X142.079 Y133.871 E.00827
; LINE_WIDTH: 0.561443
G1 X141.89 Y133.749 E.0095
G1 X141.823 Y133.749 E.00281
G1 X141.26 Y134.312 E.03364
G1 X141.89 Y134.312 E.0266
; LINE_WIDTH: 0.543368
G1 X142.008 Y134.328 E.00484
; LINE_WIDTH: 0.501084
G1 X142.125 Y134.344 E.00443
; LINE_WIDTH: 0.4588
G1 X142.243 Y134.36 E.00402
; LINE_WIDTH: 0.416516
G1 X142.36 Y134.377 E.00361
; LINE_WIDTH: 0.374232
G1 X142.478 Y134.393 E.0032
; LINE_WIDTH: 0.376571
G1 X142.534 Y134.376 E.0016
; LINE_WIDTH: 0.423533
G1 X142.59 Y134.36 E.00182
; LINE_WIDTH: 0.470495
G1 X142.647 Y134.343 E.00205
; LINE_WIDTH: 0.517456
G1 X142.703 Y134.327 E.00227
; LINE_WIDTH: 0.564418
G1 X142.76 Y134.31 E.0025
; LINE_WIDTH: 0.61138
G1 F11082.591
G1 X142.816 Y134.293 E.00272
G1 X134.891 Y134.316 F30000
; LINE_WIDTH: 0.55641
G1 F12000
G1 X134.818 Y134.242 E.00436
G1 X134.825 Y134.19 E.00221
G1 X134.581 Y134.043 E.0119
G1 X134.282 Y133.745 E.01767
G1 X134.151 Y133.779 E.0057
G1 X133.614 Y134.316 E.03176
G1 X134.831 Y134.316 E.05095
G1 X126.913 Y134.271 F30000
; LINE_WIDTH: 0.64009
G1 F10549.76
G1 X127.083 Y134.275 E.00827
G1 X126.913 Y134.271 F30000
; LINE_WIDTH: 0.621219
G1 F10894.032
G1 X126.849 Y134.243 E.0033
; LINE_WIDTH: 0.572015
G1 F11907.125
G1 X126.784 Y134.215 E.00302
; LINE_WIDTH: 0.522812
G1 F12000
G1 X126.72 Y134.187 E.00274
; LINE_WIDTH: 0.473609
G1 X126.656 Y134.159 E.00246
; LINE_WIDTH: 0.424405
G1 X126.592 Y134.132 E.00218
; LINE_WIDTH: 0.389467
G2 X126.222 Y134.026 I-.507 J1.081 E.0109
; LINE_WIDTH: 0.43468
G1 X126.164 Y133.841 E.00619
G1 X125.628 Y134.377 E.02417
; LINE_WIDTH: 0.41366
G1 X126.071 Y134.395 E.01338
; LINE_WIDTH: 0.37162
G1 X126.514 Y134.412 E.01187
; LINE_WIDTH: 0.375202
G1 X126.571 Y134.392 E.00164
; LINE_WIDTH: 0.424405
G1 X126.628 Y134.372 E.00188
; LINE_WIDTH: 0.473609
G1 X126.685 Y134.352 E.00213
; LINE_WIDTH: 0.522812
G1 X126.742 Y134.332 E.00237
; LINE_WIDTH: 0.572015
G1 F11907.125
G1 X126.799 Y134.311 E.00261
; LINE_WIDTH: 0.621219
G1 F10894.032
G1 X126.857 Y134.291 E.00286
G1 X119.584 Y134.384 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X119.412 Y134.199 E.00776
G1 X119.417 Y134.063 E.00418
G3 X118.959 Y133.676 I.663 J-1.251 E.01855
G1 X118.681 Y133.676 E.00852
G1 X117.974 Y134.384 E.03075
G1 X119.524 Y134.384 E.04763
G1 X118.84 Y133.998 F30000
; LINE_WIDTH: 0.3669
G1 F12000
G1 X118.78 Y134.033 E.00185
G1 X118.823 Y134.059 E.00134
G1 X111.938 Y134.384 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X111.774 Y134.213 E.00727
G1 X111.794 Y134.093 E.00371
G1 X111.559 Y133.953 E.0084
G1 X111.283 Y133.676 E.01201
G1 X111.045 Y133.676 E.00732
G1 X110.337 Y134.384 E.03075
G1 X111.878 Y134.384 E.04733
G1 X111.183 Y134.008 F30000
; LINE_WIDTH: 0.35066
G1 F12000
G1 X111.125 Y134.042 E.00167
G1 X111.164 Y134.064 E.00113
G1 X104.085 Y134.384 F30000
; LINE_WIDTH: 0.41999
G1 F12000
M73 P91 R2
G1 X103.879 Y134.136 E.00991
G1 X103.924 Y133.948 E.00592
G1 X103.607 Y133.676 E.01284
G1 X103.14 Y133.676 E.01435
G1 X102.432 Y134.384 E.03075
G1 X104.025 Y134.384 E.04893
G1 X103.286 Y134.03 F30000
; LINE_WIDTH: 0.3734
G1 F12000
G1 X103.4 Y134.03 E.00307
G1 X96.44 Y134.384 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X96.24 Y134.148 E.0095
G1 X96.284 Y133.974 E.00551
G3 X95.931 Y133.676 I1.015 J-1.563 E.01424
G1 X95.503 Y133.676 E.01314
G1 X94.796 Y134.384 E.03075
G1 X96.38 Y134.384 E.04868
G1 X95.65 Y134.03 F30000
; LINE_WIDTH: 0.3734
G1 F12000
G1 X95.724 Y134.03 E.00201
G1 X89.448 Y133.676 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X74.371 Y133.676 E.46327
G1 X74.371 Y134.384 E.02174
G1 X89.35 Y134.384 E.46023
G1 X89.133 Y134.111 E.01069
G1 X89.284 Y133.841 E.00951
G1 X89.406 Y133.719 E.00529
G1 X74.725 Y134.03 F30000
; LINE_WIDTH: 0.3734
G1 F12000
G1 X88.729 Y134.03 E.37713
G1 X92.467 Y131.782 F30000
; FEATURE: Bridge
; LINE_WIDTH: 0.40834
; LAYER_HEIGHT: 0.4
G1 F3000
G1 X90.233 Y134.016 E.16858
G1 X90.881 Y134.016 E.03459
G1 X93.05 Y131.847 E.16364
G2 X94.545 Y130.798 I-1.013 J-3.034 E.09882
G2 X94.769 Y130.489 I-1.547 J-1.355 E.02039
G1 X94.867 Y130.337 E.00965
G1 X95.208 Y130.337 E.01818
G1 X91.53 Y134.016 E.27756
G1 X92.178 Y134.016 E.03459
G1 X95.856 Y130.337 E.27756
G1 X96.504 Y130.337 E.03459
G1 X92.826 Y134.016 E.27756
G1 X93.474 Y134.016 E.03459
G1 X97.152 Y130.337 E.27756
G1 X97.801 Y130.337 E.03459
G1 X95.755 Y132.383 E.15434
G1 X96.079 Y132.707 E.02446
G1 X98.449 Y130.337 E.1788
G1 X99.097 Y130.337 E.03459
G1 X96.403 Y133.031 E.20325
G1 X96.64 Y133.268 E.01785
G1 X96.764 Y133.319 E.00715
G1 X99.745 Y130.337 E.22498
G1 X100.393 Y130.337 E.03459
G1 X97.222 Y133.509 E.23933
G1 X97.093 Y134.016 E.02788
G1 X97.363 Y134.016 E.01442
G1 X101.042 Y130.337 E.27756
G1 X101.69 Y130.337 E.03459
G1 X98.011 Y134.016 E.27756
G1 X98.66 Y134.016 E.03459
G1 X102.338 Y130.337 E.27756
G1 X102.986 Y130.337 E.03459
G1 X99.308 Y134.016 E.27756
G1 X99.956 Y134.016 E.03459
G1 X103.634 Y130.337 E.27756
G1 X104.282 Y130.337 E.03459
G1 X100.604 Y134.016 E.27756
G1 X101.252 Y134.016 E.03459
G1 X104.931 Y130.337 E.27756
G1 X105.579 Y130.337 E.03459
G1 X103.482 Y132.434 E.1582
G1 X103.806 Y132.758 E.02446
G1 X106.227 Y130.337 E.18266
G1 X106.875 Y130.337 E.03459
G1 X104.131 Y133.082 E.20711
G2 X104.509 Y133.352 I.573 J-.403 E.02527
G1 X107.285 Y130.575 E.20953
G2 X107.575 Y130.934 I1.887 J-1.223 E.02464
G1 X104.82 Y133.689 E.20787
G1 X104.73 Y134.016 E.01807
G1 X105.142 Y134.016 E.02197
G1 X107.903 Y131.254 E.20836
G2 X108.157 Y131.447 I.903 J-.925 E.01706
G1 X108.277 Y131.528 E.00774
G1 X105.79 Y134.016 E.18769
G1 X106.438 Y134.016 E.03459
G1 X108.701 Y131.753 E.17074
G1 X109.175 Y131.927 E.02696
G1 X106.884 Y134.218 E.1729
G1 X105.939 Y128.746 F30000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.450885
; LAYER_HEIGHT: 0.2
G1 F15000
G1 X96.061 Y128.746 E.32838
G1 X96.037 Y129.154 E.01359
G1 X105.963 Y129.154 E.32997
G1 X105.943 Y128.806 E.01159
G1 X106.331 Y128.354 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X95.669 Y128.354 E.32759
G3 X95.58 Y129.547 I-5.262 J.209 E.03684
G1 X106.422 Y129.547 E.33313
G3 X106.331 Y128.414 I4.002 J-.891 E.03504
G1 X106.707 Y127.977 F30000
G1 F15000
G1 X95.292 Y127.977 E.35073
G1 X95.292 Y128.9 E.02835
G1 X95.231 Y129.395 E.01533
G1 X95.073 Y129.924 E.01697
G1 X106.941 Y129.924 E.36466
G1 X106.772 Y129.404 E.01682
G1 X106.709 Y128.902 E.01552
G1 X106.707 Y128.037 E.02659
; WIPE_START
G1 X106.709 Y128.902 E-.32888
G1 X106.772 Y129.404 E-.19197
G1 X106.941 Y129.924 E-.20797
G1 X106.859 Y129.924 E-.03117
; WIPE_END
G1 E-.04 F1800
G1 X107.283 Y126.88 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.556 Y126.153 E.03158
G1 X106.023 Y126.153
G1 X107.232 Y127.362 E.05255
G1 X106.699 Y127.362
G1 X105.489 Y126.153 E.05255
G1 X104.956 Y126.153
G1 X106.165 Y127.362 E.05255
G1 X105.632 Y127.362
G1 X104.423 Y126.153 E.05255
G1 X103.89 Y126.153
G1 X105.099 Y127.362 E.05255
G1 X104.566 Y127.362
G1 X103.356 Y126.153 E.05255
G1 X102.823 Y126.153
G1 X104.032 Y127.362 E.05255
G1 X103.499 Y127.362
G1 X102.29 Y126.153 E.05255
G1 X101.757 Y126.153
G1 X102.966 Y127.362 E.05255
G1 X102.433 Y127.362
G1 X101.223 Y126.153 E.05255
G1 X100.69 Y126.153
G1 X101.899 Y127.362 E.05255
G1 X101.366 Y127.362
G1 X100.157 Y126.153 E.05255
G1 X99.624 Y126.153
G1 X100.833 Y127.362 E.05255
G1 X100.3 Y127.362
G1 X99.09 Y126.153 E.05255
G1 X98.557 Y126.153
G1 X99.766 Y127.362 E.05255
G1 X99.233 Y127.362
G1 X98.024 Y126.153 E.05255
G1 X97.491 Y126.153
G1 X98.7 Y127.362 E.05255
G1 X98.167 Y127.362
G1 X96.957 Y126.153 E.05255
G1 X96.424 Y126.153
G1 X97.633 Y127.362 E.05255
G1 X97.1 Y127.362
G1 X95.891 Y126.153 E.05255
G1 X95.358 Y126.153
G1 X96.567 Y127.362 E.05255
G1 X96.034 Y127.362
G1 X94.824 Y126.153 E.05255
G1 X94.717 Y126.579
G1 X95.5 Y127.362 E.03405
; WIPE_START
M204 S10000
G1 X94.717 Y126.579 E-.42112
G1 X94.824 Y126.153 E-.16685
G1 X95.144 Y126.473 E-.17203
; WIPE_END
G1 E-.04 F1800
G1 X88.425 Y126.153 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X89.283 Y127.01 E.03726
G1 X89.101 Y127.362
G1 X87.892 Y126.153 E.05255
G1 X87.359 Y126.153
G1 X88.568 Y127.362 E.05255
G1 X88.035 Y127.362
G1 X86.825 Y126.153 E.05255
G1 X86.292 Y126.153
G1 X87.501 Y127.362 E.05255
G1 X86.968 Y127.362
G1 X85.759 Y126.153 E.05255
G1 X85.226 Y126.153
G1 X86.435 Y127.362 E.05255
G1 X85.902 Y127.362
G1 X84.692 Y126.153 E.05255
G1 X84.159 Y126.153
G1 X85.368 Y127.362 E.05255
G1 X84.835 Y127.362
G1 X83.626 Y126.153 E.05255
G1 X83.093 Y126.153
G1 X84.302 Y127.362 E.05255
G1 X83.769 Y127.362
G1 X82.559 Y126.153 E.05255
G1 X82.026 Y126.153
G1 X83.235 Y127.362 E.05255
G1 X82.702 Y127.362
G1 X81.493 Y126.153 E.05255
G1 X80.96 Y126.153
G1 X82.169 Y127.362 E.05255
G1 X81.636 Y127.362
G1 X80.426 Y126.153 E.05255
G1 X79.893 Y126.153
G1 X81.102 Y127.362 E.05255
G1 X80.569 Y127.362
G1 X79.36 Y126.153 E.05255
G1 X78.827 Y126.153
G1 X80.036 Y127.362 E.05255
G1 X79.503 Y127.362
G1 X78.293 Y126.153 E.05255
G1 X77.76 Y126.153
G1 X78.969 Y127.362 E.05255
G1 X78.436 Y127.362
G1 X77.227 Y126.153 E.05255
G1 X76.693 Y126.153
G1 X77.903 Y127.362 E.05255
G1 X77.37 Y127.362
G1 X76.16 Y126.153 E.05255
G1 X75.627 Y126.153
G1 X76.836 Y127.362 E.05255
G1 X76.303 Y127.362
G1 X75.094 Y126.153 E.05255
G1 X74.56 Y126.153
G1 X75.77 Y127.362 E.05255
G1 X75.237 Y127.362
G1 X74.027 Y126.153 E.05255
G1 X73.494 Y126.153
G1 X74.703 Y127.362 E.05255
G1 X74.17 Y127.362
G1 X73.417 Y126.61 E.03271
; WIPE_START
M204 S10000
G1 X74.17 Y127.362 E-.40447
G1 X74.703 Y127.362 E-.20264
G1 X74.419 Y127.078 E-.15289
; WIPE_END
G1 E-.04 F1800
G1 X73.994 Y127.977 Z5.8 F30000
G1 Z5.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X88.706 Y127.977 E.45204
G1 X88.707 Y128.782 E.02474
G1 X88.783 Y129.452 E.02072
G1 X89.021 Y130.155 E.0228
G1 X89.381 Y130.747 E.0213
G1 X89.767 Y131.171 E.01761
G1 X90.285 Y131.562 E.01995
G1 X90.897 Y131.849 E.02076
G1 X77.554 Y131.849 E.40998
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X73.994 Y131.849 E.10937
G1 X73.994 Y131.153 E.02138
; Slow Down End
G1 F12000
G1 X73.994 Y128.037 E.09576
G1 X74.371 Y131.472 F30000
G1 F12000
G1 X74.371 Y128.354 E.09581
G1 X88.329 Y128.354 E.42887
G1 X88.332 Y128.822 E.01438
G1 X88.425 Y129.571 E.0232
G1 X88.698 Y130.349 E.02533
G1 X89.101 Y131 E.02351
G1 X89.537 Y131.471 E.01975
G3 X84.714 Y131.472 I-2.466 J-381.012 E.14821
G1 X74.431 Y131.472 E.31596
G1 X88.706 Y131.095 F30000
G1 F12000
G1 X88.375 Y130.543 E.01978
G1 X88.067 Y129.69 E.02786
G1 X87.952 Y128.731 E.02969
G1 X74.748 Y128.731 E.4057
G1 X74.748 Y131.095 E.07264
G1 X88.646 Y131.095 E.42703
G1 X88.042 Y130.718 F30000
G1 F12000
G1 X87.709 Y129.809 E.02974
G1 X87.604 Y129.108 E.02179
G1 X75.125 Y129.108 E.38342
G1 X75.125 Y130.718 E.04947
G1 X87.982 Y130.718 E.39505
G1 X87.489 Y130.341 F30000
G1 F12000
G1 X87.316 Y129.808 E.0172
G1 X87.265 Y129.485 E.01005
G1 X75.502 Y129.485 E.36142
G1 X75.502 Y130.341 E.0263
G1 X87.429 Y130.341 E.36645
G1 X75.93 Y129.913 F30000
; LINE_WIDTH: 0.52164
G1 F12000
G1 X86.841 Y129.913 E.42564
G1 X76.665 Y132.907 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X75.037 Y132.907 E.05401
G1 X75.703 Y132.241 E.03125
G1 X80.51 Y132.241 E.15944
G1 X81.176 Y132.907 E.03125
G1 X82.713 Y132.907 E.051
G1 X83.379 Y132.241 E.03125
G1 X88.185 Y132.241 E.15944
G1 X88.852 Y132.907 E.03125
G1 X90.389 Y132.907 E.051
G1 X91.055 Y132.241 E.03125
G1 X89.427 Y132.241 E.05401
; WIPE_START
G1 X91.055 Y132.241 E-.61876
G1 X90.792 Y132.504 E-.14124
; WIPE_END
G1 E-.04 F1800
G1 X98.403 Y131.929 Z5.8 F30000
G1 X124.941 Y129.924 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X124.772 Y129.404 E.01682
G1 X124.709 Y128.902 E.01552
G1 X124.707 Y127.977 E.02844
G1 X113.292 Y127.977 E.35073
G1 X113.292 Y128.891 E.02809
G1 X113.165 Y129.66 E.02395
G1 X113.063 Y129.924 E.00869
G1 X124.881 Y129.924 E.36314
G1 X124.422 Y129.547 F30000
G1 F12000
G3 X124.331 Y128.354 I4.216 J-.923 E.03688
G1 X113.669 Y128.354 E.32759
G1 X113.669 Y128.891 E.01651
G1 X113.567 Y129.547 E.02039
G1 X124.362 Y129.547 E.33171
G1 X123.963 Y129.154 F30000
; LINE_WIDTH: 0.450885
G1 F12000
G1 X123.939 Y128.746 E.01359
G1 X114.061 Y128.746 E.32838
G1 X114.03 Y129.154 E.0136
G1 X123.903 Y129.154 E.32821
; WIPE_START
G1 X121.903 Y129.154 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X129.53 Y129.433 Z5.8 F30000
G1 X142.941 Y129.924 Z5.8
G1 Z5.4
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F12000
G1 X142.772 Y129.403 E.01682
G1 X142.709 Y128.902 E.01552
G1 X142.707 Y127.977 E.02844
G1 X131.29 Y127.977 E.3508
G1 X131.262 Y129.204 E.03772
G1 X131.154 Y129.7 E.01558
G1 X131.063 Y129.924 E.00744
G1 X142.881 Y129.924 E.36314
G1 X142.422 Y129.547 F30000
G1 F12000
G3 X142.331 Y128.354 I4.214 J-.923 E.03688
G1 X131.659 Y128.354 E.32792
G1 X131.639 Y129.213 E.02639
G1 X131.576 Y129.547 E.01045
G1 X142.362 Y129.547 E.3314
G1 X141.963 Y129.154 F30000
; LINE_WIDTH: 0.450885
G1 F12000
G1 X141.939 Y128.746 E.01359
G1 X132.042 Y128.746 E.32901
G1 X132.033 Y129.154 E.01357
G1 X141.903 Y129.154 E.32812
; CHANGE_LAYER
; Z_HEIGHT: 5.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X139.903 Y129.154 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 28/33
; update layer progress
M73 L28
M991 S0 P27 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z5.8 I.023 J1.217 P1  F30000
G1 X182.398 Y128.356 Z5.8
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y134.699 E.21039
G1 X73.602 Y134.699 E3.60896
G1 X73.602 Y128.356 E.21039
G1 X89.098 Y128.356 E.51403
G1 X89.098 Y128.757 E.01331
G2 X94.899 Y128.881 I2.902 J-.015 E.2974
G1 X94.9 Y128.356 E.0174
G1 X107.098 Y128.356 E.40463
G2 X107.65 Y130.453 I3.224 J.273 E.07335
G2 X112.899 Y128.881 I2.347 J-1.713 E.23741
G1 X112.9 Y128.356 E.0174
G1 X125.098 Y128.356 E.40463
G2 X125.65 Y130.453 I3.224 J.273 E.07335
G2 X130.902 Y128.757 I2.35 J-1.704 E.24181
G1 X130.902 Y128.356 E.01329
G1 X143.098 Y128.356 E.40456
G2 X143.65 Y130.453 I3.223 J.273 E.07336
G2 X148.902 Y128.757 I2.35 J-1.704 E.2418
G1 X148.902 Y128.356 E.01329
G1 X161.098 Y128.356 E.40456
G2 X161.65 Y130.453 I3.223 J.273 E.07336
G2 X166.902 Y128.757 I2.35 J-1.704 E.2418
G1 X166.902 Y128.356 E.01329
G1 X182.338 Y128.356 E.51204
; WIPE_START
G1 X182.357 Y130.356 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y126.717 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y135.091 E.2573
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y135.091 E3.36709
G1 X73.21 Y126.717 E.2573
G1 X89.49 Y126.717 E.50024
G1 X89.49 Y128.752 E.06254
G2 X94.507 Y128.867 I2.51 J-.009 E.23825
G1 X94.51 Y126.717 E.06605
G1 X107.49 Y126.717 E.39885
G2 X107.493 Y128.871 I44.62 J1.018 E.06619
G2 X112.507 Y128.867 I2.507 J-.123 E.23487
G1 X112.51 Y126.717 E.06605
G1 X125.49 Y126.717 E.39885
G2 X125.493 Y128.871 I44.62 J1.018 E.06619
G2 X130.51 Y128.752 I2.507 J-.128 E.23808
G1 X130.51 Y126.717 E.06254
G1 X143.49 Y126.717 E.39884
G2 X143.493 Y128.871 I44.776 J1.018 E.06619
G2 X148.51 Y128.752 I2.507 J-.128 E.23809
G1 X148.51 Y126.717 E.06254
G1 X161.49 Y126.717 E.39884
G2 X161.493 Y128.871 I44.776 J1.018 E.06619
G2 X166.51 Y128.752 I2.507 J-.128 E.23809
G1 X166.51 Y126.717 E.06254
G1 X182.73 Y126.717 E.4984
M204 S10000
G1 X182.583 Y127.676 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.125 Y128.134 E.01989
G1 X181.592 Y128.134
G1 X182.583 Y127.143 E.04306
G1 X182.268 Y126.924
G1 X181.058 Y128.134 E.05255
G1 X180.525 Y128.134
G1 X181.734 Y126.924 E.05255
G1 X181.201 Y126.924
G1 X179.992 Y128.134 E.05255
G1 X179.459 Y128.134
G1 X180.668 Y126.924 E.05255
G1 X180.135 Y126.924
G1 X178.925 Y128.134 E.05255
G1 X178.392 Y128.134
G1 X179.601 Y126.924 E.05255
G1 X179.068 Y126.924
G1 X177.859 Y128.134 E.05255
G1 X177.326 Y128.134
G1 X178.535 Y126.924 E.05255
G1 X178.002 Y126.924
G1 X176.792 Y128.134 E.05255
G1 X176.259 Y128.134
G1 X177.468 Y126.924 E.05255
G1 X176.935 Y126.924
G1 X175.726 Y128.134 E.05255
G1 X175.193 Y128.134
G1 X176.402 Y126.924 E.05255
G1 X175.869 Y126.924
G1 X174.659 Y128.134 E.05255
G1 X174.126 Y128.134
G1 X175.335 Y126.924 E.05255
G1 X174.802 Y126.924
G1 X173.593 Y128.134 E.05255
G1 X173.06 Y128.134
G1 X174.269 Y126.924 E.05255
G1 X173.736 Y126.924
G1 X172.526 Y128.134 E.05255
G1 X171.993 Y128.134
G1 X173.202 Y126.924 E.05255
G1 X172.669 Y126.924
G1 X171.46 Y128.134 E.05255
G1 X170.927 Y128.134
G1 X172.136 Y126.924 E.05255
G1 X171.603 Y126.924
G1 X170.393 Y128.134 E.05255
G1 X169.86 Y128.134
G1 X171.069 Y126.924 E.05255
G1 X170.536 Y126.924
G1 X169.327 Y128.134 E.05255
G1 X168.794 Y128.134
G1 X170.003 Y126.924 E.05255
G1 X169.47 Y126.924
G1 X168.26 Y128.134 E.05255
G1 X167.727 Y128.134
G1 X168.936 Y126.924 E.05255
G1 X168.403 Y126.924
G1 X167.194 Y128.134 E.05255
G1 X166.717 Y128.077
G1 X167.87 Y126.924 E.05008
G1 X167.337 Y126.924
G1 X166.717 Y127.543 E.0269
; WIPE_START
M204 S10000
G1 X167.337 Y126.924 E-.33272
G1 X167.87 Y126.924 E-.20264
G1 X167.452 Y127.342 E-.22464
; WIPE_END
G1 E-.04 F1800
G1 X164.418 Y131.95 Z6 F30000
G1 Z5.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X164.642 Y131.936 E.00623
G1 X182.006 Y130.322 F30000
; LINE_WIDTH: 0.419443
G1 F12000
G1 X182.006 Y128.748 E.04828
G1 X167.287 Y128.748 E.45161
G1 X167.278 Y129.077 E.0101
G1 X167.163 Y129.669 E.01849
G1 X166.853 Y130.396 E.02424
G1 X166.48 Y130.919 E.0197
G1 X165.933 Y131.416 E.02269
G1 X165.337 Y131.761 E.02112
G1 X164.724 Y131.929 E.01951
G1 X165.321 Y131.895 E.01836
G1 X182.006 Y131.895 E.51192
G1 X182.006 Y130.382 E.04644
G1 X181.629 Y130.322 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X181.629 Y129.125 E.03677
G1 X167.65 Y129.125 E.42951
G1 X167.533 Y129.741 E.01925
G1 X167.199 Y130.546 E.02677
G1 X166.786 Y131.14 E.02224
G1 X166.383 Y131.518 E.01698
G1 X181.629 Y131.518 E.46845
G1 X181.629 Y130.382 E.03492
G1 X181.252 Y130.322 F30000
G1 F12000
G1 X181.252 Y129.502 E.02518
G1 X167.963 Y129.502 E.4083
G1 X167.846 Y130.002 E.01576
G1 X167.545 Y130.695 E.02323
G1 X167.25 Y131.141 E.01643
G1 X181.252 Y131.141 E.43023
G1 X181.252 Y130.382 E.02334
G1 X180.875 Y130.322 F30000
G1 F12000
G1 X180.875 Y129.879 E.01359
G1 X168.274 Y129.879 E.38716
G1 X167.926 Y130.764 E.02921
G1 X180.875 Y130.764 E.39786
G1 X180.875 Y130.382 E.01175
G1 X168.6 Y130.322 F30000
; LINE_WIDTH: 0.55062
G1 F12000
G1 X180.372 Y130.322 E.48704
G1 X179.061 Y132.634 F30000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X180.689 Y132.634 E.05401
G1 X180.343 Y132.287 E.01625
G1 X175.444 Y132.287 E.1625
G1 X175.098 Y132.634 E.01625
G1 X173.013 Y132.634 E.06915
G1 X172.667 Y132.287 E.01625
G1 X167.768 Y132.287 E.1625
G1 X167.422 Y132.634 E.01625
G1 X165.337 Y132.634 E.06915
G1 X164.991 Y132.287 E.01625
G1 X164.1 Y132.287 E.02957
G1 X164.082 Y132.001 E.00952
M73 P92 R2
G1 X163.857 Y131.99 E.00749
G1 X163.832 Y132.287 E.0099
G1 X160.092 Y132.287 E.12406
G1 X159.746 Y132.634 E.01625
G1 X157.662 Y132.634 E.06915
G1 X157.315 Y132.287 E.01625
G1 X152.416 Y132.287 E.1625
G1 X152.07 Y132.634 E.01625
G1 X149.986 Y132.634 E.06915
G1 X149.639 Y132.287 E.01625
G1 X146.1 Y132.287 E.11741
G1 X146.082 Y132.001 E.00952
G1 X145.857 Y131.99 E.00749
G1 X145.832 Y132.287 E.0099
G1 X144.74 Y132.287 E.03621
G1 X144.394 Y132.634 E.01625
G1 X142.31 Y132.634 E.06915
G1 X141.963 Y132.287 E.01625
G1 X137.065 Y132.287 E.1625
G1 X136.718 Y132.634 E.01625
G1 X134.634 Y132.634 E.06915
G1 X134.287 Y132.287 E.01625
G1 X129.389 Y132.287 E.1625
G1 X129.042 Y132.634 E.01625
G1 X126.958 Y132.634 E.06915
G1 X126.611 Y132.287 E.01625
G1 X121.713 Y132.287 E.1625
G1 X121.366 Y132.634 E.01625
G1 X119.282 Y132.634 E.06915
G1 X118.935 Y132.287 E.01625
G1 X114.037 Y132.287 E.1625
G1 X113.69 Y132.634 E.01625
G1 X111.606 Y132.634 E.06915
G1 X111.259 Y132.287 E.01625
G1 X110.138 Y132.287 E.03721
G1 X110.117 Y131.996 E.00969
G3 X109.884 Y131.997 I-.121 J-1.758 E.00772
G1 X109.863 Y132.287 E.00966
G1 X106.361 Y132.287 E.11617
G1 X106.014 Y132.634 E.01625
G1 X103.93 Y132.634 E.06915
G1 X103.584 Y132.287 E.01625
G1 X98.685 Y132.287 E.1625
G1 X98.338 Y132.634 E.01625
G1 X96.254 Y132.634 E.06915
G1 X95.908 Y132.287 E.01625
G1 X92.156 Y132.287 E.12444
G1 X92.13 Y131.996 E.00969
G3 X91.847 Y131.984 I-.101 J-.98 E.00943
G1 X91.814 Y132.287 E.01011
G1 X91.009 Y132.287 E.02671
G1 X90.662 Y132.634 E.01625
G1 X88.578 Y132.634 E.06915
G1 X88.232 Y132.287 E.01625
G1 X83.333 Y132.287 E.1625
G1 X82.987 Y132.634 E.01625
G1 X80.902 Y132.634 E.06915
G1 X80.556 Y132.287 E.01625
G1 X75.657 Y132.287 E.1625
G1 X75.311 Y132.634 E.01625
G1 X76.939 Y132.634 E.05401
G1 X73.994 Y134.307 F30000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X182.006 Y134.307 E3.31882
G1 X182.006 Y133.026 E.03936
G1 X73.994 Y133.026 E3.31882
G1 X73.994 Y134.247 E.03751
G1 X74.409 Y133.892 F30000
; LINE_WIDTH: 0.49481
G1 F12000
G1 X181.591 Y133.892 E3.94683
G1 X181.591 Y133.44 E.01664
G1 X74.409 Y133.44 E3.94683
G1 X74.409 Y133.832 E.01443
; WIPE_START
G1 X74.409 Y133.44 E-.14892
G1 X76.017 Y133.44 E-.61108
; WIPE_END
G1 E-.04 F1800
G1 X83.013 Y130.39 Z6 F30000
G1 X89.283 Y127.656 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.805 Y128.134 E.02076
G1 X88.272 Y128.134
G1 X89.283 Y127.123 E.04393
G1 X88.948 Y126.924
G1 X87.738 Y128.134 E.05255
G1 X87.205 Y128.134
G1 X88.414 Y126.924 E.05255
G1 X87.881 Y126.924
G1 X86.672 Y128.134 E.05255
G1 X86.139 Y128.134
G1 X87.348 Y126.924 E.05255
G1 X86.815 Y126.924
G1 X85.605 Y128.134 E.05255
G1 X85.072 Y128.134
G1 X86.281 Y126.924 E.05255
G1 X85.748 Y126.924
G1 X84.539 Y128.134 E.05255
G1 X84.006 Y128.134
G1 X85.215 Y126.924 E.05255
G1 X84.682 Y126.924
G1 X83.472 Y128.134 E.05255
G1 X82.939 Y128.134
G1 X84.148 Y126.924 E.05255
G1 X83.615 Y126.924
G1 X82.406 Y128.134 E.05255
G1 X81.873 Y128.134
G1 X83.082 Y126.924 E.05255
G1 X82.549 Y126.924
G1 X81.339 Y128.134 E.05255
G1 X80.806 Y128.134
G1 X82.015 Y126.924 E.05255
G1 X81.482 Y126.924
G1 X80.273 Y128.134 E.05255
G1 X79.739 Y128.134
G1 X80.949 Y126.924 E.05255
G1 X80.416 Y126.924
G1 X79.206 Y128.134 E.05255
G1 X78.673 Y128.134
G1 X79.882 Y126.924 E.05255
G1 X79.349 Y126.924
G1 X78.14 Y128.134 E.05255
G1 X77.606 Y128.134
G1 X78.816 Y126.924 E.05255
G1 X78.283 Y126.924
G1 X77.073 Y128.134 E.05255
G1 X76.54 Y128.134
G1 X77.749 Y126.924 E.05255
G1 X77.216 Y126.924
G1 X76.007 Y128.134 E.05255
G1 X75.473 Y128.134
G1 X76.683 Y126.924 E.05255
G1 X76.149 Y126.924
G1 X74.94 Y128.134 E.05255
G1 X74.407 Y128.134
G1 X75.616 Y126.924 E.05255
G1 X75.083 Y126.924
G1 X73.874 Y128.134 E.05255
G1 X73.417 Y128.057
G1 X74.55 Y126.924 E.0492
G1 X74.016 Y126.924
G1 X73.417 Y127.523 E.02603
; WIPE_START
M204 S10000
G1 X74.016 Y126.924 E-.32194
G1 X74.55 Y126.924 E-.20264
G1 X74.112 Y127.362 E-.23543
; WIPE_END
G1 E-.04 F1800
G1 X81.486 Y129.332 Z6 F30000
G1 X91.157 Y131.914 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X91.445 Y131.938 E.00801
G1 X91.157 Y131.914 F30000
; LINE_WIDTH: 0.419443
G1 F12000
G1 X90.557 Y131.711 E.01944
G1 X90.007 Y131.373 E.0198
G1 X89.446 Y130.829 E.02397
G1 X89.092 Y130.296 E.01964
G1 X88.858 Y129.73 E.0188
G1 X88.723 Y129.085 E.02021
G1 X88.711 Y128.748 E.01034
G1 X73.994 Y128.748 E.45155
G1 X73.994 Y131.895 E.09656
G1 X90.523 Y131.895 E.50714
G1 X91.097 Y131.909 E.01762
G1 X89.611 Y131.518 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X89.182 Y131.099 E.01843
G1 X88.776 Y130.503 E.02215
G1 X88.509 Y129.872 E.02106
G1 X88.353 Y129.157 E.02247
G1 X88.315 Y129.125 E.00153
G1 X74.371 Y129.125 E.42843
G1 X74.371 Y131.518 E.07353
G1 X89.551 Y131.518 E.46641
G1 X88.744 Y131.141 F30000
G1 F12000
G1 X88.461 Y130.709 E.01587
G1 X88.159 Y130.014 E.0233
G1 X88.036 Y129.502 E.01616
G1 X74.748 Y129.502 E.40829
G1 X74.748 Y131.141 E.05036
G1 X88.684 Y131.141 E.42819
G1 X88.066 Y130.764 F30000
G1 F12000
G3 X87.722 Y129.884 I5.084 J-2.496 E.02908
G1 X75.125 Y129.879 E.38704
G1 X75.125 Y130.764 E.02719
G1 X88.006 Y130.764 E.39577
G1 X75.568 Y130.322 F30000
; LINE_WIDTH: 0.55062
G1 F12000
G1 X87.34 Y130.322 E.48703
; WIPE_START
G1 X85.34 Y130.322 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X92.922 Y129.446 Z6 F30000
G1 X107.283 Y127.787 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X106.936 Y128.134 E.01508
G1 X106.402 Y128.134
G1 X107.283 Y127.253 E.03825
G1 X107.078 Y126.924
G1 X105.869 Y128.134 E.05255
G1 X105.336 Y128.134
G1 X106.545 Y126.924 E.05255
G1 X106.012 Y126.924
G1 X104.803 Y128.134 E.05255
G1 X104.269 Y128.134
G1 X105.479 Y126.924 E.05255
G1 X104.945 Y126.924
G1 X103.736 Y128.134 E.05255
G1 X103.203 Y128.134
G1 X104.412 Y126.924 E.05255
G1 X103.879 Y126.924
G1 X102.67 Y128.134 E.05255
G1 X102.136 Y128.134
G1 X103.346 Y126.924 E.05255
G1 X102.812 Y126.924
G1 X101.603 Y128.134 E.05255
G1 X101.07 Y128.134
G1 X102.279 Y126.924 E.05255
G1 X101.746 Y126.924
G1 X100.537 Y128.134 E.05255
G1 X100.003 Y128.134
G1 X101.213 Y126.924 E.05255
G1 X100.679 Y126.924
G1 X99.47 Y128.134 E.05255
G1 X98.937 Y128.134
G1 X100.146 Y126.924 E.05255
G1 X99.613 Y126.924
G1 X98.404 Y128.134 E.05255
G1 X97.87 Y128.134
G1 X99.08 Y126.924 E.05255
G1 X98.546 Y126.924
G1 X97.337 Y128.134 E.05255
G1 X96.804 Y128.134
G1 X98.013 Y126.924 E.05255
G1 X97.48 Y126.924
G1 X96.27 Y128.134 E.05255
G1 X95.737 Y128.134
G1 X96.947 Y126.924 E.05255
G1 X96.413 Y126.924
G1 X95.204 Y128.134 E.05255
G1 X94.716 Y128.089
G1 X95.88 Y126.924 E.0506
G1 X95.347 Y126.924
G1 X94.716 Y127.555 E.0274
; WIPE_START
M204 S10000
G1 X95.347 Y126.924 E-.33884
G1 X95.88 Y126.924 E-.20264
G1 X95.473 Y127.331 E-.21852
; WIPE_END
G1 E-.04 F1800
G1 X102.716 Y129.74 Z6 F30000
G1 X109.306 Y131.933 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X109.49 Y131.946 E.0051
G1 X109.306 Y131.933 F30000
; LINE_WIDTH: 0.419305
G1 F12000
G1 X108.609 Y131.735 E.02224
G1 X108.013 Y131.378 E.02128
G3 X107.318 Y130.661 I1.952 J-2.592 E.03075
G1 X106.958 Y130.012 E.02277
G1 X106.771 Y129.399 E.01964
G1 X106.722 Y128.748 E.02003
G1 X95.286 Y128.748 E.35076
G1 X95.278 Y129.077 E.01009
G1 X95.163 Y129.669 E.0185
G1 X94.924 Y130.266 E.0197
G1 X94.579 Y130.799 E.0195
G1 X94.135 Y131.259 E.0196
G1 X93.724 Y131.556 E.01554
G3 X92.996 Y131.892 I-3.883 J-7.446 E.02461
G1 X108.582 Y131.895 E.47801
G1 X109.246 Y131.928 E.02041
G1 X107.599 Y131.518 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X107.344 Y131.284 E.01065
G1 X106.988 Y130.844 E.01739
G1 X106.628 Y130.195 E.02281
G1 X106.41 Y129.507 E.02216
G1 X106.37 Y129.125 E.0118
G1 X95.65 Y129.125 E.32937
G1 X95.533 Y129.741 E.01925
G1 X95.274 Y130.408 E.02198
G1 X94.894 Y131.006 E.02178
G1 X94.408 Y131.518 E.02169
G1 X107.539 Y131.518 E.40347
G1 X106.737 Y131.141 F30000
G1 F12000
G1 X106.298 Y130.377 E.02707
G1 X106.048 Y129.615 E.02465
G1 X106.028 Y129.502 E.00351
G1 X95.963 Y129.502 E.30925
G3 X95.256 Y131.141 I-4.078 J-.787 E.05527
G1 X106.677 Y131.141 E.35091
G1 X106.082 Y130.764 F30000
G1 F12000
G3 X105.734 Y129.879 I2.625 J-1.543 E.02933
G1 X96.274 Y129.879 E.29065
G1 X95.934 Y130.764 E.02913
G1 X106.022 Y130.764 E.30995
G1 X96.6 Y130.322 F30000
; LINE_WIDTH: 0.55062
G1 F12000
G1 X105.344 Y130.322 E.36174
; WIPE_START
G1 X103.344 Y130.322 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X110.909 Y129.309 Z6 F30000
G1 X125.283 Y127.384 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X124.533 Y128.134 E.03257
G1 X124 Y128.134
G1 X125.209 Y126.924 E.05255
G1 X124.676 Y126.924
G1 X123.467 Y128.134 E.05255
G1 X122.933 Y128.134
G1 X124.143 Y126.924 E.05255
G1 X123.609 Y126.924
G1 X122.4 Y128.134 E.05255
G1 X121.867 Y128.134
G1 X123.076 Y126.924 E.05255
G1 X122.543 Y126.924
G1 X121.334 Y128.134 E.05255
G1 X120.8 Y128.134
G1 X122.01 Y126.924 E.05255
G1 X121.476 Y126.924
G1 X120.267 Y128.134 E.05255
G1 X119.734 Y128.134
G1 X120.943 Y126.924 E.05255
G1 X120.41 Y126.924
G1 X119.201 Y128.134 E.05255
G1 X118.667 Y128.134
G1 X119.877 Y126.924 E.05255
G1 X119.343 Y126.924
G1 X118.134 Y128.134 E.05255
G1 X117.601 Y128.134
G1 X118.81 Y126.924 E.05255
G1 X118.277 Y126.924
G1 X117.068 Y128.134 E.05255
G1 X116.534 Y128.134
G1 X117.744 Y126.924 E.05255
G1 X117.21 Y126.924
G1 X116.001 Y128.134 E.05255
G1 X115.468 Y128.134
G1 X116.677 Y126.924 E.05255
G1 X116.144 Y126.924
G1 X114.934 Y128.134 E.05255
G1 X114.401 Y128.134
G1 X115.611 Y126.924 E.05255
G1 X115.077 Y126.924
G1 X113.868 Y128.134 E.05255
G1 X113.335 Y128.134
G1 X114.544 Y126.924 E.05255
G1 X114.011 Y126.924
G1 X112.801 Y128.134 E.05255
G1 X112.716 Y127.686
G1 X113.478 Y126.924 E.03309
; WIPE_START
M204 S10000
G1 X112.716 Y127.686 E-.40918
G1 X112.801 Y128.134 E-.17326
G1 X113.132 Y127.803 E-.17756
; WIPE_END
G1 E-.04 F1800
G1 X120.461 Y129.933 Z6 F30000
G1 X127.36 Y131.938 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X127.461 Y131.945 E.00281
G1 X127.36 Y131.938 F30000
; LINE_WIDTH: 0.419353
G1 F12000
G1 X126.704 Y131.778 E.02072
G1 X126.147 Y131.474 E.01949
G1 X125.655 Y131.064 E.01964
G1 X125.195 Y130.475 E.02293
G1 X124.899 Y129.861 E.0209
G1 X124.743 Y129.242 E.01956
G1 X124.716 Y128.748 E.01518
G1 X113.277 Y128.748 E.35089
G1 X113.237 Y129.354 E.01861
G1 X113.088 Y129.874 E.0166
G1 X112.677 Y130.668 E.02743
G1 X112.253 Y131.153 E.01975
G1 X111.665 Y131.591 E.02252
G1 X111.086 Y131.859 E.01954
G1 X110.936 Y131.895 E.00474
G1 X126.686 Y131.895 E.48311
G1 X127.301 Y131.933 E.01889
G1 X125.609 Y131.518 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X125.328 Y131.265 E.01161
G1 X124.896 Y130.705 E.02174
G1 X124.558 Y130.022 E.02341
G1 X124.377 Y129.333 E.0219
G1 X124.357 Y129.125 E.0064
G1 X113.63 Y129.125 E.32959
G1 X113.591 Y129.502 E.01165
G1 X113.42 Y130.08 E.01851
G1 X113.007 Y130.851 E.0269
G1 X112.535 Y131.403 E.02229
G1 X112.4 Y131.518 E.00547
G1 X125.549 Y131.518 E.40403
G1 X124.757 Y131.141 F30000
G1 F12000
G1 X124.492 Y130.763 E.0142
G1 X124.218 Y130.183 E.01969
G1 X124.031 Y129.502 E.02169
G1 X113.972 Y129.502 E.30906
G3 X113.702 Y130.377 I-4.829 J-1.014 E.02816
G1 X113.336 Y131.035 E.02312
G1 X113.261 Y131.141 E.00402
G1 X124.697 Y131.141 E.35138
G1 X124.075 Y130.764 F30000
G1 F12000
G1 X123.814 Y130.186 E.0195
G1 X123.735 Y129.879 E.00972
G1 X114.266 Y129.879 E.29095
G1 X114.031 Y130.56 E.02211
G1 X113.918 Y130.764 E.00719
G1 X124.015 Y130.764 E.31026
G1 X114.596 Y130.322 F30000
; LINE_WIDTH: 0.55062
G1 F12000
G1 X123.333 Y130.322 E.36145
; WIPE_START
G1 X121.333 Y130.322 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X128.904 Y129.354 Z6 F30000
G1 X143.283 Y127.515 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X142.664 Y128.134 E.02689
G1 X142.131 Y128.134
G1 X143.283 Y126.982 E.05006
G1 X142.807 Y126.924
G1 X141.597 Y128.134 E.05255
G1 X141.064 Y128.134
G1 X142.273 Y126.924 E.05255
G1 X141.74 Y126.924
G1 X140.531 Y128.134 E.05255
G1 X139.998 Y128.134
G1 X141.207 Y126.924 E.05255
G1 X140.674 Y126.924
G1 X139.464 Y128.134 E.05255
G1 X138.931 Y128.134
G1 X140.14 Y126.924 E.05255
G1 X139.607 Y126.924
G1 X138.398 Y128.134 E.05255
G1 X137.865 Y128.134
G1 X139.074 Y126.924 E.05255
G1 X138.541 Y126.924
G1 X137.331 Y128.134 E.05255
G1 X136.798 Y128.134
G1 X138.007 Y126.924 E.05255
G1 X137.474 Y126.924
G1 X136.265 Y128.134 E.05255
G1 X135.732 Y128.134
G1 X136.941 Y126.924 E.05255
G1 X136.408 Y126.924
G1 X135.198 Y128.134 E.05255
G1 X134.665 Y128.134
G1 X135.874 Y126.924 E.05255
G1 X135.341 Y126.924
G1 X134.132 Y128.134 E.05255
G1 X133.599 Y128.134
G1 X134.808 Y126.924 E.05255
G1 X134.275 Y126.924
G1 X133.065 Y128.134 E.05255
G1 X132.532 Y128.134
G1 X133.741 Y126.924 E.05255
G1 X133.208 Y126.924
G1 X131.999 Y128.134 E.05255
G1 X131.465 Y128.134
G1 X132.675 Y126.924 E.05255
G1 X132.142 Y126.924
G1 X130.932 Y128.134 E.05255
G1 X130.717 Y127.815
G1 X131.608 Y126.924 E.03871
G1 X131.075 Y126.924
G1 X130.717 Y127.282 E.01554
; WIPE_START
M204 S10000
G1 X131.075 Y126.924 E-.19218
G1 X131.608 Y126.924 E-.20264
G1 X130.929 Y127.604 E-.36518
; WIPE_END
G1 E-.04 F1800
G1 X138.239 Y129.799 Z6 F30000
G1 X145.36 Y131.938 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X145.461 Y131.945 E.00281
G1 X145.36 Y131.938 F30000
; LINE_WIDTH: 0.418775
G1 F12000
G1 X144.704 Y131.778 E.02069
G1 X144.147 Y131.474 E.01946
G1 X143.655 Y131.064 E.01961
G1 X143.195 Y130.474 E.0229
G1 X142.899 Y129.861 E.02086
G1 X142.743 Y129.242 E.01953
G1 X142.716 Y128.748 E.01516
G1 X131.287 Y128.748 E.35005
G1 X131.278 Y129.077 E.01008
G1 X131.163 Y129.669 E.01846
G1 X130.853 Y130.396 E.02419
G1 X130.48 Y130.919 E.01967
G1 X129.933 Y131.416 E.02265
G1 X129.337 Y131.761 E.02108
G1 X128.724 Y131.929 E.01948
G1 X129.321 Y131.895 E.01833
G1 X144.686 Y131.895 E.47058
G1 X145.301 Y131.933 E.01886
G1 X143.609 Y131.518 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X143.328 Y131.265 E.01161
G1 X142.896 Y130.705 E.02175
G1 X142.559 Y130.022 E.02341
G1 X142.377 Y129.333 E.02191
G1 X142.357 Y129.125 E.0064
G1 X131.65 Y129.125 E.32897
G1 X131.533 Y129.741 E.01925
G1 X131.199 Y130.546 E.02677
G1 X130.786 Y131.14 E.02224
G1 X130.383 Y131.518 E.01698
G1 X143.549 Y131.518 E.40454
G1 X142.757 Y131.141 F30000
G1 F12000
G1 X142.492 Y130.762 E.0142
G1 X142.218 Y130.183 E.01969
G1 X142.031 Y129.502 E.0217
G1 X131.963 Y129.502 E.30933
G1 X131.846 Y130.002 E.01576
G1 X131.545 Y130.695 E.02323
G1 X131.25 Y131.141 E.01643
G1 X142.697 Y131.141 E.35171
G1 X142.075 Y130.764 F30000
G1 F12000
G1 X141.814 Y130.186 E.0195
G1 X141.735 Y129.879 E.00972
G1 X132.274 Y129.879 E.29069
G1 X131.926 Y130.764 E.02921
G1 X142.015 Y130.764 E.31
G1 X132.6 Y130.322 F30000
; LINE_WIDTH: 0.55061
G1 F12000
G1 X141.333 Y130.322 E.36129
G1 X128.418 Y131.95 F30000
; LINE_WIDTH: 0.38292
G1 F12000
G1 X128.642 Y131.936 E.00623
; WIPE_START
G1 X128.418 Y131.95 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X135.985 Y130.958 Z6 F30000
G1 X161.283 Y127.646 Z6
G1 Z5.6
M73 P93 R2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X160.795 Y128.134 E.0212
G1 X160.261 Y128.134
G1 X161.283 Y127.112 E.04438
G1 X160.937 Y126.924
G1 X159.728 Y128.134 E.05255
G1 X159.195 Y128.134
G1 X160.404 Y126.924 E.05255
G1 X159.871 Y126.924
G1 X158.662 Y128.134 E.05255
G1 X158.128 Y128.134
G1 X159.338 Y126.924 E.05255
G1 X158.804 Y126.924
G1 X157.595 Y128.134 E.05255
G1 X157.062 Y128.134
G1 X158.271 Y126.924 E.05255
G1 X157.738 Y126.924
G1 X156.529 Y128.134 E.05255
G1 X155.995 Y128.134
G1 X157.205 Y126.924 E.05255
G1 X156.671 Y126.924
G1 X155.462 Y128.134 E.05255
G1 X154.929 Y128.134
G1 X156.138 Y126.924 E.05255
G1 X155.605 Y126.924
G1 X154.396 Y128.134 E.05255
G1 X153.862 Y128.134
G1 X155.072 Y126.924 E.05255
G1 X154.538 Y126.924
G1 X153.329 Y128.134 E.05255
G1 X152.796 Y128.134
G1 X154.005 Y126.924 E.05255
G1 X153.472 Y126.924
G1 X152.263 Y128.134 E.05255
G1 X151.729 Y128.134
G1 X152.939 Y126.924 E.05255
G1 X152.405 Y126.924
G1 X151.196 Y128.134 E.05255
G1 X150.663 Y128.134
G1 X151.872 Y126.924 E.05255
G1 X151.339 Y126.924
G1 X150.129 Y128.134 E.05255
G1 X149.596 Y128.134
G1 X150.806 Y126.924 E.05255
G1 X150.272 Y126.924
G1 X149.063 Y128.134 E.05255
G1 X148.717 Y127.946
G1 X149.739 Y126.924 E.04439
G1 X149.206 Y126.924
G1 X148.717 Y127.413 E.02122
; WIPE_START
M204 S10000
G1 X149.206 Y126.924 E-.26245
G1 X149.739 Y126.924 E-.20264
G1 X149.19 Y127.473 E-.29491
; WIPE_END
G1 E-.04 F1800
G1 X156.47 Y129.767 Z6 F30000
G1 X163.36 Y131.938 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38292
G1 F12000
G1 X163.461 Y131.945 E.00281
G1 X163.36 Y131.938 F30000
; LINE_WIDTH: 0.418775
G1 F12000
G1 X162.704 Y131.778 E.02069
G1 X162.147 Y131.474 E.01946
G1 X161.655 Y131.064 E.01961
G1 X161.195 Y130.474 E.0229
G1 X160.899 Y129.861 E.02086
G1 X160.743 Y129.242 E.01953
G1 X160.716 Y128.748 E.01516
G1 X149.287 Y128.748 E.35005
G1 X149.278 Y129.077 E.01009
G1 X149.163 Y129.669 E.01846
G1 X148.853 Y130.396 E.02419
G1 X148.48 Y130.919 E.01967
G1 X147.933 Y131.416 E.02265
G1 X147.337 Y131.761 E.02108
G1 X146.724 Y131.929 E.01948
G1 X147.321 Y131.895 E.01833
G1 X162.686 Y131.895 E.47059
G1 X163.301 Y131.933 E.01886
G1 X161.609 Y131.518 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X161.328 Y131.265 E.01161
G1 X160.896 Y130.705 E.02175
G1 X160.559 Y130.022 E.02341
G1 X160.377 Y129.333 E.02191
G1 X160.357 Y129.125 E.0064
G1 X149.65 Y129.125 E.32897
G1 X149.533 Y129.741 E.01925
G1 X149.199 Y130.546 E.02677
G1 X148.786 Y131.14 E.02224
G1 X148.383 Y131.518 E.01698
G1 X161.549 Y131.518 E.40454
G1 X160.757 Y131.141 F30000
G1 F12000
G1 X160.492 Y130.762 E.0142
G1 X160.218 Y130.183 E.01969
G1 X160.031 Y129.502 E.0217
G1 X149.963 Y129.502 E.30933
G1 X149.846 Y130.002 E.01576
G1 X149.545 Y130.695 E.02323
G1 X149.25 Y131.141 E.01643
G1 X160.697 Y131.141 E.35171
G1 X160.075 Y130.764 F30000
G1 F12000
G1 X159.814 Y130.186 E.0195
G1 X159.735 Y129.879 E.00972
G1 X150.274 Y129.879 E.29069
G1 X149.926 Y130.764 E.02921
G1 X160.015 Y130.764 E.31
G1 X150.6 Y130.322 F30000
; LINE_WIDTH: 0.55061
G1 F12000
G1 X159.333 Y130.322 E.36129
G1 X146.418 Y131.95 F30000
; LINE_WIDTH: 0.38292
G1 F12000
G1 X146.642 Y131.936 E.00623
; CHANGE_LAYER
; Z_HEIGHT: 5.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F12000
G1 X146.418 Y131.95 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 29/33
; update layer progress
M73 L29
M991 S0 P28 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6 I.089 J1.214 P1  F30000
G1 X182.398 Y129.314 Z6
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y134.244 E.16355
G1 X73.602 Y134.244 E3.60896
G1 X73.602 Y129.314 E.16355
M73 P93 R1
G1 X89.153 Y129.314 E.51586
G2 X94.847 Y129.314 I2.847 J-.564 E.26476
G1 X107.153 Y129.314 E.40823
G1 X107.182 Y129.444 E.00444
G2 X112.847 Y129.314 I2.818 J-.695 E.26033
G1 X125.153 Y129.314 E.40823
G2 X130.847 Y129.314 I2.847 J-.568 E.26461
G1 X143.153 Y129.314 E.40823
G2 X148.847 Y129.314 I2.847 J-.568 E.26461
G1 X161.153 Y129.314 E.40823
G2 X166.847 Y129.314 I2.847 J-.568 E.26461
G1 X182.338 Y129.314 E.51387
; WIPE_START
G1 X182.362 Y131.313 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y127.488 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y134.636 E.21963
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y134.636 E3.36709
G1 X73.21 Y127.488 E.21963
G1 X89.49 Y127.488 E.50024
G1 X89.49 Y128.752 E.03884
G2 X94.51 Y128.752 I2.51 J-.005 E.24197
G1 X94.51 Y127.488 E.03884
G1 X107.49 Y127.488 E.39884
G2 X107.494 Y128.884 I24.045 J.632 E.04289
G2 X112.51 Y128.752 I2.506 J-.137 E.23792
G1 X112.51 Y127.488 E.03884
G1 X125.49 Y127.488 E.39884
G2 X125.494 Y128.884 I24.049 J.632 E.04289
G2 X130.51 Y128.752 I2.506 J-.137 E.23792
G1 X130.51 Y127.488 E.03884
G1 X143.49 Y127.488 E.39884
G2 X143.494 Y128.884 I24.108 J.632 E.04289
G2 X148.51 Y128.752 I2.506 J-.137 E.23792
G1 X148.51 Y127.488 E.03884
G1 X161.49 Y127.488 E.39884
G2 X161.494 Y128.884 I24.108 J.632 E.04289
G2 X166.51 Y128.752 I2.506 J-.137 E.23792
G1 X166.51 Y127.488 E.03884
G1 X182.73 Y127.488 E.4984
M204 S10000
G1 X182.222 Y127.696 F30000
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.583 Y128.057 E.01569
G1 X182.583 Y128.59
G1 X181.688 Y127.696 E.03886
G1 X181.155 Y127.696
G1 X182.55 Y129.091 E.06063
G1 X182.017 Y129.091
G1 X180.622 Y127.696 E.06063
G1 X180.089 Y127.696
G1 X181.484 Y129.091 E.06063
G1 X180.951 Y129.091
G1 X179.555 Y127.696 E.06063
G1 X179.022 Y127.696
G1 X180.417 Y129.091 E.06063
G1 X179.884 Y129.091
G1 X178.489 Y127.696 E.06063
G1 X177.956 Y127.696
G1 X179.351 Y129.091 E.06063
G1 X178.818 Y129.091
G1 X177.422 Y127.696 E.06063
G1 X176.889 Y127.696
G1 X178.284 Y129.091 E.06063
G1 X177.751 Y129.091
G1 X176.356 Y127.696 E.06063
G1 X175.822 Y127.696
G1 X177.218 Y129.091 E.06063
G1 X176.685 Y129.091
G1 X175.289 Y127.696 E.06063
G1 X174.756 Y127.696
G1 X176.151 Y129.091 E.06063
G1 X175.618 Y129.091
G1 X174.223 Y127.696 E.06063
G1 X173.689 Y127.696
G1 X175.085 Y129.091 E.06063
G1 X174.552 Y129.091
G1 X173.156 Y127.696 E.06063
G1 X172.623 Y127.696
G1 X174.018 Y129.091 E.06063
G1 X173.485 Y129.091
G1 X172.09 Y127.696 E.06063
G1 X171.556 Y127.696
G1 X172.952 Y129.091 E.06063
G1 X172.418 Y129.091
G1 X171.023 Y127.696 E.06063
G1 X170.49 Y127.696
G1 X171.885 Y129.091 E.06063
G1 X171.352 Y129.091
G1 X169.957 Y127.696 E.06063
G1 X169.423 Y127.696
G1 X170.819 Y129.091 E.06063
G1 X170.285 Y129.091
G1 X168.89 Y127.696 E.06063
G1 X168.357 Y127.696
G1 X169.752 Y129.091 E.06063
G1 X169.219 Y129.091
G1 X167.824 Y127.696 E.06063
G1 X167.29 Y127.696
G1 X168.686 Y129.091 E.06063
G1 X168.152 Y129.091
G1 X166.757 Y127.696 E.06063
G1 X166.717 Y128.189
G1 X167.619 Y129.091 E.03919
G1 X167.086 Y129.091
G1 X166.717 Y128.723 E.01601
; WIPE_START
M204 S10000
G1 X167.086 Y129.091 E-.19803
G1 X167.619 Y129.091 E-.20264
G1 X166.951 Y128.422 E-.35933
; WIPE_END
G1 E-.04 F1800
G1 X161.283 Y128.087 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X160.891 Y127.696 E.01701
G1 X160.358 Y127.696
G1 X161.283 Y128.62 E.04018
G1 X161.22 Y129.091
G1 X159.825 Y127.696 E.06063
G1 X159.291 Y127.696
G1 X160.687 Y129.091 E.06063
G1 X160.154 Y129.091
G1 X158.758 Y127.696 E.06063
G1 X158.225 Y127.696
G1 X159.62 Y129.091 E.06063
G1 X159.087 Y129.091
G1 X157.692 Y127.696 E.06063
G1 X157.158 Y127.696
G1 X158.554 Y129.091 E.06063
G1 X158.021 Y129.091
G1 X156.625 Y127.696 E.06063
G1 X156.092 Y127.696
G1 X157.487 Y129.091 E.06063
G1 X156.954 Y129.091
G1 X155.559 Y127.696 E.06063
G1 X155.025 Y127.696
G1 X156.421 Y129.091 E.06063
G1 X155.887 Y129.091
G1 X154.492 Y127.696 E.06063
G1 X153.959 Y127.696
G1 X155.354 Y129.091 E.06063
G1 X154.821 Y129.091
G1 X153.426 Y127.696 E.06063
G1 X152.892 Y127.696
G1 X154.288 Y129.091 E.06063
G1 X153.754 Y129.091
G1 X152.359 Y127.696 E.06063
G1 X151.826 Y127.696
G1 X153.221 Y129.091 E.06063
G1 X152.688 Y129.091
G1 X151.293 Y127.696 E.06063
G1 X150.759 Y127.696
G1 X152.155 Y129.091 E.06063
G1 X151.621 Y129.091
G1 X150.226 Y127.696 E.06063
G1 X149.693 Y127.696
G1 X151.088 Y129.091 E.06063
G1 X150.555 Y129.091
G1 X149.16 Y127.696 E.06063
G1 X148.717 Y127.787
G1 X150.022 Y129.091 E.05668
G1 X149.488 Y129.091
G1 X148.717 Y128.32 E.0335
M204 S10000
G1 X148.921 Y129.11 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.197905
G1 F15000
G1 X148.701 Y128.57 E.00736
G1 X148.914 Y129.11 F30000
; LINE_WIDTH: 0.312538
G1 F15000
G1 X148.713 Y128.582 E.01241
; WIPE_START
G1 X148.914 Y129.11 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X143.283 Y128.218 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X142.761 Y127.696 E.02269
G1 X142.227 Y127.696
G1 X143.283 Y128.751 E.04586
G1 X143.089 Y129.091
G1 X141.694 Y127.696 E.06063
G1 X141.161 Y127.696
G1 X142.556 Y129.091 E.06063
G1 X142.023 Y129.091
G1 X140.627 Y127.696 E.06063
G1 X140.094 Y127.696
G1 X141.49 Y129.091 E.06063
G1 X140.956 Y129.091
G1 X139.561 Y127.696 E.06063
G1 X139.028 Y127.696
G1 X140.423 Y129.091 E.06063
G1 X139.89 Y129.091
G1 X138.494 Y127.696 E.06063
G1 X137.961 Y127.696
G1 X139.357 Y129.091 E.06063
G1 X138.823 Y129.091
G1 X137.428 Y127.696 E.06063
G1 X136.895 Y127.696
G1 X138.29 Y129.091 E.06063
G1 X137.757 Y129.091
G1 X136.361 Y127.696 E.06063
G1 X135.828 Y127.696
G1 X137.223 Y129.091 E.06063
G1 X136.69 Y129.091
G1 X135.295 Y127.696 E.06063
G1 X134.762 Y127.696
G1 X136.157 Y129.091 E.06063
G1 X135.624 Y129.091
G1 X134.228 Y127.696 E.06063
G1 X133.695 Y127.696
G1 X135.09 Y129.091 E.06063
G1 X134.557 Y129.091
G1 X133.162 Y127.696 E.06063
G1 X132.629 Y127.696
G1 X134.024 Y129.091 E.06063
G1 X133.491 Y129.091
G1 X132.095 Y127.696 E.06063
G1 X131.562 Y127.696
G1 X132.957 Y129.091 E.06063
G1 X132.424 Y129.091
G1 X131.029 Y127.696 E.06063
G1 X130.717 Y127.918
G1 X131.891 Y129.091 E.05099
G1 X131.358 Y129.091
G1 X130.717 Y128.451 E.02782
M204 S10000
G1 X130.86 Y129.11 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.201163
G1 F15000
G1 X130.705 Y128.705 E.00559
; WIPE_START
G1 X130.86 Y129.11 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X127.468 Y132.001 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.41999
G1 F12000
G1 X126.853 Y131.838 E.01955
G1 X126.283 Y131.561 E.01947
G1 X125.894 Y131.282 E.01472
G1 X125.465 Y130.852 E.01867
G1 X125.021 Y130.153 E.02544
G1 X124.863 Y129.706 E.01458
G1 X113.154 Y129.71 E.35977
G1 X112.852 Y130.398 E.0231
G1 X112.484 Y130.914 E.01947
G1 X111.888 Y131.448 E.02461
G1 X111.33 Y131.763 E.01969
G1 X110.726 Y131.963 E.01955
G1 X110.096 Y132.043 E.01952
G1 X109.468 Y132.001 E.01933
G1 X108.853 Y131.838 E.01955
G1 X108.283 Y131.561 E.01947
G1 X107.894 Y131.282 E.01471
G1 X107.466 Y130.854 E.01859
G1 X107.022 Y130.156 E.02544
G1 X106.858 Y129.706 E.01471
G1 X95.906 Y129.706 E.33651
G1 X95.154 Y129.709 E.0231
G1 X94.852 Y130.398 E.0231
G1 X94.485 Y130.912 E.01941
G1 X94.225 Y131.179 E.01145
G1 X93.621 Y131.617 E.02294
G1 X93.034 Y131.878 E.01973
G1 X92.423 Y132.017 E.01925
G3 X90.885 Y131.849 I-.385 J-3.601 E.04789
G1 X90.15 Y131.474 E.02538
G1 X89.552 Y130.953 E.02435
G1 X89.167 Y130.431 E.01993
G1 X88.9 Y129.865 E.01925
G1 X88.854 Y129.706 E.00509
G1 X73.994 Y129.706 E.45659
G1 X73.994 Y133.852 E.1274
G1 X182.006 Y133.852 E3.31881
G1 X182.006 Y129.706 E.1274
G1 X167.154 Y129.71 E.45633
G1 X166.852 Y130.398 E.0231
G1 X166.484 Y130.914 E.01947
G1 X165.888 Y131.448 E.0246
G1 X165.33 Y131.763 E.01969
G1 X164.726 Y131.963 E.01955
G1 X164.096 Y132.043 E.01951
G1 X163.468 Y132.001 E.01933
G1 X162.853 Y131.838 E.01955
G1 X162.283 Y131.561 E.01947
G1 X161.894 Y131.282 E.01472
G1 X161.465 Y130.852 E.01867
G1 X161.021 Y130.153 E.02543
G1 X160.863 Y129.706 E.01458
G1 X149.154 Y129.71 E.35977
G1 X148.852 Y130.398 E.0231
G1 X148.484 Y130.914 E.01947
G1 X147.888 Y131.448 E.0246
G1 X147.33 Y131.763 E.01969
G1 X146.726 Y131.963 E.01955
G1 X146.096 Y132.043 E.01952
G1 X145.468 Y132.001 E.01933
G1 X144.853 Y131.838 E.01955
G1 X144.283 Y131.561 E.01947
G1 X143.894 Y131.282 E.01472
G1 X143.465 Y130.852 E.01866
G1 X143.021 Y130.153 E.02544
G1 X142.863 Y129.706 E.01458
G1 X131.154 Y129.71 E.35977
G1 X130.852 Y130.398 E.0231
G1 X130.484 Y130.914 E.01947
G1 X129.888 Y131.448 E.0246
G1 X129.33 Y131.763 E.01969
G1 X128.726 Y131.963 E.01955
G1 X128.096 Y132.043 E.01952
G1 X127.528 Y132.005 E.01749
G1 X126.754 Y132.202 F30000
G1 F12000
G1 X126.116 Y131.9 E.0217
G1 X125.698 Y131.608 E.01567
G1 X125.198 Y131.119 E.0215
G1 X124.701 Y130.354 E.02803
G1 X124.593 Y130.083 E.00896
G1 X113.399 Y130.083 E.34394
G1 X113.198 Y130.548 E.01557
G1 X112.79 Y131.135 E.02197
G1 X112.138 Y131.731 E.02712
G1 X111.513 Y132.093 E.02221
G1 X110.842 Y132.322 E.02178
G1 X110.141 Y132.417 E.02174
G1 X109.441 Y132.377 E.02154
G1 X108.754 Y132.202 E.02178
G1 X108.116 Y131.9 E.0217
G1 X107.698 Y131.609 E.01567
G1 X107.2 Y131.121 E.02142
G1 X106.702 Y130.356 E.02801
G1 X106.591 Y130.083 E.00908
G1 X95.399 Y130.083 E.34388
G1 X95.198 Y130.548 E.01557
G1 X94.791 Y131.133 E.02191
G1 X94.446 Y131.484 E.0151
G1 X93.842 Y131.922 E.02294
G1 X93.184 Y132.223 E.02223
G1 X92.505 Y132.385 E.02146
G3 X90.788 Y132.214 I-.47 J-3.975 E.05342
G1 X89.977 Y131.809 E.02787
G1 X89.302 Y131.236 E.02719
G3 X88.586 Y130.083 I2.937 J-2.625 E.04192
G1 X74.371 Y130.083 E.43676
G1 X74.371 Y133.475 E.10423
G1 X181.629 Y133.475 E3.29564
G1 X181.629 Y130.083 E.10423
G1 X167.399 Y130.083 E.43722
G1 X167.198 Y130.548 E.01557
G1 X166.79 Y131.135 E.02197
G1 X166.138 Y131.731 E.02712
G1 X165.513 Y132.093 E.0222
G1 X164.842 Y132.322 E.02178
G1 X164.141 Y132.417 E.02174
G1 X163.441 Y132.377 E.02154
G1 X162.754 Y132.202 E.02178
G1 X162.116 Y131.9 E.0217
G1 X161.697 Y131.608 E.01567
G1 X161.198 Y131.119 E.0215
G1 X160.701 Y130.354 E.02801
G1 X160.593 Y130.083 E.00897
G1 X149.399 Y130.083 E.34394
G1 X149.198 Y130.548 E.01557
G1 X148.79 Y131.135 E.02197
G1 X148.138 Y131.731 E.02712
G1 X147.513 Y132.093 E.0222
G1 X146.842 Y132.322 E.02178
G1 X146.141 Y132.417 E.02174
G1 X145.441 Y132.377 E.02154
G1 X144.754 Y132.202 E.02178
G1 X144.116 Y131.9 E.0217
G1 X143.697 Y131.608 E.01567
G1 X143.198 Y131.119 E.0215
G1 X142.701 Y130.354 E.02803
G1 X142.593 Y130.083 E.00896
G1 X131.399 Y130.083 E.34394
G1 X131.198 Y130.548 E.01557
G1 X130.79 Y131.135 E.02197
G1 X130.138 Y131.731 E.02712
G1 X129.513 Y132.093 E.0222
G1 X128.842 Y132.322 E.02178
G1 X128.141 Y132.417 E.02174
G1 X127.441 Y132.377 E.02154
G1 X126.812 Y132.217 E.01993
G1 X143.478 Y131.915 F30000
; LINE_WIDTH: 0.418464
G1 F12000
G1 X142.931 Y131.385 E.02329
G1 X142.382 Y130.554 E.03048
G1 X142.337 Y130.46 E.00319
G1 X131.647 Y130.46 E.32714
G1 X131.443 Y130.875 E.01417
G1 X131.095 Y131.356 E.01815
G1 X130.389 Y132.013 E.02952
G1 X129.696 Y132.423 E.02463
G1 X128.959 Y132.682 E.02392
G1 X128.184 Y132.774 E.02387
G1 X127.415 Y132.745 E.02356
G1 X126.656 Y132.566 E.02387
G1 X125.95 Y132.238 E.02383
G1 X125.478 Y131.915 E.0175
G1 X124.931 Y131.385 E.0233
G1 X124.382 Y130.554 E.03049
G1 X124.337 Y130.46 E.00319
G1 X113.647 Y130.46 E.32714
G1 X113.443 Y130.875 E.01418
G1 X113.095 Y131.356 E.01814
G1 X112.389 Y132.013 E.02952
G1 X111.696 Y132.423 E.02463
G1 X110.959 Y132.682 E.02392
G1 X110.184 Y132.774 E.02387
G1 X109.415 Y132.745 E.02356
G1 X108.656 Y132.566 E.02387
G1 X107.949 Y132.238 E.02384
G1 X107.478 Y131.915 E.01749
G1 X106.933 Y131.387 E.02322
G1 X106.383 Y130.557 E.03046
M73 P94 R1
G1 X106.336 Y130.46 E.00331
G1 X95.647 Y130.46 E.32711
G1 X95.443 Y130.875 E.01418
G3 X94.064 Y132.227 I-3.757 J-2.453 E.05956
G1 X93.335 Y132.569 E.02464
G1 X92.585 Y132.745 E.02357
G3 X90.692 Y132.578 I-.552 J-4.556 E.05859
G1 X89.803 Y132.144 E.03025
G1 X89.053 Y131.518 E.02992
G3 X88.465 Y130.718 I4.37 J-3.823 E.03041
G1 X88.345 Y130.46 E.00872
G1 X74.748 Y130.46 E.41609
G1 X74.748 Y133.098 E.08073
G1 X90.624 Y133.098 E.48582
G2 X93.215 Y133.098 I1.296 J-96.27 E.0793
G1 X108.585 Y133.098 E.47035
G2 X110.804 Y133.097 I1.089 J-66.989 E.0679
G1 X126.585 Y133.098 E.48294
G2 X128.804 Y133.097 I1.089 J-67.059 E.0679
G1 X144.585 Y133.098 E.48294
G2 X146.804 Y133.097 I1.089 J-66.987 E.0679
G1 X162.585 Y133.098 E.48294
G2 X164.804 Y133.097 I1.089 J-66.942 E.06789
G1 X181.252 Y133.098 E.50335
G1 X181.252 Y130.46 E.08073
G1 X167.647 Y130.46 E.41633
G1 X167.443 Y130.875 E.01417
G1 X167.095 Y131.356 E.01815
G1 X166.389 Y132.013 E.02952
G1 X165.696 Y132.423 E.02463
G1 X164.959 Y132.682 E.02392
G1 X164.184 Y132.774 E.02387
G1 X163.415 Y132.745 E.02356
G1 X162.656 Y132.566 E.02387
G1 X161.95 Y132.238 E.02383
G1 X161.478 Y131.915 E.0175
G1 X160.931 Y131.385 E.0233
G1 X160.382 Y130.554 E.03047
G1 X160.337 Y130.46 E.0032
G1 X149.647 Y130.46 E.32714
G1 X149.443 Y130.875 E.01417
G1 X149.095 Y131.356 E.01815
G1 X148.389 Y132.013 E.02952
G1 X147.696 Y132.423 E.02463
G1 X146.959 Y132.682 E.02392
G1 X146.184 Y132.774 E.02387
G1 X145.415 Y132.745 E.02356
G1 X144.656 Y132.566 E.02387
G1 X143.95 Y132.238 E.02383
G1 X143.527 Y131.949 E.01567
G1 X165.936 Y132.721 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X180.875 Y132.721 E.45901
G1 X180.875 Y130.837 E.05789
G1 X167.895 Y130.837 E.39883
G1 X167.4 Y131.577 E.02734
G1 X166.639 Y132.295 E.03216
G1 X165.987 Y132.69 E.0234
G1 X180.498 Y132.344 F30000
G1 F12000
G1 X180.498 Y131.214 E.03471
G1 X168.113 Y131.214 E.38055
G1 X167.706 Y131.798 E.02186
G1 X167.152 Y132.344 E.0239
G1 X180.438 Y132.344 E.40823
G1 X180.121 Y131.779 F30000
; LINE_WIDTH: 0.419265
G1 F12000
G1 X180.121 Y131.591 E.00577
G1 X168.321 Y131.591 E.36187
G1 X168.049 Y131.967 E.01425
G1 X180.121 Y131.967 E.37023
G1 X180.121 Y131.839 E.00393
G1 X148.639 Y132.295 F30000
; Slow Down Start
; LINE_WIDTH: 0.41999
G1 F3000;_EXTRUDE_SET_SPEED
G1 X148.862 Y132.084 E.00945
; Slow Down End
G1 F12000
G1 X149.4 Y131.577 E.02272
G1 X149.895 Y130.837 E.02734
G1 X160.114 Y130.837 E.31401
G1 X160.664 Y131.651 E.0302
G1 X161.093 Y132.081 E.01867
G1 X161.597 Y132.465 E.01945
G1 X162.076 Y132.721 E.01671
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X147.936 Y132.721 E.43448
; Slow Down End
G1 F12000
G1 X148.587 Y132.326 E.0234
G1 X160.822 Y132.344 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X149.152 Y132.344 E.3586
G1 X149.416 Y132.084 E.01138
; Slow Down End
G1 F12000
G1 X149.706 Y131.798 E.01252
G1 X150.113 Y131.214 E.02186
G1 X159.905 Y131.214 E.3009
G2 X160.78 Y132.301 I4.016 J-2.335 E.04304
G1 X159.958 Y131.967 F30000
; LINE_WIDTH: 0.419265
G1 F12000
G1 X159.697 Y131.591 E.01404
G1 X150.321 Y131.591 E.28754
G1 X150.049 Y131.967 E.01425
G1 X159.898 Y131.967 E.30205
G1 X143.597 Y132.464 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X144.077 Y132.721 E.01671
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X129.936 Y132.721 E.43448
G1 X130.639 Y132.295 E.02525
G1 X130.862 Y132.084 E.00945
; Slow Down End
G1 F12000
G1 X131.4 Y131.577 E.02272
G1 X131.895 Y130.837 E.02734
G1 X142.114 Y130.837 E.31401
G1 X142.664 Y131.651 E.0302
G1 X143.093 Y132.081 E.01866
G1 X143.549 Y132.428 E.0176
G1 X131.152 Y132.344 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X131.416 Y132.084 E.01138
; Slow Down End
G1 F12000
G1 X131.706 Y131.798 E.01252
G1 X132.113 Y131.214 E.02186
G1 X141.906 Y131.214 E.3009
G2 X142.822 Y132.344 I4.083 J-2.376 E.04488
G1 X131.212 Y132.344 E.35675
G1 X141.958 Y131.967 F30000
; LINE_WIDTH: 0.419265
G1 F12000
G1 X141.697 Y131.591 E.01404
G1 X132.321 Y131.591 E.28754
G1 X132.049 Y131.967 E.01425
G1 X141.898 Y131.967 E.30205
G1 X113.401 Y131.577 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X113.895 Y130.837 E.02734
G1 X124.114 Y130.837 E.31401
G1 X124.664 Y131.651 E.0302
G1 X125.093 Y132.081 E.01867
G1 X125.597 Y132.465 E.01944
G1 X126.076 Y132.721 E.01671
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X111.936 Y132.721 E.43448
G1 X112.639 Y132.295 E.02525
G1 X112.862 Y132.084 E.00945
; Slow Down End
G1 F12000
G1 X113.357 Y131.618 E.02087
G1 X124.822 Y132.344 F30000
G1 F12000
G1 X124.397 Y131.918 E.01849
G3 X123.906 Y131.214 I4.265 J-3.503 E.02641
G1 X114.113 Y131.214 E.3009
G1 X113.706 Y131.798 E.02186
G1 X113.416 Y132.084 E.01253
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X113.152 Y132.344 E.01138
G1 X124.762 Y132.344 E.35676
; Slow Down End
G1 X123.958 Y131.967 F30000
; LINE_WIDTH: 0.41927
G1 F12000
G1 X123.697 Y131.591 E.01404
G1 X114.321 Y131.591 E.28755
G1 X114.049 Y131.967 E.01425
G1 X123.898 Y131.967 E.30205
G1 X94.878 Y132.084 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X95.059 Y131.947 E.00697
G1 X95.402 Y131.575 E.01553
G1 X95.894 Y130.837 E.02728
G1 X106.114 Y130.837 E.314
G1 X106.666 Y131.654 E.03029
G1 X107.094 Y132.082 E.01859
G1 X107.597 Y132.464 E.01943
G1 X108.076 Y132.721 E.01671
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X93.931 Y132.721 E.43464
G1 X94.285 Y132.533 E.01233
; Slow Down End
G1 F12000
G1 X94.83 Y132.12 E.021
G1 X106.822 Y132.344 F30000
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X95.175 Y132.344 E.35789
G2 X95.444 Y132.084 I-.967 J-1.274 E.01153
; Slow Down End
G1 F12000
G1 X95.707 Y131.796 E.01196
G1 X96.113 Y131.214 E.02181
G1 X105.905 Y131.214 E.3009
G2 X106.78 Y132.301 I4.048 J-2.36 E.04303
G1 X105.958 Y131.967 F30000
; LINE_WIDTH: 0.41927
G1 F12000
G1 X105.697 Y131.591 E.01404
G1 X96.321 Y131.591 E.28755
G1 X96.049 Y131.967 E.01425
G1 X105.898 Y131.967 E.30206
G1 X89.63 Y132.479 F30000
; LINE_WIDTH: 0.41999
G1 F12000
G1 X90.098 Y132.721 E.01618
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X75.125 Y132.721 E.46006
G1 X75.125 Y132.084 E.01957
; Slow Down End
G1 F12000
G1 X75.125 Y130.837 E.03832
G1 X88.06 Y130.837 E.39745
G2 X88.803 Y131.801 I13.519 J-9.645 E.03739
G1 X89.123 Y132.084 E.01314
G2 X89.581 Y132.445 I1.682 J-1.661 E.01797
G1 X75.502 Y131.214 F30000
G1 F12000
G1 X87.886 Y131.214 E.38051
G1 X88.304 Y131.809 E.02235
G1 X88.848 Y132.344 E.02342
; Slow Down Start
G1 F3000;_EXTRUDE_SET_SPEED
G1 X75.502 Y132.344 E.41005
G1 X75.502 Y132.084 E.00798
; Slow Down End
G1 F12000
G1 X75.502 Y131.274 E.02489
G1 X87.953 Y131.967 F30000
; LINE_WIDTH: 0.41927
G1 F12000
G1 X87.68 Y131.591 E.01426
G1 X75.879 Y131.591 E.3619
G1 X75.879 Y131.967 E.01154
G1 X87.893 Y131.967 E.36844
; WIPE_START
G1 X85.893 Y131.967 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.283 Y128.077 Z6.2 F30000
G1 Z5.8
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X88.902 Y127.696 E.01656
G1 X88.368 Y127.696
G1 X89.283 Y128.61 E.03973
G1 X89.23 Y129.091
G1 X87.835 Y127.696 E.06063
G1 X87.302 Y127.696
G1 X88.697 Y129.091 E.06063
G1 X88.164 Y129.091
G1 X86.768 Y127.696 E.06063
G1 X86.235 Y127.696
G1 X87.631 Y129.091 E.06063
G1 X87.097 Y129.091
G1 X85.702 Y127.696 E.06063
G1 X85.169 Y127.696
G1 X86.564 Y129.091 E.06063
G1 X86.031 Y129.091
G1 X84.635 Y127.696 E.06063
G1 X84.102 Y127.696
G1 X85.497 Y129.091 E.06063
G1 X84.964 Y129.091
G1 X83.569 Y127.696 E.06063
G1 X83.036 Y127.696
G1 X84.431 Y129.091 E.06063
G1 X83.898 Y129.091
G1 X82.502 Y127.696 E.06063
G1 X81.969 Y127.696
G1 X83.364 Y129.091 E.06063
G1 X82.831 Y129.091
G1 X81.436 Y127.696 E.06063
G1 X80.903 Y127.696
G1 X82.298 Y129.091 E.06063
G1 X81.765 Y129.091
G1 X80.369 Y127.696 E.06063
G1 X79.836 Y127.696
G1 X81.231 Y129.091 E.06063
G1 X80.698 Y129.091
G1 X79.303 Y127.696 E.06063
G1 X78.77 Y127.696
G1 X80.165 Y129.091 E.06063
G1 X79.632 Y129.091
G1 X78.236 Y127.696 E.06063
G1 X77.703 Y127.696
G1 X79.098 Y129.091 E.06063
G1 X78.565 Y129.091
G1 X77.17 Y127.696 E.06063
G1 X76.637 Y127.696
G1 X78.032 Y129.091 E.06063
G1 X77.499 Y129.091
G1 X76.103 Y127.696 E.06063
G1 X75.57 Y127.696
G1 X76.965 Y129.091 E.06063
G1 X76.432 Y129.091
G1 X75.037 Y127.696 E.06063
G1 X74.504 Y127.696
G1 X75.899 Y129.091 E.06063
G1 X75.366 Y129.091
G1 X73.97 Y127.696 E.06063
G1 X73.437 Y127.696
G1 X74.832 Y129.091 E.06063
G1 X74.299 Y129.091
G1 X73.417 Y128.209 E.03831
G1 X73.417 Y128.743
G1 X73.766 Y129.091 E.01514
; WIPE_START
M204 S10000
G1 X73.417 Y128.743 E-.18726
G1 X73.417 Y128.209 E-.20264
G1 X74.106 Y128.898 E-.37011
; WIPE_END
G1 E-.04 F1800
G1 X81.738 Y128.802 Z6.2 F30000
G1 X107.283 Y128.479 Z6.2
G1 Z5.8
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X106.499 Y127.696 E.03405
G1 X105.966 Y127.696
G1 X107.296 Y129.026 E.05781
G1 X106.828 Y129.091
G1 X105.432 Y127.696 E.06063
G1 X104.899 Y127.696
G1 X106.295 Y129.091 E.06063
G1 X105.761 Y129.091
G1 X104.366 Y127.696 E.06063
G1 X103.833 Y127.696
G1 X105.228 Y129.091 E.06063
G1 X104.695 Y129.091
G1 X103.299 Y127.696 E.06063
G1 X102.766 Y127.696
G1 X104.162 Y129.091 E.06063
G1 X103.628 Y129.091
G1 X102.233 Y127.696 E.06063
G1 X101.7 Y127.696
G1 X103.095 Y129.091 E.06063
G1 X102.562 Y129.091
G1 X101.166 Y127.696 E.06063
G1 X100.633 Y127.696
G1 X102.028 Y129.091 E.06063
G1 X101.495 Y129.091
G1 X100.1 Y127.696 E.06063
G1 X99.567 Y127.696
G1 X100.962 Y129.091 E.06063
G1 X100.429 Y129.091
G1 X99.033 Y127.696 E.06063
G1 X98.5 Y127.696
G1 X99.895 Y129.091 E.06063
G1 X99.362 Y129.091
G1 X97.967 Y127.696 E.06063
G1 X97.434 Y127.696
G1 X98.829 Y129.091 E.06063
G1 X98.296 Y129.091
G1 X96.9 Y127.696 E.06063
G1 X96.367 Y127.696
G1 X97.762 Y129.091 E.06063
G1 X97.229 Y129.091
G1 X95.834 Y127.696 E.06063
G1 X95.301 Y127.696
G1 X96.696 Y129.091 E.06063
G1 X96.163 Y129.091
G1 X94.767 Y127.696 E.06063
G1 X94.717 Y128.179
G1 X95.629 Y129.091 E.03963
G1 X95.096 Y129.091
G1 X94.717 Y128.712 E.01646
; WIPE_START
M204 S10000
G1 X95.096 Y129.091 E-.20354
G1 X95.629 Y129.091 E-.20264
G1 X94.971 Y128.433 E-.35383
; WIPE_END
G1 E-.04 F1800
G1 X102.603 Y128.412 Z6.2 F30000
G1 X125.283 Y128.349 Z6.2
G1 Z5.8
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X124.63 Y127.696 E.02837
G1 X124.096 Y127.696
G1 X125.286 Y128.886 E.05171
G1 X124.959 Y129.091
G1 X123.563 Y127.696 E.06063
G1 X123.03 Y127.696
G1 X124.425 Y129.091 E.06063
G1 X123.892 Y129.091
G1 X122.497 Y127.696 E.06063
G1 X121.963 Y127.696
G1 X123.359 Y129.091 E.06063
G1 X122.826 Y129.091
G1 X121.43 Y127.696 E.06063
G1 X120.897 Y127.696
G1 X122.292 Y129.091 E.06063
G1 X121.759 Y129.091
G1 X120.364 Y127.696 E.06063
G1 X119.83 Y127.696
G1 X121.226 Y129.091 E.06063
G1 X120.692 Y129.091
G1 X119.297 Y127.696 E.06063
G1 X118.764 Y127.696
G1 X120.159 Y129.091 E.06063
G1 X119.626 Y129.091
G1 X118.231 Y127.696 E.06063
G1 X117.697 Y127.696
G1 X119.093 Y129.091 E.06063
G1 X118.559 Y129.091
G1 X117.164 Y127.696 E.06063
G1 X116.631 Y127.696
G1 X118.026 Y129.091 E.06063
G1 X117.493 Y129.091
G1 X116.098 Y127.696 E.06063
G1 X115.564 Y127.696
G1 X116.96 Y129.091 E.06063
G1 X116.426 Y129.091
G1 X115.031 Y127.696 E.06063
G1 X114.498 Y127.696
G1 X115.893 Y129.091 E.06063
G1 X115.36 Y129.091
G1 X113.965 Y127.696 E.06063
G1 X113.431 Y127.696
G1 X114.827 Y129.091 E.06063
G1 X114.293 Y129.091
G1 X112.898 Y127.696 E.06063
G1 X112.717 Y128.048
G1 X113.76 Y129.091 E.04531
G1 X113.227 Y129.091
G1 X112.717 Y128.582 E.02214
M204 S10000
G1 X112.804 Y129.11 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.0902513
G1 F15000
G1 X112.699 Y128.83 E.00115
; CHANGE_LAYER
; Z_HEIGHT: 6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X112.804 Y129.11 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 30/33
; update layer progress
M73 L30
M991 S0 P29 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6.2 I-.025 J1.217 P1  F30000
G1 X182.398 Y130.564 Z6.2
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y133.789 E.10701
G1 X73.602 Y133.789 E3.60896
G1 X73.602 Y130.564 E.10701
G1 X89.734 Y130.564 E.53513
G1 X89.828 Y130.675 E.00485
G2 X94.266 Y130.564 I2.171 J-1.933 E.16754
G1 X107.734 Y130.564 E.44676
G2 X112.266 Y130.564 I2.266 J-1.833 E.17221
G1 X125.734 Y130.564 E.44676
G2 X130.266 Y130.564 I2.266 J-1.833 E.17221
G1 X143.734 Y130.564 E.44676
G2 X148.266 Y130.564 I2.266 J-1.833 E.17221
G1 X161.734 Y130.564 E.44676
G2 X166.266 Y130.564 I2.266 J-1.833 E.17221
G1 X182.338 Y130.564 E.53314
; WIPE_START
G1 X182.375 Y132.563 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y128.446 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y134.182 E.17624
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y134.182 E3.36709
G1 X73.21 Y128.446 E.17624
G1 X89.491 Y128.446 E.50027
G1 X89.493 Y128.869 E.01301
G2 X94.507 Y128.867 I2.507 J-.126 E.23467
G1 X94.509 Y128.446 E.01293
G1 X107.491 Y128.446 E.39889
G2 X108.677 Y130.883 I2.616 J.234 E.0875
G2 X112.507 Y128.867 I1.323 J-2.134 E.16037
G1 X112.509 Y128.446 E.01293
G1 X125.491 Y128.446 E.39889
G2 X126.677 Y130.883 I2.616 J.234 E.0875
G2 X130.507 Y128.867 I1.323 J-2.134 E.16037
G1 X130.509 Y128.446 E.01293
G1 X143.491 Y128.446 E.39889
G2 X144.677 Y130.883 I2.616 J.234 E.0875
G2 X148.507 Y128.867 I1.323 J-2.134 E.16037
G1 X148.509 Y128.446 E.01293
G1 X161.491 Y128.446 E.39889
G2 X162.677 Y130.883 I2.616 J.234 E.0875
G2 X166.507 Y128.867 I1.323 J-2.134 E.16037
G1 X166.509 Y128.446 E.01293
G1 X182.73 Y128.446 E.49842
; WIPE_START
M204 S10000
G1 X182.751 Y130.446 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.051 Y130.341 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.583 Y129.809 E.02312
G1 X182.583 Y129.276
G1 X181.517 Y130.341 E.04629
G1 X180.984 Y130.341
G1 X182.583 Y128.743 E.06947
G1 X182.139 Y128.653
G1 X180.451 Y130.341 E.07335
G1 X179.918 Y130.341
G1 X181.605 Y128.653 E.07335
G1 X181.072 Y128.653
G1 X179.384 Y130.341 E.07335
G1 X178.851 Y130.341
G1 X180.539 Y128.653 E.07335
G1 X180.006 Y128.653
G1 X178.318 Y130.341 E.07335
G1 X177.784 Y130.341
G1 X179.472 Y128.653 E.07335
G1 X178.939 Y128.653
G1 X177.251 Y130.341 E.07335
G1 X176.718 Y130.341
G1 X178.406 Y128.653 E.07335
G1 X177.873 Y128.653
G1 X176.185 Y130.341 E.07335
G1 X175.651 Y130.341
G1 X177.339 Y128.653 E.07335
G1 X176.806 Y128.653
G1 X175.118 Y130.341 E.07335
G1 X174.585 Y130.341
G1 X176.273 Y128.653 E.07335
G1 X175.74 Y128.653
G1 X174.052 Y130.341 E.07335
G1 X173.518 Y130.341
G1 X175.206 Y128.653 E.07335
G1 X174.673 Y128.653
G1 X172.985 Y130.341 E.07335
G1 X172.452 Y130.341
G1 X174.14 Y128.653 E.07335
G1 X173.607 Y128.653
G1 X171.919 Y130.341 E.07335
G1 X171.385 Y130.341
G1 X173.073 Y128.653 E.07335
G1 X172.54 Y128.653
G1 X170.852 Y130.341 E.07335
G1 X170.319 Y130.341
G1 X172.007 Y128.653 E.07335
G1 X171.474 Y128.653
G1 X169.786 Y130.341 E.07335
G1 X169.252 Y130.341
G1 X170.94 Y128.653 E.07335
G1 X170.407 Y128.653
G1 X168.719 Y130.341 E.07335
G1 X168.186 Y130.341
G1 X169.874 Y128.653 E.07335
G1 X169.34 Y128.653
G1 X167.653 Y130.341 E.07335
M73 P95 R1
G1 X167.119 Y130.341
G1 X168.807 Y128.653 E.07335
G1 X168.274 Y128.653
G1 X166.586 Y130.341 E.07335
G1 X166.431 Y129.963
G1 X167.741 Y128.653 E.05691
G1 X167.207 Y128.653
G1 X166.683 Y129.178 E.02279
; WIPE_START
M204 S10000
G1 X167.207 Y128.653 E-.28187
G1 X167.741 Y128.653 E-.20264
G1 X167.228 Y129.166 E-.27549
; WIPE_END
G1 E-.04 F1800
G1 X166.927 Y132.177 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.59935
G1 F11322.18
G1 X180.725 Y132.177 E.62561
G1 X165.066 Y132.643 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X181.252 Y132.643 E.49733
G1 X181.252 Y131.71 E.02868
G1 X166.739 Y131.71 E.44593
G1 X166.414 Y131.996 E.01329
G1 X165.88 Y132.332 E.01939
G1 X165.122 Y132.622 E.02493
G1 X148.927 Y132.177 F30000
; LINE_WIDTH: 0.59936
G1 F11321.976
G1 X161.002 Y132.177 E.54748
G1 X147.066 Y132.643 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X162.935 Y132.643 E.48758
G1 X162.313 Y132.425 E.02026
G1 X161.507 Y131.934 E.02897
G1 X161.253 Y131.71 E.01041
G1 X148.739 Y131.71 E.38452
G1 X148.414 Y131.996 E.01329
G1 X147.88 Y132.332 E.01939
G1 X147.122 Y132.622 E.02494
G1 X130.927 Y132.177 F30000
; LINE_WIDTH: 0.59935
G1 F11322.18
G1 X143.002 Y132.177 E.54747
G1 X130.739 Y131.71 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X130.414 Y131.996 E.01329
G1 X129.88 Y132.332 E.01939
G1 X129.066 Y132.643 E.02678
G1 X144.935 Y132.643 E.48758
G1 X144.313 Y132.425 E.02026
G1 X143.507 Y131.934 E.02897
G1 X143.253 Y131.71 E.01042
G1 X130.799 Y131.71 E.38268
G1 X130.586 Y131.333 F30000
G1 F15000
G1 X130.213 Y131.676 E.01559
G1 X129.679 Y132.012 E.01939
; LINE_WIDTH: 0.443858
G1 X129.278 Y132.186 E.01427
; LINE_WIDTH: 0.491593
G1 F14041.422
G1 X128.878 Y132.361 E.01597
; LINE_WIDTH: 0.529135
G1 F12957.231
G1 X128.809 Y132.39 E.00298
; LINE_WIDTH: 0.551984
G1 F12375.659
G1 X128.74 Y132.419 E.00312
G1 X128.024 Y132.475 E.02976
G1 X127.256 Y132.42 E.03193
; LINE_WIDTH: 0.551529
G1 F12386.732
G1 X127.052 Y132.332 E.00923
; LINE_WIDTH: 0.513947
G1 F13375.051
G1 X126.847 Y132.244 E.00854
; LINE_WIDTH: 0.476364
G1 F14534.759
G1 X126.643 Y132.157 E.00786
; LINE_WIDTH: 0.420261
G1 F15000
G1 X126.438 Y132.069 E.00684
G1 X125.712 Y131.618 E.02628
G1 X125.409 Y131.333 E.01279
G1 X112.586 Y131.333 E.39427
G1 X112.213 Y131.676 E.0156
G1 X111.679 Y132.012 E.0194
; LINE_WIDTH: 0.44386
G1 X111.278 Y132.187 E.01428
; LINE_WIDTH: 0.4916
G1 F14041.189
G1 X110.878 Y132.361 E.01598
; LINE_WIDTH: 0.529138
G1 F12957.165
G1 X110.808 Y132.39 E.00298
; LINE_WIDTH: 0.551991
G1 F12375.483
G1 X110.739 Y132.419 E.00312
G1 X110.024 Y132.475 E.02976
G1 X109.256 Y132.419 E.03195
; LINE_WIDTH: 0.55159
G1 F12385.241
G1 X109.051 Y132.332 E.00922
; LINE_WIDTH: 0.51399
G1 F13373.809
G1 X108.847 Y132.244 E.00854
; LINE_WIDTH: 0.47639
G1 F14533.877
G1 X108.643 Y132.157 E.00786
; LINE_WIDTH: 0.420261
G1 F15000
G1 X108.438 Y132.069 E.00684
G1 X107.712 Y131.618 E.02629
G1 X107.409 Y131.333 E.01279
G1 X94.586 Y131.333 E.39427
G1 X94.213 Y131.676 E.01559
G1 X93.679 Y132.012 E.01941
; LINE_WIDTH: 0.44386
G1 X93.278 Y132.187 E.01428
; LINE_WIDTH: 0.4916
G1 F14041.189
G1 X92.878 Y132.361 E.01598
; LINE_WIDTH: 0.529138
G1 F12957.165
G1 X92.808 Y132.39 E.00298
; LINE_WIDTH: 0.55205
G1 F12374.05
G1 X92.739 Y132.419 E.00312
G1 X92.024 Y132.475 E.02976
G1 X91.253 Y132.419 E.03208
; LINE_WIDTH: 0.5518
G1 F12380.13
G1 X91.088 Y132.349 E.00743
; LINE_WIDTH: 0.51414
G1 F13369.551
G1 X90.923 Y132.279 E.00688
; LINE_WIDTH: 0.47648
G1 F14530.86
G1 X90.758 Y132.209 E.00633
; LINE_WIDTH: 0.420088
G1 F15000
G3 X89.397 Y131.333 I1.567 J-3.927 E.05005
G1 X74.371 Y131.333 E.46182
G1 X74.371 Y133.02 E.05187
G1 X90.454 Y133.02 E.49429
; LINE_WIDTH: 0.440528
G1 X90.748 Y133 E.00955
; LINE_WIDTH: 0.481603
G1 F14361.185
G1 X91.042 Y132.979 E.01054
; LINE_WIDTH: 0.519263
G1 F13225.778
G1 X91.132 Y132.962 E.00357
; LINE_WIDTH: 0.552176
G1 F12370.999
G1 X91.223 Y132.945 E.00382
G2 X92.766 Y132.945 I.774 J-15.787 E.06409
; LINE_WIDTH: 0.551372
G1 F12390.57
G1 X93.007 Y132.964 E.01
; LINE_WIDTH: 0.513834
G1 F13378.246
G1 X93.248 Y132.983 E.00926
; LINE_WIDTH: 0.476297
G1 F14537.022
G1 X93.488 Y133.002 E.00853
; LINE_WIDTH: 0.420297
G1 F15000
G1 X93.729 Y133.02 E.00742
G1 X108.276 Y133.02 E.44732
; LINE_WIDTH: 0.438295
G1 X108.649 Y133.002 E.01203
; LINE_WIDTH: 0.474905
G1 F14583.84
G1 X109.022 Y132.984 E.01315
; LINE_WIDTH: 0.512505
G1 F13416.102
G1 X109.124 Y132.964 E.00397
; LINE_WIDTH: 0.551982
G1 F12375.707
G1 X109.226 Y132.945 E.0043
G2 X110.766 Y132.945 I.771 J-15.77 E.06394
; LINE_WIDTH: 0.551372
G1 F12390.57
G1 X111.007 Y132.964 E.01
; LINE_WIDTH: 0.513834
G1 F13378.246
G1 X111.248 Y132.983 E.00926
; LINE_WIDTH: 0.476297
G1 F14537.022
G1 X111.488 Y133.002 E.00853
; LINE_WIDTH: 0.420297
G1 F15000
G1 X111.729 Y133.02 E.00742
G1 X126.276 Y133.02 E.44732
; LINE_WIDTH: 0.438275
G1 X126.649 Y133.002 E.01204
; LINE_WIDTH: 0.474845
G1 F14585.866
G1 X127.022 Y132.984 E.01315
; LINE_WIDTH: 0.512428
G1 F13418.316
G1 X127.124 Y132.964 E.00397
; LINE_WIDTH: 0.551965
G1 F12376.129
G1 X127.226 Y132.945 E.00431
G2 X128.767 Y132.945 I.771 J-15.774 E.06392
; LINE_WIDTH: 0.551389
G1 F12390.142
G1 X129.007 Y132.964 E.01
; LINE_WIDTH: 0.513847
G1 F13377.892
G1 X129.248 Y132.983 E.00926
; LINE_WIDTH: 0.476304
G1 F14536.77
G1 X129.489 Y133.002 E.00853
; LINE_WIDTH: 0.420297
G1 F15000
G1 X129.729 Y133.02 E.00742
G1 X144.275 Y133.02 E.44731
; LINE_WIDTH: 0.438268
G1 X144.649 Y133.002 E.01204
; LINE_WIDTH: 0.474823
G1 F14586.625
G1 X145.022 Y132.984 E.01316
; LINE_WIDTH: 0.512405
G1 F13418.96
G1 X145.124 Y132.964 E.00397
; LINE_WIDTH: 0.551964
G1 F12376.141
G1 X145.226 Y132.945 E.00431
G2 X146.767 Y132.945 I.771 J-15.773 E.06392
; LINE_WIDTH: 0.551389
G1 F12390.142
G1 X147.007 Y132.964 E.01
; LINE_WIDTH: 0.513847
G1 F13377.892
G1 X147.248 Y132.983 E.00926
; LINE_WIDTH: 0.476304
G1 F14536.77
G1 X147.489 Y133.002 E.00853
; LINE_WIDTH: 0.420297
G1 F15000
G1 X147.729 Y133.02 E.00742
G1 X162.275 Y133.02 E.44731
; LINE_WIDTH: 0.438268
G1 X162.649 Y133.002 E.01205
; LINE_WIDTH: 0.474823
G1 F14586.625
G1 X163.022 Y132.984 E.01316
; LINE_WIDTH: 0.512403
G1 F13419.031
G1 X163.124 Y132.964 E.00397
; LINE_WIDTH: 0.551962
G1 F12376.2
G1 X163.226 Y132.945 E.00431
G2 X164.767 Y132.945 I.771 J-15.777 E.06392
; LINE_WIDTH: 0.551389
G1 F12390.142
G1 X165.007 Y132.964 E.01
; LINE_WIDTH: 0.513847
G1 F13377.892
G1 X165.248 Y132.983 E.00926
; LINE_WIDTH: 0.476304
G1 F14536.77
G1 X165.489 Y133.002 E.00853
; LINE_WIDTH: 0.420124
G1 F15000
G1 X165.729 Y133.02 E.00742
G1 X181.629 Y133.02 E.48871
G1 X181.629 Y131.333 E.05187
G1 X166.586 Y131.333 E.46237
G1 X166.213 Y131.676 E.01559
G1 X165.679 Y132.012 E.01939
; LINE_WIDTH: 0.443858
G1 X165.278 Y132.186 E.01427
; LINE_WIDTH: 0.491593
G1 F14041.422
G1 X164.878 Y132.361 E.01597
; LINE_WIDTH: 0.529135
G1 F12957.231
G1 X164.809 Y132.39 E.00298
; LINE_WIDTH: 0.551982
G1 F12375.719
G1 X164.74 Y132.419 E.00312
G1 X164.024 Y132.475 E.02976
G1 X163.256 Y132.42 E.03193
; LINE_WIDTH: 0.55152
G1 F12386.945
G1 X163.052 Y132.332 E.00923
; LINE_WIDTH: 0.51394
G1 F13375.229
G1 X162.847 Y132.244 E.00855
; LINE_WIDTH: 0.47636
G1 F14534.883
G1 X162.642 Y132.156 E.00787
; LINE_WIDTH: 0.420261
G1 F15000
G1 X162.438 Y132.069 E.00685
G1 X161.712 Y131.618 E.02627
G1 X161.409 Y131.333 E.0128
G1 X148.586 Y131.333 E.39427
G1 X148.213 Y131.676 E.01559
G1 X147.679 Y132.012 E.0194
; LINE_WIDTH: 0.443858
G1 X147.278 Y132.186 E.01427
; LINE_WIDTH: 0.491593
G1 F14041.422
G1 X146.878 Y132.361 E.01597
; LINE_WIDTH: 0.529135
G1 F12957.231
G1 X146.809 Y132.39 E.00298
; LINE_WIDTH: 0.551984
G1 F12375.659
G1 X146.74 Y132.419 E.00312
G1 X146.024 Y132.475 E.02976
G1 X145.256 Y132.42 E.03193
; LINE_WIDTH: 0.551529
G1 F12386.732
G1 X145.052 Y132.332 E.00923
; LINE_WIDTH: 0.513947
G1 F13375.051
G1 X144.847 Y132.244 E.00855
; LINE_WIDTH: 0.476364
G1 F14534.759
G1 X144.642 Y132.157 E.00786
; LINE_WIDTH: 0.420284
G1 F15000
G1 X144.438 Y132.069 E.00685
G1 X143.712 Y131.618 E.02627
G1 X143.409 Y131.333 E.0128
G1 X130.646 Y131.333 E.39245
G1 X130.434 Y130.956 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X130.043 Y131.333 E.0167
G1 X129.478 Y131.693 E.02058
G1 X128.736 Y131.96 E.02422
G1 X127.98 Y132.043 E.02339
G1 X127.308 Y131.97 E.02075
G1 X126.563 Y131.713 E.02422
G1 X125.917 Y131.301 E.02354
G1 X125.565 Y130.956 E.01517
G1 X112.434 Y130.956 E.40346
G1 X112.043 Y131.333 E.0167
G1 X111.478 Y131.693 E.02058
G1 X110.736 Y131.96 E.02423
G1 X109.98 Y132.043 E.02339
G1 X109.308 Y131.97 E.02077
G1 X108.563 Y131.713 E.0242
G1 X107.917 Y131.301 E.02354
G1 X107.565 Y130.956 E.01517
G1 X94.434 Y130.956 E.40346
G1 X94.043 Y131.333 E.01669
G1 X93.478 Y131.693 E.02058
G1 X92.736 Y131.96 E.02423
G1 X91.98 Y132.043 E.02339
G1 X91.305 Y131.97 E.02085
G1 X90.709 Y131.781 E.01921
G1 X90.381 Y131.618 E.01126
G1 X89.778 Y131.181 E.02288
G1 X89.559 Y130.956 E.00965
G1 X73.994 Y130.956 E.47824
G1 X73.994 Y133.397 E.07503
G1 X182.006 Y133.397 E3.31881
G1 X182.006 Y130.956 E.07503
G1 X166.434 Y130.956 E.47847
G1 X166.043 Y131.333 E.0167
G1 X165.478 Y131.693 E.02058
G1 X164.736 Y131.96 E.02422
G1 X163.98 Y132.043 E.02339
G1 X163.308 Y131.97 E.02075
G1 X162.563 Y131.713 E.02423
G1 X161.917 Y131.301 E.02353
G1 X161.565 Y130.956 E.01517
G1 X148.434 Y130.956 E.40346
G1 X148.043 Y131.333 E.01669
G1 X147.478 Y131.693 E.02058
G1 X146.736 Y131.96 E.02422
G1 X145.98 Y132.043 E.02339
G1 X145.308 Y131.97 E.02075
G1 X144.563 Y131.713 E.02423
G1 X143.917 Y131.301 E.02353
G1 X143.565 Y130.956 E.01517
G1 X130.494 Y130.956 E.40162
; WIPE_START
G1 X132.494 Y130.956 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X125.253 Y131.71 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; LINE_WIDTH: 0.41999
G1 F15000
G1 X112.739 Y131.71 E.38452
G1 X112.414 Y131.996 E.01329
G1 X111.88 Y132.332 E.01939
G1 X111.066 Y132.643 E.02678
G1 X126.935 Y132.643 E.48758
G1 X126.313 Y132.425 E.02025
G1 X125.507 Y131.934 E.02899
G1 X125.298 Y131.749 E.00857
G1 X112.927 Y132.177 F30000
; LINE_WIDTH: 0.59935
G1 F11322.18
G1 X125.002 Y132.177 E.54747
G1 X108.935 Y132.643 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X108.313 Y132.425 E.02025
G1 X107.507 Y131.934 E.02899
G1 X107.253 Y131.71 E.01041
G1 X94.739 Y131.71 E.38452
G1 X94.414 Y131.995 E.01328
G1 X93.88 Y132.332 E.01939
G1 X93.066 Y132.643 E.02678
G1 X108.875 Y132.643 E.48574
G1 X94.927 Y132.177 F30000
; LINE_WIDTH: 0.59935
G1 F11322.18
G1 X107.002 Y132.177 E.54747
G1 X90.925 Y132.643 F30000
; LINE_WIDTH: 0.41999
G1 F15000
G1 X90.35 Y132.446 E.01869
G1 X89.938 Y132.228 E.01431
G1 X89.242 Y131.71 E.02668
G1 X74.748 Y131.71 E.44534
G1 X74.748 Y132.643 E.02868
G1 X90.865 Y132.643 E.49522
G1 X75.215 Y132.177 F30000
; LINE_WIDTH: 0.59935
G1 F11322.18
G1 X89.011 Y132.177 E.62555
; WIPE_START
G1 X87.011 Y132.177 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X89.264 Y130.341 Z6.4 F30000
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X89.593 Y130.012 E.01431
G1 X89.432 Y129.639
G1 X88.73 Y130.341 E.0305
G1 X88.197 Y130.341
G1 X89.323 Y129.215 E.04894
G1 X89.285 Y128.72
G1 X87.664 Y130.341 E.07043
G1 X87.131 Y130.341
G1 X88.819 Y128.653 E.07335
G1 X88.285 Y128.653
G1 X86.597 Y130.341 E.07335
G1 X86.064 Y130.341
G1 X87.752 Y128.653 E.07335
G1 X87.219 Y128.653
G1 X85.531 Y130.341 E.07335
G1 X84.998 Y130.341
G1 X86.686 Y128.653 E.07335
G1 X86.152 Y128.653
G1 X84.464 Y130.341 E.07335
G1 X83.931 Y130.341
G1 X85.619 Y128.653 E.07335
G1 X85.086 Y128.653
G1 X83.398 Y130.341 E.07335
G1 X82.865 Y130.341
G1 X84.553 Y128.653 E.07335
G1 X84.019 Y128.653
G1 X82.331 Y130.341 E.07335
G1 X81.798 Y130.341
G1 X83.486 Y128.653 E.07335
G1 X82.953 Y128.653
G1 X81.265 Y130.341 E.07335
G1 X80.732 Y130.341
G1 X82.42 Y128.653 E.07335
G1 X81.886 Y128.653
G1 X80.198 Y130.341 E.07335
G1 X79.665 Y130.341
G1 X81.353 Y128.653 E.07335
G1 X80.82 Y128.653
G1 X79.132 Y130.341 E.07335
G1 X78.599 Y130.341
G1 X80.286 Y128.653 E.07335
G1 X79.753 Y128.653
G1 X78.065 Y130.341 E.07335
G1 X77.532 Y130.341
G1 X79.22 Y128.653 E.07335
G1 X78.687 Y128.653
G1 X76.999 Y130.341 E.07335
G1 X76.466 Y130.341
G1 X78.153 Y128.653 E.07335
G1 X77.62 Y128.653
G1 X75.932 Y130.341 E.07335
G1 X75.399 Y130.341
G1 X77.087 Y128.653 E.07335
G1 X76.554 Y128.653
G1 X74.866 Y130.341 E.07335
G1 X74.333 Y130.341
G1 X76.02 Y128.653 E.07335
G1 X75.487 Y128.653
G1 X73.799 Y130.341 E.07335
G1 X73.417 Y130.19
G1 X74.954 Y128.653 E.06677
G1 X74.421 Y128.653
G1 X73.417 Y129.656 E.0436
G1 X73.417 Y129.123
G1 X73.887 Y128.653 E.02042
; WIPE_START
M204 S10000
G1 X73.417 Y129.123 E-.25258
G1 X73.417 Y129.656 E-.20264
G1 X73.985 Y129.089 E-.30479
; WIPE_END
G1 E-.04 F1800
G1 X81.611 Y129.38 Z6.4 F30000
G1 X106.861 Y130.341 Z6.4
G1 Z6
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X107.468 Y129.734 E.02636
G1 X107.345 Y129.324
G1 X106.328 Y130.341 E.04418
G1 X105.795 Y130.341
G1 X107.285 Y128.851 E.06477
G1 X106.949 Y128.653
G1 X105.261 Y130.341 E.07335
G1 X104.728 Y130.341
G1 X106.416 Y128.653 E.07335
G1 X105.883 Y128.653
G1 X104.195 Y130.341 E.07335
G1 X103.662 Y130.341
G1 X105.35 Y128.653 E.07335
G1 X104.816 Y128.653
G1 X103.128 Y130.341 E.07335
G1 X102.595 Y130.341
G1 X104.283 Y128.653 E.07335
G1 X103.75 Y128.653
G1 X102.062 Y130.341 E.07335
G1 X101.529 Y130.341
G1 X103.217 Y128.653 E.07335
G1 X102.683 Y128.653
G1 X100.995 Y130.341 E.07335
G1 X100.462 Y130.341
G1 X102.15 Y128.653 E.07335
G1 X101.617 Y128.653
G1 X99.929 Y130.341 E.07335
G1 X99.396 Y130.341
G1 X101.084 Y128.653 E.07335
G1 X100.55 Y128.653
G1 X98.862 Y130.341 E.07335
G1 X98.329 Y130.341
G1 X100.017 Y128.653 E.07335
G1 X99.484 Y128.653
G1 X97.796 Y130.341 E.07335
G1 X97.263 Y130.341
G1 X98.95 Y128.653 E.07335
G1 X98.417 Y128.653
G1 X96.729 Y130.341 E.07335
G1 X96.196 Y130.341
G1 X97.884 Y128.653 E.07335
G1 X97.351 Y128.653
G1 X95.663 Y130.341 E.07335
G1 X95.13 Y130.341
G1 X96.817 Y128.653 E.07335
G1 X96.284 Y128.653
G1 X94.596 Y130.341 E.07335
G1 X94.421 Y129.983
G1 X95.751 Y128.653 E.05779
G1 X95.218 Y128.653
G1 X94.681 Y129.19 E.02333
M204 S10000
G1 X94.749 Y129.258 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.138519
G1 F15000
G1 X94.609 Y129.507 E.00222
G1 X94.736 Y129.402 F30000
; LINE_WIDTH: 0.137674
G1 F15000
G1 X94.667 Y129.176 E.00183
; WIPE_START
G1 X94.736 Y129.402 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X102.347 Y129.973 Z6.4 F30000
G1 X107.493 Y130.36 Z6.4
G1 Z6
G1 E.8 F1800
; LINE_WIDTH: 0.189726
G1 F15000
G1 X107.56 Y129.909 E.00546
G1 X107.266 Y129.246 F30000
; LINE_WIDTH: 0.102375
G1 F15000
G1 X107.321 Y129.081 E.00084
; WIPE_START
G1 X107.266 Y129.246 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X114.884 Y129.717 Z6.4 F30000
G1 X124.992 Y130.341 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X125.506 Y129.827 E.02234
G1 X125.37 Y129.43
G1 X124.459 Y130.341 E.03958
G1 X123.925 Y130.341
G1 X125.292 Y128.974 E.0594
G1 X125.08 Y128.653
G1 X123.392 Y130.341 E.07335
G1 X122.859 Y130.341
G1 X124.547 Y128.653 E.07335
G1 X124.014 Y128.653
G1 X122.326 Y130.341 E.07335
G1 X121.792 Y130.341
G1 X123.48 Y128.653 E.07335
G1 X122.947 Y128.653
G1 X121.259 Y130.341 E.07335
G1 X120.726 Y130.341
G1 X122.414 Y128.653 E.07335
G1 X121.881 Y128.653
G1 X120.193 Y130.341 E.07335
G1 X119.659 Y130.341
G1 X121.347 Y128.653 E.07335
G1 X120.814 Y128.653
G1 X119.126 Y130.341 E.07335
G1 X118.593 Y130.341
G1 X120.281 Y128.653 E.07335
G1 X119.748 Y128.653
G1 X118.06 Y130.341 E.07335
G1 X117.526 Y130.341
G1 X119.214 Y128.653 E.07335
G1 X118.681 Y128.653
G1 X116.993 Y130.341 E.07335
G1 X116.46 Y130.341
G1 X118.148 Y128.653 E.07335
G1 X117.615 Y128.653
G1 X115.927 Y130.341 E.07335
G1 X115.393 Y130.341
G1 X117.081 Y128.653 E.07335
G1 X116.548 Y128.653
G1 X114.86 Y130.341 E.07335
G1 X114.327 Y130.341
G1 X116.015 Y128.653 E.07335
G1 X115.481 Y128.653
G1 X113.794 Y130.341 E.07335
G1 X113.26 Y130.341
G1 X114.948 Y128.653 E.07335
G1 X114.415 Y128.653
G1 X112.727 Y130.341 E.07335
G1 X112.264 Y130.271
G1 X113.882 Y128.653 E.07028
G1 X113.348 Y128.653
G1 X112.649 Y129.352 E.03039
M204 S10000
G1 X112.868 Y128.634 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.178029
G1 F15000
G1 X112.69 Y129.045 E.00493
G1 X112.718 Y129.422 F30000
; LINE_WIDTH: 0.101096
G1 F15000
G3 X112.545 Y129.698 I-9.204 J-5.584 E.00155
G1 X112.715 Y129.419 F30000
; LINE_WIDTH: 0.166341
G1 F15000
G1 X112.548 Y129.7 E.00329
; WIPE_START
G1 X112.715 Y129.419 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X120.344 Y129.65 Z6.4 F30000
G1 X143.123 Y130.341 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X143.547 Y129.917 E.01841
G1 X143.398 Y129.533
G1 X142.59 Y130.341 E.03512
G1 X142.056 Y130.341
G1 X143.305 Y129.092 E.05426
G1 X143.211 Y128.653
G1 X141.523 Y130.341 E.07335
G1 X140.99 Y130.341
G1 X142.678 Y128.653 E.07335
G1 X142.144 Y128.653
G1 X140.456 Y130.341 E.07335
G1 X139.923 Y130.341
G1 X141.611 Y128.653 E.07335
G1 X141.078 Y128.653
G1 X139.39 Y130.341 E.07335
G1 X138.857 Y130.341
G1 X140.545 Y128.653 E.07335
G1 X140.011 Y128.653
G1 X138.323 Y130.341 E.07335
G1 X137.79 Y130.341
G1 X139.478 Y128.653 E.07335
G1 X138.945 Y128.653
G1 X137.257 Y130.341 E.07335
G1 X136.724 Y130.341
G1 X138.412 Y128.653 E.07335
G1 X137.878 Y128.653
G1 X136.19 Y130.341 E.07335
G1 X135.657 Y130.341
G1 X137.345 Y128.653 E.07335
G1 X136.812 Y128.653
G1 X135.124 Y130.341 E.07335
G1 X134.591 Y130.341
G1 X136.279 Y128.653 E.07335
G1 X135.745 Y128.653
G1 X134.057 Y130.341 E.07335
G1 X133.524 Y130.341
G1 X135.212 Y128.653 E.07335
G1 X134.679 Y128.653
G1 X132.991 Y130.341 E.07335
G1 X132.458 Y130.341
G1 X134.145 Y128.653 E.07335
G1 X133.612 Y128.653
G1 X131.924 Y130.341 E.07335
G1 X131.391 Y130.341
G1 X133.079 Y128.653 E.07335
G1 X132.546 Y128.653
G1 X130.858 Y130.341 E.07335
G1 X130.325 Y130.341
G1 X132.012 Y128.653 E.07335
G1 X131.479 Y128.653
G1 X130.603 Y129.529 E.03806
M204 S10000
G1 X130.671 Y129.596 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.141887
G1 F15000
G1 X130.546 Y129.783 E.00181
; LINE_WIDTH: 0.12826
G1 X130.499 Y129.851 E.00058
; LINE_WIDTH: 0.102137
G1 X130.452 Y129.92 E.0004
G1 X130.667 Y129.593 F30000
; LINE_WIDTH: 0.19998
G1 F15000
G3 X130.459 Y129.925 I-13.447 J-8.154 E.00501
; WIPE_START
G1 X130.667 Y129.593 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.934 Y128.634 Z6.4 F30000
G1 Z6
M73 P96 R1
G1 E.8 F1800
; LINE_WIDTH: 0.181878
G1 F15000
G1 X130.685 Y129.162 E.00661
G1 X130.923 Y128.634 F30000
; LINE_WIDTH: 0.284734
G1 F15000
G1 X130.691 Y129.165 E.01141
; WIPE_START
G1 X130.923 Y128.634 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.548 Y128.975 Z6.4 F30000
G1 X161.59 Y130.005 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X161.254 Y130.341 E.01461
G1 X160.72 Y130.341
G1 X161.43 Y129.631 E.03084
G1 X161.322 Y129.206
G1 X160.187 Y130.341 E.04932
G1 X159.654 Y130.341
G1 X161.285 Y128.71 E.07087
G1 X160.808 Y128.653
G1 X159.12 Y130.341 E.07335
G1 X158.587 Y130.341
G1 X160.275 Y128.653 E.07335
G1 X159.742 Y128.653
G1 X158.054 Y130.341 E.07335
G1 X157.521 Y130.341
G1 X159.209 Y128.653 E.07335
G1 X158.675 Y128.653
G1 X156.987 Y130.341 E.07335
G1 X156.454 Y130.341
G1 X158.142 Y128.653 E.07335
G1 X157.609 Y128.653
G1 X155.921 Y130.341 E.07335
G1 X155.388 Y130.341
G1 X157.076 Y128.653 E.07335
G1 X156.542 Y128.653
G1 X154.854 Y130.341 E.07335
G1 X154.321 Y130.341
G1 X156.009 Y128.653 E.07335
G1 X155.476 Y128.653
G1 X153.788 Y130.341 E.07335
G1 X153.255 Y130.341
G1 X154.943 Y128.653 E.07335
G1 X154.409 Y128.653
G1 X152.721 Y130.341 E.07335
G1 X152.188 Y130.341
G1 X153.876 Y128.653 E.07335
G1 X153.343 Y128.653
G1 X151.655 Y130.341 E.07335
G1 X151.122 Y130.341
G1 X152.81 Y128.653 E.07335
G1 X152.276 Y128.653
G1 X150.588 Y130.341 E.07335
G1 X150.055 Y130.341
G1 X151.743 Y128.653 E.07335
G1 X151.21 Y128.653
G1 X149.522 Y130.341 E.07335
G1 X148.989 Y130.341
G1 X150.676 Y128.653 E.07335
G1 X150.143 Y128.653
G1 X148.455 Y130.341 E.07335
G1 X148.534 Y129.729
G1 X149.61 Y128.653 E.04674
G1 X149.077 Y128.653
G1 X148.703 Y129.027 E.01624
; WIPE_START
M204 S10000
G1 X149.077 Y128.653 E-.20086
G1 X149.61 Y128.653 E-.20264
G1 X148.947 Y129.317 E-.3565
; WIPE_END
G1 E-.04 F1800
G1 X156.578 Y129.201 Z6.4 F30000
G1 X161.245 Y129.13 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.0970074
G1 F15000
G1 X161.308 Y128.954 E.00082
G1 X161.321 Y129.183 F30000
; LINE_WIDTH: 0.099479
G1 F15000
G1 X161.239 Y129.022 E.00083
; CHANGE_LAYER
; Z_HEIGHT: 6.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X161.321 Y129.183 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 31/33
; update layer progress
M73 L31
M991 S0 P30 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6.4 I-.151 J1.208 P1  F30000
G1 X182.398 Y131.814 Z6.4
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
G1 X182.398 Y133.335 E.05047
G1 X73.602 Y133.335 E3.60896
G1 X73.602 Y131.814 E.05047
G1 X182.338 Y131.814 E3.60697
; WIPE_START
G1 X182.398 Y133.335 E-.57856
G1 X181.92 Y133.335 E-.18144
; WIPE_END
G1 E-.04 F1800
G1 X182.79 Y129.696 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y133.727 E.12387
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y133.727 E3.36709
G1 X73.21 Y129.696 E.12387
G1 X89.676 Y129.697 E.50594
G2 X94.325 Y129.696 I2.324 J-.948 E.18262
G1 X107.675 Y129.696 E.41021
G2 X112.325 Y129.696 I2.325 J-.947 E.18266
G1 X125.675 Y129.696 E.41021
G2 X130.325 Y129.696 I2.325 J-.947 E.18266
G1 X143.675 Y129.696 E.41021
G2 X148.325 Y129.696 I2.325 J-.947 E.18266
G1 X161.675 Y129.696 E.41021
G2 X166.325 Y129.696 I2.325 J-.947 E.18266
G1 X182.73 Y129.696 E.50408
; WIPE_START
M204 S10000
G1 X182.76 Y131.696 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.583 Y130.723 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X181.763 Y129.903 E.03563
G1 X181.229 Y129.903
G1 X182.583 Y131.256 E.0588
G1 X182.384 Y131.591
G1 X180.696 Y129.903 E.07335
G1 X180.163 Y129.903
G1 X181.851 Y131.591 E.07335
G1 X181.318 Y131.591
G1 X179.63 Y129.903 E.07335
G1 X179.096 Y129.903
G1 X180.784 Y131.591 E.07335
G1 X180.251 Y131.591
G1 X178.563 Y129.903 E.07335
G1 X178.03 Y129.903
G1 X179.718 Y131.591 E.07335
G1 X179.185 Y131.591
G1 X177.497 Y129.903 E.07335
G1 X176.963 Y129.903
G1 X178.651 Y131.591 E.07335
G1 X178.118 Y131.591
G1 X176.43 Y129.903 E.07335
G1 X175.897 Y129.903
G1 X177.585 Y131.591 E.07335
G1 X177.052 Y131.591
G1 X175.364 Y129.903 E.07335
G1 X174.83 Y129.903
G1 X176.518 Y131.591 E.07335
G1 X175.985 Y131.591
G1 X174.297 Y129.903 E.07335
G1 X173.764 Y129.903
G1 X175.452 Y131.591 E.07335
G1 X174.918 Y131.591
G1 X173.231 Y129.903 E.07335
G1 X172.697 Y129.903
G1 X174.385 Y131.591 E.07335
G1 X173.852 Y131.591
G1 X172.164 Y129.903 E.07335
G1 X171.631 Y129.903
G1 X173.319 Y131.591 E.07335
G1 X172.785 Y131.591
G1 X171.098 Y129.903 E.07335
G1 X170.564 Y129.903
G1 X172.252 Y131.591 E.07335
G1 X171.719 Y131.591
G1 X170.031 Y129.903 E.07335
G1 X169.498 Y129.903
G1 X171.186 Y131.591 E.07335
G1 X170.652 Y131.591
G1 X168.965 Y129.903 E.07335
G1 X168.431 Y129.903
G1 X170.119 Y131.591 E.07335
G1 X169.586 Y131.591
G1 X167.898 Y129.903 E.07335
G1 X167.365 Y129.903
G1 X169.053 Y131.591 E.07335
G1 X168.519 Y131.591
G1 X166.831 Y129.903 E.07335
G1 X166.407 Y130.012
G1 X167.986 Y131.591 E.06863
G1 X167.453 Y131.591
G1 X166.203 Y130.341 E.05432
G1 X165.96 Y130.632
G1 X166.92 Y131.591 E.04169
G1 X166.386 Y131.591
G1 X165.68 Y130.885 E.03068
G1 X165.362 Y131.1
G1 X165.853 Y131.591 E.02132
G1 X165.32 Y131.591
G1 X165.003 Y131.275 E.01375
; WIPE_START
M204 S10000
G1 X165.32 Y131.591 E-.17
G1 X165.853 Y131.591 E-.20264
G1 X165.362 Y131.1 E-.26365
G1 X165.632 Y130.918 E-.12371
; WIPE_END
G1 E-.04 F1800
G1 X160.966 Y129.903 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
G1 F12000
M204 S2000
G1 X162.654 Y131.591 E.07335
G1 X162.12 Y131.591
G1 X160.432 Y129.903 E.07335
G1 X159.899 Y129.903
G1 X161.587 Y131.591 E.07335
G1 X161.054 Y131.591
G1 X159.366 Y129.903 E.07335
G1 X158.833 Y129.903
G1 X160.521 Y131.591 E.07335
G1 X159.987 Y131.591
G1 X158.299 Y129.903 E.07335
G1 X157.766 Y129.903
G1 X159.454 Y131.591 E.07335
G1 X158.921 Y131.591
G1 X157.233 Y129.903 E.07335
G1 X156.7 Y129.903
G1 X158.387 Y131.591 E.07335
G1 X157.854 Y131.591
G1 X156.166 Y129.903 E.07335
G1 X155.633 Y129.903
G1 X157.321 Y131.591 E.07335
G1 X156.788 Y131.591
G1 X155.1 Y129.903 E.07335
G1 X154.567 Y129.903
G1 X156.254 Y131.591 E.07335
G1 X155.721 Y131.591
G1 X154.033 Y129.903 E.07335
G1 X153.5 Y129.903
G1 X155.188 Y131.591 E.07335
G1 X154.655 Y131.591
G1 X152.967 Y129.903 E.07335
G1 X152.434 Y129.903
G1 X154.121 Y131.591 E.07335
G1 X153.588 Y131.591
G1 X151.9 Y129.903 E.07335
G1 X151.367 Y129.903
G1 X153.055 Y131.591 E.07335
G1 X152.522 Y131.591
G1 X150.834 Y129.903 E.07335
G1 X150.301 Y129.903
G1 X151.988 Y131.591 E.07335
G1 X151.455 Y131.591
G1 X149.767 Y129.903 E.07335
G1 X149.234 Y129.903
G1 X150.922 Y131.591 E.07335
G1 X150.389 Y131.591
G1 X148.701 Y129.903 E.07335
G1 X148.36 Y130.096
G1 X149.855 Y131.591 E.06497
G1 X149.322 Y131.591
G1 X148.146 Y130.415 E.05109
G1 X147.895 Y130.697
G1 X148.789 Y131.591 E.03885
G1 X148.256 Y131.591
G1 X147.606 Y130.941 E.02823
G1 X147.278 Y131.147
G1 X147.722 Y131.591 E.0193
M204 S10000
G1 X162.723 Y131.61 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.241854
G1 F15000
G1 X162.795 Y131.56 E.00142
; LINE_WIDTH: 0.283001
G1 X162.866 Y131.509 E.00171
; LINE_WIDTH: 0.324147
G1 X162.938 Y131.459 E.00201
; LINE_WIDTH: 0.344706
G2 X162.873 Y131.351 I-.115 J-.004 E.00329
; LINE_WIDTH: 0.290692
G1 X162.759 Y131.271 E.00281
; LINE_WIDTH: 0.246373
G1 X162.652 Y131.193 E.00219
; LINE_WIDTH: 0.207967
G1 X162.538 Y131.105 E.00194
; LINE_WIDTH: 0.163596
M73 P96 R0
G1 X162.332 Y130.933 E.00264
; LINE_WIDTH: 0.127039
G1 X162.044 Y130.663 E.00271
G1 X161.773 Y130.368 E.00275
; LINE_WIDTH: 0.162701
G1 X161.687 Y130.265 E.00131
; LINE_WIDTH: 0.190033
G1 X161.605 Y130.161 E.00158
; LINE_WIDTH: 0.224461
G1 X161.521 Y130.05 E.00207
; LINE_WIDTH: 0.25463
G1 X161.402 Y129.884 E.00351
; WIPE_START
G1 X161.521 Y130.05 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X153.9 Y130.462 Z6.6 F30000
G1 X144.438 Y130.973 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X145.048 Y131.583 E.02649
G1 X144.523 Y131.591
G1 X142.835 Y129.903 E.07335
G1 X142.302 Y129.903
G1 X143.99 Y131.591 E.07335
G1 X143.456 Y131.591
G1 X141.768 Y129.903 E.07335
G1 X141.235 Y129.903
G1 X142.923 Y131.591 E.07335
G1 X142.39 Y131.591
G1 X140.702 Y129.903 E.07335
G1 X140.169 Y129.903
G1 X141.857 Y131.591 E.07335
G1 X141.323 Y131.591
G1 X139.635 Y129.903 E.07335
G1 X139.102 Y129.903
G1 X140.79 Y131.591 E.07335
G1 X140.257 Y131.591
G1 X138.569 Y129.903 E.07335
G1 X138.036 Y129.903
G1 X139.723 Y131.591 E.07335
G1 X139.19 Y131.591
G1 X137.502 Y129.903 E.07335
G1 X136.969 Y129.903
G1 X138.657 Y131.591 E.07335
G1 X138.124 Y131.591
G1 X136.436 Y129.903 E.07335
G1 X135.903 Y129.903
G1 X137.59 Y131.591 E.07335
G1 X137.057 Y131.591
G1 X135.369 Y129.903 E.07335
G1 X134.836 Y129.903
G1 X136.524 Y131.591 E.07335
G1 X135.991 Y131.591
G1 X134.303 Y129.903 E.07335
G1 X133.77 Y129.903
G1 X135.457 Y131.591 E.07335
G1 X134.924 Y131.591
G1 X133.236 Y129.903 E.07335
G1 X132.703 Y129.903
G1 X134.391 Y131.591 E.07335
G1 X133.858 Y131.591
G1 X132.17 Y129.903 E.07335
G1 X131.636 Y129.903
G1 X133.324 Y131.591 E.07335
G1 X132.791 Y131.591
G1 X131.103 Y129.903 E.07335
G1 X130.57 Y129.903
G1 X132.258 Y131.591 E.07335
G1 X131.725 Y131.591
G1 X130.311 Y130.178 E.06141
G1 X130.088 Y130.488
G1 X131.191 Y131.591 E.04794
G1 X130.658 Y131.591
G1 X129.827 Y130.76 E.0361
G1 X129.529 Y130.996
G1 X130.125 Y131.591 E.02587
G1 X129.592 Y131.591
G1 X129.192 Y131.192 E.01736
M204 S10000
G1 X129.078 Y131.224 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.154113
G1 F15000
G1 X129.028 Y131.292 E.00076
; LINE_WIDTH: 0.196837
G1 X128.978 Y131.359 E.00106
; LINE_WIDTH: 0.225291
G1 X129.083 Y131.61 E.00404
; WIPE_START
G1 X128.978 Y131.359 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X130.51 Y129.884 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; LINE_WIDTH: 0.116241
G1 F15000
G1 X130.406 Y130.039 E.00112
; LINE_WIDTH: 0.0853674
G1 X130.442 Y130.047 E.00013
; WIPE_START
G1 X130.406 Y130.039 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.022 Y130.539 Z6.6 F30000
G1 X144.451 Y130.961 Z6.6
G1 Z6.2
G1 E.8 F1800
; LINE_WIDTH: 0.221716
G1 F15000
G1 X144.305 Y130.972 E.00214
G1 X144.012 Y130.696 E.00586
G1 X143.735 Y130.394 E.00597
; LINE_WIDTH: 0.256147
G1 X143.647 Y130.289 E.00238
; LINE_WIDTH: 0.284288
G1 X143.562 Y130.182 E.0027
; LINE_WIDTH: 0.319382
G1 X143.478 Y130.071 E.00314
; LINE_WIDTH: 0.345191
G1 X143.345 Y129.884 E.00564
; WIPE_START
G1 X143.478 Y130.071 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X135.878 Y130.769 Z6.6 F30000
G1 X126.925 Y131.591 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X125.237 Y129.903 E.07335
G1 X124.704 Y129.903
G1 X126.392 Y131.591 E.07335
G1 X125.859 Y131.591
G1 X124.171 Y129.903 E.07335
G1 X123.638 Y129.903
G1 X125.326 Y131.591 E.07335
G1 X124.792 Y131.591
G1 X123.104 Y129.903 E.07335
G1 X122.571 Y129.903
G1 X124.259 Y131.591 E.07335
G1 X123.726 Y131.591
G1 X122.038 Y129.903 E.07335
G1 X121.505 Y129.903
G1 X123.192 Y131.591 E.07335
G1 X122.659 Y131.591
G1 X120.971 Y129.903 E.07335
G1 X120.438 Y129.903
G1 X122.126 Y131.591 E.07335
G1 X121.593 Y131.591
G1 X119.905 Y129.903 E.07335
G1 X119.372 Y129.903
G1 X121.059 Y131.591 E.07335
G1 X120.526 Y131.591
G1 X118.838 Y129.903 E.07335
G1 X118.305 Y129.903
G1 X119.993 Y131.591 E.07335
G1 X119.46 Y131.591
G1 X117.772 Y129.903 E.07335
G1 X117.239 Y129.903
G1 X118.926 Y131.591 E.07335
G1 X118.393 Y131.591
G1 X116.705 Y129.903 E.07335
G1 X116.172 Y129.903
G1 X117.86 Y131.591 E.07335
G1 X117.327 Y131.591
G1 X115.639 Y129.903 E.07335
G1 X115.106 Y129.903
G1 X116.793 Y131.591 E.07335
G1 X116.26 Y131.591
G1 X114.572 Y129.903 E.07335
G1 X114.039 Y129.903
G1 X115.727 Y131.591 E.07335
G1 X115.194 Y131.591
G1 X113.506 Y129.903 E.07335
G1 X112.972 Y129.903
G1 X114.66 Y131.591 E.07335
G1 X114.127 Y131.591
G1 X112.453 Y129.917 E.07273
G1 X112.26 Y130.257
G1 X113.594 Y131.591 E.05795
G1 X113.061 Y131.591
G1 X112.028 Y130.558 E.04487
G1 X111.758 Y130.822
G1 X112.527 Y131.591 E.03342
G1 X111.994 Y131.591
G1 X111.451 Y131.048 E.02362
G1 X111.103 Y131.233
G1 X111.461 Y131.591 E.01555
M204 S10000
G1 X111.058 Y131.249 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.135311
G1 F15000
G1 X110.933 Y131.335 E.00114
G1 X110.962 Y131.61 E.00208
G1 X127.105 Y131.392 F30000
; LINE_WIDTH: 0.110854
G1 F15000
G3 X126.829 Y131.201 I11.611 J-17.111 E.00186
G1 X108.795 Y131.591 F30000
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X107.107 Y129.903 E.07335
G1 X106.573 Y129.903
G1 X108.261 Y131.591 E.07335
G1 X107.728 Y131.591
G1 X106.04 Y129.903 E.07335
G1 X105.507 Y129.903
G1 X107.195 Y131.591 E.07335
G1 X106.662 Y131.591
G1 X104.974 Y129.903 E.07335
G1 X104.44 Y129.903
G1 X106.128 Y131.591 E.07335
G1 X105.595 Y131.591
G1 X103.907 Y129.903 E.07335
G1 X103.374 Y129.903
G1 X105.062 Y131.591 E.07335
G1 X104.528 Y131.591
G1 X102.841 Y129.903 E.07335
G1 X102.307 Y129.903
G1 X103.995 Y131.591 E.07335
G1 X103.462 Y131.591
G1 X101.774 Y129.903 E.07335
G1 X101.241 Y129.903
G1 X102.929 Y131.591 E.07335
G1 X102.395 Y131.591
G1 X100.708 Y129.903 E.07335
G1 X100.174 Y129.903
G1 X101.862 Y131.591 E.07335
G1 X101.329 Y131.591
G1 X99.641 Y129.903 E.07335
G1 X99.108 Y129.903
G1 X100.796 Y131.591 E.07335
G1 X100.262 Y131.591
G1 X98.575 Y129.903 E.07335
G1 X98.041 Y129.903
G1 X99.729 Y131.591 E.07335
G1 X99.196 Y131.591
G1 X97.508 Y129.903 E.07335
G1 X96.975 Y129.903
M73 P97 R0
G1 X98.663 Y131.591 E.07335
G1 X98.129 Y131.591
G1 X96.442 Y129.903 E.07335
G1 X95.908 Y129.903
G1 X97.596 Y131.591 E.07335
G1 X97.063 Y131.591
G1 X95.375 Y129.903 E.07335
G1 X94.842 Y129.903
G1 X96.53 Y131.591 E.07335
G1 X95.996 Y131.591
G1 X94.41 Y130.005 E.06892
G1 X94.207 Y130.335
G1 X95.463 Y131.591 E.05458
G1 X94.93 Y131.591
G1 X93.965 Y130.626 E.04192
G1 X93.686 Y130.88
G1 X94.397 Y131.591 E.03088
G1 X93.863 Y131.591
G1 X93.369 Y131.097 E.02149
G1 X93.011 Y131.272
G1 X93.33 Y131.591 E.01388
M204 S10000
G1 X109.095 Y131.441 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.201968
G1 F15000
G3 X108.778 Y131.223 I10.411 J-15.497 E.00499
; LINE_WIDTH: 0.143894
G1 X108.678 Y131.149 E.00102
; LINE_WIDTH: 0.104134
G1 X108.546 Y131.047 E.00083
; WIPE_START
G1 X108.678 Y131.149 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X107.705 Y130.207 Z6.6 F30000
G1 Z6.2
G1 E.8 F1800
; LINE_WIDTH: 0.0961438
G1 F15000
G1 X107.648 Y130.134 E.0004
; LINE_WIDTH: 0.122822
G1 X107.567 Y130.027 E.00088
; LINE_WIDTH: 0.156973
G1 X107.465 Y129.884 E.00163
; WIPE_START
G1 X107.567 Y130.027 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X99.934 Y129.977 Z6.6 F30000
G1 X88.977 Y129.905 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.42
G1 F12000
M204 S2000
G1 X90.664 Y131.591 E.07329
G1 X90.131 Y131.591
G1 X88.444 Y129.905 E.07329
G1 X87.911 Y129.904
G1 X89.597 Y131.591 E.07329
G1 X89.064 Y131.591
G1 X87.377 Y129.904 E.07329
G1 X86.844 Y129.904
G1 X88.531 Y131.591 E.0733
G1 X87.998 Y131.591
G1 X86.311 Y129.904 E.0733
G1 X85.777 Y129.904
G1 X87.464 Y131.591 E.0733
G1 X86.931 Y131.591
G1 X85.244 Y129.904 E.0733
G1 X84.711 Y129.904
G1 X86.398 Y131.591 E.0733
G1 X85.864 Y131.591
G1 X84.178 Y129.904 E.07331
G1 X83.644 Y129.904
G1 X85.331 Y131.591 E.07331
G1 X84.798 Y131.591
G1 X83.111 Y129.904 E.07331
G1 X82.578 Y129.904
G1 X84.265 Y131.591 E.07331
G1 X83.731 Y131.591
G1 X82.044 Y129.904 E.07331
G1 X81.511 Y129.904
G1 X83.198 Y131.591 E.07332
G1 X82.665 Y131.591
G1 X80.978 Y129.904 E.07332
G1 X80.444 Y129.904
G1 X82.132 Y131.591 E.07332
G1 X81.598 Y131.591
G1 X79.911 Y129.904 E.07332
G1 X79.378 Y129.904
G1 X81.065 Y131.591 E.07332
G1 X80.532 Y131.591
G1 X78.844 Y129.904 E.07333
G1 X78.311 Y129.904
G1 X79.999 Y131.591 E.07333
G1 X79.465 Y131.591
G1 X77.778 Y129.904 E.07333
G1 X77.245 Y129.904
G1 X78.932 Y131.591 E.07333
G1 X78.399 Y131.591
G1 X76.711 Y129.903 E.07333
G1 X76.178 Y129.903
G1 X77.866 Y131.591 E.07334
G1 X77.332 Y131.591
G1 X75.645 Y129.903 E.07334
G1 X75.111 Y129.903
G1 X76.799 Y131.591 E.07334
G1 X76.266 Y131.591
G1 X74.578 Y129.903 E.07334
G1 X74.045 Y129.903
G1 X75.733 Y131.591 E.07334
G1 X75.199 Y131.591
G1 X73.511 Y129.903 E.07335
G1 X73.417 Y130.342
G1 X74.666 Y131.591 E.05426
G1 X74.133 Y131.591
G1 X73.417 Y130.876 E.03109
M204 S10000
G1 X90.73 Y131.61 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.240002
G1 F15000
G1 X90.801 Y131.561 E.00138
; LINE_WIDTH: 0.277474
G1 X90.872 Y131.513 E.00164
; LINE_WIDTH: 0.314945
G1 X90.942 Y131.465 E.0019
; LINE_WIDTH: 0.336163
G2 X90.874 Y131.347 I-.112 J-.013 E.00348
; LINE_WIDTH: 0.283209
G1 X90.76 Y131.268 E.00272
; LINE_WIDTH: 0.237483
G1 X90.646 Y131.184 E.00224
; LINE_WIDTH: 0.20027
G1 X90.547 Y131.107 E.00161
; LINE_WIDTH: 0.169471
G1 X90.436 Y131.017 E.00147
; LINE_WIDTH: 0.123295
G1 X90.051 Y130.664 E.00342
G1 X89.776 Y130.366 E.00266
; LINE_WIDTH: 0.155393
G1 X89.69 Y130.263 E.00123
; LINE_WIDTH: 0.182663
G1 X89.608 Y130.159 E.0015
; LINE_WIDTH: 0.217036
G1 X89.524 Y130.048 E.00198
; LINE_WIDTH: 0.247307
G1 X89.408 Y129.886 E.00333
; WIPE_START
G1 X89.524 Y130.048 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X81.964 Y131.098 Z6.6 F30000
G1 X73.994 Y132.206 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.41999
G1 F15000
G1 X73.994 Y132.943 E.02265
G1 X182.006 Y132.943 E3.31882
G1 X182.006 Y132.206 E.02265
G1 X74.054 Y132.206 E3.31697
G1 X74.363 Y132.574 F30000
; LINE_WIDTH: 0.40307
G1 F15000
G1 X181.577 Y132.574 E3.1465
; CHANGE_LAYER
; Z_HEIGHT: 6.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X179.577 Y132.574 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 32/33
; update layer progress
M73 L32
M991 S0 P31 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6.6 I.55 J1.085 P1  F30000
G1 X182.79 Y130.946 Z6.6
G1 Z6.4
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X182.79 Y133.272 E.07149
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y133.272 E3.36709
G1 X73.21 Y130.946 E.07149
G1 X90.788 Y130.946 E.54011
G2 X93.213 Y130.946 I1.213 J-2.188 E.07779
G1 X108.788 Y130.946 E.47857
G2 X111.213 Y130.946 I1.213 J-2.188 E.0778
G1 X126.788 Y130.946 E.47857
G2 X129.213 Y130.946 I1.213 J-2.188 E.0778
G1 X144.788 Y130.946 E.47857
G2 X147.213 Y130.946 I1.213 J-2.188 E.0778
G1 X162.788 Y130.946 E.47857
G2 X165.213 Y130.946 I1.213 J-2.188 E.0778
G1 X182.73 Y130.946 E.53826
; WIPE_START
M204 S10000
G1 X182.782 Y132.945 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X182.583 Y132.475 Z6.8 F30000
G1 Z6.4
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X182.217 Y132.841 E.0159
G1 X181.684 Y132.841
G1 X182.583 Y131.942 E.03907
G1 X182.583 Y131.409
G1 X181.15 Y132.841 E.06224
G1 X180.617 Y132.841
G1 X182.305 Y131.153 E.07335
G1 X181.772 Y131.153
G1 X180.084 Y132.841 E.07335
G1 X179.551 Y132.841
G1 X181.238 Y131.153 E.07335
G1 X180.705 Y131.153
G1 X179.017 Y132.841 E.07335
G1 X178.484 Y132.841
G1 X180.172 Y131.153 E.07335
G1 X179.639 Y131.153
G1 X177.951 Y132.841 E.07335
G1 X177.418 Y132.841
G1 X179.105 Y131.153 E.07335
G1 X178.572 Y131.153
G1 X176.884 Y132.841 E.07335
G1 X176.351 Y132.841
G1 X178.039 Y131.153 E.07335
G1 X177.506 Y131.153
G1 X175.818 Y132.841 E.07335
G1 X175.284 Y132.841
G1 X176.972 Y131.153 E.07335
G1 X176.439 Y131.153
G1 X174.751 Y132.841 E.07335
G1 X174.218 Y132.841
G1 X175.906 Y131.153 E.07335
G1 X175.373 Y131.153
G1 X173.685 Y132.841 E.07335
G1 X173.151 Y132.841
G1 X174.839 Y131.153 E.07335
G1 X174.306 Y131.153
G1 X172.618 Y132.841 E.07335
G1 X172.085 Y132.841
G1 X173.773 Y131.153 E.07335
G1 X173.24 Y131.153
G1 X171.552 Y132.841 E.07335
G1 X171.018 Y132.841
G1 X172.706 Y131.153 E.07335
G1 X172.173 Y131.153
G1 X170.485 Y132.841 E.07335
G1 X169.952 Y132.841
G1 X171.64 Y131.153 E.07335
G1 X171.107 Y131.153
G1 X169.419 Y132.841 E.07335
G1 X168.885 Y132.841
G1 X170.573 Y131.153 E.07335
G1 X170.04 Y131.153
G1 X168.352 Y132.841 E.07335
G1 X167.819 Y132.841
G1 X169.507 Y131.153 E.07335
G1 X168.974 Y131.153
G1 X167.286 Y132.841 E.07335
G1 X166.752 Y132.841
G1 X168.44 Y131.153 E.07335
G1 X167.907 Y131.153
G1 X166.219 Y132.841 E.07335
G1 X165.686 Y132.841
G1 X167.374 Y131.153 E.07335
G1 X166.84 Y131.153
G1 X165.153 Y132.841 E.07335
G1 X164.619 Y132.841
G1 X166.307 Y131.153 E.07335
G1 X165.774 Y131.153
G1 X164.086 Y132.841 E.07335
G1 X163.553 Y132.841
G1 X165.211 Y131.183 E.07206
G1 X164.428 Y131.433
G1 X163.02 Y132.841 E.06119
G1 X162.486 Y132.841
G1 X163.864 Y131.463 E.05987
G1 X163.395 Y131.399
G1 X161.953 Y132.841 E.06267
G1 X161.42 Y132.841
G1 X162.989 Y131.272 E.0682
G1 X162.574 Y131.153
G1 X160.887 Y132.841 E.07335
G1 X160.353 Y132.841
G1 X162.041 Y131.153 E.07335
G1 X161.508 Y131.153
G1 X159.82 Y132.841 E.07335
G1 X159.287 Y132.841
G1 X160.975 Y131.153 E.07335
G1 X160.441 Y131.153
G1 X158.754 Y132.841 E.07335
G1 X158.22 Y132.841
G1 X159.908 Y131.153 E.07335
G1 X159.375 Y131.153
G1 X157.687 Y132.841 E.07335
G1 X157.154 Y132.841
G1 X158.842 Y131.153 E.07335
G1 X158.308 Y131.153
G1 X156.62 Y132.841 E.07335
G1 X156.087 Y132.841
G1 X157.775 Y131.153 E.07335
G1 X157.242 Y131.153
G1 X155.554 Y132.841 E.07335
G1 X155.021 Y132.841
G1 X156.709 Y131.153 E.07335
G1 X156.175 Y131.153
G1 X154.487 Y132.841 E.07335
G1 X153.954 Y132.841
G1 X155.642 Y131.153 E.07335
G1 X155.109 Y131.153
G1 X153.421 Y132.841 E.07335
G1 X152.888 Y132.841
G1 X154.576 Y131.153 E.07335
G1 X154.042 Y131.153
G1 X152.354 Y132.841 E.07335
G1 X151.821 Y132.841
G1 X153.509 Y131.153 E.07335
G1 X152.976 Y131.153
G1 X151.288 Y132.841 E.07335
G1 X150.755 Y132.841
G1 X152.443 Y131.153 E.07335
G1 X151.909 Y131.153
G1 X150.221 Y132.841 E.07335
G1 X149.688 Y132.841
G1 X151.376 Y131.153 E.07335
G1 X150.843 Y131.153
G1 X149.155 Y132.841 E.07335
G1 X148.622 Y132.841
G1 X150.31 Y131.153 E.07335
G1 X149.776 Y131.153
G1 X148.088 Y132.841 E.07335
G1 X147.555 Y132.841
G1 X149.243 Y131.153 E.07335
G1 X148.71 Y131.153
G1 X147.022 Y132.841 E.07335
G1 X146.489 Y132.841
G1 X148.176 Y131.153 E.07335
G1 X147.643 Y131.153
G1 X145.955 Y132.841 E.07335
G1 X145.422 Y132.841
G1 X146.978 Y131.285 E.06761
G1 X146.277 Y131.453
G1 X144.889 Y132.841 E.06034
G1 X144.356 Y132.841
G1 X145.742 Y131.454 E.06026
G1 X145.29 Y131.373
G1 X143.822 Y132.841 E.06379
G1 X143.289 Y132.841
G1 X144.897 Y131.233 E.06987
G1 X144.444 Y131.153
G1 X142.756 Y132.841 E.07335
G1 X142.223 Y132.841
G1 X143.91 Y131.153 E.07335
G1 X143.377 Y131.153
G1 X141.689 Y132.841 E.07335
G1 X141.156 Y132.841
G1 X142.844 Y131.153 E.07335
G1 X142.311 Y131.153
G1 X140.623 Y132.841 E.07335
G1 X140.089 Y132.841
G1 X141.777 Y131.153 E.07335
G1 X141.244 Y131.153
G1 X139.556 Y132.841 E.07335
G1 X139.023 Y132.841
G1 X140.711 Y131.153 E.07335
G1 X140.178 Y131.153
G1 X138.49 Y132.841 E.07335
G1 X137.956 Y132.841
G1 X139.644 Y131.153 E.07335
G1 X139.111 Y131.153
G1 X137.423 Y132.841 E.07335
G1 X136.89 Y132.841
G1 X138.578 Y131.153 E.07335
G1 X138.045 Y131.153
G1 X136.357 Y132.841 E.07335
G1 X135.823 Y132.841
G1 X137.511 Y131.153 E.07335
G1 X136.978 Y131.153
G1 X135.29 Y132.841 E.07335
G1 X134.757 Y132.841
G1 X136.445 Y131.153 E.07335
G1 X135.912 Y131.153
G1 X134.224 Y132.841 E.07335
G1 X133.69 Y132.841
G1 X135.378 Y131.153 E.07335
G1 X134.845 Y131.153
G1 X133.157 Y132.841 E.07335
G1 X132.624 Y132.841
G1 X134.312 Y131.153 E.07335
G1 X133.779 Y131.153
G1 X132.091 Y132.841 E.07335
G1 X131.557 Y132.841
G1 X133.245 Y131.153 E.07335
G1 X132.712 Y131.153
G1 X131.024 Y132.841 E.07335
G1 X130.491 Y132.841
G1 X132.179 Y131.153 E.07335
G1 X131.645 Y131.153
G1 X129.958 Y132.841 E.07335
G1 X129.424 Y132.841
G1 X131.112 Y131.153 E.07335
G1 X130.579 Y131.153
G1 X128.891 Y132.841 E.07335
G1 X128.358 Y132.841
G1 X130.046 Y131.153 E.07335
G1 X129.512 Y131.153
G1 X127.825 Y132.841 E.07335
G1 X127.291 Y132.841
G1 X128.78 Y131.352 E.0647
G1 X128.136 Y131.463
G1 X126.758 Y132.841 E.05987
G1 X126.225 Y132.841
G1 X127.625 Y131.441 E.06085
G1 X127.189 Y131.343
G1 X125.692 Y132.841 E.06509
G1 X125.158 Y132.841
G1 X126.808 Y131.192 E.07167
G1 X126.313 Y131.153
G1 X124.625 Y132.841 E.07335
G1 X124.092 Y132.841
G1 X125.78 Y131.153 E.07335
G1 X125.246 Y131.153
G1 X123.559 Y132.841 E.07335
G1 X123.025 Y132.841
G1 X124.713 Y131.153 E.07335
G1 X124.18 Y131.153
G1 X122.492 Y132.841 E.07335
G1 X121.959 Y132.841
G1 X123.647 Y131.153 E.07335
G1 X123.113 Y131.153
G1 X121.425 Y132.841 E.07335
G1 X120.892 Y132.841
G1 X122.58 Y131.153 E.07335
G1 X122.047 Y131.153
G1 X120.359 Y132.841 E.07335
G1 X119.826 Y132.841
G1 X121.514 Y131.153 E.07335
G1 X120.98 Y131.153
G1 X119.292 Y132.841 E.07335
G1 X118.759 Y132.841
G1 X120.447 Y131.153 E.07335
G1 X119.914 Y131.153
G1 X118.226 Y132.841 E.07335
G1 X117.693 Y132.841
G1 X119.381 Y131.153 E.07335
G1 X118.847 Y131.153
G1 X117.159 Y132.841 E.07335
G1 X116.626 Y132.841
G1 X118.314 Y131.153 E.07335
G1 X117.781 Y131.153
G1 X116.093 Y132.841 E.07335
G1 X115.56 Y132.841
G1 X117.248 Y131.153 E.07335
G1 X116.714 Y131.153
G1 X115.026 Y132.841 E.07335
G1 X114.493 Y132.841
G1 X116.181 Y131.153 E.07335
G1 X115.648 Y131.153
M73 P98 R0
G1 X113.96 Y132.841 E.07335
G1 X113.427 Y132.841
G1 X115.115 Y131.153 E.07335
G1 X114.581 Y131.153
G1 X112.893 Y132.841 E.07335
G1 X112.36 Y132.841
G1 X114.048 Y131.153 E.07335
G1 X113.515 Y131.153
G1 X111.827 Y132.841 E.07335
G1 X111.294 Y132.841
G1 X112.981 Y131.153 E.07335
G1 X112.448 Y131.153
G1 X110.76 Y132.841 E.07335
G1 X110.227 Y132.841
G1 X111.915 Y131.153 E.07335
G1 X111.382 Y131.153
G1 X109.694 Y132.841 E.07335
G1 X109.161 Y132.841
G1 X110.602 Y131.4 E.06263
G1 X110.002 Y131.467
G1 X108.627 Y132.841 E.05972
G1 X108.094 Y132.841
G1 X109.512 Y131.423 E.06163
G1 X109.092 Y131.31
G1 X107.561 Y132.841 E.06652
G1 X107.028 Y132.841
G1 X108.715 Y131.153 E.07335
G1 X108.182 Y131.153
G1 X106.494 Y132.841 E.07335
G1 X105.961 Y132.841
G1 X107.649 Y131.153 E.07335
G1 X107.116 Y131.153
G1 X105.428 Y132.841 E.07335
G1 X104.894 Y132.841
G1 X106.582 Y131.153 E.07335
G1 X106.049 Y131.153
G1 X104.361 Y132.841 E.07335
G1 X103.828 Y132.841
G1 X105.516 Y131.153 E.07335
G1 X104.983 Y131.153
G1 X103.295 Y132.841 E.07335
G1 X102.761 Y132.841
G1 X104.449 Y131.153 E.07335
G1 X103.916 Y131.153
G1 X102.228 Y132.841 E.07335
G1 X101.695 Y132.841
G1 X103.383 Y131.153 E.07335
G1 X102.85 Y131.153
G1 X101.162 Y132.841 E.07335
G1 X100.628 Y132.841
G1 X102.316 Y131.153 E.07335
G1 X101.783 Y131.153
G1 X100.095 Y132.841 E.07335
G1 X99.562 Y132.841
G1 X101.25 Y131.153 E.07335
G1 X100.717 Y131.153
G1 X99.029 Y132.841 E.07335
G1 X98.495 Y132.841
G1 X100.183 Y131.153 E.07335
G1 X99.65 Y131.153
G1 X97.962 Y132.841 E.07335
G1 X97.429 Y132.841
G1 X99.117 Y131.153 E.07335
G1 X98.584 Y131.153
G1 X96.896 Y132.841 E.07335
G1 X96.362 Y132.841
G1 X98.05 Y131.153 E.07335
G1 X97.517 Y131.153
G1 X95.829 Y132.841 E.07335
G1 X95.296 Y132.841
G1 X96.984 Y131.153 E.07335
G1 X96.45 Y131.153
G1 X94.763 Y132.841 E.07335
G1 X94.229 Y132.841
G1 X95.917 Y131.153 E.07335
G1 X95.384 Y131.153
G1 X93.696 Y132.841 E.07335
G1 X93.163 Y132.841
G1 X94.851 Y131.153 E.07335
G1 X94.317 Y131.153
G1 X92.63 Y132.841 E.07335
G1 X92.096 Y132.841
G1 X93.784 Y131.153 E.07335
G1 X93.234 Y131.171
G1 X91.563 Y132.841 E.07259
G1 X91.03 Y132.841
G1 X92.44 Y131.431 E.06126
G1 X91.874 Y131.464
G1 X90.497 Y132.841 E.05985
G1 X89.963 Y132.841
G1 X91.403 Y131.401 E.06258
G1 X90.996 Y131.275
G1 X89.43 Y132.841 E.06807
G1 X88.897 Y132.841
G1 X90.585 Y131.153 E.07335
G1 X90.051 Y131.153
G1 X88.363 Y132.841 E.07335
G1 X87.83 Y132.841
G1 X89.518 Y131.153 E.07335
G1 X88.985 Y131.153
G1 X87.297 Y132.841 E.07335
G1 X86.764 Y132.841
G1 X88.452 Y131.153 E.07335
G1 X87.918 Y131.153
G1 X86.23 Y132.841 E.07335
G1 X85.697 Y132.841
G1 X87.385 Y131.153 E.07335
G1 X86.852 Y131.153
G1 X85.164 Y132.841 E.07335
G1 X84.631 Y132.841
G1 X86.319 Y131.153 E.07335
G1 X85.785 Y131.153
G1 X84.097 Y132.841 E.07335
G1 X83.564 Y132.841
G1 X85.252 Y131.153 E.07335
G1 X84.719 Y131.153
G1 X83.031 Y132.841 E.07335
G1 X82.498 Y132.841
G1 X84.186 Y131.153 E.07335
G1 X83.652 Y131.153
G1 X81.964 Y132.841 E.07335
G1 X81.431 Y132.841
G1 X83.119 Y131.153 E.07335
G1 X82.586 Y131.153
G1 X80.898 Y132.841 E.07335
G1 X80.365 Y132.841
G1 X82.053 Y131.153 E.07335
G1 X81.519 Y131.153
G1 X79.831 Y132.841 E.07335
G1 X79.298 Y132.841
G1 X80.986 Y131.153 E.07335
G1 X80.453 Y131.153
G1 X78.765 Y132.841 E.07335
G1 X78.232 Y132.841
G1 X79.919 Y131.153 E.07335
G1 X79.386 Y131.153
G1 X77.698 Y132.841 E.07335
G1 X77.165 Y132.841
G1 X78.853 Y131.153 E.07335
G1 X78.32 Y131.153
G1 X76.632 Y132.841 E.07335
G1 X76.099 Y132.841
G1 X77.786 Y131.153 E.07335
G1 X77.253 Y131.153
G1 X75.565 Y132.841 E.07335
G1 X75.032 Y132.841
G1 X76.72 Y131.153 E.07335
G1 X76.187 Y131.153
G1 X74.499 Y132.841 E.07335
G1 X73.966 Y132.841
G1 X75.653 Y131.153 E.07335
G1 X75.12 Y131.153
G1 X73.432 Y132.841 E.07335
G1 X73.417 Y132.323
G1 X74.587 Y131.153 E.05082
G1 X74.054 Y131.153
G1 X73.417 Y131.789 E.02765
; WIPE_START
M204 S10000
G1 X74.054 Y131.153 E-.34193
G1 X74.587 Y131.153 E-.20264
G1 X74.186 Y131.554 E-.21543
; WIPE_END
G1 E-.04 F1800
G1 X81.818 Y131.549 Z6.8 F30000
G1 X127.812 Y131.521 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.0928421
G1 F15000
G1 X127.647 Y131.441 E.00075
G1 X127.885 Y131.448 F30000
; LINE_WIDTH: 0.114046
G1 F15000
G1 X127.7 Y131.516 E.00114
; WIPE_START
G1 X127.885 Y131.448 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X120.252 Y131.379 Z6.8 F30000
G1 X110.949 Y131.296 Z6.8
G1 Z6.4
G1 E.8 F1800
; LINE_WIDTH: 0.128496
G1 F15000
G1 X110.67 Y131.467 E.00229
; WIPE_START
G1 X110.949 Y131.296 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X108.881 Y131.255 Z6.8 F30000
G1 Z6.4
G1 E.8 F1800
; LINE_WIDTH: 0.102686
G1 F15000
G1 X108.754 Y131.164 E.00076
; WIPE_START
G1 X108.881 Y131.255 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X116.513 Y131.294 Z6.8 F30000
G1 X164.057 Y131.537 Z6.8
G1 Z6.4
G1 E.8 F1800
; LINE_WIDTH: 0.116231
G1 F15000
G1 X163.846 Y131.445 E.00138
G1 X164.149 Y131.445 F30000
; LINE_WIDTH: 0.106947
G1 F15000
G1 X163.938 Y131.537 E.0012
; WIPE_START
G1 X164.149 Y131.445 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X156.518 Y131.304 Z6.8 F30000
G1 X147.341 Y131.134 Z6.8
G1 Z6.4
G1 E.8 F1800
; LINE_WIDTH: 0.151806
G1 F15000
G1 X147.227 Y131.219 E.00126
; LINE_WIDTH: 0.194174
G1 X147.041 Y131.348 E.00279
; WIPE_START
G1 X147.227 Y131.219 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X145.932 Y131.531 Z6.8 F30000
G1 Z6.4
G1 E.8 F1800
; LINE_WIDTH: 0.0981318
G1 F15000
G1 X145.723 Y131.435 E.00103
G1 X146.013 Y131.45 F30000
; LINE_WIDTH: 0.10753
G1 F15000
G1 X145.816 Y131.529 E.00112
; WIPE_START
G1 X146.013 Y131.45 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X138.382 Y131.339 Z6.8 F30000
G1 X129.174 Y131.205 Z6.8
G1 Z6.4
G1 E.8 F1800
; LINE_WIDTH: 0.165913
G1 F15000
G1 X128.846 Y131.418 E.00392
G1 X129.171 Y131.201 F30000
; LINE_WIDTH: 0.109491
G1 F15000
G3 X128.85 Y131.422 I-9.566 J-13.578 E.00211
; WIPE_START
G1 X129.171 Y131.201 E-.76
; WIPE_END
G1 E-.04 F1800
G1 X136.799 Y131.454 Z6.8 F30000
G1 X182.594 Y132.972 Z6.8
G1 Z6.4
G1 E.8 F1800
; LINE_WIDTH: 0.25179
G1 F15000
G1 X73.406 Y132.972 E1.85841
; CHANGE_LAYER
; Z_HEIGHT: 6.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15000
G1 X75.406 Y132.972 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 33/33
; update layer progress
M73 L33
M991 S0 P32 ;notify layer change
; OBJECT_ID: 15
G17
G3 Z6.8 I.009 J1.217 P1  F30000
G1 X182.79 Y132.196 Z6.8
G1 Z6.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5369
M204 S5000
G1 X182.79 Y132.818 E.01912
;========Date 20250206========
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0
M1004 S5 P1  ; external shutter

M623
; SKIPPABLE_END

G1 X73.21 Y132.818 E3.36709
G1 X73.21 Y132.196 E.01912
G1 X182.73 Y132.196 E3.36524
M204 S10000
G1 X182.594 Y132.507 F30000
; FEATURE: Gap infill
; LINE_WIDTH: 0.27295
G1 F5369
G1 X73.406 Y132.507 E2.04668
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F15000
G1 X75.406 Y132.507 E-.76
; WIPE_END
G1 E-.04 F1800
G17
G3 Z7 I1.217 J0 P1  F30000
M106 S0
M106 P2 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20240528 =====================
M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G1 E-0.8 F1800 ; retract
G1 Z7.1 F900 ; lower z a little
G1 X65 Y245 F12000 ; move to safe pos
G1 Y265 F3000

G1 X65 Y245 F12000
G1 Y265 F3000
M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

G1 X100 F12000 ; wipe
; pull back filament to AMS
M620 S255
G1 X20 Y50 F12000
G1 Y-3
T255
G1 X65 F12000
G1 Y265
G1 X100 F12000 ; wipe
M621 S255
M104 S0 ; turn off hotend

M622.1 S1 ; for prev firware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
    M400 ; wait all motion done
    M991 S0 P-1 ;end smooth timelapse at safe pos
    M400 S3 ;wait for last picture to be taken
M623; end of "timelapse_record_flag"

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z106.6 F600
    G1 Z104.6

M400 P100
M17 R ; restore z current

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0
;=====printer finish  sound=========
M17
M400 S1
M1006 S1
M1006 A0 B20 L100 C37 D20 M40 E42 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C46 D10 M80 E46 F10 N80
M1006 A44 B20 L100 C39 D20 M60 E48 F20 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C44 D10 M60 E44 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C39 D10 M60 E39 F10 N60
M1006 A0 B10 L100 C0 D10 M60 E0 F10 N60
M1006 A0 B10 L100 C48 D10 M60 E44 F10 N100
M1006 A0 B10 L100 C0 D10 M60 E0 F10  N100
M1006 A49 B20 L100 C44 D20 M100 E41 F20 N100
M1006 A0 B20 L100 C0 D20 M60 E0 F20 N100
M1006 A0 B20 L100 C37 D20 M30 E37 F20 N60
M1006 W

M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power
M960 S5 P0 ; turn off logo lamp
M73 P100 R0
; EXECUTABLE_BLOCK_END

