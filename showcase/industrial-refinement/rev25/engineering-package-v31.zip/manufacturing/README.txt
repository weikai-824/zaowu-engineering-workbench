reference_only / manufacturer_reference 不等于已校准切片参数或生产放行。正式生产还需绑定实际机台、材料批次、支撑/摆放、首件实测和责任签核。
