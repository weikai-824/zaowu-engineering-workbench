工程包：Final Showcase · 桌面智能环境监测终端
项目 217a34ab-6fc4-42ef-a04b-c167c15dd177 · Revision 11 · 2026-09-15T13:55:45.969Z
manufacturing 零件进入 BOM、制造计划、分件 STL 与 assembly；Visual Candidate 只在 references 中保留。
cad-native 已展开 CAD Task 的 STEP、BREP、STL、assembly 与 report，保留原结果 ZIP，并附带已复核的外层 execution-proof.json。内部 CAD report 仍为 unsigned_local_report；设备软件密钥签名不等于硬件证明、独立重算或制造验证。
slicing 始终包含固定任务 manifest、配置与输入 STL；仅当真实结果已归档时包含 result.zip、结果报告、3MF 和其中的 G-code。
offline_consistent 只证明固定文件链一致；physicalValidation=not_run，productionReady=false。
traceability.json 记录项目、Revision、Part、CAD Task、Slice Task 和全部已列文件 SHA-256。
